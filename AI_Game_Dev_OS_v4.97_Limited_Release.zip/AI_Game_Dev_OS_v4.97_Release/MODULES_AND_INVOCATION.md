# AI Game Dev OS v4.97 Modules And Invocation

This is the root-level module and invocation contract for
`AI_Game_Dev_OS_v4.97/`. It is the authoritative place to understand what
modules exist, which files define them, and how Codex, WorkBuddy, Cursor, or an
external runtime adapter should invoke them.

Layer-local README files are pointers only. Do not use `os_layer/README.md` or
`pack_layer/README.md` as operational entrypoints for v4.97.

## Root Operating Model

v4.97 keeps the root-first operating style while using physical layers:

```text
AI_Game_Dev_OS_v4.97/
  README.md
  INDEX.md
  MANIFEST.json
  MODULES_AND_INVOCATION.md
  RUNTIME_INSTANCE_CONTRACT.md
  REAL_PROJECT_ADOPTION_CONTRACT.md
  ROOT_MIRROR_POLICY.md
  IDE_INTEGRATION.md
  USER_MANUAL.md
  OS_PACK_LAYER_MAP.md
  DELIVERY_CONTRACT.md
  os_layer/
  pack_layer/
  production_runtime/
  packs/
  scripts/
  tests/
```

The root directory owns:

- user and AI IDE entrypoints;
- module catalog;
- invocation rules;
- validation commands;
- source/release delivery boundaries;
- `.dev_os_meta/` delivery policy;
- root/pack-layer mirror rules.

The layers own implementation files, schemas, packs, tests, and historical
baseline surfaces. They do not own whole-version onboarding, module selection,
call instructions, changelog, or release notes.

Layer-local `CHANGELOG.md` or `RELEASE_NOTES*.md` files are allowed only when
they are inherited historical baseline provenance. For v4.97, whole-package
changelog and release-note authority belongs at the version root.

## Module Catalog

| Module | Primary root route | Implementation surface | Main invocation |
| --- | --- | --- | --- |
| Version contract | `README.md`, `INDEX.md`, `MANIFEST.json` | root files | Read before any layer-specific action. |
| AI IDE bootstrap | `IDE_INTEGRATION.md` | root file plus Orchestrator sheet | Build an explicit route before edits or agent handoff. |
| User workflow manual | `USER_MANUAL.md` | root file | Follow for GDD, project attachment, QA, beta readiness. |
| Runtime instance contract | `RUNTIME_INSTANCE_CONTRACT.md` | target project `.ai_dev_os/` and artifact root | Place generated bindings, run plans, traces, reports, and adoption evidence outside canonical v4.97 definitions. |
| Real-project adoption contract | `REAL_PROJECT_ADOPTION_CONTRACT.md` | target project plus artifact root | Define required adoption evidence and lifecycle promotion gate. |
| Contract schemas | `schemas/version_manifest.schema.json`, `schemas/ai_ide_integration_policy.schema.json`, `schemas/ai_ide_invocation_profile.schema.json` | root schemas | Validate the root manifest and AI IDE adapter JSON contracts. |
| Root mirror policy | `ROOT_MIRROR_POLICY.md` | root `packs/`, `scripts/`, `tests/` mirrors | Use root commands as stable public entrypoints while keeping `pack_layer/` synchronized. |
| OS baseline | `OS_PACK_LAYER_MAP.md` | `os_layer/` | Use only after root routing selects an OS capability. |
| Orchestrator routing | `os_layer/os_control_plane/leads/orchestrator.capability.json` | OS control plane | Review resource selection and invocation plans. |
| FixOps/problem intake | `os_layer/docs/31_fixops/README.md` | OS docs plus repository-root `.dev_os_meta/fixops/` evidence | Record recurring problems and proposed fixes; promote accepted behavior before packaging. |
| Production pack | `pack_layer/packs/game_system_packs/end_to_end_production/capability_pack.json` | `pack_layer/packs/game_system_packs/end_to_end_production/` | Select agents, skills, allowed writes, forbidden writes, and validation commands. |
| Slice 0 Gate-local baseline | `V497_KICKOFF_BASELINE.md` | two manifest-enumerated paths under `production_runtime/` | Verify that an unbound package/build stage is omitted and cannot become an ordinary Gate default. This is not a qualified runtime. |
| Consumer-derived-state contract baseline | `V497_DEVELOPMENT_STATUS.md` | exact manifest-enumerated schemas, `production_runtime/` composition/CLI, sanitized fixtures and focused tests | Inspect/dry-run/validate canonical-to-derived coherence without project writes or new obligations; not complete Slice 2/Assembly/Pilot/qualification/adoption/release. |
| Delivery workflow | `pack_layer/packs/game_system_packs/end_to_end_production/references/end_to_end_delivery_workflow.json` | pack references | Resolve skill owners, artifact routes, and gates. |
| Runtime adapter | `pack_layer/packs/game_system_packs/end_to_end_production/docs/agent_harness/RUNTIME_ADAPTER_SPEC.md` | pack docs and schemas | Consume run plans, execute external agents, return execution traces. |
| AI IDE adapter base | `adapters/AI_IDE_ADAPTER_BASE.md` | adapter contract | Bind all supported AI IDEs to shared read order, canonical-source resolution, runtime state, evidence, and stop conditions. |
| Codex adapter | `adapters/codex/codex_integration_policy.json`, `adapters/codex/codex_invocation_profile.json`, `adapters/codex/codex_runtime_adapter_contract.md` | adapter contract | Specialize the shared adapter base for Codex parent/subagent coordination. |
| Production Worker | `adapters/codex/production_worker.py` | Codex adapter implementation | Apply one selected task through exact inputs and bounded write envelopes. |
| Godot local-development execution | `adapters/codex/godot_execution_adapter.py`, `adapters/codex/godot_development_build.py`, `adapters/codex/godot_focused_qa.py` | Codex adapter plus development CLIs | Run typed feedback, reproducible development delivery, and independent focused QA. |
| Resource lease and terminal artifact lifecycle | `os_layer/scripts/portable_workspace/resource_lifecycle.py`, `production_runtime/execution_artifact_lifecycle.py`, `engine_profiles/godot/artifact_lifecycle.py`, `adapters/codex/candidate1_focused_qa_runtime_v1_3_0.py` | Service-owned SQLite plus exact external execution root | Reserve before materialization, enforce semantic/disk admission, preserve Evidence/logs and compact allowlisted transient bytes only after process/reference/consumer closure. |
| Pack Registry and cross-project reuse | `production_runtime/pack_registry.py`, `production_runtime/cli.py pack-registry` | Explicit package manifests plus read-only exact Git identities | Observe content-addressed components, preview deny-by-default reuse and verify target rollback trees without lifecycle or project mutation. |
| Integrated functional pre-closure | `production_runtime/integrated_closure.py` | Clean Git package identity, two exact Assembly locks/component inventories, caller-enumerated hash-and-pointer Evidence | Report exact closure cells, seven outcome dimensions and eight negative families without aggregate scoring or authority mutation. |
| Production Spec input bridge | `adapters/codex/production_spec_input_bridge.py` | engine-neutral Codex adapter input contract | Validate one full Production Spec, apply deterministic default mappings, and preserve additive/narrowing augmentations without executing the Production Cell. |
| Production Cell composition | `adapters/codex/production_cell_composition.py`, `adapters/codex/godot_local_development_profile.py` | engine-neutral core plus the single v4.97 Godot profile | Compose an already selected committed implementation checkpoint, target feedback, development build, and focused QA. |
| Project Evidence continuity | `adapters/codex/development_project_evidence.py`, `adapters/codex/development_project_memory.py`, `schemas/project_evidence_continuity.schema.json` | project-local development data plus root/Pack CLI mirrors | Register and verify small content-addressed facts, explicitly promote evidence-linked memory, rebuild a disposable keyword index, and assemble an advisory evolve-input bundle. |
| Cursor adapter | `adapters/cursor/cursor_integration_policy.json`, `adapters/cursor/cursor_invocation_profile.json`, `adapters/cursor/cursor_runtime_adapter_contract.md` | adapter contract | Specialize the shared adapter base for Cursor worktree-oriented parallel agents. |
| WorkBuddy private adapter | `adapters/workbuddy_private/workbuddy_private_integration_policy.json`, `adapters/workbuddy_private/workbuddy_private_invocation_profile.json`, `adapters/workbuddy_private/workbuddy_private_runtime_adapter_contract.md` | adapter contract | Specialize the shared adapter base for WorkBuddy private runtime coordination. |
| Release and payload delivery | `DELIVERY_CONTRACT.md` | root docs and delivery scripts | Decide source-tree payload, release snapshot, governance appendix, and transient policy. |

## Invocation Principles

Every non-trivial invocation must declare:

- goal class;
- selected module;
- selected layer or root compatibility path;
- owner agent, skill, workflow state, or OS control capability;
- files to read;
- allowed write surface;
- expected evidence;
- validation command;
- stop condition.

Repository scripts are contract and validation tools. They may create briefs,
run plans, reports, schemas, and diagnostics. They must not silently call LLM
agents or act as an automatic agent router.

## Common Invocation Routes

### Terminal Execution-Artifact Lifecycle

Build a closed `resource_allocation_request` and call the fenced service before
any execution-root `mkdir`, checkout or snapshot creation. Use
`materialize_managed_godot_execution_snapshot(...)` for the byte-frozen Godot
v1.0.1 creator and the Candidate 1 v1.3.0 wrapper for the byte-frozen v1.2.0
operation. Both wrappers bind the accepted legacy physical-copy reason because
those frozen creators cannot be rewritten in place. Direct low-level
materializers/finalizers remain compatibility primitives, not the managed
invocation route.

Bind a live process group when applicable, record its exact completion receipt,
and close only the named consumers whose work actually finished. Managed
finalizers move held resources to `consumer_hold`; they create the
`resource_lease_binding`, compaction tombstone and central cleanup receipt only
when every required consumer/reference and process condition is closed.

Compaction is necessary only after the run is terminal. Retaining bytes is
necessary while recovery or Human observation still consumes them. An
explicit diagnostic retention override is optional. Evidence/logs and the
compaction tombstone remain; project clones and package roots are protected
and never deletion targets. A boundary incident keeps its run for forensics.

The package-local read/audit/plan surface is:

```text
python3 -m os_layer.scripts.portable_workspace.resource_lifecycle_cli --state-root <state> leases
python3 -m os_layer.scripts.portable_workspace.resource_lifecycle_cli --state-root <state> audit --discover-path <path>
python3 -m os_layer.scripts.portable_workspace.resource_lifecycle_cli --state-root <state> gc-plan --audit-json <audit.json>
```

There is deliberately no allocation, cleanup-apply or branch-delete CLI in
this corrective. A GC plan is non-executable and does not grant R5/R6 or
historical cleanup authority.

### Pack Registry and Reuse Preview

From the `AI_Game_Dev_OS_v4.97/` package root, the command family is:

```text
python3 -m production_runtime.cli pack-registry scan ...
python3 -m production_runtime.cli pack-registry list --snapshot <snapshot.json>
python3 -m production_runtime.cli pack-registry inspect --snapshot <snapshot.json> --component-id <id>
python3 -m production_runtime.cli pack-registry reuse-preview ...
python3 -m production_runtime.cli pack-registry rollback-verify --preview <preview.json> --project-root <exact-read-only-clone>
```

`scan` requires explicit Pack, Recipe, Agent, Skill, Engine Profile and quality
profile paths; templates are included only through explicit `--template`
arguments. `reuse-preview` requires both exact Assembly locks, both exact
Project Bindings and the target baseline commit/tree. It reuses only the exact
neutral core and emits target-resolved components, inheritance exclusions,
dependency, write, validation and rollback plans.

`rollback-verify` requires the checkout HEAD/tree and complete baseline-to-
current delta to match the preview. It reads Git blobs and builds forward and
reverse trees through a temporary index/object directory, then removes that
temporary state. It has no apply, checkout, reset, Adapter, lifecycle or
project-write operation. Snapshot, preview or rollback PASS remains ordinary
development Evidence, not professional efficacy, promotion, adoption,
qualification or release authority.

### Integrated Functional Pre-closure

`production_runtime.integrated_closure.build_integrated_preclosure(...)` is a
pure reporting boundary over one clean package checkout, two re-resolvable
Assembly locks and an explicit Evidence manifest. Every Evidence file requires
an exact raw SHA-256 and JSON-pointer assertion. The evaluator requires all
seven Revision 3 outcome dimensions and the eight mandatory negative families;
it never emits an aggregate score.

Only `verified` satisfies a required closure cell. `bounded`,
`synthetic_only`, `not_run`, `unsupported`, `missing_required_disposition` and
`failed` remain visible blockers. The evaluator validates bytes and declared
assertions but does not authenticate Evidence Authority, run a project,
contact WorkBuddy, dispatch a model, mutate lifecycle or grant qualification.

### GDD Orchestration

Primary files:

- `scripts/delivery/run_gdd_orchestrator.py`
- `pack_layer/packs/game_system_packs/end_to_end_production/skills/gdd_orchestrator_skill.json`
- `pack_layer/packs/game_system_packs/end_to_end_production/references/end_to_end_delivery_workflow.json`

Start a planned GDD run:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/run_gdd_orchestrator.py start \
  --intent "反向塔防：护送怪物下班"
```

Validate a run package or completed outputs:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/run_gdd_orchestrator.py validate \
  --artifact-root <artifact_root>
```

The start command creates an execution package. Codex, WorkBuddy, Cursor, or an
external runtime still has to perform the authored work and return artifacts.

### Shared Truth

Primary files:

- `scripts/delivery/generate_shared_truth_index.py`
- `scripts/delivery/validate_shared_truth_index.py`
- `scripts/delivery/validate_shared_truth_writeback.py`
- `pack_layer/packs/game_system_packs/end_to_end_production/references/shared_truth/artifact_index.schema.json`

Use this route when design, code, data, QA, and evidence refs need a common
index. Write-back validation is approval checking only; it does not update
external truth stores.

### Architecture Baseline

Primary files:

- `scripts/delivery/inspect_architecture_baseline.py`
- `scripts/delivery/validate_architecture_baseline.py`
- `pack_layer/packs/game_system_packs/end_to_end_production/references/architecture/module_map.schema.json`

Use this route when attaching a project or checking drift between declared
design/runtime surfaces and actual project files.

### Controlled Refactor

Primary files:

- `scripts/delivery/evaluate_controlled_refactor_demo.py`
- `scripts/delivery/validate_controlled_refactor_artifacts.py`
- `pack_layer/packs/game_system_packs/end_to_end_production/references/refactor/small_refactor_proposal.schema.json`
- `pack_layer/packs/game_system_packs/end_to_end_production/references/refactor/approved_refactor_handoff.schema.json`

Use this route only for approved, bounded refactors with before/after evidence,
QA, rollback notes, and write-surface checks.

### Agent Harness

Primary files:

- `scripts/delivery/generate_agent_run_plan.py`
- `scripts/delivery/validate_agent_execution_trace.py`
- `pack_layer/packs/game_system_packs/end_to_end_production/docs/agent_harness/RUNTIME_ADAPTER_SPEC.md`
- `pack_layer/packs/game_system_packs/end_to_end_production/references/agent_harness/agent_run_plan.schema.json`
- `pack_layer/packs/game_system_packs/end_to_end_production/references/agent_harness/agent_execution_trace.schema.json`

Generate a run plan:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/generate_agent_run_plan.py \
  --artifact-root <delivery_artifact_root> \
  --write-plan <agent_run_plan.json>
```

Validate a runtime-produced trace:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_agent_execution_trace.py \
  --run-plan <agent_run_plan.json> \
  --trace <agent_execution_trace.json>
```

Synthetic traces are regression evidence only. Beta promotion requires a
runtime-produced trace.

### Beta Readiness

Primary files:

- `scripts/delivery/evaluate_pack_beta_readiness.py`
- `scripts/delivery/render_beta_readiness_report.py`
- `pack_layer/packs/game_system_packs/end_to_end_production/docs/beta/REAL_PROJECT_ADOPTION_CHECKLIST.md`
- `pack_layer/packs/game_system_packs/end_to_end_production/docs/beta/V493_BETA_READINESS_REPORT.md`
- `pack_layer/packs/game_system_packs/end_to_end_production/references/beta_readiness_criteria.json`

Run a non-mutating real-project dry run:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/evaluate_pack_beta_readiness.py \
  --project-root <project_root> \
  --artifact-root <delivery_artifact_root> \
  --dry-run \
  --write-report <report.json>
```

Render a reviewer-facing report:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/render_beta_readiness_report.py \
  --report <report.json> \
  --write-markdown <report.md>
```

The evaluator is read-only with respect to `project_root`. It does not promote
`lifecycle_status`.

### Project Evidence Continuity MVP

Primary files:

- `scripts/development/run_project_evidence_continuity.py`
- `pack_layer/scripts/development/run_project_evidence_continuity.py`
- `schemas/project_evidence_continuity.schema.json`

Register one small factual artifact from the project or an explicitly added
source root, then rebuild and query the disposable metadata index:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/development/run_project_evidence_continuity.py \
  --project-root <project_root> \
  --project-id <project_id> \
  --allowed-source-root <artifact_root> \
  register \
  --source <artifact_file> \
  --task-id <task_id> \
  --source-revision <exact_revision> \
  --evidence-kind <kind> \
  --title <title> \
  --summary <summary> \
  --recorded-by <actor_id>

python3 AI_Game_Dev_OS_v4.97/scripts/development/run_project_evidence_continuity.py \
  --project-root <project_root> --project-id <project_id> rebuild-index

python3 AI_Game_Dev_OS_v4.97/scripts/development/run_project_evidence_continuity.py \
  --project-root <project_root> --project-id <project_id> \
  search --query <keywords>
```

The default registration status is `observed`; `verified` additionally requires
an explicit validator ID. Exact `verify` does not depend on the index. Index
failure reduces discovery only, and evolve bundles remain
`advisory_input_only`. These commands do not perform automatic ingestion,
memory injection, qualification, Gate, release, or live actions.

### Delivery Hygiene

Primary files:

- `scripts/delivery/validate_markdown_local_paths.py`
- `scripts/delivery/validate_pack_layer_mirror.py`
- `scripts/delivery/validate_release_snapshot_freshness.py`
- `scripts/delivery/validate_delivery_transients.py`
- `DELIVERY_CONTRACT.md`

Use these commands before packaging or handoff:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_markdown_local_paths.py
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_pack_layer_mirror.py
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_release_snapshot_freshness.py
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_delivery_transients.py --strict
```

`validate_release_snapshot_freshness.py` and
`validate_delivery_transients.py` are non-blocking diagnostics by default. The
release-snapshot checker's `--strict` form applies only when an explicitly
selected delivery scope includes `AI_Game_Dev_OS_v4.97_Release/`; it is not an
ordinary-development or development-handoff prerequisite.

## Write Boundaries

The production pack manifest defines project write boundaries. In summary:

- allowed project writes include runtime source, scenes, resources, data,
  tests, RawData, tools, production art, GDD/spec docs, temporary outputs,
  handoff logs, agent logs, and task files;
- forbidden writes include core OS internals, capability protocols,
  governance scripts, `project.godot`, generated Godot internals, and `.git/`;
- `.dev_os_meta/` is repository-root governance state and is not runtime package
  content by default;
- root `packs/`, `scripts/`, and `tests/` are compatibility mirrors and must
  stay aligned with `pack_layer/`.

When a task crosses these boundaries, stop and produce an explicit invocation
plan instead of editing directly.

## Root-First Rule

For v4.97, the root directory owns the external interface. Root files are the external interface;
layer files are implementation surfaces. This preserves the
old pre-split operating model while allowing the source tree to keep OS and
pack code physically separated.

Do not add new v4.97 changelog, release-note, module, or invocation authority
under `os_layer/` or `pack_layer/`. Add those files at the root and let layer
files point back to them.
