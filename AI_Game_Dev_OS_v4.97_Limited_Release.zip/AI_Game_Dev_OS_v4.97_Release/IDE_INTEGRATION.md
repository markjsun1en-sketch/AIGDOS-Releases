# AI IDE Integration Guide

Version: `AI_Game_Dev_OS_v4.97` Production Assembly development candidate

This file is the bootstrap guide for Codex, WorkBuddy, Cursor, or another AI
IDE/runtime that mounts `AI_Game_Dev_OS_v4.97/` and needs to use it as an AI
Game Dev OS rather than as a loose document folder.

## Read Order

An AI IDE should read these files in order before routing work:

1. `INDEX.md` - version-level navigation and boundaries.
2. `MANIFEST.json` - machine-readable current version, layer, pack,
   Orchestrator, and validation surfaces.
3. `README.md` - human-readable capability and status overview.
4. `DESIGN_AND_CAPABILITY_ARCHITECTURE.md` - whole-system architecture map,
   founding constraints, truth hierarchy, layer model, and capability flow.
5. `MODULES_AND_INVOCATION.md` - root module catalog, invocation routes,
   write boundaries, and command map.
6. `RUNTIME_INSTANCE_CONTRACT.md` - target-project `.ai_dev_os/` and artifact
   root boundary for generated bindings, run plans, traces, and reports.
7. `REAL_PROJECT_ADOPTION_CONTRACT.md` - evidence requirements and lifecycle
   promotion gate for real projects.
8. `ROOT_MIRROR_POLICY.md` - stable root command and mirror-sync policy.
9. `IDE_INTEGRATION.md` - this runtime bootstrap protocol.
10. `adapters/AI_IDE_ADAPTER_BASE.md` - shared AI IDE adapter contract.
11. `USER_MANUAL.md` - user-facing operating workflows.
12. `OS_PACK_LAYER_MAP.md` - split-layer boundary map.
13. `os_layer/os_control_plane/leads/orchestrator.capability.json` - control
   plane routing authority and invocation-plan review.
14. `pack_layer/packs/game_system_packs/end_to_end_production/capability_pack.json`
   - production pack manifest.
15. `pack_layer/packs/game_system_packs/end_to_end_production/references/end_to_end_delivery_workflow.json`
   - workflow states, skill owners, artifact routes, and gates.
16. `pack_layer/packs/game_system_packs/end_to_end_production/docs/roadmap/PHASE_STATUS.md`
   - current implementation status and remaining lifecycle-promotion limits.

Do not start from `os_layer/README.md` or `pack_layer/README.md` as the full
version entrypoint. Those files are layer-local pointers.

Use root `scripts/` and `tests/` commands as stable public entrypoints unless a
task explicitly requires layer-local maintenance. `ROOT_MIRROR_POLICY.md`
defines how those commands must remain synchronized with `pack_layer/`.

Adapter-specific directories are first-class integration surfaces:

- `adapters/codex/` for Codex parent/subagent coordination.
- `adapters/cursor/` for Cursor worktree-oriented parallel agents.
- `adapters/workbuddy_private/` for WorkBuddy private runtime coordination.

These adapters do not define canonical agents, skills, workflows, schemas, or
validators. They bind AI IDE behavior back to the root contracts, Orchestrator,
production pack manifest, and delivery workflow.

## Routing Model

The user can express goals naturally. The AI IDE is responsible for turning the
goal into an explicit OS/Pack invocation plan before editing files or running
commands.

Minimum routing decision:

```text
user goal
-> goal class
-> selected OS resource or pack resource
-> owner agent or control capability
-> owner skill or workflow state
-> allowed write surfaces
-> required evidence
-> validation command
-> stop condition
```

The Orchestrator control sheet defines the cross-layer routing authority:

- `os_pack_resource_routing_review`
- `os_pack_invocation_plan_review`
- `task_breakdown_review`
- `subagent_routing_gate_review`
- `contract_check_review`
- `doc_sync_review`
- `multi_agent_preflight_review`

These capabilities let the AI IDE select and hand off to OS and pack resources.
They do not authorize silent product approval, unrestricted writes, or automatic
LLM calls from repository scripts.

## Goal Classes

| User goal | Primary route |
| --- | --- |
| Create or improve a GDD | `gdd_orchestrator_skill`, GDD specialist skills, GDD review gates |
| Convert design to implementation specs | `game_design_production_spec_skill`, `production_spec_patch_skill` |
| Attach a real project | project readiness, Shared Truth, Architecture Baseline, beta readiness |
| Inspect architecture drift | Architecture Baseline scripts and schemas |
| Perform a small approved refactor | Controlled Refactor proposal, handoff, evidence, QA, rollback |
| Execute runtime/data/art work | RawData, Godot runtime slice, UI asset binding, QA evidence skills |
| Bind a Production Spec into one development slice | read-only Production Spec input bridge, explicit selection, optional additive/narrowing augmentations |
| Compose a selected development slice | engine-neutral Production Cell contract; v4.97 implements only `godot_local_development_v1` |
| Validate external agent execution | Agent Harness run plan and execution trace validator |
| Triage a recurring issue | FixOps problem/fix/pattern workflow and repository-root `.dev_os_meta/fixops/` evidence |
| Change OS behavior or promote intake | repository-root `.dev_os_meta/` governance and promotion pipeline first |

## Invocation Contract

Before doing work, the AI IDE should state:

- selected layer: `os_layer`, `pack_layer`, compatibility path, or
  workspace-level `.dev_os_meta`;
- selected pack, agent, skill, script, or control capability;
- why that resource is the narrowest correct owner;
- files it expects to read;
- files it may write;
- validation command it will run;
- stop condition if required evidence is missing.

For multi-agent or runtime-adapter work, generate or use an explicit run plan:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/generate_agent_run_plan.py \
  --artifact-root <delivery_artifact_root> \
  --write-plan <agent_run_plan.json>
```

The runtime adapter consumes handoff lanes and returns an
`agent_execution_trace.json`. Repository scripts validate the trace; they do
not execute the LLM agents directly.

Generated runtime state must follow `RUNTIME_INSTANCE_CONTRACT.md`: project
bindings, run plans, traces, and local reports belong under the target
project's `.ai_dev_os/` directory, while shareable evidence belongs under an
explicit artifact root such as `target_project_artifacts/v493/`.

## Project Attachment

When attaching a real project, the AI IDE should collect:

- project root;
- engine/runtime shape;
- `.ai_dev_os/readiness_binding_registry.json` if present;
- compatibility capability bindings or `.ai_dev_os` local state if no registry
  exists;
- delivery artifact root;
- current GDD/spec/QA/rollback evidence;
- runtime/data/art surfaces referenced by artifacts;
- external truth system or write-back request policy if used.

Then run read-only readiness checks before proposing writes:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/evaluate_pack_beta_readiness.py \
  --project-root <project_root> \
  --artifact-root <delivery_artifact_root> \
  --dry-run \
  --write-report <report.json>
```

The first real-project run may be `BLOCKED`. Treat blockers as routing input,
not as failure of the OS.

If a project has `.ai_dev_os/readiness_binding_registry.json`, treat it as the
project-declared readiness adapter input. It may carry split-gate states for
sprint closure, focused QA, human review, supported adoption, OS demo readiness,
and production release. Keep those gates distinct:

- a passing sprint closure can coexist with non-final human review;
- a rejected follow-up art batch should block human review without rewriting an
  earlier sprint closure as failed;
- a blocked OS demo gate may block OS demo/support promotion without changing
  the project sprint verdict;
- draft dependency packs may support pilot/advisory validation only, not
  supported adoption.

When human review changes after a report was generated, refresh from the project
registry and artifact root:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/evaluate_pack_beta_readiness.py \
  --project-root <project_root> \
  --artifact-root <delivery_artifact_root> \
  --agent-trace <project_root>/.ai_dev_os/agent_execution_trace.json \
  --trace-provenance <project_root>/.ai_dev_os/agent_execution_trace.provenance.json \
  --adoption-mode supported_project_adoption \
  --write-report <delivery_artifact_root>/beta_readiness_report_refreshed.json

python3 AI_Game_Dev_OS_v4.97/scripts/delivery/render_beta_readiness_report.py \
  --report <delivery_artifact_root>/beta_readiness_report_refreshed.json \
  --write-markdown <delivery_artifact_root>/beta_readiness_report_refreshed.md
```

The refreshed report should be read by gate, not as one blended "project pass or
fail" result.

## Evidence Rules

Every non-trivial action should leave one or more of:

- schema-valid delivery artifact;
- human-readable GDD/design/spec document;
- Shared Truth index or write-back validation result;
- Architecture Baseline report;
- approved refactor handoff and before/after evidence;
- QA evidence bundle;
- rollback note;
- agent run plan and runtime-produced execution trace;
- FixOps problem/fix/pattern card when a recurring gap appears.

Fixture success is regression evidence. It is not real-project adoption
evidence.

## Hard Boundaries

- Do not auto-call LLM agents from repository Python scripts.
- Do not treat `lifecycle_status: "draft"` as beta promotion.
- Do not treat repository-root `.dev_os_meta/` as runtime package content.
- Do not put v4.93 module selection or invocation rules into layer README files.
- Do not bypass Orchestrator routing when the request crosses OS and pack
  resources.
- Do not write outside declared owner boundaries without an explicit plan and
  validation route.
- Do not promote generated exploratory GDD output into fixtures unless it is an
  intentional regression artifact.
