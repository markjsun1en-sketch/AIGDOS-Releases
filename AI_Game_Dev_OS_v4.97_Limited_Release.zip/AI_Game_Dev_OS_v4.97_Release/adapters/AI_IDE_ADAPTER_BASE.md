# AI IDE Adapter Base Contract

Version: `AI_Game_Dev_OS_v4.93`

This contract applies to every AI IDE/runtime adapter under `adapters/`.
Adapter-specific files may specialize runtime behavior, but they must not
replace the canonical root, OS-layer, or pack-layer contracts.

## Shared Read Order

1. `INDEX.md`
2. `MANIFEST.json`
3. `README.md`
4. `DESIGN_AND_CAPABILITY_ARCHITECTURE.md`
5. `MODULES_AND_INVOCATION.md`
6. `RUNTIME_INSTANCE_CONTRACT.md`
7. `REAL_PROJECT_ADOPTION_CONTRACT.md`
8. `ROOT_MIRROR_POLICY.md`
9. `IDE_INTEGRATION.md`
10. adapter-specific policy and invocation profile
11. `os_layer/os_control_plane/leads/orchestrator.capability.json`
12. `pack_layer/packs/game_system_packs/end_to_end_production/capability_pack.json`
13. `pack_layer/packs/game_system_packs/end_to_end_production/references/end_to_end_delivery_workflow.json`
14. `pack_layer/packs/game_system_packs/end_to_end_production/docs/agent_harness/RUNTIME_ADAPTER_SPEC.md`

## Canonical Source Rule

Adapters reference canonical sources. They do not define canonical agents,
skills, workflows, schemas, validators, lifecycle state, or release authority.

If an adapter file conflicts with a root contract, Orchestrator capability
sheet, production pack manifest, or delivery workflow, the AI IDE must stop and
request a contract repair.

## Invocation Rule

Before editing or running commands, the AI IDE must produce an invocation
record with:

- goal class;
- selected layer or compatibility path;
- selected resource;
- owner agent or control capability;
- owner skill or workflow state;
- allowed write surfaces;
- required evidence;
- validation command;
- stop condition.

## Runtime State Rule

Generated runtime state belongs in the target project or an explicit artifact
root, not in canonical v4.93 definitions.

Use `RUNTIME_INSTANCE_CONTRACT.md` for:

- `<target_project>/.ai_dev_os/capability_bindings.json`;
- `<target_project>/.ai_dev_os/agent_run_plan.json`;
- `<target_project>/.ai_dev_os/agent_execution_trace.json`;
- `<target_project>/.ai_dev_os/reports/`;
- `<target_project_artifacts>/v493/`.

## Evidence Rule

Repository scripts may generate plans, reports, validators, and diagnostics.
They do not automatically call LLM agents. External runtimes execute or
delegate the work and return evidence for validation.

Fixture success, dry-run reports, and synthetic traces are regression evidence.
They are not real-project adoption evidence.

## Stop Conditions

Stop before implementation when:

- root contracts are unread or inconsistent;
- no canonical owner can be resolved;
- the requested write surface is outside allowed writes;
- required evidence paths are missing;
- adapter-mediated work lacks an `agent_execution_trace.json`;
- beta readiness has promotion blockers;
- the task would make repository-root `.dev_os_meta/` a runtime package
  dependency.
