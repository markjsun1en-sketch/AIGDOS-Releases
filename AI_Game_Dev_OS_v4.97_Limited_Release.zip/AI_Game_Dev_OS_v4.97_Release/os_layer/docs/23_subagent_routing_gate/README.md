# Subagent Routing Gate — Adoption Notes

> **Layer 1 (OS Spec) — adoption surface.** v4.91 Addendum-C / P1.5.
>
> **Skill**: [`skills/_generic_core/orchestrator/subagent-routing-gate/SKILL.md`](../../skills/_generic_core/orchestrator/subagent-routing-gate/SKILL.md) · [`REFERENCES.md`](../../skills/_generic_core/orchestrator/subagent-routing-gate/REFERENCES.md)
>
> **Schema**: [`schemas/governance/delegation_decision.schema.json`](../../schemas/governance/delegation_decision.schema.json) (1.0.0)
>
> **Runtime sink**: [`runtime/registries/delegation_decision_ledger.jsonl`](../../runtime/registries/delegation_decision_ledger.jsonl) (append-only)
>
> **Validator**: [`scripts/governance/validate_delegation_decisions.py`](../../scripts/governance/validate_delegation_decisions.py)
>
> **Invariant**: [`inv_008_delegation_gate_recorded`](../../runtime/protected_contracts/protected_regression_matrix.yaml)
>
> **Sister docs**: [`DECISION_RULES.md`](DECISION_RULES.md) · [`AUDIT_LEDGER_CONTRACT.md`](AUDIT_LEDGER_CONTRACT.md)

---

## 1. Why this directory exists

`docs/23_subagent_routing_gate/` is the Layer 1 adoption companion to
the `subagent-routing-gate` skill. The skill itself describes *what*
the gate does and *how* a parent agent uses it; the docs in this
directory describe:

- the **decision contract** (when SPAWN_SUBAGENT vs LOCAL vs ESCALATE
  is the correct routing) — see [`DECISION_RULES.md`](DECISION_RULES.md);
- the **audit-ledger contract** (envelope shape, LOCAL reason-code
  enum, amends/withdrawal lifecycle, validator exit codes) — see
  [`AUDIT_LEDGER_CONTRACT.md`](AUDIT_LEDGER_CONTRACT.md);
- the **adoption hooks** that allow Layer 2 host projects to bind the
  gate to their own narrative paths without changing the skill or the
  schema — covered below.

Project-specific narrative paths (per-agent log filename, handoff
directory layout, open-issues file) are **not** specified here. Those
remain Layer 2 / project bindings (Charter anti-pattern #5
compliant).

## 2. Charter alignment

| Charter anti-pattern | How this surface complies |
|---|---|
| #2 / inv_002 — no project literals in Layer 1 | Skill, schema, validator, ledger, all docs in this dir use generic placeholders only |
| #5 — Core does not bind to project narrative | The skill names canonical narrative *types* (orchestrator log / per-agent log / handoff / open-issues), never project-specific filenames |
| #7 — no free-text escape tokens | LOCAL `reason_code` is a closed 5-element enum; `reason_note` is capped at 200 chars |
| #11 — a recorded decision is not a closure-gate pass | The validator enforces decision-record shape only; F17 "delegation-decisions smoke" tests the validator, not task completion |
| #15 — no soft alias / no escape hatch | The schema rejects unknown reason codes outright; recorded entries cannot carry `amends`, amended/withdrawn entries must |

## 3. Adoption hooks (Layer 2 binding contract)

A host project adopting this gate provides three bindings:

1. **Narrative path map** (per-project): which filenames in the
   project's `logs/` tree count as orchestrator log / per-agent log /
   handoff / open-issues for the gate's narrative writeback step.
2. **Owner catalog**: source of truth for resolving the formal
   `owner` field (typical sources: `agents_index.md`, an
   agent-role catalog, sprint-board task rows, or handoff records).
3. **Stop / escalate triggers**: optional project-specific
   conditions that promote a `SPAWN_SUBAGENT` or `LOCAL` decision
   back to `ESCALATE` (these go in `details.stop_or_escalate_if`).

The runtime mirror path
(`runtime/registries/delegation_decision_ledger.jsonl`) is canonical
and identical in every host project. Projects do **not** override it.

## 4. Smoke gate (F17)

The fast closure gate has a single item dedicated to this surface:

```
F17  Delegation decisions smoke (v4.91 Addendum-C)
     -> validate canonical empty ledger (rc=0)
     -> validate synthetic LOCAL-without-reason_code negative (rc=1)
```

Both sub-checks run via the validator's `--ledger` flag against
fixtures created in-process. F17 PASS reads as: *the validator can
read the canonical ledger without violations, and rejects a
mis-shaped LOCAL decision with the correct violation code*. It is
**not** a statement that any project's delegation decisions are
correct — that is human review territory.

## 5. Test coverage

`tests/governance/test_delegation_gate.py` (11 tests, v4.91
Addendum-C c3) drives the validator across:

- envelope happy-path (SPAWN_SUBAGENT recorded, LOCAL+reason_code,
  ESCALATE empty required_evidence);
- enum bindings (LOCAL missing reason_code, LOCAL with unknown
  reason_code);
- envelope shape (event_id pattern, cross-line uniqueness);
- amends referential integrity (unresolved reference, recorded vs
  amended/withdrawn audit_status branches);
- CLI exit-code contract (EXIT_OK on empty ledger, EXIT_VIOLATION on
  mis-shaped entry).

Adoption-time test additions belong in the host project; this
directory does not require any project-specific test files.

## 6. Deferred / out of scope

- A second `result` value for staged escalation (e.g.
  `SPAWN_SUBAGENT_DRY_RUN`) is **not planned**. Adding one would be a
  contract change requiring EP + matrix owner per Charter SOP §11.
- Cross-tenant delegation (parent in tenant A spawning subagent in
  tenant B) is explicitly out of scope for v4.91. The runtime mirror
  is per-host (single ledger per repo); Layer 2 cross-tenant routing
  is governed by `docs/19_tenancy/TENANCY_CONTRACT.md` instead.
