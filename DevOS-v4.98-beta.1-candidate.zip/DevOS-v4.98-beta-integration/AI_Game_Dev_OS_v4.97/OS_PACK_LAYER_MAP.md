# v4.97 OS Layer And Pack Layer Map

## Purpose

`AI_Game_Dev_OS_v4.97/` uses the inherited explicit physical split:

```text
AI_Game_Dev_OS_v4.97/
  os_layer/
  pack_layer/
  production_runtime/
```

This file explains what belongs in each layer and how the current v4.97 tree is
assembled from inherited and current surfaces.

## Source Baseline

`os_layer/` is sourced from `AI_Game_Dev_OS_v4.92_Release/` as provenance.

The v4.92 release is the closed full-OS provenance baseline first inherited by
v4.94 and carried into v4.97. It provides the OS/control-plane and runtime
surfaces that are not reimplemented by the inherited v4.93 production pack.

This is a packaging lineage statement, not a runtime dependency. A complete
`AI_Game_Dev_OS_v4.97/` checkout must use the packaged `os_layer/` surfaces and
must not require a sibling `AI_Game_Dev_OS_v4.92_Release/` directory to run
validation, AI IDE routing, or production-pack workflows.

Key inherited OS surfaces include:

- `os_layer/agent_packs/`
- `os_layer/capability_protocols/`
- `os_layer/docs/`
- `os_layer/evolution/`
- `os_layer/hub/`
- `os_layer/ltm/`
- `os_layer/os_control_plane/`
- `os_layer/runtime/`
- `os_layer/runtime_db/`
- `os_layer/schemas/`
- `os_layer/skills/`

The current v4.97 OS layer also includes the inherited docs-only FixOps
foundation under `os_layer/docs/31_fixops/`. Its working cards and route
decisions remain in the repository-root `.dev_os_meta/fixops/` workspace
governance area, outside this version package.

## Pack Layer

`pack_layer/` contains the current v4.93 production pack overlay:

- `pack_layer/packs/game_system_packs/end_to_end_production/`
- `pack_layer/scripts/delivery/`
- `pack_layer/tests/delivery/`

The production pack adds GDD orchestration, delivery artifact validation,
Shared Truth, Architecture Baseline, controlled refactor evidence, agent
harness protocol, beta readiness reports, and production runtime/data/art/QA
contracts.

## Production Runtime Development Baseline

`production_runtime/` is a successor-local development surface, separate from
the inherited `os_layer/` and `pack_layer/`. It contains the Slice 0
non-writing Gate-local fixture/test and an accepted pre-choice read-only
consumer-derived-state contract baseline. The latter adds exact schemas,
pure composition/route resolution, a non-mutating CLI, sanitized fixtures and
focused tests. Neither baseline establishes complete Slice 2/Production
Assembly, a Pilot, qualification, adoption, release, or project obligation.

## Compatibility Paths

The pre-split paths are retained for compatibility during this transition:

- `packs/`
- `scripts/`
- `tests/`

They mirror the inherited v4.93 pack-layer implementation and keep the existing
test entrypoint stable:

```text
python3 -m pytest AI_Game_Dev_OS_v4.97/tests/delivery/test_v493_end_to_end_skill_contracts.py -q --tb=short
```

Future work may remove or replace these compatibility paths only after tests,
docs, and user workflows are migrated to `pack_layer/`.

The active v4.97 decision is to keep them as stable public compatibility
surfaces. `ROOT_MIRROR_POLICY.md` defines the synchronization rule,
deprecation rule, and mirror validation gate.

## Current Boundary

The split does not automatically promote all `.dev_os_meta/` material into the
release package. The FixOps docs-only foundation has been promoted into
`os_layer/docs/31_fixops/`; repository-root `.dev_os_meta/` remains workspace
governance state. Memory-routing infrastructure changes, self-evolution
candidates, DB/RAG work, and skill-intake material still require the meta
promotion pipeline before becoming authoritative v4.97 package content.

## Validation Expectations

The current v4.97 development package is structurally valid only when both are
true:

- `os_layer/` preserves the full v4.92 release baseline surfaces.
- `pack_layer/` contains the v4.93 `end_to_end_production_pack` and delivery
  harness surfaces.
- `production_runtime/` and the three associated root schemas contain exactly
  the accepted non-writing baseline paths enumerated by the root manifest;
  other unaccepted Assembly bytes remain outside delivery identity.

The compatibility test entrypoint must continue to pass until a deliberate
migration replaces it.
