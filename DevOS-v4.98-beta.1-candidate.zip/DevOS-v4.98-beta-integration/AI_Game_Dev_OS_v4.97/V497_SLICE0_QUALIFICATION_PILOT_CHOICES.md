# v4.97 Slice 0 Qualification Pilot Choices

Status: read-only project inventory and bounded candidate comparison complete.
On 2026-08-29 the Human selected Candidate 1, all four documented lanes, both
exact Candidate 1 path allowlists, the two dedicated clone targets, and
WorkBuddy as read/recovery-only second Adapter. The dedicated tracked-only
clones now exist; feature implementation and external Adapter contact remain
separate later actions.

This document presents ordinary development choices. It grants no project
write, protected execution, qualification, `L3/PC-3` disposition, Pack or
Adapter promotion, supported adoption, release, push/tag, or production/live
authority.

## 1. Definitions and comparison boundary

For this comparison:

- a **maker lane** owns one non-overlapping product domain and its authored
  focused test input;
- the **integration/build lane** is the sole owner that combines admitted
  maker outputs into one runnable clone revision and performs the exact
  project-bound development build/startup checks;
- **independent focused QA** consumes the integrated revision read-only,
  writes Evidence outside product source, and cannot self-author or repair the
  implementation it judges; and
- a **preliminary write set** is a candidate path allowlist, not permission.
  It becomes executable only after the Human selects the feature, exact clone
  and admitted paths.

The neutral Feature Recipe must describe outcome, artifact roles,
dependencies, acceptance and rollback. Godot paths, scenes, commands and
project-local strings belong only to the two Project Bindings and the Godot
Engine Profile.

## 2. Confirmed inventory facts

### 2.1 LessIsMore accepted v4.96 source

| Fact | Exact observation |
| --- | --- |
| Original candidate | `/Users/macsun/Documents/LessIsMore_v495_Production_Cell` |
| Branch | `codex/v496-production-cell` |
| Commit | `f62d4fa7a7175962078bca097728d527b61b3666` |
| Tree | `5714d31f72917f2f717e18dfb73d1bafe47f17c2` |
| Tracked/index status | clean; zero untracked |
| Ignored state | 4,690 paths, including three active `tmp/v496_feature_b_human_checkpoint.*` source files |
| Godot root | repository root; Godot 4.4, 1920×1080 |
| Main scene | `res://scenes/boot/dev_boot.tscn` |
| Development export | tracked `macOS Development` preset exists |

The ignored active source has drifted from the accepted v4.96 evidence while
the tracked commit/tree remains unchanged. The original directory is therefore
read-only evidence input, not an admissible writable Pilot target.

The strongest existing exact tracked-only source anchor is:

`/private/tmp/lessismore-v496-qualification-source`

It has the same commit/tree, zero status/untracked paths, and ignored content
only under `.godot/`. It remains source-only because it is temporary, has an
existing import cache, shares the `LessIsMore` Godot `user://` namespace, and
its fetch/push URL points at the original Production Cell repository. A later
dedicated writable clone must disable push and isolate Godot user data.

The current `/Users/macsun/lessismore` SP128 line is a different project
identity at commit/tree
`66b7d3aefdc0f3f2224a379d819e2540abffb3f9` /
`b371c79c05e83a0e572c2894c91868c711cba835`; it is the source of the frozen
Gate-local contract fixture, not the accepted f62 Pilot source.

### 2.2 RandomHeroes source

| Fact | Exact observation |
| --- | --- |
| Original repository | `/Users/macsun/Documents/RandomHeroes` |
| Branch | `main` |
| Commit | `52e50087fa20cef85cb1de220986e1c2560b5e9c` |
| Tree | `8c2ef717e3210293edf91c56632c84311adb7784` |
| Tracked/index status | clean |
| Other state | seven untracked and 3,978 ignored paths |
| Godot root | `<randomheroes-clone>/game/`; Godot 4.4, Mobile, 1080×1920 |
| Main scene | `res://scenes/main.tscn` |
| Development export | no tracked `<randomheroes-clone>/game/export_presets.cfg` |

No existing RandomHeroes tracked-only clone was found. Its original repository
must remain read-only. A dedicated clone can be created only after the Human
selects the feature and exact write set.

Several existing validation scripts are unsafe for an unreviewed Pilot:

- `<randomheroes-clone>/game/tests/pity_montecarlo_validation.py` overwrites a tracked report;
- `<randomheroes-clone>/game/tests/spin_postpone_smoke.gd` and
  `<randomheroes-clone>/game/tests/sprint9_postclose_capture.gd` hard-code Evidence writes into the
  original repository; and
- normal startup/QA can write shared Godot `user://` data.

They must not be invoked as generic QA. Later execution requires an isolated
user-data scope and a dedicated evidence sink.

### 2.3 Build/integration implication

LessIsMore can use its existing macOS development export preset. RandomHeroes
can support exact-engine parse, startup and local runnable integration without
changing product semantics, but a packaged export would require a new
`<randomheroes-clone>/game/export_presets.cfg`. That additional path is not in any default candidate
write set and requires a separate Human choice.

### 2.4 Second-Adapter availability without contact

Only filesystem/path discovery was performed:

- Claude Code executable exists at `/Users/macsun/.local/bin/claude`; its
  local version target is `2.1.31`.
- Cursor.app exists; its internal `cursor` script exists, but `cursor` is not
  currently on `PATH`. `/usr/local/bin/code` points into Cursor.app.
- neither executable was invoked and no external Adapter was contacted.

## 3. Candidate 1 — Read-only Hero / Run Summary

### 3.1 Neutral outcome

Open one Human-observable summary from an existing project entry point. A
project adapter projects an allowlisted, deep-copied read model; a separate UI
consumer presents it and restores interaction/focus on close. Opening,
refreshing and closing the summary must not mutate gameplay, persistence or
transaction state.

Allowed neutral fields are identity/display label, HP, project-selected
resources, compact build/status summary, progress count and terminal run
state. Internal ledgers, executor tokens, pending operations, raw dictionaries,
inventory editing, heal/equip/reset actions and persistence are excluded.

### 3.2 Lanes and preliminary write sets

#### LessIsMore

**Maker A — read-model projection**

- `<lessismore-clone>/scripts/map/run_summary_projection.gd`
- `<lessismore-clone>/scripts/map/run_summary_projection.gd.uid`
- `<lessismore-clone>/tools/qa_v497_run_summary_projection_smoke.gd`
- `<lessismore-clone>/tools/qa_v497_run_summary_projection_smoke.gd.uid`

**Maker B — presentation and interaction**

- `<lessismore-clone>/scripts/ui/shared/run_summary_presenter.gd`
- `<lessismore-clone>/scripts/ui/shared/run_summary_presenter.gd.uid`
- `<lessismore-clone>/tools/qa_v497_run_summary_presenter_smoke.gd`
- `<lessismore-clone>/tools/qa_v497_run_summary_presenter_smoke.gd.uid`

**Integration/build owner**

- `<lessismore-clone>/scripts/map/world_map_controller.gd`
- `<lessismore-clone>/tools/qa_v497_run_summary_integration_smoke.gd`
- `<lessismore-clone>/tools/qa_v497_run_summary_integration_smoke.gd.uid`

The binding reuses the existing disabled `HpChip`, shell modal and
focus/interaction-lock behavior. No scene write is needed by default.

#### RandomHeroes

**Maker A — read-model projection**

- `<randomheroes-clone>/game/scripts/ui/hero_summary_read_model.gd`
- `<randomheroes-clone>/game/scripts/ui/hero_summary_read_model.gd.uid`
- `<randomheroes-clone>/game/tests/v497_hero_summary_read_model_smoke.gd`
- `<randomheroes-clone>/game/tests/v497_hero_summary_read_model_smoke.gd.uid`

**Maker B — presentation and interaction**

- `<randomheroes-clone>/game/scripts/ui/hero_summary_panel.gd`
- `<randomheroes-clone>/game/scripts/ui/hero_summary_panel.gd.uid`
- `<randomheroes-clone>/game/scenes/hero_summary_panel.tscn`

**Integration/build owner**

- `<randomheroes-clone>/game/scripts/ui/button_deck_controller.gd`
- `<randomheroes-clone>/game/tests/v497_hero_summary_integration_smoke.gd`
- `<randomheroes-clone>/game/tests/v497_hero_summary_integration_smoke.gd.uid`

The binding replaces only the existing Hero-button print placeholder and uses
`Character.get_frontend_status_summary()` plus the existing GameManager/HUD
snapshot. It does not activate Bag, Collection or Build placeholders.

**Independent focused QA — both projects**

- product-source write set: empty;
- reads the integrated allowlist and maker-authored smoke inputs; and
- writes only source-linked Evidence under an external qualification artifact
  root selected later.

### 3.3 Dependencies

- exact source commit/tree and dedicated tracked-only clone;
- project-local repository/GameString display-name resolution;
- deep-copy/allowlist adapter with no setter or live collection alias;
- existing modal/focus entry on LessIsMore and Hero-button entry on
  RandomHeroes;
- exact Godot 4.4 executable identity; and
- isolated `user://`, evidence and build artifact roots.

### 3.4 Minimum tests

- before/open/refresh/close deep hash of gameplay state is identical;
- projection contains only the declared allowlist and no ledger, token,
  pending operation or live collection alias;
- missing character, empty collections, no active region and completed/failed
  run states remain truthful;
- display names use project localization rather than raw IDs;
- unavailable or transaction-active states deny opening rather than showing a
  half-committed snapshot;
- close and cancel restore prior focus and interaction exactly;
- three LessIsMore locales and RandomHeroes' admitted locale set fit without
  clipping;
- exact-project parse/startup, first-project development export/launch and
  Human observation; and
- QA verifies source HEAD/tree/status and isolated user-data state before and
  after execution.

### 3.5 Adaptability and primary failure modes

**LessIsMore fit: high.** It already has an allowlisted run profile, copied
session snapshots, a disabled HP entry and a reusable shell overlay.

**RandomHeroes fit: high.** It already has `get_frontend_status_summary()`,
HUD snapshots and a Hero-button placeholder intended for a panel.

Primary failures are live dictionary aliases, stale/raw localized values,
internal ledger disclosure, hidden mutation, modal stacking, focus loss,
reading half-committed state and scope expansion into inventory/build editing.

## 4. Candidate 2 — Committed Progress / Milestone Notice Toast

### 4.1 Neutral outcome

Convert an already committed project progression event into one non-blocking,
deduplicated, localized notice. The feature observes state; it does not advance
progress, acknowledge a blocking milestone, unlock content, save state or
change numerical outcomes.

The neutral payload is limited to event identity/dedupe key, kind, subject
reference, committed progress counts and run epoch. Project adapters resolve
visible text.

### 4.2 Lanes and preliminary write sets

#### LessIsMore

**Maker A — committed-state contract**

- `<lessismore-clone>/scripts/map/run_progress_notice_contract.gd`
- `<lessismore-clone>/scripts/map/run_progress_notice_contract.gd.uid`
- `<lessismore-clone>/tools/qa_v497_run_progress_notice_contract_smoke.gd`
- `<lessismore-clone>/tools/qa_v497_run_progress_notice_contract_smoke.gd.uid`

**Maker B — queue/presentation**

- `<lessismore-clone>/scripts/ui/shared/run_progress_toast.gd`
- `<lessismore-clone>/scripts/ui/shared/run_progress_toast.gd.uid`
- `<lessismore-clone>/scenes/ui/shared/run_progress_toast.tscn`
- `<lessismore-clone>/tools/qa_v497_run_progress_toast_presenter_smoke.gd`
- `<lessismore-clone>/tools/qa_v497_run_progress_toast_presenter_smoke.gd.uid`

**Integration/build owner**

- `<lessismore-clone>/scripts/map/world_map_controller.gd`
- `<lessismore-clone>/scripts/ui/ui_shell_root.gd`
- `<lessismore-clone>/tools/qa_v497_run_progress_toast_integration_smoke.gd`
- `<lessismore-clone>/tools/qa_v497_run_progress_toast_integration_smoke.gd.uid`

Only normal region-node resolution after
`region_run_session.complete_active_node(...)` is admitted. Boss prepare,
failed/replayed work and the existing blocking region-clear acknowledgement
are excluded.

#### RandomHeroes

**Maker A — existing-signal adapter**

- `<randomheroes-clone>/game/scripts/progress_notice_model.gd`
- `<randomheroes-clone>/game/scripts/progress_notice_model.gd.uid`
- `<randomheroes-clone>/game/tests/v497_progress_notice_model_smoke.gd`
- `<randomheroes-clone>/game/tests/v497_progress_notice_model_smoke.gd.uid`

**Maker B — queue/presentation**

- `<randomheroes-clone>/game/scripts/ui/progress_notice_controller.gd`
- `<randomheroes-clone>/game/scripts/ui/progress_notice_controller.gd.uid`
- `<randomheroes-clone>/game/scenes/progress_notice.tscn`

**Integration/build owner**

- `<randomheroes-clone>/game/scripts/main_init.gd`
- `<randomheroes-clone>/game/tests/v497_progress_notice_integration_smoke.gd`
- `<randomheroes-clone>/game/tests/v497_progress_notice_integration_smoke.gd.uid`

The adapter consumes the existing `chapter_phase_changed_relayed`,
`region_boss_warning_relayed` and `chapter_cleared_relayed` signals. It does
not modify `map_progress.gd` or progression/persistence behavior.

**Independent focused QA — both projects**

- product-source write set: empty;
- observes queue, input, focus, z-order and committed-source identity; and
- writes only external Evidence.

### 4.3 Dependencies

- a single exact post-commit source in each Project Binding;
- stable event/dedupe identity and run-reset epoch;
- project GameString lookup without hard-coded visible text;
- non-blocking overlay layer with explicit suppression behind blocking UI;
- exact Godot/build and isolated runtime roots.

### 4.4 Minimum tests

- prepared, failed, unchanged and replayed events emit zero notices;
- one new committed event emits exactly one notice;
- replay of the same dedupe key remains exactly one;
- new run/reset clears prior queue and dedupe state;
- ordering and timeout remain deterministic;
- the notice never grabs focus, intercepts pointer input or blocks
  spin/map/battle controls;
- blocking milestone, exit decision or modal suppresses/queues rather than
  being covered by the notice;
- locale refresh and target viewport constraints remain readable;
- exact parse/startup, first-project development export/launch and Human
  observation; and
- source and isolated user-data identity are unchanged outside admitted
  outputs.

### 4.5 Adaptability and primary failure modes

**LessIsMore fit: medium-high.** It already has `show_toast` and exact commit
points, but also has a blocking boss/region milestone. The candidate is valid
only if it does not duplicate or bypass that lifecycle.

**RandomHeroes fit: high and product-relevant.** The three relay signals are
already present, and source comments explicitly reserve HUD/Toast integration.

Primary failures are pre-commit emission, duplicate replay, stale queue after
reset, z-order over a blocking modal, focus/input interception, raw IDs,
hard-coded localization and accidental progression/persistence scope growth.

## 5. Candidate 3 — Pause-aware Help / Controls Overlay

### 5.1 Neutral outcome

Open a localized, read-only controls/help view under one explicit pause
lifecycle. Cancel returns to the pause root before a second cancel resumes.
The view must not mutate gameplay, settings drafts, save data or exit state.

### 5.2 Lanes and preliminary write sets

#### LessIsMore

**Maker A — help/action contract and localization formal chain**

- `<lessismore-clone>/scripts/ui/pause/help_overlay_view_model.gd`
- `<lessismore-clone>/scripts/ui/pause/help_overlay_view_model.gd.uid`
- `<lessismore-clone>/RawData/GameString.xlsx`
- `<lessismore-clone>/data/game_strings/game_strings.tres`
- `<lessismore-clone>/data/generated/rawdata_import_report.json`
- `<lessismore-clone>/tools/qa_v497_pause_help_contract_smoke.gd`
- `<lessismore-clone>/tools/qa_v497_pause_help_contract_smoke.gd.uid`

**Maker B — presentation**

- `<lessismore-clone>/scripts/ui/pause/help_panel.gd`
- `<lessismore-clone>/scripts/ui/pause/help_panel.gd.uid`
- `<lessismore-clone>/scenes/ui/pause/help_panel.tscn`
- `<lessismore-clone>/tools/qa_v497_pause_help_presenter_smoke.gd`
- `<lessismore-clone>/tools/qa_v497_pause_help_presenter_smoke.gd.uid`

**Integration/build owner**

- `<lessismore-clone>/scripts/ui/pause/pause_menu_panel.gd`
- `<lessismore-clone>/scripts/ui/pause/pause_menu_layer.gd`
- `<lessismore-clone>/tools/qa_v497_pause_help_integration_smoke.gd`
- `<lessismore-clone>/tools/qa_v497_pause_help_integration_smoke.gd.uid`

#### RandomHeroes

**Maker A — pause/help lifecycle and localization**

- `<randomheroes-clone>/game/scripts/ui/pause_help_lifecycle.gd`
- `<randomheroes-clone>/game/scripts/ui/pause_help_lifecycle.gd.uid`
- `<randomheroes-clone>/game/data/xlsx/gamestring.xlsx`
- `<randomheroes-clone>/game/data/gamestring.json`
- `<randomheroes-clone>/game/tests/v497_pause_help_lifecycle_smoke.gd`
- `<randomheroes-clone>/game/tests/v497_pause_help_lifecycle_smoke.gd.uid`

**Maker B — presentation**

- `<randomheroes-clone>/game/scripts/ui/help_overlay_controller.gd`
- `<randomheroes-clone>/game/scripts/ui/help_overlay_controller.gd.uid`
- `<randomheroes-clone>/game/scenes/help_overlay.tscn`

**Integration/build owner**

- `<randomheroes-clone>/game/scripts/main_init.gd`
- `<randomheroes-clone>/game/scenes/main.tscn`
- `<randomheroes-clone>/game/tests/v497_pause_help_integration_smoke.gd`
- `<randomheroes-clone>/game/tests/v497_pause_help_integration_smoke.gd.uid`

**Independent focused QA — both projects**

- product-source write set: empty;
- validates lifecycle, focus/input and localization formal-chain outputs; and
- writes only external Evidence.

### 5.3 Dependencies

- project-defined canonical action set and localization pipeline;
- overlay process mode that remains active while project runtime is paused;
- explicit pause ownership, cancel routing and prior-focus restoration;
- assurance that current reels/timers/battle do not partially continue;
- isolated `user://`, because existing settings/save paths can otherwise be
  shared across clones.

### 5.4 Minimum tests

- entering Help never unpauses or advances runtime state;
- first cancel returns Help to pause root; second cancel alone resumes;
- focus cycle includes Help and returns to its entry point;
- settings-unsaved and exit-confirmation behavior is unchanged;
- no gameplay/settings/save/user-data mutation;
- displayed actions match InputMap/runtime bindings and have a truthful empty
  state when missing;
- admitted locales, long text, viewport resizing, keyboard/controller focus;
- exact parse/startup/build/launch and Human observation; and
- no input propagation into gameplay while Help is visible.

### 5.5 Adaptability and primary failure modes

**LessIsMore fit: high.** It already owns SceneTree pause, process-always UI,
cancel routing and focus restore.

**RandomHeroes fit: uncertain/medium.** No equivalent mature pause ownership
contract was found; reel, timer, battle and SaveData interactions would need a
new bounded lifecycle.

Primary failures are partial pause, overlay freezing itself, accidental resume,
input propagation, broken focus ring, bypassed settings/exit confirmation,
hard-coded physical keys, incomplete GameString formal-chain updates and
shared user-data pollution.

## 6. Comparison and recommendation

| Candidate | Concrete benefit | Cost / failure exposure | Cross-project fit |
| --- | --- | --- | --- |
| Read-only Hero/Run Summary | smallest mutation surface; clear before/after Human proof; existing entry and read APIs in both projects | stale/aliased projection and modal/focus risk | **high / high** |
| Committed Progress Toast | strongest existing RandomHeroes product gap; exercises event handoff, dedupe and non-blocking UI | LessIsMore lifecycle duplication and z-order risk | medium-high / **high** |
| Pause-aware Help | strongest interaction/focus lifecycle test | localization formal chain plus new RandomHeroes pause ownership | high / uncertain-medium |

Recommendation: select **Read-only Hero/Run Summary** for the first v4.97
qualification Pilot. It is necessary neither for qualification nor for either
project, but it gives the cleanest first proof of two independent maker
domains, exact write separation, read-only QA, integration/build and a
Human-observable result without changing gameplay outcomes.

If the Human values a stronger event/queue production test over minimum risk,
select **Committed Progress Toast** instead. Pause-aware Help should remain an
optional third choice until RandomHeroes pause ownership is separately bounded.

## 7. Decisions still reserved to the Human

No work beyond the Slice 0 baseline may infer these decisions:

1. selected feature: Summary, Toast, Help, or a Human-revised alternative;
2. admitted four lanes and the exact path allowlist for each project;
3. dedicated LessIsMore clone path derived from f62 and dedicated
   RandomHeroes clone path derived from 52e5;
4. whether RandomHeroes needs only exact-engine development startup or a new
   packaged-export preset;
5. first-project and second-project write permission, accepted separately; and
6. second Adapter: recommended Claude Code read/recovery-only, or a separately
   bounded Cursor path; neither receives project-write eligibility.

The list above records what was reserved when Slice 0 was first frozen. It is
superseded for this Pilot by the exact selection below; it remains useful as a
statement that no choice could be inferred before the Human response.

## 8. Human selection received 2026-08-29

The Human selected:

1. **Candidate 1 — Read-only Hero / Run Summary**;
2. Maker A, Maker B, independent focused QA and integration/build, with the
   exact Candidate 1 preliminary path allowlists in section 3;
3. `/Users/macsun/Documents/LessIsMore_v497_Qualification_Pilot`, derived from
   `f62d4fa7a7175962078bca097728d527b61b3666` /
   `5714d31f72917f2f717e18dfb73d1bafe47f17c2`;
4. `/Users/macsun/Documents/RandomHeroes_v497_Qualification_Pilot`, derived
   from `52e50087fa20cef85cb1de220986e1c2560b5e9c` /
   `8c2ef717e3210293edf91c56632c84311adb7784`;
5. exact-engine RandomHeroes startup only, with no new
   `game/export_presets.cfg` and no packaged export; and
6. WorkBuddy as the second Adapter, read/recovery-only and without project-write
   eligibility.

Both dedicated clones were created tracked-only on
`codex/v497-qualification-pilot`, were clean before feature work, and have
their push URL set to `/dev/null`. The original repositories remain read-only.

The selected WorkBuddy host candidate is `/Applications/WorkBuddy.app` version
5.3.14. Availability was inspected without launch or contact. Revision 3 still
requires separate Human approval of the named executable, sanitized input
scope and non-write invocation before external Adapter contact.

The exact machine-local scope record is
`.dev_os_meta/evidence/2026-08-29_v497_candidate1_pilot_admission.md`. This
selection admits ordinary implementation in the listed clone paths only. It
does not grant qualification, `L3/PC-3`, Pack/Adapter promotion, supported
adoption, release, push/tag or production/live authority.

### 8.1 Post-selection RandomHeroes binding discovery

Read-only inspection after selection found that the preliminary RandomHeroes
allowlist cannot yet satisfy its own four-lane contract without correction:
the repository ignores `.uid` files, Maker B has no focused-test path, and
exact selection/focus restoration plus localized copy cross paths not present
in the preliminary list. The machine-local evidence record is
`.dev_os_meta/evidence/2026-08-29_v497_randomheroes_candidate1_write_set_gap.md`.

This new target fact does not change the selected feature or LessIsMore scope.
It keeps RandomHeroes non-writing until the Human explicitly accepts the
smallest corrected allowlist or selects preview-only reuse. The system must not
silently widen the original selection.

### 8.2 LessIsMore export-resource scope successor received 2026-08-30

After the first runnable-result observation exposed zero Recovery Hub services
inside the exported PCK, the Human admitted exactly one additional
LessIsMore integration/build-owned path:

- `<lessismore-clone>/scripts/data/data_repository.gd`

The admitted operation is limited to changing
`DataRepository._load_resources()` from filesystem-oriented directory
enumeration to export-safe `ResourceLoader.list_directory()` enumeration.
The existing `.tres` resource filter, key extraction and data-ID indexing
semantics remain unchanged.

This successor authorization does not admit any export-preset change, any
other DataRepository behavior, any additional project path, or any
RandomHeroes write. It does not complete focused QA, development build, Human
observation, qualification, adoption, release, push/tag or production/live
authority. The earlier Project Bindings and evidence remain historical;
execution after this expansion requires a successor exact commit/tree,
Project Binding, Stage Authority Source and assembly lock.
