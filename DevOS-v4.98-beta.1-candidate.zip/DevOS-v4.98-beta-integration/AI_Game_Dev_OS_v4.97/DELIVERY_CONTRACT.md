# AI Game Dev OS v4.97 Development Delivery Contract

This file defines the delivery boundary for `AI_Game_Dev_OS_v4.97/`.

## Delivery Units

| Unit | Role | Included By Default |
| --- | --- | --- |
| `AI_Game_Dev_OS_v4.97/` | Active source tree and version payload root | Yes |
| `AI_Game_Dev_OS_v4.97/os_layer/` | inherited OS baseline plus v4.94 Runtime State additions and v4.97 verification surfaces | Yes |
| `AI_Game_Dev_OS_v4.97/pack_layer/` | inherited v4.93 production pack overlay, delivery harness, and bounded v4.97 development bindings | Yes |
| `AI_Game_Dev_OS_v4.97/production_runtime/` | Pre-choice non-writing Gate-local and consumer-derived-state contract baselines; not complete Assembly or a qualified runtime | Yes, for the exact manifest-enumerated paths |
| `AI_Game_Dev_OS_v4.97/adapters/` | AI IDE/runtime and v4.97 Production-foundation implementation contracts | Yes |
| `AI_Game_Dev_OS_v4.97/schemas/` | Root manifest, AI IDE, and v4.97 Production binding/receipt schemas | Yes |
| `AI_Game_Dev_OS_v4.97/packs/`, `scripts/`, `tests/` | Root compatibility mirrors for stable user commands | Yes, while compatibility paths remain active |
| target project `.ai_dev_os/` | Runtime bindings, run plans, traces, and local reports generated during a project run | No, project-owned state |
| explicit artifact root such as `target_project_artifacts/v493/` | Runtime evidence such as beta reports, Shared Truth indexes, architecture baselines, and QA/refactor evidence | No, unless the delivery explicitly targets project evidence |
| repository-root `.dev_os_meta/` | Workspace governance evidence and promotion working state | No |
| `AI_Game_Dev_OS_v4.97_Release/` | Release snapshot, if separately authorized and cut from the source tree | No, unless the delivery explicitly targets the release snapshot |

## Source Tree Delivery

When delivering the active source tree, include:

- root entry docs and manifest;
- root runtime instance contract;
- root real-project adoption contract;
- root mirror policy;
- root contract schemas;
- `os_layer/`;
- `pack_layer/`;
- the Slice 0 and accepted consumer-derived-state `production_runtime/` paths
  and contract schemas exactly enumerated by `MANIFEST.json`;
- `adapters/`;
- root compatibility mirrors;
- validation scripts and tests.

Do not include repository-root `.dev_os_meta/` as executable package content.
If reviewers need provenance, reference `.dev_os_meta/` paths in reports or
attach a separate governance appendix.

## Runtime Instance Delivery

Generated runtime state is not source tree content. `RUNTIME_INSTANCE_CONTRACT.md`
defines where Codex, WorkBuddy, Cursor, or another runtime adapter should place
project bindings, run plans, execution traces, reports, and adoption evidence.

For project evidence delivery, state:

- target project root;
- target project `.ai_dev_os/` path, when included;
- artifact root path, when included;
- generated reports and traces;
- validation commands and results.

Do not write project-specific runtime instances into canonical `os_layer/`,
`pack_layer/`, `production_runtime/`, root docs, adapters, schemas, agents, or
skills. `production_runtime/` contains package-owned contracts/fixtures, not
project-owned run state.

## Release Snapshot Delivery

`AI_Game_Dev_OS_v4.97_Release/` is a snapshot target, not the live editing
surface. A release snapshot is valid only after it is regenerated from the
current source tree and revalidated.

Release snapshot delivery must state:

- source tree commit or diff base;
- snapshot path;
- whether root compatibility mirrors are included;
- whether a separate governance appendix is attached;
- validation commands and results.

Do not imply the release snapshot contains source-tree documentation changes
until it has been explicitly refreshed.

Check the current snapshot status with:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_release_snapshot_freshness.py --strict
```

Use `--strict` only when the delivery explicitly targets
`AI_Game_Dev_OS_v4.97_Release/`.

## Transient Files

Test runs may create `__pycache__/`, `.pytest_cache/`, `.pyc`, `.pyo`, and
`.DS_Store` files. These are local execution artifacts and must not enter a
delivery payload.

Diagnose them with:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_delivery_transients.py --strict
```

Use `--strict` only when preparing an actual delivery payload.

## Mirror Sync Rule

The root compatibility paths must mirror `pack_layer/` for the current pack
surfaces:

- `packs/game_system_packs/end_to_end_production/`
- `scripts/delivery/`
- `tests/delivery/`

Validate this with:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_pack_layer_mirror.py
```

Generated exploratory output such as
`tests/delivery/fixtures/gdd_formal_output_tests/` is excluded unless it is
intentionally promoted as a regression fixture.

`ROOT_MIRROR_POLICY.md` records the active decision: root mirrors remain stable
public compatibility surfaces for v4.93, and divergence from `pack_layer/` is a
validation error while that policy is active.

## `.dev_os_meta` Rule

`.dev_os_meta/` is workspace governance state. It may contain Problem/Fix cards,
memory route decisions, intake reviews, and promotion proposals. Those files can
explain why a change was made, but they do not become runtime dependencies.

Promotion boundary:

- accepted OS behavior must be promoted into `os_layer/`;
- accepted production-pack behavior must be promoted into `pack_layer/` and
  mirrored into root compatibility paths while those paths exist;
- unpromoted governance evidence remains outside the version payload.

## Layer Document Rule

v4.97 entrypoints, changelog, release notes, module catalog, invocation rules,
and delivery rules live at the `AI_Game_Dev_OS_v4.97/` root.

Layer-local README files are pointers or layer-scope notes. Layer-local
`CHANGELOG.md` and `RELEASE_NOTES*.md` files may remain only as inherited OS
baseline provenance, and must not be treated as v4.97 release notes.

## Required Verification

Run these before claiming the source tree delivery is coherent:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_markdown_local_paths.py
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_pack_layer_mirror.py
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_delivery_transients.py --strict
python3 -m pytest AI_Game_Dev_OS_v4.97/tests/delivery/test_v493_end_to_end_skill_contracts.py -q --tb=short
python3 -m pytest AI_Game_Dev_OS_v4.97/pack_layer/tests/delivery/test_v493_end_to_end_skill_contracts.py -q --tb=short
python3 -m pytest AI_Game_Dev_OS_v4.97/os_layer/tests/test_v493_layer_boundary_docs.py -q --tb=short
git diff --check -- AI_Game_Dev_OS_v4.97
```

Run release-snapshot freshness with `--strict` only after separate release work
is authorized and `AI_Game_Dev_OS_v4.97_Release/` is the selected delivery
target. It is not part of this development identity refresh.
