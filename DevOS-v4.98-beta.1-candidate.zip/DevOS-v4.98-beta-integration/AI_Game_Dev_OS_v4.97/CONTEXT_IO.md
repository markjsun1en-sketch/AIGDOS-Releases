# Bounded Context Reads and Writes

This is the root invocation guide for a v4.97 development-source capability.
Its presence does not release the package or rebind an existing project.
Projects adopt it explicitly through their adapter and context configuration.

## Ownership and limits

The OS supplies a reader, structured writer, and default policy. The project
owns paths, budgets, current task state, evidence, blockers, and Human pauses.
The tools require an explicit existing `--repo-root`; the writer rejects a
project root inside this canonical OS package. Generated project state stays
outside the package. A configured path is not authorization to write it.

Canonical implementation is `os_layer/tools/runtime/`; these are OS tools,
not production-pack scripts requiring root/pack-layer mirrors. This guide
is the public root route; no parallel wrapper or evidence store is added.

The default policy is [context_io_policy.json](os_layer/runtime/config/context_io_policy.json).
A project may supply the complete same-schema file at
`runtime/config/context_io_policy.json`. An invalid override fails rather
than silently falling back. Responses identify the selected policy and hash.
Paths and budgets are configurable; defaults are:

| Operation | Default | Limit / behavior |
| --- | --- | --- |
| Heading or literal-query index | 12 entries | Up to 20 per page; short snippets |
| Source excerpt | 4,000 characters | Up to 16,000; explicit continuation cursor |
| Log delta | 800 characters | Reject oversize; never silently truncate |
| Current task summary | 4,000 characters | Reject oversize; never silently truncate |
| Necessary write exception | Explicit reason | Up to 3 times the configured budget |
| Hot-log size warning | 10,000 characters | Advisory; no automatic archive |

Budgets count Unicode characters, not model tokens. They bound returned source
content or rendered entries; JSON metadata adds overhead. Disk size alone does
not measure model input cost. The reader still accesses the source locally,
and the writer scans configured logs locally for duplicate markers.

## Read route

Run these commands from the version package root, replacing example paths:

```sh
python3 os_layer/tools/runtime/read_context_window.py --repo-root /path/to/project --audit
python3 os_layer/tools/runtime/read_context_window.py logs/orchestrator_log.md --repo-root /path/to/project --query TASK-EXAMPLE
python3 os_layer/tools/runtime/read_context_window.py logs/orchestrator_log.md --repo-root /path/to/project --start-line 20 --max-chars 4000
```

Without a query or start line, a file read returns a heading index. Index
pagination uses `--offset`; source continuation uses the returned line and
character positions with `--start-line` and `--start-char`. Use
`--expect-sha256` with the previous response's source hash to reject stale
positions, including continuation inside a very long line.

Read mandatory project instructions and the current task summary first. Use
indexes to locate needed historical evidence, then fetch bounded excerpts.
Path lists in cold-start packs are navigation, not instructions to dump every
file. A snippet or no-match result does not establish current state or the
absence of blockers. Retrieve enough context to resolve ambiguities and
preserve applicable instructions even when that requires several excerpts.

## Write route

Keep one current-state entry per task in the project's existing task system or
summary. Do not add a parallel summary if the task system already supplies it.
Keep scope/acceptance decisions in the task and test details beside their
original results. Update current state for meaningful progress, a blocker,
changed next action or a real handoff; no update is needed for unchanged polls.

Indexes are navigation, not extra progress logs. Coordination logs record
cross-task decisions; role logs retain reusable role-specific conclusions.
Neither needs a copy of every task update. A handoff can link to the current
entry when it already contains the information needed by the recipient.
Closure belongs in the existing task unless a selected delivery contract
requires a separate artifact. Do not create a report solely to prove that
another log or summary was checked.

The writer accepts exactly these JSON keys for a log entry:

```json
{
  "task_id": "TASK-EXAMPLE",
  "date": "2026-10-07",
  "status": "verification_pending",
  "change": "Implemented the scoped behavior; focused checks passed.",
  "blockers": ["Human playtest remains pending."],
  "boundaries": ["Respect the project's existing pause boundary."],
  "next_step": "Collect the authorized playtest result.",
  "evidence": ["tasks/specs/TASK-EXAMPLE.md"]
}
```

Evidence paths must name existing files in the target project. Replace the
example with real results and boundaries. Save the input JSON outside the
canonical package. Preview, inspect the rendered delta, then apply using
`before_sha256` from the preview:

```sh
python3 os_layer/tools/runtime/write_context_entry.py logs/orchestrator_log.md --repo-root /path/to/project --input /tmp/context-entry.json
python3 os_layer/tools/runtime/write_context_entry.py logs/orchestrator_log.md --repo-root /path/to/project --input /tmp/context-entry.json --apply --expect-sha256 PREVIEW_HASH
```

Preview is a mechanical step, not a new human-approval gate. Continue within
existing authorization. The supported append targets are existing
`logs/orchestrator_log.md`, `logs/open_issues.md`, and `logs/agents/*.md`.
Custom layouts use the policy's path allowlist. These are available destinations,
not a list to write to after every task. Preview/apply remains the writer's
mechanical concurrency protocol, not an additional review or approval workflow.

For a current summary, add `objective` and `owner` strings and a `proven` list
to the JSON, use `--mode summary`, and target
`tasks/summaries/TASK-EXAMPLE_current_summary.md`. For a new file the expected
hash is `ABSENT`. Existing unstructured summaries are protected: migrate
them deliberately under their normal ownership rules before using this
writer. Structured summaries retain task identity. Removing or rewording
blockers/boundaries requires `--resolution-note` with the reason and evidence;
the tool checks the presence of the note, not the truth or authority of it.

If a necessary boundary cannot fit, use `--budget-exception REASON`. Never
omit a pending blocker or pause merely to meet a budget. Exceptions remain
bounded by policy. Detailed evidence stays in its existing source; register
or promote it through the existing Evidence/Memory workflow when applicable.
Writing a summary does not itself promote evidence or memory.

Duplicate suppression is exact structured-payload matching, ignoring date,
across configured logs; it is not semantic deduplication. Append preserves
the existing prefix. Apply checks the expected file hash and serializes
cooperating writers with a POSIX advisory lock; summary replacement is atomic.
Arbitrary editors do not participate in that lock and still need coordination.
Read/preview do not require POSIX locking; apply fails before writing when
that backend is unavailable. This is not a universal filesystem interceptor.

## Cold-start integration

```sh
python3 os_layer/tools/runtime/boot_agent_thread.py --repo-root /path/to/project --agent AGENT_ID --context-io
```

The target must already have the normal boot prerequisites. The optional
`--context-io` flag adds navigation, policy budgets, and tool paths to all
three cold-start profiles. Existing default `cold_start_pack.v1` output is
unchanged; consumers opting in must accept the additive `context_io` field.
The boot wrapper's dry-run remains a routing preview, without generating the
pack. This flag does not migrate files or enable writing automatically.

## Validation

```sh
python3 -B -m pytest -p no:cacheprovider os_layer/tests/test_context_io_read.py os_layer/tests/test_context_io_write.py os_layer/tests/test_context_io_policy.py os_layer/tests/test_cold_start_pack.py os_layer/tests/test_boot_agent_thread.py os_layer/tests/test_sprint_context_rollup.py -q
```

Tests cover configurable project layouts and budgets, lossless excerpts,
stale hashes, concurrent cooperating writers, duplicate entries, preserved
boundaries, path rejection, unsupported locking, and compatible boot output.
They are development regression evidence, not measured token savings or
proof that an external adapter has adopted this route.
