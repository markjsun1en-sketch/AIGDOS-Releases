# AI Game Dev OS v4.93 Restructuring Plan (Historical)

Status: inherited planning record. It explains the split-layer work that formed
the current baseline, but its v4.93 command paths are not the active v4.95
command source. Use `MANIFEST.json`, `INDEX.md`, and
`V495_DEVELOPMENT_STATUS.md` for the current development line.

This plan records the intended software-engineering restructuring path for
`AI_Game_Dev_OS_v4.93/`. It is based on the current v4.93 source tree after the
OS/Pack split and root-first documentation cleanup.

The plan is deliberately not an implementation step. It defines the target
architecture, current gaps, phased work, validation gates, and non-goals before
any further directory moves or adapter scaffolding.

## Current Baseline

Current v4.93 already has these structural facts:

- root files own the public entrypoint, module catalog, invocation guidance,
  delivery rules, and AI IDE bootstrap;
- `os_layer/` carries the inherited v4.92 OS baseline plus promoted v4.93
  OS-layer additions;
- `pack_layer/` carries the v4.93 production pack overlay, agents, skills,
  workflow, schemas, delivery scripts, and tests;
- `adapters/` now carries a shared AI IDE adapter base plus initial Codex,
  Cursor, and WorkBuddy private adapter contracts;
- `RUNTIME_INSTANCE_CONTRACT.md` now separates canonical v4.93 definitions
  from target-project runtime state and artifact evidence;
- `REAL_PROJECT_ADOPTION_CONTRACT.md` now defines the evidence gate for real
  project adoption and lifecycle promotion;
- root `packs/`, `scripts/`, and `tests/` remain stable compatibility mirrors
  under `ROOT_MIRROR_POLICY.md`;
- repository-root `.dev_os_meta/` remains governance state outside the version
  payload;
- layer-local README files are pointers or layer-scope notes;
- layer-local `CHANGELOG.md` and `RELEASE_NOTES*.md` are allowed only as
  inherited historical OS baseline provenance.

The current lifecycle posture remains `draft` / beta-candidate scaffold until
real-project adoption evidence passes review.

## Target Architecture

The target engineering shape is:

```text
AI_Game_Dev_OS_v4.93/
  root public API
  os_layer/       # inherited OS core and promoted OS additions
  pack_layer/     # production capability implementation
  adapters/       # first-class Codex/Cursor/WorkBuddy integration contracts
  packs/          # compatibility mirror or deprecated public surface
  scripts/        # compatibility mirror or deprecated public surface
  tests/          # compatibility mirror or deprecated public surface

target_project/
  .ai_dev_os/     # runtime instance state, bindings, traces, reports

repository-root .dev_os_meta/
  governance evidence and promotion working state
```

The architectural rule is:

```text
Root = public API / AI IDE entrypoint
os_layer = inherited OS core
pack_layer = production capability implementation
adapters = runtime integration contracts
target project = runtime instances and evidence
.dev_os_meta = governance memory, not package content
```

## Desired Directory Responsibilities

| Area | Responsibility | Should Not Own |
| --- | --- | --- |
| Root | v4.93 entrypoint, module catalog, invocation contract, delivery contract, changelog, release notes, manifest, user manual | Layer implementation details beyond routing pointers |
| `os_layer/` | v4.92 OS baseline, Orchestrator, protocols, LTM, runtime, FixOps foundation, promoted OS additions | v4.93 public onboarding, pack workflow, v4.93 release notes |
| `pack_layer/` | Canonical production pack agents, skills, workflow definitions, schemas, delivery scripts, pack tests | Whole-version entrypoint, OS governance, runtime instance outputs |
| `adapters/` | Codex/Cursor/WorkBuddy policy, invocation profile, runtime adapter contract, example bindings | Canonical pack agents or generated project evidence |
| Root mirrors | Stable compatibility commands or deprecated aliases | Silent long-term divergence from `pack_layer/` |
| Target project `.ai_dev_os/` | Runtime bindings, run plans, traces, reports | Canonical v4.93 definitions |
| `.dev_os_meta/` | Problem/Fix/Pattern/Self-Evo governance and promotion evidence | Runtime package dependency |

## Current Gaps Against Target

| Gap | Current State | Risk |
| --- | --- | --- |
| Adapter layer early draft | `adapters/` exists with shared AI IDE rules and initial Codex/Cursor/WorkBuddy contracts, but has not yet been exercised on a real target project | Adapter stop conditions and evidence routing may need refinement after first adoption run |
| Runtime instance contract not exercised | `RUNTIME_INSTANCE_CONTRACT.md` defines target-project `.ai_dev_os/` and artifact-root placement, but has not yet been exercised on a real project | First adoption run may reveal missing required files or evidence routing details |
| Root mirrors require continued sync | `ROOT_MIRROR_POLICY.md` keeps `packs/`, `scripts/`, and `tests/` as stable public compatibility mirrors | Divergence remains possible if mirror validation is skipped |
| Release snapshot requires future refresh when source changes | `AI_Game_Dev_OS_v4.93_Release/` has been refreshed from the current source tree | Future source edits can make the snapshot stale again unless strict freshness is rerun |
| Real-project adoption awaiting target inputs | `REAL_PROJECT_ADOPTION_CONTRACT.md` defines required evidence, but no real target project root and runtime-produced trace have been supplied | Lifecycle must remain `draft` |
| `.dev_os_meta` delivery appendix not packaged | Governance evidence is referenced, not delivered as a formal appendix | Reviewers may need a separate evidence bundle |

## Phase Plan

### Phase A: Root Authority Lockdown

Status: mostly complete.

Work:

- keep root files as the only v4.93 public entrypoint;
- keep layer README files as pointers or layer-scope notes;
- keep v4.93 changelog and release-note authority at root;
- keep `MODULES_AND_INVOCATION.md` as the module and invocation contract;
- keep `DELIVERY_CONTRACT.md` as the payload and governance boundary.

Acceptance:

- markdown path checks pass;
- root/pack contract tests pass;
- OS layer boundary tests pass;
- no layer-local v4.93 changelog or release-note authority exists.

### Phase B: Codex Adapter Contract

Status: complete as initial contract.

Create a first-class adapter surface:

```text
adapters/
  README.md
  AI_IDE_ADAPTER_BASE.md
adapters/codex/
  codex_integration_policy.json
  codex_invocation_profile.json
  codex_runtime_adapter_contract.md
  examples/
adapters/cursor/
  cursor_integration_policy.json
  cursor_invocation_profile.json
  cursor_runtime_adapter_contract.md
adapters/workbuddy_private/
  workbuddy_private_integration_policy.json
  workbuddy_private_invocation_profile.json
  workbuddy_private_runtime_adapter_contract.md
```

Each adapter should define:

- read order;
- selected module and owner resolution;
- allowed write policy;
- forbidden write policy;
- required evidence by goal class;
- stop conditions;
- validation command matrix;
- run-plan expectations;
- execution-trace expectations;
- target-project `.ai_dev_os/` output policy.

Acceptance:

- root manifest includes `adapters/AI_IDE_ADAPTER_BASE.md`,
  `adapters/codex/`, `adapters/cursor/`, and
  `adapters/workbuddy_private/` as adapter surfaces;
- adapter docs do not duplicate canonical agents, skills, or workflows;
- tests verify the adapter references root contracts, Orchestrator, pack
  manifest, and runtime adapter spec;
- repository Python scripts remain validators/planners, not automatic LLM
  routers.

Remaining follow-up:

- exercise the adapter against a real target project;
- refine stop conditions and evidence routing from the first blocked/pass run;
- decide whether Cursor and WorkBuddy need additional project-binding examples
  after the first real runtime run.

### Phase C: Runtime Instance Contract

Status: complete as initial contract.

Define where generated outputs live for a target project:

```text
target_project/
  .ai_dev_os/
    capability_bindings.json
    codex_runtime_profile.json
    agent_run_plan.json
    agent_execution_trace.json
    reports/

target_project_artifacts/
  v493/
    beta_readiness_report.json
    shared_truth_index.json
    architecture_baseline.json
    refactor_evidence/
```

Acceptance:

- generated run plans, traces, beta reports, Shared Truth indexes, and
  architecture baselines are described as runtime instances, not canonical pack
  definitions;
- validators can inspect those outputs without writing to project internals
  unless an explicit output path is passed;
- sample fixtures remain regression evidence only.

Remaining follow-up:

- exercise the contract on a real target project;
- refine required runtime instance files after the first blocked/pass run;
- decide whether additional adapter examples should be added for Cursor and
  WorkBuddy.

### Phase D: Root Mirror Decision

Status: complete as active compatibility policy.

Decision:

Keep root `packs/`, `scripts/`, and `tests/` as stable public compatibility
surfaces for v4.93, with mirror validation as a source-tree and release gate.
`pack_layer/` remains the production implementation layer. Root commands remain
the stable public commands for users and AI IDEs.

Acceptance:

- `validate_pack_layer_mirror.py` remains green while mirrors exist;
- `CLI_COMMAND_MATRIX.md` documents canonical commands and compatibility
  aliases;
- no root/pack script behavior diverges silently.

Remaining follow-up:

- keep `CLI_COMMAND_MATRIX.md` aligned whenever commands change;
- revisit deprecation only through an explicit future migration plan;
- keep mirror validation in required verification while root mirrors exist.

### Phase E: Release Snapshot Refresh

Status: complete for the current source tree.

Work:

- regenerated `AI_Game_Dev_OS_v4.93_Release/` from the current source tree;
- excluded transient files and generated exploratory GDD fixture output;
- kept `.dev_os_meta/` outside runtime payload;
- ran strict snapshot freshness before release claims.

Acceptance:

```bash
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/validate_release_snapshot_freshness.py --strict
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/validate_delivery_transients.py --strict
```

Remaining follow-up:

- rerun the refresh and strict freshness check after any source-tree change that
  should be included in the release snapshot;
- attach `.dev_os_meta/` only as a separate governance appendix if requested.

### Phase F: Real-Project Adoption And Lifecycle Promotion

Status: blocked pending real-project inputs.

Work:

- root adoption contract is defined in `REAL_PROJECT_ADOPTION_CONTRACT.md`;
- next required input is a real project root, artifact root, capability
  bindings, and runtime-produced `agent_execution_trace.json`;
- after inputs exist, run beta readiness evaluator against the real project;
- replace sample refactor/write-back/evidence instances with real project
  evidence;
- review blockers, warnings, remediation items, and promotion evidence.

Acceptance:

- generated beta readiness report has `verdict: "PASS"`;
- `beta_promotion_allowed: true`;
- `promotion_blockers` is empty;
- lifecycle promotion remains a manual manifest update after review.

## Non-Goals

- Do not move canonical agents or skills into `adapters/`.
- Do not put v4.93 changelog or release notes inside `os_layer/` or
  `pack_layer/`.
- Do not make Python scripts call LLM agents automatically.
- Do not make `.dev_os_meta/` a runtime package dependency.
- Do not promote `lifecycle_status` from `draft` with fixture-only evidence.
- Do not refresh or delete the release snapshot without an explicit delivery
  step.

## Required Verification For Plan Updates

Run these after editing this plan:

```bash
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/validate_markdown_local_paths.py
python3 AI_Game_Dev_OS_v4.93/pack_layer/scripts/delivery/validate_markdown_local_paths.py
python3 -m pytest AI_Game_Dev_OS_v4.93/tests/delivery/test_v493_end_to_end_skill_contracts.py -q --tb=short -k "docs_path or manifest"
python3 -m pytest AI_Game_Dev_OS_v4.93/pack_layer/tests/delivery/test_v493_end_to_end_skill_contracts.py -q --tb=short -k "docs_path or manifest"
git diff --check -- AI_Game_Dev_OS_v4.93
```
