# v4.96 Package Identity Reconciliation

Status: bounded development-package identity refresh; not qualification, Gate,
Production Pack promotion, supported adoption, release acceptance, or
production/live authority.

## Comparison Boundary

The reproducible package-root comparison is:

```text
v4.95 baseline commit:        66c1371d6f547d3445dc200c5f80d5361a3c51f9
v4.95 baseline package tree:  dcba13fe82bab8a5b2b414fd1ef9b783b1b420ba
v4.96 first commit:           b867c49e1fc913e6fb65a88ceb48754bd5f4418e
identity-refresh preimage:    90f48303255a682429bc4a0566d2153ebb31ae6d
v4.96 preimage package tree:  ad6195a1a0476a9e146e0f5902bcbedbbe7d837a
```

The trees are compared as package roots, not by their different directory
names:

```bash
git diff --no-renames --name-status \
  66c1371d6f547d3445dc200c5f80d5361a3c51f9:AI_Game_Dev_OS_v4.95 \
  90f48303255a682429bc4a0566d2153ebb31ae6d:AI_Game_Dev_OS_v4.96
```

This report and the identity-refresh edits are intentionally outside that
preimage. The inventory remains reproducible after the refresh.

## Exact Preimage Inventory

The frozen v4.95 package contains 2,417 tracked files. The v4.96 preimage
contains 2,463 tracked files:

- 46 paths are added by v4.96 development;
- 13 inherited paths have bounded v4.96 modifications;
- no inherited path is deleted or renamed.

| Package area | Added | Modified | Meaning |
| --- | ---: | ---: | --- |
| root | 0 | 1 | v4.96 capability navigation added to the inherited index |
| `adapters/` | 18 | 5 | multi-lane runtime, Godot lane backends, Evidence/Memory lifecycle, permission-aware retrieval, compatibility migration, and Team Memory |
| `bin/` | 1 | 0 | package-local `ai-dev-os` CLI entrypoint |
| `os_layer/` | 11 | 6 | focused runtime and CLI tests plus Team Memory status command routing |
| `schemas/` | 15 | 0 | lane, recovery, lifecycle, permissions, migration, retrieval, Team Memory, and status contracts |
| `scripts/` | 1 | 1 | Godot multi-lane profile runner and stricter build source identity |
| **total** | **46** | **13** | **59 paths differ from v4.95** |

The changed surface is the bounded v4.96 line described in
`V496_DEVELOPMENT_STATUS.md`. It implements one exact Godot local-development
profile and one LessIsMore Pilot; it does not establish a second engine,
cross-host support, all-domain production, or autonomous semantic merge.

## Manifest Finding

At the identity-refresh preimage, the v4.96 directory still contained the
v4.95 root manifest, schema constraints, root documentation identity, command
paths, and mirrored static assertions. Most of those files were byte-identical
to the frozen v4.95 package. The directory name and implemented v4.96 surfaces
therefore disagreed with the package's declared current identity.

Changing only `version_id` would remain false identity because the root schema,
entrypoints, command roots, capability inventory, provenance boundary, and
tests would still disagree.

## Reconciliation Decision

The v4.96 development package identity is the whole
`AI_Game_Dev_OS_v4.96/` source tree. The bounded refresh therefore updates:

1. the root manifest and its direct schema;
2. current root entry documents and command paths;
3. the Codex/multi-lane/Evidence/Memory capability inventory;
4. mirrored static assertions that validate current root identity; and
5. the v4.96 changelog and development status.

The refresh deliberately preserves:

- the frozen v4.95 baseline commit and package-tree identity above;
- `V495_DEVELOPMENT_STATUS.md` and
  `V495_PACKAGE_IDENTITY_RECONCILIATION.md` as historical records;
- v4.95 Evidence/Memory source schema identifiers used by compatibility
  migration and its fixtures;
- the inherited v4.93 production-pack IDs, artifact namespace, fixtures, and
  historical test filenames;
- the OS-layer Core manifest, release manifest, checksums, and `VERSION` bytes
  as provenance rather than relabeling them as v4.96 closure;
- protected v4.94 approval identifiers and environment-classifier literals;
  and
- `lifecycle_status: "draft"` plus every qualification, Gate, promotion,
  supported-adoption, release, distribution, and production/live non-claim.

## Resulting Identity Boundary

After this refresh, `MANIFEST.json` may identify the root as a v4.96
multi-lane Production development candidate. That means the current root
entrypoints and validation commands resolve coherently from the v4.96 package
directory. It does not mean:

- the inherited OS-layer release inventory has been rebuilt;
- the v4.93 production pack has changed lifecycle status;
- L2 or PC-2 has received Human disposition;
- a release snapshot, tag, distribution artifact, supported adoption, or
  production deployment exists; or
- the exact LessIsMore Pilot implies universal project, domain, host, adapter,
  or engine support.

Qualification must bind the post-reconciliation exact package tree separately.
