# AI IDE Integration Guide

Version: `AI_Game_Dev_OS_v4.97` Production Assembly development candidate

This file is the bootstrap guide for Codex, WorkBuddy, Cursor, or another AI
IDE/runtime that mounts `AI_Game_Dev_OS_v4.97/` and needs to use it as an AI
Game Dev OS rather than as a loose document folder.

## Read Order

Use this order for initial integration or a change to the selected OS/pack
route. For an already-bound, explicit task, read applicable instructions, the
current task state and the relevant contract/code; reuse unchanged context.
The list is navigation, not a requirement to reload every file at each step:

1. `INDEX.md` - version-level navigation and boundaries.
2. `MANIFEST.json` - machine-readable current version, layer, pack,
   Orchestrator, and validation surfaces.
3. `README.md` - human-readable capability and status overview.
4. `DESIGN_AND_CAPABILITY_ARCHITECTURE.md` - whole-system architecture map,
   founding constraints, truth hierarchy, layer model, and capability flow.
5. `MODULES_AND_INVOCATION.md` - root module catalog, invocation routes,
   write boundaries, and command map.
6. `RUNTIME_INSTANCE_CONTRACT.md` - target-project `.ai_dev_os/` and artifact
   root boundary for generated bindings, run plans, traces, and reports.
7. `REAL_PROJECT_ADOPTION_CONTRACT.md` - evidence requirements and lifecycle
   promotion gate for real projects.
8. `ROOT_MIRROR_POLICY.md` - stable root command and mirror-sync policy.
9. `IDE_INTEGRATION.md` - this runtime bootstrap protocol.
10. `adapters/AI_IDE_ADAPTER_BASE.md` - shared AI IDE adapter contract.
11. `USER_MANUAL.md` - user-facing operating workflows.
12. `OS_PACK_LAYER_MAP.md` - split-layer boundary map.
13. `os_layer/os_control_plane/leads/orchestrator.capability.json` - control
   plane routing authority and invocation-plan review.
14. `pack_layer/packs/game_system_packs/end_to_end_production/capability_pack.json`
   - production pack manifest.
15. `pack_layer/packs/game_system_packs/end_to_end_production/references/end_to_end_delivery_workflow.json`
   - workflow states, skill owners, artifact routes, and gates.
16. `pack_layer/packs/game_system_packs/end_to_end_production/docs/roadmap/PHASE_STATUS.md`
   - current implementation status and remaining lifecycle-promotion limits.

Do not start from `os_layer/README.md` or `pack_layer/README.md` as the full
version entrypoint. Those files are layer-local pointers.

Use root `scripts/` and `tests/` commands as stable public entrypoints unless a
task explicitly requires layer-local maintenance. `ROOT_MIRROR_POLICY.md`
defines how those commands must remain synchronized with `pack_layer/`.

Adapter-specific directories are first-class integration surfaces:

- `adapters/codex/` for Codex parent/subagent coordination.
- `adapters/cursor/` for Cursor worktree-oriented parallel agents.
- `adapters/workbuddy_private/` for WorkBuddy private runtime coordination.

These adapters do not define canonical agents, skills, workflows, schemas, or
validators. They bind AI IDE behavior back to the root contracts, Orchestrator,
production pack manifest, and delivery workflow.

## Routing Model

Use the existing task to establish scope, owner, allowed writes and applicable
validation once. A clear user request may supply the scope; do not create a
separate proposal or invocation document merely to restate it. Continue within
that authorization while the scope and dependencies remain unchanged.

The current executor normally handles authorized work within its owner boundary.
Delegate when independent parallel work or an independent review adds value,
subject to host authorization. Different role names alone do not require new
agents. Ordinary local steps do not require a `LOCAL` override or routing log.
For an actual delegation or unresolved authority boundary, use the existing task
or dispatch brief; see the [routing skill](os_layer/skills/_generic_core/orchestrator/subagent-routing-gate/SKILL.md).

The Orchestrator control sheet defines the cross-layer routing authority:

- `os_pack_resource_routing_review`
- `os_pack_invocation_plan_review`
- `task_breakdown_review`
- `subagent_routing_gate_review`
- `contract_check_review`
- `doc_sync_review`
- `multi_agent_preflight_review`

These capabilities are available when their scope applies, not a checklist to
invoke for every task. They let the AI IDE select and hand off to OS and pack resources.
They do not authorize silent product approval, unrestricted writes, or automatic
LLM calls from repository scripts.

## Goal Classes

| User goal | Primary route |
| --- | --- |
| Create or improve a GDD | `gdd_orchestrator_skill`, GDD specialist skills, GDD review gates |
| Convert design to implementation specs | `game_design_production_spec_skill`, `production_spec_patch_skill` |
| Attach a real project | project readiness, Shared Truth, Architecture Baseline, beta readiness |
| Inspect architecture drift | Architecture Baseline scripts and schemas |
| Perform a small approved refactor | Existing task scope, focused before/after evidence and rollback method; use the formal Controlled Refactor artifact route only when selected by the delivery contract |
| Execute runtime/data/art work | RawData, Godot runtime slice, UI asset binding, QA evidence skills |
| Bind a Production Spec into one development slice | read-only Production Spec input bridge, explicit selection, optional additive/narrowing augmentations |
| Compose a selected development slice | engine-neutral Production Cell contract; v4.97 implements only `godot_local_development_v1` |
| Validate external agent execution | Agent Harness run plan and execution trace validator |
| Triage a recurring issue | FixOps problem/fix/pattern workflow and repository-root `.dev_os_meta/fixops/` evidence |
| Develop an OS change | Existing repository task and affected contracts; `.dev_os_meta/` promotion applies when promoting intake or changing formal version qualification |

## Invocation Contract

Reuse the task's scope, owner, write boundaries and validation plan. Update only
when those facts change; no per-command invocation declaration is required.
For a dispatch, state the subtask, write set and expected evidence once in the
brief, and return the result to the same task. Ask for a decision only when
authorization, scope or a required human judgment is unresolved.

For an explicitly selected runtime-adapter or Agent Harness contract requiring
structured lanes, generate or reuse its run plan. Its required fields, traces
and validators remain mandatory; ordinary host-side delegation alone does not
select this artifact route:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/generate_agent_run_plan.py \
  --artifact-root <delivery_artifact_root> \
  --write-plan <agent_run_plan.json>
```

The runtime adapter consumes handoff lanes and returns an
`agent_execution_trace.json`. Repository scripts validate the trace; they do
not execute the LLM agents directly.

Generated runtime state must follow `RUNTIME_INSTANCE_CONTRACT.md`: project
bindings, run plans, traces, and local reports belong under the target
project's `.ai_dev_os/` directory, while shareable evidence belongs under an
explicit artifact root such as `target_project_artifacts/v493/`.

## Project Attachment

When attaching a real project, the AI IDE should collect the following. These
checks apply to attachment or qualification changes, not every development task:

- project root;
- engine/runtime shape;
- `.ai_dev_os/readiness_binding_registry.json` if present;
- compatibility capability bindings or `.ai_dev_os` local state if no registry
  exists;
- delivery artifact root;
- current GDD/spec/QA/rollback evidence;
- runtime/data/art surfaces referenced by artifacts;
- external truth system or write-back request policy if used.

Then run read-only readiness checks before proposing writes:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/evaluate_pack_beta_readiness.py \
  --project-root <project_root> \
  --artifact-root <delivery_artifact_root> \
  --dry-run \
  --write-report <report.json>
```

The first real-project run may be `BLOCKED`. Treat blockers as routing input,
not as failure of the OS.

If a project has `.ai_dev_os/readiness_binding_registry.json`, treat it as the
project-declared readiness adapter input. It may carry split-gate states for
sprint closure, focused QA, human review, supported adoption, OS demo readiness,
and production release. Keep those gates distinct:

- a passing sprint closure can coexist with non-final human review;
- a rejected follow-up art batch should block human review without rewriting an
  earlier sprint closure as failed;
- a blocked OS demo gate may block OS demo/support promotion without changing
  the project sprint verdict;
- draft dependency packs may support pilot/advisory validation only, not
  supported adoption.

When human review changes after a report was generated, refresh from the project
registry and artifact root:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/evaluate_pack_beta_readiness.py \
  --project-root <project_root> \
  --artifact-root <delivery_artifact_root> \
  --agent-trace <project_root>/.ai_dev_os/agent_execution_trace.json \
  --trace-provenance <project_root>/.ai_dev_os/agent_execution_trace.provenance.json \
  --adoption-mode supported_project_adoption \
  --write-report <delivery_artifact_root>/beta_readiness_report_refreshed.json

python3 AI_Game_Dev_OS_v4.97/scripts/delivery/render_beta_readiness_report.py \
  --report <delivery_artifact_root>/beta_readiness_report_refreshed.json \
  --write-markdown <delivery_artifact_root>/beta_readiness_report_refreshed.md
```

The refreshed report should be read by gate, not as one blended "project pass or
fail" result.

## Evidence Rules

Keep evidence for the task's acceptance conditions in its existing record and
link the original results. Do not produce a new report for every action or copy
the same conclusion into role logs, coordination logs and handoffs. Record
scope decisions once, maintain one current-state entry, and keep validation
details with the relevant test/task. A real owner/thread handoff can reference
that entry; add only missing transfer information. Closure is a conclusion in
the existing task unless its delivery contract requires a separate artifact.

Choose checks by impact:

- Documentation-only changes: review the diff and affected links; no unrelated
  runtime tests or whole-project acceptance matrix.
- Local fixes: test the defect and directly affected existing paths.
- Behavior-preserving refactors: inspect changed interfaces/call relationships
  and compare representative affected behavior before and after.
- Save/data/public-contract or other high-risk changes: retain applicable
  contract checks, focused regression and independent review.
- Visual/gameplay delivery: retain relevant runtime evidence and human judgment;
  do not apply gameplay acceptance to unrelated tooling or documentation.

Reuse evidence only while relevant source/dependencies, inputs, environment and
assertions remain applicable. Rerun for a relevant change, failure, a specific
diagnostic question or an explicit gate requirement. Capture distinguishing
conditions and the first failure together; retain failed attempts and explain
test corrections without rewriting prior results. Stop once applicable checks
pass and no new change or unresolved concern justifies more testing.

Independent review addresses risky behavior, contracts, test expectations and
delivery decisions; routine summaries and mechanical receipts do not each need
another independent review. Selected machine contracts still require their
schema-valid artifacts, source identity, traces and checks. Isolation, resource
budgets, failure preservation, recovery consumers and release/migration gates
remain intact. These rules do not rebind downstream projects or alter old runs.

Fixture success is regression evidence. It is not real-project adoption
evidence.

## Hard Boundaries

- Do not auto-call LLM agents from repository Python scripts.
- Do not treat `lifecycle_status: "draft"` as beta promotion.
- Do not treat repository-root `.dev_os_meta/` as runtime package content.
- Do not put v4.93 module selection or invocation rules into layer README files.
- Do not bypass Orchestrator routing when the request crosses OS and pack
  resources.
- Do not write outside declared owner boundaries without an explicit plan and
  validation route.
- Do not promote generated exploratory GDD output into fixtures unless it is an
  intentional regression artifact.

## Original CoFlow design workflow

When the user asks for the original complete CoFlow process, select
`--workflow-profile coflow_original` on `scripts/delivery/run_gdd_orchestrator.py start`
or `plan`. This produces independent stages 1–7, 7.5 and 8, not the old eight
specialists plus longform. Read the [stage authoring and review protocol](pack_layer/packs/game_system_packs/end_to_end_production/references/gdd_authoring_playbooks/coflow_original_protocol.md).
Use an empty artifact root for planning; revise and validate existing runs in place.

Non-CoFlow calls retain the legacy default. CoFlow text without a profile fails
explicitly; use `--workflow-profile specialist` when longform/specialists are intended.
The CLI does not execute LLMs. The current host executes assigned work and supplies
content-bound review/trace records. `coflow_validation_report.json` distinguishes
plan, execution evidence, authored content, semantic review and production approval.
`reviewed` is local design review only; the existing production approval chain remains required.

### CoFlow professional draft execution (2.0.0)

New `coflow_original` plans bind seven responsibility roles and eight draft skills.
After planning, run `run_gdd_orchestrator.py prepare-stage --artifact-root <root> --stage <stage_id>`;
execute a fresh bounded task from its packet, then validate the authored evidence.
Use `project-resources --artifact-root <root>` for deterministic step 8 inventory.
Full protocol: `references/gdd_authoring_playbooks/coflow_original_protocol.md` inside
the end_to_end_production pack. Context, methods and constraints are content-bound;
local authored/reviewed states still grant no production approval. Existing CoFlow
1.0.0 runs retain their old validation contract, not a professional-execution claim.
