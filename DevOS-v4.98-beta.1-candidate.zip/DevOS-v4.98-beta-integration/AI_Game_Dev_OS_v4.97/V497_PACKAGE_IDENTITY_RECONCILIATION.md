# v4.97 Package Identity Reconciliation

Status: bounded Slice 1 development-package identity refresh; not Production
Assembly completion, qualification Pilot evidence, `L3/PC-3` disposition,
Pack or Adapter promotion, supported adoption, release, or production/live
authority.

## Comparison Boundary

The reproducible package-root comparison is:

```text
accepted v4.96 release commit:  a99ace44a984e58e30c323d84d951d960fac6744
accepted v4.96 identity commit: ae5e120a991c16cb4a98e9c18eed54ebe4a4decc
accepted v4.96 package tree:    575cf6a2d6cb20a7ccf1e5a3642b13b612991a4c
v4.97 first package commit:     39945e9cde878c919e6bdf0b1f603dc93bd24917
identity-refresh preimage:      391ef198cc9c4fa6d5249262c00148dfa54145d2
v4.97 preimage package tree:    c232b4973932768cbee8e6e9943adfc0ffb81a62
```

The accepted v4.96 identity commit and the peeled release commit both resolve
`AI_Game_Dev_OS_v4.96/` to
`575cf6a2d6cb20a7ccf1e5a3642b13b612991a4c`. The manifest keeps the peeled
release commit as `inherited_source_commit`; the identity commit is recorded
separately so those two commit roles are not conflated.

That equality is mechanically reproducible with:

```bash
git rev-parse \
  ae5e120a991c16cb4a98e9c18eed54ebe4a4decc:AI_Game_Dev_OS_v4.96 \
  a99ace44a984e58e30c323d84d951d960fac6744:AI_Game_Dev_OS_v4.96
```

Both output lines must equal the accepted package tree above.

The trees are compared as package roots, not by their different directory
names:

```bash
git diff --no-renames --name-status \
  a99ace44a984e58e30c323d84d951d960fac6744:AI_Game_Dev_OS_v4.96 \
  391ef198cc9c4fa6d5249262c00148dfa54145d2:AI_Game_Dev_OS_v4.97
```

This report and the identity-refresh edits are intentionally outside that
preimage. The comparison remains reproducible after the refresh.

## Exact Preimage Inventory

The accepted v4.96 package contains 2,465 tracked files. The v4.97 identity
preimage contains 2,470 tracked files:

- five paths were added in Slice 0 and the Slice 1 Runtime State baseline
  repair;
- four inherited Runtime State test paths have bounded modifications; and
- no accepted v4.96 path was deleted or renamed.

| Package area | Added | Modified | Meaning |
| --- | ---: | ---: | --- |
| root | 2 | 0 | Slice 0 kickoff/boundary and Human-choice inventory |
| `os_layer/` | 1 | 4 | static Runtime State baseline-coverage contract and repaired tests |
| `production_runtime/` | 2 | 0 | non-writing Gate-local fixture and focused test |
| **total** | **5** | **4** | **9 paths differ from accepted v4.96** |

The exact changed paths are mechanically available from the command above.
The successor was initially populated from the accepted v4.96 Git tree, so
the five additions and four test changes are successor-only.

## Identity Finding

At the identity-refresh preimage, the successor directory still contained
the v4.96 root manifest, schema constraints, entrypoint identities, current
command paths, delivery validators, roadmap mirror text, and mirrored static
assertions. The directory name and implemented Slice 0/1 surfaces therefore
did not yet form one coherent current identity.

Changing only `version_id` would be insufficient: provenance, root
entrypoints, delivery inventory, `production_runtime/`, command roots and the
tests that enforce them would still disagree.

## Reconciliation Decision

The current development-package identity is the whole
`AI_Game_Dev_OS_v4.97/` source tree. The bounded refresh updates:

1. `MANIFEST.json` and `schemas/version_manifest.schema.json`;
2. current root entry documents and package-local command paths;
3. root and `pack_layer/` mirrored delivery validators and static assertions;
4. both roadmap mirrors that identify the current package path;
5. the Slice 0 `production_runtime/` inventory; and
6. the v4.97 development status and changelog.

The refresh deliberately preserves:

- accepted v4.96 commit and package-tree provenance;
- `V496_DEVELOPMENT_STATUS.md` and
  `V496_PACKAGE_IDENTITY_RECONCILIATION.md` as historical records;
- all earlier Evidence/Memory compatibility schema identifiers, migration
  names, fixtures, protected approval IDs and environment literals;
- inherited v4.93 production-pack IDs, artifact namespaces and historical
  test filenames;
- the embedded OS-layer release manifest's v4.94 inventory as non-current
  provenance;
- `os_layer/MANIFEST.json`, `os_layer/RELEASE_MANIFEST.json`,
  `os_layer/CHECKSUMS.sha`, `os_layer/CHECKSUMS.txt`, and `os_layer/VERSION`
  byte-for-byte; and
- `lifecycle_status: "draft"` plus every qualification, promotion, adoption,
  release and production/live non-claim.

## Production Runtime Inventory Boundary

The Slice 1 manifest enumerates only the two tracked Slice 0 surfaces:

- `production_runtime/fixtures/gate_local/sp128_g7_non_writing.stage_contract_binding.json`
- `production_runtime/tests/test_slice0_gate_local_fixture.py`

It does not inventory or depend on concurrent, uncommitted Production
Assembly work. A later admitted slice must reconcile any newly accepted bytes
separately.

## Resulting Identity Boundary

After this refresh, the root manifest may identify the source as a v4.97
Production Assembly development candidate. That means its current entrypoints,
delivery surface and validation commands resolve coherently from the v4.97
directory. It does not mean:

- Production Assembly has been implemented or accepted;
- the qualification Pilot feature, lanes, clone write sets or second Adapter
  have been selected or exercised;
- the inherited OS-layer inventory has become a v4.97 whole-package release
  manifest;
- the inherited Production Pack or any Adapter has changed lifecycle status;
  or
- `L3/PC-3`, supported adoption, release, distribution, push/tag or
  production/live authority exists.

Any later qualification must bind the exact post-reconciliation package tree
and its separately admitted project/Adapter evidence.

## Resource-lifecycle successor identity note

`PLAN-V497-RLRC-001` Revision 1 does not rewrite the identity-refresh preimage
or any accepted Assembly. Its R4 freeze is a forward-only development-package
successor. The exact post-implementation commit, root tree, package tree,
changed-path inventory and raw file hashes are recorded under
`.dev_os_meta/evidence/v497_resource_lease_retention_corrective/` after the
package commit is clean. In particular, the accepted Candidate 1 v1.2.0 and
Godot v1.0.1 raw SHA-256 locks remain separate inputs to that receipt.

This successor identity authorizes neither R5/R6 cleanup nor Slice 9
qualification re-entry. Any later Assembly comparison must re-resolve against
the R4 package tree rather than inheriting the predecessor receipt.
