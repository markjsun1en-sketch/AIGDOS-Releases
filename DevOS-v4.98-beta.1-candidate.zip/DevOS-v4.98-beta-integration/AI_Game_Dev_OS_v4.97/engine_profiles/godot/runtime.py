"""Fail-closed Godot 4.4 execution-snapshot runtime.

This module is an Engine Profile implementation, not a Project Binding and not
an authority source.  It verifies a caller-supplied machine-local host-tool
identity, materializes one clean exact Git commit through ``git archive``, and
constructs or executes only the command explicitly selected by the caller.

The source clone is never a Godot execution root.  The only project-like root
that may be passed to Godot is a newly-created external snapshot containing
tracked bytes plus one deterministic ``override.cfg`` that isolates
``user://``.  Evidence, build, log, and cache roots are sibling external
runtime artifacts and are not project write scopes.
"""

from __future__ import annotations

import base64
import binascii
import ctypes
from dataclasses import asdict, dataclass, field
import errno
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import platform
import re
import secrets
import shutil
import signal
import stat
import subprocess
import tarfile
import tempfile
import time
from typing import Any, BinaryIO, Mapping, Sequence

from production_runtime.composition.assembly import (
    AssemblyResolutionError,
    reresolve_and_verify_assembly_lock,
)


MODULE_ROOT = Path(__file__).resolve().parent
VERSION_ROOT = MODULE_ROOT.parents[1]
DEFAULT_ENGINE_PROFILE_PATH = MODULE_ROOT / "engine_profile.json"
DEFAULT_HOST_TOOL_REQUIREMENT_PATH = MODULE_ROOT / "host_tool_requirement.json"
DEFAULT_GIT_HOST_TOOL_REQUIREMENT_PATH = (
    MODULE_ROOT / "git_host_tool_requirement.json"
)
ENGINE_PROFILE_SCHEMA_PATH = VERSION_ROOT / "schemas" / "engine_profile.schema.json"
PROJECT_BINDING_SCHEMA_PATH = VERSION_ROOT / "schemas" / "project_binding.schema.json"
CAPABILITY_PACK_PATH = (
    VERSION_ROOT / "production_packs/runtime_feature_slice/capability_pack.json"
)
FEATURE_RECIPE_PATH = (
    VERSION_ROOT
    / "production_packs/runtime_feature_slice/recipes/read_only_hero_run_summary.recipe.json"
)

PROFILE_ID = "godot_4_4_local_development"
EXECUTABLE_REF = "host-tool://godot-4.4-stable-official"
GIT_EXECUTABLE_REF = "host-tool://apple-git-2.50.1"
GODOT_HOST_REQUIREMENT_ID = "godot_4_4_stable_official_macos"
GIT_HOST_REQUIREMENT_ID = "apple_git_2_50_1_macos"
STARTUP_COMMAND_ID = "godot_exact_engine_startup"
EXPORT_COMMAND_ID = "godot_development_export"
SUPPORTED_PROJECT_COMMANDS = {
    "lessismore": frozenset({STARTUP_COMMAND_ID, EXPORT_COMMAND_ID}),
    "randomheroes": frozenset({STARTUP_COMMAND_ID}),
}

_SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")
_GIT_OBJECT_PATTERN = re.compile(r"^[0-9a-f]{40}$")
_IDENTIFIER_PATTERN = re.compile(r"^[a-z][a-z0-9_.-]{1,63}$")
_EXECUTION_ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9_.-]{2,63}$")
_CUSTOM_USER_DIR_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]{7,127}$")
_MAX_CAPTURE_BYTES = 128 * 1024
_EXECUTION_TOKEN_ENV = "AI_DEV_OS_EXECUTION_TOKEN"
_EXECUTION_CONSUMED_MARKER = "godot_execution_consumed.json"
_PROCESS_SCAN_INTERVAL_SECONDS = 0.05
_PROCESS_CLEANUP_TIMEOUT_SECONDS = 5.0
_MAX_PROCESS_ARGUMENT_BYTES = 4 * 1024 * 1024
_MAX_HOST_TOOL_PROBE_TIMEOUT_SECONDS = 60.0
_MAX_STAGE_EXECUTION_TIMEOUT_SECONDS = 3600.0

_EXPECTED_PROFILE_COMMANDS: Mapping[str, Mapping[str, Any]] = {
    STARTUP_COMMAND_ID: {
        "command_id": STARTUP_COMMAND_ID,
        "stage_family": "development_build",
        "operation_id": "build_or_startup_integration",
        "host_tool_ref_id": "godot_4_4_stable_official_macos",
        "executable_ref": EXECUTABLE_REF,
        "arguments": [
            "--headless",
            "--path",
            "{snapshot_godot_root}",
            "--log-file",
            "{log_file}",
            "--quit-after",
            "2",
        ],
    },
    EXPORT_COMMAND_ID: {
        "command_id": EXPORT_COMMAND_ID,
        "stage_family": "development_build",
        "operation_id": "build_or_startup_integration",
        "host_tool_ref_id": "godot_4_4_stable_official_macos",
        "executable_ref": EXECUTABLE_REF,
        "arguments": [
            "--headless",
            "--path",
            "{snapshot_godot_root}",
            "--log-file",
            "{log_file}",
            "--export-debug",
            "macOS Development",
            "{build_output}",
        ],
    },
}

_HOST_REQUIREMENT_KEYS = frozenset(
    {
        "schema_version",
        "artifact_type",
        "requirement_id",
        "executable_ref",
        "engine_family",
        "required_platform",
        "accepted_reported_versions",
        "accepted_binary_sha256",
        "required_capabilities",
        "version_probe_arguments",
        "non_claims",
    }
)
_HOST_IDENTITY_KEYS = frozenset(
    {
        "schema_version",
        "artifact_type",
        "executable_ref",
        "executable_path",
        "reported_version",
        "binary_sha256",
        "capabilities",
    }
)
_HOST_TOOL_BINDING_KEYS = frozenset(
    {
        "identity",
        "identity_sha256",
        "byte_count",
        "requirement_id",
        "requirement_sha256",
        "version_probe_arguments",
    }
)

SNAPSHOT_NON_CLAIMS = (
    "snapshot_materialization_grants_no_project_write_or_execution_permission",
    "git_archive_excludes_untracked_and_ignored_source_paths_by_construction",
    "override_cfg_changes_only_the_snapshot_user_data_namespace",
    "external_runtime_roots_are_not_project_binding_write_scopes",
    "snapshot_identity_is_not_feature_qa_qualification_adoption_or_release_evidence",
    "isolated_user_data_does_not_claim_a_general_operating_system_sandbox",
)
COMMAND_NON_CLAIMS = (
    "an_explicit_command_plan_does_not_make_its_stage_required_or_blocking",
    "a_factual_process_success_does_not_establish_feature_correctness",
    "engine_execution_grants_no_qualification_adoption_release_or_live_authority",
    "process_group_and_token_containment_is_not_a_general_operating_system_sandbox",
)


class GodotEngineProfileError(RuntimeError):
    """Base class carrying one stable fail-closed reason code."""

    def __init__(self, code: str, detail: str | None = None) -> None:
        self.code = code
        self.detail = detail
        message = code if detail is None else f"{code}: {detail}"
        super().__init__(message)


class HostToolIdentityError(GodotEngineProfileError):
    """Raised when the executable identity is absent, unsafe, or mismatched."""


class SnapshotBoundaryError(GodotEngineProfileError):
    """Raised when source or external-snapshot boundaries are not exact."""


class StageCommandError(GodotEngineProfileError):
    """Raised when an unselected, unsupported, or unsafe command is requested."""


class StageAuthorizationError(StageCommandError):
    """Raised when an exact Assembly stage does not authorize engine execution."""


def _bounded_timeout(
    value: Any,
    *,
    code: str,
    maximum: float,
    error_type: type[GodotEngineProfileError],
) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise error_type(code)
    try:
        normalized = float(value)
    except (OverflowError, ValueError) as exc:
        raise error_type(code) from exc
    if (
        not math.isfinite(normalized)
        or normalized <= 0
        or normalized > maximum
    ):
        raise error_type(code)
    return normalized


def _binding_json_object(value: str, *, label: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value)
    except (TypeError, json.JSONDecodeError) as exc:
        raise SnapshotBoundaryError(f"{label}_invalid") from exc
    if not isinstance(parsed, dict):
        raise SnapshotBoundaryError(f"{label}_invalid")
    if _canonical_json_bytes(parsed).decode("utf-8") != value:
        raise SnapshotBoundaryError(f"{label}_not_canonical")
    if set(parsed) != _HOST_TOOL_BINDING_KEYS:
        raise SnapshotBoundaryError(f"{label}_shape_invalid")
    identity = parsed.get("identity")
    if not isinstance(identity, dict) or set(identity) != _HOST_IDENTITY_KEYS:
        raise SnapshotBoundaryError(f"{label}_shape_invalid")
    string_identity_fields = (
        "schema_version",
        "artifact_type",
        "executable_ref",
        "executable_path",
        "reported_version",
        "binary_sha256",
    )
    if any(
        not isinstance(identity.get(name), str)
        or not identity[name]
        or "\x00" in identity[name]
        for name in string_identity_fields
    ):
        raise SnapshotBoundaryError(f"{label}_shape_invalid")
    capabilities = identity.get("capabilities")
    if (
        not isinstance(capabilities, list)
        or not capabilities
        or any(
            not isinstance(item, str) or not item or "\x00" in item
            for item in capabilities
        )
        or len(set(capabilities)) != len(capabilities)
    ):
        raise SnapshotBoundaryError(f"{label}_shape_invalid")
    byte_count = parsed.get("byte_count")
    probe_arguments = parsed.get("version_probe_arguments")
    if (
        identity.get("schema_version") != "1.0.0"
        or identity.get("artifact_type") != "host_tool_identity"
        or not isinstance(byte_count, int)
        or isinstance(byte_count, bool)
        or byte_count <= 0
        or not isinstance(probe_arguments, list)
        or not probe_arguments
        or any(
            not isinstance(item, str) or not item or "\x00" in item
            for item in probe_arguments
        )
        or any(
            not isinstance(parsed.get(name), str)
            or not parsed[name]
            or "\x00" in parsed[name]
            for name in (
                "identity_sha256",
                "requirement_id",
                "requirement_sha256",
            )
        )
        or _SHA256_PATTERN.fullmatch(parsed["identity_sha256"]) is None
        or _SHA256_PATTERN.fullmatch(parsed["requirement_sha256"]) is None
        or _SHA256_PATTERN.fullmatch(identity["binary_sha256"]) is None
        or parsed["identity_sha256"] != _json_sha256(identity)
    ):
        raise SnapshotBoundaryError(f"{label}_shape_invalid")
    return parsed


@dataclass(frozen=True)
class VerifiedHostTool:
    """Observed executable identity bound to one exact requirement."""

    executable_ref: str
    executable_path: str
    reported_version: str
    binary_sha256: str
    byte_count: int
    capabilities: tuple[str, ...]
    requirement_id: str
    requirement_sha256: str
    version_probe_arguments: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["capabilities"] = list(self.capabilities)
        value["version_probe_arguments"] = list(self.version_probe_arguments)
        value["non_claims"] = [
            "host_tool_identity_does_not_grant_project_execution_permission",
            "tool_identity_does_not_prove_any_project_result",
        ]
        return value

    def identity_input(self) -> dict[str, Any]:
        """Return the closed machine-local identity shape accepted by the verifier."""

        return {
            "schema_version": "1.0.0",
            "artifact_type": "host_tool_identity",
            "executable_ref": self.executable_ref,
            "executable_path": self.executable_path,
            "reported_version": self.reported_version,
            "binary_sha256": self.binary_sha256,
            "capabilities": list(self.capabilities),
        }

    def binding_record(self) -> dict[str, Any]:
        """Return the exact observed identity plus its bound requirement."""

        identity = self.identity_input()
        return {
            "identity": identity,
            "identity_sha256": _json_sha256(identity),
            "byte_count": self.byte_count,
            "requirement_id": self.requirement_id,
            "requirement_sha256": self.requirement_sha256,
            "version_probe_arguments": list(self.version_probe_arguments),
        }


@dataclass(frozen=True)
class VerifiedStageAuthorization:
    """Exact Assembly/Project Binding authorization for one engine stage."""

    assembly_sha256: str
    project_binding_id: str
    project_binding_sha256: str
    project_id: str
    project_family: str
    project_root: str
    project_subroot: str
    source_commit: str
    source_tree: str
    selected_stage_id: str
    selected_command_id: str
    stage_family: str
    operation_id: str
    disposition: str
    permission_status: str
    executable_ref: str
    command_arguments: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["command_arguments"] = list(self.command_arguments)
        return value


@dataclass(frozen=True)
class ExecutionSnapshotReceipt:
    """Immutable description of one newly materialized execution snapshot."""

    profile_id: str
    profile_sha256: str
    assembly_sha256: str
    project_binding_id: str
    project_binding_sha256: str
    selected_stage_id: str
    authorized_command_id: str
    stage_disposition: str
    project_id: str
    execution_id: str
    source_clone_root: str
    source_commit: str
    source_tree: str
    git_archive_sha256: str
    godot_host_tool_binding_json: str
    git_host_tool_binding_json: str
    snapshot_root: str
    project_subroot: str
    godot_root: str
    project_godot_sha256: str
    snapshot_payload_manifest_sha256: str
    snapshot_payload_file_count: int
    override_relative_path: str
    override_content_base64: str
    override_sha256: str
    custom_user_dir_name: str
    custom_user_dir_seed_sha256: str
    macos_application_support_relative_path: str
    evidence_root: str
    build_root: str
    log_root: str
    cache_root: str
    receipt_path: str
    receipt_sha256: str
    non_claims: tuple[str, ...]

    def payload(self) -> dict[str, Any]:
        return {
            "schema_version": "1.0.0",
            "artifact_type": "godot_execution_snapshot_receipt",
            "profile_id": self.profile_id,
            "profile_sha256": self.profile_sha256,
            "execution_authorization": {
                "assembly_sha256": self.assembly_sha256,
                "project_binding_id": self.project_binding_id,
                "project_binding_sha256": self.project_binding_sha256,
                "selected_stage_id": self.selected_stage_id,
                "authorized_command_id": self.authorized_command_id,
                "stage_disposition": self.stage_disposition,
            },
            "project_id": self.project_id,
            "execution_id": self.execution_id,
            "source_identity": {
                "clone_root": self.source_clone_root,
                "commit": self.source_commit,
                "tree": self.source_tree,
                "clean_tracked_and_untracked": True,
                "materialization_method": "git_archive_exact_commit",
                "git_archive_sha256": self.git_archive_sha256,
                "untracked_source_paths_included": False,
                "ignored_source_paths_included": False,
            },
            "host_tool_identities": {
                "godot": _binding_json_object(
                    self.godot_host_tool_binding_json,
                    label="snapshot_godot_host_tool_binding",
                ),
                "git": _binding_json_object(
                    self.git_host_tool_binding_json,
                    label="snapshot_git_host_tool_binding",
                ),
            },
            "snapshot": {
                "snapshot_root": self.snapshot_root,
                "project_subroot": self.project_subroot,
                "godot_root": self.godot_root,
                "project_godot_sha256": self.project_godot_sha256,
                "payload_manifest_sha256": self.snapshot_payload_manifest_sha256,
                "payload_file_count": self.snapshot_payload_file_count,
                "git_metadata_present": False,
            },
            "override": {
                "relative_path": self.override_relative_path,
                "content_base64": self.override_content_base64,
                "byte_count": len(_decode_base64(self.override_content_base64)),
                "sha256": self.override_sha256,
                "overridden_project_settings": [
                    "application/config/use_custom_user_dir",
                    "application/config/custom_user_dir_name",
                ],
                "custom_user_dir_name": self.custom_user_dir_name,
                "custom_user_dir_seed_sha256": self.custom_user_dir_seed_sha256,
                "macos_application_support_relative_path": (
                    self.macos_application_support_relative_path
                ),
            },
            "external_runtime_roots": {
                "evidence": self.evidence_root,
                "build": self.build_root,
                "log": self.log_root,
                "cache": self.cache_root,
            },
            "receipt_relative_path": "godot_execution_snapshot_receipt.json",
            "non_claims": list(self.non_claims),
        }

    def to_dict(self) -> dict[str, Any]:
        value = ExecutionSnapshotReceipt.payload(self)
        value["receipt_sha256"] = self.receipt_sha256
        return value


@dataclass(frozen=True)
class GodotStageCommand:
    """An exact argv plan for one caller-selected stage command."""

    selected_command_id: str
    selected_stage_id: str
    stage_family: str
    operation_id: str
    stage_disposition: str
    assembly_sha256: str
    project_binding_id: str
    project_binding_sha256: str
    project_id: str
    profile_id: str
    profile_sha256: str
    executable_ref: str
    executable_sha256: str
    snapshot_receipt_sha256: str
    snapshot_root: str
    source_clone_root: str
    cwd: str
    argv: tuple[str, ...]
    environment_overrides: tuple[tuple[str, str], ...]
    log_file: str
    build_output: str | None
    command_sha256: str
    non_claims: tuple[str, ...]

    def payload(self) -> dict[str, Any]:
        return {
            "selected_command_id": self.selected_command_id,
            "selected_stage_id": self.selected_stage_id,
            "stage_family": self.stage_family,
            "operation_id": self.operation_id,
            "stage_disposition": self.stage_disposition,
            "assembly_sha256": self.assembly_sha256,
            "project_binding_id": self.project_binding_id,
            "project_binding_sha256": self.project_binding_sha256,
            "project_id": self.project_id,
            "profile_id": self.profile_id,
            "profile_sha256": self.profile_sha256,
            "executable_ref": self.executable_ref,
            "executable_sha256": self.executable_sha256,
            "snapshot_receipt_sha256": self.snapshot_receipt_sha256,
            "snapshot_root": self.snapshot_root,
            "source_clone_root": self.source_clone_root,
            "cwd": self.cwd,
            "argv": list(self.argv),
            "environment_overrides": dict(self.environment_overrides),
            "log_file": self.log_file,
            "build_output": self.build_output,
            "non_claims": list(self.non_claims),
        }

    def to_dict(self) -> dict[str, Any]:
        value = GodotStageCommand.payload(self)
        value["command_sha256"] = self.command_sha256
        return value


@dataclass(frozen=True)
class GodotStageResult:
    """Factual process outcome; never an aggregate or Human verdict."""

    selected_command_id: str
    selected_stage_id: str
    assembly_sha256: str
    project_binding_sha256: str
    command_sha256: str
    snapshot_receipt_sha256: str
    executable_sha256: str
    argv: tuple[str, ...]
    cwd: str
    status: str
    failure_kind: str | None
    exit_code: int | None
    duration_ms: int
    stdout: str
    stderr: str
    stdout_truncated: bool
    stderr_truncated: bool
    non_claims: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["argv"] = list(self.argv)
        value["non_claims"] = list(self.non_claims)
        return value


def _require_snapshot_receipt_shape(receipt: ExecutionSnapshotReceipt) -> None:
    if type(receipt) is not ExecutionSnapshotReceipt:
        raise SnapshotBoundaryError("snapshot_receipt_type_invalid")
    values = {
        name: getattr(receipt, name)
        for name in ExecutionSnapshotReceipt.__dataclass_fields__
    }
    if (
        not isinstance(receipt.snapshot_payload_file_count, int)
        or isinstance(receipt.snapshot_payload_file_count, bool)
        or receipt.snapshot_payload_file_count < 0
        or not isinstance(receipt.non_claims, tuple)
        or any(
            not isinstance(item, str) or not item or "\x00" in item
            for item in receipt.non_claims
        )
    ):
        raise SnapshotBoundaryError("snapshot_receipt_shape_invalid")
    for name, value in values.items():
        if name in {"snapshot_payload_file_count", "non_claims"}:
            continue
        if not isinstance(value, str) or not value or "\x00" in value:
            raise SnapshotBoundaryError("snapshot_receipt_shape_invalid", name)
    for name in (
        "profile_sha256",
        "assembly_sha256",
        "project_binding_sha256",
        "git_archive_sha256",
        "project_godot_sha256",
        "snapshot_payload_manifest_sha256",
        "override_sha256",
        "custom_user_dir_seed_sha256",
        "receipt_sha256",
    ):
        if _SHA256_PATTERN.fullmatch(str(values[name])) is None:
            raise SnapshotBoundaryError("snapshot_receipt_shape_invalid", name)


def _require_stage_command_shape(command: GodotStageCommand) -> None:
    if type(command) is not GodotStageCommand:
        raise StageCommandError("stage_command_type_invalid")
    values = {
        name: getattr(command, name)
        for name in GodotStageCommand.__dataclass_fields__
    }
    if (
        not isinstance(command.argv, tuple)
        or not command.argv
        or any(
            not isinstance(item, str) or not item or "\x00" in item
            for item in command.argv
        )
        or not isinstance(command.environment_overrides, tuple)
        or any(
            not isinstance(item, tuple)
            or len(item) != 2
            or any(
                not isinstance(part, str) or not part or "\x00" in part
                for part in item
            )
            for item in command.environment_overrides
        )
        or len({item[0] for item in command.environment_overrides})
        != len(command.environment_overrides)
        or not isinstance(command.non_claims, tuple)
        or any(
            not isinstance(item, str) or not item or "\x00" in item
            for item in command.non_claims
        )
        or (
            command.build_output is not None
            and (
                not isinstance(command.build_output, str)
                or not command.build_output
                or "\x00" in command.build_output
            )
        )
    ):
        raise StageCommandError("stage_command_shape_invalid")
    for name, value in values.items():
        if name in {
            "argv",
            "environment_overrides",
            "non_claims",
            "build_output",
        }:
            continue
        if not isinstance(value, str) or not value or "\x00" in value:
            raise StageCommandError("stage_command_shape_invalid", name)
    for name in (
        "assembly_sha256",
        "project_binding_sha256",
        "profile_sha256",
        "executable_sha256",
        "snapshot_receipt_sha256",
        "command_sha256",
    ):
        if _SHA256_PATTERN.fullmatch(str(values[name])) is None:
            raise StageCommandError("stage_command_shape_invalid", name)


def _duplicate_rejecting_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise GodotEngineProfileError("json_duplicate_key", key)
        value[key] = item
    return value


def _read_json_object(path: Path, *, label: str) -> dict[str, Any]:
    try:
        raw = path.read_text(encoding="utf-8")
        value = json.loads(raw, object_pairs_hook=_duplicate_rejecting_object)
    except GodotEngineProfileError:
        raise
    except FileNotFoundError as exc:
        raise GodotEngineProfileError(f"{label}_missing", str(path)) from exc
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise GodotEngineProfileError(f"{label}_invalid", str(exc)) from exc
    if not isinstance(value, dict):
        raise GodotEngineProfileError(f"{label}_not_object")
    return value


def _mapping_or_json_path(value: Mapping[str, Any] | str | Path, *, label: str) -> dict[str, Any]:
    if isinstance(value, Mapping):
        try:
            return json.loads(json.dumps(value, ensure_ascii=False))
        except (TypeError, ValueError) as exc:
            raise GodotEngineProfileError(f"{label}_not_json", str(exc)) from exc
    path = Path(value)
    if not path.is_absolute():
        raise GodotEngineProfileError(f"{label}_path_not_absolute", str(path))
    return _read_json_object(path, label=label)


def _canonical_json_bytes(value: Mapping[str, Any]) -> bytes:
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise GodotEngineProfileError("canonical_json_invalid", str(exc)) from exc


def _decode_base64(value: str) -> bytes:
    if not isinstance(value, str):
        raise SnapshotBoundaryError("snapshot_override_base64_invalid")
    try:
        return base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise SnapshotBoundaryError("snapshot_override_base64_invalid") from exc


def _json_sha256(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(_canonical_json_bytes(value)).hexdigest()


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
    except OSError as exc:
        raise GodotEngineProfileError("file_identity_unreadable", str(path)) from exc
    return digest.hexdigest()


def _require_string_list(value: Any, *, code: str, nonempty: bool = True) -> tuple[str, ...]:
    if not isinstance(value, list) or (nonempty and not value):
        raise GodotEngineProfileError(code)
    if any(not isinstance(item, str) or not item for item in value):
        raise GodotEngineProfileError(code)
    if len(set(value)) != len(value):
        raise GodotEngineProfileError(f"{code}_duplicate")
    return tuple(value)


def _component_ref_for_source(
    *,
    component_id: str,
    version: str,
    source: Mapping[str, Any] | str | Path,
    label: str,
) -> dict[str, str]:
    source_value = _mapping_or_json_path(source, label=f"{label}_source")
    return {
        "component_id": component_id,
        "version": version,
        "canonical_sha256": _json_sha256(source_value),
    }


def _require_exact_component_refs(
    refs: Any,
    *,
    expected: Sequence[tuple[str, str, Mapping[str, Any] | str | Path]],
    label: str,
) -> None:
    if not isinstance(refs, list) or any(not isinstance(item, dict) for item in refs):
        raise GodotEngineProfileError(f"{label}_ref_inventory_invalid")
    expected_refs = [
        _component_ref_for_source(
            component_id=component_id,
            version=version,
            source=source,
            label=f"{label}_{component_id}",
        )
        for component_id, version, source in expected
    ]
    if refs != expected_refs:
        raise GodotEngineProfileError(f"{label}_ref_identity_mismatch")


def load_engine_profile(
    profile: Mapping[str, Any] | str | Path = DEFAULT_ENGINE_PROFILE_PATH,
    *,
    host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_HOST_TOOL_REQUIREMENT_PATH
    ),
    git_host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_GIT_HOST_TOOL_REQUIREMENT_PATH
    ),
) -> dict[str, Any]:
    """Load, schema-check, and bind the exact built-in command templates."""

    value = _mapping_or_json_path(profile, label="engine_profile")
    host_requirement_value = load_host_tool_requirement(host_tool_requirement)
    git_requirement_value = load_git_host_tool_requirement(
        git_host_tool_requirement
    )
    try:
        import jsonschema
    except ImportError as exc:  # pragma: no cover - explicit dependency failure
        raise GodotEngineProfileError("jsonschema_dependency_unavailable") from exc
    schema = _read_json_object(ENGINE_PROFILE_SCHEMA_PATH, label="engine_profile_schema")
    try:
        jsonschema.Draft7Validator(schema).validate(value)
    except jsonschema.ValidationError as exc:
        pointer = "/" + "/".join(str(item) for item in exc.absolute_path)
        raise GodotEngineProfileError(
            "engine_profile_schema_invalid", f"{pointer}: {exc.message}"
        ) from exc
    if value.get("engine_profile_id") != PROFILE_ID:
        raise GodotEngineProfileError("engine_profile_identity_mismatch")
    if value.get("can_change_completion_semantics") is not False:
        raise GodotEngineProfileError("engine_profile_completion_semantics_unsafe")
    if value.get("allowed_write_scope_ids") != []:
        raise GodotEngineProfileError("engine_profile_project_write_scope_not_empty")
    if value.get("supported_pack_ids") != ["candidate1_read_only_summary_pack"]:
        raise GodotEngineProfileError("engine_profile_supported_pack_identity_mismatch")
    if value.get("supported_recipe_ids") != [
        "candidate1_read_only_hero_run_summary"
    ]:
        raise GodotEngineProfileError("engine_profile_supported_recipe_identity_mismatch")
    _require_exact_component_refs(
        value.get("supported_pack_refs"),
        expected=(
            (
                "candidate1_read_only_summary_pack",
                "2.0.0",
                CAPABILITY_PACK_PATH,
            ),
        ),
        label="supported_pack",
    )
    _require_exact_component_refs(
        value.get("supported_recipe_refs"),
        expected=(
            (
                "candidate1_read_only_hero_run_summary",
                "2.0.0",
                FEATURE_RECIPE_PATH,
            ),
        ),
        label="supported_recipe",
    )
    _require_exact_component_refs(
        value.get("host_tool_refs"),
        expected=(
            (GIT_HOST_REQUIREMENT_ID, "1.0.0", git_requirement_value),
            (GODOT_HOST_REQUIREMENT_ID, "1.0.0", host_requirement_value),
        ),
        label="host_tool",
    )
    commands = value.get("commands")
    if not isinstance(commands, list):
        raise GodotEngineProfileError("engine_profile_commands_invalid")
    actual = {item.get("command_id"): item for item in commands if isinstance(item, dict)}
    if actual != _EXPECTED_PROFILE_COMMANDS or len(actual) != len(commands):
        raise GodotEngineProfileError("engine_profile_command_registry_mismatch")
    return value


def load_host_tool_requirement(
    requirement: Mapping[str, Any] | str | Path = DEFAULT_HOST_TOOL_REQUIREMENT_PATH,
) -> dict[str, Any]:
    """Load the distributable, path-free Godot host-tool requirement."""

    return _load_host_tool_requirement(
        requirement,
        label="host_tool_requirement",
        expected_requirement_id=GODOT_HOST_REQUIREMENT_ID,
        expected_executable_ref=EXECUTABLE_REF,
        expected_family="godot",
    )


def load_git_host_tool_requirement(
    requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_GIT_HOST_TOOL_REQUIREMENT_PATH
    ),
) -> dict[str, Any]:
    """Load the distributable, path-free Apple Git requirement."""

    return _load_host_tool_requirement(
        requirement,
        label="git_host_tool_requirement",
        expected_requirement_id=GIT_HOST_REQUIREMENT_ID,
        expected_executable_ref=GIT_EXECUTABLE_REF,
        expected_family="git",
    )


def _load_host_tool_requirement(
    requirement: Mapping[str, Any] | str | Path,
    *,
    label: str,
    expected_requirement_id: str,
    expected_executable_ref: str,
    expected_family: str,
) -> dict[str, Any]:
    value = _mapping_or_json_path(requirement, label=label)
    if set(value) != _HOST_REQUIREMENT_KEYS:
        raise HostToolIdentityError("host_tool_requirement_shape_invalid")
    if value.get("schema_version") != "1.0.0":
        raise HostToolIdentityError("host_tool_requirement_schema_version_invalid")
    if value.get("artifact_type") != "host_tool_requirement":
        raise HostToolIdentityError("host_tool_requirement_artifact_type_invalid")
    if (
        value.get("requirement_id") != expected_requirement_id
        or value.get("executable_ref") != expected_executable_ref
        or value.get("engine_family") != expected_family
    ):
        raise HostToolIdentityError("host_tool_requirement_identity_invalid")
    if value.get("required_platform") != "macos":
        raise HostToolIdentityError("host_tool_requirement_platform_invalid")
    versions = _require_string_list(
        value.get("accepted_reported_versions"), code="accepted_reported_versions_invalid"
    )
    digests = _require_string_list(
        value.get("accepted_binary_sha256"), code="accepted_binary_sha256_invalid"
    )
    if any(_SHA256_PATTERN.fullmatch(item) is None for item in digests):
        raise HostToolIdentityError("accepted_binary_sha256_invalid")
    _require_string_list(value.get("required_capabilities"), code="required_capabilities_invalid")
    probe = _require_string_list(
        value.get("version_probe_arguments"), code="version_probe_arguments_invalid"
    )
    if probe != ("--version",):
        raise HostToolIdentityError("version_probe_arguments_not_builtin")
    _require_string_list(value.get("non_claims"), code="host_tool_non_claims_invalid")
    if not versions:
        raise HostToolIdentityError("accepted_reported_versions_invalid")
    return value


def _project_family(project_id: str) -> str:
    if project_id == "lessismore" or project_id.startswith("lessismore_"):
        return "lessismore"
    if project_id == "randomheroes" or project_id.startswith("randomheroes_"):
        return "randomheroes"
    raise StageAuthorizationError("authorized_project_family_not_supported", project_id)


def _require_component_canonical_ref(
    material: Mapping[str, Any],
    *,
    artifact_type: str,
    component_id: str,
    version: str,
    canonical_sha256: str,
) -> None:
    matches = [
        item
        for item in material.get("component_refs", [])
        if isinstance(item, Mapping) and item.get("artifact_type") == artifact_type
    ]
    if len(matches) != 1:
        raise StageAuthorizationError(
            "assembly_component_ref_not_exact", artifact_type
        )
    reference = matches[0]
    if (
        reference.get("component_id") != component_id
        or reference.get("version") != version
        or reference.get("canonical_sha256") != canonical_sha256
    ):
        raise StageAuthorizationError(
            "assembly_component_canonical_ref_mismatch", artifact_type
        )


def _load_project_binding(
    project_binding: Mapping[str, Any] | str | Path,
) -> dict[str, Any]:
    value = _mapping_or_json_path(project_binding, label="project_binding")
    try:
        import jsonschema
    except ImportError as exc:  # pragma: no cover - explicit dependency failure
        raise StageAuthorizationError("jsonschema_dependency_unavailable") from exc
    schema = _read_json_object(
        PROJECT_BINDING_SCHEMA_PATH, label="project_binding_schema"
    )
    try:
        jsonschema.Draft7Validator(schema).validate(value)
    except jsonschema.ValidationError as exc:
        pointer = "/" + "/".join(str(item) for item in exc.absolute_path)
        raise StageAuthorizationError(
            "project_binding_schema_invalid", f"{pointer}: {exc.message}"
        ) from exc
    return value


def verify_stage_authorization(
    *,
    assembly_lock: Mapping[str, Any] | str | Path,
    assembly_component_paths: Sequence[str | Path],
    project_binding: Mapping[str, Any] | str | Path,
    selected_stage_id: str,
    selected_command_id: str,
    profile: Mapping[str, Any] | str | Path = DEFAULT_ENGINE_PROFILE_PATH,
    host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_HOST_TOOL_REQUIREMENT_PATH
    ),
    git_host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_GIT_HOST_TOOL_REQUIREMENT_PATH
    ),
) -> VerifiedStageAuthorization:
    """Verify one exact permitted Engine stage from a content-addressed lock.

    A command id alone is never authorization.  The lock, its exact host
    Project Binding, the selected stage, and the selected profile command must
    agree on identity, disposition, permission, operation, and arguments.
    """

    if not isinstance(selected_stage_id, str) or not selected_stage_id:
        raise StageAuthorizationError("selected_stage_id_missing")
    if not isinstance(selected_command_id, str) or not selected_command_id:
        raise StageAuthorizationError("selected_command_id_missing")
    lock_input = _mapping_or_json_path(assembly_lock, label="assembly_lock")
    if isinstance(assembly_component_paths, (str, bytes)):
        raise StageAuthorizationError("assembly_component_paths_invalid")
    try:
        component_paths = tuple(assembly_component_paths)
    except TypeError as exc:
        raise StageAuthorizationError("assembly_component_paths_invalid") from exc
    if not component_paths:
        raise StageAuthorizationError("assembly_component_paths_empty")
    try:
        lock_value = reresolve_and_verify_assembly_lock(lock_input, component_paths)
    except (AssemblyResolutionError, OSError, TypeError, ValueError) as exc:
        raise StageAuthorizationError(
            "assembly_authority_reresolution_failed", str(exc)
        ) from exc
    assembly_sha256 = str(lock_value["assembly_sha256"])
    binding = _load_project_binding(project_binding)
    profile_value = load_engine_profile(
        profile,
        host_tool_requirement=host_tool_requirement,
        git_host_tool_requirement=git_host_tool_requirement,
    )
    profile_sha256 = _json_sha256(profile_value)
    binding_sha256 = _json_sha256(binding)
    material = lock_value["assembly_material"]
    _require_component_canonical_ref(
        material,
        artifact_type="engine_profile",
        component_id=str(profile_value["engine_profile_id"]),
        version=str(profile_value["version"]),
        canonical_sha256=profile_sha256,
    )
    _require_component_canonical_ref(
        material,
        artifact_type="project_binding",
        component_id=str(binding["project_binding_id"]),
        version=str(binding["version"]),
        canonical_sha256=binding_sha256,
    )
    adapter_ref = binding.get("execution_adapter_ref")
    if not isinstance(adapter_ref, Mapping):
        raise StageAuthorizationError("project_binding_execution_adapter_ref_invalid")
    _require_component_canonical_ref(
        material,
        artifact_type="execution_adapter",
        component_id=str(adapter_ref.get("component_id")),
        version=str(adapter_ref.get("version")),
        canonical_sha256=str(adapter_ref.get("canonical_sha256")),
    )
    expected_engine_ref = {
        "component_id": profile_value["engine_profile_id"],
        "version": profile_value["version"],
        "canonical_sha256": profile_sha256,
    }
    if (
        binding.get("engine_profile_id") != profile_value["engine_profile_id"]
        or binding.get("engine_profile_ref") != expected_engine_ref
    ):
        raise StageAuthorizationError("project_binding_engine_profile_ref_mismatch")
    if binding.get("binding_scope") != "host_exact":
        raise StageAuthorizationError("project_binding_not_host_exact")
    if binding.get("execution_mode") != "project_write_admitted":
        raise StageAuthorizationError("project_binding_project_write_not_admitted")
    if material.get("execution_mode") != "project_write_admitted":
        raise StageAuthorizationError("assembly_execution_mode_not_admitted")
    if material.get("execution_ready") is not True:
        raise StageAuthorizationError("assembly_execution_not_ready")
    project_id = str(binding["project_id"])
    family = _project_family(project_id)
    if selected_command_id not in SUPPORTED_PROJECT_COMMANDS[family]:
        raise StageAuthorizationError("command_not_supported_for_project")
    if selected_command_id not in binding.get("allowed_command_ids", []):
        raise StageAuthorizationError("project_binding_command_not_allowed")

    stage_matches = [
        item
        for item in material.get("stage_resolution", [])
        if isinstance(item, Mapping) and item.get("stage_id") == selected_stage_id
    ]
    if len(stage_matches) != 1:
        raise StageAuthorizationError("assembly_stage_not_exactly_resolved")
    stage = stage_matches[0]
    disposition = stage.get("disposition")
    if disposition not in {"required", "optional"}:
        raise StageAuthorizationError("assembly_stage_not_authorized", str(disposition))
    clause = stage.get("controlling_clause_ref")
    if not isinstance(clause, str) or not clause:
        raise StageAuthorizationError("assembly_stage_not_explicitly_bound")
    if disposition == "required" and stage.get("blocking") is not True:
        raise StageAuthorizationError("required_stage_not_blocking")
    if disposition == "optional" and stage.get("blocking") is not False:
        raise StageAuthorizationError("optional_stage_not_explicit_nonblocking")
    if stage.get("permission_status") != "permitted":
        raise StageAuthorizationError(
            "assembly_stage_permission_not_permitted",
            str(stage.get("permission_status")),
        )
    if stage.get("execution_kind") != "engine_command":
        raise StageAuthorizationError("assembly_stage_not_engine_command")

    graph_matches = [
        item
        for item in material.get("command_graph", [])
        if isinstance(item, Mapping) and item.get("stage_id") == selected_stage_id
    ]
    if len(graph_matches) != 1:
        raise StageAuthorizationError("assembly_command_graph_stage_not_exact")
    graph = graph_matches[0]
    profile_matches = [
        item
        for item in profile_value["commands"]
        if item["command_id"] == selected_command_id
    ]
    if len(profile_matches) != 1:
        raise StageAuthorizationError("profile_command_not_exact")
    command = profile_matches[0]
    expected_graph = {
        "stage_id": selected_stage_id,
        "execution_kind": "engine_command",
        "operation_id": command["operation_id"],
        "command_id": selected_command_id,
        "executable_ref": command["executable_ref"],
        "arguments": command["arguments"],
    }
    if graph != expected_graph:
        raise StageAuthorizationError("assembly_command_graph_mismatch")
    if (
        stage.get("stage_family") != command["stage_family"]
        or stage.get("operation_id") != command["operation_id"]
    ):
        raise StageAuthorizationError("assembly_stage_profile_command_mismatch")

    raw_root = Path(str(binding["project_root"]))
    if not raw_root.is_absolute():
        raise StageAuthorizationError("project_binding_root_not_absolute")
    try:
        project_root = raw_root.resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise StageAuthorizationError("project_binding_root_unavailable") from exc
    if raw_root.is_symlink() or not project_root.is_dir() or str(project_root) != str(raw_root):
        raise StageAuthorizationError("project_binding_root_not_canonical")
    try:
        subroot = _validate_project_subroot(binding["project_subroot"])
        commit = _validate_git_object(
            binding["source_identity"]["commit"], label="source_commit"
        )
        tree = _validate_git_object(
            binding["source_identity"]["tree"], label="source_tree"
        )
    except SnapshotBoundaryError as exc:
        raise StageAuthorizationError("project_binding_source_identity_invalid", str(exc)) from exc
    return VerifiedStageAuthorization(
        assembly_sha256=assembly_sha256,
        project_binding_id=str(binding["project_binding_id"]),
        project_binding_sha256=binding_sha256,
        project_id=project_id,
        project_family=family,
        project_root=str(project_root),
        project_subroot=subroot,
        source_commit=commit,
        source_tree=tree,
        selected_stage_id=selected_stage_id,
        selected_command_id=selected_command_id,
        stage_family=str(stage["stage_family"]),
        operation_id=str(stage["operation_id"]),
        disposition=str(disposition),
        permission_status="permitted",
        executable_ref=str(command["executable_ref"]),
        command_arguments=tuple(str(item) for item in command["arguments"]),
    )


def verify_host_tool_identity(
    host_tool_identity: Mapping[str, Any] | str | Path,
    *,
    requirement: Mapping[str, Any] | str | Path = DEFAULT_HOST_TOOL_REQUIREMENT_PATH,
    timeout_seconds: float = 10.0,
) -> VerifiedHostTool:
    """Recompute path/version/SHA identity without invoking any project."""

    required = load_host_tool_requirement(requirement)
    return _verify_host_tool_identity(
        host_tool_identity, required=required, timeout_seconds=timeout_seconds
    )


def verify_git_tool_identity(
    git_tool_identity: Mapping[str, Any] | str | Path,
    *,
    requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_GIT_HOST_TOOL_REQUIREMENT_PATH
    ),
    timeout_seconds: float = 10.0,
) -> VerifiedHostTool:
    """Freshly verify the exact Git executable used for source operations."""

    required = load_git_host_tool_requirement(requirement)
    return _verify_host_tool_identity(
        git_tool_identity, required=required, timeout_seconds=timeout_seconds
    )


def _verify_host_tool_identity(
    host_tool_identity: Mapping[str, Any] | str | Path,
    *,
    required: Mapping[str, Any],
    timeout_seconds: float,
) -> VerifiedHostTool:
    supplied = _mapping_or_json_path(host_tool_identity, label="host_tool_identity")
    if set(supplied) != _HOST_IDENTITY_KEYS:
        raise HostToolIdentityError("host_tool_identity_shape_invalid")
    if supplied.get("schema_version") != "1.0.0" or supplied.get(
        "artifact_type"
    ) != "host_tool_identity":
        raise HostToolIdentityError("host_tool_identity_header_invalid")
    if supplied.get("executable_ref") != required["executable_ref"]:
        raise HostToolIdentityError("host_tool_executable_ref_mismatch")
    raw_path = supplied.get("executable_path")
    if not isinstance(raw_path, str) or not raw_path:
        raise HostToolIdentityError("host_tool_path_invalid")
    lexical = Path(raw_path)
    if not lexical.is_absolute():
        raise HostToolIdentityError("host_tool_path_not_absolute", raw_path)
    try:
        executable = lexical.resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise HostToolIdentityError("host_tool_unavailable", raw_path) from exc
    if lexical.is_symlink() or not executable.is_file() or not os.access(executable, os.X_OK):
        raise HostToolIdentityError("host_tool_not_executable_regular_file", str(executable))
    if str(executable) != raw_path:
        raise HostToolIdentityError("host_tool_path_not_canonical", raw_path)
    if required["required_platform"] == "macos" and platform.system() != "Darwin":
        raise HostToolIdentityError("host_tool_platform_mismatch", platform.system())
    supplied_digest = supplied.get("binary_sha256")
    if not isinstance(supplied_digest, str) or _SHA256_PATTERN.fullmatch(supplied_digest) is None:
        raise HostToolIdentityError("host_tool_supplied_digest_invalid")
    try:
        initial_byte_count = executable.stat().st_size
    except OSError as exc:
        raise HostToolIdentityError("host_tool_unavailable", str(executable)) from exc
    actual_digest = _file_sha256(executable)
    if supplied_digest != actual_digest:
        raise HostToolIdentityError("host_tool_supplied_digest_mismatch")
    if actual_digest not in required["accepted_binary_sha256"]:
        raise HostToolIdentityError("host_tool_binary_not_accepted")
    capabilities = _require_string_list(
        supplied.get("capabilities"), code="host_tool_capabilities_invalid"
    )
    if capabilities != tuple(required["required_capabilities"]):
        raise HostToolIdentityError("host_tool_capabilities_mismatch")
    normalized_timeout = _bounded_timeout(
        timeout_seconds,
        code="host_tool_probe_timeout_invalid",
        maximum=_MAX_HOST_TOOL_PROBE_TIMEOUT_SECONDS,
        error_type=HostToolIdentityError,
    )
    argv = [str(executable), *required["version_probe_arguments"]]
    try:
        result = subprocess.run(
            argv,
            check=False,
            capture_output=True,
            text=False,
            timeout=normalized_timeout,
            shell=False,
        )
    except FileNotFoundError as exc:
        raise HostToolIdentityError("host_tool_unavailable", str(executable)) from exc
    except subprocess.TimeoutExpired as exc:
        raise HostToolIdentityError("host_tool_version_probe_timeout") from exc
    except OSError as exc:
        raise HostToolIdentityError("host_tool_version_probe_unavailable", str(exc)) from exc
    if result.returncode != 0:
        raise HostToolIdentityError(
            "host_tool_version_probe_failed", str(result.returncode)
        )
    try:
        observed_version = result.stdout.decode("utf-8", errors="strict").strip()
    except UnicodeDecodeError as exc:
        raise HostToolIdentityError("host_tool_version_probe_not_utf8") from exc
    if not observed_version or "\n" in observed_version or "\r" in observed_version:
        raise HostToolIdentityError("host_tool_version_probe_shape_invalid")
    if supplied.get("reported_version") != observed_version:
        raise HostToolIdentityError("host_tool_supplied_version_mismatch")
    if observed_version not in required["accepted_reported_versions"]:
        raise HostToolIdentityError("host_tool_version_not_accepted")
    try:
        final_byte_count = executable.stat().st_size
    except OSError as exc:
        raise HostToolIdentityError("host_tool_changed_during_probe") from exc
    if (
        final_byte_count != initial_byte_count
        or _file_sha256(executable) != actual_digest
    ):
        raise HostToolIdentityError("host_tool_changed_during_probe")
    return VerifiedHostTool(
        executable_ref=required["executable_ref"],
        executable_path=str(executable),
        reported_version=observed_version,
        binary_sha256=actual_digest,
        byte_count=final_byte_count,
        capabilities=tuple(capabilities),
        requirement_id=required["requirement_id"],
        requirement_sha256=_json_sha256(required),
        version_probe_arguments=tuple(required["version_probe_arguments"]),
    )


def _validate_identifier(value: Any, *, label: str) -> str:
    if not isinstance(value, str) or _IDENTIFIER_PATTERN.fullmatch(value) is None:
        raise SnapshotBoundaryError(f"{label}_invalid")
    return value


def _validate_execution_id(value: Any) -> str:
    if not isinstance(value, str) or _EXECUTION_ID_PATTERN.fullmatch(value) is None:
        raise SnapshotBoundaryError("execution_id_invalid")
    return value


def _validate_git_object(value: Any, *, label: str) -> str:
    if not isinstance(value, str) or _GIT_OBJECT_PATTERN.fullmatch(value) is None:
        raise SnapshotBoundaryError(f"{label}_invalid")
    return value


def _validate_project_subroot(value: Any) -> str:
    if value == ".":
        return "."
    if not isinstance(value, str) or not value or "\\" in value or "\x00" in value:
        raise SnapshotBoundaryError("project_subroot_unsafe")
    path = PurePosixPath(value)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise SnapshotBoundaryError("project_subroot_unsafe")
    if path.as_posix() != value:
        raise SnapshotBoundaryError("project_subroot_not_canonical")
    return value


def _paths_disjoint(first: Path, second: Path) -> bool:
    return first != second and first not in second.parents and second not in first.parents


def _read_only_git_environment() -> dict[str, str]:
    environment = os.environ.copy()
    environment["GIT_OPTIONAL_LOCKS"] = "0"
    environment["GIT_TERMINAL_PROMPT"] = "0"
    return environment


def _run_git_text(repository: Path, git_binary: Path, *arguments: str) -> str:
    argv = [str(git_binary), "-C", str(repository), *arguments]
    try:
        result = subprocess.run(
            argv,
            check=False,
            capture_output=True,
            text=True,
            timeout=30,
            shell=False,
            env=_read_only_git_environment(),
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise SnapshotBoundaryError("git_inspection_unavailable", str(exc)) from exc
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        raise SnapshotBoundaryError("git_inspection_failed", detail)
    return result.stdout


def _require_source_identity(
    source_clone_root: Path,
    *,
    expected_commit: str,
    expected_tree: str,
    git_binary: Path,
) -> None:
    top = _run_git_text(
        source_clone_root, git_binary, "rev-parse", "--show-toplevel"
    ).strip()
    try:
        repository_root = Path(top).resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise SnapshotBoundaryError("git_repository_root_invalid", top) from exc
    if repository_root != source_clone_root:
        raise SnapshotBoundaryError("source_clone_root_not_git_toplevel")
    head = _run_git_text(source_clone_root, git_binary, "rev-parse", "HEAD").strip()
    if head != expected_commit:
        raise SnapshotBoundaryError("source_commit_mismatch", head)
    tree = _run_git_text(
        source_clone_root, git_binary, "rev-parse", "HEAD^{tree}"
    ).strip()
    if tree != expected_tree:
        raise SnapshotBoundaryError("source_tree_mismatch", tree)
    status = _run_git_text(
        source_clone_root,
        git_binary,
        "status",
        "--porcelain=v1",
        "--untracked-files=all",
    )
    if status:
        raise SnapshotBoundaryError("source_clone_dirty", status.splitlines()[0])


def _write_git_archive(
    repository: Path,
    git_binary: Path,
    commit: str,
    destination: BinaryIO,
) -> None:
    argv = [
        str(git_binary),
        "-C",
        str(repository),
        "archive",
        "--format=tar",
        commit,
    ]
    try:
        result = subprocess.run(
            argv,
            check=False,
            stdout=destination,
            stderr=subprocess.PIPE,
            timeout=120,
            shell=False,
            env=_read_only_git_environment(),
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise SnapshotBoundaryError("git_archive_unavailable", str(exc)) from exc
    if result.returncode != 0:
        detail = result.stderr.decode("utf-8", errors="replace").strip()
        raise SnapshotBoundaryError("git_archive_failed", detail)


def _archive_sha256(handle: BinaryIO) -> str:
    handle.seek(0)
    digest = hashlib.sha256()
    for chunk in iter(lambda: handle.read(1024 * 1024), b""):
        digest.update(chunk)
    handle.seek(0)
    return digest.hexdigest()


def _safe_archive_name(name: str) -> PurePosixPath:
    if not name or "\\" in name or "\x00" in name:
        raise SnapshotBoundaryError("git_archive_member_path_unsafe", name)
    pure = PurePosixPath(name)
    if pure.is_absolute() or any(part in {"", ".", ".."} for part in pure.parts):
        raise SnapshotBoundaryError("git_archive_member_path_unsafe", name)
    return pure


def _extract_git_archive(handle: BinaryIO, snapshot_root: Path) -> None:
    handle.seek(0)
    try:
        archive = tarfile.open(fileobj=handle, mode="r:")
    except tarfile.TarError as exc:
        raise SnapshotBoundaryError("git_archive_tar_invalid", str(exc)) from exc
    with archive:
        members = archive.getmembers()
        seen: set[str] = set()
        normalized: list[tuple[tarfile.TarInfo, PurePosixPath]] = []
        for member in members:
            pure = _safe_archive_name(member.name.rstrip("/") if member.isdir() else member.name)
            canonical = pure.as_posix()
            if canonical in seen:
                raise SnapshotBoundaryError("git_archive_member_duplicate", canonical)
            seen.add(canonical)
            if not (member.isdir() or member.isreg()):
                raise SnapshotBoundaryError(
                    "git_archive_member_type_unsupported", canonical
                )
            normalized.append((member, pure))
        for member, pure in normalized:
            target = snapshot_root.joinpath(*pure.parts)
            if snapshot_root not in target.parents:
                raise SnapshotBoundaryError("git_archive_member_path_escape", member.name)
            if member.isdir():
                target.mkdir(parents=True, exist_ok=False)
                target.chmod(0o755)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            source = archive.extractfile(member)
            if source is None:
                raise SnapshotBoundaryError("git_archive_member_unreadable", member.name)
            try:
                with target.open("xb") as output:
                    shutil.copyfileobj(source, output, length=1024 * 1024)
            except OSError as exc:
                raise SnapshotBoundaryError(
                    "git_archive_member_write_failed", member.name
                ) from exc
            target.chmod(0o755 if member.mode & 0o111 else 0o644)


def _snapshot_payload_manifest(
    *,
    snapshot_root: Path,
    godot_root: Path,
    override_path: Path | None,
    allow_runtime_cache: bool,
) -> tuple[str, int]:
    """Digest all materialized files except the unique override/runtime cache."""

    runtime_cache = godot_root / ".godot"
    if runtime_cache.is_symlink():
        raise SnapshotBoundaryError("snapshot_runtime_cache_symlink")
    if runtime_cache.exists() and not allow_runtime_cache:
        raise SnapshotBoundaryError("tracked_godot_cache_conflict")
    if runtime_cache.exists() and not runtime_cache.is_dir():
        raise SnapshotBoundaryError("snapshot_runtime_cache_not_directory")
    entries: list[dict[str, Any]] = []
    try:
        paths = sorted(snapshot_root.rglob("*"), key=lambda item: item.as_posix())
    except OSError as exc:
        raise SnapshotBoundaryError("snapshot_payload_scan_failed", str(exc)) from exc
    for path in paths:
        if path.is_symlink():
            raise SnapshotBoundaryError("snapshot_payload_symlink", str(path))
        if override_path is not None and path == override_path:
            continue
        if path == runtime_cache or runtime_cache in path.parents:
            continue
        if path.is_dir():
            continue
        if not path.is_file():
            raise SnapshotBoundaryError("snapshot_payload_type_unsupported", str(path))
        relative = path.relative_to(snapshot_root).as_posix()
        entries.append(
            {
                "path": relative,
                "mode": stat.S_IMODE(path.stat().st_mode),
                "byte_count": path.stat().st_size,
                "sha256": _file_sha256(path),
            }
        )
    return _json_sha256({"files": entries}), len(entries)


def _snapshot_object_inventory(
    *,
    snapshot_root: Path,
    godot_root: Path,
    override_path: Path | None,
    allow_runtime_cache: bool,
) -> tuple[dict[str, Any], ...]:
    """Describe every non-exempt filesystem object under one snapshot."""

    runtime_cache = godot_root / ".godot"
    if runtime_cache.is_symlink():
        raise SnapshotBoundaryError("snapshot_runtime_cache_symlink")
    if runtime_cache.exists() and not allow_runtime_cache:
        raise SnapshotBoundaryError("tracked_godot_cache_conflict")
    if runtime_cache.exists() and not runtime_cache.is_dir():
        raise SnapshotBoundaryError("snapshot_runtime_cache_not_directory")
    try:
        paths = sorted(snapshot_root.rglob("*"), key=lambda item: item.as_posix())
    except OSError as exc:
        raise SnapshotBoundaryError("snapshot_object_scan_failed", str(exc)) from exc
    inventory: list[dict[str, Any]] = []
    for path in paths:
        if path.is_symlink():
            raise SnapshotBoundaryError("snapshot_payload_symlink", str(path))
        if override_path is not None and path == override_path:
            continue
        if path == runtime_cache or runtime_cache in path.parents:
            continue
        relative = path.relative_to(snapshot_root).as_posix()
        mode = stat.S_IMODE(path.stat().st_mode)
        if path.is_dir():
            inventory.append({"path": relative, "type": "directory", "mode": mode})
        elif path.is_file():
            inventory.append(
                {
                    "path": relative,
                    "type": "file",
                    "mode": mode,
                    "byte_count": path.stat().st_size,
                    "sha256": _file_sha256(path),
                }
            )
        else:
            raise SnapshotBoundaryError("snapshot_payload_type_unsupported", str(path))
    return tuple(inventory)


def _fresh_archive_snapshot_identity(
    *,
    source: Path,
    source_commit: str,
    project_subroot: str,
    snapshot_root: Path,
    godot_root: Path,
    override_path: Path,
    git_binary: Path,
    allow_runtime_cache: bool,
) -> tuple[str, str, int, str]:
    """Freshly derive tracked bytes and require exact snapshot object equality."""

    with tempfile.TemporaryFile(mode="w+b") as archive_file:
        _write_git_archive(source, git_binary, source_commit, archive_file)
        archive_digest = _archive_sha256(archive_file)
        with tempfile.TemporaryDirectory(prefix="v497-git-archive-") as temporary:
            expected_root = Path(temporary) / "snapshot"
            expected_root.mkdir(mode=0o700)
            _extract_git_archive(archive_file, expected_root)
            expected_godot_root = (
                expected_root
                if project_subroot == "."
                else expected_root.joinpath(*PurePosixPath(project_subroot).parts)
            )
            if not expected_godot_root.is_dir() or expected_godot_root.is_symlink():
                raise SnapshotBoundaryError("fresh_archive_godot_root_missing")
            expected_override = expected_godot_root / "override.cfg"
            if expected_override.exists() or expected_override.is_symlink():
                raise SnapshotBoundaryError("tracked_override_cfg_conflict")
            expected_inventory = _snapshot_object_inventory(
                snapshot_root=expected_root,
                godot_root=expected_godot_root,
                override_path=None,
                allow_runtime_cache=False,
            )
            actual_inventory = _snapshot_object_inventory(
                snapshot_root=snapshot_root,
                godot_root=godot_root,
                override_path=override_path,
                allow_runtime_cache=allow_runtime_cache,
            )
            if actual_inventory != expected_inventory:
                raise SnapshotBoundaryError(
                    "snapshot_fresh_archive_object_mismatch"
                )
            payload_digest, payload_file_count = _snapshot_payload_manifest(
                snapshot_root=expected_root,
                godot_root=expected_godot_root,
                override_path=None,
                allow_runtime_cache=False,
            )
            project_marker = expected_godot_root / "project.godot"
            if project_marker.is_symlink() or not project_marker.is_file():
                raise SnapshotBoundaryError("fresh_archive_project_godot_missing")
            project_godot_sha256 = _file_sha256(project_marker)
    return (
        archive_digest,
        payload_digest,
        payload_file_count,
        project_godot_sha256,
    )


def _custom_user_dir_seed(
    *,
    project_id: str,
    source_commit: str,
    source_tree: str,
    execution_id: str,
    snapshot_root: Path,
) -> str:
    return _json_sha256(
        {
            "profile_id": PROFILE_ID,
            "project_id": project_id,
            "source_commit": source_commit,
            "source_tree": source_tree,
            "execution_id": execution_id,
            "snapshot_root": str(snapshot_root),
        }
    )


def expected_custom_user_dir_name(
    *,
    project_id: str,
    source_commit: str,
    source_tree: str,
    execution_id: str,
    snapshot_root: str | Path,
) -> str:
    """Derive a single safe macOS Application Support component."""

    project = _validate_identifier(project_id, label="project_id")
    commit = _validate_git_object(source_commit, label="source_commit")
    tree = _validate_git_object(source_tree, label="source_tree")
    execution = _validate_execution_id(execution_id)
    raw_snapshot = Path(snapshot_root)
    if not raw_snapshot.is_absolute():
        raise SnapshotBoundaryError("snapshot_root_not_absolute")
    snapshot = raw_snapshot.parent.resolve(strict=False) / raw_snapshot.name
    seed = _custom_user_dir_seed(
        project_id=project,
        source_commit=commit,
        source_tree=tree,
        execution_id=execution,
        snapshot_root=snapshot,
    )
    name = f"ai_game_dev_os_v497_{project}_{seed[:24]}"
    if _CUSTOM_USER_DIR_PATTERN.fullmatch(name) is None:
        raise SnapshotBoundaryError("derived_custom_user_dir_unsafe")
    return name


def _override_bytes(custom_user_dir_name: str) -> bytes:
    if _CUSTOM_USER_DIR_PATTERN.fullmatch(custom_user_dir_name) is None:
        raise SnapshotBoundaryError("custom_user_dir_unsafe")
    return (
        "[application]\n"
        "config/use_custom_user_dir=true\n"
        f"config/custom_user_dir_name={json.dumps(custom_user_dir_name)}\n"
    ).encode("utf-8")


def _new_receipt(
    *,
    profile_sha256: str,
    authorization: VerifiedStageAuthorization,
    project_id: str,
    execution_id: str,
    source_clone_root: Path,
    source_commit: str,
    source_tree: str,
    git_archive_sha256: str,
    godot_host_tool: VerifiedHostTool,
    git_host_tool: VerifiedHostTool,
    snapshot_root: Path,
    project_subroot: str,
    godot_root: Path,
    project_godot_sha256: str,
    snapshot_payload_manifest_sha256: str,
    snapshot_payload_file_count: int,
    override_content: bytes,
    custom_user_dir_name: str,
    custom_user_dir_seed_sha256: str,
    evidence_root: Path,
    build_root: Path,
    log_root: Path,
    cache_root: Path,
) -> ExecutionSnapshotReceipt:
    override_path = godot_root / "override.cfg"
    receipt_path = evidence_root / "godot_execution_snapshot_receipt.json"
    common = dict(
        profile_id=PROFILE_ID,
        profile_sha256=profile_sha256,
        assembly_sha256=authorization.assembly_sha256,
        project_binding_id=authorization.project_binding_id,
        project_binding_sha256=authorization.project_binding_sha256,
        selected_stage_id=authorization.selected_stage_id,
        authorized_command_id=authorization.selected_command_id,
        stage_disposition=authorization.disposition,
        project_id=project_id,
        execution_id=execution_id,
        source_clone_root=str(source_clone_root),
        source_commit=source_commit,
        source_tree=source_tree,
        git_archive_sha256=git_archive_sha256,
        godot_host_tool_binding_json=_canonical_json_bytes(
            godot_host_tool.binding_record()
        ).decode("utf-8"),
        git_host_tool_binding_json=_canonical_json_bytes(
            git_host_tool.binding_record()
        ).decode("utf-8"),
        snapshot_root=str(snapshot_root),
        project_subroot=project_subroot,
        godot_root=str(godot_root),
        project_godot_sha256=project_godot_sha256,
        snapshot_payload_manifest_sha256=snapshot_payload_manifest_sha256,
        snapshot_payload_file_count=snapshot_payload_file_count,
        override_relative_path=override_path.relative_to(snapshot_root).as_posix(),
        override_content_base64=base64.b64encode(override_content).decode("ascii"),
        override_sha256=hashlib.sha256(override_content).hexdigest(),
        custom_user_dir_name=custom_user_dir_name,
        custom_user_dir_seed_sha256=custom_user_dir_seed_sha256,
        macos_application_support_relative_path=custom_user_dir_name,
        evidence_root=str(evidence_root),
        build_root=str(build_root),
        log_root=str(log_root),
        cache_root=str(cache_root),
        receipt_path=str(receipt_path),
        non_claims=SNAPSHOT_NON_CLAIMS,
    )
    provisional = ExecutionSnapshotReceipt(receipt_sha256="0" * 64, **common)
    return ExecutionSnapshotReceipt(
        receipt_sha256=_json_sha256(
            ExecutionSnapshotReceipt.payload(provisional)
        ),
        **common,
    )


def materialize_execution_snapshot(
    *,
    assembly_lock: Mapping[str, Any] | str | Path,
    assembly_component_paths: Sequence[str | Path],
    project_binding: Mapping[str, Any] | str | Path,
    selected_stage_id: str,
    selected_command_id: str,
    host_tool_identity: Mapping[str, Any] | str | Path,
    git_tool_identity: Mapping[str, Any] | str | Path,
    source_clone_root: str | Path,
    expected_commit: str,
    expected_tree: str,
    project_id: str,
    project_subroot: str,
    external_root: str | Path,
    execution_id: str,
    custom_user_dir_name: str | None = None,
    profile: Mapping[str, Any] | str | Path = DEFAULT_ENGINE_PROFILE_PATH,
    host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_HOST_TOOL_REQUIREMENT_PATH
    ),
    git_host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_GIT_HOST_TOOL_REQUIREMENT_PATH
    ),
) -> ExecutionSnapshotReceipt:
    """Create one fresh tracked-only snapshot and durable provenance receipt.

    ``external_root`` must already exist.  The function creates exactly one
    new ``<external_root>/<execution_id>`` run root.  Its ``snapshot`` child is
    the only project root eligible for later Godot argv construction.
    """

    host_requirement_value = load_host_tool_requirement(host_tool_requirement)
    git_requirement_value = load_git_host_tool_requirement(
        git_host_tool_requirement
    )
    profile_value = load_engine_profile(
        profile,
        host_tool_requirement=host_requirement_value,
        git_host_tool_requirement=git_requirement_value,
    )
    godot_host_tool = verify_host_tool_identity(
        host_tool_identity, requirement=host_requirement_value
    )
    git_host_tool = verify_git_tool_identity(
        git_tool_identity, requirement=git_requirement_value
    )
    profile_digest = _json_sha256(profile_value)
    project = _validate_identifier(project_id, label="project_id")
    authorization = verify_stage_authorization(
        assembly_lock=assembly_lock,
        assembly_component_paths=assembly_component_paths,
        project_binding=project_binding,
        selected_stage_id=selected_stage_id,
        selected_command_id=selected_command_id,
        profile=profile_value,
        host_tool_requirement=host_requirement_value,
        git_host_tool_requirement=git_requirement_value,
    )
    if authorization.project_id != project:
        raise StageAuthorizationError("project_binding_project_id_mismatch")
    execution = _validate_execution_id(execution_id)
    commit = _validate_git_object(expected_commit, label="expected_commit")
    tree = _validate_git_object(expected_tree, label="expected_tree")
    subroot = _validate_project_subroot(project_subroot)
    raw_source = Path(source_clone_root)
    if not raw_source.is_absolute():
        raise SnapshotBoundaryError("source_clone_root_not_absolute")
    try:
        source = raw_source.resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise SnapshotBoundaryError("source_clone_root_missing") from exc
    if raw_source.is_symlink() or not source.is_dir() or str(source) != str(raw_source):
        raise SnapshotBoundaryError("source_clone_root_not_canonical")
    if str(source) != authorization.project_root:
        raise StageAuthorizationError("project_binding_root_mismatch")
    if commit != authorization.source_commit:
        raise StageAuthorizationError("project_binding_commit_mismatch")
    if tree != authorization.source_tree:
        raise StageAuthorizationError("project_binding_tree_mismatch")
    if subroot != authorization.project_subroot:
        raise StageAuthorizationError("project_binding_subroot_mismatch")
    raw_external = Path(external_root)
    if not raw_external.is_absolute():
        raise SnapshotBoundaryError("external_root_not_absolute")
    try:
        external = raw_external.resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise SnapshotBoundaryError("external_root_missing") from exc
    if raw_external.is_symlink() or not external.is_dir() or str(external) != str(raw_external):
        raise SnapshotBoundaryError("external_root_not_canonical")
    run_root = external / execution
    snapshot_root = run_root / "snapshot"
    evidence_root = run_root / "evidence"
    build_root = run_root / "build"
    log_root = run_root / "logs"
    cache_root = run_root / "cache"
    if snapshot_root.exists() or snapshot_root.is_symlink():
        raise SnapshotBoundaryError("snapshot_already_exists")
    if run_root.exists() or run_root.is_symlink():
        raise SnapshotBoundaryError("execution_run_root_exists")
    if not _paths_disjoint(source, run_root):
        raise SnapshotBoundaryError("external_snapshot_overlaps_source_clone")
    package_root = VERSION_ROOT.resolve(strict=True)
    if not _paths_disjoint(package_root, source):
        raise SnapshotBoundaryError("source_clone_overlaps_os_package")
    if not _paths_disjoint(package_root, run_root):
        raise SnapshotBoundaryError("external_snapshot_overlaps_os_package")
    git = Path(git_host_tool.executable_path)
    _require_source_identity(
        source,
        expected_commit=commit,
        expected_tree=tree,
        git_binary=git,
    )
    derived_custom_name = expected_custom_user_dir_name(
        project_id=project,
        source_commit=commit,
        source_tree=tree,
        execution_id=execution,
        snapshot_root=snapshot_root,
    )
    if custom_user_dir_name is not None:
        if not isinstance(custom_user_dir_name, str) or _CUSTOM_USER_DIR_PATTERN.fullmatch(
            custom_user_dir_name
        ) is None:
            raise SnapshotBoundaryError("custom_user_dir_unsafe")
        if custom_user_dir_name != derived_custom_name:
            raise SnapshotBoundaryError("custom_user_dir_not_identity_bound")
    override_content = _override_bytes(derived_custom_name)
    created = False
    try:
        with tempfile.TemporaryFile(mode="w+b") as archive_file:
            _write_git_archive(source, git, commit, archive_file)
            archive_digest = _archive_sha256(archive_file)
            run_root.mkdir(mode=0o700)
            created = True
            snapshot_root.mkdir(mode=0o700)
            evidence_root.mkdir(mode=0o700)
            build_root.mkdir(mode=0o700)
            log_root.mkdir(mode=0o700)
            cache_root.mkdir(mode=0o700)
            _extract_git_archive(archive_file, snapshot_root)
        godot_root = snapshot_root if subroot == "." else snapshot_root.joinpath(
            *PurePosixPath(subroot).parts
        )
        if not godot_root.is_dir() or godot_root.is_symlink():
            raise SnapshotBoundaryError("snapshot_godot_root_missing")
        project_marker = godot_root / "project.godot"
        if project_marker.is_symlink() or not project_marker.is_file():
            raise SnapshotBoundaryError("snapshot_project_godot_missing")
        override_path = godot_root / "override.cfg"
        if override_path.exists() or override_path.is_symlink():
            raise SnapshotBoundaryError("tracked_override_cfg_conflict")
        payload_manifest_digest, payload_file_count = _snapshot_payload_manifest(
            snapshot_root=snapshot_root,
            godot_root=godot_root,
            override_path=None,
            allow_runtime_cache=False,
        )
        override_path.write_bytes(override_content)
        override_path.chmod(0o600)
        seed = _custom_user_dir_seed(
            project_id=project,
            source_commit=commit,
            source_tree=tree,
            execution_id=execution,
            snapshot_root=snapshot_root,
        )
        receipt = _new_receipt(
            profile_sha256=profile_digest,
            authorization=authorization,
            project_id=project,
            execution_id=execution,
            source_clone_root=source,
            source_commit=commit,
            source_tree=tree,
            git_archive_sha256=archive_digest,
            godot_host_tool=godot_host_tool,
            git_host_tool=git_host_tool,
            snapshot_root=snapshot_root,
            project_subroot=subroot,
            godot_root=godot_root,
            project_godot_sha256=_file_sha256(project_marker),
            snapshot_payload_manifest_sha256=payload_manifest_digest,
            snapshot_payload_file_count=payload_file_count,
            override_content=override_content,
            custom_user_dir_name=derived_custom_name,
            custom_user_dir_seed_sha256=seed,
            evidence_root=evidence_root,
            build_root=build_root,
            log_root=log_root,
            cache_root=cache_root,
        )
        Path(receipt.receipt_path).write_bytes(
            _canonical_json_bytes(ExecutionSnapshotReceipt.to_dict(receipt))
            + b"\n"
        )
        _require_source_identity(
            source,
            expected_commit=commit,
            expected_tree=tree,
            git_binary=git,
        )
        verify_execution_snapshot(
            receipt,
            assembly_lock=assembly_lock,
            assembly_component_paths=assembly_component_paths,
            project_binding=project_binding,
            selected_stage_id=selected_stage_id,
            selected_command_id=selected_command_id,
            host_tool_identity=host_tool_identity,
            git_tool_identity=git_tool_identity,
            profile=profile_value,
            host_tool_requirement=host_requirement_value,
            git_host_tool_requirement=git_requirement_value,
        )
        return receipt
    except Exception:
        if created and run_root.exists() and not run_root.is_symlink():
            shutil.rmtree(run_root)
        raise


def _verify_execution_snapshot(
    receipt: ExecutionSnapshotReceipt,
    *,
    assembly_lock: Mapping[str, Any] | str | Path,
    assembly_component_paths: Sequence[str | Path],
    project_binding: Mapping[str, Any] | str | Path,
    selected_stage_id: str,
    selected_command_id: str,
    host_tool_identity: Mapping[str, Any] | str | Path,
    git_tool_identity: Mapping[str, Any] | str | Path,
    profile: Mapping[str, Any] | str | Path = DEFAULT_ENGINE_PROFILE_PATH,
    host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_HOST_TOOL_REQUIREMENT_PATH
    ),
    git_host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_GIT_HOST_TOOL_REQUIREMENT_PATH
    ),
    allow_runtime_cache: bool,
    expected_consumed_marker: bytes | None,
) -> ExecutionSnapshotReceipt:
    """Shared verifier; only the post-process path may admit Godot cache."""

    if allow_runtime_cache != (expected_consumed_marker is not None):
        raise SnapshotBoundaryError("snapshot_post_execution_state_invalid")

    if type(receipt) is not ExecutionSnapshotReceipt:
        raise SnapshotBoundaryError("snapshot_receipt_type_invalid")
    _require_snapshot_receipt_shape(receipt)
    host_requirement_value = load_host_tool_requirement(host_tool_requirement)
    git_requirement_value = load_git_host_tool_requirement(
        git_host_tool_requirement
    )
    profile_value = load_engine_profile(
        profile,
        host_tool_requirement=host_requirement_value,
        git_host_tool_requirement=git_requirement_value,
    )
    godot_host_tool = verify_host_tool_identity(
        host_tool_identity, requirement=host_requirement_value
    )
    git_host_tool = verify_git_tool_identity(
        git_tool_identity, requirement=git_requirement_value
    )
    authorization = verify_stage_authorization(
        assembly_lock=assembly_lock,
        assembly_component_paths=assembly_component_paths,
        project_binding=project_binding,
        selected_stage_id=selected_stage_id,
        selected_command_id=selected_command_id,
        profile=profile_value,
        host_tool_requirement=host_requirement_value,
        git_host_tool_requirement=git_requirement_value,
    )
    if receipt.profile_id != profile_value["engine_profile_id"] or receipt.profile_sha256 != _json_sha256(
        profile_value
    ):
        raise SnapshotBoundaryError("snapshot_profile_identity_mismatch")
    if (
        receipt.assembly_sha256 != authorization.assembly_sha256
        or receipt.project_binding_id != authorization.project_binding_id
        or receipt.project_binding_sha256 != authorization.project_binding_sha256
        or receipt.selected_stage_id != authorization.selected_stage_id
        or receipt.authorized_command_id != authorization.selected_command_id
        or receipt.stage_disposition != authorization.disposition
    ):
        raise StageAuthorizationError("snapshot_execution_authorization_mismatch")
    if receipt.receipt_sha256 != _json_sha256(
        ExecutionSnapshotReceipt.payload(receipt)
    ):
        raise SnapshotBoundaryError("snapshot_receipt_digest_mismatch")
    raw_source = Path(receipt.source_clone_root)
    raw_snapshot = Path(receipt.snapshot_root)
    raw_godot_root = Path(receipt.godot_root)
    raw_receipt_path = Path(receipt.receipt_path)

    def canonical_directory(path: Path, *, label: str) -> Path:
        if not path.is_absolute():
            raise SnapshotBoundaryError(f"{label}_not_absolute", str(path))
        try:
            resolved = path.resolve(strict=True)
        except (OSError, RuntimeError) as exc:
            raise SnapshotBoundaryError(f"{label}_missing", str(path)) from exc
        if path.is_symlink() or not resolved.is_dir() or str(path) != str(resolved):
            raise SnapshotBoundaryError(f"{label}_not_canonical", str(path))
        return resolved

    source = canonical_directory(raw_source, label="source_clone_root")
    snapshot = canonical_directory(raw_snapshot, label="snapshot_root")
    if snapshot.name != "snapshot":
        raise SnapshotBoundaryError("snapshot_root_layout_mismatch")
    execution = _validate_execution_id(receipt.execution_id)
    run_root = snapshot.parent
    if run_root.name != execution:
        raise SnapshotBoundaryError("snapshot_run_root_identity_mismatch")
    package_root = VERSION_ROOT.resolve(strict=True)
    if not _paths_disjoint(package_root, source):
        raise SnapshotBoundaryError("source_clone_overlaps_os_package")
    if not _paths_disjoint(package_root, run_root):
        raise SnapshotBoundaryError("external_snapshot_overlaps_os_package")

    expected_godot_root = (
        snapshot
        if authorization.project_subroot == "."
        else snapshot.joinpath(*PurePosixPath(authorization.project_subroot).parts)
    )
    godot_root = canonical_directory(raw_godot_root, label="snapshot_godot_root")
    if godot_root != expected_godot_root:
        raise SnapshotBoundaryError("snapshot_godot_root_identity_mismatch")

    expected_external_roots = (
        run_root / "evidence",
        run_root / "build",
        run_root / "logs",
        run_root / "cache",
    )
    supplied_external_roots = tuple(
        Path(value)
        for value in (
            receipt.evidence_root,
            receipt.build_root,
            receipt.log_root,
            receipt.cache_root,
        )
    )
    external_roots = tuple(
        canonical_directory(path, label="snapshot_external_runtime_root")
        for path in supplied_external_roots
    )
    if external_roots != expected_external_roots:
        raise SnapshotBoundaryError("snapshot_external_runtime_root_layout_mismatch")

    consumed_marker_path = expected_external_roots[0] / _EXECUTION_CONSUMED_MARKER
    if expected_consumed_marker is None:
        if consumed_marker_path.exists() or consumed_marker_path.is_symlink():
            raise SnapshotBoundaryError("snapshot_execution_already_consumed")
    else:
        try:
            resolved_consumed_marker = consumed_marker_path.resolve(strict=True)
        except (OSError, RuntimeError) as exc:
            raise SnapshotBoundaryError("snapshot_consumed_marker_missing") from exc
        if (
            consumed_marker_path.is_symlink()
            or not resolved_consumed_marker.is_file()
            or str(consumed_marker_path) != str(resolved_consumed_marker)
        ):
            raise SnapshotBoundaryError("snapshot_consumed_marker_not_canonical")
        try:
            observed_consumed_marker = consumed_marker_path.read_bytes()
        except OSError as exc:
            raise SnapshotBoundaryError("snapshot_consumed_marker_unreadable") from exc
        if observed_consumed_marker != expected_consumed_marker:
            raise SnapshotBoundaryError("snapshot_consumed_marker_mismatch")

    expected_receipt_path = (
        expected_external_roots[0] / "godot_execution_snapshot_receipt.json"
    )
    if raw_receipt_path != expected_receipt_path:
        raise SnapshotBoundaryError("snapshot_receipt_path_mismatch")
    try:
        receipt_path = raw_receipt_path.resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise SnapshotBoundaryError("snapshot_receipt_file_missing") from exc
    if (
        raw_receipt_path.is_symlink()
        or not receipt_path.is_file()
        or str(raw_receipt_path) != str(receipt_path)
    ):
        raise SnapshotBoundaryError("snapshot_receipt_file_not_canonical")
    receipt_document = ExecutionSnapshotReceipt.to_dict(receipt)
    expected_receipt_file_bytes = _canonical_json_bytes(receipt_document) + b"\n"
    try:
        observed_receipt_file_bytes = receipt_path.read_bytes()
    except OSError as exc:
        raise SnapshotBoundaryError("snapshot_receipt_file_unreadable") from exc
    if observed_receipt_file_bytes != expected_receipt_file_bytes:
        raise SnapshotBoundaryError("snapshot_receipt_file_not_canonical")
    stored = _read_json_object(receipt_path, label="snapshot_receipt")
    if _canonical_json_bytes(stored) != _canonical_json_bytes(receipt_document):
        raise SnapshotBoundaryError("snapshot_receipt_file_mismatch")
    if (
        receipt.project_id != authorization.project_id
        or str(source) != authorization.project_root
        or receipt.source_commit != authorization.source_commit
        or receipt.source_tree != authorization.source_tree
        or receipt.project_subroot != authorization.project_subroot
    ):
        raise StageAuthorizationError("snapshot_project_binding_identity_mismatch")
    if not _paths_disjoint(source, snapshot):
        raise SnapshotBoundaryError("snapshot_overlaps_source_clone")
    if any(not _paths_disjoint(snapshot, path) for path in external_roots):
        raise SnapshotBoundaryError("runtime_artifact_root_inside_snapshot")
    for index, path in enumerate(external_roots):
        if not _paths_disjoint(source, path):
            raise SnapshotBoundaryError("runtime_artifact_root_overlaps_source")
        if any(not _paths_disjoint(path, other) for other in external_roots[index + 1 :]):
            raise SnapshotBoundaryError("runtime_artifact_roots_overlap")
    if (snapshot / ".git").exists() or (snapshot / ".git").is_symlink():
        raise SnapshotBoundaryError("snapshot_contains_git_metadata")
    project_marker = godot_root / "project.godot"
    if project_marker.is_symlink() or not project_marker.is_file():
        raise SnapshotBoundaryError("snapshot_project_godot_missing")
    if _file_sha256(project_marker) != receipt.project_godot_sha256:
        raise SnapshotBoundaryError("snapshot_project_godot_digest_mismatch")
    expected_override_path = godot_root / "override.cfg"
    expected_override_relative_path = expected_override_path.relative_to(
        snapshot
    ).as_posix()
    if receipt.override_relative_path != expected_override_relative_path:
        raise SnapshotBoundaryError("snapshot_override_path_mismatch")
    if expected_override_path.is_symlink() or not expected_override_path.is_file():
        raise SnapshotBoundaryError("snapshot_override_missing")
    expected_override = _decode_base64(receipt.override_content_base64)
    if expected_override_path.read_bytes() != expected_override:
        raise SnapshotBoundaryError("snapshot_override_bytes_mismatch")
    if hashlib.sha256(expected_override).hexdigest() != receipt.override_sha256:
        raise SnapshotBoundaryError("snapshot_override_digest_mismatch")
    payload_digest, payload_file_count = _snapshot_payload_manifest(
        snapshot_root=snapshot,
        godot_root=godot_root,
        override_path=expected_override_path,
        allow_runtime_cache=allow_runtime_cache,
    )
    if payload_digest != receipt.snapshot_payload_manifest_sha256:
        raise SnapshotBoundaryError("snapshot_payload_manifest_mismatch")
    if payload_file_count != receipt.snapshot_payload_file_count:
        raise SnapshotBoundaryError("snapshot_payload_file_count_mismatch")
    expected_name = expected_custom_user_dir_name(
        project_id=receipt.project_id,
        source_commit=receipt.source_commit,
        source_tree=receipt.source_tree,
        execution_id=receipt.execution_id,
        snapshot_root=snapshot,
    )
    if receipt.custom_user_dir_name != expected_name:
        raise SnapshotBoundaryError("snapshot_custom_user_dir_identity_mismatch")
    seed = _custom_user_dir_seed(
        project_id=receipt.project_id,
        source_commit=receipt.source_commit,
        source_tree=receipt.source_tree,
        execution_id=receipt.execution_id,
        snapshot_root=snapshot,
    )
    if seed != receipt.custom_user_dir_seed_sha256:
        raise SnapshotBoundaryError("snapshot_custom_user_dir_seed_mismatch")
    if receipt.macos_application_support_relative_path != expected_name:
        raise SnapshotBoundaryError("snapshot_macos_user_path_mismatch")
    git = Path(git_host_tool.executable_path)
    _require_source_identity(
        source,
        expected_commit=receipt.source_commit,
        expected_tree=receipt.source_tree,
        git_binary=git,
    )
    (
        fresh_archive_sha256,
        fresh_payload_sha256,
        fresh_file_count,
        fresh_project_godot_sha256,
    ) = _fresh_archive_snapshot_identity(
        source=source,
        source_commit=receipt.source_commit,
        project_subroot=receipt.project_subroot,
        snapshot_root=snapshot,
        godot_root=godot_root,
        override_path=expected_override_path,
        git_binary=git,
        allow_runtime_cache=allow_runtime_cache,
    )
    if fresh_archive_sha256 != receipt.git_archive_sha256:
        raise SnapshotBoundaryError("snapshot_git_archive_digest_mismatch")
    if fresh_payload_sha256 != receipt.snapshot_payload_manifest_sha256:
        raise SnapshotBoundaryError("snapshot_fresh_payload_manifest_mismatch")
    if fresh_file_count != receipt.snapshot_payload_file_count:
        raise SnapshotBoundaryError("snapshot_fresh_payload_file_count_mismatch")
    if fresh_project_godot_sha256 != receipt.project_godot_sha256:
        raise SnapshotBoundaryError("snapshot_fresh_project_godot_mismatch")
    derived_override = _override_bytes(expected_name)
    if expected_override_path.read_bytes() != derived_override:
        raise SnapshotBoundaryError("snapshot_override_not_freshly_derived")
    expected_receipt = _new_receipt(
        profile_sha256=_json_sha256(profile_value),
        authorization=authorization,
        project_id=authorization.project_id,
        execution_id=receipt.execution_id,
        source_clone_root=source,
        source_commit=authorization.source_commit,
        source_tree=authorization.source_tree,
        git_archive_sha256=fresh_archive_sha256,
        godot_host_tool=godot_host_tool,
        git_host_tool=git_host_tool,
        snapshot_root=snapshot,
        project_subroot=authorization.project_subroot,
        godot_root=godot_root,
        project_godot_sha256=fresh_project_godot_sha256,
        snapshot_payload_manifest_sha256=fresh_payload_sha256,
        snapshot_payload_file_count=fresh_file_count,
        override_content=derived_override,
        custom_user_dir_name=expected_name,
        custom_user_dir_seed_sha256=seed,
        evidence_root=Path(receipt.evidence_root),
        build_root=Path(receipt.build_root),
        log_root=Path(receipt.log_root),
        cache_root=Path(receipt.cache_root),
    )
    expected_receipt_document = ExecutionSnapshotReceipt.to_dict(expected_receipt)
    if _canonical_json_bytes(expected_receipt_document) != _canonical_json_bytes(
        receipt_document
    ):
        raise SnapshotBoundaryError("snapshot_receipt_fresh_rebuild_mismatch")
    if _canonical_json_bytes(stored) != _canonical_json_bytes(
        expected_receipt_document
    ):
        raise SnapshotBoundaryError("snapshot_receipt_file_fresh_rebuild_mismatch")
    return receipt


def verify_execution_snapshot(
    receipt: ExecutionSnapshotReceipt,
    *,
    assembly_lock: Mapping[str, Any] | str | Path,
    assembly_component_paths: Sequence[str | Path],
    project_binding: Mapping[str, Any] | str | Path,
    selected_stage_id: str,
    selected_command_id: str,
    host_tool_identity: Mapping[str, Any] | str | Path,
    git_tool_identity: Mapping[str, Any] | str | Path,
    profile: Mapping[str, Any] | str | Path = DEFAULT_ENGINE_PROFILE_PATH,
    host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_HOST_TOOL_REQUIREMENT_PATH
    ),
    git_host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_GIT_HOST_TOOL_REQUIREMENT_PATH
    ),
) -> ExecutionSnapshotReceipt:
    """Freshly verify one pristine, not-yet-executed snapshot.

    A pre-existing ``godot_root/.godot`` is never admitted here: build and
    execution planning must not consume caller-injected import/cache state.
    The execution path uses the private post-process verifier only after the
    selected process has been contained and reaped.
    """

    return _verify_execution_snapshot(
        receipt,
        assembly_lock=assembly_lock,
        assembly_component_paths=assembly_component_paths,
        project_binding=project_binding,
        selected_stage_id=selected_stage_id,
        selected_command_id=selected_command_id,
        host_tool_identity=host_tool_identity,
        git_tool_identity=git_tool_identity,
        profile=profile,
        host_tool_requirement=host_tool_requirement,
        git_host_tool_requirement=git_host_tool_requirement,
        allow_runtime_cache=False,
        expected_consumed_marker=None,
    )


def _path_within(path: Path, root: Path) -> bool:
    return path == root or root in path.parents


def _require_macos_development_export_preset(godot_root: Path) -> None:
    preset_path = godot_root / "export_presets.cfg"
    if preset_path.is_symlink() or not preset_path.is_file():
        raise StageCommandError("development_export_preset_missing")
    try:
        lines = preset_path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as exc:
        raise StageCommandError("development_export_preset_unreadable") from exc
    in_preset = False
    found_name = False
    found_platform = False
    for raw_line in lines:
        line = raw_line.strip()
        if line.startswith("[") and line.endswith("]"):
            if in_preset and found_name and found_platform:
                return
            in_preset = re.fullmatch(r"\[preset\.\d+\]", line) is not None
            found_name = False
            found_platform = False
            continue
        if not in_preset:
            continue
        if re.fullmatch(r'name\s*=\s*"macOS Development"', line):
            found_name = True
        if re.fullmatch(r'platform\s*=\s*"macOS"', line):
            found_platform = True
    if not (in_preset and found_name and found_platform):
        raise StageCommandError("development_export_preset_missing")


def _command_payload(
    *,
    authorization: VerifiedStageAuthorization,
    command_contract: Mapping[str, Any],
    project_id: str,
    profile_id: str,
    profile_sha256: str,
    host_tool: VerifiedHostTool,
    snapshot: ExecutionSnapshotReceipt,
    argv: tuple[str, ...],
    environment_overrides: tuple[tuple[str, str], ...],
    log_file: Path,
    build_output: Path | None,
) -> dict[str, Any]:
    return {
        "selected_command_id": authorization.selected_command_id,
        "selected_stage_id": authorization.selected_stage_id,
        "stage_family": command_contract["stage_family"],
        "operation_id": command_contract["operation_id"],
        "stage_disposition": authorization.disposition,
        "assembly_sha256": authorization.assembly_sha256,
        "project_binding_id": authorization.project_binding_id,
        "project_binding_sha256": authorization.project_binding_sha256,
        "project_id": project_id,
        "profile_id": profile_id,
        "profile_sha256": profile_sha256,
        "executable_ref": host_tool.executable_ref,
        "executable_sha256": host_tool.binary_sha256,
        "snapshot_receipt_sha256": snapshot.receipt_sha256,
        "snapshot_root": snapshot.snapshot_root,
        "source_clone_root": snapshot.source_clone_root,
        "cwd": snapshot.godot_root,
        "argv": list(argv),
        "environment_overrides": dict(environment_overrides),
        "log_file": str(log_file),
        "build_output": None if build_output is None else str(build_output),
        "non_claims": list(COMMAND_NON_CLAIMS),
    }


def build_stage_command(
    *,
    assembly_lock: Mapping[str, Any] | str | Path,
    assembly_component_paths: Sequence[str | Path],
    project_binding: Mapping[str, Any] | str | Path,
    selected_stage_id: str,
    snapshot: ExecutionSnapshotReceipt,
    host_tool_identity: Mapping[str, Any] | str | Path,
    git_tool_identity: Mapping[str, Any] | str | Path,
    selected_command_id: str,
    build_output: str | Path | None = None,
    profile: Mapping[str, Any] | str | Path = DEFAULT_ENGINE_PROFILE_PATH,
    host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_HOST_TOOL_REQUIREMENT_PATH
    ),
    git_host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_GIT_HOST_TOOL_REQUIREMENT_PATH
    ),
) -> GodotStageCommand:
    """Build argv for exactly one caller-selected command; there is no default."""

    if not isinstance(selected_command_id, str) or not selected_command_id:
        raise StageCommandError("selected_command_id_missing")
    requirement_value = load_host_tool_requirement(host_tool_requirement)
    git_requirement_value = load_git_host_tool_requirement(
        git_host_tool_requirement
    )
    profile_value = load_engine_profile(
        profile,
        host_tool_requirement=requirement_value,
        git_host_tool_requirement=git_requirement_value,
    )
    host_tool = verify_host_tool_identity(
        host_tool_identity, requirement=requirement_value
    )
    verify_git_tool_identity(
        git_tool_identity, requirement=git_requirement_value
    )
    authorization = verify_stage_authorization(
        assembly_lock=assembly_lock,
        assembly_component_paths=assembly_component_paths,
        project_binding=project_binding,
        selected_stage_id=selected_stage_id,
        selected_command_id=selected_command_id,
        profile=profile_value,
        host_tool_requirement=requirement_value,
        git_host_tool_requirement=git_requirement_value,
    )
    verify_execution_snapshot(
        snapshot,
        assembly_lock=assembly_lock,
        assembly_component_paths=assembly_component_paths,
        project_binding=project_binding,
        selected_stage_id=selected_stage_id,
        selected_command_id=selected_command_id,
        host_tool_identity=host_tool_identity,
        git_tool_identity=git_tool_identity,
        profile=profile_value,
        host_tool_requirement=requirement_value,
        git_host_tool_requirement=git_requirement_value,
    )
    host_refs = [
        item
        for item in profile_value["host_tool_refs"]
        if item["component_id"] == GODOT_HOST_REQUIREMENT_ID
    ]
    if len(host_refs) != 1:
        raise StageCommandError("profile_godot_host_tool_ref_not_exact")
    host_ref = host_refs[0]
    if (
        host_tool.requirement_id != host_ref["component_id"]
        or host_tool.requirement_sha256 != host_ref["canonical_sha256"]
        or host_tool.requirement_sha256 != _json_sha256(requirement_value)
    ):
        raise StageCommandError("verified_host_tool_requirement_mismatch")
    if snapshot.project_id != authorization.project_id:
        raise StageAuthorizationError("command_project_binding_identity_mismatch")
    command_contract = next(
        (
            item
            for item in profile_value["commands"]
            if item["command_id"] == selected_command_id
        ),
        None,
    )
    if command_contract is None:
        raise StageCommandError("selected_command_not_in_profile")
    if command_contract["executable_ref"] != host_tool.executable_ref:
        raise StageCommandError("command_host_tool_ref_mismatch")
    snapshot_root = Path(snapshot.snapshot_root)
    godot_root = Path(snapshot.godot_root)
    source_root = Path(snapshot.source_clone_root)
    if not _paths_disjoint(source_root, godot_root) or not _path_within(godot_root, snapshot_root):
        raise StageCommandError("command_project_root_not_external_snapshot")
    log_file = Path(snapshot.log_root) / f"{selected_command_id}.log"
    if log_file.exists() or log_file.is_symlink():
        raise StageCommandError("command_log_output_already_exists")
    resolved_build: Path | None = None
    if selected_command_id == EXPORT_COMMAND_ID:
        _require_macos_development_export_preset(godot_root)
        if build_output is None:
            raise StageCommandError("development_export_output_required")
        raw_output = Path(build_output)
        if not raw_output.is_absolute():
            raise StageCommandError("development_export_output_not_absolute")
        build_root = Path(snapshot.build_root)
        resolved_build = raw_output.parent.resolve(strict=True) / raw_output.name
        if resolved_build.parent != build_root or resolved_build.suffix != ".app":
            raise StageCommandError("development_export_output_outside_build_root")
        if resolved_build.exists() or resolved_build.is_symlink():
            raise StageCommandError("development_export_output_already_exists")
    elif build_output is not None:
        raise StageCommandError("startup_command_rejects_build_output")
    replacements = {
        "{snapshot_godot_root}": str(godot_root),
        "{log_file}": str(log_file),
        "{build_output}": "" if resolved_build is None else str(resolved_build),
    }
    arguments: list[str] = []
    for value in command_contract["arguments"]:
        rendered = replacements.get(value, value)
        if not rendered or "\x00" in rendered or (value.startswith("{") and value not in replacements):
            raise StageCommandError("command_argument_template_invalid", value)
        arguments.append(rendered)
    argv = (host_tool.executable_path, *arguments)
    if str(source_root) in argv or any(
        item.startswith(str(source_root) + os.sep) for item in argv
    ):
        raise StageCommandError("source_clone_appears_in_command")
    environment = (
        ("AI_DEV_OS_BUILD_ROOT", snapshot.build_root),
        ("AI_DEV_OS_EVIDENCE_ROOT", snapshot.evidence_root),
        ("AI_DEV_OS_LOG_ROOT", snapshot.log_root),
        ("XDG_CACHE_HOME", snapshot.cache_root),
    )
    profile_digest = _json_sha256(profile_value)
    payload = _command_payload(
        authorization=authorization,
        command_contract=command_contract,
        project_id=snapshot.project_id,
        profile_id=profile_value["engine_profile_id"],
        profile_sha256=profile_digest,
        host_tool=host_tool,
        snapshot=snapshot,
        argv=argv,
        environment_overrides=environment,
        log_file=log_file,
        build_output=resolved_build,
    )
    return GodotStageCommand(
        selected_command_id=selected_command_id,
        selected_stage_id=selected_stage_id,
        stage_family=command_contract["stage_family"],
        operation_id=command_contract["operation_id"],
        stage_disposition=authorization.disposition,
        assembly_sha256=authorization.assembly_sha256,
        project_binding_id=authorization.project_binding_id,
        project_binding_sha256=authorization.project_binding_sha256,
        project_id=snapshot.project_id,
        profile_id=profile_value["engine_profile_id"],
        profile_sha256=profile_digest,
        executable_ref=host_tool.executable_ref,
        executable_sha256=host_tool.binary_sha256,
        snapshot_receipt_sha256=snapshot.receipt_sha256,
        snapshot_root=snapshot.snapshot_root,
        source_clone_root=snapshot.source_clone_root,
        cwd=snapshot.godot_root,
        argv=argv,
        environment_overrides=environment,
        log_file=str(log_file),
        build_output=None if resolved_build is None else str(resolved_build),
        command_sha256=_json_sha256(payload),
        non_claims=COMMAND_NON_CLAIMS,
    )


def _truncate_capture(value: bytes | None) -> tuple[str, bool]:
    raw = value or b""
    truncated = len(raw) > _MAX_CAPTURE_BYTES
    return raw[:_MAX_CAPTURE_BYTES].decode("utf-8", errors="replace"), truncated


@dataclass(frozen=True)
class _ObservedProcess:
    """PID plus start time, used to avoid signalling a reused PID."""

    pid: int
    start_seconds: int
    start_microseconds: int
    status: int = field(compare=False)


class _ProcBSDInfo(ctypes.Structure):
    """Darwin ``proc_bsdinfo`` prefix and start-time fields."""

    _fields_ = [
        ("pbi_flags", ctypes.c_uint32),
        ("pbi_status", ctypes.c_uint32),
        ("pbi_xstatus", ctypes.c_uint32),
        ("pbi_pid", ctypes.c_uint32),
        ("pbi_ppid", ctypes.c_uint32),
        ("pbi_uid", ctypes.c_uint32),
        ("pbi_gid", ctypes.c_uint32),
        ("pbi_ruid", ctypes.c_uint32),
        ("pbi_rgid", ctypes.c_uint32),
        ("pbi_svuid", ctypes.c_uint32),
        ("pbi_svgid", ctypes.c_uint32),
        ("rfu_1", ctypes.c_uint32),
        ("pbi_comm", ctypes.c_char * 16),
        ("pbi_name", ctypes.c_char * 32),
        ("pbi_nfiles", ctypes.c_uint32),
        ("pbi_pgid", ctypes.c_uint32),
        ("pbi_pjobc", ctypes.c_uint32),
        ("e_tdev", ctypes.c_uint32),
        ("e_tpgid", ctypes.c_uint32),
        ("pbi_nice", ctypes.c_int32),
        ("pbi_start_tvsec", ctypes.c_uint64),
        ("pbi_start_tvusec", ctypes.c_uint64),
    ]


_DARWIN_PROCESS_LIBRARIES: tuple[Any, Any] | None = None


def _darwin_process_libraries() -> tuple[Any, Any]:
    """Load the narrow Darwin process-inspection APIs or fail closed."""

    global _DARWIN_PROCESS_LIBRARIES
    if platform.system() != "Darwin":
        raise StageCommandError("engine_descendant_scan_unsupported_platform")
    if _DARWIN_PROCESS_LIBRARIES is None:
        try:
            libproc = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
            libc = ctypes.CDLL(None, use_errno=True)
        except OSError as exc:  # pragma: no cover - supported macOS invariant
            raise StageCommandError(
                "engine_descendant_scan_unavailable", str(exc)
            ) from exc
        libproc.proc_listpids.argtypes = [
            ctypes.c_uint32,
            ctypes.c_uint32,
            ctypes.c_void_p,
            ctypes.c_int,
        ]
        libproc.proc_listpids.restype = ctypes.c_int
        libproc.proc_pidinfo.argtypes = [
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_uint64,
            ctypes.c_void_p,
            ctypes.c_int,
        ]
        libproc.proc_pidinfo.restype = ctypes.c_int
        libc.sysctl.argtypes = [
            ctypes.POINTER(ctypes.c_int),
            ctypes.c_uint,
            ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_size_t),
            ctypes.c_void_p,
            ctypes.c_size_t,
        ]
        libc.sysctl.restype = ctypes.c_int
        _DARWIN_PROCESS_LIBRARIES = (libproc, libc)
    return _DARWIN_PROCESS_LIBRARIES


def _same_user_process_ids() -> tuple[int, ...]:
    """Enumerate every current process owned by this runtime's uid."""

    libproc, _ = _darwin_process_libraries()
    # PROC_UID_ONLY is the documented Darwin selector for one real uid.
    selector = 4
    ctypes.set_errno(0)
    required = libproc.proc_listpids(selector, os.getuid(), None, 0)
    if required <= 0:
        error = ctypes.get_errno()
        raise StageCommandError(
            "engine_descendant_scan_failed",
            os.strerror(error) if error else "proc_listpids_size_failed",
        )
    buffer_bytes = max(required + 4096, 16 * 1024)
    for _attempt in range(4):
        slots = (buffer_bytes + ctypes.sizeof(ctypes.c_int) - 1) // ctypes.sizeof(
            ctypes.c_int
        )
        values = (ctypes.c_int * slots)()
        ctypes.set_errno(0)
        used = libproc.proc_listpids(
            selector, os.getuid(), values, ctypes.sizeof(values)
        )
        if used < 0:
            error = ctypes.get_errno()
            raise StageCommandError(
                "engine_descendant_scan_failed",
                os.strerror(error) if error else "proc_listpids_failed",
            )
        if used < ctypes.sizeof(values):
            count = used // ctypes.sizeof(ctypes.c_int)
            return tuple(
                sorted({int(pid) for pid in values[:count] if int(pid) > 0})
            )
        buffer_bytes *= 2
    raise StageCommandError("engine_descendant_scan_inventory_unbounded")


def _process_identity(pid: int) -> _ObservedProcess | None:
    """Return a reuse-safe identity, or ``None`` when the PID has exited."""

    libproc, _ = _darwin_process_libraries()
    info = _ProcBSDInfo()
    ctypes.set_errno(0)
    used = libproc.proc_pidinfo(
        pid, 3, 0, ctypes.byref(info), ctypes.sizeof(info)
    )
    if used == 0:
        error = ctypes.get_errno()
        if error in {0, errno.ESRCH, errno.EINVAL}:
            return None
        raise StageCommandError(
            "engine_descendant_identity_failed", f"pid={pid}:{os.strerror(error)}"
        )
    if used != ctypes.sizeof(info):
        raise StageCommandError(
            "engine_descendant_identity_incomplete", f"pid={pid}:bytes={used}"
        )
    if int(info.pbi_uid) != os.getuid():
        return None
    return _ObservedProcess(
        pid=pid,
        start_seconds=int(info.pbi_start_tvsec),
        start_microseconds=int(info.pbi_start_tvusec),
        status=int(info.pbi_status),
    )


def _process_arguments_and_environment(pid: int) -> bytes | None:
    """Read Darwin KERN_PROCARGS2 bytes for one same-user process."""

    _, libc = _darwin_process_libraries()
    mib = (ctypes.c_int * 3)(1, 49, pid)  # CTL_KERN, KERN_PROCARGS2, pid
    for attempt in range(2):
        size = ctypes.c_size_t(0)
        ctypes.set_errno(0)
        if libc.sysctl(mib, 3, None, ctypes.byref(size), None, 0) != 0:
            error = ctypes.get_errno()
            if error in {errno.ESRCH, errno.EINVAL}:
                return None
            if error == errno.EPERM:
                identity = _process_identity(pid)
                # Darwin returns EPERM for a zombie's discarded procargs.  A
                # zombie cannot execute or write; observed identities remain
                # tracked until their PID is reaped below.
                if identity is None or identity.status == 5:
                    return None
            raise StageCommandError(
                "engine_descendant_environment_unreadable",
                f"pid={pid}:{os.strerror(error)}",
            )
        if size.value == 0:
            return None
        if size.value > _MAX_PROCESS_ARGUMENT_BYTES:
            raise StageCommandError(
                "engine_descendant_environment_too_large", f"pid={pid}"
            )
        buffer = ctypes.create_string_buffer(size.value)
        actual = ctypes.c_size_t(size.value)
        ctypes.set_errno(0)
        if libc.sysctl(mib, 3, buffer, ctypes.byref(actual), None, 0) == 0:
            return ctypes.string_at(buffer, actual.value)
        error = ctypes.get_errno()
        if error in {errno.ESRCH, errno.EINVAL}:
            return None
        if error == errno.EPERM:
            identity = _process_identity(pid)
            if identity is None or identity.status == 5:
                return None
        if error == errno.ENOMEM and attempt == 0:
            continue
        raise StageCommandError(
            "engine_descendant_environment_unreadable",
            f"pid={pid}:{os.strerror(error)}",
        )
    raise StageCommandError("engine_descendant_environment_unreadable", f"pid={pid}")


def _scan_execution_token(token: str) -> set[_ObservedProcess]:
    """Find all same-user processes that still carry this execution token."""

    expected = f"{_EXECUTION_TOKEN_ENV}={token}".encode("ascii")
    matches: set[_ObservedProcess] = set()
    for pid in _same_user_process_ids():
        payload = _process_arguments_and_environment(pid)
        if payload is None or expected not in payload.split(b"\0"):
            continue
        identity = _process_identity(pid)
        if identity is not None:
            matches.add(identity)
    return matches


def _identity_is_alive(identity: _ObservedProcess) -> bool:
    current = _process_identity(identity.pid)
    return current == identity


def _kill_observed_process(identity: _ObservedProcess) -> None:
    """SIGKILL only if the PID still denotes the process we observed."""

    if not _identity_is_alive(identity):
        return
    try:
        os.kill(identity.pid, signal.SIGKILL)
    except ProcessLookupError:
        return
    except OSError as exc:
        raise StageCommandError(
            "engine_descendant_termination_failed", f"pid={identity.pid}:{exc}"
        ) from exc


def _kill_command_process_group(process: subprocess.Popen[bytes]) -> None:
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        return
    except OSError as exc:
        raise StageCommandError(
            "engine_process_group_termination_failed", str(exc)
        ) from exc


def _terminate_execution_processes(
    process: subprocess.Popen[bytes],
    *,
    token: str,
    observed: set[_ObservedProcess],
) -> tuple[bytes, bytes]:
    """Kill the original process group and token-bearing escaped descendants."""

    group_error: StageCommandError | None = None
    try:
        _kill_command_process_group(process)
    except StageCommandError as exc:
        group_error = exc
        try:
            process.kill()
        except OSError:
            pass

    deadline = time.monotonic() + _PROCESS_CLEANUP_TIMEOUT_SECONDS
    stdout = b""
    stderr = b""
    while True:
        current = _scan_execution_token(token)
        observed.update(current)
        for identity in tuple(observed):
            _kill_observed_process(identity)
        if process.poll() is None:
            try:
                process.kill()
            except OSError:
                pass
        try:
            stdout, stderr = process.communicate(timeout=0.05)
        except subprocess.TimeoutExpired:
            pass
        current = _scan_execution_token(token)
        observed.update(current)
        alive = {identity for identity in observed if _identity_is_alive(identity)}
        if process.returncode is not None and not current and not alive:
            if group_error is not None:
                raise group_error
            return stdout, stderr
        if time.monotonic() >= deadline:
            raise StageCommandError(
                "engine_descendant_cleanup_unproven",
                f"token_processes={len(current)}:observed_alive={len(alive)}",
            )
        time.sleep(_PROCESS_SCAN_INTERVAL_SECONDS)


def _run_stage_process(
    command: GodotStageCommand,
    *,
    environment: Mapping[str, str],
    timeout_seconds: float,
) -> tuple[str, str | None, int | None, bytes, bytes]:
    """Run one argv with narrow process-group plus token containment.

    This is descendant cleanup for the supported macOS execution profile.  It
    is deliberately not represented as a general operating-system sandbox.
    """

    token = secrets.token_hex(32)
    child_environment = dict(environment)
    child_environment[_EXECUTION_TOKEN_ENV] = token

    try:
        process = subprocess.Popen(
            list(command.argv),
            cwd=command.cwd,
            env=child_environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=False,
            shell=False,
            start_new_session=True,
        )
    except OSError as exc:
        raise StageCommandError("engine_command_unavailable", str(exc)) from exc
    observed: set[_ObservedProcess] = set()
    deadline = time.monotonic() + timeout_seconds
    stdout = b""
    stderr = b""
    cleanup_complete = False
    try:
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                stdout, stderr = _terminate_execution_processes(
                    process, token=token, observed=observed
                )
                return "failed", "timeout", None, stdout, stderr
            try:
                stdout, stderr = process.communicate(
                    timeout=min(_PROCESS_SCAN_INTERVAL_SECONDS, remaining)
                )
            except subprocess.TimeoutExpired:
                observed.update(_scan_execution_token(token))
                if process.poll() is not None:
                    current = _scan_execution_token(token)
                    observed.update(current)
                    alive = {
                        identity
                        for identity in observed
                        if _identity_is_alive(identity)
                    }
                    if current or alive:
                        _terminate_execution_processes(
                            process, token=token, observed=observed
                        )
                        cleanup_complete = True
                        raise StageCommandError(
                            "engine_descendant_residual_detected"
                        )
                continue
            observed.update(_scan_execution_token(token))
            break
    except StageCommandError as execution_error:
        if not cleanup_complete:
            try:
                _terminate_execution_processes(
                    process, token=token, observed=observed
                )
            except StageCommandError as cleanup_error:
                raise StageCommandError(
                    "engine_descendant_cleanup_unproven",
                    f"trigger={execution_error.code}:cleanup={cleanup_error.code}",
                ) from cleanup_error
        raise
    if process.returncode is None:  # pragma: no cover - communicate contract
        _terminate_execution_processes(process, token=token, observed=observed)
        raise StageCommandError("engine_command_not_reaped")
    current = _scan_execution_token(token)
    observed.update(current)
    alive = {identity for identity in observed if _identity_is_alive(identity)}
    if current or alive:
        _terminate_execution_processes(process, token=token, observed=observed)
        raise StageCommandError("engine_descendant_residual_detected")
    if process.returncode == 0:
        return "passed", None, 0, stdout, stderr
    return "failed", "command_failed", process.returncode, stdout, stderr


def _create_execution_consumed_marker(
    command: GodotStageCommand,
    snapshot: ExecutionSnapshotReceipt,
) -> bytes:
    payload = {
        "schema_version": "1.0.0",
        "artifact_type": "godot_execution_consumed_marker",
        "assembly_sha256": command.assembly_sha256,
        "project_binding_sha256": command.project_binding_sha256,
        "selected_stage_id": command.selected_stage_id,
        "selected_command_id": command.selected_command_id,
        "command_sha256": command.command_sha256,
        "snapshot_receipt_sha256": snapshot.receipt_sha256,
        "non_claims": [
            "consumed_state_is_not_feature_qa_or_qualification_evidence",
            "a_consumed_snapshot_must_not_be_reused_for_another_process",
        ],
    }
    marker_bytes = _canonical_json_bytes(payload) + b"\n"
    marker_path = Path(snapshot.evidence_root) / _EXECUTION_CONSUMED_MARKER
    try:
        with marker_path.open("xb") as handle:
            handle.write(marker_bytes)
            handle.flush()
            os.fsync(handle.fileno())
        marker_path.chmod(0o600)
    except FileExistsError as exc:
        raise SnapshotBoundaryError("snapshot_execution_already_consumed") from exc
    except OSError as exc:
        raise SnapshotBoundaryError(
            "snapshot_consumed_marker_write_failed", str(exc)
        ) from exc
    return marker_bytes


def execute_stage_command(
    *,
    assembly_lock: Mapping[str, Any] | str | Path,
    assembly_component_paths: Sequence[str | Path],
    project_binding: Mapping[str, Any] | str | Path,
    selected_stage_id: str,
    command: GodotStageCommand,
    snapshot: ExecutionSnapshotReceipt,
    host_tool_identity: Mapping[str, Any] | str | Path,
    git_tool_identity: Mapping[str, Any] | str | Path,
    timeout_seconds: float = 30.0,
    profile: Mapping[str, Any] | str | Path = DEFAULT_ENGINE_PROFILE_PATH,
    host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_HOST_TOOL_REQUIREMENT_PATH
    ),
    git_host_tool_requirement: Mapping[str, Any] | str | Path = (
        DEFAULT_GIT_HOST_TOOL_REQUIREMENT_PATH
    ),
) -> GodotStageResult:
    """Execute a previously built command against its external snapshot only."""

    if type(command) is not GodotStageCommand:
        raise StageCommandError("stage_command_type_invalid")
    _require_stage_command_shape(command)
    normalized_timeout = _bounded_timeout(
        timeout_seconds,
        code="stage_command_timeout_invalid",
        maximum=_MAX_STAGE_EXECUTION_TIMEOUT_SECONDS,
        error_type=StageCommandError,
    )
    requirement_value = load_host_tool_requirement(host_tool_requirement)
    git_requirement_value = load_git_host_tool_requirement(
        git_host_tool_requirement
    )
    host_tool = verify_host_tool_identity(
        host_tool_identity, requirement=requirement_value
    )
    git_host_tool = verify_git_tool_identity(
        git_tool_identity, requirement=git_requirement_value
    )
    authorization = verify_stage_authorization(
        assembly_lock=assembly_lock,
        assembly_component_paths=assembly_component_paths,
        project_binding=project_binding,
        selected_stage_id=selected_stage_id,
        selected_command_id=command.selected_command_id,
        profile=profile,
        host_tool_requirement=requirement_value,
        git_host_tool_requirement=git_requirement_value,
    )
    verify_execution_snapshot(
        snapshot,
        assembly_lock=assembly_lock,
        assembly_component_paths=assembly_component_paths,
        project_binding=project_binding,
        selected_stage_id=selected_stage_id,
        selected_command_id=command.selected_command_id,
        host_tool_identity=host_tool_identity,
        git_tool_identity=git_tool_identity,
        profile=profile,
        host_tool_requirement=requirement_value,
        git_host_tool_requirement=git_requirement_value,
    )
    if command.snapshot_receipt_sha256 != snapshot.receipt_sha256:
        raise StageCommandError("stage_command_snapshot_identity_mismatch")
    if (
        command.selected_stage_id != authorization.selected_stage_id
        or command.assembly_sha256 != authorization.assembly_sha256
        or command.project_binding_id != authorization.project_binding_id
        or command.project_binding_sha256 != authorization.project_binding_sha256
        or command.stage_disposition != authorization.disposition
    ):
        raise StageAuthorizationError("stage_command_execution_authorization_mismatch")
    if command.executable_sha256 != host_tool.binary_sha256 or command.argv[0] != host_tool.executable_path:
        raise StageCommandError("stage_command_host_tool_identity_mismatch")
    if command.command_sha256 != _json_sha256(
        GodotStageCommand.payload(command)
    ):
        raise StageCommandError("stage_command_digest_mismatch")
    rebuilt = build_stage_command(
        assembly_lock=assembly_lock,
        assembly_component_paths=assembly_component_paths,
        project_binding=project_binding,
        selected_stage_id=selected_stage_id,
        snapshot=snapshot,
        host_tool_identity=host_tool_identity,
        git_tool_identity=git_tool_identity,
        selected_command_id=command.selected_command_id,
        build_output=command.build_output,
        profile=profile,
        host_tool_requirement=requirement_value,
        git_host_tool_requirement=git_requirement_value,
    )
    if _canonical_json_bytes(GodotStageCommand.to_dict(rebuilt)) != (
        _canonical_json_bytes(GodotStageCommand.to_dict(command))
    ):
        raise StageCommandError("stage_command_rebuild_mismatch")
    consumed_marker = _create_execution_consumed_marker(command, snapshot)
    environment = os.environ.copy()
    environment.update(dict(command.environment_overrides))
    started = time.monotonic_ns()
    execution_error: StageCommandError | None = None
    try:
        status, failure_kind, exit_code, stdout_bytes, stderr_bytes = (
            _run_stage_process(
                command,
                environment=environment,
                timeout_seconds=normalized_timeout,
            )
        )
        stdout, stdout_truncated = _truncate_capture(stdout_bytes)
        stderr, stderr_truncated = _truncate_capture(stderr_bytes)
    except StageCommandError as exc:
        execution_error = exc
    duration_ms = max(0, (time.monotonic_ns() - started) // 1_000_000)
    _verify_execution_snapshot(
        snapshot,
        assembly_lock=assembly_lock,
        assembly_component_paths=assembly_component_paths,
        project_binding=project_binding,
        selected_stage_id=selected_stage_id,
        selected_command_id=command.selected_command_id,
        host_tool_identity=host_tool_identity,
        git_tool_identity=git_tool_identity,
        profile=profile,
        host_tool_requirement=requirement_value,
        git_host_tool_requirement=git_requirement_value,
        allow_runtime_cache=True,
        expected_consumed_marker=consumed_marker,
    )
    if execution_error is not None:
        raise execution_error
    return GodotStageResult(
        selected_command_id=command.selected_command_id,
        selected_stage_id=command.selected_stage_id,
        assembly_sha256=command.assembly_sha256,
        project_binding_sha256=command.project_binding_sha256,
        command_sha256=command.command_sha256,
        snapshot_receipt_sha256=snapshot.receipt_sha256,
        executable_sha256=host_tool.binary_sha256,
        argv=command.argv,
        cwd=command.cwd,
        status=status,
        failure_kind=failure_kind,
        exit_code=exit_code,
        duration_ms=duration_ms,
        stdout=stdout,
        stderr=stderr,
        stdout_truncated=stdout_truncated,
        stderr_truncated=stderr_truncated,
        non_claims=COMMAND_NON_CLAIMS,
    )
