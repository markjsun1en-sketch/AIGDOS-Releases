"""Godot execution-run finalization without project or authority mutation."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from engine_profiles.godot import runtime_v1_0_1
from os_layer.scripts.portable_workspace.resource_lifecycle import (
    ResourceLifecycleError,
    ResourceLifecycleService,
    normalize_allocation_request,
)
from production_runtime.execution_artifact_lifecycle import (
    COMPACTION_RECEIPT_NAME,
    ExecutionArtifactLifecycleError,
    compact_terminal_run_root,
)


VERSION_ROOT = Path(__file__).resolve().parents[2]
LEGACY_MATERIALIZATION_REASON = (
    "accepted_godot_runtime_v1_0_1_git_archive_physical_copy_wrapper"
)
ACCEPTED_RUNTIME_RAW_SHA256 = (
    "c21bb0ca033fbbf53d64a0acd9b0d3b3dd934fc0b224e819282c7002946ba69a"
)


def _field(receipt: Mapping[str, Any] | Any, name: str) -> Any:
    if isinstance(receipt, Mapping):
        value = receipt.get(name)
    else:
        value = getattr(receipt, name, None)
    if value is None:
        raise ExecutionArtifactLifecycleError(
            f"godot_snapshot_receipt_field_missing:{name}"
        )
    return value


def finalize_godot_execution_artifacts(
    snapshot_receipt: Mapping[str, Any] | Any,
    *,
    terminal_state: str,
    terminal_receipt_path: str | Path,
    human_observation_pending: bool,
    recovery_pending: bool,
    resource_lease_binding: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Remove transient snapshot/build bytes after every consumer is terminal.

    The caller must explicitly state that neither recovery nor Human
    observation still depends on the snapshot or delivered build.  This
    function never infers those states from a successful engine command.
    """

    if not isinstance(human_observation_pending, bool):
        raise ExecutionArtifactLifecycleError(
            "human_observation_pending_not_boolean"
        )
    if not isinstance(recovery_pending, bool):
        raise ExecutionArtifactLifecycleError("recovery_pending_not_boolean")
    if human_observation_pending:
        raise ExecutionArtifactLifecycleError(
            "human_observation_pending_blocks_compaction"
        )
    if recovery_pending:
        raise ExecutionArtifactLifecycleError("recovery_pending_blocks_compaction")

    execution_id = _field(snapshot_receipt, "execution_id")
    snapshot_root = Path(_field(snapshot_receipt, "snapshot_root"))
    evidence_root = Path(_field(snapshot_receipt, "evidence_root"))
    build_root = Path(_field(snapshot_receipt, "build_root"))
    log_root = Path(_field(snapshot_receipt, "log_root"))
    cache_root = Path(_field(snapshot_receipt, "cache_root"))
    source_clone_root = Path(_field(snapshot_receipt, "source_clone_root"))
    run_root = snapshot_root.parent
    expected_layout = {
        "snapshot": snapshot_root,
        "evidence": evidence_root,
        "build": build_root,
        "logs": log_root,
        "cache": cache_root,
    }
    for name, observed in expected_layout.items():
        if observed != run_root / name:
            raise ExecutionArtifactLifecycleError(
                f"godot_execution_run_layout_mismatch:{name}"
            )

    return compact_terminal_run_root(
        run_root,
        execution_id=execution_id,
        terminal_state=terminal_state,
        terminal_receipt_path=terminal_receipt_path,
        transient_children=("snapshot", "cache", "build"),
        durable_children=("evidence", "logs"),
        protected_roots=(source_clone_root, VERSION_ROOT),
        resource_lease_binding=resource_lease_binding,
    )


def _managed_request(
    value: Mapping[str, Any],
    *,
    source_clone_root: Path,
    external_root: Path,
    execution_id: str,
    selected_stage_id: str,
    expected_commit: str,
    expected_tree: str,
    project_id: str,
) -> dict[str, Any]:
    request = normalize_allocation_request(value)
    identity = request["identity"]
    materialization = request["materialization"]
    authority = request["authority"]
    expected_run_root = external_root / execution_id
    exact_identity = {
        "resource_class": "execution_root",
        "project_id": project_id,
        "source_commit": expected_commit,
        "source_tree": expected_tree,
        "stage_id": selected_stage_id,
    }
    for field, expected in exact_identity.items():
        if identity[field] != expected:
            raise ExecutionArtifactLifecycleError(
                f"godot_resource_request_identity_mismatch:{field}"
            )
    if identity["purpose"] not in {
        "build",
        "startup",
        "independent_qa",
        "retry",
    }:
        raise ExecutionArtifactLifecycleError(
            "godot_resource_request_purpose_invalid"
        )
    exact_materialization = {
        "profile": "full_tracked_cow",
        "source_path": str(source_clone_root),
        "admitted_parent": str(external_root),
        "requested_path": str(expected_run_root),
        "physical_fallback_allowed": True,
        "full_materialization_reason": LEGACY_MATERIALIZATION_REASON,
    }
    for field, expected in exact_materialization.items():
        if materialization[field] != expected:
            raise ExecutionArtifactLifecycleError(
                f"godot_resource_request_materialization_mismatch:{field}"
            )
    if (
        authority["project_write"]
        or authority["git_branch_create"]
        or not authority["engine_execute"]
        or authority["historical_cleanup"]
    ):
        raise ExecutionArtifactLifecycleError(
            "godot_resource_request_authority_mismatch"
        )
    return request


def materialize_managed_godot_execution_snapshot(
    *,
    resource_lifecycle_service: ResourceLifecycleService,
    resource_allocation_request: Mapping[str, Any],
    assembly_lock: Mapping[str, Any] | str | Path,
    assembly_component_paths: Sequence[str | Path],
    project_binding: Mapping[str, Any] | str | Path,
    selected_stage_id: str,
    selected_command_id: str,
    host_tool_identity: Mapping[str, Any] | str | Path,
    git_tool_identity: Mapping[str, Any] | str | Path,
    source_clone_root: str | Path,
    expected_commit: str,
    expected_tree: str,
    project_id: str,
    project_subroot: str,
    external_root: str | Path,
    execution_id: str,
    custom_user_dir_name: str | None = None,
    profile: Mapping[str, Any] | str | Path = (
        runtime_v1_0_1.DEFAULT_ENGINE_PROFILE_PATH
    ),
    host_tool_requirement: Mapping[str, Any] | str | Path = (
        runtime_v1_0_1.DEFAULT_HOST_TOOL_REQUIREMENT_PATH
    ),
    git_host_tool_requirement: Mapping[str, Any] | str | Path = (
        runtime_v1_0_1.DEFAULT_GIT_HOST_TOOL_REQUIREMENT_PATH
    ),
) -> dict[str, Any]:
    """Reserve before delegating to the exact accepted Godot materializer."""

    lifecycle = resource_lifecycle_service
    if not isinstance(lifecycle, ResourceLifecycleService):
        raise TypeError("resource_lifecycle_service_required")
    source = Path(source_clone_root).resolve(strict=True)
    external = Path(external_root).resolve(strict=True)
    request = _managed_request(
        resource_allocation_request,
        source_clone_root=source,
        external_root=external,
        execution_id=execution_id,
        selected_stage_id=selected_stage_id,
        expected_commit=expected_commit,
        expected_tree=expected_tree,
        project_id=project_id,
    )
    reservation = lifecycle.reserve(request)
    if reservation["lease"] is None:
        recommendation = reservation["gc_recommendation"]
        raise ExecutionArtifactLifecycleError(
            f"godot_resource_allocation_blocked:"
            f"{recommendation['blocker_code']}"
        )
    lease = reservation["lease"]
    owns_materialization = False
    arguments = {
        "assembly_lock": assembly_lock,
        "assembly_component_paths": assembly_component_paths,
        "project_binding": project_binding,
        "selected_stage_id": selected_stage_id,
        "selected_command_id": selected_command_id,
        "host_tool_identity": host_tool_identity,
        "git_tool_identity": git_tool_identity,
        "source_clone_root": source_clone_root,
        "expected_commit": expected_commit,
        "expected_tree": expected_tree,
        "project_id": project_id,
        "project_subroot": project_subroot,
        "external_root": external_root,
        "execution_id": execution_id,
        "custom_user_dir_name": custom_user_dir_name,
        "profile": profile,
        "host_tool_requirement": host_tool_requirement,
        "git_host_tool_requirement": git_host_tool_requirement,
    }
    try:
        lease = lifecycle.transition(
            lease["resource_id"],
            expected_generation=lease["generation"],
            to_state="materializing",
        )
        owns_materialization = True
        receipt = runtime_v1_0_1.materialize_execution_snapshot(**arguments)
        run_root = Path(_field(receipt, "snapshot_root")).parent.resolve(
            strict=True
        )
        if run_root != external / execution_id:
            raise ExecutionArtifactLifecycleError(
                "godot_managed_runtime_run_root_mismatch"
            )
        lease = lifecycle.transition(
            lease["resource_id"],
            expected_generation=lease["generation"],
            to_state="active",
            canonical_path=run_root,
            materialization_receipt={
                "method": "accepted_godot_runtime_v1_0_1_git_archive",
                "accepted_runtime_raw_sha256": ACCEPTED_RUNTIME_RAW_SHA256,
                "physical_fallback_used": True,
                "full_materialization_reason": LEGACY_MATERIALIZATION_REASON,
            },
        )
    except Exception:
        if owns_materialization:
            current = lifecycle.lease(lease["resource_id"])
            if current is not None and current["state"] not in {
                "blocked",
                "finalizing",
                "compacted",
                "released",
            }:
                try:
                    lifecycle.mark_blocked(
                        current["resource_id"],
                        expected_generation=current["generation"],
                        blocker_code="recovery_pending",
                    )
                except ResourceLifecycleError:
                    pass
        raise
    return {
        "snapshot_receipt": receipt,
        "resource_id": lease["resource_id"],
        "resource_lease_generation": lease["generation"],
        "resource_state": lease["state"],
        "reservation_disposition": reservation["disposition"],
    }


def finalize_managed_godot_execution_artifacts(
    managed_snapshot: Mapping[str, Any],
    *,
    resource_lifecycle_service: ResourceLifecycleService,
    terminal_state: str,
    terminal_receipt_path: str | Path,
    terminal_consumer_ids: Sequence[str],
    human_observation_pending: bool,
    recovery_pending: bool,
    process_completion: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Apply consumer/process holds, then compact an exact managed snapshot."""

    lifecycle = resource_lifecycle_service
    if not isinstance(lifecycle, ResourceLifecycleService):
        raise TypeError("resource_lifecycle_service_required")
    if not isinstance(managed_snapshot, Mapping):
        raise ExecutionArtifactLifecycleError("managed_snapshot_not_object")
    required = {
        "snapshot_receipt",
        "resource_id",
        "resource_lease_generation",
        "resource_state",
        "reservation_disposition",
    }
    if set(managed_snapshot) != required:
        raise ExecutionArtifactLifecycleError("managed_snapshot_not_closed")
    resource_id = managed_snapshot["resource_id"]
    generation = managed_snapshot["resource_lease_generation"]
    snapshot_receipt = managed_snapshot["snapshot_receipt"]
    lease = lifecycle.lease(resource_id)
    if lease is None or lease["generation"] != generation:
        raise ExecutionArtifactLifecycleError(
            "godot_resource_lease_identity_mismatch"
        )
    run_root = Path(_field(snapshot_receipt, "snapshot_root")).parent
    if lease["state"] == "compacted":
        compaction_path = run_root / COMPACTION_RECEIPT_NAME
        if not compaction_path.is_file() or compaction_path.is_symlink():
            raise ExecutionArtifactLifecycleError(
                "godot_managed_compaction_receipt_missing"
            )
        compaction = json.loads(compaction_path.read_text(encoding="utf-8"))
        completion = lifecycle.complete_finalization(
            resource_id,
            expected_generation=generation,
            terminal_receipt=compaction,
        )
        return {"compaction": compaction, **completion, "blockers": []}
    if process_completion is not None:
        if not isinstance(process_completion, Mapping) or set(
            process_completion
        ) != {"process_group_id", "exit_code", "process_receipt_sha256"}:
            raise ExecutionArtifactLifecycleError(
                "godot_process_completion_not_closed"
            )
        lease = lifecycle.complete_process_group(
            resource_id,
            expected_generation=generation,
            process_group_id=process_completion["process_group_id"],
            exit_code=process_completion["exit_code"],
            process_receipt_sha256=process_completion[
                "process_receipt_sha256"
            ],
        )
    if not isinstance(human_observation_pending, bool):
        raise ExecutionArtifactLifecycleError(
            "human_observation_pending_not_boolean"
        )
    if not isinstance(recovery_pending, bool):
        raise ExecutionArtifactLifecycleError(
            "recovery_pending_not_boolean"
        )
    if isinstance(terminal_consumer_ids, (str, bytes)):
        raise ExecutionArtifactLifecycleError(
            "godot_terminal_consumer_ids_invalid"
        )
    known = {
        consumer["consumer_id"]
        for consumer in lease["retention"]["consumer_ids"]
    }
    if not set(terminal_consumer_ids).issubset(known):
        raise ExecutionArtifactLifecycleError(
            "godot_terminal_consumer_id_not_in_lease"
        )
    for consumer_id in terminal_consumer_ids:
        observed = next(
            consumer
            for consumer in lease["retention"]["consumer_ids"]
            if consumer["consumer_id"] == consumer_id
        )
        if observed["disposition"] == "complete":
            continue
        lease = lifecycle.set_consumer_disposition(
            resource_id,
            expected_generation=generation,
            consumer_id=consumer_id,
            disposition="complete",
        )
    explicit_blockers = []
    if human_observation_pending:
        explicit_blockers.append("human_observation_pending")
    if recovery_pending:
        explicit_blockers.append("recovery_pending")
    if explicit_blockers:
        if lease["state"] == "active":
            held = lifecycle.transition(
                resource_id,
                expected_generation=generation,
                to_state="consumer_hold",
                outcome=terminal_state,
            )
        elif lease["state"] == "consumer_hold":
            held = lease
        else:
            raise ExecutionArtifactLifecycleError(
                "godot_explicit_hold_state_invalid"
            )
        return {
            "compaction": None,
            "lease": held,
            "cleanup_receipt": None,
            "blockers": sorted(explicit_blockers),
        }
    prepared = lifecycle.prepare_finalization(
        resource_id,
        expected_generation=generation,
        outcome=terminal_state,
    )
    if not prepared["ready"]:
        return {
            "compaction": None,
            "lease": prepared["lease"],
            "cleanup_receipt": None,
            "blockers": prepared["blockers"],
        }
    binding = lifecycle.finalization_binding(
        resource_id, expected_generation=generation
    )
    compaction = finalize_godot_execution_artifacts(
        snapshot_receipt,
        terminal_state=terminal_state,
        terminal_receipt_path=terminal_receipt_path,
        human_observation_pending=False,
        recovery_pending=False,
        resource_lease_binding=binding,
    )
    completion = lifecycle.complete_finalization(
        resource_id,
        expected_generation=generation,
        terminal_receipt=compaction,
    )
    return {"compaction": compaction, **completion, "blockers": []}


__all__ = [
    "finalize_godot_execution_artifacts",
    "finalize_managed_godot_execution_artifacts",
    "materialize_managed_godot_execution_snapshot",
]
