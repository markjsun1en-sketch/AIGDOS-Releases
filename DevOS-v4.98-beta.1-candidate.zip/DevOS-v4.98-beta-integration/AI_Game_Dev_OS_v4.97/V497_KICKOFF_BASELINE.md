# v4.97 Slice 0 Successor and Boundary Baseline

Status: exact successor created; root identity reconciliation, Runtime State
repair, Pilot feature selection, project writes, second-Adapter selection and
qualification have not started.

This record is a development baseline. It is not a Decision/Gate transaction,
qualification, `L3/PC-3` disposition, Pack or Adapter promotion, supported
adoption, release, push/tag authority, or production/live authority.

## Controlling identity

| Fact | Exact value |
| --- | --- |
| Development branch | `codex/v497-development` |
| Kickoff repository commit | `251eedeb20d94c734deae987e67356ae589b14ea` |
| Local `main` at kickoff | `251eedeb20d94c734deae987e67356ae589b14ea` |
| Local `origin/main` ref at kickoff | `251eedeb20d94c734deae987e67356ae589b14ea` |
| Controlling plan | `.dev_os_meta/plans/2026-08-21_v4_97_master_implementation_plan.md` |
| Controlling plan revision | `3` |
| Controlling plan commit | `f2d45a68896dde80c11e2c79b022bd5dd3bad69e` |
| v4.96 release peeled commit | `a99ace44a984e58e30c323d84d951d960fac6744` |
| Accepted v4.96 package commit named by the plan | `ae5e120a991c16cb4a98e9c18eed54ebe4a4decc` |
| Accepted v4.96 package subtree | `575cf6a2d6cb20a7ccf1e5a3642b13b612991a4c` |
| Successor root | `AI_Game_Dev_OS_v4.97/` |

Both the plan-named accepted package commit and the peeled release commit
resolve `AI_Game_Dev_OS_v4.96/` to the same accepted subtree above.

## Exact successor preimage

`AI_Game_Dev_OS_v4.97/` was populated directly from the accepted Git tree
object with `git archive`, not copied from a working directory. Before any
successor-only Slice 0 files were added:

- the accepted tree contained 2,465 tracked files;
- the successor preimage contained 2,465 files; and
- `diff -qr AI_Game_Dev_OS_v4.96 AI_Game_Dev_OS_v4.97` returned no
  differences.

The v4.96 package and release snapshot/tag remain unchanged. All later edits
are restricted to `AI_Game_Dev_OS_v4.97/` unless a later Human instruction
explicitly changes the boundary.

## Identity state

The directory is the v4.97 successor, but its inherited root manifest,
entrypoint documents, OS-layer provenance identity and command literals still
contain accepted v4.96 bytes. Slice 0 does not relabel those inherited bytes.
The coherent root/package identity refresh belongs to Slice 1, together with
the inherited Runtime State baseline repair.

Until that refresh passes, this tree must be described as:

`v4.97 successor with accepted v4.96 preimage and Slice 0 contract baseline`

It must not be described as an identity-reconciled v4.97 package.

## Authority and write boundary

Production capability, execution permission and project obligation are
separate facts:

- **Production capability**: Revision 3 describes four composition profiles
  and the full qualification capability envelope; Slice 0 does not implement
  or qualify that envelope.
- **Execution permission**: this kickoff permits successor-local development
  and read-only source-project inventory. It grants no original-project write,
  second-Adapter invocation, protected execution or live contact.
- **Project obligation**: no Pilot feature, admitted lane set, clone write set
  or second Adapter is selected. The full two-maker, independent-QA and
  build/integration chain is therefore not a project obligation and cannot be
  inherited by an ordinary Gate.

Protected/frozen boundaries:

- `AI_Game_Dev_OS_v4.96/` and `v4.96-release` remain immutable;
- original LessIsMore and RandomHeroes repositories remain read-only;
- no disposable or dedicated Pilot clone is created or written before Human
  selection of the exact feature, admitted lanes and per-clone write sets;
- no second Adapter is contacted before Human selection and a separately
  accepted sanitized non-write invocation; and
- no Agent, Skill, Pack, Adapter or target project receives lifecycle,
  professional-efficacy, support or adoption promotion from Slice 0.

## Frozen Gate-local non-escalation fixture

The immutable, non-authoritative fixture is:

`production_runtime/fixtures/gate_local/sp128_g7_non_writing.stage_contract_binding.json`

Frozen SHA-256:

`d2f6e27bc322d08f9fa05604b104786635a6d7a115c82e47ed860f5e6f16d1de`

It is resolve/dry-run-only with an empty write set. Its explicit required
bindings preserve lifecycle, transaction, interaction, focus, the
contract-bound high-risk formal-chain validation, Gate-local integration,
focused acceptance and a Human-owned checkpoint. It also carries one explicitly non-blocking optional
diagnostic stage and the rule that adverse evidence still applies to any
required criterion it directly disproves.

The tracked SP128 G7 source contract contains no PCK artifact clause, and
Revision 3 does not define PCK as a separate contract object. The fixture
therefore selects the source-linked `formal_chain` high-risk validation and
does not fabricate a PCK receipt requirement. PCK, build, package and delivery
integration remain unbound and omitted.

The fixture contains no uncontracted artifact or delivery clause. Its
unbound-stage rule is `omitted`; capability availability, execution permission
and Composition Profile selection cannot add an obligation. The frozen-byte
and semantic invariants live in
`production_runtime/tests/test_slice0_gate_local_fixture.py`.

## Pending Human choices

The read-only project inventory and three compared options are recorded in
`V497_SLICE0_QUALIFICATION_PILOT_CHOICES.md`.

Before any Godot feature implementation or project-clone write, the Human must
select or revise:

1. one bounded feature and its exact two maker domains;
2. admitted maker, independent focused-QA and build/integration lanes;
3. the exact LessIsMore and RandomHeroes tracked-only clone targets;
4. the first-clone and second-clone write sets, accepted separately; and
5. the second Adapter and its later sanitized read/recovery-only invocation.

## Explicit non-claims

Slice 0 does not claim qualification, `L3`, `PC-3`, Unity/Unreal support, a
second concrete engine, second-Adapter project writing, Pack/Adapter
promotion, supported adoption, semantic RAG, cross-machine Team Memory,
automatic semantic merge, web dashboard, bulk Agent/Skill promotion, release,
push/tag authority, or production/live use.
