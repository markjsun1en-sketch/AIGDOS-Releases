# AI Game Dev OS v4.97 Runtime Instance Contract

This contract defines where generated runtime state, project bindings, run
plans, execution traces, and adoption reports belong when v4.97 is used against
a target project.

Runtime instances are not canonical v4.97 definitions. They are outputs from a
specific project run and must live in the target project or an explicit artifact
root.

The `target_project_artifacts/v493/` name below is the inherited production-pack
evidence namespace. Function-first task state uses the bounded project-local
path inherited from `V494_DEVELOPMENT_STATUS.md`; v4.97 Production build, QA,
composition and multi-lane receipts use explicit external artifact roots as
documented in `V496_DEVELOPMENT_STATUS.md`.

## Canonical Versus Runtime

| Category | Location | Examples |
| --- | --- | --- |
| Canonical v4.97 definitions | `AI_Game_Dev_OS_v4.97/` | root docs, `os_layer/`, `pack_layer/`, manifest-enumerated `production_runtime/`, adapters, schemas, validators |
| Adapter contracts | `AI_Game_Dev_OS_v4.97/adapters/` | Codex policy, invocation profile, runtime adapter and Production Cell contracts |
| Runtime project state | `target_project/.ai_dev_os/` | bindings, run plans, execution traces, local reports |
| Runtime artifact evidence | explicit artifact root such as `target_project_artifacts/v493/` | beta report, Shared Truth index, Architecture Baseline, refactor evidence |
| Governance memory | repository-root `.dev_os_meta/` | Problem/Fix/Pattern/Self-Evo evidence and promotion working state |

Canonical files may describe runtime outputs. They must not be overwritten by a
project run.

## Target Project State

Recommended target-project state layout:

```text
target_project/
  .ai_dev_os/
    capability_bindings.json
    codex_runtime_profile.json
    agent_run_plan.json
    agent_execution_trace.json
    reports/
      beta_readiness_report.json
      validation_summary.md
```

The `.ai_dev_os/` directory belongs to the target project. It is not the same as
repository-root `.dev_os_meta/`.

## Artifact Root

Recommended artifact root layout:

```text
target_project_artifacts/
  v493/
    beta_readiness_report.json
    shared_truth_index.json
    architecture_baseline.json
    refactor_evidence/
    qa_evidence/
    gdd_runs/
```

Use an explicit artifact root for large, reviewable, or shareable evidence.
Validators may read this root. They should not mutate the target project unless
an explicit output path is passed.

## Required Runtime Instance Files

| File | Required When | Producer | Validator |
| --- | --- | --- | --- |
| `.ai_dev_os/capability_bindings.json` | Attaching a real project | Codex or runtime adapter | project readiness / beta readiness checks |
| `.ai_dev_os/agent_run_plan.json` | External or multi-agent execution | `generate_agent_run_plan.py` or Codex using the same contract | `validate_agent_execution_trace.py` |
| `.ai_dev_os/agent_execution_trace.json` | Adapter-mediated execution and beta evidence | Codex or runtime adapter | `validate_agent_execution_trace.py` |
| `v493/beta_readiness_report.json` | Beta readiness evaluation | `evaluate_pack_beta_readiness.py` | `render_beta_readiness_report.py` and reviewer gate |
| `v493/shared_truth_index.json` | Shared Truth evaluation | `generate_shared_truth_index.py` | `validate_shared_truth_index.py` |
| `v493/architecture_baseline.json` | Architecture baseline evaluation | `inspect_architecture_baseline.py` | `validate_architecture_baseline.py` |

## Adapter Binding

Codex should use:

- `adapters/codex/codex_integration_policy.json`
- `adapters/codex/codex_invocation_profile.json`
- `adapters/codex/examples/codex_project_binding.example.json`

The example binding is not a real project binding. A real binding belongs in:

```text
target_project/.ai_dev_os/capability_bindings.json
```

## Write Rules

- Generated runtime state must not be written into canonical agents, skills,
  workflows, schemas, or root docs.
- Generated evidence should use `.ai_dev_os/` or an explicit artifact root.
- Repository-root `.dev_os_meta/` may be referenced for governance provenance,
  but runtime execution must not depend on it.
- Fixture outputs remain regression evidence and do not prove real-project
  adoption.
- Lifecycle promotion requires reviewed real-project evidence and a
  runtime-produced `agent_execution_trace.json`.

## Validation Commands

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_agent_execution_trace.py \
  --run-plan <target_project>/.ai_dev_os/agent_run_plan.json \
  --trace <target_project>/.ai_dev_os/agent_execution_trace.json
```

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/evaluate_pack_beta_readiness.py \
  --project-root <target_project> \
  --artifact-root <target_project_artifacts>/v493 \
  --agent-trace <target_project>/.ai_dev_os/agent_execution_trace.json \
  --write-report <target_project_artifacts>/v493/beta_readiness_report.json
```

## Stop Condition

If a task requires writing generated run state into `AI_Game_Dev_OS_v4.97/`
canonical definitions, stop and repair the invocation plan. The correct target
is the target project's `.ai_dev_os/` directory or an explicit artifact root.
