# AI Game Dev OS v4.97 Production Assembly Development Index

> 2026-09-14 current disposition: **limited candidate closed**, package lifecycle **draft**.
> Read [v497 release notes](V497_RELEASE_NOTES.md) and
> [closure state](V497_RELEASE_CLOSURE.json). The dated development records below
> remain historical; their earlier pending-work/release wording does not reopen
> this limited closure. Full qualification and professional efficacy are unverified.

> Use `V497_DEVELOPMENT_STATUS.md` for the current Slice 0/1 surface, accepted
> pre-choice non-writing consumer-derived-state baseline, exact Candidate 1
> Human scope admission, and implemented but unqualified Slice 2-4 development
> baselines, and
> `V497_PACKAGE_IDENTITY_RECONCILIATION.md` for the inherited/current boundary.
> This index does not claim qualification, Gate passage, or release.

This is the root index for `AI_Game_Dev_OS_v4.97/`. It describes the current
version shape, points to the authoritative root-level files, and keeps the
layer-local documents from becoming the whole-version explanation.

## Development batches and serialized consumer validation

Governance policy 1.7.0 separates accepted ordinary batch scope from the exact
identity of each executable candidate. Hash changes require fresh technical
binding and affected checks. An unchanged accepted command/boundary projection
can authorize that binding without another Human gate. Commands, environments,
paths, stage controls, reviewer restrictions and lease controls remain compared;
protected execution still needs separate exact Human acceptance.

`incremental_execution.preflight_ordinary_execution` is shared by candidate
preparation and the run entrypoint. It reads bound files and the real planner
before root writes, and rejects missing inputs, changed bytes or inconsistent
initial/runtime plans. A failed preflight returns the candidate to development;
it is not a new authority event. Old exact authorities and old receipts never
become proof for changed input identities.

The successor adapter exposes two read-only CLI modes: `--rehearse-chain` takes
`--manifest`, `--graph`, `--ie7-receipt` and `--ie7-freeze`; `--rehearse-projection`
takes `--projection`. Paths select existing serialized JSON inputs. Neither
mode creates execution roots or grants execution authority. The projection
mode runs the same contract checks as the supervisor, and the baseline builder
calls it before returning a frozen baseline. Host identity, active sandbox,
Human binding and actual outcomes remain execution-time checks.

Relevant surfaces:

- `production_runtime/contracts/governance/qualification_pilot.execution_governance_policy.json`
- `os_layer/scripts/portable_workspace/batch_a_successor_governed_execution.py`
- `os_layer/tests/portable_workspace/test_successor_serialized_consumption.py`
- `os_layer/fixtures/portable_workspace/successor_recorded_chain/provenance.json`

## Version Shape

v4.97 is a Production Assembly development successor on the exact accepted
v4.96 split-layer base:

- `os_layer/` preserves the v4.92 OS baseline and carries later additions,
  including v4.94 Runtime State development integration.
- `pack_layer/` carries the inherited v4.93 production pack overlay.
- `adapters/` carries first-class AI IDE/runtime integration contracts, starting
  with Codex.
- `production_packs/` carries the draft engine-neutral Candidate 1 Pack,
  Recipe, four Agent contracts and seven Skill contracts.
- `engine_profiles/` carries the concrete Godot 4.4 development profile,
  separate exact Godot/Git host-tool requirements and clean-snapshot runtime.
- `production_runtime/` carries the Slice 0 fixture, accepted read-only
  consumer-derived-state baseline, deterministic Assembly/completion runtime,
  quality harness, exact Candidate 1 contracts/host bindings, fixtures and
  focused tests, plus the ordinary-only incremental planner, receipt journal
  and Resource Lease adapter.
- `packs/`, `scripts/`, and `tests/` are compatibility paths for the stable
  validation entrypoint.
- the repository-root `.dev_os_meta/` remains workspace governance and evidence
  state outside this version directory and outside runtime package content.

The current lifecycle posture is a development candidate, not beta promotion:
the root and production pack manifests declare `lifecycle_status: "draft"`.
The pre-choice consumer-derived-state baseline's Stage/route and internal
receipt checks are not complete Assembly-lock or Evidence-store provenance or
authenticity. Slice 2-4 implementation does not change that historical
artifact. Every authority-sensitive use requires exact component paths and
full object-equal re-resolution of the lock. The exact A8 first-project result
and its bounded Human disposition are recorded in
`V497_DEVELOPMENT_STATUS.md`, but no Pilot functional closure, real
professional-efficacy result, adoption, release, or live evidence exists.

## Root-Level Files

| File | Role |
| --- | --- |
| `V497_DEVELOPMENT_STATUS.md` | Current exact successor, Slice 0/1 facts, accepted pre-choice non-writing contract baseline, Candidate 1 admission, Slice 2-4 development facts, remaining work, and non-claims. |
| `V497_PACKAGE_IDENTITY_RECONCILIATION.md` | Reproducible v4.96-to-v4.97 inventory, root identity decision, and preserved provenance. |
| `V497_KICKOFF_BASELINE.md` | Historical Slice 0 successor and authority boundary at kickoff. |
| `V497_SLICE0_QUALIFICATION_PILOT_CHOICES.md` | Read-only project inventory, Pilot alternatives and exact 2026-08-29 Human selection. |
| `V496_DEVELOPMENT_STATUS.md` | Historical accepted v4.96 multi-lane Production, Evidence/Memory, Team Memory, and exact Pilot status. |
| `V496_PACKAGE_IDENTITY_RECONCILIATION.md` | Historical v4.95-to-v4.96 inventory and root identity refresh. |
| `V495_DEVELOPMENT_STATUS.md` | Historical v4.95 Production-foundation and Evidence Continuity development status. |
| `V495_PACKAGE_IDENTITY_RECONCILIATION.md` | Historical v4.94-to-v4.95 inventory and root identity refresh. |
| `V494_DEVELOPMENT_STATUS.md` | Historical v4.94 function-first capabilities and closure status. |
| `V494_PACKAGE_IDENTITY_RECONCILIATION.md` | Historical v4.93-to-v4.94 inventory and identity refresh. |
| `README.md` | Human-readable version overview and capability map. |
| `CHANGELOG.md` | Version history, migration notes, roadmap alignment, and provenance details. |
| `MANIFEST.json` | Machine-readable version manifest for root, layer, pack, and validation surfaces. |
| `INDEX.md` | This version-level navigation index. |
| `DESIGN_AND_CAPABILITY_ARCHITECTURE.md` | Whole-system architecture map, founding constraints, truth hierarchy, layer model, and capability flow. |
| `MODULES_AND_INVOCATION.md` | Root-level module catalog, invocation routes, write boundaries, and command map. |
| `RUNTIME_INSTANCE_CONTRACT.md` | Target-project `.ai_dev_os/` and artifact-root contract for generated bindings, run plans, traces, and reports. |
| `REAL_PROJECT_ADOPTION_CONTRACT.md` | Required real-project evidence, beta readiness run sequence, and lifecycle promotion gate. |
| `ROOT_MIRROR_POLICY.md` | Decision and validation gate for root `packs/`, `scripts/`, and `tests/` compatibility mirrors. |
| `IDE_INTEGRATION.md` | Bootstrap guide for Codex, WorkBuddy, Cursor, and other AI IDE/runtime integrations. |
| `USER_MANUAL.md` | User-facing manual for the inherited pack workflow with Codex or another runtime adapter. |
| `OS_PACK_LAYER_MAP.md` | Boundary map for `os_layer/`, `pack_layer/`, and compatibility paths. |
| `DELIVERY_CONTRACT.md` | Source tree, release snapshot, mirror sync, and governance appendix delivery rules. |
| `RESTRUCTURING_PLAN.md` | Historical v4.93 restructuring record for adapters, runtime instances, and root mirrors. |
| `OPTIMIZATION_AND_COMPLETION_PLAN.md` | Historical implementation plan, superseded by phase status for current state. |

## Layer Implementation Pointers

| Surface | Role |
| --- | --- |
| `os_layer/README.md` | OS-layer pointer back to root entrypoints; not a whole-version guide. |
| `os_layer/os_control_plane/leads/orchestrator.capability.json` | Orchestrator control capability sheet, including v4.93 OS/Pack resource routing. |
| `os_layer/docs/31_fixops/README.md` | Promoted docs-only FixOps foundation. |
| `pack_layer/README.md` | Pack-layer pointer back to root entrypoints; not a whole-version guide. |
| `pack_layer/packs/game_system_packs/end_to_end_production/capability_pack.json` | v4.93 production pack manifest. |
| `pack_layer/packs/game_system_packs/end_to_end_production/references/end_to_end_delivery_workflow.json` | Pack workflow, skill owners, artifact routes, and gate sequence. |
| `production_runtime/fixtures/gate_local/sp128_g7_non_writing.stage_contract_binding.json` | Frozen non-writing Gate-local Stage Contract Binding fixture. |
| `production_runtime/tests/test_slice0_gate_local_fixture.py` | Frozen-byte and non-escalation semantic checks for that fixture. |
| `production_runtime/cli.py` | Read-only Assembly/validation plus Pack Registry scan/list/inspect/reuse-preview/rollback-verify CLI; no fix, sync, project write, Adapter execution, qualification, release, or live operation. |
| `production_runtime/composition/` | Pure schema validation, derived-state comparison, exact Stage Contract-bound route resolution, deterministic Assembly resolution and completion evaluation. |
| `production_runtime/fixtures/derived_state/lessismore_sp129_sanitized/` | Sanitized consumer regression fixture set; not a real project binding or adoption record. |
| `production_runtime/tests/test_validation_*.py` | Focused schema, route, derived-state and CLI non-writing checks. |
| `schemas/derived_state_binding.schema.json` | Closed contract for canonical-to-derived projection identity and authority separation. |
| `schemas/validation_discrepancy.schema.json` | Closed typed expected/actual discrepancy Evidence contract. |
| `schemas/validation_route.schema.json` | Closed product/compatibility validation-route contract with separate capability, permission and obligation. |
| `production_packs/runtime_feature_slice/` | Draft engine-neutral Candidate 1 capability Pack, Recipe, four Agent contracts and seven Skill contracts. |
| `production_runtime/composition/assembly.py` | Deterministic discovery/resolution, content-addressed lock generation, structural inspection and full-bundle object-equal re-resolution for authority-sensitive use. |
| `production_runtime/composition/completion.py` | Pure completion evaluation after exact component-path re-resolution, including optional adverse-evidence semantics. |
| `production_runtime/contracts/composition_profiles/` | Closed `gate_local`, `milestone`, `closure` and `qualification_pilot` profiles. |
| `production_runtime/contracts/candidate1/` | Neutral Candidate 1 QA/authority/stage contracts plus exact LessIsMore and RandomHeroes host chains. |
| `production_runtime/contracts/governance/qualification_pilot.execution_governance_policy.json` | Frozen five-scope execution-governance routing plus high-risk execution-readiness assurance; freezes the policy-ordered probe/subject map while separating product source, runtime scratch, Evidence, external contact and protected transitions without granting execution authority. |
| `production_runtime/governance_assurance.py` | Pure claim-to-test, static-validation, independent-falsification and sandbox-parity evaluator; binds every probe to its authoritative subject, checks launch order and attestation stdout/receipt equality, reconstructs the fingerprint, and returns at most internal-consistency `freeze_eligible`. |
| `production_runtime/governance_assurance_preflight.py` | Receipt producer for deterministic static validation plus policy-ordered one-command-per-probe macOS sandbox checks; embeds exact-runner attestation, authoritative subjects, actual launch order, profile/argv/results and runtime-versus-construction derivation in one self-cleaning ephemeral root. |
| `os_layer/scripts/portable_workspace/batch_a_governed_execution.py` | Frozen Batch A protected runner; distinguishes generic in-process macOS deny observations from the supported exact profile, rejects conflicting duplicate input hashes and malformed libproc sizing, tracks initial process groups plus same-session descendants, retries vanished-PID inventories, and performs identity, Evidence, failure and same-process cleanup checks inside the OS boundary. |
| `os_layer/fixtures/portable_workspace/v497_slice9_batch_a_a3.sb` | Exact A3 macOS sandbox profile: network denied, WorkBuddy reads denied, and writes restricted to `/dev/null` plus the two Human-bound A3 roots. |
| `os_layer/tests/portable_workspace/test_batch_a_governed_execution.py` | Active-sandbox/forged-marker, direct launch, duplicate-input identity, Git-config, signal/full failure Evidence, inherited process-group/same-session escape, malformed/fork-churn inventory, bounded successful vanished-PID retry invariants and same-process cleanup regressions. |
| `production_runtime/quality/` | Contract validation, source-observation aggregation, efficacy receipt evaluation and pre-Pilot baseline helpers. |
| `production_runtime/fixtures/assembly/` | Non-writing Assembly fixtures for Gate-local and Candidate 1 boundary tests. |
| `production_runtime/fixtures/quality/` | Synthetic quality corpus, sealed split/observations and honest pre-Pilot incomplete baselines. |
| `engine_profiles/godot/` | Godot 4.4 Engine Profile, separate Godot/Git host-tool requirements and fresh-identity clean-snapshot startup/export runtime. |
| `engine_profiles/godot/artifact_lifecycle.py` | Godot terminal finalizer; snapshot/build/cache removal is blocked while Human observation or recovery is pending. |
| `production_runtime/execution_artifact_lifecycle.py` | Fail-closed, receipt-preserving compaction for terminal isolated run roots. |
| `production_runtime/tests/test_execution_artifact_lifecycle.py` | Schema, containment, restart, idempotence, consumer-hold and focused-QA lifecycle regressions. |
| `production_runtime/pack_registry.py` | Explicit content-addressed Pack scan, exact cross-project reuse preview, deny-by-default inheritance exclusions, target write/validation plan and temporary-index rollback verification. |
| `schemas/pack_registry_snapshot.schema.json`, `schemas/pack_registry_template_manifest.schema.json` | Closed non-writing Pack/Recipe/Profile/Agent/Skill/template observation and explicit template-manifest contracts with lifecycle and professional-efficacy separation. |
| `schemas/cross_project_reuse_preview.schema.json`, `schemas/cross_project_reuse_receipt.schema.json` | Closed exact-core reuse, target, chronology and non-inheritance contracts. |
| `schemas/rollback_materialization_receipt.schema.json` | Closed per-path and bidirectional Git-tree rollback verification contract. |
| `production_runtime/tests/test_pack_registry_reuse.py` | Determinism, exact-core, write-boundary, CLI, tamper, undeclared-delta and isolated rollback regressions. |
| `production_runtime/integrated_closure.py` | Read-only exact package/two-Assembly replay, hash-and-pointer Evidence binding, seven-dimension comparison matrix and eight-family negative inventory with no aggregate score. |
| `schemas/integrated_functional_preclosure_receipt.schema.json` | Closed Slice 9 pre-closure receipt; required, useful and optional states stay distinct and unsupported cells remain visible. |
| `production_runtime/tests/test_integrated_closure.py` | Identity, omission, tamper, dirty-tree, negative-isolation and non-aggregation regressions for integrated pre-closure. |
| `production_runtime/incremental_execution.py` | Content-addressed invalidation planner plus exact ordinary IE0-IE7 executor, closed prior-reuse/current-run receipt validation, dual implementation/carrier identity gate, atomic attempt journal and adapter to the existing Resource Lifecycle owner. Its protected graph validator preserves predecessor `IE9 <- IE8` and admits only ordered successor `IE9 <- [IE7, IE8]`; the executor still cannot cross IE7 without later protected authority. |
| `production_runtime/fixtures/incremental_execution/` | Sanitized successor manifest, exact IE0-IE10 graph and Stage Contract Binding facts; project entries are read-only identities and create no project obligation or authority. |
| `production_runtime/tests/test_incremental_execution.py` | The separately named 86-case identity, exact execution-contract, restart, authority, composition, resource, derived-state and final-assembly matrix, including canonical lease-fence mapping, post-transition recovery checkpoints and exact predecessor/successor IE9 dependency-shape coverage. |
| `os_layer/scripts/portable_workspace/batch_a_successor_governed_execution.py` | Corrected but unexecuted successor IE9/IE10 supervisor-worker adapter: source-derived one-build allocation validation, closed two-phase projection/materialization, exact Human authority, actual IE7/IE8/IE9 receipt-chain recomputation, sandbox attestation, one lease, process/session fencing, selected historical A3 domain helpers and success-only compaction. |
| `os_layer/fixtures/portable_workspace/v497_successor_protected_seed/snapshot/seed.json` | Non-authority package seed for exact sparse-declared materialization of the future protected attempt's `snapshot/` child. |
| `schemas/v497_successor_protected_execution.schema.json` | Draft-07 `oneOf` contract for thirteen closed successor artifacts, including the non-executable authority template, envelope projection and exact protected-execution baseline used by the create-once materialization protocol. |
| `os_layer/tests/portable_workspace/test_batch_a_successor_governed_execution.py` | 84 separately named synthetic cases covering source-derived allocation composition, projection/materialization, actual dependency receipts, authority, sandbox identity, lease/fence, historical runner/profile parity, receipt/retention and failure/interruption without launching IE9/IE10 or creating reserved roots. |
| `adapters/codex/v497_candidate1.execution_adapter.json` | Candidate 1 Codex execution capability binding; cannot widen canonical ownership or completion semantics. |
| `adapters/codex/references/` | Exact Codex tool/renderer implementation references used by Assembly resolution. |
| `production_runtime/tests/conftest.py` | Package-local import bootstrap for the documented repository-root Production Runtime test entrypoint. |
| `production_runtime/tests/test_assembly_*.py` | Assembly schema, resolution, completion, CLI and boundary tests. |
| `production_runtime/tests/test_quality_*.py` | Quality schema, aggregation, evaluation and baseline tests. |
| `production_runtime/tests/test_godot_engine_profile.py` | Exact host tool, clean snapshot, containment, startup/export and failure-boundary tests. |
| `production_runtime/tests/test_candidate1_host_bindings.py` | Exact Codex/Project/QA/authority/stage/lock host-chain tests. |
| `production_runtime/tests/test_qualification_execution_governance_policy.py` | Frozen-digest, closed-schema and semantic regression checks for retry, delegation, routing and non-authority rules. |
| `production_runtime/tests/test_execution_readiness_assurance.py` | Fail-closed assurance regressions for missing tests and probes, reviewer independence, argv/hash/order or embedded-attestation drift, fingerprint reconstruction, chronology and non-authority. |

## Adapter Entrypoints

| Surface | Role |
| --- | --- |
| `adapters/README.md` | Adapter directory map and canonical-source boundary. |
| `adapters/AI_IDE_ADAPTER_BASE.md` | Shared AI IDE adapter base for read order, runtime state, evidence, and stop conditions. |
| `adapters/codex/README.md` | Codex adapter, function-first, and Production-foundation file map. |
| `adapters/codex/codex_integration_policy.json` | Codex read order, boundary, evidence, validation, and runtime-output policy. |
| `adapters/codex/codex_invocation_profile.json` | Codex goal-class routing profile and runtime instance policy. |
| `adapters/codex/codex_runtime_adapter_contract.md` | Human-readable Codex execution contract. |
| `adapters/codex/development_task_adapter.py` | Function-first project-local task, Truth binding, closure, and read-only spec-replay API. |
| `adapters/codex/development_project_memory.py` | Explicit post-closure project-memory promotion and bounded retrieval. |
| `adapters/codex/multi_lane_coordinator.py` | Engine-neutral DAG admission, overlap checks, truthful aggregate, retry, cancellation, and recovery. |
| `adapters/codex/multi_lane_workspace.py` | Bounded workspace identity and write-envelope support for maker lanes. |
| `adapters/codex/godot_multi_lane_profile.py` | The single concrete Godot local-development multi-lane profile. |
| `adapters/codex/development_evidence_lifecycle.py` | Append-only Evidence invalidation, supersession, retention, and current-head resolution. |
| `adapters/codex/development_project_memory_lifecycle.py` | Append-only Project Memory lifecycle and conservative current-head resolution. |
| `adapters/codex/development_project_permissions.py` | Deny-by-default project principal/source capability decisions. |
| `adapters/codex/permission_aware_project_retrieval.py` | Permission and lifecycle filtering before deterministic advisory ranking. |
| `adapters/codex/development_project_compatibility_migration.py` | Selected, dry-runnable, non-destructive v4.95-to-v4.96 migration. |
| `adapters/codex/team_memory_provider.py` | Optional default-off Team Memory Provider contract and exact-scope client. |
| `adapters/codex/local_team_memory_provider.py` | Same-host, single-project local Provider implementation with explicit publication. |
| `adapters/codex/team_memory_status.py` | Read-only Provider state and current-actor permission projection; no Memory enumeration or authority claim. |
| `bin/ai-dev-os team-memory status` | Package-local human-table / agent-JSON status CLI. |
| `adapters/codex/production_worker.py` | Bounded one-task Worker with exact input and three-envelope write enforcement. |
| `adapters/codex/godot_execution_adapter.py` | Typed Godot local-development execution boundary. |
| `adapters/codex/godot_development_build.py` | Reproducible identified macOS development-build delivery and recovery checks. |
| `adapters/codex/godot_focused_qa.py` | Independent clean-source focused-QA runner. |
| `adapters/codex/candidate1_focused_qa_runtime_v1_2_0.py` | Candidate 1 prepared QA successor that copies the exact macOS Godot app into per-run scratch, confines self-contained `editor_data`, and verifies the shared support root before/after. |
| `adapters/codex/candidate1_focused_qa_runtime_v1_3_0.py` | Managed lifecycle successor that reserves an exact resource lease before invoking byte-frozen v1.2.0 and compacts only after declared consumers close. |
| `os_layer/scripts/portable_workspace/resource_lifecycle.py` | Fenced allocation/lease, semantic quota, materialization, consumer/process hold, audit, recovery and non-executable GC-plan service. |
| `os_layer/scripts/portable_workspace/resource_lifecycle_cli.py` | Structured package-local lease/read/audit/reconcile/reference/GC-plan CLI; no allocate/apply/delete command. |
| `os_layer/runtime/integrations/git/git_branch_cleanup.py` | Managed Git object-base/worktree materialization plus exact non-forced plan/revalidate/release; automatic branch deletion is rejected. |
| `adapters/codex/production_spec_input_bridge.py` | Read-only deterministic mapping from one validated Production Spec into a selected feature input, with bounded optional augmentations. |
| `adapters/codex/bindings/godot_production_spec_input.binding.json` | Godot Production Spec handoff compatibility binding, separate from the composition profile identity. |
| `adapters/codex/production_cell_composition.py` | Engine-neutral four-stage Production Cell composition contract. |
| `adapters/codex/godot_local_development_profile.py` | The single implemented v4.96 concrete composition profile. |
| `adapters/cursor/README.md` | Cursor adapter pointer and file map. |
| `adapters/cursor/cursor_integration_policy.json` | Cursor read order, boundary, evidence, validation, and runtime-output policy. |
| `adapters/cursor/cursor_invocation_profile.json` | Cursor goal-class routing profile and runtime instance policy. |
| `adapters/cursor/cursor_runtime_adapter_contract.md` | Human-readable Cursor execution contract. |
| `adapters/workbuddy_private/README.md` | WorkBuddy private adapter pointer and file map. |
| `adapters/workbuddy_private/workbuddy_private_integration_policy.json` | WorkBuddy read order, boundary, evidence, validation, and runtime-output policy. |
| `adapters/workbuddy_private/workbuddy_private_invocation_profile.json` | WorkBuddy goal-class routing profile and runtime instance policy. |
| `adapters/workbuddy_private/workbuddy_private_runtime_adapter_contract.md` | Human-readable WorkBuddy private execution contract. |

## Contract Schema Entrypoints

| Surface | Role |
| --- | --- |
| `schemas/version_manifest.schema.json` | Root `MANIFEST.json` structure, lifecycle, adapter, delivery, and validation contract. |
| `schemas/production_capability_pack.schema.json`, `schemas/feature_recipe.schema.json`, `schemas/composition_profile.schema.json` | Engine-neutral Pack, Recipe and profile contracts; capability and eligible stage shape do not create permission or obligation. |
| `schemas/agent_contract.schema.json`, `schemas/skill_contract.schema.json` | Canonical draft Agent/Skill ownership, boundary, handoff and quality-profile references. |
| `schemas/engine_profile.schema.json`, `schemas/host_tool_requirement.schema.json`, `schemas/execution_adapter.schema.json` | Concrete engine/tool and Adapter capability contracts outside the neutral Pack/Recipe. |
| `schemas/project_binding.schema.json`, `schemas/qa_evidence_policy.schema.json`, `schemas/stage_authority_source.schema.json`, `schemas/stage_contract_binding.schema.json` | Exact project permission, Evidence policy and controlling-clause authority chain. |
| `schemas/qualification_execution_governance_policy.schema.json` | Closed frozen policy for five execution scope classes, ordinary iteration, independent execution-readiness assurance, Human-authority boundaries and actual hard-stop violations. |
| `schemas/v497_batch_a_evidence.schema.json` | Closed A2/A3 execution, full regression-failure, terminal, manifest and cleanup receipt shapes. |
| `schemas/assembly_reference_contract.schema.json`, `schemas/assembly_lock.schema.json`, `schemas/assembly_completion_evaluation.schema.json` | Content-addressed Assembly references, deterministic lock and non-authoritative completion evaluation. |
| `schemas/capability_quality_profile.schema.json`, `schemas/benchmark_split.schema.json`, `schemas/professional_efficacy_receipt.schema.json`, `schemas/baseline_comparison.schema.json`, `schemas/support_cell.schema.json` | Quality rubric/split, source-linked efficacy, comparison and exact support-cell contracts with separate states. |
| `schemas/ai_ide_integration_policy.schema.json` | Shared schema for Codex, Cursor, and WorkBuddy integration policies. |
| `schemas/ai_ide_invocation_profile.schema.json` | Shared schema for Codex, Cursor, and WorkBuddy invocation profiles. |
| `schemas/production_skill_tool_binding.schema.json` | Production Skill/Agent/tool binding contract. |
| `schemas/godot_development_build_delivery.schema.json` | Factual Godot development-build receipt contract. |
| `schemas/focused_qa_tool_binding.schema.json` | Focused-QA binding contract. |
| `schemas/v497_candidate1_focused_qa_disposable_tool_binding.schema.json` | Exact Candidate 1 binding for disposable Godot-tool materialization before project load and focused QA. |
| `schemas/execution_artifact_compaction_receipt.schema.json` | Prepared/completed tombstone for terminal transient-artifact compaction with durable Evidence/log identities. |
| `schemas/resource_allocation_request.schema.json`, `schemas/resource_lease.schema.json`, `schemas/resource_reference_manifest.schema.json` | Closed creation-time identity, authority, materialization, ownership, forward-reference and lease-state contracts. |
| `schemas/resource_audit_snapshot.schema.json`, `schemas/resource_gc_plan.schema.json`, `schemas/resource_cleanup_receipt.schema.json` | Closed read-only audit, non-executable cleanup planning and exact terminal receipt chain. |
| `schemas/incremental_execution_input_manifest.schema.json`, `schemas/incremental_execution_stage_graph.schema.json` | Closed canonical input inventory and deterministic stage-dependency graph contracts; graph `1.1.0` adds exact roots, path bindings, commands and lease requests while retaining `1.0.0` fixture validation. |
| `schemas/incremental_execution_stage_receipt.schema.json`, `schemas/incremental_execution_plan_receipt.schema.json` | Closed immutable terminal-stage and explicitly non-executable planning receipt contracts; receipt `1.1.0` binds graph/idempotency/path and process-lease fences. |
| `schemas/production_spec_input_bridge_request.schema.json` | Required feature/profile/source/write selection plus optional augmentation contract. |
| `schemas/production_spec_input_bridge_result.schema.json` | Schema-valid mapping trace, selected feature input, conflicts, provenance, and non-authority result. |
| `schemas/production_spec_profile_input_binding.schema.json` | Production Spec handoff compatibility to a target Production Cell profile binding. |
| `schemas/production_cell_profile_binding.schema.json` | Engine-profile stage binding contract. |
| `schemas/production_cell_composition_result.schema.json` | Ordered non-authoritative composition receipt contract. |
| `schemas/project_permission_policy.schema.json` | Deny-by-default project and Team Memory permission policy. |
| `schemas/multi_lane_plan.schema.json` | Engine-neutral lane owners, dependencies, reads, writes, checks, and attempt contract. |
| `schemas/multi_lane_aggregate_result.schema.json` | Truthful aggregate result and required-lane completion contract. |
| `schemas/multi_lane_recovery_receipt.schema.json` | Bounded retry and partial-recovery receipt contract. |
| `schemas/evidence_lifecycle_receipt.schema.json` | Append-only Evidence lifecycle receipt. |
| `schemas/project_memory_lifecycle_receipt.schema.json` | Append-only Project Memory lifecycle receipt. |
| `schemas/permission_aware_project_retrieval_index.schema.json` | Eligible source-linked retrieval view after permission/lifecycle filtering. |
| `schemas/team_memory_activation_binding.schema.json` | Explicit Provider installation/activation and exact-scope binding. |
| `schemas/team_memory_status_snapshot.schema.json` | Read-only Provider/actor permission status snapshot contract. |

## Capability Entrypoints

| Capability Area | Primary Files |
| --- | --- |
| Current v4.97 status | `V497_DEVELOPMENT_STATUS.md`, `V497_PACKAGE_IDENTITY_RECONCILIATION.md` |
| Inherited v4.96 status | `V496_DEVELOPMENT_STATUS.md`, `V496_PACKAGE_IDENTITY_RECONCILIATION.md` |
| Slice 0 Gate-local fixture | `production_runtime/fixtures/gate_local/sp128_g7_non_writing.stage_contract_binding.json`, `production_runtime/tests/test_slice0_gate_local_fixture.py` |
| Consumer-derived-state contract baseline | `production_runtime/cli.py`, `production_runtime/composition/`, `production_runtime/fixtures/derived_state/lessismore_sp129_sanitized/`, `production_runtime/tests/test_validation_*.py`, `schemas/derived_state_binding.schema.json`, `schemas/validation_discrepancy.schema.json`, `schemas/validation_route.schema.json` |
| Slice 2 Production Assembly development baseline | `production_packs/runtime_feature_slice/`, `production_runtime/composition/assembly.py`, `production_runtime/composition/completion.py`, `production_runtime/contracts/composition_profiles/`, `production_runtime/fixtures/assembly/`, `production_runtime/tests/test_assembly_*.py` |
| Qualification-Pilot execution governance | `production_runtime/contracts/governance/qualification_pilot.execution_governance_policy.json`, `production_runtime/governance_assurance.py`, `production_runtime/governance_assurance_preflight.py`, `schemas/qualification_execution_governance_policy.schema.json`, `production_runtime/tests/test_qualification_execution_governance_policy.py`, `production_runtime/tests/test_execution_readiness_assurance.py` |
| Slice 3 quality development baseline | `production_runtime/quality/`, `production_runtime/fixtures/quality/`, `production_runtime/tests/test_quality_*.py`, `schemas/capability_quality_profile.schema.json`, `schemas/professional_efficacy_receipt.schema.json` |
| Slice 4 Godot/Codex host-binding development baseline | `engine_profiles/godot/`, `adapters/codex/v497_candidate1.execution_adapter.json`, `adapters/codex/references/`, `production_runtime/contracts/candidate1/host_bindings/`, `production_runtime/tests/test_godot_engine_profile.py`, `production_runtime/tests/test_candidate1_host_bindings.py` |
| Slice 8 Pack Registry and exact reuse baseline | `production_runtime/pack_registry.py`, `production_runtime/tests/test_pack_registry_reuse.py`, `schemas/pack_registry_snapshot.schema.json`, `schemas/cross_project_reuse_preview.schema.json`, `schemas/cross_project_reuse_receipt.schema.json`, `schemas/rollback_materialization_receipt.schema.json` |
| Slice 9 integrated functional pre-closure | `production_runtime/integrated_closure.py`, `production_runtime/tests/test_integrated_closure.py`, `schemas/integrated_functional_preclosure_receipt.schema.json` |
| Incremental execution corrective | `production_runtime/incremental_execution.py`, `production_runtime/fixtures/incremental_execution/`, `production_runtime/tests/test_incremental_execution.py`, `schemas/incremental_execution_input_manifest.schema.json`, `schemas/incremental_execution_stage_graph.schema.json`, `schemas/incremental_execution_stage_receipt.schema.json`, `schemas/incremental_execution_plan_receipt.schema.json` |
| Resource lease and retention corrective | `os_layer/scripts/portable_workspace/resource_lifecycle.py`, `engine_profiles/godot/artifact_lifecycle.py`, `adapters/codex/candidate1_focused_qa_runtime_v1_3_0.py`, `production_runtime/execution_artifact_lifecycle.py`, `os_layer/tests/portable_workspace/`, `production_runtime/tests/test_resource_managed_artifact_lifecycle.py` |
| Function-first development | `V494_DEVELOPMENT_STATUS.md`, `adapters/codex/development_task_adapter.py`, `adapters/codex/development_project_memory.py`, `os_layer/scripts/runtime_state/` |
| Multi-lane Production | `adapters/codex/multi_lane_coordinator.py`, `adapters/codex/multi_lane_workspace.py`, `adapters/codex/godot_multi_lane_profile.py`, `scripts/development/` |
| Evidence/Memory lifecycle and migration | `adapters/codex/development_evidence_lifecycle.py`, `adapters/codex/development_project_memory_lifecycle.py`, `adapters/codex/development_project_compatibility_migration.py` |
| Permission-aware retrieval | `adapters/codex/development_project_permissions.py`, `adapters/codex/permission_aware_project_retrieval.py` |
| Optional Team Memory status | `adapters/codex/team_memory_provider.py`, `adapters/codex/team_memory_status.py`, `schemas/team_memory_status_snapshot.schema.json`, `bin/ai-dev-os team-memory status` |
| Production Worker and target feedback | `adapters/codex/production_worker.py`, `adapters/codex/godot_execution_adapter.py` |
| Development build and focused QA | `adapters/codex/godot_development_build.py`, `adapters/codex/godot_focused_qa.py`, `scripts/development/` |
| Production Spec input bridge | `adapters/codex/production_spec_input_bridge.py`, `adapters/codex/bindings/godot_production_spec_input.binding.json`, `schemas/production_spec_input_bridge_request.schema.json`, `schemas/production_spec_input_bridge_result.schema.json`, `schemas/production_spec_profile_input_binding.schema.json` |
| Production Cell composition | `adapters/codex/production_cell_composition.py`, `adapters/codex/godot_local_development_profile.py`, `adapters/codex/bindings/godot_local_development.profile.json` |
| Orchestrator routing | `os_layer/os_control_plane/leads/orchestrator.capability.json`, `pack_layer/scripts/delivery/generate_agent_run_plan.py` |
| GDD orchestration | `pack_layer/scripts/delivery/run_gdd_orchestrator.py`, `pack_layer/packs/game_system_packs/end_to_end_production/skills/gdd_orchestrator_skill.json` |
| Shared Truth | `pack_layer/scripts/delivery/generate_shared_truth_index.py`, `pack_layer/scripts/delivery/validate_shared_truth_index.py` |
| Architecture Baseline | `pack_layer/scripts/delivery/inspect_architecture_baseline.py`, `pack_layer/scripts/delivery/validate_architecture_baseline.py` |
| Controlled Refactor | `pack_layer/scripts/delivery/evaluate_controlled_refactor_demo.py`, `pack_layer/scripts/delivery/validate_controlled_refactor_artifacts.py` |
| Agent Harness | `pack_layer/packs/game_system_packs/end_to_end_production/docs/agent_harness/RUNTIME_ADAPTER_SPEC.md`, `pack_layer/scripts/delivery/validate_agent_execution_trace.py` |
| Runtime instance boundary | `RUNTIME_INSTANCE_CONTRACT.md`, `adapters/AI_IDE_ADAPTER_BASE.md`, adapter invocation profiles |
| Real-project adoption | `REAL_PROJECT_ADOPTION_CONTRACT.md`, `pack_layer/packs/game_system_packs/end_to_end_production/docs/beta/REAL_PROJECT_ADOPTION_CHECKLIST.md` |
| AI IDE adapters | `adapters/AI_IDE_ADAPTER_BASE.md`, `adapters/codex/`, `adapters/cursor/`, `adapters/workbuddy_private/` |
| Beta Readiness | `pack_layer/scripts/delivery/evaluate_pack_beta_readiness.py`, `pack_layer/scripts/delivery/render_beta_readiness_report.py` |
| FixOps/problem intake | `os_layer/docs/31_fixops/README.md`, repository-root `.dev_os_meta/fixops/INDEX.md` |
| Mirror sync | `scripts/delivery/validate_pack_layer_mirror.py`, `pack_layer/scripts/delivery/validate_pack_layer_mirror.py` |
| Root mirror policy | `ROOT_MIRROR_POLICY.md`, `pack_layer/packs/game_system_packs/end_to_end_production/docs/roadmap/CLI_COMMAND_MATRIX.md` |
| Release snapshot freshness | `scripts/delivery/validate_release_snapshot_freshness.py`, `pack_layer/scripts/delivery/validate_release_snapshot_freshness.py` |
| Delivery transient diagnosis | `scripts/delivery/validate_delivery_transients.py`, `pack_layer/scripts/delivery/validate_delivery_transients.py` |

## AI IDE Bootstrap

For Codex, WorkBuddy, Cursor, or another mounted AI runtime, use
`DESIGN_AND_CAPABILITY_ARCHITECTURE.md`, `MODULES_AND_INVOCATION.md`,
`RUNTIME_INSTANCE_CONTRACT.md`,
`REAL_PROJECT_ADOPTION_CONTRACT.md`, `ROOT_MIRROR_POLICY.md`, and
`IDE_INTEGRATION.md` as the first operational protocols after this index. The
AI IDE should read the root manifest, whole-system architecture map, root module
catalog, runtime instance contract, real-project adoption contract, root mirror
policy, Orchestrator control sheet, production pack manifest, delivery workflow,
and user manual before selecting a pack, agent, skill, script, or governance
workflow.

The required routing shape is:

```text
natural-language goal -> goal class -> OS/Pack resource -> owner -> evidence -> validation -> stop condition
```

Repository scripts may generate contracts, briefs, reports, run plans, and
validators. They do not directly execute LLM agents.

## Status Entrypoints

| File | Use |
| --- | --- |
| `pack_layer/packs/game_system_packs/end_to_end_production/docs/roadmap/PHASE_STATUS.md` | Current completed phases and remaining lifecycle-promotion prerequisites. |
| `pack_layer/packs/game_system_packs/end_to_end_production/docs/roadmap/FOLLOWUP_OPTIMIZATION_PLAN.md` | Completed follow-up optimization work and selector strategy. |
| `pack_layer/packs/game_system_packs/end_to_end_production/docs/roadmap/FILE_ORGANIZATION_STATUS.md` | File organization decisions and generated-output exclusions. |
| `pack_layer/packs/game_system_packs/end_to_end_production/docs/beta/REAL_PROJECT_ADOPTION_CHECKLIST.md` | Required real-project evidence before beta promotion. |
| `RESTRUCTURING_PLAN.md` | Historical split-layer restructuring rationale; not the active v4.97 command source. |
| `RUNTIME_INSTANCE_CONTRACT.md` | Runtime output placement and target-project evidence boundary. |
| `REAL_PROJECT_ADOPTION_CONTRACT.md` | Real-project evidence and manual lifecycle promotion gate. |
| `ROOT_MIRROR_POLICY.md` | Active compatibility mirror decision and deprecation rule. |

## Validation Entrypoints

Canonical root compatibility entrypoint:

```bash
python3 -m pytest AI_Game_Dev_OS_v4.97/tests/delivery/test_v493_end_to_end_skill_contracts.py -q --tb=short
```

Pack-layer mirror entrypoint:

```bash
python3 -m pytest AI_Game_Dev_OS_v4.97/pack_layer/tests/delivery/test_v493_end_to_end_skill_contracts.py -q --tb=short
```

Complete successor-local Production Runtime entrypoint:

```bash
python3 -m pytest AI_Game_Dev_OS_v4.97/production_runtime/tests -q --tb=short
```

Successor protected-adapter implementation validation (does not run the
protected command):

```bash
PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONHASHSEED=0 python3 -I -B -m pytest -p no:cacheprovider AI_Game_Dev_OS_v4.97/os_layer/tests/portable_workspace/test_batch_a_successor_governed_execution.py -q
```

This verifies development contracts and implementations only. It does not
establish qualification, professional efficacy, a supported cell, Human
observation, adoption, release, or production/live authority.

Markdown path check:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_markdown_local_paths.py
python3 AI_Game_Dev_OS_v4.97/pack_layer/scripts/delivery/validate_markdown_local_paths.py
```

Mirror sync check:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_pack_layer_mirror.py
```

Release snapshot freshness diagnosis for ordinary development:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_release_snapshot_freshness.py
```

Use `--strict` only for an explicitly selected release-snapshot delivery, not
as a prerequisite for ordinary development or development handoff.

Transient file diagnosis:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_delivery_transients.py --strict
```

OS-layer boundary docs test:

```bash
python3 -m pytest AI_Game_Dev_OS_v4.97/os_layer/tests/test_v493_layer_boundary_docs.py -q --tb=short
```

Patch hygiene:

```bash
git diff --check -- AI_Game_Dev_OS_v4.97
```

## Boundaries

- runtime adapter lanes are the handoff surface for external agent execution;
  repository scripts generate and validate contracts but do not execute LLM
  agents directly.
- Root files own v4.97 entrypoints, module selection, invocation instructions,
  and validation commands.
- Do not treat `os_layer/README.md` as the v4.97 total-version README.
- Do not treat `pack_layer/README.md` as the v4.97 total-version README.
- Do not treat repository-root `.dev_os_meta/` as runtime package content.
- Do not treat Python delivery scripts as automatic LLM agent routers.
- Do not promote `lifecycle_status` from `draft` without real-project beta
  readiness evidence and reviewed runtime-produced agent trace.
- LessIsMore is ordinary execution-ready only; RandomHeroes remains
  resolve-only and WorkBuddy remains uncontacted pending a separate exact
  non-writing invocation approval.
