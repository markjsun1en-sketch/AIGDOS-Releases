"""Bridge one validated Production Spec into a Production Cell feature input.

The bridge is engine-neutral and read-only.  It validates an existing
``game_design_production_spec``, combines deterministic default mappings with
an explicit runtime selection, and preserves optional augmentation bindings in
the result.  It does not execute a Worker or profile, modify project state,
approve design, evaluate a Gate, or grant release/production/live authority.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from adapters.codex.production_cell_composition import SelectedFeatureSpec


MAX_JSON_BYTES = 2 * 1024 * 1024
_RESERVED_OVERRIDE_FIELDS = {
    "accepted_behavior",
    "accepted_behavior_delta",
    "acceptance_criteria",
    "declared_write_surfaces",
    "expected_source_revision",
    "feature_id",
    "target_profile_id",
    "task_id",
}


class ProductionSpecInputBridgeError(ValueError):
    """Raised when a bridge contract or source artifact is malformed."""


def _load_json_object(
    raw_path: str | Path,
    label: str,
) -> tuple[Path, dict[str, Any], str]:
    candidate = Path(raw_path)
    if not candidate.is_absolute() or "\x00" in str(candidate):
        raise ProductionSpecInputBridgeError(
            f"{label} path must be absolute and safe"
        )
    try:
        path = candidate.resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise ProductionSpecInputBridgeError(
            f"missing or unreadable {label}: {candidate}"
        ) from exc
    if not path.is_file():
        raise ProductionSpecInputBridgeError(f"{label} must be a file: {path}")
    try:
        payload = path.read_bytes()
    except OSError as exc:
        raise ProductionSpecInputBridgeError(
            f"unable to read {label}: {path}"
        ) from exc
    if len(payload) > MAX_JSON_BYTES:
        raise ProductionSpecInputBridgeError(
            f"{label} exceeds the {MAX_JSON_BYTES}-byte read limit"
        )
    try:
        value = json.loads(payload.decode("utf-8"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise ProductionSpecInputBridgeError(
            f"{label} must be a UTF-8 JSON object: {path}"
        ) from exc
    if not isinstance(value, dict):
        raise ProductionSpecInputBridgeError(
            f"{label} must contain a JSON object: {path}"
        )
    return path, value, hashlib.sha256(payload).hexdigest()


def _validate_json(
    value: Mapping[str, Any],
    schema: Mapping[str, Any],
    label: str,
) -> None:
    try:
        import jsonschema
    except ImportError as exc:
        raise ProductionSpecInputBridgeError(
            "jsonschema is required for Production Spec input bridging"
        ) from exc
    try:
        jsonschema.Draft7Validator(schema).validate(value)
    except jsonschema.ValidationError as exc:
        location = ".".join(str(item) for item in exc.absolute_path)
        suffix = f" at {location}" if location else ""
        raise ProductionSpecInputBridgeError(
            f"{label} schema validation failed{suffix}: {exc.message}"
        ) from exc


def _stable_unique(values: Sequence[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def _issue(code: str, field: str, message: str) -> dict[str, str]:
    return {"code": code, "field": field, "message": message}


def _json_clone(value: Any, label: str) -> Any:
    try:
        return json.loads(json.dumps(value))
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise ProductionSpecInputBridgeError(
            f"{label} must contain only JSON-serializable values"
        ) from exc


def _reserved_override_paths(value: Any, prefix: str) -> list[str]:
    matches: list[str] = []
    if isinstance(value, Mapping):
        for key, item in value.items():
            path = f"{prefix}.{key}"
            if key in _RESERVED_OVERRIDE_FIELDS:
                matches.append(path)
            matches.extend(_reserved_override_paths(item, path))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            matches.extend(
                _reserved_override_paths(item, f"{prefix}.{index}")
            )
    return matches


def _resolve_package_relative_file(
    package_root: Path,
    raw_path: str,
    label: str,
) -> Path:
    candidate = Path(raw_path)
    if candidate.is_absolute() or "\x00" in raw_path:
        raise ProductionSpecInputBridgeError(
            f"{label} must be a safe package-relative path"
        )
    try:
        root = package_root.resolve(strict=True)
        resolved = (root / candidate).resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise ProductionSpecInputBridgeError(
            f"missing or unreadable {label}: {candidate}"
        ) from exc
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise ProductionSpecInputBridgeError(
            f"{label} must remain inside the version package"
        ) from exc
    if not resolved.is_file():
        raise ProductionSpecInputBridgeError(f"{label} must be a file")
    return resolved


def _normalized_augmentations(request: Mapping[str, Any]) -> dict[str, Any]:
    supplied = request.get("augmentations")
    if not isinstance(supplied, Mapping):
        supplied = {}
    return {
        "additional_input_refs": list(supplied.get("additional_input_refs", [])),
        "implementation_evidence_refs": list(
            supplied.get("implementation_evidence_refs", [])
        ),
        "write_surface_bindings": _json_clone(
            supplied.get("write_surface_bindings", []),
            "write_surface_bindings",
        ),
        "qa_bindings": _json_clone(
            supplied.get("qa_bindings", []),
            "qa_bindings",
        ),
        "profile_options": _json_clone(
            supplied.get("profile_options", {}),
            "profile_options",
        ),
    }


def bridge_game_design_production_spec(
    *,
    production_spec_path: str | Path,
    request: Mapping[str, Any],
    production_spec_schema_path: str | Path,
    request_schema_path: str | Path,
    profile_input_binding_path: str | Path,
    profile_input_binding_schema_path: str | Path,
    target_profile_binding_schema_path: str | Path,
    result_schema_path: str | Path,
) -> dict[str, Any]:
    """Return a schema-valid bridge result without executing or writing state."""
    if not isinstance(request, Mapping):
        raise ProductionSpecInputBridgeError("bridge request must be a mapping")

    spec_path, production_spec, spec_sha256 = _load_json_object(
        production_spec_path,
        "Production Spec",
    )
    _, production_spec_schema, _ = _load_json_object(
        production_spec_schema_path,
        "Production Spec schema",
    )
    _, request_schema, _ = _load_json_object(
        request_schema_path,
        "Production Spec bridge request schema",
    )
    input_binding_path, profile_input_binding, input_binding_sha256 = (
        _load_json_object(
            profile_input_binding_path,
            "Production Spec profile input binding",
        )
    )
    _, profile_input_binding_schema, _ = _load_json_object(
        profile_input_binding_schema_path,
        "Production Spec profile input binding schema",
    )
    _, target_profile_binding_schema, _ = _load_json_object(
        target_profile_binding_schema_path,
        "Production Cell profile binding schema",
    )
    _, result_schema, _ = _load_json_object(
        result_schema_path,
        "Production Spec bridge result schema",
    )

    _validate_json(
        production_spec,
        production_spec_schema,
        "Production Spec",
    )
    _validate_json(request, request_schema, "Production Spec bridge request")
    _validate_json(
        profile_input_binding,
        profile_input_binding_schema,
        "Production Spec profile input binding",
    )
    version_root = input_binding_path.parents[3]
    target_binding_ref = _resolve_package_relative_file(
        version_root,
        profile_input_binding["target_profile_binding_path"],
        "target Production Cell profile binding",
    )
    target_binding_path, target_profile_binding, target_binding_sha256 = (
        _load_json_object(
            target_binding_ref,
            "target Production Cell profile binding",
        )
    )
    _validate_json(
        target_profile_binding,
        target_profile_binding_schema,
        "target Production Cell profile binding",
    )

    selection = request["selection"]
    augmentations = _normalized_augmentations(request)
    target_profile_id = selection["target_profile_id"]
    selected_writes = list(selection["declared_write_surfaces"])
    issues: list[dict[str, str]] = []

    if target_profile_id != profile_input_binding["target_profile_id"]:
        issues.append(
            _issue(
                "selected_profile_binding_mismatch",
                "selection.target_profile_id",
                "selected target_profile_id does not match the supplied profile-input binding",
            )
        )
    if (
        profile_input_binding["target_profile_id"]
        != target_profile_binding["profile_id"]
        or profile_input_binding["target_profile_binding_id"]
        != target_profile_binding["binding_id"]
    ):
        issues.append(
            _issue(
                "profile_input_binding_target_mismatch",
                "profile_input_binding.target_profile_binding_id",
                "profile-input binding does not match its target composition profile binding",
            )
        )

    accepted_routes = list(
        profile_input_binding["accepted_handoff_routes"]
    )
    spec_routes = list(production_spec["handoff_routes"])
    matched_routes = [route for route in spec_routes if route in accepted_routes]
    if not matched_routes:
        issues.append(
            _issue(
                "production_spec_profile_handoff_incompatible",
                "production_spec.handoff_routes",
                "Production Spec has no handoff route accepted by the selected profile",
            )
        )

    acceptance_criteria = list(production_spec["acceptance_criteria"])
    if len(set(acceptance_criteria)) != len(acceptance_criteria):
        issues.append(
            _issue(
                "production_spec_acceptance_criteria_not_unique",
                "production_spec.acceptance_criteria",
                "Production Cell feature criteria must be unique",
            )
        )

    runtime_surfaces = {
        item["surface"] for item in production_spec["runtime_contracts"]
    }
    data_contract_names = {
        item["name"] for item in production_spec["data_contracts"]
    }
    selected_write_set = set(selected_writes)
    for index, binding in enumerate(augmentations["write_surface_bindings"]):
        source_kind = binding["source_kind"]
        source_ref = binding["source_ref"]
        known_sources = (
            runtime_surfaces
            if source_kind == "runtime_contract"
            else data_contract_names
        )
        if source_ref not in known_sources:
            issues.append(
                _issue(
                    "write_surface_binding_source_unknown",
                    f"augmentations.write_surface_bindings.{index}.source_ref",
                    "write-surface binding does not name a source Production Spec contract",
                )
            )
        undeclared = [
            surface
            for surface in binding["concrete_surfaces"]
            if surface not in selected_write_set
        ]
        if undeclared:
            issues.append(
                _issue(
                    "augmentation_expands_declared_write_surface",
                    f"augmentations.write_surface_bindings.{index}.concrete_surfaces",
                    "augmentation concrete surfaces must stay inside the selected write envelope",
                )
            )

    qa_scenario_ids = {
        item["scenario_id"] for item in production_spec["qa_scenarios"]
    }
    for index, binding in enumerate(augmentations["qa_bindings"]):
        if binding["scenario_id"] not in qa_scenario_ids:
            issues.append(
                _issue(
                    "qa_binding_scenario_unknown",
                    f"augmentations.qa_bindings.{index}.scenario_id",
                    "QA binding does not name a Production Spec QA scenario",
                )
            )

    unexpected_profiles = sorted(
        set(augmentations["profile_options"]) - {target_profile_id}
    )
    if unexpected_profiles:
        issues.append(
            _issue(
                "augmentation_targets_unselected_profile",
                "augmentations.profile_options",
                "profile options may target only the explicitly selected profile",
            )
        )
    for profile_id, options in augmentations["profile_options"].items():
        reserved_paths = _reserved_override_paths(
            options,
            f"augmentations.profile_options.{profile_id}",
        )
        if reserved_paths:
            issues.append(
                _issue(
                    "augmentation_attempts_reserved_override",
                    reserved_paths[0],
                    "profile options cannot override Production Spec or required selection fields",
                )
            )

    task_id = production_spec["task_id"]
    source_identity_ref = (
        f"game_design_production_spec:{task_id}@sha256:{spec_sha256}"
    )
    source_trace_refs = [
        item["source_artifact"] for item in production_spec["source_trace"]
    ]
    production_document_ref = (
        "production_document:"
        f"{production_spec['production_document']['path']}"
    )
    input_refs = _stable_unique(
        [
            source_identity_ref,
            *source_trace_refs,
            production_document_ref,
            *augmentations["additional_input_refs"],
        ]
    )

    mapping_trace = [
        {
            "target_field": "task_id",
            "source": "production_spec.task_id",
            "mode": "default",
        },
        {
            "target_field": "title",
            "source": "production_spec.production_document.title",
            "mode": "default",
        },
        {
            "target_field": "acceptance_criteria",
            "source": "production_spec.acceptance_criteria",
            "mode": "default",
        },
        {
            "target_field": "input_refs",
            "source": "production_spec identity, source_trace, production_document, and optional additional_input_refs",
            "mode": "default_plus_augmentation",
        },
        {
            "target_field": "feature_id",
            "source": "request.selection.feature_id",
            "mode": "required_binding",
        },
        {
            "target_field": "declared_write_surfaces",
            "source": "request.selection.declared_write_surfaces",
            "mode": "required_binding",
        },
        {
            "target_field": "target_profile_id",
            "source": "request.selection.target_profile_id",
            "mode": "required_binding",
        },
        {
            "target_field": "expected_source_revision",
            "source": "request.selection.expected_source_revision",
            "mode": "required_binding",
        },
    ]

    selected_feature_spec: dict[str, Any] | None = None
    if not issues:
        selected_feature_spec = SelectedFeatureSpec(
            feature_id=selection["feature_id"],
            task_id=task_id,
            title=production_spec["production_document"]["title"],
            acceptance_criteria=tuple(acceptance_criteria),
            input_refs=tuple(input_refs),
            declared_write_surfaces=tuple(selected_writes),
            target_profile_id=target_profile_id,
            expected_source_revision=selection["expected_source_revision"],
        ).to_dict()

    result = {
        "schema_version": "1.0.0",
        "artifact_type": "production_spec_input_bridge_result",
        "status": "ready" if selected_feature_spec is not None else "review_needed",
        "source_spec": {
            "path": str(spec_path),
            "sha256": spec_sha256,
            "artifact_type": "game_design_production_spec",
            "task_id": task_id,
            "schema_validation_status": "passed",
        },
        "profile_input_binding": {
            "path": str(input_binding_path),
            "sha256": input_binding_sha256,
            "binding_id": profile_input_binding["binding_id"],
            "target_profile_id": profile_input_binding["target_profile_id"],
            "target_profile_binding_id": profile_input_binding[
                "target_profile_binding_id"
            ],
            "target_profile_binding_path": str(target_binding_path),
            "target_profile_binding_sha256": target_binding_sha256,
            "accepted_handoff_routes": accepted_routes,
            "matched_handoff_routes": matched_routes,
        },
        "selection": {
            "feature_id": selection["feature_id"],
            "target_profile_id": target_profile_id,
            "expected_source_revision": selection["expected_source_revision"],
            "declared_write_surfaces": selected_writes,
        },
        "selected_feature_spec": selected_feature_spec,
        "augmentations": augmentations,
        "mapping_trace": mapping_trace,
        "issues": issues,
        "profile_option_validation_status": (
            "deferred_to_selected_profile"
            if augmentations["profile_options"]
            else "not_supplied"
        ),
        "state_changes_applied": False,
        "execution_started": False,
        "authority_status": "not_asserted",
        "non_claims": [
            "bridge_result_is_not_design_or_human_acceptance",
            "schema_validation_is_not_approval_or_gate_authority",
            "bridge_ready_means_mapping_ready_not_execution_admission",
            "bridge_does_not_expand_worker_write_authority",
            "profile_options_remain_owned_by_the_selected_profile",
            "bridge_does_not_execute_worker_engine_build_or_qa",
            "bridge_result_is_not_qualification_release_or_live_authority",
        ],
    }
    _validate_json(result, result_schema, "Production Spec bridge result")
    return result
