"""Engine-neutral deterministic coordinator for bounded multi-lane work.

The coordinator consumes an explicit lane plan.  It validates principals,
capabilities, dependencies, source identity, and project-relative read/write
envelopes before calling any backend.  Backends own execution details and
return factual outcomes; the coordinator owns only scheduling state and
receipt construction.

Operational ``accepted`` is a lane-result state, not Human acceptance, a Gate,
qualification, release authority, or permission to contact a live system.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Protocol, Sequence, runtime_checkable


LANE_KINDS = {"maker", "integration", "build", "checker"}
LANE_STATES = {
    "planned",
    "ready",
    "running",
    "review_needed",
    "needs_resolution",
    "blocked",
    "failed",
    "cancelled",
    "succeeded",
    "accepted",
    "stale",
}
TERMINAL_BACKEND_STATES = {
    "review_needed",
    "needs_resolution",
    "blocked",
    "failed",
    "cancelled",
    "succeeded",
    "accepted",
}
AGGREGATE_STATES = {
    "planned",
    "running",
    "review_needed",
    "blocked",
    "failed",
    "completed",
    "cancelled",
}

WRITE_SET_DISPOSITIONS = {"serialize", "eligible_concurrent"}


class MultiLaneContractError(RuntimeError):
    """Raised when a plan, backend, or backend result violates the contract."""


class MultiLaneReceiptError(RuntimeError):
    """Raised when an aggregate receipt cannot be safely validated or written."""


class MultiLaneWriteEscapeError(MultiLaneContractError):
    """Raised when a backend reports an actual write outside its lane envelope."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _required_text(value: str, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise MultiLaneContractError(f"{label} must be a non-empty string")
    if "\x00" in value:
        raise MultiLaneContractError(f"{label} contains a NUL byte")
    return value.strip()


def _optional_text(value: str | None, label: str) -> str | None:
    if value is None:
        return None
    return _required_text(value, label)


def _text_tuple(
    values: Sequence[str],
    label: str,
    *,
    allow_empty: bool = False,
) -> tuple[str, ...]:
    if isinstance(values, (str, bytes)):
        raise MultiLaneContractError(f"{label} must be a sequence of strings")
    normalized = tuple(_required_text(value, f"{label} item") for value in values)
    if not allow_empty and not normalized:
        raise MultiLaneContractError(f"{label} must not be empty")
    if len(set(normalized)) != len(normalized):
        raise MultiLaneContractError(f"{label} must not contain duplicates")
    return normalized


def _json_object(value: Mapping[str, Any], label: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise MultiLaneContractError(f"{label} must be a mapping")
    try:
        encoded = json.dumps(value, ensure_ascii=False, sort_keys=True)
        decoded = json.loads(encoded)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise MultiLaneContractError(
            f"{label} must contain only JSON-serializable values"
        ) from exc
    if not isinstance(decoded, dict):
        raise MultiLaneContractError(f"{label} must serialize to an object")
    return decoded


def _project_pattern(value: str, label: str) -> str:
    pattern = _required_text(value, label)
    if "\\" in pattern or pattern.startswith("/"):
        raise MultiLaneContractError(f"{label} must be project-relative POSIX syntax")
    parts = PurePosixPath(pattern).parts
    if not parts or any(part in {"", ".", ".."} for part in parts):
        raise MultiLaneContractError(f"{label} is not a safe project-relative pattern")
    return pattern


def _project_path(value: str, label: str) -> str:
    relative = _project_pattern(value, label)
    if any(token in relative for token in ("*", "?", "[", "]")):
        raise MultiLaneContractError(f"{label} must be an exact project-relative path")
    return relative


def _glob_regex(pattern: str) -> re.Pattern[str]:
    pieces: list[str] = ["^"]
    index = 0
    while index < len(pattern):
        character = pattern[index]
        if character == "*":
            if index + 1 < len(pattern) and pattern[index + 1] == "*":
                pieces.append(".*")
                index += 2
            else:
                pieces.append("[^/]*")
                index += 1
        elif character == "?":
            pieces.append("[^/]")
            index += 1
        else:
            pieces.append(re.escape(character))
            index += 1
    pieces.append("$")
    return re.compile("".join(pieces))


def _matches_any(relative_path: str, patterns: Sequence[str]) -> bool:
    return any(_glob_regex(pattern).fullmatch(relative_path) for pattern in patterns)


def _has_glob_token(pattern: str) -> bool:
    return any(token in pattern for token in ("*", "?", "[", "]"))


def _recursive_prefix(pattern: str) -> str | None:
    if pattern.endswith("/**") and not _has_glob_token(pattern[:-3]):
        return pattern[:-2]
    return None


def _declared_patterns_overlap(first: str, second: str) -> bool:
    """Return true for overlaps that the bounded preflight can prove safely.

    Exact paths, identical patterns, and simple recursive-prefix envelopes are
    proven before execution.  Intersections between two more complex glob
    expressions are deliberately left to exact observed-write comparison; an
    observed intersection then becomes ``needs_resolution`` rather than being
    guessed or silently merged.
    """

    if first == second:
        return True
    first_has_glob = _has_glob_token(first)
    second_has_glob = _has_glob_token(second)
    if not first_has_glob and _glob_regex(second).fullmatch(first):
        return True
    if not second_has_glob and _glob_regex(first).fullmatch(second):
        return True
    first_prefix = _recursive_prefix(first)
    second_prefix = _recursive_prefix(second)
    if first_prefix is not None and second.startswith(first_prefix):
        return True
    if second_prefix is not None and first.startswith(second_prefix):
        return True
    return False


def _canonical_sha256(value: Mapping[str, Any]) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


@dataclass(frozen=True)
class PrincipalBinding:
    principal_id: str
    capabilities: tuple[str, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "principal_id",
            _required_text(self.principal_id, "principal_id"),
        )
        object.__setattr__(
            self,
            "capabilities",
            _text_tuple(self.capabilities, "principal capabilities"),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "principal_id": self.principal_id,
            "capabilities": list(self.capabilities),
        }


@dataclass(frozen=True)
class LaneDefinition:
    lane_id: str
    lane_kind: str
    primary_principal_id: str
    selected_agent_id: str | None
    selected_skill_id: str | None
    depends_on: tuple[str, ...]
    required_capabilities: tuple[str, ...]
    input_refs: tuple[str, ...]
    read_patterns: tuple[str, ...]
    write_patterns: tuple[str, ...]
    required_validators: tuple[str, ...]
    expected_output_artifact_types: tuple[str, ...]
    max_attempts: int
    timeout_seconds: int
    concurrency_group: str
    serialized: bool
    human_checkpoint_required: bool
    required: bool = True

    def __post_init__(self) -> None:
        object.__setattr__(self, "lane_id", _required_text(self.lane_id, "lane_id"))
        if self.lane_kind not in LANE_KINDS:
            raise MultiLaneContractError(
                f"lane {self.lane_id} has unsupported lane_kind {self.lane_kind!r}"
            )
        object.__setattr__(
            self,
            "primary_principal_id",
            _required_text(self.primary_principal_id, "primary_principal_id"),
        )
        object.__setattr__(
            self,
            "selected_agent_id",
            _optional_text(self.selected_agent_id, "selected_agent_id"),
        )
        object.__setattr__(
            self,
            "selected_skill_id",
            _optional_text(self.selected_skill_id, "selected_skill_id"),
        )
        if (self.selected_agent_id is None) != (self.selected_skill_id is None):
            raise MultiLaneContractError(
                "selected_agent_id and selected_skill_id must be supplied together"
            )
        object.__setattr__(
            self,
            "depends_on",
            _text_tuple(self.depends_on, "depends_on", allow_empty=True),
        )
        object.__setattr__(
            self,
            "required_capabilities",
            _text_tuple(self.required_capabilities, "required_capabilities"),
        )
        object.__setattr__(self, "input_refs", _text_tuple(self.input_refs, "input_refs"))
        object.__setattr__(
            self,
            "read_patterns",
            tuple(
                _project_pattern(value, "read_patterns item")
                for value in _text_tuple(self.read_patterns, "read_patterns")
            ),
        )
        object.__setattr__(
            self,
            "write_patterns",
            tuple(
                _project_pattern(value, "write_patterns item")
                for value in _text_tuple(
                    self.write_patterns,
                    "write_patterns",
                    allow_empty=True,
                )
            ),
        )
        object.__setattr__(
            self,
            "required_validators",
            _text_tuple(self.required_validators, "required_validators"),
        )
        object.__setattr__(
            self,
            "expected_output_artifact_types",
            _text_tuple(
                self.expected_output_artifact_types,
                "expected_output_artifact_types",
            ),
        )
        if not isinstance(self.max_attempts, int) or not 1 <= self.max_attempts <= 10:
            raise MultiLaneContractError("max_attempts must be an integer from 1 to 10")
        if (
            not isinstance(self.timeout_seconds, int)
            or not 1 <= self.timeout_seconds <= 86400
        ):
            raise MultiLaneContractError(
                "timeout_seconds must be an integer from 1 to 86400"
            )
        object.__setattr__(
            self,
            "concurrency_group",
            _required_text(self.concurrency_group, "concurrency_group"),
        )
        if self.lane_kind == "checker" and self.write_patterns:
            raise MultiLaneContractError(
                f"checker lane {self.lane_id} must not declare project writes"
            )

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        for key in (
            "depends_on",
            "required_capabilities",
            "input_refs",
            "read_patterns",
            "write_patterns",
            "required_validators",
            "expected_output_artifact_types",
        ):
            value[key] = list(value[key])
        return value


@dataclass(frozen=True)
class LanePlan:
    plan_id: str
    project_id: str
    feature_id: str
    task_id: str
    expected_source_revision: str
    profile_id: str
    profile_required_capabilities: tuple[str, ...]
    principals: tuple[PrincipalBinding, ...]
    lanes: tuple[LaneDefinition, ...]
    max_write_concurrency: int
    non_claims: tuple[str, ...]
    schema_version: str = "1.0.0"
    artifact_type: str = "multi_lane_plan"

    def __post_init__(self) -> None:
        if self.schema_version != "1.0.0":
            raise MultiLaneContractError("unsupported lane plan schema_version")
        if self.artifact_type != "multi_lane_plan":
            raise MultiLaneContractError("unsupported lane plan artifact_type")
        for field in (
            "plan_id",
            "project_id",
            "feature_id",
            "task_id",
            "expected_source_revision",
            "profile_id",
        ):
            object.__setattr__(self, field, _required_text(getattr(self, field), field))
        object.__setattr__(
            self,
            "profile_required_capabilities",
            _text_tuple(
                self.profile_required_capabilities,
                "profile_required_capabilities",
            ),
        )
        if not self.principals:
            raise MultiLaneContractError("principals must not be empty")
        if not all(isinstance(value, PrincipalBinding) for value in self.principals):
            raise MultiLaneContractError("principals must contain PrincipalBinding values")
        principal_ids = [value.principal_id for value in self.principals]
        if len(set(principal_ids)) != len(principal_ids):
            raise MultiLaneContractError("principal IDs must be unique")
        if not self.lanes:
            raise MultiLaneContractError("lanes must not be empty")
        if not all(isinstance(value, LaneDefinition) for value in self.lanes):
            raise MultiLaneContractError("lanes must contain LaneDefinition values")
        lane_ids = [value.lane_id for value in self.lanes]
        if len(set(lane_ids)) != len(lane_ids):
            raise MultiLaneContractError("lane IDs must be unique")
        lane_id_set = set(lane_ids)
        principals = {value.principal_id: value for value in self.principals}
        for lane in self.lanes:
            missing_dependencies = set(lane.depends_on) - lane_id_set
            if missing_dependencies:
                raise MultiLaneContractError(
                    f"lane {lane.lane_id} has missing dependencies: "
                    f"{sorted(missing_dependencies)}"
                )
            if lane.lane_id in lane.depends_on:
                raise MultiLaneContractError(
                    f"lane {lane.lane_id} cannot depend on itself"
                )
            principal = principals.get(lane.primary_principal_id)
            if principal is None:
                raise MultiLaneContractError(
                    f"lane {lane.lane_id} has unknown principal "
                    f"{lane.primary_principal_id!r}"
                )
            missing_capabilities = set(lane.required_capabilities) - set(
                principal.capabilities
            )
            if missing_capabilities:
                raise MultiLaneContractError(
                    f"lane {lane.lane_id} principal lacks capabilities: "
                    f"{sorted(missing_capabilities)}"
                )
        if (
            not isinstance(self.max_write_concurrency, int)
            or not 1 <= self.max_write_concurrency <= 2
        ):
            raise MultiLaneContractError(
                "max_write_concurrency must be an integer from 1 to 2"
            )
        object.__setattr__(
            self,
            "non_claims",
            _text_tuple(self.non_claims, "non_claims"),
        )
        self.topological_lane_ids()

    def topological_lane_ids(self) -> tuple[str, ...]:
        dependencies = {lane.lane_id: set(lane.depends_on) for lane in self.lanes}
        dependents = {lane.lane_id: set() for lane in self.lanes}
        for lane_id, lane_dependencies in dependencies.items():
            for dependency_id in lane_dependencies:
                dependents[dependency_id].add(lane_id)
        ready = sorted(lane_id for lane_id, values in dependencies.items() if not values)
        ordered: list[str] = []
        while ready:
            lane_id = ready.pop(0)
            ordered.append(lane_id)
            for dependent_id in sorted(dependents[lane_id]):
                dependencies[dependent_id].remove(lane_id)
                if not dependencies[dependent_id] and dependent_id not in ready:
                    ready.append(dependent_id)
                    ready.sort()
        if len(ordered) != len(self.lanes):
            cyclic = sorted(lane_id for lane_id, values in dependencies.items() if values)
            raise MultiLaneContractError(f"lane dependency graph contains a cycle: {cyclic}")
        return tuple(ordered)

    def depends_on_transitively(self, lane_id: str, dependency_id: str) -> bool:
        lane_ids = {lane.lane_id for lane in self.lanes}
        if lane_id not in lane_ids or dependency_id not in lane_ids:
            raise MultiLaneContractError(
                "dependency query must reference known lane IDs"
            )
        lane_by_id = {lane.lane_id: lane for lane in self.lanes}
        pending = list(lane_by_id[lane_id].depends_on)
        visited: set[str] = set()
        while pending:
            candidate = pending.pop()
            if candidate == dependency_id:
                return True
            if candidate in visited:
                continue
            visited.add(candidate)
            pending.extend(lane_by_id[candidate].depends_on)
        return False

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "artifact_type": self.artifact_type,
            "plan_id": self.plan_id,
            "project_id": self.project_id,
            "feature_id": self.feature_id,
            "task_id": self.task_id,
            "expected_source_revision": self.expected_source_revision,
            "profile_id": self.profile_id,
            "profile_required_capabilities": list(self.profile_required_capabilities),
            "principals": [principal.to_dict() for principal in self.principals],
            "lanes": [lane.to_dict() for lane in self.lanes],
            "max_write_concurrency": self.max_write_concurrency,
            "non_claims": list(self.non_claims),
        }

    def derive_lane_states(
        self,
        observed_states: Mapping[str, str] | None = None,
    ) -> dict[str, str]:
        """Derive current ready/planned/blocked states without executing lanes."""

        observed = {} if observed_states is None else dict(observed_states)
        known_lane_ids = {lane.lane_id for lane in self.lanes}
        unknown = set(observed) - known_lane_ids
        if unknown:
            raise MultiLaneContractError(
                f"observed states reference unknown lanes: {sorted(unknown)}"
            )
        for lane_id, state in observed.items():
            if state not in LANE_STATES:
                raise MultiLaneContractError(
                    f"lane {lane_id} has unsupported observed state {state!r}"
                )
        lane_by_id = {lane.lane_id: lane for lane in self.lanes}
        derived: dict[str, str] = {}
        for lane_id in self.topological_lane_ids():
            if lane_id in observed:
                derived[lane_id] = observed[lane_id]
                continue
            lane = lane_by_id[lane_id]
            dependency_states = [derived[value] for value in lane.depends_on]
            if not dependency_states or all(
                state == "accepted" for state in dependency_states
            ):
                derived[lane_id] = "ready"
            elif any(
                state
                in {
                    "review_needed",
                    "needs_resolution",
                    "blocked",
                    "failed",
                    "cancelled",
                    "succeeded",
                    "stale",
                }
                for state in dependency_states
            ):
                derived[lane_id] = "blocked"
            else:
                derived[lane_id] = "planned"
        return derived

    @property
    def sha256(self) -> str:
        return _canonical_sha256(self.to_dict())


@dataclass(frozen=True)
class WriteSetDecision:
    lane_a: str
    lane_b: str
    disposition: str
    reasons: tuple[str, ...]
    declared_overlap_pairs: tuple[tuple[str, str], ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "lane_a", _required_text(self.lane_a, "lane_a"))
        object.__setattr__(self, "lane_b", _required_text(self.lane_b, "lane_b"))
        if self.lane_a == self.lane_b:
            raise MultiLaneContractError("write-set decision requires two lanes")
        if self.disposition not in WRITE_SET_DISPOSITIONS:
            raise MultiLaneContractError(
                f"unsupported write-set disposition {self.disposition!r}"
            )
        object.__setattr__(
            self,
            "reasons",
            _text_tuple(self.reasons, "write-set decision reasons"),
        )
        normalized_pairs: list[tuple[str, str]] = []
        for first, second in self.declared_overlap_pairs:
            normalized_pairs.append(
                (
                    _project_pattern(first, "declared overlap first pattern"),
                    _project_pattern(second, "declared overlap second pattern"),
                )
            )
        object.__setattr__(self, "declared_overlap_pairs", tuple(normalized_pairs))

    @property
    def pair_key(self) -> tuple[str, str]:
        return tuple(sorted((self.lane_a, self.lane_b)))

    def to_dict(self) -> dict[str, Any]:
        return {
            "lane_a": self.lane_a,
            "lane_b": self.lane_b,
            "disposition": self.disposition,
            "reasons": list(self.reasons),
            "declared_overlap_pairs": [
                {
                    "lane_a_pattern": first,
                    "lane_b_pattern": second,
                }
                for first, second in self.declared_overlap_pairs
            ],
        }


@dataclass(frozen=True)
class LaneBackendOutcome:
    state: str
    input_source_revision: str
    output_revision: str | None
    result_artifact_type: str | None
    facts: Mapping[str, Any]
    observed_write_paths: tuple[str, ...] = ()
    artifact_identities: Mapping[str, Any] = field(default_factory=dict)
    evidence_refs: tuple[str, ...] = ()
    failure_kind: str | None = None
    failure_owner: str | None = None
    next_action: str | None = None

    def __post_init__(self) -> None:
        if self.state not in TERMINAL_BACKEND_STATES:
            raise MultiLaneContractError(
                f"backend outcome has unsupported state {self.state!r}"
            )
        object.__setattr__(
            self,
            "input_source_revision",
            _required_text(self.input_source_revision, "input_source_revision"),
        )
        object.__setattr__(
            self,
            "output_revision",
            _optional_text(self.output_revision, "output_revision"),
        )
        object.__setattr__(
            self,
            "result_artifact_type",
            _optional_text(self.result_artifact_type, "result_artifact_type"),
        )
        object.__setattr__(self, "facts", _json_object(self.facts, "outcome facts"))
        object.__setattr__(
            self,
            "observed_write_paths",
            tuple(
                _project_path(value, "observed_write_paths item")
                for value in _text_tuple(
                    self.observed_write_paths,
                    "observed_write_paths",
                    allow_empty=True,
                )
            ),
        )
        identities = {} if self.artifact_identities is None else self.artifact_identities
        object.__setattr__(
            self,
            "artifact_identities",
            _json_object(identities, "artifact_identities"),
        )
        object.__setattr__(
            self,
            "evidence_refs",
            _text_tuple(self.evidence_refs, "evidence_refs", allow_empty=True),
        )
        for field in ("failure_kind", "failure_owner", "next_action"):
            object.__setattr__(
                self,
                field,
                _optional_text(getattr(self, field), field),
            )
        if self.state in {"succeeded", "accepted"}:
            if self.output_revision is None or self.result_artifact_type is None:
                raise MultiLaneContractError(
                    "successful outcomes require output_revision and result_artifact_type"
                )
        elif self.failure_owner is None:
            raise MultiLaneContractError(
                "non-successful outcomes require failure_owner"
            )


@dataclass(frozen=True)
class LaneExecutionContext:
    plan: LanePlan
    lane: LaneDefinition
    attempt_id: int
    dependency_results: tuple["LaneResult", ...]


@runtime_checkable
class LaneBackend(Protocol):
    lane_id: str
    backend_id: str
    capabilities: tuple[str, ...]

    def run(self, context: LaneExecutionContext) -> LaneBackendOutcome:
        """Run one bounded lane and return a factual operational outcome."""


@dataclass(frozen=True)
class LaneResult:
    schema_version: str
    artifact_type: str
    result_id: str
    lane_id: str
    lane_kind: str
    state: str
    attempt_id: int
    backend_id: str
    input_source_revision: str
    output_revision: str | None
    dependency_result_ids: tuple[str, ...]
    declared_write_patterns: tuple[str, ...]
    observed_write_paths: tuple[str, ...]
    result_artifact_type: str | None
    facts: dict[str, Any]
    artifact_identities: dict[str, Any]
    evidence_refs: tuple[str, ...]
    failure_kind: str | None
    failure_owner: str | None
    next_action: str | None
    started_at: str | None
    duration_ms: int | None
    non_claims: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        for key in (
            "dependency_result_ids",
            "declared_write_patterns",
            "observed_write_paths",
            "evidence_refs",
            "non_claims",
        ):
            value[key] = list(value[key])
        return value


@dataclass(frozen=True)
class MultiLaneAggregateResult:
    schema_version: str
    artifact_type: str
    run_id: str
    plan_id: str
    plan_sha256: str
    project_id: str
    feature_id: str
    task_id: str
    expected_source_revision: str
    profile_id: str
    status: str
    lane_order: tuple[str, ...]
    lane_results: tuple[LaneResult, ...]
    unresolved_required_lane_ids: tuple[str, ...]
    completed_at: str
    non_claims: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "artifact_type": self.artifact_type,
            "run_id": self.run_id,
            "plan_id": self.plan_id,
            "plan_sha256": self.plan_sha256,
            "project_id": self.project_id,
            "feature_id": self.feature_id,
            "task_id": self.task_id,
            "expected_source_revision": self.expected_source_revision,
            "profile_id": self.profile_id,
            "status": self.status,
            "lane_order": list(self.lane_order),
            "lane_results": [result.to_dict() for result in self.lane_results],
            "unresolved_required_lane_ids": list(self.unresolved_required_lane_ids),
            "completed_at": self.completed_at,
            "non_claims": list(self.non_claims),
        }


@dataclass(frozen=True)
class MultiLaneRecoveryReceipt:
    schema_version: str
    artifact_type: str
    recovery_id: str
    plan_id: str
    plan_sha256: str
    prior_run_id: str
    resumed_run_id: str
    status: str
    selected_retry_lane_ids: tuple[str, ...]
    reused_lane_result_ids: tuple[str, ...]
    new_attempt_result_ids: tuple[str, ...]
    stale_lane_result_ids: tuple[str, ...]
    needs_resolution_lane_ids: tuple[str, ...]
    write_set_decisions: tuple[WriteSetDecision, ...]
    facts: dict[str, Any]
    created_at: str
    non_claims: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "artifact_type": self.artifact_type,
            "recovery_id": self.recovery_id,
            "plan_id": self.plan_id,
            "plan_sha256": self.plan_sha256,
            "prior_run_id": self.prior_run_id,
            "resumed_run_id": self.resumed_run_id,
            "status": self.status,
            "selected_retry_lane_ids": list(self.selected_retry_lane_ids),
            "reused_lane_result_ids": list(self.reused_lane_result_ids),
            "new_attempt_result_ids": list(self.new_attempt_result_ids),
            "stale_lane_result_ids": list(self.stale_lane_result_ids),
            "needs_resolution_lane_ids": list(self.needs_resolution_lane_ids),
            "write_set_decisions": [
                decision.to_dict() for decision in self.write_set_decisions
            ],
            "facts": dict(self.facts),
            "created_at": self.created_at,
            "non_claims": list(self.non_claims),
        }


@dataclass(frozen=True)
class MultiLaneRecoveryOutcome:
    aggregate_result: MultiLaneAggregateResult
    recovery_receipt: MultiLaneRecoveryReceipt


class MultiLaneCoordinator:
    """Execute ready lanes in deterministic topological order."""

    def __init__(
        self,
        *,
        plan: LanePlan,
        backends: Sequence[LaneBackend],
        profile_capabilities: Sequence[str],
    ) -> None:
        if not isinstance(plan, LanePlan):
            raise MultiLaneContractError("plan must be a LanePlan")
        self.plan = plan
        self.profile_capabilities = _text_tuple(
            profile_capabilities,
            "profile_capabilities",
        )
        missing_profile_capabilities = set(plan.profile_required_capabilities) - set(
            self.profile_capabilities
        )
        if missing_profile_capabilities:
            raise MultiLaneContractError(
                "profile lacks required capabilities: "
                f"{sorted(missing_profile_capabilities)}"
            )
        backend_by_lane: dict[str, LaneBackend] = {}
        known_lane_ids = {lane.lane_id for lane in plan.lanes}
        for backend in backends:
            if not isinstance(backend, LaneBackend):
                raise MultiLaneContractError("backend does not implement LaneBackend")
            lane_id = _required_text(backend.lane_id, "backend lane_id")
            if lane_id not in known_lane_ids:
                raise MultiLaneContractError(f"backend targets unknown lane {lane_id!r}")
            if lane_id in backend_by_lane:
                raise MultiLaneContractError(f"duplicate backend for lane {lane_id!r}")
            _required_text(backend.backend_id, "backend_id")
            capabilities = _text_tuple(backend.capabilities, "backend capabilities")
            lane = next(value for value in plan.lanes if value.lane_id == lane_id)
            missing = set(lane.required_capabilities) - set(capabilities)
            if missing:
                raise MultiLaneContractError(
                    f"backend for lane {lane_id} lacks capabilities: {sorted(missing)}"
                )
            backend_by_lane[lane_id] = backend
        missing_backends = known_lane_ids - set(backend_by_lane)
        if missing_backends:
            raise MultiLaneContractError(
                f"missing backends for lanes: {sorted(missing_backends)}"
            )
        self.backends = backend_by_lane

    def preflight_write_sets(self) -> tuple[WriteSetDecision, ...]:
        """Derive conservative pairwise write scheduling before execution."""

        lane_by_id = {lane.lane_id: lane for lane in self.plan.lanes}
        write_lane_ids = [
            lane_id
            for lane_id in self.plan.topological_lane_ids()
            if lane_by_id[lane_id].write_patterns
        ]
        decisions: list[WriteSetDecision] = []
        for index, lane_a_id in enumerate(write_lane_ids):
            for lane_b_id in write_lane_ids[index + 1 :]:
                if self.plan.depends_on_transitively(lane_a_id, lane_b_id) or (
                    self.plan.depends_on_transitively(lane_b_id, lane_a_id)
                ):
                    continue
                lane_a = lane_by_id[lane_a_id]
                lane_b = lane_by_id[lane_b_id]
                overlaps = tuple(
                    (first, second)
                    for first in lane_a.write_patterns
                    for second in lane_b.write_patterns
                    if _declared_patterns_overlap(first, second)
                )
                reasons: list[str] = []
                if self.plan.max_write_concurrency == 1:
                    reasons.append("plan_write_concurrency_is_one")
                if lane_a.serialized or lane_b.serialized:
                    reasons.append("lane_requires_serialization")
                if overlaps:
                    reasons.append("declared_write_overlap")
                if reasons:
                    disposition = "serialize"
                else:
                    disposition = "eligible_concurrent"
                    reasons.append("declared_write_sets_are_disjoint")
                decisions.append(
                    WriteSetDecision(
                        lane_a=lane_a_id,
                        lane_b=lane_b_id,
                        disposition=disposition,
                        reasons=tuple(reasons),
                        declared_overlap_pairs=overlaps,
                    )
                )
        return tuple(decisions)

    def _validate_prior_result(
        self,
        prior_result: MultiLaneAggregateResult,
    ) -> dict[str, LaneResult]:
        if not isinstance(prior_result, MultiLaneAggregateResult):
            raise MultiLaneContractError(
                "prior_result must be a MultiLaneAggregateResult"
            )
        expected_identity = (
            self.plan.plan_id,
            self.plan.sha256,
            self.plan.project_id,
            self.plan.feature_id,
            self.plan.task_id,
            self.plan.expected_source_revision,
            self.plan.profile_id,
        )
        observed_identity = (
            prior_result.plan_id,
            prior_result.plan_sha256,
            prior_result.project_id,
            prior_result.feature_id,
            prior_result.task_id,
            prior_result.expected_source_revision,
            prior_result.profile_id,
        )
        if observed_identity != expected_identity:
            raise MultiLaneContractError(
                "prior result identity does not match the current lane plan"
            )
        prior_by_lane = {result.lane_id: result for result in prior_result.lane_results}
        expected_lane_ids = {lane.lane_id for lane in self.plan.lanes}
        if len(prior_by_lane) != len(prior_result.lane_results):
            raise MultiLaneContractError("prior result contains duplicate lane IDs")
        if set(prior_by_lane) != expected_lane_ids:
            raise MultiLaneContractError(
                "prior result lane set does not match the current lane plan"
            )
        lane_by_id = {lane.lane_id: lane for lane in self.plan.lanes}
        for lane_id, result in prior_by_lane.items():
            lane = lane_by_id[lane_id]
            if result.lane_kind != lane.lane_kind:
                raise MultiLaneContractError(
                    f"prior result lane kind mismatch for {lane_id}"
                )
            if result.input_source_revision != self.plan.expected_source_revision:
                raise MultiLaneContractError(
                    f"prior result source revision mismatch for {lane_id}"
                )
            if not 0 <= result.attempt_id <= lane.max_attempts:
                raise MultiLaneContractError(
                    f"prior result attempt is outside the declared bound for {lane_id}"
                )
        return prior_by_lane

    @staticmethod
    def _stale_result(
        *,
        lane: LaneDefinition,
        prior_result: LaneResult,
        dependency_results: Sequence[LaneResult],
    ) -> LaneResult:
        current_dependency_ids = tuple(
            result.result_id for result in dependency_results
        )
        facts = dict(prior_result.facts)
        facts["stale_derivation"] = {
            "prior_result_id": prior_result.result_id,
            "prior_dependency_result_ids": list(prior_result.dependency_result_ids),
            "current_dependency_result_ids": list(current_dependency_ids),
            "reason": "dependency_result_identity_changed",
        }
        return LaneResult(
            schema_version="1.0.0",
            artifact_type="multi_lane_result",
            result_id=f"lane-result-{uuid.uuid4().hex}",
            lane_id=lane.lane_id,
            lane_kind=lane.lane_kind,
            state="stale",
            attempt_id=prior_result.attempt_id,
            backend_id=prior_result.backend_id,
            input_source_revision=prior_result.input_source_revision,
            output_revision=prior_result.output_revision,
            dependency_result_ids=prior_result.dependency_result_ids,
            declared_write_patterns=prior_result.declared_write_patterns,
            observed_write_paths=prior_result.observed_write_paths,
            result_artifact_type=prior_result.result_artifact_type,
            facts=facts,
            artifact_identities=dict(prior_result.artifact_identities),
            evidence_refs=prior_result.evidence_refs,
            failure_kind="dependency_result_identity_changed",
            failure_owner="multi_lane_coordinator",
            next_action="select this lane for a bounded new attempt",
            started_at=None,
            duration_ms=None,
            non_claims=(
                "stale_result_preserves_historical_evidence_but_is_not_current",
                "lane_result_is_not_human_acceptance_or_protected_authority",
            ),
        )

    @staticmethod
    def _needs_resolution_result(
        result: LaneResult,
        *,
        other_lane_id: str,
        overlapping_paths: Sequence[str],
    ) -> LaneResult:
        facts = dict(result.facts)
        observations = list(facts.get("unexpected_observed_write_overlaps", []))
        observations.append(
            {
                "other_lane_id": other_lane_id,
                "paths": list(overlapping_paths),
            }
        )
        facts["unexpected_observed_write_overlaps"] = observations
        return LaneResult(
            **{
                **asdict(result),
                "state": "needs_resolution",
                "facts": facts,
                "failure_kind": "unexpected_observed_write_overlap",
                "failure_owner": "multi_lane_coordinator",
                "next_action": "resolve or re-plan the affected lane write sets",
            }
        )

    @classmethod
    def _apply_unexpected_observed_overlap(
        cls,
        *,
        current_lane_id: str,
        results: dict[str, LaneResult],
        decisions: Mapping[tuple[str, str], WriteSetDecision],
    ) -> None:
        current = results[current_lane_id]
        if current.state not in {"accepted", "succeeded"}:
            return
        for other_lane_id, other in tuple(results.items()):
            if other_lane_id == current_lane_id:
                continue
            if other.state not in {"accepted", "succeeded"}:
                continue
            decision = decisions.get(tuple(sorted((current_lane_id, other_lane_id))))
            if decision is None or decision.disposition != "eligible_concurrent":
                continue
            overlapping_paths = tuple(
                sorted(set(current.observed_write_paths) & set(other.observed_write_paths))
            )
            if not overlapping_paths:
                continue
            results[current_lane_id] = cls._needs_resolution_result(
                results[current_lane_id],
                other_lane_id=other_lane_id,
                overlapping_paths=overlapping_paths,
            )
            results[other_lane_id] = cls._needs_resolution_result(
                results[other_lane_id],
                other_lane_id=current_lane_id,
                overlapping_paths=overlapping_paths,
            )
            current = results[current_lane_id]

    @staticmethod
    def _blocked_result(
        *,
        lane: LaneDefinition,
        backend: LaneBackend,
        dependency_results: Sequence[LaneResult],
        expected_source_revision: str,
    ) -> LaneResult:
        blocking = sorted(
            result.lane_id
            for result in dependency_results
            if result.state != "accepted"
        )
        return LaneResult(
            schema_version="1.0.0",
            artifact_type="multi_lane_result",
            result_id=f"lane-result-{uuid.uuid4().hex}",
            lane_id=lane.lane_id,
            lane_kind=lane.lane_kind,
            state="blocked",
            attempt_id=0,
            backend_id=backend.backend_id,
            input_source_revision=expected_source_revision,
            output_revision=None,
            dependency_result_ids=tuple(result.result_id for result in dependency_results),
            declared_write_patterns=lane.write_patterns,
            observed_write_paths=(),
            result_artifact_type=None,
            facts={"blocked_by_dependency_lanes": blocking},
            artifact_identities={},
            evidence_refs=(),
            failure_kind="dependency_not_accepted",
            failure_owner=None,
            next_action=None,
            started_at=None,
            duration_ms=None,
            non_claims=(
                "blocked_lane_is_not_a_pass_or_waiver",
                "lane_result_is_not_human_acceptance_or_protected_authority",
            ),
        )

    @staticmethod
    def _derive_aggregate_status(
        plan: LanePlan,
        results_by_lane: Mapping[str, LaneResult],
    ) -> tuple[str, tuple[str, ...]]:
        required_lanes = [lane for lane in plan.lanes if lane.required]
        unresolved = tuple(
            sorted(
                lane.lane_id
                for lane in required_lanes
                if results_by_lane[lane.lane_id].state != "accepted"
            )
        )
        if not unresolved:
            return "completed", ()
        states = {results_by_lane[lane_id].state for lane_id in unresolved}
        if "failed" in states:
            return "failed", unresolved
        if "cancelled" in states:
            return "cancelled", unresolved
        if "blocked" in states:
            return "blocked", unresolved
        return "review_needed", unresolved

    def _run_internal(
        self,
        *,
        attempt_ids: Mapping[str, int] | None = None,
        prior_results_by_lane: Mapping[str, LaneResult] | None = None,
        selected_lane_ids: Sequence[str] = (),
    ) -> MultiLaneAggregateResult:
        attempts = {} if attempt_ids is None else dict(attempt_ids)
        unknown_attempt_lanes = set(attempts) - {
            lane.lane_id for lane in self.plan.lanes
        }
        if unknown_attempt_lanes:
            raise MultiLaneContractError(
                f"attempt IDs reference unknown lanes: {sorted(unknown_attempt_lanes)}"
            )
        prior = {} if prior_results_by_lane is None else dict(prior_results_by_lane)
        selected = set(selected_lane_ids)
        lane_by_id = {lane.lane_id: lane for lane in self.plan.lanes}
        results: dict[str, LaneResult] = {}
        order = self.plan.topological_lane_ids()
        decisions = self.preflight_write_sets()
        decisions_by_pair = {decision.pair_key: decision for decision in decisions}
        for lane_id in order:
            lane = lane_by_id[lane_id]
            backend = self.backends[lane_id]
            dependency_results = tuple(results[value] for value in lane.depends_on)
            prior_result = prior.get(lane_id)
            if prior_result is not None and lane_id not in selected:
                current_dependency_ids = tuple(
                    result.result_id for result in dependency_results
                )
                if (
                    prior_result.state == "accepted"
                    and current_dependency_ids != prior_result.dependency_result_ids
                ):
                    results[lane_id] = self._stale_result(
                        lane=lane,
                        prior_result=prior_result,
                        dependency_results=dependency_results,
                    )
                else:
                    results[lane_id] = prior_result
                self._apply_unexpected_observed_overlap(
                    current_lane_id=lane_id,
                    results=results,
                    decisions=decisions_by_pair,
                )
                continue
            if any(result.state != "accepted" for result in dependency_results):
                results[lane_id] = self._blocked_result(
                    lane=lane,
                    backend=backend,
                    dependency_results=dependency_results,
                    expected_source_revision=self.plan.expected_source_revision,
                )
                continue
            default_attempt_id = (
                max(1, prior_result.attempt_id + 1)
                if prior_result is not None
                else 1
            )
            attempt_id = attempts.get(lane_id, default_attempt_id)
            if not isinstance(attempt_id, int) or not 1 <= attempt_id <= lane.max_attempts:
                raise MultiLaneContractError(
                    f"lane {lane_id} attempt_id must be within its declared bound"
                )
            started_at = _utc_now()
            started_clock = time.monotonic()
            outcome = backend.run(
                LaneExecutionContext(
                    plan=self.plan,
                    lane=lane,
                    attempt_id=attempt_id,
                    dependency_results=dependency_results,
                )
            )
            duration_ms = max(0, round((time.monotonic() - started_clock) * 1000))
            if not isinstance(outcome, LaneBackendOutcome):
                raise MultiLaneContractError(
                    f"backend {backend.backend_id} returned an invalid outcome"
                )
            if outcome.input_source_revision != self.plan.expected_source_revision:
                raise MultiLaneContractError(
                    f"lane {lane_id} input source revision does not match the plan"
                )
            if (
                outcome.result_artifact_type is not None
                and outcome.result_artifact_type
                not in lane.expected_output_artifact_types
            ):
                raise MultiLaneContractError(
                    f"lane {lane_id} returned undeclared artifact type "
                    f"{outcome.result_artifact_type!r}"
                )
            escaped = tuple(
                path
                for path in outcome.observed_write_paths
                if not _matches_any(path, lane.write_patterns)
            )
            if escaped:
                raise MultiLaneWriteEscapeError(
                    f"lane {lane_id} observed out-of-envelope writes: {list(escaped)}"
                )
            results[lane_id] = LaneResult(
                schema_version="1.0.0",
                artifact_type="multi_lane_result",
                result_id=f"lane-result-{uuid.uuid4().hex}",
                lane_id=lane.lane_id,
                lane_kind=lane.lane_kind,
                state=outcome.state,
                attempt_id=attempt_id,
                backend_id=backend.backend_id,
                input_source_revision=outcome.input_source_revision,
                output_revision=outcome.output_revision,
                dependency_result_ids=tuple(
                    result.result_id for result in dependency_results
                ),
                declared_write_patterns=lane.write_patterns,
                observed_write_paths=outcome.observed_write_paths,
                result_artifact_type=outcome.result_artifact_type,
                facts=dict(outcome.facts),
                artifact_identities=dict(outcome.artifact_identities),
                evidence_refs=outcome.evidence_refs,
                failure_kind=outcome.failure_kind,
                failure_owner=outcome.failure_owner,
                next_action=outcome.next_action,
                started_at=started_at,
                duration_ms=duration_ms,
                non_claims=(
                    "operational_lane_acceptance_is_not_human_acceptance",
                    "lane_result_is_not_qualification_gate_release_or_live_authority",
                ),
            )
            self._apply_unexpected_observed_overlap(
                current_lane_id=lane_id,
                results=results,
                decisions=decisions_by_pair,
            )
        status, unresolved = self._derive_aggregate_status(self.plan, results)
        if status not in AGGREGATE_STATES:
            raise MultiLaneContractError(
                f"coordinator produced unsupported aggregate status {status!r}"
            )
        return MultiLaneAggregateResult(
            schema_version="1.0.0",
            artifact_type="multi_lane_aggregate_result",
            run_id=f"multi-lane-run-{uuid.uuid4().hex}",
            plan_id=self.plan.plan_id,
            plan_sha256=self.plan.sha256,
            project_id=self.plan.project_id,
            feature_id=self.plan.feature_id,
            task_id=self.plan.task_id,
            expected_source_revision=self.plan.expected_source_revision,
            profile_id=self.plan.profile_id,
            status=status,
            lane_order=order,
            lane_results=tuple(results[lane_id] for lane_id in order),
            unresolved_required_lane_ids=unresolved,
            completed_at=_utc_now(),
            non_claims=(
                "aggregate_completion_is_operational_not_human_acceptance",
                "aggregate_result_is_not_qualification_or_gate_evidence",
                "aggregate_result_is_not_release_or_pack_promotion_authority",
                "aggregate_result_grants_no_production_or_live_authority",
            ),
        )

    def run(
        self,
        *,
        attempt_ids: Mapping[str, int] | None = None,
    ) -> MultiLaneAggregateResult:
        """Execute one new aggregate from the explicit plan."""

        return self._run_internal(attempt_ids=attempt_ids)

    def recover(
        self,
        *,
        prior_result: MultiLaneAggregateResult,
        retry_lane_ids: Sequence[str],
    ) -> MultiLaneRecoveryOutcome:
        """Run only explicitly selected attempts and preserve unaffected facts."""

        selected = _text_tuple(retry_lane_ids, "retry_lane_ids")
        known_lane_ids = {lane.lane_id for lane in self.plan.lanes}
        unknown = set(selected) - known_lane_ids
        if unknown:
            raise MultiLaneContractError(
                f"retry selection references unknown lanes: {sorted(unknown)}"
            )
        prior_by_lane = self._validate_prior_result(prior_result)
        resumed = self._run_internal(
            prior_results_by_lane=prior_by_lane,
            selected_lane_ids=selected,
        )
        resumed_by_lane = {
            result.lane_id: result for result in resumed.lane_results
        }
        reused_result_ids = tuple(
            prior_by_lane[lane_id].result_id
            for lane_id in resumed.lane_order
            if resumed_by_lane[lane_id].result_id
            == prior_by_lane[lane_id].result_id
        )
        new_attempt_result_ids = tuple(
            resumed_by_lane[lane_id].result_id
            for lane_id in resumed.lane_order
            if lane_id in selected
            and resumed_by_lane[lane_id].result_id
            != prior_by_lane[lane_id].result_id
            and resumed_by_lane[lane_id].attempt_id
            > prior_by_lane[lane_id].attempt_id
        )
        stale_result_ids = tuple(
            result.result_id
            for result in resumed.lane_results
            if result.state == "stale"
        )
        needs_resolution_lane_ids = tuple(
            result.lane_id
            for result in resumed.lane_results
            if result.state == "needs_resolution"
        )
        receipt = MultiLaneRecoveryReceipt(
            schema_version="1.0.0",
            artifact_type="multi_lane_recovery_receipt",
            recovery_id=f"multi-lane-recovery-{uuid.uuid4().hex}",
            plan_id=self.plan.plan_id,
            plan_sha256=self.plan.sha256,
            prior_run_id=prior_result.run_id,
            resumed_run_id=resumed.run_id,
            status=resumed.status,
            selected_retry_lane_ids=selected,
            reused_lane_result_ids=reused_result_ids,
            new_attempt_result_ids=new_attempt_result_ids,
            stale_lane_result_ids=stale_result_ids,
            needs_resolution_lane_ids=needs_resolution_lane_ids,
            write_set_decisions=self.preflight_write_sets(),
            facts={
                "execution_mode": "deterministic_serial",
                "prior_status": prior_result.status,
                "resumed_status": resumed.status,
                "reused_lane_count": len(reused_result_ids),
                "new_attempt_count": len(new_attempt_result_ids),
                "stale_lane_count": len(stale_result_ids),
            },
            created_at=_utc_now(),
            non_claims=(
                "recovery_receipt_is_operational_not_a_gate_or_qualification",
                "reused_evidence_is_not_replayed_write_authority",
                "recovery_does_not_expand_lane_permissions_or_live_authority",
            ),
        )
        return MultiLaneRecoveryOutcome(
            aggregate_result=resumed,
            recovery_receipt=receipt,
        )


def lane_plan_from_dict(value: Mapping[str, Any]) -> LanePlan:
    """Build and validate a lane plan from an already parsed JSON object."""

    if not isinstance(value, Mapping):
        raise MultiLaneContractError("lane plan must be a mapping")
    allowed = {
        "schema_version",
        "artifact_type",
        "plan_id",
        "project_id",
        "feature_id",
        "task_id",
        "expected_source_revision",
        "profile_id",
        "profile_required_capabilities",
        "principals",
        "lanes",
        "max_write_concurrency",
        "non_claims",
    }
    extra = set(value) - allowed
    if extra:
        raise MultiLaneContractError(f"lane plan has unknown fields: {sorted(extra)}")
    try:
        principals = tuple(
            PrincipalBinding(
                principal_id=item["principal_id"],
                capabilities=tuple(item["capabilities"]),
            )
            for item in value["principals"]
        )
        lanes = tuple(
            LaneDefinition(
                lane_id=item["lane_id"],
                lane_kind=item["lane_kind"],
                primary_principal_id=item["primary_principal_id"],
                selected_agent_id=item.get("selected_agent_id"),
                selected_skill_id=item.get("selected_skill_id"),
                depends_on=tuple(item["depends_on"]),
                required_capabilities=tuple(item["required_capabilities"]),
                input_refs=tuple(item["input_refs"]),
                read_patterns=tuple(item["read_patterns"]),
                write_patterns=tuple(item["write_patterns"]),
                required_validators=tuple(item["required_validators"]),
                expected_output_artifact_types=tuple(
                    item["expected_output_artifact_types"]
                ),
                max_attempts=item["max_attempts"],
                timeout_seconds=item["timeout_seconds"],
                concurrency_group=item["concurrency_group"],
                serialized=item["serialized"],
                human_checkpoint_required=item["human_checkpoint_required"],
                required=item.get("required", True),
            )
            for item in value["lanes"]
        )
        return LanePlan(
            schema_version=value["schema_version"],
            artifact_type=value["artifact_type"],
            plan_id=value["plan_id"],
            project_id=value["project_id"],
            feature_id=value["feature_id"],
            task_id=value["task_id"],
            expected_source_revision=value["expected_source_revision"],
            profile_id=value["profile_id"],
            profile_required_capabilities=tuple(
                value["profile_required_capabilities"]
            ),
            principals=principals,
            lanes=lanes,
            max_write_concurrency=value["max_write_concurrency"],
            non_claims=tuple(value["non_claims"]),
        )
    except (KeyError, TypeError) as exc:
        raise MultiLaneContractError(f"lane plan has an invalid shape: {exc}") from exc


def write_multi_lane_receipt(
    *,
    receipt_path: str | Path,
    result: MultiLaneAggregateResult,
    schema_path: str | Path,
) -> Path:
    """Validate and create one aggregate receipt without overwriting."""

    if not isinstance(result, MultiLaneAggregateResult):
        raise MultiLaneReceiptError("result must be a MultiLaneAggregateResult")
    candidate = Path(receipt_path)
    if not candidate.is_absolute() or "\x00" in str(candidate):
        raise MultiLaneReceiptError("receipt_path must be an absolute safe path")
    parent = candidate.parent.resolve(strict=True)
    if not parent.is_dir() or parent.is_symlink():
        raise MultiLaneReceiptError("receipt parent must be a regular directory")
    final_path = parent / candidate.name
    if final_path.exists() or final_path.is_symlink():
        raise MultiLaneReceiptError(f"aggregate receipt already exists: {final_path}")
    schema_file = Path(schema_path).resolve(strict=True)
    try:
        schema = json.loads(schema_file.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise MultiLaneReceiptError(
            f"invalid aggregate receipt schema: {schema_file}: {exc}"
        ) from exc
    try:
        import jsonschema
    except ImportError as exc:
        raise MultiLaneReceiptError(
            "jsonschema is required to validate aggregate receipts"
        ) from exc
    value = result.to_dict()
    try:
        jsonschema.Draft7Validator(schema).validate(value)
    except jsonschema.ValidationError as exc:
        raise MultiLaneReceiptError(
            f"aggregate receipt is schema-invalid: {exc.message}"
        ) from exc
    temporary = parent / f".{final_path.name}.tmp-{uuid.uuid4().hex}"
    payload = (
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    try:
        descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, final_path)
    except FileExistsError as exc:
        raise MultiLaneReceiptError(
            f"aggregate receipt already exists: {final_path}"
        ) from exc
    finally:
        if temporary.exists():
            temporary.unlink()
    return final_path


def write_multi_lane_recovery_receipt(
    *,
    receipt_path: str | Path,
    receipt: MultiLaneRecoveryReceipt,
    schema_path: str | Path,
) -> Path:
    """Validate and create one append-only recovery receipt."""

    if not isinstance(receipt, MultiLaneRecoveryReceipt):
        raise MultiLaneReceiptError(
            "receipt must be a MultiLaneRecoveryReceipt"
        )
    candidate = Path(receipt_path)
    if not candidate.is_absolute() or "\x00" in str(candidate):
        raise MultiLaneReceiptError("receipt_path must be an absolute safe path")
    parent = candidate.parent.resolve(strict=True)
    if not parent.is_dir() or parent.is_symlink():
        raise MultiLaneReceiptError("receipt parent must be a regular directory")
    final_path = parent / candidate.name
    if final_path.exists() or final_path.is_symlink():
        raise MultiLaneReceiptError(f"recovery receipt already exists: {final_path}")
    schema_file = Path(schema_path).resolve(strict=True)
    try:
        schema = json.loads(schema_file.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise MultiLaneReceiptError(
            f"invalid recovery receipt schema: {schema_file}: {exc}"
        ) from exc
    try:
        import jsonschema
    except ImportError as exc:
        raise MultiLaneReceiptError(
            "jsonschema is required to validate recovery receipts"
        ) from exc
    value = receipt.to_dict()
    try:
        jsonschema.Draft7Validator(schema).validate(value)
    except jsonschema.ValidationError as exc:
        raise MultiLaneReceiptError(
            f"recovery receipt is schema-invalid: {exc.message}"
        ) from exc
    temporary = parent / f".{final_path.name}.tmp-{uuid.uuid4().hex}"
    payload = (
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    try:
        descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, final_path)
    except FileExistsError as exc:
        raise MultiLaneReceiptError(
            f"recovery receipt already exists: {final_path}"
        ) from exc
    finally:
        if temporary.exists():
            temporary.unlink()
    return final_path
