"""Advisory evolve-input assembly from verified project Evidence."""

from __future__ import annotations

from typing import Any, Mapping, Sequence

from ._development_evidence_common import (
    canonical_bytes,
    normalized_evidence_ids,
    normalized_text,
    sha256_bytes,
)


def build_evolution_bundle(
    store: Any,
    evidence_ids: Sequence[str],
    *,
    memory_ids: Sequence[str] = (),
) -> dict[str, Any]:
    """Build a deterministic, read-only evolve input from verified facts."""
    selected_evidence_ids = normalized_evidence_ids(evidence_ids)
    if not selected_evidence_ids:
        raise ValueError("codex_project_evidence_bundle_empty")

    from .development_evidence_lifecycle import (
        DevelopmentEvidenceLifecycleStore,
    )

    lifecycle = DevelopmentEvidenceLifecycleStore(store).resolve_all()
    lifecycle_bindings: dict[str, dict[str, Any]] = {}

    evidence_records: list[dict[str, Any]] = []
    for evidence_id in selected_evidence_ids:
        result = store.verify(evidence_id)
        if result["status"] != "ok":
            raise ValueError(
                "codex_project_evidence_bundle_evidence_invalid:"
                f"{evidence_id}"
            )
        record = result["evidence"]
        if record["verification_status"] != "verified":
            raise ValueError(
                "codex_project_evidence_bundle_evidence_unverified:"
                f"{evidence_id}"
            )
        effective = lifecycle["views"].get(evidence_id)
        if (
            not isinstance(effective, Mapping)
            or effective.get("status") != "ok"
            or not effective.get("current_eligible")
            or not effective.get("retrieval_eligible")
            or not effective.get("payload_visible")
        ):
            raise ValueError(
                "codex_project_evidence_bundle_evidence_lifecycle_ineligible:"
                f"{evidence_id}"
            )
        lifecycle_bindings[evidence_id] = {
            "lifecycle_revision": effective["lifecycle_revision"],
            "effective_state": effective["effective_state"],
        }
        evidence_records.append(record)

    if isinstance(memory_ids, (str, bytes)) or not isinstance(
        memory_ids, Sequence,
    ):
        raise ValueError("codex_project_evidence_memory_refs_invalid")
    selected_memory_ids = sorted(dict.fromkeys(
        normalized_text(value, field="memory_id", maximum=200)
        for value in memory_ids
    ))
    memory_records = _verified_memory_records(
        store,
        selected_memory_ids,
        selected_evidence_ids,
    )

    identity = {
        "project_id": store._project_id,
        "evidence_ids": selected_evidence_ids,
        "memory_ids": selected_memory_ids,
        "lifecycle_inventory_sha256": lifecycle[
            "lifecycle_inventory_sha256"
        ],
        "lifecycle_bindings": lifecycle_bindings,
    }
    return {
        "schema_version": "1.0.0",
        "artifact_type": "project_evolution_evidence_bundle",
        "bundle_id": "evolve-evidence-" + sha256_bytes(
            canonical_bytes(identity)
        )[:24],
        "project_id": store._project_id,
        "source_revisions": sorted({
            record["source_revision"] for record in evidence_records
        }),
        "evidence_records": evidence_records,
        "memory_records": memory_records,
        "integrity_status": "pass",
        "authority_status": "advisory_input_only",
        "non_claims": [
            "bundle_is_not_project_truth_or_memory_promotion",
            "bundle_is_not_an_evolution_decision_or_implementation_authority",
            "bundle_is_not_qualification_gate_release_or_live_authority",
        ],
    }


def _verified_memory_records(
    store: Any,
    memory_ids: Sequence[str],
    selected_evidence_ids: Sequence[str],
) -> list[dict[str, Any]]:
    if not memory_ids:
        return []

    from .development_project_memory import DevelopmentProjectMemoryStore

    memory_store = DevelopmentProjectMemoryStore(
        store._project_root,
        project_id=store._project_id,
    )
    memory_records: list[dict[str, Any]] = []
    for memory_id in memory_ids:
        result = memory_store.get(memory_id)
        if result["status"] != "ok":
            raise ValueError(
                "codex_project_evidence_bundle_memory_invalid:"
                f"{memory_id}"
            )
        memory = result["memory"]
        source = memory.get("source")
        refs = (
            source.get("evidence_refs", [])
            if isinstance(source, Mapping) else []
        )
        if (
            memory.get("format_version") != 2
            or not refs
            or not set(refs).issubset(selected_evidence_ids)
        ):
            raise ValueError(
                "codex_project_evidence_bundle_memory_unbound:"
                f"{memory_id}"
            )
        memory_records.append(memory)
    return memory_records
