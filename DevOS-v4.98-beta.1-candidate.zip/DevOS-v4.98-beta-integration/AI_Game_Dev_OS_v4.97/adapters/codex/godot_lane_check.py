"""Bounded Worker check contracts for concrete Godot lanes."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

from .multi_lane_workspace import project_relative_path, required_text


@dataclass(frozen=True)
class GodotLaneCheck:
    validator_id: str
    script_path: str
    pass_token: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "validator_id",
            required_text(self.validator_id, "validator_id"),
        )
        object.__setattr__(
            self,
            "script_path",
            project_relative_path(self.script_path, "script_path"),
        )
        object.__setattr__(
            self,
            "pass_token",
            required_text(self.pass_token, "pass_token"),
        )


class WorkspaceWorker(Protocol):
    project_root: Path
    attempt_id: int

    def preflight(self) -> dict[str, Any]: ...

    def run_script(
        self,
        script_path: str,
        *,
        expected_pass_token: str | None = None,
    ): ...


def compact_command_result(value: Any) -> dict[str, Any]:
    raw = value.to_dict() if hasattr(value, "to_dict") else {}
    return {
        "status": getattr(value, "status", raw.get("status")),
        "failure_kind": getattr(value, "failure_kind", raw.get("failure_kind")),
        "exit_code": getattr(value, "exit_code", raw.get("exit_code")),
        "run_id": getattr(value, "run_id", raw.get("run_id")),
        "pass_token_observed": getattr(
            value,
            "pass_token_observed",
            raw.get("pass_token_observed"),
        ),
        "ignored_diagnostic_count": raw.get("ignored_diagnostic_count", 0),
    }
