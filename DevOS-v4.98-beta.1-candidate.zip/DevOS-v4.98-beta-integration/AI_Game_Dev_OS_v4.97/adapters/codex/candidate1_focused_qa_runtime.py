"""Assembly-bound external focused QA for the v4.97 Candidate 1 pilot.

This host Adapter operation verifies one exact ``qualification_pilot`` lock,
materializes a separate Git execution workspace from the bound clean source,
adds only an excluded deterministic ``override.cfg`` for isolated Godot
``user://`` state, and delegates the selected must-pass scripts to the
canonical v4.97 focused-QA Agent/Skill binding.

The execution workspace and evidence are external runtime artifacts.  They are
not Project Binding write scopes, do not change the admitted source clone, and
cannot establish Human acceptance, qualification, adoption, release, or live
authority.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
from typing import Any, Mapping, Sequence

from adapters.codex.godot_focused_qa import FocusedQaCheck, GodotFocusedQaRunner
from engine_profiles.godot.runtime_v1_0_1 import (
    verify_git_tool_identity,
    verify_host_tool_identity,
)
from os_layer.scripts.runtime_state.model import parse_i_json, sha256_json
from production_runtime.composition.assembly import (
    AssemblyResolutionError,
    reresolve_and_verify_assembly_lock,
)
from production_runtime.composition.schema_validation import require_schema


VERSION_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_AGENT_CONTRACT = (
    VERSION_ROOT
    / "production_packs/runtime_feature_slice/agents/focused_qa_checker.agent.json"
)
DEFAULT_SKILL_CONTRACT = (
    VERSION_ROOT
    / "production_packs/runtime_feature_slice/skills/independent_focused_summary_qa.skill.json"
)
DEFAULT_TOOL_BINDING = (
    VERSION_ROOT
    / "adapters/codex/bindings/v497_candidate1_godot_focused_qa.binding.json"
)
DEFAULT_EVIDENCE_SCHEMA = (
    VERSION_ROOT
    / "pack_layer/packs/game_system_packs/end_to_end_production/"
    "references/artifact_schemas/qa_evidence_bundle.schema.json"
)
DEFAULT_GODOT_REQUIREMENT = VERSION_ROOT / "engine_profiles/godot/host_tool_requirement.json"
DEFAULT_GIT_REQUIREMENT = (
    VERSION_ROOT / "engine_profiles/godot/git_host_tool_requirement.json"
)

FOCUSED_QA_STAGE_ID = "independent_focused_qa"
FOCUSED_QA_OPERATION_ID = "perform_focused_qa"
FOCUSED_QA_VALIDATOR_ID = "focused_qa_source_integrity"
EXPECTED_PROJECT_ID = "lessismore_v497_qualification_pilot"
EXPECTED_ADAPTER_ID = "codex_candidate1_project_execution_qa"
EXPECTED_AGENT_ID = "focused_qa_checker"
EXPECTED_SKILL_ID = "independent_focused_summary_qa"

ALLOWED_CHECKS: Mapping[str, str] = {
    "tools/qa_v497_run_summary_projection_smoke.gd": "QA_RESULT: PASS",
    "tools/qa_v497_run_summary_presenter_smoke.gd": "QA_RESULT: PASS",
    "tools/qa_v497_run_summary_integration_smoke.gd": "QA_RESULT: PASS",
}
INTEGRITY_PATHS = (
    "scripts/map/run_summary_projection.gd",
    "scripts/map/run_summary_projection.gd.uid",
    "scripts/map/world_map_controller.gd",
    "scripts/ui/shared/run_summary_presenter.gd",
    "scripts/ui/shared/run_summary_presenter.gd.uid",
    "tools/qa_v497_run_summary_integration_smoke.gd",
    "tools/qa_v497_run_summary_integration_smoke.gd.uid",
    "tools/qa_v497_run_summary_presenter_smoke.gd",
    "tools/qa_v497_run_summary_presenter_smoke.gd.uid",
    "tools/qa_v497_run_summary_projection_smoke.gd",
    "tools/qa_v497_run_summary_projection_smoke.gd.uid",
)
_EXECUTION_ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9_.-]{2,63}$")


class Candidate1FocusedQaAssemblyError(RuntimeError):
    """Raised when exact assembly or external-workspace boundaries fail."""


def _load_object(value: Mapping[str, Any] | str | Path, *, label: str) -> dict:
    if isinstance(value, Mapping):
        candidate = json.loads(
            json.dumps(dict(value), ensure_ascii=False, sort_keys=True)
        )
    else:
        try:
            candidate = parse_i_json(Path(value).read_text(encoding="utf-8"))
        except (OSError, UnicodeError, ValueError) as exc:
            raise Candidate1FocusedQaAssemblyError(
                f"{label}_unreadable: {exc}"
            ) from exc
    if not isinstance(candidate, dict):
        raise Candidate1FocusedQaAssemblyError(f"{label}_not_object")
    return candidate


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _git_environment() -> dict[str, str]:
    environment = os.environ.copy()
    environment["GIT_OPTIONAL_LOCKS"] = "0"
    environment["GIT_TERMINAL_PROMPT"] = "0"
    return environment


def _git(
    git_binary: Path,
    repository: Path | None,
    *arguments: str,
    timeout_seconds: float = 60.0,
) -> str:
    argv = [str(git_binary)]
    if repository is not None:
        argv.extend(["-C", str(repository)])
    argv.extend(arguments)
    try:
        result = subprocess.run(
            argv,
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            shell=False,
            env=_git_environment(),
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise Candidate1FocusedQaAssemblyError(
            f"git_operation_unavailable: {exc}"
        ) from exc
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        raise Candidate1FocusedQaAssemblyError(
            f"git_operation_failed:{result.returncode}:{detail}"
        )
    return result.stdout.strip()


def _require_component(
    lock: Mapping[str, Any],
    *,
    artifact_type: str,
    component_id: str,
    version: str,
    canonical_sha256: str,
) -> None:
    matches = [
        item
        for item in lock.get("assembly_material", {}).get("component_refs", [])
        if isinstance(item, Mapping)
        and item.get("artifact_type") == artifact_type
        and item.get("component_id") == component_id
        and item.get("version") == version
        and item.get("canonical_sha256") == canonical_sha256
    ]
    if len(matches) != 1:
        raise Candidate1FocusedQaAssemblyError(
            f"assembly_component_not_exact:{artifact_type}:{component_id}"
        )


def _require_reference(
    lock: Mapping[str, Any],
    *,
    field: str,
    component_id: str,
) -> None:
    matches = [
        item
        for item in lock.get("assembly_material", {}).get(field, [])
        if isinstance(item, Mapping)
        and item.get("component_id") == component_id
        and item.get("identity_status") == "exact_bound"
    ]
    if len(matches) != 1:
        raise Candidate1FocusedQaAssemblyError(
            f"assembly_reference_not_exact:{field}:{component_id}"
        )


def _source_state(source: Path, git_binary: Path) -> dict[str, Any]:
    top = Path(_git(git_binary, source, "rev-parse", "--show-toplevel")).resolve(
        strict=True
    )
    if top != source:
        raise Candidate1FocusedQaAssemblyError("source_clone_not_repository_root")
    return {
        "head": _git(git_binary, source, "rev-parse", "HEAD"),
        "tree": _git(git_binary, source, "rev-parse", "HEAD^{tree}"),
        "status": _git(
            git_binary,
            source,
            "status",
            "--porcelain=v1",
            "--untracked-files=all",
        ),
    }


def verify_focused_qa_authorization(
    *,
    assembly_lock: Mapping[str, Any] | str | Path,
    assembly_component_paths: Sequence[str | Path],
    project_binding: Mapping[str, Any] | str | Path,
    qa_evidence_policy: Mapping[str, Any] | str | Path,
    stage_contract_binding: Mapping[str, Any] | str | Path,
) -> dict[str, Any]:
    """Re-resolve one exact permitted Candidate 1 focused-QA Adapter stage."""

    if isinstance(assembly_component_paths, (str, bytes)):
        raise Candidate1FocusedQaAssemblyError("assembly_component_paths_invalid")
    try:
        lock = reresolve_and_verify_assembly_lock(
            _load_object(assembly_lock, label="assembly_lock"),
            tuple(assembly_component_paths),
        )
    except (AssemblyResolutionError, OSError, TypeError, ValueError) as exc:
        raise Candidate1FocusedQaAssemblyError(
            f"assembly_reresolution_failed: {exc}"
        ) from exc
    project = _load_object(project_binding, label="project_binding")
    policy = _load_object(qa_evidence_policy, label="qa_evidence_policy")
    stage_binding = _load_object(
        stage_contract_binding, label="stage_contract_binding"
    )
    require_schema(project, "project_binding.schema.json")
    require_schema(policy, "qa_evidence_policy.schema.json")
    require_schema(stage_binding, "stage_contract_binding.schema.json")

    project_sha = sha256_json(project)
    policy_sha = sha256_json(policy)
    stage_sha = sha256_json(stage_binding)
    _require_component(
        lock,
        artifact_type="project_binding",
        component_id=str(project["project_binding_id"]),
        version=str(project["version"]),
        canonical_sha256=project_sha,
    )
    _require_component(
        lock,
        artifact_type="qa_evidence_policy",
        component_id=str(policy["qa_policy_id"]),
        version=str(policy["version"]),
        canonical_sha256=policy_sha,
    )
    _require_component(
        lock,
        artifact_type="stage_contract_binding",
        component_id=str(stage_binding["stage_contract_binding_id"]),
        version=str(stage_binding["version"]),
        canonical_sha256=stage_sha,
    )
    adapter_ref = project.get("execution_adapter_ref")
    if not isinstance(adapter_ref, Mapping):
        raise Candidate1FocusedQaAssemblyError("project_adapter_ref_invalid")
    if adapter_ref.get("component_id") != EXPECTED_ADAPTER_ID:
        raise Candidate1FocusedQaAssemblyError("project_adapter_not_qa_capable")
    _require_component(
        lock,
        artifact_type="execution_adapter",
        component_id=str(adapter_ref.get("component_id")),
        version=str(adapter_ref.get("version")),
        canonical_sha256=str(adapter_ref.get("canonical_sha256")),
    )
    _require_reference(
        lock, field="agent_contract_refs", component_id=EXPECTED_AGENT_ID
    )
    _require_reference(
        lock, field="skill_contract_refs", component_id=EXPECTED_SKILL_ID
    )

    material = lock["assembly_material"]
    if (
        material.get("execution_mode") != "project_write_admitted"
        or material.get("execution_ready") is not True
    ):
        raise Candidate1FocusedQaAssemblyError("assembly_execution_not_ready")
    if material.get("qualification_identity_ready") is not False:
        raise Candidate1FocusedQaAssemblyError(
            "assembly_qualification_identity_must_remain_false"
        )
    matches = [
        item
        for item in material.get("stage_resolution", [])
        if isinstance(item, Mapping)
        and item.get("stage_id") == FOCUSED_QA_STAGE_ID
    ]
    if len(matches) != 1:
        raise Candidate1FocusedQaAssemblyError("focused_qa_stage_not_exact")
    stage = matches[0]
    if (
        stage.get("disposition") != "required"
        or stage.get("blocking") is not True
        or stage.get("permission_status") != "permitted"
        or stage.get("execution_kind") != "adapter_operation"
        or stage.get("operation_id") != FOCUSED_QA_OPERATION_ID
        or stage.get("write_scope_ids") != []
        or stage.get("required_validator_ids") != [FOCUSED_QA_VALIDATOR_ID]
    ):
        raise Candidate1FocusedQaAssemblyError(
            "focused_qa_stage_authorization_mismatch"
        )
    graph = [
        item
        for item in material.get("command_graph", [])
        if isinstance(item, Mapping)
        and item.get("stage_id") == FOCUSED_QA_STAGE_ID
    ]
    if graph != [
        {
            "stage_id": FOCUSED_QA_STAGE_ID,
            "execution_kind": "adapter_operation",
            "operation_id": FOCUSED_QA_OPERATION_ID,
            "command_id": None,
            "executable_ref": None,
            "arguments": [],
        }
    ]:
        raise Candidate1FocusedQaAssemblyError(
            "focused_qa_command_graph_mismatch"
        )
    if (
        project.get("project_id") != EXPECTED_PROJECT_ID
        or project.get("binding_scope") != "host_exact"
        or FOCUSED_QA_OPERATION_ID not in project.get("permitted_operations", [])
        or FOCUSED_QA_VALIDATOR_ID not in project.get("allowed_validator_ids", [])
    ):
        raise Candidate1FocusedQaAssemblyError("project_focused_qa_scope_mismatch")
    if policy.get("project_binding_ref") != {
        "component_id": project["project_binding_id"],
        "version": project["version"],
        "canonical_sha256": project_sha,
    }:
        raise Candidate1FocusedQaAssemblyError("qa_policy_project_ref_mismatch")
    if policy.get("independent_checker_required") is not True:
        raise Candidate1FocusedQaAssemblyError("independent_checker_not_required")
    return {
        "assembly_sha256": lock["assembly_sha256"],
        "project_binding_id": project["project_binding_id"],
        "project_binding_sha256": project_sha,
        "qa_policy_id": policy["qa_policy_id"],
        "qa_policy_sha256": policy_sha,
        "stage_contract_binding_id": stage_binding["stage_contract_binding_id"],
        "stage_contract_binding_sha256": stage_sha,
        "source_identity": dict(project["source_identity"]),
        "project_root": project["project_root"],
        "project_subroot": project["project_subroot"],
        "execution_adapter_ref": dict(adapter_ref),
        "stage": dict(stage),
    }


def _validate_checks(check_paths: Sequence[str]) -> tuple[FocusedQaCheck, ...]:
    if isinstance(check_paths, (str, bytes)) or not check_paths:
        raise Candidate1FocusedQaAssemblyError("focused_qa_checks_invalid")
    normalized: list[FocusedQaCheck] = []
    seen: set[str] = set()
    for raw in check_paths:
        if not isinstance(raw, str) or raw not in ALLOWED_CHECKS or raw in seen:
            raise Candidate1FocusedQaAssemblyError(
                f"focused_qa_check_not_allowlisted:{raw}"
            )
        seen.add(raw)
        normalized.append(FocusedQaCheck(raw, ALLOWED_CHECKS[raw]))
    return tuple(normalized)


def _override_bytes(custom_user_dir_name: str) -> bytes:
    return (
        "[application]\n"
        "config/use_custom_user_dir=true\n"
        f'config/custom_user_dir_name="{custom_user_dir_name}"\n'
    ).encode("utf-8")


def _workspace_payload_manifest(workspace: Path) -> tuple[str, int]:
    entries: list[dict[str, Any]] = []
    for path in sorted(workspace.rglob("*"), key=lambda item: item.as_posix()):
        relative = path.relative_to(workspace)
        if not relative.parts:
            continue
        if relative.parts[0] in {".git", ".godot"} or relative.as_posix() == (
            "override.cfg"
        ):
            continue
        if path.is_symlink():
            raise Candidate1FocusedQaAssemblyError(
                f"qa_workspace_symlink_unsupported:{relative.as_posix()}"
            )
        if path.is_dir():
            continue
        entries.append(
            {
                "path": relative.as_posix(),
                "byte_count": path.stat().st_size,
                "sha256": _sha256_file(path),
            }
        )
    return sha256_json({"files": entries}), len(entries)


def run_candidate1_focused_qa(
    *,
    assembly_lock: Mapping[str, Any] | str | Path,
    assembly_component_paths: Sequence[str | Path],
    project_binding: Mapping[str, Any] | str | Path,
    qa_evidence_policy: Mapping[str, Any] | str | Path,
    stage_contract_binding: Mapping[str, Any] | str | Path,
    source_clone_root: str | Path,
    external_root: str | Path,
    execution_id: str,
    attempt_id: int,
    check_paths: Sequence[str],
    acceptance_criteria: Sequence[str],
    godot_host_tool_identity: Mapping[str, Any] | str | Path,
    git_host_tool_identity: Mapping[str, Any] | str | Path,
    timeout_seconds: float = 120.0,
) -> dict[str, Any]:
    """Materialize and execute one externally evidenced focused-QA attempt."""

    if not isinstance(execution_id, str) or _EXECUTION_ID_PATTERN.fullmatch(
        execution_id
    ) is None:
        raise Candidate1FocusedQaAssemblyError("execution_id_invalid")
    if not isinstance(attempt_id, int) or isinstance(attempt_id, bool) or attempt_id < 1:
        raise Candidate1FocusedQaAssemblyError("attempt_id_invalid")
    checks = _validate_checks(check_paths)
    if isinstance(acceptance_criteria, (str, bytes)) or not acceptance_criteria:
        raise Candidate1FocusedQaAssemblyError("acceptance_criteria_invalid")
    authorization = verify_focused_qa_authorization(
        assembly_lock=assembly_lock,
        assembly_component_paths=assembly_component_paths,
        project_binding=project_binding,
        qa_evidence_policy=qa_evidence_policy,
        stage_contract_binding=stage_contract_binding,
    )
    godot = verify_host_tool_identity(
        godot_host_tool_identity, requirement=DEFAULT_GODOT_REQUIREMENT
    )
    git = verify_git_tool_identity(
        git_host_tool_identity, requirement=DEFAULT_GIT_REQUIREMENT
    )
    source = Path(source_clone_root).resolve(strict=True)
    if str(source) != authorization["project_root"]:
        raise Candidate1FocusedQaAssemblyError("source_clone_binding_mismatch")
    source_before = _source_state(source, Path(git.executable_path))
    if source_before != {
        "head": authorization["source_identity"]["commit"],
        "tree": authorization["source_identity"]["tree"],
        "status": "",
    }:
        raise Candidate1FocusedQaAssemblyError("source_clone_identity_mismatch")

    outer = Path(external_root)
    if not outer.is_absolute() or "\x00" in str(outer):
        raise Candidate1FocusedQaAssemblyError("external_root_invalid")
    outer = outer.resolve(strict=True)
    run_root = outer / execution_id
    if run_root.exists() or run_root.is_symlink():
        raise Candidate1FocusedQaAssemblyError("execution_root_already_exists")
    run_root.mkdir(mode=0o700)
    workspace = run_root / "workspace"
    evidence = run_root / "evidence"
    logs = run_root / "logs"
    cache = run_root / "cache"
    for directory in (evidence, logs, cache):
        directory.mkdir(mode=0o700)

    _git(
        Path(git.executable_path),
        None,
        "clone",
        "--no-hardlinks",
        "--no-checkout",
        "--no-tags",
        "--quiet",
        str(source),
        str(workspace),
        timeout_seconds=180.0,
    )
    _git(
        Path(git.executable_path),
        workspace,
        "checkout",
        "--quiet",
        "--detach",
        authorization["source_identity"]["commit"],
    )
    seed = hashlib.sha256(
        (
            authorization["assembly_sha256"]
            + authorization["source_identity"]["commit"]
            + execution_id
        ).encode("ascii")
    ).hexdigest()
    custom_user_dir_name = f"ai_game_dev_os_v497_candidate1_qa_{seed[:24]}"
    override = workspace / "override.cfg"
    override.write_bytes(_override_bytes(custom_user_dir_name))
    info_exclude = workspace / ".git/info/exclude"
    existing_exclude = info_exclude.read_text(encoding="utf-8")
    suffix = "" if existing_exclude.endswith("\n") else "\n"
    info_exclude.write_text(
        existing_exclude + suffix + "/override.cfg\n/.godot/\n",
        encoding="utf-8",
    )
    workspace_before = _source_state(workspace, Path(git.executable_path))
    if workspace_before != source_before:
        raise Candidate1FocusedQaAssemblyError(
            "qa_workspace_source_identity_mismatch"
        )
    payload_before, payload_file_count = _workspace_payload_manifest(workspace)
    context = {
        "schema_version": "1.0.0",
        "artifact_type": "candidate1_focused_qa_assembly_context",
        "execution_id": execution_id,
        "attempt_id": attempt_id,
        "authorization": authorization,
        "source_clone_before": source_before,
        "workspace_before": workspace_before,
        "workspace": {
            "materialization_method": "local_git_clone_exact_detached_commit",
            "root": str(workspace),
            "payload_manifest_sha256": payload_before,
            "payload_file_count": payload_file_count,
            "override_sha256": _sha256_file(override),
            "custom_user_dir_name": custom_user_dir_name,
            "git_metadata_is_external_runtime_state": True,
        },
        "host_tools": {
            "godot": godot.to_dict(),
            "git": git.to_dict(),
        },
        "checks": [
            {"script_path": check.script_path, "pass_token": check.pass_token}
            for check in checks
        ],
        "acceptance_criteria": list(acceptance_criteria),
        "non_claims": [
            "external_git_workspace_is_not_a_project_binding_write_scope",
            "excluded_override_and_ignored_cache_are_not_source_revision_bytes",
            "assembly_context_is_not_qa_verdict_or_human_observation",
            "focused_qa_execution_grants_no_qualification_adoption_release_or_live_authority",
        ],
    }
    context_path = evidence / "candidate1_focused_qa_assembly_context.json"
    _write_json(context_path, context)

    runner = GodotFocusedQaRunner(
        project_root=workspace,
        artifact_root=evidence,
        evidence_name="focused_qa",
        task_id="v497-candidate1-lessismore-focused-qa",
        attempt_id=attempt_id,
        actor_id="codex-v497-focused-qa-checker",
        acceptance_criteria=acceptance_criteria,
        checks=checks,
        integrity_paths=INTEGRITY_PATHS,
        failure_owner="focused_qa_checker",
        next_skill_route="independent_focused_summary_qa",
        agent_contract_path=DEFAULT_AGENT_CONTRACT,
        skill_contract_path=DEFAULT_SKILL_CONTRACT,
        tool_binding_path=DEFAULT_TOOL_BINDING,
        evidence_schema_path=DEFAULT_EVIDENCE_SCHEMA,
        godot_binary=godot.executable_path,
        timeout_seconds=timeout_seconds,
    )
    try:
        result = runner.run()
        source_after = _source_state(source, Path(git.executable_path))
        workspace_after = _source_state(workspace, Path(git.executable_path))
        payload_after, after_file_count = _workspace_payload_manifest(workspace)
        if source_after != source_before:
            raise Candidate1FocusedQaAssemblyError(
                "focused_qa_changed_bound_source_clone"
            )
        if workspace_after != workspace_before:
            raise Candidate1FocusedQaAssemblyError(
                "focused_qa_changed_workspace_source_identity"
            )
        if (
            payload_after != payload_before
            or after_file_count != payload_file_count
        ):
            raise Candidate1FocusedQaAssemblyError(
                "focused_qa_changed_workspace_payload"
            )
        result_value = result.to_dict()
        bundle_path = Path(result.evidence_bundle_path)
        result_receipt = {
            "schema_version": "1.0.0",
            "artifact_type": "candidate1_focused_qa_execution_receipt",
            "execution_id": execution_id,
            "attempt_id": attempt_id,
            "assembly_sha256": authorization["assembly_sha256"],
            "project_binding_sha256": authorization["project_binding_sha256"],
            "source_identity": authorization["source_identity"],
            "workspace_payload_manifest_sha256": payload_after,
            "source_clone_unchanged": True,
            "workspace_source_unchanged": True,
            "qa_result": result_value,
            "qa_evidence_bundle_sha256": _sha256_file(bundle_path),
            "assembly_context_sha256": _sha256_file(context_path),
            "status": (
                "passed" if result.verdict == "DONE" else "review_needed"
            ),
            "non_claims": [
                "passed_is_a_factual_focused_qa_result_not_human_acceptance",
                "receipt_does_not_establish_qualification_supported_adoption_or_release",
                "checker_wrote_no_bound_project_source_paths",
            ],
        }
        result_path = evidence / "candidate1_focused_qa_execution_receipt.json"
        _write_json(result_path, result_receipt)
        return {
            "run_root": str(run_root),
            "workspace_root": str(workspace),
            "assembly_context_path": str(context_path),
            "result_path": str(result_path),
            "qa_bundle_path": str(bundle_path),
            "status": result_receipt["status"],
            "verdict": result.verdict,
            "failed_check_count": result.failed_check_count,
        }
    except Exception as exc:
        failure = {
            "schema_version": "1.0.0",
            "artifact_type": "candidate1_focused_qa_failure_receipt",
            "execution_id": execution_id,
            "attempt_id": attempt_id,
            "assembly_sha256": authorization["assembly_sha256"],
            "error_type": type(exc).__name__,
            "message": str(exc),
            "status": "failed",
            "non_claims": [
                "failure_receipt_is_not_qa_pass_or_human_acceptance",
                "failure_does_not_expand_project_write_or_external_authority",
            ],
        }
        _write_json(evidence / "candidate1_focused_qa_failure_receipt.json", failure)
        raise


__all__ = [
    "ALLOWED_CHECKS",
    "Candidate1FocusedQaAssemblyError",
    "INTEGRITY_PATHS",
    "run_candidate1_focused_qa",
    "verify_focused_qa_authorization",
]
