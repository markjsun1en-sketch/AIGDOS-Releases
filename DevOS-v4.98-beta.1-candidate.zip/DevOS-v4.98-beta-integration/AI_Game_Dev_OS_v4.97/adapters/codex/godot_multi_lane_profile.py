"""Build concrete Godot backends for the neutral multi-lane coordinator.

This runtime builder binds isolated workspaces, the existing bounded
Production Worker, focused-QA receipts, and common OS/profile identities.  It
does not create worktrees, edit project source, merge, or grant protected
authority.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from .godot_focused_qa_lane_backend import (
    GodotFocusedQaReceiptLaneBackend,
)
from .godot_lane_check import GodotLaneCheck
from .godot_workspace_lane_backend import (
    GodotWorkspaceLaneBackend,
)
from .multi_lane_coordinator import LaneBackend, LanePlan
from .multi_lane_workspace import (
    WorkspaceIdentityError,
    absolute_existing_path,
    project_relative_path,
    required_text,
    run_git,
    sha256_file,
)
from .production_worker import CodexProductionWorker


GodotMultiLaneProfileError = WorkspaceIdentityError


def _os_package_identity(
    repository_root: Path,
    *,
    package_relative_path: str,
) -> dict[str, Any]:
    package_path = project_relative_path(
        package_relative_path,
        "package_relative_path",
    )
    status = run_git(
        repository_root,
        "status",
        "--porcelain=v1",
        "--untracked-files=all",
    ).stdout.splitlines()
    if status:
        raise WorkspaceIdentityError(
            "OS repository must be clean for a real-lane receipt"
        )
    return {
        "repository_root": str(repository_root),
        "commit": run_git(repository_root, "rev-parse", "HEAD").stdout.strip(),
        "tree": run_git(
            repository_root,
            "rev-parse",
            "HEAD^{tree}",
        ).stdout.strip(),
        "package_relative_path": package_path,
        "package_tree": run_git(
            repository_root,
            "rev-parse",
            f"HEAD:{package_path}",
        ).stdout.strip(),
        "status": "clean",
    }


def _common_identities(
    *,
    plan: LanePlan,
    binding: Mapping[str, Any],
    binding_path: str | Path,
) -> dict[str, Any]:
    runtime_binding_path = absolute_existing_path(binding_path, "binding_path")
    repository = absolute_existing_path(
        binding.get("os_repository_root"),
        "os_repository_root",
    )
    profile_binding_path = absolute_existing_path(
        binding.get("profile_binding_path"),
        "profile_binding_path",
    )
    return {
        "os_package": _os_package_identity(
            repository,
            package_relative_path=binding.get("os_package_relative_path"),
        ),
        "lane_plan": {
            "plan_id": plan.plan_id,
            "sha256": plan.sha256,
        },
        "runtime_binding": {
            "path": str(runtime_binding_path),
            "sha256": sha256_file(runtime_binding_path),
        },
        "profile_binding": {
            "path": str(profile_binding_path),
            "sha256": sha256_file(profile_binding_path),
        },
    }


def _runtime_lane_bindings(
    plan: LanePlan,
    binding: Mapping[str, Any],
) -> dict[str, Mapping[str, Any]]:
    lane_bindings = binding.get("lanes")
    if not isinstance(lane_bindings, list):
        raise WorkspaceIdentityError("runtime binding lanes must be a list")
    binding_by_lane: dict[str, Mapping[str, Any]] = {}
    for item in lane_bindings:
        if not isinstance(item, Mapping):
            raise WorkspaceIdentityError(
                "runtime lane binding must be an object"
            )
        lane_id = required_text(item.get("lane_id"), "runtime lane_id")
        if lane_id in binding_by_lane:
            raise WorkspaceIdentityError(
                f"duplicate runtime lane binding: {lane_id}"
            )
        binding_by_lane[lane_id] = item
    declared_lane_ids = {lane.lane_id for lane in plan.lanes}
    if set(binding_by_lane) != declared_lane_ids:
        raise WorkspaceIdentityError(
            "runtime binding must bind every declared lane exactly once"
        )
    return binding_by_lane


def _build_worker_backend(
    *,
    plan: LanePlan,
    lane,
    item: Mapping[str, Any],
    attempt_id: int,
    version_root: Path,
    godot_binary: Path,
    common_identities: Mapping[str, Any],
) -> tuple[LaneBackend, Path]:
    workspace = absolute_existing_path(item.get("workspace_root"), "workspace_root")
    inputs = item.get("declared_input_paths")
    if not isinstance(inputs, list) or not inputs:
        raise WorkspaceIdentityError(f"lane {lane.lane_id} has no declared inputs")
    checks_value = item.get("checks")
    if not isinstance(checks_value, list):
        raise WorkspaceIdentityError(f"lane {lane.lane_id} checks must be a list")
    checks = tuple(
        GodotLaneCheck(
            validator_id=check["validator_id"],
            script_path=check["script_path"],
            pass_token=check["pass_token"],
        )
        for check in checks_value
    )
    pack_root = (
        version_root
        / "pack_layer/packs/game_system_packs/end_to_end_production"
    )
    worker = CodexProductionWorker(
        project_root=workspace,
        task_id=f"{plan.task_id}:{lane.lane_id}",
        attempt_id=attempt_id,
        actor_id=lane.primary_principal_id,
        agent_contract_path=(
            pack_root / "agents/godot_runtime_slice_engineer.json"
        ),
        skill_contract_path=(
            pack_root / "skills/godot_runtime_feature_slice_skill.json"
        ),
        skill_tool_binding_path=(
            version_root
            / "adapters/codex/bindings/godot_runtime_feature_slice.binding.json"
        ),
        declared_input_paths=tuple(inputs),
        declared_write_patterns=lane.write_patterns,
        godot_binary=godot_binary,
        require_clean_build_source=True,
        timeout_seconds=float(lane.timeout_seconds),
    )
    backend = GodotWorkspaceLaneBackend(
        lane_id=lane.lane_id,
        capabilities=lane.required_capabilities,
        worker=worker,
        expected_branch=item["expected_branch"],
        expected_output_revision=item["expected_output_revision"],
        result_artifact_type=item["result_artifact_type"],
        checks=checks,
        common_identities=common_identities,
        development_delivery_receipt=item.get(
            "development_delivery_receipt"
        ),
    )
    return backend, workspace


def build_godot_multi_lane_backends(
    *,
    plan: LanePlan,
    binding: Mapping[str, Any],
    binding_path: str | Path,
    version_root: str | Path,
) -> tuple[tuple[LaneBackend, ...], dict[str, int], tuple[str, ...]]:
    """Build concrete backends from one schema-validated runtime binding."""

    if not isinstance(binding, Mapping):
        raise WorkspaceIdentityError("runtime binding must be a mapping")
    if binding.get("artifact_type") != "godot_multi_lane_runtime_binding":
        raise WorkspaceIdentityError(
            "runtime binding has the wrong artifact_type"
        )
    if binding.get("schema_version") != "1.0.0":
        raise WorkspaceIdentityError(
            "runtime binding has an unsupported schema_version"
        )
    if (
        binding.get("plan_id") != plan.plan_id
        or binding.get("plan_sha256") != plan.sha256
    ):
        raise WorkspaceIdentityError(
            "runtime binding does not match the lane plan"
        )
    version = absolute_existing_path(version_root, "version_root")
    godot_binary = absolute_existing_path(
        binding.get("godot_binary"),
        "godot_binary",
    )
    common = _common_identities(
        plan=plan,
        binding=binding,
        binding_path=binding_path,
    )
    profile_capabilities = tuple(
        required_text(value, "profile capability")
        for value in binding.get("profile_capabilities", [])
    )
    binding_by_lane = _runtime_lane_bindings(plan, binding)
    lane_by_id = {lane.lane_id: lane for lane in plan.lanes}
    write_workspaces: list[Path] = []
    backends: list[LaneBackend] = []
    attempts: dict[str, int] = {}
    for lane_id in plan.topological_lane_ids():
        lane = lane_by_id[lane_id]
        item = binding_by_lane[lane_id]
        attempt_id = item.get("attempt_id")
        if (
            not isinstance(attempt_id, int)
            or not 1 <= attempt_id <= lane.max_attempts
        ):
            raise WorkspaceIdentityError(
                f"invalid runtime attempt for lane {lane_id}"
            )
        attempts[lane_id] = attempt_id
        kind = item.get("backend_kind")
        if kind == "worker_workspace":
            backend, workspace = _build_worker_backend(
                plan=plan,
                lane=lane,
                item=item,
                attempt_id=attempt_id,
                version_root=version,
                godot_binary=godot_binary,
                common_identities=common,
            )
            backends.append(backend)
            write_workspaces.append(workspace)
        elif kind == "focused_qa_receipt":
            backends.append(
                GodotFocusedQaReceiptLaneBackend(
                    lane_id=lane_id,
                    capabilities=lane.required_capabilities,
                    workspace_root=item["workspace_root"],
                    expected_branch=item["expected_branch"],
                    expected_output_revision=item["expected_output_revision"],
                    result_artifact_type=item["result_artifact_type"],
                    qa_bundle_path=item["qa_bundle_path"],
                    qa_integrity_path=item["qa_integrity_path"],
                    development_delivery_receipt=item[
                        "development_delivery_receipt"
                    ],
                    common_identities=common,
                    expected_attempt_id=attempt_id,
                )
            )
        else:
            raise WorkspaceIdentityError(
                f"lane {lane_id} has unsupported backend_kind {kind!r}"
            )
    if len(set(write_workspaces)) != len(write_workspaces):
        raise WorkspaceIdentityError(
            "write-capable lanes must use distinct physical workspaces"
        )
    return tuple(backends), attempts, profile_capabilities
