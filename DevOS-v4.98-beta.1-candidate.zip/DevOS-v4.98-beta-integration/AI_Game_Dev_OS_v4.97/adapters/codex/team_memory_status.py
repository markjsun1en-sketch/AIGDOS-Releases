"""Read-only Team Memory Provider and current-actor permission projection."""

from __future__ import annotations

from datetime import datetime, timezone
import re
from typing import Any, Mapping, Sequence

from ._development_evidence_common import canonical_bytes, sha256_bytes
from .development_project_permissions import (
    ProjectPermissionPolicy,
    ProjectPrincipalContext,
)
from .team_memory_provider import (
    TEAM_MEMORY_PROVIDER_OPERATIONS,
    TeamMemoryProviderClient,
)


TEAM_MEMORY_STATUS_CAPABILITIES = (
    "team_memory_read",
    "team_memory_propose",
    "team_memory_review",
    "team_memory_publish",
    "team_memory_activate",
    "team_memory_supersede",
    "team_memory_invalidate",
    "team_memory_redact",
    "team_memory_export_receipt",
)
PROVIDER_STATES = frozenset(
    {
        "not_installed",
        "installed_not_enabled",
        "enabled",
        "disabled",
        "policy_revision_mismatch",
        "activation_review_needed",
        "degraded",
        "incompatible",
    }
)
HEALTH_STATES = frozenset({"ok", "not_installed", "degraded"})
SAFE_PROVIDER_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,99}")
KNOWN_PROVIDER_ISSUES = frozenset(
    {
        "provider_operations_missing",
        "activation_not_object",
        "activation_fields_invalid",
        "activation_schema_invalid",
        "activation_artifact_type_invalid",
        "activation_provider_mismatch",
        "activation_project_mismatch",
        "activation_team_mismatch",
        "activation_enabled_invalid",
        "activation_revision_invalid",
        "activation_permission_policy_revision_invalid",
        "activation_actor_id_invalid",
        "activation_principal_kind_invalid",
        "activation_recorded_at_invalid",
        "activation_non_claims_invalid",
        "activation_content_hash_mismatch",
        "activation_policy_revision_mismatch",
    }
)
STATUS_NON_CLAIMS = (
    "status_snapshot_is_read_only_and_enumerates_no_memory_records",
    "actor_context_is_caller_supplied_not_authenticated_by_this_cli",
    "permission_projection_grants_no_gate_release_production_or_live_authority",
    "provider_status_does_not_enable_team_memory_or_promote_memory",
)


def _timestamp(value: str | None) -> str:
    if value is None:
        return datetime.now(timezone.utc).isoformat()
    if not isinstance(value, str) or not value.strip():
        raise ValueError("codex_team_memory_status_observed_at_invalid")
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(
            "codex_team_memory_status_observed_at_invalid"
        ) from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("codex_team_memory_status_observed_at_timezone_required")
    return parsed.astimezone(timezone.utc).isoformat()


def _provider_state(value: Any) -> str:
    return value if isinstance(value, str) and value in PROVIDER_STATES else "unknown"


def _health_state(value: Any) -> str:
    return value if isinstance(value, str) and value in HEALTH_STATES else "unknown"


def _provider_id(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, str) and SAFE_PROVIDER_ID.fullmatch(value):
        return value
    return "provider_id_redacted"


def _issue_codes(values: Any) -> list[str]:
    """Project only finite diagnostic codes; never echo Provider payload text."""
    if isinstance(values, (str, bytes)) or not isinstance(values, Sequence):
        return ["provider_issue_redacted"] if values else []
    result: list[str] = []
    for value in values:
        if isinstance(value, str) and value in KNOWN_PROVIDER_ISSUES:
            selected = str(value)
        elif isinstance(value, str) and value.startswith("provider_unavailable:"):
            selected = "provider_unavailable"
        else:
            selected = "provider_issue_redacted"
        if selected not in result:
            result.append(selected)
    return sorted(result)


def _operations(values: Any) -> list[str]:
    if isinstance(values, (str, bytes)) or not isinstance(values, Sequence):
        return []
    advertised = set(item for item in values if isinstance(item, str))
    return [
        operation
        for operation in TEAM_MEMORY_PROVIDER_OPERATIONS
        if operation in advertised
    ]


def _admission_projection(value: Mapping[str, Any]) -> dict[str, Any]:
    status = value.get("status")
    if status not in {"ready", "blocked"}:
        status = "blocked"
    reason = value.get("reason")
    return {
        "status": status,
        "team_memory_required": bool(value.get("team_memory_required")),
        "reason": _provider_state(reason) if reason is not None else None,
        "blocks_unrelated_tasks": bool(value.get("blocks_unrelated_tasks")),
    }


def build_team_memory_status_snapshot(
    client: TeamMemoryProviderClient,
    *,
    actor_context: ProjectPrincipalContext,
    permission_policy: ProjectPermissionPolicy,
    team_memory_required: bool = False,
    observed_at: str | None = None,
) -> dict[str, Any]:
    """Build a bounded status snapshot without calling get/search or writing state.

    The actor section is a policy projection for the exact caller-supplied
    context.  This function is not an authenticator and does not convert a
    matching grant into execution, production, Gate, release, or live authority.
    """
    if not isinstance(client, TeamMemoryProviderClient):
        raise ValueError("codex_team_memory_status_client_invalid")
    if not isinstance(actor_context, ProjectPrincipalContext):
        raise ValueError("codex_team_memory_status_actor_context_invalid")
    if not isinstance(permission_policy, ProjectPermissionPolicy):
        raise ValueError("codex_team_memory_status_permission_policy_invalid")
    if (
        actor_context.project_id != client.project_id
        or actor_context.team_id != client.team_id
        or permission_policy.project_id != client.project_id
    ):
        raise PermissionError("codex_team_memory_status_scope_mismatch")

    capabilities = client.capabilities(permission_policy=permission_policy)
    health = client.health()
    admission = client.admit_requirement(
        team_memory_required=bool(team_memory_required),
        permission_policy=permission_policy,
    )
    permission_rows = []
    for capability in TEAM_MEMORY_STATUS_CAPABILITIES:
        allowed = permission_policy.allows(actor_context, capability)
        permission_rows.append(
            {
                "capability": capability,
                "decision": "allowed" if allowed else "denied",
                "reason_code": (
                    "matching_grant" if allowed else "deny_by_default"
                ),
            }
        )
    issues = _issue_codes(capabilities.get("issues", []))
    for issue in _issue_codes(health.get("issues", [])):
        if issue not in issues:
            issues.append(issue)
    issues.sort()

    body = {
        "schema_version": "1.0.0",
        "artifact_type": "team_memory_status_snapshot",
        "observed_at": _timestamp(observed_at),
        "provider": {
            "status": _provider_state(capabilities.get("status")),
            "provider_id": _provider_id(capabilities.get("provider_id")),
            "installed": bool(capabilities.get("installed")),
            "enabled_for_scope": bool(capabilities.get("enabled_for_scope")),
            "health_status": _health_state(health.get("status")),
            "team_memory_available": bool(
                health.get("team_memory_available")
            ),
            "core_project_operations_available": bool(
                health.get("core_project_operations_available")
            ),
            "same_host_only": bool(health.get("same_host_only")),
            "operations": _operations(capabilities.get("operations", [])),
            "issues": issues,
        },
        "scope": {
            "project_id": client.project_id,
            "team_id": client.team_id,
            "permission_policy_revision": permission_policy.policy_revision,
            "permission_policy_scope_match": True,
        },
        "actor": {
            **actor_context.to_dict(),
            "identity_assurance": "caller_supplied_local_context_not_authenticated",
            "authority_status": "policy_projection_only",
        },
        "permissions": permission_rows,
        "admission": _admission_projection(admission),
        "non_claims": list(STATUS_NON_CLAIMS),
    }
    return {
        **body,
        "snapshot_sha256": sha256_bytes(canonical_bytes(body)),
    }
