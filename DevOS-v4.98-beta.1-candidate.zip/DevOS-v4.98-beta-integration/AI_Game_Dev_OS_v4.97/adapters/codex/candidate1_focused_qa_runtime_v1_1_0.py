"""Prepared external focused QA for the v4.97 Candidate 1 pilot.

This successor preserves the v1.0 runtime and its historical evidence.  It
adds one explicit, evidenced Godot ``--import`` preparation operation inside
the fresh external execution workspace before the canonical focused-QA runner
executes any script.  Generated ``.godot`` bytes remain ignored runtime state;
the exact bound source clone and tracked execution-workspace identity must stay
unchanged.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

from adapters.codex.candidate1_focused_qa_runtime import (
    ALLOWED_CHECKS,
    Candidate1FocusedQaAssemblyError,
    INTEGRITY_PATHS,
    _EXECUTION_ID_PATTERN,
    _git,
    _override_bytes,
    _sha256_file,
    _source_state,
    _validate_checks,
    _workspace_payload_manifest,
    _write_json,
    verify_focused_qa_authorization,
)
from adapters.codex.godot_focused_qa import GodotFocusedQaRunner
from engine_profiles.godot.runtime_v1_0_1 import (
    verify_git_tool_identity,
    verify_host_tool_identity,
)


VERSION_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_AGENT_CONTRACT = (
    VERSION_ROOT
    / "production_packs/runtime_feature_slice/agents/focused_qa_checker.agent.json"
)
DEFAULT_SKILL_CONTRACT = (
    VERSION_ROOT
    / "production_packs/runtime_feature_slice/skills/independent_focused_summary_qa.skill.json"
)
DEFAULT_TOOL_BINDING = (
    VERSION_ROOT
    / "adapters/codex/bindings/v497_candidate1_godot_focused_qa_prepared.binding.json"
)
DEFAULT_EVIDENCE_SCHEMA = (
    VERSION_ROOT
    / "pack_layer/packs/game_system_packs/end_to_end_production/"
    "references/artifact_schemas/qa_evidence_bundle.schema.json"
)
DEFAULT_GODOT_REQUIREMENT = (
    VERSION_ROOT / "engine_profiles/godot/host_tool_requirement.json"
)
DEFAULT_GIT_REQUIREMENT = (
    VERSION_ROOT / "engine_profiles/godot/git_host_tool_requirement.json"
)


def _bounded_timeout(value: float, *, label: str, maximum: float) -> float:
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or not math.isfinite(float(value))
        or float(value) <= 0
        or float(value) > maximum
    ):
        raise Candidate1FocusedQaAssemblyError(f"{label}_invalid")
    return float(value)


def run_candidate1_focused_qa(
    *,
    assembly_lock: Mapping[str, Any] | str | Path,
    assembly_component_paths: Sequence[str | Path],
    project_binding: Mapping[str, Any] | str | Path,
    qa_evidence_policy: Mapping[str, Any] | str | Path,
    stage_contract_binding: Mapping[str, Any] | str | Path,
    source_clone_root: str | Path,
    external_root: str | Path,
    execution_id: str,
    attempt_id: int,
    check_paths: Sequence[str],
    acceptance_criteria: Sequence[str],
    godot_host_tool_identity: Mapping[str, Any] | str | Path,
    git_host_tool_identity: Mapping[str, Any] | str | Path,
    timeout_seconds: float = 120.0,
    project_load_timeout_seconds: float = 300.0,
) -> dict[str, Any]:
    """Prepare and execute one exact, externally evidenced QA attempt."""

    if not isinstance(execution_id, str) or _EXECUTION_ID_PATTERN.fullmatch(
        execution_id
    ) is None:
        raise Candidate1FocusedQaAssemblyError("execution_id_invalid")
    if not isinstance(attempt_id, int) or isinstance(attempt_id, bool) or attempt_id < 1:
        raise Candidate1FocusedQaAssemblyError("attempt_id_invalid")
    qa_timeout = _bounded_timeout(
        timeout_seconds,
        label="focused_qa_timeout_seconds",
        maximum=3600.0,
    )
    load_timeout = _bounded_timeout(
        project_load_timeout_seconds,
        label="project_load_timeout_seconds",
        maximum=3600.0,
    )
    checks = _validate_checks(check_paths)
    if isinstance(acceptance_criteria, (str, bytes)) or not acceptance_criteria:
        raise Candidate1FocusedQaAssemblyError("acceptance_criteria_invalid")

    authorization = verify_focused_qa_authorization(
        assembly_lock=assembly_lock,
        assembly_component_paths=assembly_component_paths,
        project_binding=project_binding,
        qa_evidence_policy=qa_evidence_policy,
        stage_contract_binding=stage_contract_binding,
    )
    godot = verify_host_tool_identity(
        godot_host_tool_identity,
        requirement=DEFAULT_GODOT_REQUIREMENT,
    )
    git = verify_git_tool_identity(
        git_host_tool_identity,
        requirement=DEFAULT_GIT_REQUIREMENT,
    )
    source = Path(source_clone_root).resolve(strict=True)
    if str(source) != authorization["project_root"]:
        raise Candidate1FocusedQaAssemblyError("source_clone_binding_mismatch")
    source_before = _source_state(source, Path(git.executable_path))
    if source_before != {
        "head": authorization["source_identity"]["commit"],
        "tree": authorization["source_identity"]["tree"],
        "status": "",
    }:
        raise Candidate1FocusedQaAssemblyError("source_clone_identity_mismatch")

    outer = Path(external_root)
    if not outer.is_absolute() or "\x00" in str(outer):
        raise Candidate1FocusedQaAssemblyError("external_root_invalid")
    outer = outer.resolve(strict=True)
    run_root = outer / execution_id
    if run_root.exists() or run_root.is_symlink():
        raise Candidate1FocusedQaAssemblyError("execution_root_already_exists")
    run_root.mkdir(mode=0o700)
    workspace = run_root / "workspace"
    evidence = run_root / "evidence"
    logs = run_root / "logs"
    cache = run_root / "cache"
    for directory in (evidence, logs, cache):
        directory.mkdir(mode=0o700)

    _git(
        Path(git.executable_path),
        None,
        "clone",
        "--no-hardlinks",
        "--no-checkout",
        "--no-tags",
        "--quiet",
        str(source),
        str(workspace),
        timeout_seconds=180.0,
    )
    _git(
        Path(git.executable_path),
        workspace,
        "checkout",
        "--quiet",
        "--detach",
        authorization["source_identity"]["commit"],
    )
    seed = hashlib.sha256(
        (
            authorization["assembly_sha256"]
            + authorization["source_identity"]["commit"]
            + execution_id
        ).encode("ascii")
    ).hexdigest()
    custom_user_dir_name = f"ai_game_dev_os_v497_candidate1_qa_{seed[:24]}"
    override = workspace / "override.cfg"
    override.write_bytes(_override_bytes(custom_user_dir_name))
    info_exclude = workspace / ".git/info/exclude"
    existing_exclude = info_exclude.read_text(encoding="utf-8")
    suffix = "" if existing_exclude.endswith("\n") else "\n"
    info_exclude.write_text(
        existing_exclude + suffix + "/override.cfg\n/.godot/\n",
        encoding="utf-8",
    )
    workspace_before = _source_state(workspace, Path(git.executable_path))
    if workspace_before != source_before:
        raise Candidate1FocusedQaAssemblyError(
            "qa_workspace_source_identity_mismatch"
        )
    payload_before, payload_file_count = _workspace_payload_manifest(workspace)
    context_path = evidence / "candidate1_focused_qa_assembly_context.json"
    preparation_path = evidence / "candidate1_focused_qa_project_load.json"

    try:
        runner = GodotFocusedQaRunner(
            project_root=workspace,
            artifact_root=evidence,
            evidence_name="focused_qa",
            task_id="v497-candidate1-lessismore-focused-qa",
            attempt_id=attempt_id,
            actor_id="codex-v497-focused-qa-checker",
            acceptance_criteria=acceptance_criteria,
            checks=checks,
            integrity_paths=INTEGRITY_PATHS,
            failure_owner="focused_qa_checker",
            next_skill_route="independent_focused_summary_qa",
            agent_contract_path=DEFAULT_AGENT_CONTRACT,
            skill_contract_path=DEFAULT_SKILL_CONTRACT,
            tool_binding_path=DEFAULT_TOOL_BINDING,
            evidence_schema_path=DEFAULT_EVIDENCE_SCHEMA,
            godot_binary=godot.executable_path,
            timeout_seconds=load_timeout,
        )
        preparation = runner.execution.run_project_load()
        _write_json(preparation_path, preparation.to_dict())

        source_after_preparation = _source_state(
            source,
            Path(git.executable_path),
        )
        workspace_after_preparation = _source_state(
            workspace,
            Path(git.executable_path),
        )
        payload_after_preparation, prepared_file_count = (
            _workspace_payload_manifest(workspace)
        )
        class_cache = workspace / ".godot/global_script_class_cache.cfg"
        preparation_ready = (
            preparation.status == "pass"
            and class_cache.is_file()
            and not class_cache.is_symlink()
            and source_after_preparation == source_before
            and workspace_after_preparation == workspace_before
            and payload_after_preparation == payload_before
            and prepared_file_count == payload_file_count
        )
        context = {
            "schema_version": "1.0.0",
            "artifact_type": "candidate1_focused_qa_assembly_context",
            "execution_id": execution_id,
            "attempt_id": attempt_id,
            "authorization": authorization,
            "source_clone_before": source_before,
            "workspace_before": workspace_before,
            "workspace": {
                "materialization_method": "local_git_clone_exact_detached_commit",
                "root": str(workspace),
                "payload_manifest_sha256": payload_before,
                "payload_file_count": payload_file_count,
                "override_sha256": _sha256_file(override),
                "custom_user_dir_name": custom_user_dir_name,
                "git_metadata_is_external_runtime_state": True,
            },
            "workspace_preparation": {
                "operation": "project_load",
                "command_contract": [
                    "--headless",
                    "--path",
                    "{external_workspace}",
                    "--import",
                ],
                "result_sha256": _sha256_file(preparation_path),
                "result_status": preparation.status,
                "class_cache_sha256": (
                    _sha256_file(class_cache) if class_cache.is_file() else None
                ),
                "source_clone_unchanged": source_after_preparation == source_before,
                "workspace_source_unchanged": (
                    workspace_after_preparation == workspace_before
                ),
                "workspace_payload_unchanged": (
                    payload_after_preparation == payload_before
                    and prepared_file_count == payload_file_count
                ),
                "status": "ready" if preparation_ready else "blocked",
            },
            "host_tools": {
                "godot": godot.to_dict(),
                "git": git.to_dict(),
            },
            "checks": [
                {"script_path": check.script_path, "pass_token": check.pass_token}
                for check in checks
            ],
            "acceptance_criteria": list(acceptance_criteria),
            "non_claims": [
                "external_git_workspace_is_not_a_project_binding_write_scope",
                "godot_import_cache_is_derived_external_runtime_state",
                "project_load_preparation_is_not_a_project_gate_default",
                "assembly_context_is_not_qa_verdict_or_human_observation",
                "focused_qa_execution_grants_no_qualification_adoption_release_or_live_authority",
            ],
        }
        _write_json(context_path, context)
        if not preparation_ready:
            raise Candidate1FocusedQaAssemblyError(
                "qa_workspace_project_load_preparation_blocked"
            )

        runner.execution.timeout_seconds = qa_timeout
        result = runner.run()
        source_after = _source_state(source, Path(git.executable_path))
        workspace_after = _source_state(workspace, Path(git.executable_path))
        payload_after, after_file_count = _workspace_payload_manifest(workspace)
        if source_after != source_before:
            raise Candidate1FocusedQaAssemblyError(
                "focused_qa_changed_bound_source_clone"
            )
        if workspace_after != workspace_before:
            raise Candidate1FocusedQaAssemblyError(
                "focused_qa_changed_workspace_source_identity"
            )
        if payload_after != payload_before or after_file_count != payload_file_count:
            raise Candidate1FocusedQaAssemblyError(
                "focused_qa_changed_workspace_payload"
            )
        result_value = result.to_dict()
        bundle_path = Path(result.evidence_bundle_path)
        result_receipt = {
            "schema_version": "1.0.0",
            "artifact_type": "candidate1_focused_qa_execution_receipt",
            "execution_id": execution_id,
            "attempt_id": attempt_id,
            "assembly_sha256": authorization["assembly_sha256"],
            "project_binding_sha256": authorization["project_binding_sha256"],
            "source_identity": authorization["source_identity"],
            "workspace_payload_manifest_sha256": payload_after,
            "source_clone_unchanged": True,
            "workspace_source_unchanged": True,
            "project_load_result_sha256": _sha256_file(preparation_path),
            "project_load_status": preparation.status,
            "qa_result": result_value,
            "qa_evidence_bundle_sha256": _sha256_file(bundle_path),
            "assembly_context_sha256": _sha256_file(context_path),
            "status": "passed" if result.verdict == "DONE" else "review_needed",
            "non_claims": [
                "passed_is_a_factual_focused_qa_result_not_human_acceptance",
                "receipt_does_not_establish_qualification_supported_adoption_or_release",
                "checker_wrote_no_bound_project_source_paths",
                "derived_import_cache_is_not_project_source_or_delivery_output",
            ],
        }
        result_path = evidence / "candidate1_focused_qa_execution_receipt.json"
        _write_json(result_path, result_receipt)
        return {
            "run_root": str(run_root),
            "workspace_root": str(workspace),
            "assembly_context_path": str(context_path),
            "project_load_path": str(preparation_path),
            "result_path": str(result_path),
            "qa_bundle_path": str(bundle_path),
            "status": result_receipt["status"],
            "verdict": result.verdict,
            "failed_check_count": result.failed_check_count,
        }
    except Exception as exc:
        failure = {
            "schema_version": "1.0.0",
            "artifact_type": "candidate1_focused_qa_failure_receipt",
            "execution_id": execution_id,
            "attempt_id": attempt_id,
            "assembly_sha256": authorization["assembly_sha256"],
            "error_type": type(exc).__name__,
            "message": str(exc),
            "project_load_result_sha256": (
                _sha256_file(preparation_path) if preparation_path.is_file() else None
            ),
            "status": "failed",
            "non_claims": [
                "failure_receipt_is_not_qa_pass_or_human_acceptance",
                "failure_does_not_expand_project_write_or_external_authority",
            ],
        }
        _write_json(evidence / "candidate1_focused_qa_failure_receipt.json", failure)
        raise


__all__ = [
    "ALLOWED_CHECKS",
    "Candidate1FocusedQaAssemblyError",
    "INTEGRITY_PATHS",
    "run_candidate1_focused_qa",
    "verify_focused_qa_authorization",
]
