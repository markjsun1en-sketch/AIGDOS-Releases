"""Exact development-delivery and focused-QA receipt verification."""

from __future__ import annotations

from pathlib import Path, PurePosixPath
from typing import Any, Mapping

from .multi_lane_workspace import (
    WorkspaceIdentityError,
    json_file,
    project_relative_path,
    required_text,
    sha256_file,
)


def verify_development_delivery(
    receipt_path: Path,
    *,
    expected_source_revision: str,
) -> dict[str, Any]:
    receipt = json_file(receipt_path, "development delivery receipt")
    if receipt.get("artifact_type") != "godot_development_build_delivery":
        raise WorkspaceIdentityError("development receipt has the wrong artifact_type")
    if receipt.get("status") != "delivered":
        raise WorkspaceIdentityError("development receipt is not delivered")
    source = receipt.get("source_identity")
    if not isinstance(source, dict):
        raise WorkspaceIdentityError("development receipt has no source identity")
    if source.get("git_commit") != expected_source_revision:
        raise WorkspaceIdentityError("development receipt source commit mismatch")
    if source.get("git_status") != "clean":
        raise WorkspaceIdentityError("development receipt source was not clean")
    reproducibility = receipt.get("reproducibility")
    if (
        not isinstance(reproducibility, dict)
        or reproducibility.get("status") != "byte_identical"
    ):
        raise WorkspaceIdentityError("development receipt is not byte-identical")
    for label, field in (
        ("code signature", "code_signature_verification"),
        ("launch", "launch_verification"),
        ("recovery", "recovery_verification"),
    ):
        value = receipt.get(field)
        if not isinstance(value, dict) or value.get("status") != "pass":
            raise WorkspaceIdentityError(
                f"development receipt {label} did not pass"
            )
    artifact = receipt.get("artifact_identity")
    if not isinstance(artifact, dict):
        raise WorkspaceIdentityError("development receipt has no artifact identity")
    embedded = artifact.get("embedded_pck")
    if not isinstance(embedded, dict):
        raise WorkspaceIdentityError("development receipt has no embedded PCK identity")
    artifact_relative = project_relative_path(
        required_text(artifact.get("relative_path"), "artifact relative path"),
        "artifact relative path",
    )
    embedded_relative = project_relative_path(
        required_text(embedded.get("relative_path"), "embedded PCK relative path"),
        "embedded PCK relative path",
    )
    artifact_root = receipt_path.parent / artifact_relative
    embedded_path = artifact_root.joinpath(
        *PurePosixPath(embedded_relative).parts
    ).resolve(strict=True)
    try:
        embedded_path.relative_to(artifact_root.resolve(strict=True))
    except ValueError as exc:
        raise WorkspaceIdentityError("embedded PCK escaped the delivered app") from exc
    observed_pck_sha256 = sha256_file(embedded_path)
    if observed_pck_sha256 != embedded.get("content_sha256"):
        raise WorkspaceIdentityError("delivered embedded PCK identity changed")
    return {
        "delivery_id": receipt.get("delivery_id"),
        "receipt_path": str(receipt_path),
        "receipt_sha256": sha256_file(receipt_path),
        "source_commit": source.get("git_commit"),
        "source_tree": source.get("git_tree"),
        "artifact_tree_sha256": artifact.get("tree_sha256"),
        "embedded_pck_sha256": observed_pck_sha256,
        "reproducibility": reproducibility.get("status"),
        "code_signature": receipt["code_signature_verification"].get("status"),
        "launch": receipt["launch_verification"].get("status"),
        "recovery": receipt["recovery_verification"].get("status"),
    }


def verify_bundle_artifacts(
    bundle_path: Path,
    bundle: Mapping[str, Any],
) -> None:
    artifacts = bundle.get("artifacts")
    if not isinstance(artifacts, list) or not artifacts:
        raise WorkspaceIdentityError("QA bundle has no artifacts")
    evidence_root = bundle_path.parent.resolve(strict=True)
    for index, item in enumerate(artifacts):
        if not isinstance(item, dict):
            raise WorkspaceIdentityError(f"QA artifact {index} is not an object")
        relative = project_relative_path(
            item.get("path"),
            f"QA artifact {index} path",
        )
        candidate = evidence_root.joinpath(
            *PurePosixPath(relative).parts
        ).resolve(strict=True)
        try:
            candidate.relative_to(evidence_root)
        except ValueError as exc:
            raise WorkspaceIdentityError("QA artifact escaped its evidence root") from exc
        expected_hash = required_text(
            item.get("hash"),
            f"QA artifact {index} hash",
        )
        if not expected_hash.startswith("sha256:"):
            raise WorkspaceIdentityError("QA artifact hash must use sha256")
        if sha256_file(candidate) != expected_hash.removeprefix("sha256:"):
            raise WorkspaceIdentityError(
                f"QA artifact identity changed: {relative}"
            )
