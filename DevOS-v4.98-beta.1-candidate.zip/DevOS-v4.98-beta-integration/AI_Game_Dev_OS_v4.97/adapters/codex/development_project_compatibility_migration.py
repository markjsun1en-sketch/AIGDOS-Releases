"""Compatibility-first selected migration for v4.95 Evidence/Memory v2.

Source records are read and hashed in place.  Migration writes only a bounded
compatibility receipt and the disposable v4.96 retrieval index.
"""

from __future__ import annotations

import fcntl
import json
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from ._development_evidence_common import (
    canonical_bytes,
    normalized_evidence_ids,
    normalized_text,
    pretty_bytes,
    sha256_bytes,
)
from .development_project_evidence import DevelopmentProjectEvidenceStore
from .development_project_memory import DevelopmentProjectMemoryStore
from .development_project_permissions import (
    ProjectPermissionPolicy,
    ProjectPrincipalContext,
)
from .permission_aware_project_retrieval import (
    INDEX_RELATIVE_PATH,
    PROJECT_RETRIEVAL_RELATIVE_PATH,
    PermissionAwareProjectRetrieval,
)


COMPATIBILITY_MIGRATION_RELATIVE_PATH = Path(
    ".ai_dev_os/development/compatibility_migration"
)
RECEIPTS_RELATIVE_PATH = Path("receipts")
SAFE_MEMORY_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,199}")
SAFE_MIGRATION_ID = re.compile(r"compatibility-migration-[0-9a-f]{24}")
MAX_SELECTED_ITEMS = 200
NON_CLAIMS = (
    "migration_does_not_rewrite_or_delete_source_evidence_or_memory",
    "migration_does_not_promote_memory_or_change_source_authority",
    "migration_is_not_human_acceptance_or_gate_evidence",
    "migration_grants_no_release_production_or_live_authority",
)


def _timestamp(value: str, *, field: str) -> str:
    normalized = normalized_text(value, field=field, maximum=100)
    try:
        parsed = datetime.fromisoformat(normalized.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(
            f"codex_project_compatibility_migration_{field}_invalid"
        ) from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(
            f"codex_project_compatibility_migration_{field}_timezone_required"
        )
    return parsed.astimezone(timezone.utc).isoformat()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _content_digest(value: Mapping[str, Any]) -> str:
    return sha256_bytes(
        canonical_bytes(
            {key: item for key, item in value.items() if key != "content_sha256"}
        )
    )


class DevelopmentProjectCompatibilityMigration:
    """Dry-run and materialize one explicit selected compatibility set."""

    def __init__(self, project_root: str | Path, *, project_id: str) -> None:
        self._project_root = Path(project_root).resolve()
        if not self._project_root.is_dir():
            raise ValueError(
                "codex_project_compatibility_migration_project_root_invalid"
            )
        self._project_id = normalized_text(
            project_id, field="migration_project_id", maximum=200
        )
        self._root = self._project_root / COMPATIBILITY_MIGRATION_RELATIVE_PATH
        self._evidence_store = DevelopmentProjectEvidenceStore(
            self._project_root, project_id=self._project_id
        )
        self._memory_store = DevelopmentProjectMemoryStore(
            self._project_root, project_id=self._project_id
        )
        self._retrieval = PermissionAwareProjectRetrieval(
            self._project_root, project_id=self._project_id
        )

    def _check_scope(
        self,
        context: ProjectPrincipalContext,
        policy: ProjectPermissionPolicy,
    ) -> None:
        if not isinstance(context, ProjectPrincipalContext) or not isinstance(
            policy, ProjectPermissionPolicy
        ):
            raise ValueError(
                "codex_project_compatibility_migration_permission_invalid"
            )
        if (
            context.project_id != self._project_id
            or policy.project_id != self._project_id
        ):
            raise PermissionError("codex_project_permission_denied")

    @staticmethod
    def _memory_ids(values: Sequence[str]) -> list[str]:
        if isinstance(values, (str, bytes)) or not isinstance(values, Sequence):
            raise ValueError(
                "codex_project_compatibility_migration_memory_ids_invalid"
            )
        normalized: list[str] = []
        for value in values:
            memory_id = normalized_text(
                value, field="migration_memory_id", maximum=200
            )
            if SAFE_MEMORY_ID.fullmatch(memory_id) is None:
                raise ValueError(
                    "codex_project_compatibility_migration_memory_id_invalid"
                )
            if memory_id not in normalized:
                normalized.append(memory_id)
        return sorted(normalized)

    def _selection(
        self,
        evidence_ids: Sequence[str],
        memory_ids: Sequence[str],
    ) -> tuple[list[str], list[str]]:
        evidence = normalized_evidence_ids(evidence_ids)
        memory = self._memory_ids(memory_ids)
        if not evidence and not memory:
            raise ValueError(
                "codex_project_compatibility_migration_selection_required"
            )
        if len(evidence) + len(memory) > MAX_SELECTED_ITEMS:
            raise ValueError(
                "codex_project_compatibility_migration_selection_too_large"
            )
        return evidence, memory

    def dry_run(
        self,
        evidence_ids: Sequence[str],
        *,
        memory_ids: Sequence[str] = (),
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        effective_as_of: str | None = None,
    ) -> dict[str, Any]:
        """Inspect the selected sources without creating derived state."""
        self._check_scope(actor_context, permission_policy)
        evidence, memory = self._selection(evidence_ids, memory_ids)
        if evidence or memory:
            permission_policy.require(actor_context, "project_evidence_read")
        if memory:
            permission_policy.require(actor_context, "project_memory_read")
        selected_as_of = _timestamp(
            effective_as_of or _now(), field="effective_as_of"
        )
        items = [
            self._inspect_evidence(evidence_id, as_of=selected_as_of)
            for evidence_id in evidence
        ] + [
            self._inspect_memory(memory_id, as_of=selected_as_of)
            for memory_id in memory
        ]
        items.sort(key=lambda item: (item["source_kind"], item["source_id"]))
        compatible_count = sum(
            item["compatibility_status"] == "compatible" for item in items
        )
        incompatible_count = len(items) - compatible_count
        if incompatible_count == 0:
            status = "ok"
        elif compatible_count:
            status = "partial"
        else:
            status = "review_needed"
        selection = {
            "evidence_ids": evidence,
            "memory_ids": memory,
        }
        body = {
            "schema_version": "1.0.0",
            "artifact_type": "project_compatibility_migration_dry_run",
            "project_id": self._project_id,
            "source_package_version": "v4.95",
            "target_package_version": "v4.96",
            "principal_id": actor_context.principal_id,
            "principal_kind": actor_context.principal_kind,
            "team_scope": actor_context.team_id,
            "permission_policy_revision": permission_policy.policy_revision,
            "effective_as_of": selected_as_of,
            "selection": selection,
            "selection_sha256": sha256_bytes(canonical_bytes(selection)),
            "items": items,
            "compatible_count": compatible_count,
            "incompatible_count": incompatible_count,
            "status": status,
            "writes_performed": False,
            "non_claims": list(NON_CLAIMS),
        }
        return {**body, "report_sha256": sha256_bytes(canonical_bytes(body))}

    def _inspect_evidence(
        self, evidence_id: str, *, as_of: str,
    ) -> dict[str, Any]:
        exact = self._evidence_store.verify(evidence_id)
        if exact["status"] != "ok":
            return self._incompatible_item(
                "project_evidence",
                evidence_id,
                issues=[f"source_{exact['status']}", *exact.get("issues", [])],
            )
        evidence = exact["evidence"]
        if (
            evidence.get("artifact_type") != "project_evidence_record"
            or evidence.get("schema_version") != "1.0.0"
        ):
            return self._incompatible_item(
                "project_evidence",
                evidence_id,
                issues=["v495_evidence_schema_incompatible"],
            )
        view = self._evidence_store.resolve_evidence_lifecycle(
            evidence_id, as_of=as_of
        )
        issues = list(view["issues"])
        if evidence["verification_status"] != "verified":
            issues.append("evidence_not_verified_for_retrieval")
        return {
            "source_kind": "project_evidence",
            "source_id": evidence_id,
            "compatibility_status": "compatible",
            "source_schema": "v4.95/project_evidence_record@1.0.0",
            "source_revision": evidence["source_revision"],
            "source_record_sha256": exact["record_sha256"],
            "source_content_sha256": evidence["content"]["sha256"],
            "exact_source_ref": exact["record_ref"],
            "effective_state": view["effective_state"],
            "lifecycle_revision": view["lifecycle_revision"],
            "retrieval_eligible": bool(
                evidence["verification_status"] == "verified"
                and view["status"] == "ok"
                and view["retrieval_eligible"]
            ),
            "planned_projection": "evidence_lifecycle_v1",
            "source_authority_status": evidence["authority_status"],
            "issues": list(dict.fromkeys(issues)),
        }

    def _inspect_memory(
        self, memory_id: str, *, as_of: str,
    ) -> dict[str, Any]:
        exact = self._memory_store.get(memory_id)
        if exact["status"] != "ok":
            return self._incompatible_item(
                "project_memory",
                memory_id,
                issues=[f"source_{exact['status']}", *exact.get("issues", [])],
            )
        memory = exact["memory"]
        if memory.get("format_version") != 2:
            return self._incompatible_item(
                "project_memory",
                memory_id,
                issues=["v495_memory_v2_required"],
            )
        view = self._memory_store.resolve_memory_lifecycle(
            memory_id, as_of=as_of
        )
        source = memory["source"]
        return {
            "source_kind": "project_memory",
            "source_id": memory_id,
            "compatibility_status": "compatible",
            "source_schema": "v4.95/development_project_memory@2",
            "source_revision": source["source_revision"],
            "source_record_sha256": view["record_sha256"],
            "source_content_sha256": sha256_bytes(
                memory["content"].encode("utf-8")
            ),
            "exact_source_ref": exact["relative_path"],
            "effective_state": view["effective_state"],
            "lifecycle_revision": view["lifecycle_revision"],
            "retrieval_eligible": bool(
                view["status"] == "ok" and view["retrieval_eligible"]
            ),
            "planned_projection": "project_memory_lifecycle_v1",
            "source_authority_status": "unchanged_explicit_promotion",
            "issues": list(view["issues"]),
        }

    @staticmethod
    def _incompatible_item(
        source_kind: str, source_id: str, *, issues: Sequence[str],
    ) -> dict[str, Any]:
        return {
            "source_kind": source_kind,
            "source_id": source_id,
            "compatibility_status": "incompatible",
            "source_schema": None,
            "source_revision": None,
            "source_record_sha256": None,
            "source_content_sha256": None,
            "exact_source_ref": None,
            "effective_state": None,
            "lifecycle_revision": None,
            "retrieval_eligible": False,
            "planned_projection": "none",
            "source_authority_status": "unchanged",
            "issues": list(dict.fromkeys(issues))[:8],
        }

    def migrate(
        self,
        evidence_ids: Sequence[str],
        *,
        memory_ids: Sequence[str] = (),
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        effective_as_of: str | None = None,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        """Write one idempotent receipt and rebuild only derived index state."""
        self._check_scope(actor_context, permission_policy)
        permission_policy.require(
            actor_context, "project_compatibility_migrate"
        )
        # The shared Project index contains both source classes; its builder
        # must be authorized for both even when this selected set is smaller.
        permission_policy.require(actor_context, "project_evidence_read")
        permission_policy.require(actor_context, "project_memory_read")
        if effective_as_of is None:
            raise ValueError(
                "codex_project_compatibility_migration_effective_as_of_required"
            )
        dry_run = self.dry_run(
            evidence_ids,
            memory_ids=memory_ids,
            actor_context=actor_context,
            permission_policy=permission_policy,
            effective_as_of=effective_as_of,
        )
        index_result = self._retrieval.rebuild_index(
            actor_context=actor_context,
            permission_policy=permission_policy,
            effective_as_of=dry_run["effective_as_of"],
        )
        compatible_count = dry_run["compatible_count"]
        if dry_run["status"] == "ok" and index_result["status"] == "ok":
            migration_status = "complete"
        elif compatible_count:
            migration_status = "partial"
        else:
            migration_status = "review_needed"
        identity = {
            "project_id": self._project_id,
            "principal_id": actor_context.principal_id,
            "principal_kind": actor_context.principal_kind,
            "team_scope": actor_context.team_id,
            "permission_policy_revision": permission_policy.policy_revision,
            "dry_run_report_sha256": dry_run["report_sha256"],
            "derived_index_revision": index_result["index"]["index_revision"],
        }
        identity_sha256 = sha256_bytes(canonical_bytes(identity))
        migration_id = f"compatibility-migration-{identity_sha256[:24]}"
        receipts = self._receipts_directory(create=True)
        target = receipts / f"{migration_id}.json"
        lock_path = self._root / ".migration.lock"
        if lock_path.is_symlink():
            raise ValueError(
                "codex_project_compatibility_migration_lock_symlink_rejected"
            )
        with lock_path.open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            if target.exists():
                receipt = self._read_existing_receipt(
                    target,
                    expected_migration_id=migration_id,
                    expected_identity_sha256=identity_sha256,
                )
                status = "already_migrated"
            else:
                selected_recorded_at = _timestamp(
                    recorded_at or _now(), field="recorded_at"
                )
                body = {
                    "schema_version": "1.0.0",
                    "artifact_type": "project_compatibility_migration_receipt",
                    "migration_id": migration_id,
                    "migration_identity_sha256": identity_sha256,
                    "project_id": self._project_id,
                    "source_package_version": "v4.95",
                    "target_package_version": "v4.96",
                    "principal_id": actor_context.principal_id,
                    "principal_kind": actor_context.principal_kind,
                    "team_scope": actor_context.team_id,
                    "permission_policy_revision": (
                        permission_policy.policy_revision
                    ),
                    "effective_as_of": dry_run["effective_as_of"],
                    "selection_sha256": dry_run["selection_sha256"],
                    "dry_run_report_sha256": dry_run["report_sha256"],
                    "item_results": dry_run["items"],
                    "compatible_count": dry_run["compatible_count"],
                    "incompatible_count": dry_run["incompatible_count"],
                    "derived_index": {
                        "index_ref": index_result["index_ref"],
                        "index_revision": index_result["index"][
                            "index_revision"
                        ],
                        "index_sha256": index_result["index_sha256"],
                    },
                    "migration_status": migration_status,
                    "recorded_at": selected_recorded_at,
                    "non_claims": list(NON_CLAIMS),
                }
                receipt = {**body, "content_sha256": _content_digest(body)}
                self._write_new_receipt(target, receipt)
                status = "migrated"
        return {
            "status": status,
            "migration_status": receipt["migration_status"],
            "receipt": receipt,
            "receipt_ref": target.relative_to(self._project_root).as_posix(),
            "index": index_result,
        }

    def _receipts_directory(self, *, create: bool) -> Path:
        cursor = self._project_root
        for part in COMPATIBILITY_MIGRATION_RELATIVE_PATH.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                raise ValueError(
                    "codex_project_compatibility_migration_symlink_rejected"
                )
        for part in RECEIPTS_RELATIVE_PATH.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                raise ValueError(
                    "codex_project_compatibility_migration_symlink_rejected"
                )
        if create:
            cursor.mkdir(parents=True, exist_ok=True)
        return cursor

    @staticmethod
    def _write_new_receipt(target: Path, receipt: Mapping[str, Any]) -> None:
        serialized = pretty_bytes(receipt)
        temporary = target.parent / f".{target.name}.{uuid.uuid4().hex}.tmp"
        try:
            with temporary.open("xb") as output:
                output.write(serialized)
                output.flush()
                os.fsync(output.fileno())
            os.replace(temporary, target)
        finally:
            if temporary.exists():
                temporary.unlink()

    def _read_existing_receipt(
        self,
        path: Path,
        *,
        expected_migration_id: str,
        expected_identity_sha256: str,
    ) -> dict[str, Any]:
        if path.is_symlink():
            raise ValueError(
                "codex_project_compatibility_migration_receipt_symlink_rejected"
            )
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise ValueError(
                "codex_project_compatibility_migration_receipt_unreadable"
            ) from exc
        if (
            not isinstance(value, Mapping)
            or value.get("artifact_type")
            != "project_compatibility_migration_receipt"
            or value.get("project_id") != self._project_id
            or value.get("migration_id") != expected_migration_id
            or SAFE_MIGRATION_ID.fullmatch(expected_migration_id) is None
            or value.get("migration_identity_sha256")
            != expected_identity_sha256
            or value.get("content_sha256") != _content_digest(value)
        ):
            raise ValueError(
                "codex_project_compatibility_migration_receipt_conflict"
            )
        return dict(value)

    def discard_derived_index(
        self,
        expected_index_revision: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
    ) -> dict[str, Any]:
        """Discard only the disposable index; receipts and sources remain."""
        self._check_scope(actor_context, permission_policy)
        permission_policy.require(
            actor_context, "project_derived_state_discard"
        )
        revision = normalized_text(
            expected_index_revision,
            field="migration_expected_index_revision",
            maximum=64,
        )
        if (
            len(revision) != 64
            or any(character not in "0123456789abcdef" for character in revision)
        ):
            raise ValueError(
                "codex_project_compatibility_migration_index_revision_invalid"
            )
        index_path = (
            self._project_root
            / PROJECT_RETRIEVAL_RELATIVE_PATH
            / INDEX_RELATIVE_PATH
        )
        relative_ref = index_path.relative_to(self._project_root).as_posix()
        if not index_path.exists():
            return {
                "status": "already_discarded",
                "discarded_index_revision": revision,
                "index_ref": relative_ref,
                "source_records_changed": False,
            }
        lock_path = index_path.parent / ".index.lock"
        if lock_path.is_symlink():
            raise ValueError(
                "codex_project_compatibility_migration_index_lock_symlink_rejected"
            )
        with lock_path.open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            if index_path.is_symlink() or not index_path.is_file():
                raise ValueError(
                    "codex_project_compatibility_migration_index_invalid"
                )
            try:
                index = json.loads(index_path.read_text(encoding="utf-8"))
            except (OSError, UnicodeError, json.JSONDecodeError) as exc:
                raise ValueError(
                    "codex_project_compatibility_migration_index_unreadable"
                ) from exc
            if (
                not isinstance(index, Mapping)
                or index.get("index_revision") != revision
            ):
                raise ValueError(
                    "codex_project_compatibility_migration_index_revision_mismatch"
                )
            index_path.unlink()
        return {
            "status": "discarded",
            "discarded_index_revision": revision,
            "index_ref": relative_ref,
            "source_records_changed": False,
        }
