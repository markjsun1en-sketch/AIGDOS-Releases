"""Disposable-tool external focused QA for the v4.97 Candidate 1 pilot.

This successor preserves the prepared workspace and focused-QA behavior of
v1.1 while closing one engine-state boundary: Godot editor operations never run
from the shared host-tool installation.  The exact macOS application bundle is
copied into the fresh execution root, self-contained mode is enabled there,
and the adjacent ``editor_data`` directory is treated as disposable runtime
scratch.  The shared support root, bound source clone, and tracked execution
workspace must all remain byte-and-metadata stable.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import stat
from typing import Any, Mapping, Sequence

from adapters.codex.candidate1_focused_qa_runtime import (
    ALLOWED_CHECKS,
    Candidate1FocusedQaAssemblyError,
    INTEGRITY_PATHS,
    _EXECUTION_ID_PATTERN,
    _git,
    _override_bytes,
    _sha256_file,
    _source_state,
    _validate_checks,
    _workspace_payload_manifest,
    _write_json,
    verify_focused_qa_authorization,
)
from adapters.codex.godot_focused_qa import GodotFocusedQaRunner
from engine_profiles.godot.runtime_v1_0_1 import (
    verify_git_tool_identity,
    verify_host_tool_identity,
)


VERSION_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_AGENT_CONTRACT = (
    VERSION_ROOT
    / "production_packs/runtime_feature_slice/agents/focused_qa_checker.agent.json"
)
DEFAULT_SKILL_CONTRACT = (
    VERSION_ROOT
    / "production_packs/runtime_feature_slice/skills/independent_focused_summary_qa.skill.json"
)
DEFAULT_TOOL_BINDING = (
    VERSION_ROOT
    / "adapters/codex/bindings/v497_candidate1_godot_focused_qa_disposable.binding.json"
)
DEFAULT_EVIDENCE_SCHEMA = (
    VERSION_ROOT
    / "pack_layer/packs/game_system_packs/end_to_end_production/"
    "references/artifact_schemas/qa_evidence_bundle.schema.json"
)
DEFAULT_GODOT_REQUIREMENT = (
    VERSION_ROOT / "engine_profiles/godot/host_tool_requirement.json"
)
DEFAULT_GIT_REQUIREMENT = (
    VERSION_ROOT / "engine_profiles/godot/git_host_tool_requirement.json"
)


def _bounded_timeout(value: float, *, label: str, maximum: float) -> float:
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or not math.isfinite(float(value))
        or float(value) <= 0
        or float(value) > maximum
    ):
        raise Candidate1FocusedQaAssemblyError(f"{label}_invalid")
    return float(value)


def _identity_mapping(
    value: Mapping[str, Any] | str | Path,
) -> dict[str, Any]:
    if isinstance(value, Mapping):
        supplied = dict(value)
    elif isinstance(value, (str, Path)):
        path = Path(value)
        try:
            supplied = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise Candidate1FocusedQaAssemblyError(
                "godot_host_tool_identity_invalid"
            ) from exc
    else:
        raise Candidate1FocusedQaAssemblyError(
            "godot_host_tool_identity_invalid"
        )
    if not isinstance(supplied, dict):
        raise Candidate1FocusedQaAssemblyError(
            "godot_host_tool_identity_invalid"
        )
    return supplied


def _birthtime_ns(info: os.stat_result) -> int | None:
    exact = getattr(info, "st_birthtime_ns", None)
    if isinstance(exact, int):
        return exact
    value = getattr(info, "st_birthtime", None)
    if isinstance(value, (int, float)):
        return int(value * 1_000_000_000)
    return None


def _support_root_manifest(root: Path) -> dict[str, Any]:
    """Return one content-and-metadata identity for a read-only support root."""

    resolved = root.resolve(strict=True)
    if resolved != root or root.is_symlink() or not root.is_dir():
        raise Candidate1FocusedQaAssemblyError("godot_support_root_invalid")
    entries: list[dict[str, Any]] = []
    file_count = 0
    directory_count = 0
    symlink_count = 0
    byte_count = 0
    for path in sorted((root, *root.rglob("*")), key=lambda item: item.as_posix()):
        info = path.lstat()
        relative = "." if path == root else path.relative_to(root).as_posix()
        entry: dict[str, Any] = {
            "path": relative,
            "mode": stat.S_IMODE(info.st_mode),
            "mtime_ns": info.st_mtime_ns,
            "ctime_ns": info.st_ctime_ns,
            "birthtime_ns": _birthtime_ns(info),
        }
        if stat.S_ISLNK(info.st_mode):
            entry.update({"kind": "symlink", "target": os.readlink(path)})
            symlink_count += 1
        elif stat.S_ISDIR(info.st_mode):
            entry["kind"] = "directory"
            directory_count += 1
        elif stat.S_ISREG(info.st_mode):
            digest = _sha256_file(path)
            entry.update(
                {
                    "kind": "file",
                    "byte_count": info.st_size,
                    "sha256": digest,
                }
            )
            file_count += 1
            byte_count += info.st_size
        else:
            raise Candidate1FocusedQaAssemblyError(
                "godot_support_root_contains_unsupported_entry"
            )
        entries.append(entry)
    encoded = json.dumps(
        entries,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return {
        "root": str(root),
        "manifest_sha256": hashlib.sha256(encoded).hexdigest(),
        "entry_count": len(entries),
        "file_count": file_count,
        "directory_count": directory_count,
        "symlink_count": symlink_count,
        "byte_count": byte_count,
    }


def _macos_app_root(binary: Path) -> Path:
    expected_suffix = Path("Contents/MacOS/Godot")
    if len(binary.parents) < 3 or Path(*binary.parts[-3:]) != expected_suffix:
        raise Candidate1FocusedQaAssemblyError(
            "godot_host_tool_is_not_supported_macos_app_layout"
        )
    app_root = binary.parents[2]
    if app_root.suffix != ".app" or app_root.is_symlink() or not app_root.is_dir():
        raise Candidate1FocusedQaAssemblyError(
            "godot_host_tool_is_not_supported_macos_app_layout"
        )
    return app_root


def _materialize_disposable_godot(
    *,
    source_binary: Path,
    source_support_root: Path,
    destination_root: Path,
    expected_binary_sha256: str,
) -> dict[str, Any]:
    """Copy an exact Godot app into authorized per-run runtime scratch."""

    source_binary = source_binary.resolve(strict=True)
    source_support_root = source_support_root.resolve(strict=True)
    if (
        source_support_root.is_symlink()
        or not source_support_root.is_dir()
        or source_support_root not in source_binary.parents
    ):
        raise Candidate1FocusedQaAssemblyError("godot_support_root_mismatch")
    source_app = _macos_app_root(source_binary)
    if source_support_root not in (source_app, *source_app.parents):
        raise Candidate1FocusedQaAssemblyError("godot_support_root_mismatch")
    if destination_root.exists() or destination_root.is_symlink():
        raise Candidate1FocusedQaAssemblyError(
            "disposable_godot_root_already_exists"
        )
    destination_root.mkdir(mode=0o700)
    destination_app = destination_root / source_app.name
    shutil.copytree(
        source_app,
        destination_app,
        symlinks=True,
        copy_function=shutil.copy2,
    )
    relative_binary = source_binary.relative_to(source_app)
    disposable_binary = destination_app / relative_binary
    if disposable_binary.is_symlink() or not disposable_binary.is_file():
        raise Candidate1FocusedQaAssemblyError(
            "disposable_godot_binary_invalid"
        )
    actual_binary_sha256 = _sha256_file(disposable_binary)
    if actual_binary_sha256 != expected_binary_sha256:
        raise Candidate1FocusedQaAssemblyError(
            "disposable_godot_binary_identity_mismatch"
        )
    self_contained_marker = disposable_binary.parent / "_sc_"
    if self_contained_marker.exists() or self_contained_marker.is_symlink():
        if self_contained_marker.is_symlink() or not self_contained_marker.is_file():
            raise Candidate1FocusedQaAssemblyError(
                "disposable_godot_self_contained_marker_invalid"
            )
    else:
        self_contained_marker.write_bytes(b"")
    self_contained_marker.chmod(0o600)
    editor_data = destination_root / "editor_data"
    if editor_data.exists() or editor_data.is_symlink():
        raise Candidate1FocusedQaAssemblyError(
            "disposable_godot_editor_data_root_preexists"
        )
    editor_data.mkdir(mode=0o700)
    return {
        "materialization_method": "copy_exact_macos_app_into_per_run_scratch",
        "source_support_root": str(source_support_root),
        "source_app_root": str(source_app),
        "runtime_root": str(destination_root),
        "runtime_app_root": str(destination_app),
        "runtime_binary": str(disposable_binary),
        "runtime_binary_sha256": actual_binary_sha256,
        "self_contained_marker": str(self_contained_marker),
        "editor_data_root": str(editor_data),
    }


def _require_support_root_unchanged(
    before: Mapping[str, Any], after: Mapping[str, Any]
) -> None:
    if dict(after) != dict(before):
        raise Candidate1FocusedQaAssemblyError(
            "focused_qa_changed_read_only_godot_support_root"
        )


def run_candidate1_focused_qa(
    *,
    assembly_lock: Mapping[str, Any] | str | Path,
    assembly_component_paths: Sequence[str | Path],
    project_binding: Mapping[str, Any] | str | Path,
    qa_evidence_policy: Mapping[str, Any] | str | Path,
    stage_contract_binding: Mapping[str, Any] | str | Path,
    source_clone_root: str | Path,
    external_root: str | Path,
    execution_id: str,
    attempt_id: int,
    check_paths: Sequence[str],
    acceptance_criteria: Sequence[str],
    godot_host_tool_identity: Mapping[str, Any] | str | Path,
    git_host_tool_identity: Mapping[str, Any] | str | Path,
    godot_support_root: str | Path,
    timeout_seconds: float = 120.0,
    project_load_timeout_seconds: float = 300.0,
) -> dict[str, Any]:
    """Prepare and execute one exact, externally evidenced QA attempt."""

    if not isinstance(execution_id, str) or _EXECUTION_ID_PATTERN.fullmatch(
        execution_id
    ) is None:
        raise Candidate1FocusedQaAssemblyError("execution_id_invalid")
    if not isinstance(attempt_id, int) or isinstance(attempt_id, bool) or attempt_id < 1:
        raise Candidate1FocusedQaAssemblyError("attempt_id_invalid")
    qa_timeout = _bounded_timeout(
        timeout_seconds,
        label="focused_qa_timeout_seconds",
        maximum=3600.0,
    )
    load_timeout = _bounded_timeout(
        project_load_timeout_seconds,
        label="project_load_timeout_seconds",
        maximum=3600.0,
    )
    checks = _validate_checks(check_paths)
    if isinstance(acceptance_criteria, (str, bytes)) or not acceptance_criteria:
        raise Candidate1FocusedQaAssemblyError("acceptance_criteria_invalid")

    authorization = verify_focused_qa_authorization(
        assembly_lock=assembly_lock,
        assembly_component_paths=assembly_component_paths,
        project_binding=project_binding,
        qa_evidence_policy=qa_evidence_policy,
        stage_contract_binding=stage_contract_binding,
    )
    supplied_godot_identity = _identity_mapping(godot_host_tool_identity)
    raw_godot_path = supplied_godot_identity.get("executable_path")
    supplied_godot_sha256 = supplied_godot_identity.get("binary_sha256")
    if (
        not isinstance(raw_godot_path, str)
        or not raw_godot_path
        or "\x00" in raw_godot_path
        or not isinstance(supplied_godot_sha256, str)
        or len(supplied_godot_sha256) != 64
        or any(character not in "0123456789abcdef" for character in supplied_godot_sha256)
    ):
        raise Candidate1FocusedQaAssemblyError(
            "godot_host_tool_identity_invalid"
        )
    lexical_godot_binary = Path(raw_godot_path)
    if not lexical_godot_binary.is_absolute():
        raise Candidate1FocusedQaAssemblyError(
            "godot_host_tool_identity_invalid"
        )
    godot_binary = lexical_godot_binary.resolve(strict=True)
    if (
        lexical_godot_binary.is_symlink()
        or godot_binary != lexical_godot_binary
        or not godot_binary.is_file()
    ):
        raise Candidate1FocusedQaAssemblyError(
            "godot_host_tool_identity_invalid"
        )
    git = verify_git_tool_identity(
        git_host_tool_identity,
        requirement=DEFAULT_GIT_REQUIREMENT,
    )
    support_root = Path(godot_support_root)
    if not support_root.is_absolute() or "\x00" in str(support_root):
        raise Candidate1FocusedQaAssemblyError("godot_support_root_invalid")
    support_root = support_root.resolve(strict=True)
    if support_root not in godot_binary.parents:
        raise Candidate1FocusedQaAssemblyError("godot_support_root_mismatch")
    support_before = _support_root_manifest(support_root)
    source = Path(source_clone_root).resolve(strict=True)
    if str(source) != authorization["project_root"]:
        raise Candidate1FocusedQaAssemblyError("source_clone_binding_mismatch")
    source_before = _source_state(source, Path(git.executable_path))
    if source_before != {
        "head": authorization["source_identity"]["commit"],
        "tree": authorization["source_identity"]["tree"],
        "status": "",
    }:
        raise Candidate1FocusedQaAssemblyError("source_clone_identity_mismatch")

    outer = Path(external_root)
    if not outer.is_absolute() or "\x00" in str(outer):
        raise Candidate1FocusedQaAssemblyError("external_root_invalid")
    outer = outer.resolve(strict=True)
    run_root = outer / execution_id
    if run_root.exists() or run_root.is_symlink():
        raise Candidate1FocusedQaAssemblyError("execution_root_already_exists")
    run_root.mkdir(mode=0o700)
    workspace = run_root / "workspace"
    evidence = run_root / "evidence"
    logs = run_root / "logs"
    cache = run_root / "cache"
    for directory in (evidence, logs, cache):
        directory.mkdir(mode=0o700)
    disposable_godot = _materialize_disposable_godot(
        source_binary=godot_binary,
        source_support_root=support_root,
        destination_root=run_root / "godot_tool",
        expected_binary_sha256=supplied_godot_sha256,
    )
    support_after_materialization = _support_root_manifest(support_root)
    _require_support_root_unchanged(support_before, support_after_materialization)
    disposable_identity = dict(supplied_godot_identity)
    disposable_identity["executable_path"] = disposable_godot["runtime_binary"]
    godot = verify_host_tool_identity(
        disposable_identity,
        requirement=DEFAULT_GODOT_REQUIREMENT,
    )
    support_after_tool_probe = _support_root_manifest(support_root)
    _require_support_root_unchanged(support_before, support_after_tool_probe)

    _git(
        Path(git.executable_path),
        None,
        "clone",
        "--no-hardlinks",
        "--no-checkout",
        "--no-tags",
        "--quiet",
        str(source),
        str(workspace),
        timeout_seconds=180.0,
    )
    _git(
        Path(git.executable_path),
        workspace,
        "checkout",
        "--quiet",
        "--detach",
        authorization["source_identity"]["commit"],
    )
    seed = hashlib.sha256(
        (
            authorization["assembly_sha256"]
            + authorization["source_identity"]["commit"]
            + execution_id
        ).encode("ascii")
    ).hexdigest()
    custom_user_dir_name = f"ai_game_dev_os_v497_candidate1_qa_{seed[:24]}"
    override = workspace / "override.cfg"
    override.write_bytes(_override_bytes(custom_user_dir_name))
    info_exclude = workspace / ".git/info/exclude"
    existing_exclude = info_exclude.read_text(encoding="utf-8")
    suffix = "" if existing_exclude.endswith("\n") else "\n"
    info_exclude.write_text(
        existing_exclude + suffix + "/override.cfg\n/.godot/\n",
        encoding="utf-8",
    )
    workspace_before = _source_state(workspace, Path(git.executable_path))
    if workspace_before != source_before:
        raise Candidate1FocusedQaAssemblyError(
            "qa_workspace_source_identity_mismatch"
        )
    payload_before, payload_file_count = _workspace_payload_manifest(workspace)
    context_path = evidence / "candidate1_focused_qa_assembly_context.json"
    preparation_path = evidence / "candidate1_focused_qa_project_load.json"

    try:
        runner = GodotFocusedQaRunner(
            project_root=workspace,
            artifact_root=evidence,
            evidence_name="focused_qa",
            task_id="v497-candidate1-lessismore-focused-qa",
            attempt_id=attempt_id,
            actor_id="codex-v497-focused-qa-checker",
            acceptance_criteria=acceptance_criteria,
            checks=checks,
            integrity_paths=INTEGRITY_PATHS,
            failure_owner="focused_qa_checker",
            next_skill_route="independent_focused_summary_qa",
            agent_contract_path=DEFAULT_AGENT_CONTRACT,
            skill_contract_path=DEFAULT_SKILL_CONTRACT,
            tool_binding_path=DEFAULT_TOOL_BINDING,
            evidence_schema_path=DEFAULT_EVIDENCE_SCHEMA,
            godot_binary=disposable_godot["runtime_binary"],
            timeout_seconds=load_timeout,
        )
        preparation = runner.execution.run_project_load()
        _write_json(preparation_path, preparation.to_dict())

        source_after_preparation = _source_state(
            source,
            Path(git.executable_path),
        )
        workspace_after_preparation = _source_state(
            workspace,
            Path(git.executable_path),
        )
        payload_after_preparation, prepared_file_count = (
            _workspace_payload_manifest(workspace)
        )
        support_after_preparation = _support_root_manifest(support_root)
        _require_support_root_unchanged(support_before, support_after_preparation)
        class_cache = workspace / ".godot/global_script_class_cache.cfg"
        preparation_ready = (
            preparation.status == "pass"
            and class_cache.is_file()
            and not class_cache.is_symlink()
            and source_after_preparation == source_before
            and workspace_after_preparation == workspace_before
            and payload_after_preparation == payload_before
            and prepared_file_count == payload_file_count
        )
        context = {
            "schema_version": "1.0.0",
            "artifact_type": "candidate1_focused_qa_assembly_context",
            "execution_id": execution_id,
            "attempt_id": attempt_id,
            "authorization": authorization,
            "source_clone_before": source_before,
            "workspace_before": workspace_before,
            "workspace": {
                "materialization_method": "local_git_clone_exact_detached_commit",
                "root": str(workspace),
                "payload_manifest_sha256": payload_before,
                "payload_file_count": payload_file_count,
                "override_sha256": _sha256_file(override),
                "custom_user_dir_name": custom_user_dir_name,
                "git_metadata_is_external_runtime_state": True,
            },
            "workspace_preparation": {
                "operation": "project_load",
                "command_contract": [
                    "--headless",
                    "--path",
                    "{external_workspace}",
                    "--import",
                ],
                "result_sha256": _sha256_file(preparation_path),
                "result_status": preparation.status,
                "class_cache_sha256": (
                    _sha256_file(class_cache) if class_cache.is_file() else None
                ),
                "source_clone_unchanged": source_after_preparation == source_before,
                "workspace_source_unchanged": (
                    workspace_after_preparation == workspace_before
                ),
                "workspace_payload_unchanged": (
                    payload_after_preparation == payload_before
                    and prepared_file_count == payload_file_count
                ),
                "status": "ready" if preparation_ready else "blocked",
            },
            "godot_runtime_scratch": {
                **disposable_godot,
                "source_support_manifest_before": support_before,
                "source_support_manifest_after_project_load": (
                    support_after_preparation
                ),
                "source_support_root_unchanged": True,
            },
            "host_tools": {
                "godot": godot.to_dict(),
                "git": git.to_dict(),
            },
            "checks": [
                {"script_path": check.script_path, "pass_token": check.pass_token}
                for check in checks
            ],
            "acceptance_criteria": list(acceptance_criteria),
            "non_claims": [
                "external_git_workspace_is_not_a_project_binding_write_scope",
                "godot_import_cache_is_derived_external_runtime_state",
                "godot_editor_data_is_derived_per_run_runtime_state",
                "shared_godot_support_root_is_read_only_and_identity_checked",
                "project_load_preparation_is_not_a_project_gate_default",
                "assembly_context_is_not_qa_verdict_or_human_observation",
                "focused_qa_execution_grants_no_qualification_adoption_release_or_live_authority",
            ],
        }
        _write_json(context_path, context)
        if not preparation_ready:
            raise Candidate1FocusedQaAssemblyError(
                "qa_workspace_project_load_preparation_blocked"
            )

        runner.execution.timeout_seconds = qa_timeout
        result = runner.run()
        source_after = _source_state(source, Path(git.executable_path))
        workspace_after = _source_state(workspace, Path(git.executable_path))
        payload_after, after_file_count = _workspace_payload_manifest(workspace)
        support_after = _support_root_manifest(support_root)
        _require_support_root_unchanged(support_before, support_after)
        if source_after != source_before:
            raise Candidate1FocusedQaAssemblyError(
                "focused_qa_changed_bound_source_clone"
            )
        if workspace_after != workspace_before:
            raise Candidate1FocusedQaAssemblyError(
                "focused_qa_changed_workspace_source_identity"
            )
        if payload_after != payload_before or after_file_count != payload_file_count:
            raise Candidate1FocusedQaAssemblyError(
                "focused_qa_changed_workspace_payload"
            )
        result_value = result.to_dict()
        bundle_path = Path(result.evidence_bundle_path)
        result_receipt = {
            "schema_version": "1.0.0",
            "artifact_type": "candidate1_focused_qa_execution_receipt",
            "execution_id": execution_id,
            "attempt_id": attempt_id,
            "assembly_sha256": authorization["assembly_sha256"],
            "project_binding_sha256": authorization["project_binding_sha256"],
            "source_identity": authorization["source_identity"],
            "workspace_payload_manifest_sha256": payload_after,
            "source_clone_unchanged": True,
            "workspace_source_unchanged": True,
            "shared_godot_support_root": {
                "before": support_before,
                "after": support_after,
                "unchanged": True,
            },
            "disposable_godot_runtime": disposable_godot,
            "project_load_result_sha256": _sha256_file(preparation_path),
            "project_load_status": preparation.status,
            "qa_result": result_value,
            "qa_evidence_bundle_sha256": _sha256_file(bundle_path),
            "assembly_context_sha256": _sha256_file(context_path),
            "status": "passed" if result.verdict == "DONE" else "review_needed",
            "non_claims": [
                "passed_is_a_factual_focused_qa_result_not_human_acceptance",
                "receipt_does_not_establish_qualification_supported_adoption_or_release",
                "checker_wrote_no_bound_project_source_paths",
                "derived_import_cache_is_not_project_source_or_delivery_output",
                "derived_editor_data_is_confined_to_per_run_runtime_scratch",
            ],
        }
        result_path = evidence / "candidate1_focused_qa_execution_receipt.json"
        _write_json(result_path, result_receipt)
        return {
            "run_root": str(run_root),
            "workspace_root": str(workspace),
            "assembly_context_path": str(context_path),
            "project_load_path": str(preparation_path),
            "result_path": str(result_path),
            "qa_bundle_path": str(bundle_path),
            "status": result_receipt["status"],
            "verdict": result.verdict,
            "failed_check_count": result.failed_check_count,
        }
    except Exception as exc:
        support_after_failure: dict[str, Any] | None = None
        support_root_unchanged: bool | None = None
        support_manifest_error: str | None = None
        try:
            support_after_failure = _support_root_manifest(support_root)
            support_root_unchanged = support_after_failure == support_before
        except Exception as manifest_exc:
            support_manifest_error = (
                f"{type(manifest_exc).__name__}:{manifest_exc}"
            )
        boundary_error = support_root_unchanged is False
        recorded_error = (
            Candidate1FocusedQaAssemblyError(
                "focused_qa_changed_read_only_godot_support_root"
            )
            if boundary_error
            else exc
        )
        failure = {
            "schema_version": "1.0.0",
            "artifact_type": "candidate1_focused_qa_failure_receipt",
            "execution_id": execution_id,
            "attempt_id": attempt_id,
            "assembly_sha256": authorization["assembly_sha256"],
            "error_type": type(recorded_error).__name__,
            "message": str(recorded_error),
            "project_load_result_sha256": (
                _sha256_file(preparation_path) if preparation_path.is_file() else None
            ),
            "shared_godot_support_root": {
                "before": support_before,
                "after": support_after_failure,
                "unchanged": support_root_unchanged,
                "manifest_error": support_manifest_error,
            },
            "status": "failed",
            "non_claims": [
                "failure_receipt_is_not_qa_pass_or_human_acceptance",
                "failure_does_not_expand_project_write_or_external_authority",
            ],
        }
        _write_json(evidence / "candidate1_focused_qa_failure_receipt.json", failure)
        if boundary_error:
            raise recorded_error from exc
        raise


__all__ = [
    "ALLOWED_CHECKS",
    "Candidate1FocusedQaAssemblyError",
    "INTEGRITY_PATHS",
    "_materialize_disposable_godot",
    "_support_root_manifest",
    "run_candidate1_focused_qa",
    "verify_focused_qa_authorization",
]
