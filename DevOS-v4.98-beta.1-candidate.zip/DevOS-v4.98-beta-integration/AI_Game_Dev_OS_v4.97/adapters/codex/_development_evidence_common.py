"""Shared bounded helpers for project development Evidence continuity."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
from typing import Any, Mapping, Sequence
import uuid


DEVELOPMENT_PROJECT_EVIDENCE_RELATIVE_PATH = Path(
    ".ai_dev_os/development/evidence"
)
INDEX_RELATIVE_PATH = Path("index/project_evidence_index.json")
SAFE_EVIDENCE_ID = re.compile(r"dev-evidence-[0-9a-f]{24}")
SAFE_KIND = re.compile(r"[a-z][a-z0-9_]{0,63}")
SHA256 = re.compile(r"[0-9a-f]{64}")
MAX_OBJECT_BYTES = 2 * 1024 * 1024
MAX_RECORD_FILES = 500
MAX_TEXT_CHARS = 16_384
MAX_QUERY_CHARS = 500
MAX_RESULTS = 50
VERIFICATION_STATUSES = frozenset({"observed", "verified"})

RECORD_NON_CLAIMS = [
    "registration_is_not_human_acceptance",
    "registration_is_not_memory_promotion",
    "registration_is_not_qualification_gate_or_release_authority",
    "registration_grants_no_production_or_live_authority",
]


def canonical_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        + "\n"
    ).encode("utf-8")


def pretty_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    ).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def normalized_text(
    value: Any, *, field: str, maximum: int = MAX_TEXT_CHARS,
) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"codex_project_evidence_{field}_required")
    normalized = value.strip()
    if len(normalized) > maximum:
        raise ValueError(f"codex_project_evidence_{field}_too_long")
    return normalized


def normalized_evidence_ids(values: Sequence[str]) -> list[str]:
    if isinstance(values, (str, bytes)) or not isinstance(values, Sequence):
        raise ValueError("codex_project_evidence_refs_invalid")
    normalized: list[str] = []
    for value in values:
        evidence_id = normalized_text(
            value, field="evidence_id", maximum=64,
        )
        if SAFE_EVIDENCE_ID.fullmatch(evidence_id) is None:
            raise ValueError("codex_project_evidence_id_invalid")
        if evidence_id not in normalized:
            normalized.append(evidence_id)
    return sorted(normalized)


def is_within(path: Path, root: Path) -> bool:
    return path == root or root in path.parents


def atomic_write(target: Path, value: bytes) -> None:
    temporary = target.parent / f".{target.name}.{uuid.uuid4().hex}.tmp"
    try:
        with temporary.open("xb") as output:
            output.write(value)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def record_shape_issues(
    value: Any, *, expected_evidence_id: str,
) -> list[str]:
    if not isinstance(value, Mapping):
        return ["record_not_object"]
    issues: list[str] = []
    expected_keys = {
        "schema_version", "artifact_type", "evidence_id", "project_id",
        "task_id", "source_revision", "evidence_kind", "title", "summary",
        "recorded_by", "validator_id", "verification_status", "content",
        "authority_status", "non_claims",
    }
    if set(value) != expected_keys:
        issues.append("record_fields_invalid")
    if value.get("schema_version") != "1.0.0":
        issues.append("schema_version_invalid")
    if value.get("artifact_type") != "project_evidence_record":
        issues.append("artifact_type_invalid")
    if value.get("evidence_id") != expected_evidence_id:
        issues.append("evidence_id_mismatch")
    if value.get("verification_status") not in VERIFICATION_STATUSES:
        issues.append("verification_status_invalid")
    if value.get("authority_status") != "not_asserted":
        issues.append("authority_status_invalid")
    for field in (
        "project_id", "task_id", "source_revision", "evidence_kind", "title",
        "summary", "recorded_by",
    ):
        if not isinstance(value.get(field), str) or not value.get(field):
            issues.append(f"{field}_invalid")
    if value.get("verification_status") == "verified" and not isinstance(
        value.get("validator_id"), str,
    ):
        issues.append("verified_validator_missing")
    if value.get("validator_id") is not None and not isinstance(
        value.get("validator_id"), str,
    ):
        issues.append("validator_id_invalid")
    content = value.get("content")
    if not isinstance(content, Mapping):
        issues.append("content_invalid")
    else:
        if set(content) != {
            "sha256", "byte_count", "media_type", "object_ref",
            "source_locator",
        }:
            issues.append("content_fields_invalid")
        content_sha256 = content.get("sha256")
        if not isinstance(content_sha256, str) or SHA256.fullmatch(
            content_sha256,
        ) is None:
            issues.append("content_sha256_invalid")
        if (
            isinstance(content.get("byte_count"), bool)
            or not isinstance(content.get("byte_count"), int)
            or content.get("byte_count", -1) < 0
        ):
            issues.append("content_byte_count_invalid")
        for field in ("media_type", "object_ref", "source_locator"):
            if not isinstance(content.get(field), str) or not content.get(field):
                issues.append(f"content_{field}_invalid")
    if value.get("non_claims") != RECORD_NON_CLAIMS:
        issues.append("non_claims_invalid")
    return issues
