"""Optional Team Memory Provider contract and failure-isolating client."""

from __future__ import annotations

from pathlib import Path
import re
from typing import Any, Mapping, Protocol, Sequence, runtime_checkable

from .development_project_permissions import (
    ProjectPermissionPolicy,
    ProjectPrincipalContext,
)


TEAM_MEMORY_PROVIDER_OPERATIONS = (
    "capabilities",
    "health",
    "activation_status",
    "activate",
    "disable",
    "propose",
    "review",
    "publish",
    "get",
    "search",
    "supersede",
    "invalidate",
    "redact_from_retrieval",
    "export_receipt",
)
SAFE_SCOPE_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,199}")


class TeamMemoryProviderUnavailable(RuntimeError):
    """Provider-specific availability failure; core Production stays usable."""


@runtime_checkable
class TeamMemoryProvider(Protocol):
    """Engine-neutral optional Provider surface used by admitted clients."""

    provider_id: str
    state_root: Path

    def capabilities(self) -> Mapping[str, Any]: ...

    def health(self) -> Mapping[str, Any]: ...

    def activation_status(
        self, project_id: str, team_id: str, *, policy_revision: str | None = None,
    ) -> Mapping[str, Any]: ...

    def activate(
        self,
        project_id: str,
        team_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        recorded_at: str | None = None,
    ) -> Mapping[str, Any]: ...

    def disable(
        self,
        project_id: str,
        team_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        recorded_at: str | None = None,
    ) -> Mapping[str, Any]: ...

    def propose(self, *args: Any, **kwargs: Any) -> Mapping[str, Any]: ...

    def review(self, *args: Any, **kwargs: Any) -> Mapping[str, Any]: ...

    def publish(self, *args: Any, **kwargs: Any) -> Mapping[str, Any]: ...

    def get(self, *args: Any, **kwargs: Any) -> Mapping[str, Any]: ...

    def search(self, *args: Any, **kwargs: Any) -> Mapping[str, Any]: ...

    def supersede(self, *args: Any, **kwargs: Any) -> Mapping[str, Any]: ...

    def invalidate(self, *args: Any, **kwargs: Any) -> Mapping[str, Any]: ...

    def redact_from_retrieval(
        self, *args: Any, **kwargs: Any,
    ) -> Mapping[str, Any]: ...

    def export_receipt(self, *args: Any, **kwargs: Any) -> Mapping[str, Any]: ...


def _scope(value: str, *, field: str) -> str:
    if not isinstance(value, str) or SAFE_SCOPE_ID.fullmatch(value.strip()) is None:
        raise ValueError(f"codex_team_memory_{field}_invalid")
    return value.strip()


class TeamMemoryProviderClient:
    """Bind one project/team to an optional Provider without core coupling."""

    def __init__(
        self,
        provider: TeamMemoryProvider | None,
        *,
        project_root: str | Path,
        project_id: str,
        team_id: str,
    ) -> None:
        self._provider = provider
        self._project_root = Path(project_root).resolve()
        if not self._project_root.is_dir():
            raise ValueError("codex_team_memory_project_root_invalid")
        self._project_id = _scope(project_id, field="project_id")
        self._team_id = _scope(team_id, field="team_id")
        if provider is not None:
            required_entrypoints = (
                "provider_id",
                "state_root",
                "capabilities",
                "health",
                "activation_status",
            )
            if any(
                not hasattr(provider, entrypoint)
                for entrypoint in required_entrypoints
            ):
                raise ValueError("codex_team_memory_provider_contract_invalid")
            state_root = Path(provider.state_root).resolve()
            if state_root == self._project_root or self._project_root in (
                state_root.parents
            ):
                raise ValueError(
                    "codex_team_memory_provider_state_inside_project_rejected"
                )

    @property
    def project_id(self) -> str:
        """Return the exact project scope bound to this read-only client."""
        return self._project_id

    @property
    def team_id(self) -> str:
        """Return the exact team scope bound to this read-only client."""
        return self._team_id

    def capabilities(
        self, *, permission_policy: ProjectPermissionPolicy | None = None,
    ) -> dict[str, Any]:
        if self._provider is None:
            return self._capability_response(
                status="not_installed",
                installed=False,
                enabled=False,
                operations=[],
                provider_id=None,
                issues=[],
            )
        try:
            advertised = self._provider.capabilities()
            operations = advertised.get("operations", [])
            missing = [
                operation
                for operation in TEAM_MEMORY_PROVIDER_OPERATIONS
                if operation not in operations
            ]
            policy_revision = (
                permission_policy.policy_revision
                if permission_policy is not None
                else None
            )
            activation = self._provider.activation_status(
                self._project_id,
                self._team_id,
                policy_revision=policy_revision,
            )
        except TeamMemoryProviderUnavailable as exc:
            return self._capability_response(
                status="degraded",
                installed=True,
                enabled=False,
                operations=[],
                provider_id=getattr(self._provider, "provider_id", None),
                issues=[f"provider_unavailable:{type(exc).__name__}"],
            )
        if missing:
            return self._capability_response(
                status="incompatible",
                installed=True,
                enabled=False,
                operations=list(operations),
                provider_id=advertised.get("provider_id"),
                issues=["provider_operations_missing"],
            )
        enabled = bool(activation.get("enabled"))
        return self._capability_response(
            status="enabled" if enabled else activation.get("status", "disabled"),
            installed=True,
            enabled=enabled,
            operations=list(operations),
            provider_id=advertised.get("provider_id"),
            issues=list(activation.get("issues", [])),
        )

    def _capability_response(
        self,
        *,
        status: str,
        installed: bool,
        enabled: bool,
        operations: Sequence[str],
        provider_id: str | None,
        issues: Sequence[str],
    ) -> dict[str, Any]:
        return {
            "status": status,
            "provider_id": provider_id,
            "installed": installed,
            "enabled_for_scope": enabled,
            "project_id": self._project_id,
            "team_id": self._team_id,
            "operations": list(operations),
            "issues": list(issues),
            "non_claims": [
                "installation_or_activation_does_not_grant_publish_authority",
                "provider_state_grants_no_production_gate_release_or_live_authority",
                "reference_provider_proves_same_host_sharing_only",
            ],
        }

    def health(self) -> dict[str, Any]:
        if self._provider is None:
            return {
                "status": "not_installed",
                "team_memory_available": False,
                "core_project_operations_available": True,
            }
        try:
            health = dict(self._provider.health())
        except TeamMemoryProviderUnavailable as exc:
            return {
                "status": "degraded",
                "team_memory_available": False,
                "core_project_operations_available": True,
                "issues": [f"provider_unavailable:{type(exc).__name__}"],
            }
        health["core_project_operations_available"] = True
        return health

    def admit_requirement(
        self,
        *,
        team_memory_required: bool,
        permission_policy: ProjectPermissionPolicy | None = None,
    ) -> dict[str, Any]:
        if not team_memory_required:
            return {
                "status": "ready",
                "team_memory_required": False,
                "blocks_unrelated_tasks": False,
            }
        capability = self.capabilities(permission_policy=permission_policy)
        return {
            "status": "ready" if capability["enabled_for_scope"] else "blocked",
            "team_memory_required": True,
            "reason": None if capability["enabled_for_scope"] else capability["status"],
            "blocks_unrelated_tasks": False,
        }

    def activate(
        self,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        if self._provider is None:
            return {"status": "not_installed", "enabled_for_scope": False}
        try:
            return dict(
                self._provider.activate(
                    self._project_id,
                    self._team_id,
                    actor_context=actor_context,
                    permission_policy=permission_policy,
                    recorded_at=recorded_at,
                )
            )
        except TeamMemoryProviderUnavailable as exc:
            return self._degraded(exc)

    def disable(
        self,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        if self._provider is None:
            return {"status": "not_installed", "enabled_for_scope": False}
        try:
            return dict(
                self._provider.disable(
                    self._project_id,
                    self._team_id,
                    actor_context=actor_context,
                    permission_policy=permission_policy,
                    recorded_at=recorded_at,
                )
            )
        except TeamMemoryProviderUnavailable as exc:
            return self._degraded(exc)

    def _disabled_or_missing(
        self, permission_policy: ProjectPermissionPolicy,
    ) -> dict[str, Any] | None:
        if self._provider is None:
            return {"status": "not_installed", "team_memory_available": False}
        try:
            activation = self._provider.activation_status(
                self._project_id,
                self._team_id,
                policy_revision=permission_policy.policy_revision,
            )
        except TeamMemoryProviderUnavailable as exc:
            return {
                "status": "degraded",
                "team_memory_available": False,
                "core_project_operations_available": True,
                "issues": [f"provider_unavailable:{type(exc).__name__}"],
            }
        if not activation.get("enabled"):
            return {
                "status": activation.get("status", "disabled"),
                "team_memory_available": False,
                "issues": list(activation.get("issues", [])),
            }
        return None

    def propose(
        self,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        memory_key: str,
        title: str,
        content: str,
        source_evidence_ids: Sequence[str],
        tags: Sequence[str] = (),
        lesson_class: str | None = None,
        lesson_review_state: str | None = None,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        unavailable = self._disabled_or_missing(permission_policy)
        if unavailable is not None:
            return unavailable
        try:
            optional_lesson: dict[str, Any] = {}
            if lesson_class is not None or lesson_review_state is not None:
                optional_lesson = {
                    "lesson_class": lesson_class,
                    "lesson_review_state": lesson_review_state,
                }
            return dict(
                self._provider.propose(
                    self._project_root,
                    self._project_id,
                    self._team_id,
                    actor_context=actor_context,
                    permission_policy=permission_policy,
                    memory_key=memory_key,
                    title=title,
                    content=content,
                    source_evidence_ids=source_evidence_ids,
                    tags=tags,
                    recorded_at=recorded_at,
                    **optional_lesson,
                )
            )
        except TeamMemoryProviderUnavailable as exc:
            return self._degraded(exc)

    def review(self, memory_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._write_operation("review", memory_id, **kwargs)

    def publish(self, memory_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._write_operation("publish", memory_id, **kwargs)

    def supersede(self, memory_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._write_operation("supersede", memory_id, **kwargs)

    def invalidate(self, memory_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._write_operation("invalidate", memory_id, **kwargs)

    def redact_from_retrieval(
        self, memory_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        return self._write_operation(
            "redact_from_retrieval", memory_id, **kwargs
        )

    def _write_operation(
        self, operation: str, memory_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        policy = kwargs.get("permission_policy")
        if not isinstance(policy, ProjectPermissionPolicy):
            raise ValueError("codex_team_memory_permission_policy_required")
        unavailable = self._disabled_or_missing(policy)
        if unavailable is not None:
            return unavailable
        try:
            method = getattr(self._provider, operation)
            return dict(
                method(
                    self._project_root,
                    self._project_id,
                    self._team_id,
                    memory_id,
                    **kwargs,
                )
            )
        except TeamMemoryProviderUnavailable as exc:
            return self._degraded(exc)

    def get(
        self,
        memory_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
    ) -> dict[str, Any]:
        unavailable = self._disabled_or_missing(permission_policy)
        if unavailable is not None:
            return {**unavailable, "memory": None}
        try:
            return dict(
                self._provider.get(
                    self._project_root,
                    self._project_id,
                    self._team_id,
                    memory_id,
                    actor_context=actor_context,
                    permission_policy=permission_policy,
                )
            )
        except TeamMemoryProviderUnavailable as exc:
            return {**self._degraded(exc), "memory": None}

    def search(
        self,
        query: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        limit: int = 10,
    ) -> dict[str, Any]:
        unavailable = self._disabled_or_missing(permission_policy)
        if unavailable is not None:
            return {**unavailable, "results": [], "result_count": 0}
        try:
            return dict(
                self._provider.search(
                    self._project_root,
                    self._project_id,
                    self._team_id,
                    query,
                    actor_context=actor_context,
                    permission_policy=permission_policy,
                    limit=limit,
                )
            )
        except TeamMemoryProviderUnavailable as exc:
            return {
                **self._degraded(exc),
                "results": [],
                "result_count": 0,
            }

    def export_receipt(
        self,
        memory_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
    ) -> dict[str, Any]:
        return self._write_operation(
            "export_receipt",
            memory_id,
            actor_context=actor_context,
            permission_policy=permission_policy,
        )

    @staticmethod
    def _degraded(error: BaseException) -> dict[str, Any]:
        return {
            "status": "degraded",
            "team_memory_available": False,
            "core_project_operations_available": True,
            "issues": [f"provider_unavailable:{type(error).__name__}"],
        }
