"""Production-Worker backend for one real write-capable Godot lane."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from .godot_lane_check import (
    GodotLaneCheck,
    WorkspaceWorker,
    compact_command_result,
)
from .godot_lane_receipts import verify_development_delivery
from .multi_lane_coordinator import (
    LaneBackendOutcome,
    LaneExecutionContext,
)
from .multi_lane_workspace import (
    WorkspaceIdentityError,
    absolute_existing_path,
    observe_git_workspace,
    required_text,
)


class GodotWorkspaceLaneBackend:
    """Validate one real write-capable workspace through a bounded Worker."""

    backend_id = "codex_godot_workspace_lane_backend_v1"

    def __init__(
        self,
        *,
        lane_id: str,
        capabilities: Sequence[str],
        worker: WorkspaceWorker,
        expected_branch: str,
        expected_output_revision: str,
        result_artifact_type: str,
        checks: Sequence[GodotLaneCheck],
        common_identities: Mapping[str, Any],
        development_delivery_receipt: str | Path | None = None,
    ) -> None:
        self.lane_id = required_text(lane_id, "lane_id")
        self.capabilities = tuple(
            required_text(value, "capability") for value in capabilities
        )
        if not self.capabilities or len(set(self.capabilities)) != len(
            self.capabilities
        ):
            raise WorkspaceIdentityError(
                "backend capabilities must be unique and non-empty"
            )
        self.worker = worker
        self.expected_branch = required_text(expected_branch, "expected_branch")
        self.expected_output_revision = required_text(
            expected_output_revision,
            "expected_output_revision",
        )
        self.result_artifact_type = required_text(
            result_artifact_type,
            "result_artifact_type",
        )
        self.checks = tuple(checks)
        if not all(isinstance(check, GodotLaneCheck) for check in self.checks):
            raise WorkspaceIdentityError(
                "checks must contain GodotLaneCheck values"
            )
        validator_ids = [check.validator_id for check in self.checks]
        if len(set(validator_ids)) != len(validator_ids):
            raise WorkspaceIdentityError("check validator IDs must be unique")
        self.common_identities = json.loads(
            json.dumps(dict(common_identities), ensure_ascii=False, sort_keys=True)
        )
        self.development_delivery_receipt = (
            None
            if development_delivery_receipt is None
            else absolute_existing_path(
                development_delivery_receipt,
                "development_delivery_receipt",
            )
        )

    def _failed(
        self,
        context: LaneExecutionContext,
        *,
        failure_kind: str,
        facts: Mapping[str, Any],
        observed_write_paths: Sequence[str] = (),
    ) -> LaneBackendOutcome:
        return LaneBackendOutcome(
            state="failed",
            input_source_revision=context.plan.expected_source_revision,
            output_revision=None,
            result_artifact_type=None,
            facts=dict(facts),
            observed_write_paths=tuple(observed_write_paths),
            failure_kind=failure_kind,
            failure_owner=context.lane.primary_principal_id,
            next_action=(
                "correct_the_bounded_lane_and_use_a_new_attempt_identity"
            ),
        )

    def run(self, context: LaneExecutionContext) -> LaneBackendOutcome:
        if context.lane.lane_id != self.lane_id:
            raise WorkspaceIdentityError("backend received the wrong lane context")
        if context.attempt_id != self.worker.attempt_id:
            return self._failed(
                context,
                failure_kind="lane_attempt_identity_mismatch",
                facts={
                    "context_attempt_id": context.attempt_id,
                    "worker_attempt_id": self.worker.attempt_id,
                },
            )
        try:
            before = observe_git_workspace(
                self.worker.project_root,
                base_revision=context.plan.expected_source_revision,
            )
        except WorkspaceIdentityError as exc:
            return self._failed(
                context,
                failure_kind="workspace_observation_failed",
                facts={"message": str(exc)},
            )
        identity_failures: list[str] = []
        if not before.isolated_workspace:
            identity_failures.append("workspace_root_is_not_repository_root")
        if not before.clean:
            identity_failures.append("workspace_is_dirty")
        if not before.base_is_ancestor:
            identity_failures.append("planned_source_is_not_an_ancestor")
        if before.branch != self.expected_branch:
            identity_failures.append("branch_mismatch")
        if before.head != self.expected_output_revision:
            identity_failures.append("output_revision_mismatch")
        if before.diff_check_status != "pass":
            identity_failures.append("git_diff_check_failed")
        if identity_failures:
            return self._failed(
                context,
                failure_kind="workspace_source_identity_mismatch",
                facts={
                    "identity_failures": identity_failures,
                    "workspace": before.to_dict(),
                },
                observed_write_paths=before.observed_write_paths,
            )

        preflight = self.worker.preflight()
        validator_results: dict[str, dict[str, Any]] = {
            "git_diff_check": {"status": "pass"},
        }
        if preflight.get("status") != "ready":
            return self._failed(
                context,
                failure_kind="worker_preflight_failed",
                facts={"worker_preflight": preflight},
                observed_write_paths=before.observed_write_paths,
            )
        validator_results["project_load"] = {"status": "pass"}
        if context.dependency_results and all(
            result.state == "accepted" for result in context.dependency_results
        ):
            validator_results["maker_commit_identity"] = {
                "status": "pass",
                "dependency_output_revisions": [
                    result.output_revision for result in context.dependency_results
                ],
            }

        evidence_refs: list[str] = []
        for check in self.checks:
            result = self.worker.run_script(
                check.script_path,
                expected_pass_token=check.pass_token,
            )
            compact = compact_command_result(result)
            validator_results[check.validator_id] = compact
            if compact.get("run_id"):
                evidence_refs.append(f"godot-run://{compact['run_id']}")
            if (
                compact.get("status") != "pass"
                or compact.get("pass_token_observed") is not True
            ):
                return self._failed(
                    context,
                    failure_kind="focused_validator_failed",
                    facts={
                        "failed_validator_id": check.validator_id,
                        "validator_results": validator_results,
                    },
                    observed_write_paths=before.observed_write_paths,
                )

        build_identity: dict[str, Any] | None = None
        if self.development_delivery_receipt is not None:
            try:
                build_identity = verify_development_delivery(
                    self.development_delivery_receipt,
                    expected_source_revision=before.head,
                )
            except WorkspaceIdentityError as exc:
                return self._failed(
                    context,
                    failure_kind="development_delivery_receipt_failed",
                    facts={"message": str(exc)},
                    observed_write_paths=before.observed_write_paths,
                )
            validator_results["development_build"] = {"status": "pass"}
            evidence_refs.append(str(self.development_delivery_receipt))

        missing_validators = sorted(
            set(context.lane.required_validators) - set(validator_results)
        )
        failed_validators = sorted(
            validator_id
            for validator_id in context.lane.required_validators
            if validator_results.get(validator_id, {}).get("status") != "pass"
        )
        if missing_validators or failed_validators:
            return self._failed(
                context,
                failure_kind="required_validator_not_passed",
                facts={
                    "missing_validators": missing_validators,
                    "failed_validators": failed_validators,
                    "validator_results": validator_results,
                },
                observed_write_paths=before.observed_write_paths,
            )

        after = observe_git_workspace(
            self.worker.project_root,
            base_revision=context.plan.expected_source_revision,
        )
        if (
            not after.clean
            or after.head != before.head
            or after.tree != before.tree
            or after.observed_write_paths != before.observed_write_paths
        ):
            return self._failed(
                context,
                failure_kind="validation_changed_project_source",
                facts={"before": before.to_dict(), "after": after.to_dict()},
                observed_write_paths=after.observed_write_paths,
            )

        godot_preflight = preflight.get("godot_preflight", {})
        artifact_identities: dict[str, Any] = {
            **self.common_identities,
            "workspace_source": before.to_dict(),
            "worker_binding": {
                "actor_id": preflight.get("actor_id"),
                "agent_id": preflight.get("agent_id"),
                "skill_id": preflight.get("skill_id"),
                "binding_id": preflight.get("binding_id"),
                "engine_identity": godot_preflight.get(
                    "godot_binary_identity"
                ),
            },
        }
        if build_identity is not None:
            artifact_identities["development_build"] = build_identity
        return LaneBackendOutcome(
            state="accepted",
            input_source_revision=context.plan.expected_source_revision,
            output_revision=before.head,
            result_artifact_type=self.result_artifact_type,
            facts={
                "validator_results": validator_results,
                "source_unchanged_by_validation": True,
                "observed_write_count": len(before.observed_write_paths),
                "dependency_output_revisions": [
                    result.output_revision for result in context.dependency_results
                ],
            },
            observed_write_paths=before.observed_write_paths,
            artifact_identities=artifact_identities,
            evidence_refs=tuple(evidence_refs),
        )
