"""Append-only effective lifecycle for immutable project Memory records."""

from __future__ import annotations

import fcntl
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from ._development_evidence_common import (
    SAFE_EVIDENCE_ID,
    canonical_bytes,
    normalized_evidence_ids,
    sha256_bytes,
)
from .development_project_permissions import (
    ProjectPermissionPolicy,
    ProjectPrincipalContext,
)


MEMORY_LIFECYCLE_ACTIONS = frozenset(
    {
        "candidate",
        "publish",
        "supersede",
        "deprecate",
        "invalidate",
        "redact_from_retrieval",
        "recover",
    }
)
ACTION_CAPABILITY = {
    "candidate": "project_memory_propose",
    "publish": "project_memory_publish",
    "supersede": "project_memory_supersede",
    "deprecate": "project_memory_deprecate",
    "invalidate": "project_memory_invalidate",
    "redact_from_retrieval": "project_memory_redact",
    "recover": "project_memory_recover",
}
MEMORY_LIFECYCLE_RECEIPTS_RELATIVE_PATH = Path("lifecycle/receipts")
MAX_MEMORY_RECORDS = 200
MAX_MEMORY_LIFECYCLE_RECEIPTS = 800
SAFE_MEMORY_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,199}")
SAFE_MEMORY_KEY = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}")
SAFE_RECEIPT_ID = re.compile(r"memory-lifecycle-[0-9a-f]{24}")
NON_CLAIMS = (
    "memory_lifecycle_receipt_does_not_rewrite_source_memory_or_evidence",
    "memory_lifecycle_receipt_is_not_human_acceptance_or_gate_authority",
    "memory_lifecycle_receipt_grants_no_release_production_or_live_authority",
)


def _text(value: Any, *, field: str, maximum: int = 4_000) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"codex_project_memory_lifecycle_{field}_required")
    normalized = value.strip()
    if len(normalized) > maximum:
        raise ValueError(f"codex_project_memory_lifecycle_{field}_too_long")
    return normalized


def _timestamp(value: str, *, field: str) -> tuple[str, datetime]:
    normalized = _text(value, field=field, maximum=100)
    try:
        parsed = datetime.fromisoformat(normalized.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(
            f"codex_project_memory_lifecycle_{field}_invalid"
        ) from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(
            f"codex_project_memory_lifecycle_{field}_timezone_required"
        )
    utc = parsed.astimezone(timezone.utc)
    return utc.isoformat(), utc


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _digest(value: Mapping[str, Any]) -> str:
    body = {
        key: item
        for key, item in value.items()
        if key not in {"receipt_id", "content_sha256"}
    }
    return sha256_bytes(canonical_bytes(body))


class DevelopmentProjectMemoryLifecycleStore:
    """Resolve current Memory heads without mutating v4.95/v4.96 records."""

    def __init__(self, memory_store: Any) -> None:
        required = ("_project_root", "_project_id", "_root", "_validate_root")
        if any(not hasattr(memory_store, field) for field in required):
            raise ValueError("codex_project_memory_lifecycle_store_invalid")
        self._memory_store = memory_store
        self._project_root = memory_store._project_root
        self._project_id = memory_store._project_id

    def _receipts_directory(self, *, create: bool) -> Path | None:
        if not self._memory_store._validate_root(create=create):
            return None
        cursor = self._memory_store._root
        for part in MEMORY_LIFECYCLE_RECEIPTS_RELATIVE_PATH.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                raise ValueError(
                    "codex_project_memory_lifecycle_storage_symlink_rejected"
                )
        if not cursor.exists():
            if not create:
                return None
            cursor.mkdir(parents=True, exist_ok=True)
        if not cursor.is_dir():
            raise ValueError(
                "codex_project_memory_lifecycle_storage_not_directory"
            )
        return cursor

    def _exact_memory(self, memory_id: str) -> dict[str, Any]:
        exact = self._memory_store.get(memory_id)
        if exact["status"] != "ok":
            raise ValueError(
                f"codex_project_memory_lifecycle_target_invalid:{memory_id}"
            )
        return exact["memory"]

    @staticmethod
    def _evidence_refs(memory: Mapping[str, Any]) -> tuple[str, ...]:
        source = memory.get("source")
        refs = source.get("evidence_refs") if isinstance(source, Mapping) else None
        if (
            memory.get("format_version") != 2
            or not isinstance(refs, list)
            or not refs
            or any(
                not isinstance(item, str)
                or SAFE_EVIDENCE_ID.fullmatch(item) is None
                for item in refs
            )
        ):
            raise ValueError(
                "codex_project_memory_lifecycle_evidence_link_required"
            )
        return tuple(sorted(dict.fromkeys(refs)))

    def append_action(
        self,
        target_memory_id: str,
        *,
        action: str,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        expected_prior_lifecycle_revision: int,
        reason_code: str,
        reason: str,
        source_evidence_refs: Sequence[str],
        memory_key: str | None = None,
        successor_memory_id: str | None = None,
        conflicts_with: Sequence[str] = (),
        recovers_receipt_id: str | None = None,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        target = _text(target_memory_id, field="target_memory_id", maximum=200)
        if SAFE_MEMORY_ID.fullmatch(target) is None:
            raise ValueError("codex_project_memory_lifecycle_target_id_invalid")
        selected_action = _text(action, field="action", maximum=64)
        if selected_action not in MEMORY_LIFECYCLE_ACTIONS:
            raise ValueError("codex_project_memory_lifecycle_action_invalid")
        if not isinstance(actor_context, ProjectPrincipalContext) or not isinstance(
            permission_policy, ProjectPermissionPolicy
        ):
            raise ValueError("codex_project_memory_lifecycle_permission_invalid")
        if (
            actor_context.project_id != self._project_id
            or permission_policy.project_id != self._project_id
        ):
            raise PermissionError("codex_project_permission_denied")
        required_capability = ACTION_CAPABILITY[selected_action]
        grant = permission_policy.require(actor_context, required_capability)
        if (
            isinstance(expected_prior_lifecycle_revision, bool)
            or not isinstance(expected_prior_lifecycle_revision, int)
            or expected_prior_lifecycle_revision < 0
        ):
            raise ValueError(
                "codex_project_memory_lifecycle_expected_revision_invalid"
            )
        code = _text(reason_code, field="reason_code", maximum=100)
        explanation = _text(reason, field="reason")
        recorded, _ = _timestamp(recorded_at or _now(), field="recorded_at")

        target_memory = self._exact_memory(target)
        target_refs = self._evidence_refs(target_memory)
        supplied_refs = tuple(normalized_evidence_ids(source_evidence_refs))
        if not supplied_refs or not set(target_refs).issubset(supplied_refs):
            raise ValueError(
                "codex_project_memory_lifecycle_source_evidence_mismatch"
            )
        successor = self._normalized_optional_memory_id(
            successor_memory_id, field="successor_memory_id"
        )
        conflicts = self._normalized_memory_ids(conflicts_with)
        if target in conflicts:
            raise ValueError("codex_project_memory_lifecycle_self_conflict")
        recovers = None
        if recovers_receipt_id is not None:
            recovers = _text(
                recovers_receipt_id, field="recovers_receipt_id", maximum=100
            )
            if SAFE_RECEIPT_ID.fullmatch(recovers) is None:
                raise ValueError(
                    "codex_project_memory_lifecycle_recovery_receipt_id_invalid"
                )
        self._validate_action_shape(
            selected_action,
            successor=successor,
            conflicts=conflicts,
            recovers=recovers,
        )
        related_ids = list(conflicts)
        if successor is not None:
            related_ids.append(successor)
        for memory_id in related_ids:
            related = self._exact_memory(memory_id)
            supplied_required = self._evidence_refs(related)
            if not set(supplied_required).issubset(supplied_refs):
                raise ValueError(
                    "codex_project_memory_lifecycle_source_evidence_mismatch"
                )
        self._verify_source_evidence(
            supplied_refs,
            require_current=selected_action in {"candidate", "publish"},
        )

        receipts_dir = self._receipts_directory(create=True)
        assert receipts_dir is not None
        lock_path = receipts_dir.parent / ".lifecycle.lock"
        if lock_path.is_symlink():
            raise ValueError(
                "codex_project_memory_lifecycle_lock_symlink_rejected"
            )
        with lock_path.open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            receipts, receipt_issues = self._valid_receipts_for_target(target)
            if receipt_issues:
                raise ValueError(
                    "codex_project_memory_lifecycle_target_review_needed"
                )
            latest_revision = (
                receipts[-1]["resulting_lifecycle_revision"] if receipts else 0
            )
            if latest_revision != expected_prior_lifecycle_revision:
                raise ValueError(
                    "codex_project_memory_lifecycle_stale_expected_revision"
                )
            if receipts:
                _, last_time = _timestamp(
                    receipts[-1]["recorded_at"], field="recorded_at"
                )
                _, next_time = _timestamp(recorded, field="recorded_at")
                if next_time < last_time:
                    raise ValueError(
                        "codex_project_memory_lifecycle_recorded_at_regression"
                    )
            current = self._derive_view(
                target,
                target_memory,
                receipts,
                record_sha256=None,
                as_of=recorded,
                issues=[],
            )
            if current["status"] != "ok":
                raise ValueError(
                    "codex_project_memory_lifecycle_target_review_needed"
                )
            selected_key = self._selected_memory_key(
                memory_key,
                current=current,
                action=selected_action,
                has_receipts=bool(receipts),
            )
            self._validate_transition(
                selected_action,
                current=current,
                receipts=receipts,
                recovers=recovers,
            )
            if successor is not None:
                all_views = self.resolve_all(as_of=recorded)["views"]
                successor_view = all_views.get(successor)
                if (
                    successor_view is None
                    or successor_view.get("memory_key") != selected_key
                    or not successor_view.get("source_evidence_eligible")
                    or successor_view.get("effective_state") != "published"
                ):
                    raise ValueError(
                        "codex_project_memory_lifecycle_successor_key_mismatch"
                    )

            resulting_revision = expected_prior_lifecycle_revision + 1
            body: dict[str, Any] = {
                "schema_version": "1.0.0",
                "artifact_type": "project_memory_lifecycle_receipt",
                "project_id": self._project_id,
                "target_memory_id": target,
                "memory_key": selected_key,
                "action": selected_action,
                "actor_id": actor_context.principal_id,
                "principal_kind": actor_context.principal_kind,
                "team_scope": actor_context.team_id,
                "actor_roles": list(grant.roles),
                "required_capability": required_capability,
                "permission_policy_revision": permission_policy.policy_revision,
                "expected_prior_lifecycle_revision": (
                    expected_prior_lifecycle_revision
                ),
                "resulting_lifecycle_revision": resulting_revision,
                "reason_code": code,
                "reason": explanation,
                "source_evidence_refs": list(supplied_refs),
                "successor_memory_id": successor,
                "conflicts_with": list(conflicts),
                "recovers_receipt_id": recovers,
                "resulting_effective_state": "pending_derivation",
                "recorded_at": recorded,
                "non_claims": list(NON_CLAIMS),
            }
            pending = {
                **body,
                "receipt_id": "memory-lifecycle-pending",
                "content_sha256": "0" * 64,
            }
            predicted = self._derive_view(
                target,
                target_memory,
                [*receipts, pending],
                record_sha256=None,
                as_of=recorded,
                issues=[],
            )
            body["resulting_effective_state"] = predicted["effective_state"]
            digest = _digest(body)
            receipt_id = f"memory-lifecycle-{digest[:24]}"
            receipt = {
                **body,
                "receipt_id": receipt_id,
                "content_sha256": digest,
            }
            target_path = receipts_dir / (
                f"{target}.{resulting_revision:08d}.{receipt_id}.json"
            )
            serialized = (
                json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True)
                + "\n"
            ).encode("utf-8")
            try:
                with target_path.open("xb") as output:
                    output.write(serialized)
                    output.flush()
                    os.fsync(output.fileno())
            except FileExistsError as exc:
                raise ValueError(
                    "codex_project_memory_lifecycle_receipt_conflict"
                ) from exc
        return {
            "status": "recorded",
            "receipt": receipt,
            "receipt_ref": target_path.relative_to(self._project_root).as_posix(),
            "effective_view": self.resolve(target, as_of=recorded),
        }

    @staticmethod
    def _validate_action_shape(
        action: str,
        *,
        successor: str | None,
        conflicts: Sequence[str],
        recovers: str | None,
    ) -> None:
        if (action == "supersede") != (successor is not None):
            raise ValueError(
                "codex_project_memory_lifecycle_successor_shape_invalid"
            )
        if conflicts and action not in {"candidate", "publish"}:
            raise ValueError(
                "codex_project_memory_lifecycle_conflicts_not_applicable"
            )
        if (action == "recover") != (recovers is not None):
            raise ValueError(
                "codex_project_memory_lifecycle_recover_shape_invalid"
            )

    @staticmethod
    def _validate_transition(
        action: str,
        *,
        current: Mapping[str, Any],
        receipts: Sequence[Mapping[str, Any]],
        recovers: str | None,
    ) -> None:
        if action != "recover" and current["effective_state"] in {
            "superseded",
            "deprecated",
            "invalidated",
            "retrieval_redacted",
        }:
            raise ValueError(
                "codex_project_memory_lifecycle_recovery_required"
            )
        if action == "candidate" and current["effective_state"] == "candidate":
            raise ValueError(
                "codex_project_memory_lifecycle_already_candidate"
            )
        if action == "publish" and current["effective_state"] not in {
            "candidate",
            "published",
        }:
            raise ValueError(
                "codex_project_memory_lifecycle_publish_state_invalid"
            )
        if action != "recover":
            return
        receipts_by_id = {
            item["receipt_id"]: item for item in receipts
        }
        recovered = {
            item["recovers_receipt_id"]
            for item in receipts
            if item["action"] == "recover"
        }
        referenced = receipts_by_id.get(recovers)
        if (
            referenced is None
            or referenced["action"] == "recover"
            or recovers in recovered
        ):
            raise ValueError(
                "codex_project_memory_lifecycle_recovery_target_invalid"
            )

    @staticmethod
    def _normalized_optional_memory_id(
        value: str | None, *, field: str,
    ) -> str | None:
        if value is None:
            return None
        normalized = _text(value, field=field, maximum=200)
        if SAFE_MEMORY_ID.fullmatch(normalized) is None:
            raise ValueError(f"codex_project_memory_lifecycle_{field}_invalid")
        return normalized

    @classmethod
    def _normalized_memory_ids(
        cls, values: Sequence[str],
    ) -> tuple[str, ...]:
        if isinstance(values, (str, bytes)) or not isinstance(values, Sequence):
            raise ValueError(
                "codex_project_memory_lifecycle_conflicts_with_invalid"
            )
        normalized: list[str] = []
        for value in values:
            item = cls._normalized_optional_memory_id(
                value, field="conflict_memory_id"
            )
            if item is None:
                raise ValueError(
                    "codex_project_memory_lifecycle_conflict_memory_id_invalid"
                )
            if item not in normalized:
                normalized.append(item)
        return tuple(sorted(normalized))

    @staticmethod
    def _selected_memory_key(
        value: str | None,
        *,
        current: Mapping[str, Any],
        action: str,
        has_receipts: bool,
    ) -> str:
        if value is None:
            return current["memory_key"]
        selected = _text(value, field="memory_key", maximum=200)
        if SAFE_MEMORY_KEY.fullmatch(selected) is None:
            raise ValueError("codex_project_memory_lifecycle_memory_key_invalid")
        if action not in {"candidate", "publish"} and selected != current[
            "memory_key"
        ]:
            raise ValueError(
                "codex_project_memory_lifecycle_memory_key_change_invalid"
            )
        if has_receipts and selected != current["memory_key"]:
            raise ValueError(
                "codex_project_memory_lifecycle_memory_key_change_invalid"
            )
        return selected

    def _verify_source_evidence(
        self, refs: Sequence[str], *, require_current: bool,
    ) -> None:
        from .development_project_evidence import (
            DevelopmentProjectEvidenceStore,
        )

        evidence_store = DevelopmentProjectEvidenceStore(
            self._project_root, project_id=self._project_id
        )
        lifecycle = evidence_store.lifecycle_store()
        for evidence_id in refs:
            exact = evidence_store.verify(evidence_id)
            if exact["status"] != "ok" or exact["evidence"][
                "verification_status"
            ] != "verified":
                raise ValueError(
                    "codex_project_memory_lifecycle_source_evidence_invalid:"
                    f"{evidence_id}"
                )
            if require_current:
                effective = lifecycle.resolve(evidence_id)
                if (
                    effective["status"] != "ok"
                    or not effective["retrieval_eligible"]
                ):
                    raise ValueError(
                        "codex_project_memory_lifecycle_source_evidence_ineligible:"
                        f"{evidence_id}"
                    )

    def _receipt_paths(self) -> tuple[list[Path], bool]:
        directory = self._receipts_directory(create=False)
        if directory is None:
            return [], False
        paths = sorted(directory.glob("*.json"))
        return paths[:MAX_MEMORY_LIFECYCLE_RECEIPTS], (
            len(paths) > MAX_MEMORY_LIFECYCLE_RECEIPTS
        )

    def inventory_sha256(self) -> str:
        paths, truncated = self._receipt_paths()
        rows = []
        for path in paths:
            try:
                raw = path.read_bytes()
            except OSError:
                raw = b""
            rows.append({"filename": path.name, "sha256": sha256_bytes(raw)})
        return sha256_bytes(
            canonical_bytes({"rows": rows, "truncated": truncated})
        )

    def _valid_receipts_for_target(
        self, memory_id: str,
    ) -> tuple[list[dict[str, Any]], list[str]]:
        paths, truncated = self._receipt_paths()
        matching = [
            path for path in paths if path.name.startswith(f"{memory_id}.")
        ]
        issues = ["lifecycle_receipt_scan_truncated"] if truncated else []
        candidates: list[dict[str, Any]] = []
        for path in matching:
            if path.is_symlink():
                issues.append(f"receipt_symlink_rejected:{path.name}")
                continue
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, UnicodeError, json.JSONDecodeError):
                issues.append(f"receipt_unreadable:{path.name}")
                continue
            shape_issues = self._receipt_shape_issues(
                value, expected_memory_id=memory_id
            )
            if shape_issues:
                issues.extend(f"{item}:{path.name}" for item in shape_issues)
                continue
            candidates.append(dict(value))
        candidates.sort(
            key=lambda item: (
                item["resulting_lifecycle_revision"], item["receipt_id"]
            )
        )
        accepted: list[dict[str, Any]] = []
        revision = 0
        seen: set[str] = set()
        for receipt in candidates:
            if receipt["receipt_id"] in seen:
                issues.append(f"duplicate_receipt_id:{receipt['receipt_id']}")
                continue
            if (
                receipt["expected_prior_lifecycle_revision"] != revision
                or receipt["resulting_lifecycle_revision"] != revision + 1
            ):
                issues.append(
                    f"stale_or_noncontiguous_revision:{receipt['receipt_id']}"
                )
                continue
            accepted.append(receipt)
            seen.add(receipt["receipt_id"])
            revision += 1
        return accepted, list(dict.fromkeys(issues))

    def _receipt_shape_issues(
        self, value: Any, *, expected_memory_id: str,
    ) -> list[str]:
        required = {
            "schema_version",
            "artifact_type",
            "receipt_id",
            "project_id",
            "target_memory_id",
            "memory_key",
            "action",
            "actor_id",
            "principal_kind",
            "team_scope",
            "actor_roles",
            "required_capability",
            "permission_policy_revision",
            "expected_prior_lifecycle_revision",
            "resulting_lifecycle_revision",
            "reason_code",
            "reason",
            "source_evidence_refs",
            "successor_memory_id",
            "conflicts_with",
            "recovers_receipt_id",
            "resulting_effective_state",
            "recorded_at",
            "content_sha256",
            "non_claims",
        }
        if not isinstance(value, Mapping):
            return ["receipt_not_object"]
        issues: list[str] = []
        if set(value) != required:
            issues.append("receipt_fields_invalid")
        if value.get("schema_version") != "1.0.0":
            issues.append("schema_version_invalid")
        if value.get("artifact_type") != "project_memory_lifecycle_receipt":
            issues.append("artifact_type_invalid")
        if value.get("project_id") != self._project_id:
            issues.append("project_id_mismatch")
        if value.get("target_memory_id") != expected_memory_id:
            issues.append("target_memory_id_mismatch")
        receipt_id = value.get("receipt_id")
        if not isinstance(receipt_id, str) or SAFE_RECEIPT_ID.fullmatch(
            receipt_id
        ) is None:
            issues.append("receipt_id_invalid")
        if value.get("action") not in MEMORY_LIFECYCLE_ACTIONS:
            issues.append("action_invalid")
        action = value.get("action")
        key = value.get("memory_key")
        if not isinstance(key, str) or SAFE_MEMORY_KEY.fullmatch(key) is None:
            issues.append("memory_key_invalid")
        if value.get("non_claims") != list(NON_CLAIMS):
            issues.append("non_claims_invalid")
        if value.get("principal_kind") not in {
            "project", "team", "user", "agent", "skill", "pack", "tool"
        }:
            issues.append("principal_kind_invalid")
        if value.get("required_capability") != ACTION_CAPABILITY.get(action):
            issues.append("required_capability_mismatch")
        team_scope = value.get("team_scope")
        if team_scope is not None and (
            not isinstance(team_scope, str) or not team_scope
        ):
            issues.append("team_scope_invalid")
        for field in (
            "actor_id",
            "principal_kind",
            "required_capability",
            "permission_policy_revision",
            "reason_code",
            "reason",
            "resulting_effective_state",
            "recorded_at",
        ):
            if not isinstance(value.get(field), str) or not value.get(field):
                issues.append(f"{field}_invalid")
        for field in (
            "source_evidence_refs", "conflicts_with", "actor_roles"
        ):
            if not isinstance(value.get(field), list):
                issues.append(f"{field}_invalid")
        source_refs = value.get("source_evidence_refs")
        if isinstance(source_refs, list):
            valid_source_refs = bool(source_refs) and all(
                isinstance(item, str)
                and SAFE_EVIDENCE_ID.fullmatch(item) is not None
                for item in source_refs
            )
            if (
                not valid_source_refs
                or len(source_refs) != len(set(source_refs))
            ):
                issues.append("source_evidence_refs_invalid")
        conflicts = value.get("conflicts_with")
        if isinstance(conflicts, list):
            valid_conflicts = all(
                isinstance(item, str)
                and SAFE_MEMORY_ID.fullmatch(item) is not None
                for item in conflicts
            )
            if (
                not valid_conflicts
                or len(conflicts) != len(set(conflicts))
                or expected_memory_id in conflicts
            ):
                issues.append("conflicts_with_invalid")
        if conflicts and action not in {"candidate", "publish"}:
            issues.append("conflicts_with_not_applicable")
        roles = value.get("actor_roles")
        if isinstance(roles, list):
            valid_roles = all(
                isinstance(item, str) and bool(item) for item in roles
            )
            if not valid_roles or len(roles) != len(set(roles)):
                issues.append("actor_roles_invalid")
        successor = value.get("successor_memory_id")
        if action == "supersede":
            if (
                not isinstance(successor, str)
                or SAFE_MEMORY_ID.fullmatch(successor) is None
                or successor == expected_memory_id
            ):
                issues.append("successor_memory_id_invalid")
        elif successor is not None:
            issues.append("successor_memory_id_not_applicable")
        recovers = value.get("recovers_receipt_id")
        if action == "recover":
            if not isinstance(recovers, str) or SAFE_RECEIPT_ID.fullmatch(
                recovers
            ) is None:
                issues.append("recovers_receipt_id_invalid")
        elif recovers is not None:
            issues.append("recovers_receipt_id_not_applicable")
        for field in (
            "expected_prior_lifecycle_revision",
            "resulting_lifecycle_revision",
        ):
            item = value.get(field)
            if isinstance(item, bool) or not isinstance(item, int) or item < 0:
                issues.append(f"{field}_invalid")
        expected_revision = value.get("expected_prior_lifecycle_revision")
        resulting_revision = value.get("resulting_lifecycle_revision")
        if (
            isinstance(expected_revision, int)
            and not isinstance(expected_revision, bool)
            and isinstance(resulting_revision, int)
            and not isinstance(resulting_revision, bool)
            and resulting_revision != expected_revision + 1
        ):
            issues.append("resulting_lifecycle_revision_invalid")
        if value.get("resulting_effective_state") not in {
            "candidate",
            "published",
            "superseded",
            "deprecated",
            "invalidated",
            "retrieval_redacted",
        }:
            issues.append("resulting_effective_state_invalid")
        try:
            _timestamp(value.get("recorded_at"), field="recorded_at")
        except (TypeError, ValueError):
            issues.append("recorded_at_invalid")
        digest = value.get("content_sha256")
        if not isinstance(digest, str) or digest != _digest(value):
            issues.append("content_sha256_mismatch")
        if isinstance(receipt_id, str) and isinstance(digest, str) and (
            receipt_id != f"memory-lifecycle-{digest[:24]}"
        ):
            issues.append("receipt_id_hash_mismatch")
        return issues

    def _inventory(self) -> dict[str, Any]:
        rows: list[dict[str, str]] = []
        valid: dict[str, dict[str, Any]] = {}
        skipped: list[str] = []
        if not self._memory_store._validate_root(create=False):
            return self._inventory_result(rows, valid, skipped, False)
        paths = sorted(self._memory_store._root.glob("*.json"))
        truncated = len(paths) > MAX_MEMORY_RECORDS
        for path in paths[:MAX_MEMORY_RECORDS]:
            try:
                raw = path.read_bytes()
            except OSError:
                raw = b""
            rows.append({"filename": path.name, "record_sha256": sha256_bytes(raw)})
            exact = self._memory_store.get(path.stem)
            if exact["status"] != "ok":
                skipped.append(path.stem)
                continue
            valid[path.stem] = {
                "memory": exact["memory"],
                "record_sha256": sha256_bytes(raw),
            }
        return self._inventory_result(rows, valid, skipped, truncated)

    @staticmethod
    def _inventory_result(
        rows: Sequence[Mapping[str, str]],
        valid: Mapping[str, Mapping[str, Any]],
        skipped: Sequence[str],
        truncated: bool,
    ) -> dict[str, Any]:
        return {
            "inventory_sha256": sha256_bytes(canonical_bytes(list(rows))),
            "valid": dict(valid),
            "skipped": list(skipped),
            "truncated": truncated,
        }

    def _derive_view(
        self,
        memory_id: str,
        memory: Mapping[str, Any],
        receipts: Sequence[Mapping[str, Any]],
        *,
        record_sha256: str | None,
        as_of: str,
        issues: Sequence[str],
    ) -> dict[str, Any]:
        _, as_of_time = _timestamp(as_of, field="as_of")
        applicable = []
        semantic_issues = list(issues)
        for receipt in receipts:
            try:
                _, receipt_time = _timestamp(
                    receipt["recorded_at"], field="recorded_at"
                )
            except (KeyError, TypeError, ValueError):
                semantic_issues.append(
                    f"invalid_recorded_at:{receipt.get('receipt_id', 'unknown')}"
                )
                continue
            if receipt_time <= as_of_time:
                applicable.append(receipt)
        by_id = {item["receipt_id"]: item for item in applicable}
        recovered: set[str] = set()
        for receipt in applicable:
            if receipt["action"] != "recover":
                continue
            referenced = by_id.get(receipt["recovers_receipt_id"])
            if (
                referenced is None
                or referenced["resulting_lifecycle_revision"]
                >= receipt["resulting_lifecycle_revision"]
                or referenced["action"] == "recover"
                or referenced["receipt_id"] in recovered
            ):
                semantic_issues.append(
                    f"invalid_recovery_reference:{receipt['receipt_id']}"
                )
                continue
            recovered.add(referenced["receipt_id"])

        state = "published"
        memory_key = memory_id
        current_eligible = True
        retrieval_eligible = True
        payload_visible = True
        successor = None
        conflicts: set[str] = set()
        for receipt in applicable:
            if receipt["action"] == "recover" or receipt["receipt_id"] in recovered:
                continue
            action = receipt["action"]
            if action in {"candidate", "publish"}:
                memory_key = receipt["memory_key"]
                conflicts.update(receipt["conflicts_with"])
            if action == "candidate":
                state = "candidate"
                current_eligible = False
                retrieval_eligible = False
            elif action == "publish":
                state = "published"
                current_eligible = True
                retrieval_eligible = True
                payload_visible = True
            elif action == "supersede":
                state = "superseded"
                current_eligible = False
                retrieval_eligible = False
                successor = receipt["successor_memory_id"]
            elif action == "deprecate":
                state = "deprecated"
                current_eligible = False
                retrieval_eligible = False
            elif action == "invalidate":
                state = "invalidated"
                current_eligible = False
                retrieval_eligible = False
            elif action == "redact_from_retrieval":
                state = "retrieval_redacted"
                retrieval_eligible = False
                payload_visible = False
        if semantic_issues:
            current_eligible = False
            retrieval_eligible = False
        return {
            "status": "ok" if not semantic_issues else "review_needed",
            "memory_id": memory_id,
            "memory_key": memory_key,
            "record_sha256": record_sha256,
            "lifecycle_revision": (
                applicable[-1]["resulting_lifecycle_revision"] if applicable else 0
            ),
            "effective_state": state,
            "current_eligible": current_eligible,
            "retrieval_eligible": retrieval_eligible,
            "payload_visible": payload_visible,
            "source_evidence_eligible": False,
            "successor_memory_id": successor,
            "conflicts_with": sorted(conflicts),
            "applied_receipt_ids": [item["receipt_id"] for item in applicable],
            "recovered_receipt_ids": sorted(recovered),
            "as_of": as_of,
            "issues": list(dict.fromkeys(semantic_issues)),
        }

    def _apply_source_eligibility(
        self, view: dict[str, Any], memory: Mapping[str, Any], *, as_of: str,
    ) -> None:
        try:
            refs = self._evidence_refs(memory)
        except ValueError:
            view["retrieval_eligible"] = False
            view["current_eligible"] = False
            view["issues"] = list(
                dict.fromkeys([*view["issues"], "memory_not_evidence_linked"])
            )
            return
        from .development_project_evidence import (
            DevelopmentProjectEvidenceStore,
        )

        evidence_store = DevelopmentProjectEvidenceStore(
            self._project_root, project_id=self._project_id
        )
        lifecycle = evidence_store.lifecycle_store()
        source_issues = []
        for evidence_id in refs:
            exact = evidence_store.verify(evidence_id)
            effective = lifecycle.resolve(evidence_id, as_of=as_of)
            if (
                exact["status"] != "ok"
                or exact["evidence"]["verification_status"] != "verified"
                or effective["status"] != "ok"
                or not effective["retrieval_eligible"]
            ):
                source_issues.append("source_evidence_ineligible")
        view["source_evidence_eligible"] = not source_issues
        if source_issues:
            view["retrieval_eligible"] = False
            view["current_eligible"] = False
            view["issues"] = list(
                dict.fromkeys([*view["issues"], *source_issues])
            )

    def resolve(
        self, memory_id: str, *, as_of: str | None = None,
    ) -> dict[str, Any]:
        normalized = _text(memory_id, field="target_memory_id", maximum=200)
        if SAFE_MEMORY_ID.fullmatch(normalized) is None:
            raise ValueError("codex_project_memory_lifecycle_target_id_invalid")
        selected_as_of, _ = _timestamp(as_of or _now(), field="as_of")
        resolved = self.resolve_all(as_of=selected_as_of)
        if normalized in resolved["views"]:
            return resolved["views"][normalized]
        return {
            "status": "not_found",
            "memory_id": normalized,
            "memory_key": None,
            "record_sha256": None,
            "lifecycle_revision": 0,
            "effective_state": "unavailable",
            "current_eligible": False,
            "retrieval_eligible": False,
            "payload_visible": False,
            "source_evidence_eligible": False,
            "successor_memory_id": None,
            "conflicts_with": [],
            "applied_receipt_ids": [],
            "recovered_receipt_ids": [],
            "as_of": selected_as_of,
            "issues": [],
        }

    def resolve_all(self, *, as_of: str | None = None) -> dict[str, Any]:
        selected_as_of, _ = _timestamp(as_of or _now(), field="as_of")
        observed = self._inventory()
        views: dict[str, dict[str, Any]] = {}
        for memory_id, item in observed["valid"].items():
            receipts, receipt_issues = self._valid_receipts_for_target(memory_id)
            view = self._derive_view(
                memory_id,
                item["memory"],
                receipts,
                record_sha256=item["record_sha256"],
                as_of=selected_as_of,
                issues=receipt_issues,
            )
            self._apply_source_eligibility(
                view, item["memory"], as_of=selected_as_of
            )
            views[memory_id] = view

        cycle_members = self._successor_cycle_members(views)
        self._mark_review_needed(views, cycle_members, "successor_cycle")
        active = {
            memory_id
            for memory_id, view in views.items()
            if view["current_eligible"]
            and view["effective_state"] in {"published", "retrieval_redacted"}
        }
        by_key: dict[str, list[str]] = {}
        for memory_id in sorted(active):
            by_key.setdefault(views[memory_id]["memory_key"], []).append(memory_id)
        for members in by_key.values():
            if len(members) > 1:
                self._mark_review_needed(
                    views, set(members), "unresolved_multiple_current_heads"
                )
        explicit_conflicts = {
            member
            for memory_id in active
            for member in views[memory_id]["conflicts_with"]
            if member in active
        } | {
            memory_id
            for memory_id in active
            if any(
                member in active for member in views[memory_id]["conflicts_with"]
            )
        }
        self._mark_review_needed(
            views, explicit_conflicts, "unresolved_explicit_conflict"
        )
        status = "ok"
        if (
            observed["skipped"]
            or observed["truncated"]
            or any(view["status"] != "ok" for view in views.values())
        ):
            status = "review_needed"
        return {
            "status": status,
            "project_id": self._project_id,
            "as_of": selected_as_of,
            "memory_inventory_sha256": observed["inventory_sha256"],
            "lifecycle_inventory_sha256": self.inventory_sha256(),
            "views": {key: views[key] for key in sorted(views)},
            "skipped_invalid_memory_ids": sorted(observed["skipped"]),
            "scan_truncated": observed["truncated"],
            "non_claims": [
                "effective_view_does_not_mutate_or_delete_source_memory",
                "review_needed_does_not_select_a_conflict_winner",
                "effective_view_grants_no_gate_release_production_or_live_authority",
            ],
        }

    @staticmethod
    def _mark_review_needed(
        views: Mapping[str, dict[str, Any]], members: set[str], issue: str,
    ) -> None:
        for memory_id in sorted(members):
            view = views[memory_id]
            view["status"] = "review_needed"
            view["current_eligible"] = False
            view["retrieval_eligible"] = False
            view["issues"] = list(dict.fromkeys([*view["issues"], issue]))

    @staticmethod
    def _successor_cycle_members(
        views: Mapping[str, Mapping[str, Any]],
    ) -> set[str]:
        successor = {
            memory_id: view["successor_memory_id"]
            for memory_id, view in views.items()
            if view.get("successor_memory_id") in views
        }
        cycles: set[str] = set()
        completed: set[str] = set()
        for start in sorted(successor):
            if start in completed:
                continue
            path: list[str] = []
            positions: dict[str, int] = {}
            current = start
            while current in successor and current not in completed:
                if current in positions:
                    cycles.update(path[positions[current] :])
                    break
                positions[current] = len(path)
                path.append(current)
                current = successor[current]
            completed.update(path)
        return cycles
