# Codex Runtime Adapter Contract

This contract describes how Codex should operate when it mounts
`AI_Game_Dev_OS_v4.97/` as an AI Game Dev OS development source.
Promotion-facing shapes remain compatible with the inherited v4.93 contract,
and v4.94 development-task behavior remains inherited.

Codex is the external AI IDE/runtime operator. The inherited v4.93 package
remains the promotion-facing contract source; this document additionally owns
the v4.94 development-only task behavior and the first v4.95 bounded Production
Worker behavior. Repository scripts do not call LLM agents automatically.

## Bounded Godot Production Worker

`production_worker.py` is the v4.95 single-worker execution entrypoint for one
already admitted local development task attempt. The external Codex host owns
the reasoning loop and explicitly supplies the target project, task/attempt,
actor, Agent contract, Skill contract, tool binding, exact input paths, write
patterns, and Godot binary or project-local capability binding.

The worker loads the real `godot_runtime_slice_engineer` and
`godot_runtime_feature_slice_skill` contracts plus
`bindings/godot_runtime_feature_slice.binding.json`. It exposes only exact
declared UTF-8 input reads, atomic text writes, and typed Godot version,
project-load, script, scene, export, packaged-app, and reproducible development-
build operations. A write must be permitted by all three envelopes: the task
declaration, Agent `can_modify`/`must_not_modify`, and Skill
`allowed_writes`/`forbidden_writes`. Replacement also requires the caller's
exact observed SHA-256; a changed target is returned for re-read rather than
silently overwritten.

`godot_execution_adapter.py` resolves an explicit executable without a shell,
records its byte identity, requires one regular `project.godot`, prevents
project/symlink escape, limits captured output, distinguishes parse and
resource failures even when Godot exits zero, and can require an observable
PASS token. Its project-load operation uses Godot's import-wait mode so a zero
exit cannot represent an editor process that quit while the import scan was
still pending. ANSI-colored diagnostics are normalized before classification;
the reproduced Godot 4.4 headless progress-dialog messages are retained but
scoped out, while any other import error still fails. Direct command timeouts
terminate the process group. macOS
LaunchServices mode binds both the Godot executable and app-bundle identity,
waits through `/usr/bin/open`, and truthfully reports that timeout cleanup is
limited to the launcher-wait process; packaged development checks therefore
also pass Godot's bounded `--quit-after` argument. Results stay bound to task,
attempt, actor, Agent, and Skill identities.

`godot_development_build.py` requires a clean pinned Git source by default and
an explicit artifact root outside the project. Before export it waits for
imports, requires every active adjacent `.import` / `.uid` sidecar to be
tracked and paired with tracked source, and binds their aggregate identity.
It then exports the same source twice to fresh staging paths, rechecks source
identity after each export, and requires byte-identical full app content-tree
identities, including exactly one embedded PCK. Before atomic promotion it
verifies the development signature and an isolated byte-for-byte PCK restore.
After promotion it launches the exact delivered app; if a replacement launch
fails, it restores the previous delivered app. The adjacent atomic JSON receipt
records source, engine, build, artifact, signature, launch, recovery, and
rollback facts. This is a local development delivery primitive, not release
packaging, signing, notarization, distribution, or live-state recovery.

Agent/Skill/binding `draft` status is a limit, not execution authority. The
worker does not decide that design is accepted, write project state before a
host admits a legal task, verify its own result independently, qualify a
package, pass a Gate, promote evidence, build a release, or contact live state.
The inherited binding provides reproducible development export and factual
delivery receipts; `godot_focused_qa.py` provides the separate read-only QA
executor. v4.96 composes those primitives through the bounded multi-lane
profile described in `V496_DEVELOPMENT_STATUS.md`; none of them grants
qualification, release, or production/live authority.

## Development Task State

`development_task_adapter.py` is the bounded development entry for task state
in an explicitly selected game project. It starts the project-local Runtime
State service and separates two roles:

- `CodexDevelopmentTaskAdapter` may queue, prepare/start, select/resume, and
  list tasks,
  attach work-product references, claim `CLAIMED_DONE`, and withdraw an
  unreviewed claim as the accountable producer or latest claimant. Selection
  without a task ID succeeds only for exactly one unfinished task; zero or
  multiple unfinished tasks return an explicit non-success outcome. It may
  persist and resolve task-linked development blockers, but it cannot mark an
  issue `VERIFIED` or `CLOSED`;
- `CodexDevelopmentReviewAdapter` may independently return a claimed task to
  `IN_PROGRESS` with a commit-bound FAIL reason, or verify and close it only
  when a PASS review is bound to the implementation Git commit. Its review
  queue lists only `CLAIMED_DONE` tasks whose accountable producer differs
  from the current reviewer.

The task producer cannot verify or close its own work. Neither adapter can run
qualification, pass a Gate, promote a project, or release a package. Task state
writes stay beneath
`<target_project>/.ai_dev_os/development/runtime_state/`. An explicit memory
promotion may write beneath
`<target_project>/.ai_dev_os/development/project_memory/`. Neither path creates
`.ai_dev_os/state`.

`list_resume_candidates()` is the read-only discovery path when automatic
selection is ambiguous. For each unfinished task it returns only the existing
task identity, title, feature, state, owner, derived next action and current
attempt projection. It does not choose, prioritize, claim, lock or update any
task; the caller must still pass an explicit task ID to `resume_task()`.
`queue_task()` leaves future work in `CREATED`; its returned `prepare_task`
action is implemented by the idempotent `prepare_task()` call. A prepared
`READY` task returns `start_task`, also an idempotent call. `begin_task()` is
the convenience path that performs all three steps immediately. These calls
reuse the existing task lifecycle and do not create a scheduler, assignment
service, execution worker or qualification action.

The lightweight review path is admitted only for project-local development
state. The reviewer identity must differ from the task's immutable accountable
producer. A completion claim requires one or more Git implementation references
that all carry the same full commit. Before writing work products, the adapter
requires that commit to exist in the selected project's local Git repository
and every safe project-relative path to resolve to a blob at that commit.
Output references are supplementary and cannot make an output-only task
reviewable. The check does not require the commit to be HEAD, require a clean
worktree, compare working bytes, or compute a manifest. The claim stores that
commit in its transition context. PASS and FAIL must match both the stored
claim commit and every current implementation reference. For PASS closure,
P0/P1 counts must be integer zero. Qualification keeps the packaged Evidence
Core receipt requirement unchanged.

Immediately before the first development PASS is stored, the independent
review adapter repeats the local commit/blob availability check. This protects
claims retained from an older adapter or written through the lower-level task
session. A missing source blocks only PASS: `reject_task_claim()` may still
record a commit-bound FAIL and return the task for repair. If PASS already
reached `VERIFIED`, crash recovery of the remaining `CLOSED` transition trusts
that persisted PASS binding and does not repeat the Git check without a state
change.

PASS admission checks for open handoffs before it writes the review reference
or moves the task to `VERIFIED`. If a process ends after `VERIFIED` is committed
but before `CLOSED`, the same reviewer can resume only the close step after the
persisted reviewer, commit, verdict and PASS reference are rechecked. This is
crash recovery for local development state, not a second review or promotion.

A development FAIL reference must also name the implemented Git commit and
carry a concise findings summary. It returns the task directly to
`IN_PROGRESS` for ordinary repair, preserves the producer identity and prior
review reference, and creates no blocker, verification, qualification or Gate
claim. A later corrected commit receives a fresh independent review.

`list_review_queue()` is a bounded current-state read. It does not claim,
assign, prioritize or lock a task, and it creates no review evidence. A task
leaves the returned list as soon as it leaves `CLAIMED_DONE`; concurrent callers
must still handle normal CAS/state-transition rejection when they act.
Task, issue and handoff lists request project/type-filtered pages of at most 100
rows and advance with the last object ID. The page size is an IPC bound, not a
project capacity or governance threshold; reaching it performs another bounded
read rather than rejecting a long-lived project. Qualification reads retain
their existing request surface.

`withdraw_task_claim()` is a development correction before review acceptance.
The immutable accountable producer or the actor recorded by the latest
`claimed_by` may supply a reason and return `CLAIMED_DONE` to `IN_PROGRESS`.
Implementation/output references and transition history remain intact, while
the task leaves the review queue. The operation cannot withdraw `VERIFIED` or
`CLOSED` work and creates no Human, qualification or Gate disposition.

Development task revisions are operational state. They do not require or
produce `agent_execution_trace.json`. The trace and readiness validators below
apply only when a separate promotion or qualification workflow is requested.

`inspect_work_context()` is an optional, read-only observation. It reports the
selected project's Git repository root, branch, HEAD, detached state and short
status. A dirty worktree, detached HEAD, unborn branch, unavailable Git binary,
or non-Git project is returned as data and does not block development task
creation, resumption or mutation. The observation is not stored as evidence
and does not compute a manifest or per-file digest.

Development handoffs reuse the packaged `handoff` lifecycle. The source actor
may send a task-linked handoff; only its named `to_owner` may accept and
complete it. The named recipient may also reject a `SENT` handoff or return an
`ACCEPTED`/`IN_EXECUTION` handoff, with an attributable reason. Handoff
completion records development notes and optional output references, while
reject/return records no completion claim. None of these paths transfers the
source task's immutable accountable producer, verifies the task, or establishes
authority over the output.

`get_resume_context()` is a current read projection, not a checkpoint. It
combines the selected unfinished task with its active blockers, open handoffs,
handoffs assigned to the current actor, and `inspect_work_context()` output.
Reading it creates no Runtime State revision and does not convert missing or
dirty Git context into a failure. Its `current_attempt` is derived from the
append-only task transition history: initial work and explicit rework start a
new attempt number, while resuming after a resolved blocker preserves the
existing attempt. A latest-only progress note is included only when its
stored `attempt_id` belongs to that attempt; legacy unbound notes are accepted
only for the first attempt. This is a projection, not a new attempt object,
retry ledger, evaluator result, or execution authority.

`inspect_task_inputs()` is a development diagnostic for two explicit local
reference forms: `project://<relative-path>` checks current project presence,
and `git://<repository>@<40-hex-commit>/<relative-path>` compares the current
worktree path with that Git revision. When the selected project is nested in a
larger Git repository, the adapter derives the repository-relative path before
reading the named revision. Missing or changed inputs are reported but do not
mutate, block or invalidate the task. Other schemes, including `design://`,
remain opaque and return `uninspectable`; this adapter does not resolve their
truth or authority.

`load_task_readset()` is an explicit cold-start helper, not an automatic
preflight. It reads only the selected task's declared `project://` text files
and exact `git://...@<commit>/...` text blobs. It never scans the whole project,
does not follow escaping paths, skips binary/non-UTF-8 or oversized content,
and applies fixed file-count and total-byte budgets. Git content is read from
the named revision, so a dirty worktree does not silently replace the task's
bound context. Returned content is `reference_content_only`; loading it does
not establish approval, Project Truth, qualification, or execution authority.

`get_resume_context(..., include_input_contents=True)` opts into that same
bounded readset while constructing the recovery view. It uses the already
selected task revision and the same Git observation as input inspection. The
default is `False`, so ordinary resume discovery still reads metadata only.
This option does not scan undeclared files, persist content or update state.

`preview_input_impacts()` is an on-demand read over unfinished development
tasks. It groups tasks that currently have `changed` or `missing` inspectable
inputs and separately counts opaque `uninspectable` references. The result is
a prioritization hint only: it does not mark a task stale, invalidate work,
change task state, establish Project Truth, or prevent the task from running.

`apply_input_revision_change()` is the explicit mutating companion for a
revision change already decided outside this adapter. Its old and replacement
inputs must be exact `git://` references to the same repository and path, and
the replacement must match the current worktree. It changes only unfinished
tasks that name the old reference. A `CREATED` task is rebound before work
starts; a started, claimed, verified, reopened, or already-blocked task receives
one linked `input_revalidation` blocker. Repeating the same call is idempotent.
The operation returns `NON_QUALIFYING`: it neither grants Human authority nor
claims that the design change was approved.

`propagate_production_spec_patch_input_revision()` is a convenience bridge for
the existing Pack-layer implementation entry. The caller supplies one already
selected `production_spec_patch` object plus the explicit old and replacement
Git refs. The bridge checks only the artifact type, supported version, and the
non-empty `task_id`, `patch_id`, `source_merge_record_ref`, and
`accepted_behavior_delta` fields before calling `apply_input_revision_change()`.
It does not run the delivery validator, prove approval, or infer Git revisions
from semantic runtime/data surfaces. Its result therefore reports
`artifact_validation_status: not_performed`,
`authority_status: external_not_asserted`, and remains `NON_QUALIFYING`.

The separate `production_spec_input_bridge.py` consumes one complete,
schema-valid `game_design_production_spec` before Production Cell composition.
It deterministically maps existing task identity, document title, acceptance
criteria and source provenance, then combines them with an explicit
feature/profile/source-revision/write-envelope selection. Optional
`augmentations` are additive or narrowing bindings only: they may carry extra
input/evidence refs, concrete write/QA bindings, or selected-profile options,
but cannot override accepted behavior, target another profile, or expand the
selected write envelope. A separate profile-input compatibility binding owns
the accepted handoff routes and references, without changing, the target
composition binding. The result does not execute the Worker, engine,
development build, or QA and does not interpret schema validity as approval.

`preview_production_spec_patch_replay()` is the read-only companion. It checks
the same patch identity fields and requires the replacement Git input to match
the selected project, then reports every task that still names the old input.
For historical development tasks only, preview may also match one unambiguous
pair consisting of a same-repository 8-to-39-hex commit prefix and the exact
`project://` path named by the caller's full previous ref. This compatibility
is preview-only; mutating propagation still requires the exact persisted Git
ref.
It includes terminal tasks so callers can see whether a closed task may need a
separate reopen decision. State-specific actions and suggested focused checks
are recommendations only. The call does not create blockers, rebind inputs,
reopen tasks, validate the patch, or grant production authority.

`complete_task_input_revalidation()` rebinds one affected task to the exact
replacement reference and resolves its dedicated blocker after checking the
replacement again. Only the immutable accountable producer or latest claimant
may call it. Other active blockers keep the task blocked. This is development
workflow state, not qualification, Gate, promotion, or Project Truth evidence.

`record_progress()` stores one current summary and next step on an
`IN_PROGRESS` or `BLOCKED` task. A later call replaces that note rather than
growing a second history beside Runtime State revisions. The adapter binds the
note to the derived current `attempt_id`, so a note from a prior review cycle
is not restored as current rework progress. Recording progress
does not change lifecycle state, task ownership, verification or authority;
it is operational development context only.

`checkpoint_for_interruption()` performs that same latest-only progress write
with a compact Git snapshot and then returns a fresh `get_resume_context()`
bound to the saved task revision. The snapshot contains HEAD, branch, detached
and dirty flags, change count, and a hash of the sorted status summary; it does
not store paths or a diff. Resume compares that snapshot read-only and reports
`unchanged`, `review_changes`, or `context_unavailable`. The result is advisory
and non-blocking: it neither rolls back files nor changes the task lifecycle.
Retrying the same summary, next step, and snapshot in the same attempt returns
`already_checkpointed` without creating another revision. The operation is a
development convenience, not a database snapshot, backup, evidence receipt,
qualification or Gate action.

`cancel_task()` uses the existing terminal `CANCELLED` transition and records
the caller and reason in its transition context. Cancelled tasks remain in
Runtime State but no longer participate in automatic resume selection or input
impact preview. Only the immutable accountable producer or the most recent
claimant may cancel; the State Service repeats this check at its write boundary.
Cancellation is rejected while a linked handoff remains open, so delegated
work cannot silently outlive its source task. It does not delete the task,
resolve linked issues, or create a completion claim.

`get_development_completion_summary()` projects an already closed task into a
small read model containing task identity/revision, the claimed Git commit and
implementation refs, independent PASS review identity and finding counts,
outputs, and close event. It fails for a non-closed task and does not persist a
summary object or change the task revision.

`promote_closed_task_to_project_memory()` is an explicit development-only
distillation step. The caller supplies the memory title, concise content, and
optional tags. One immutable JSON record is written per source task revision
under `.ai_dev_os/development/project_memory/`; an exact retry is idempotent and
different bytes cannot silently replace the selected record. It does not
publish to package or global LTM.

`search_project_memories()` performs a manual bounded local scan with optional
keywords and tags. A missing memory directory returns an empty result without
creating it. The result reports scan count, truncation, and skipped invalid
files. It is never called automatically by task start/resume and does not
inject returned content into a task context.

## Required Read Order

1. `INDEX.md`
2. `MANIFEST.json`
3. `README.md`
4. `DESIGN_AND_CAPABILITY_ARCHITECTURE.md`
5. `MODULES_AND_INVOCATION.md`
6. `RUNTIME_INSTANCE_CONTRACT.md`
7. `REAL_PROJECT_ADOPTION_CONTRACT.md`
8. `ROOT_MIRROR_POLICY.md`
9. `IDE_INTEGRATION.md`
10. `adapters/codex/codex_integration_policy.json`
11. `adapters/codex/codex_invocation_profile.json`
12. `os_layer/os_control_plane/leads/orchestrator.capability.json`
13. `pack_layer/packs/game_system_packs/end_to_end_production/capability_pack.json`
14. `pack_layer/packs/game_system_packs/end_to_end_production/references/end_to_end_delivery_workflow.json`
15. `pack_layer/packs/game_system_packs/end_to_end_production/docs/agent_harness/RUNTIME_ADAPTER_SPEC.md`

## Invocation Flow

Development task-state flow:

```text
explicit local game-project root + project identity
-> Codex opens the development task adapter
-> create or resume a task
-> perform the functional work
-> record work-product references
-> claim CLAIMED_DONE
-> an independent Codex review adapter records a commit-bound PASS
-> verify and close the development task
```

Promotion/qualification flow:

```text
user goal
-> Codex reads root contracts
-> Codex selects goal class
-> Codex checks Orchestrator routing capabilities
-> Codex selects canonical pack resource, workflow state, owner, or validator
-> Codex states write boundary, evidence, validation, and stop condition
-> Codex performs or delegates work
-> Codex writes runtime instance evidence
-> Codex runs validators
-> Codex reports PASS, WARN, BLOCKED, or FixOps intake
```

## Canonical Source Rule

This adapter does not define canonical agents, skills, workflows, schemas, or
validators. It references:

- `os_layer/os_control_plane/leads/orchestrator.capability.json`
- `DESIGN_AND_CAPABILITY_ARCHITECTURE.md`
- `pack_layer/packs/game_system_packs/end_to_end_production/capability_pack.json`
- `pack_layer/packs/game_system_packs/end_to_end_production/references/end_to_end_delivery_workflow.json`
- `pack_layer/packs/game_system_packs/end_to_end_production/docs/agent_harness/RUNTIME_ADAPTER_SPEC.md`

If those sources conflict, Codex must stop and request a contract repair rather
than inventing a local override inside `adapters/codex/`.

## Runtime Instance Outputs

Codex-generated runtime state belongs in the target project or artifact root,
not in canonical v4.93 definitions:

The full runtime instance layout is defined in `RUNTIME_INSTANCE_CONTRACT.md`.
Real-project adoption evidence and lifecycle promotion gates are defined in
`REAL_PROJECT_ADOPTION_CONTRACT.md`.

```text
target_project/
  .ai_dev_os/
    development/
      runtime_state/
        runtime-state.development.sqlite3
      project_memory/       # absent until explicit promotion
        completion-<task>-r<revision>.json
    capability_bindings.json
    codex_runtime_profile.json
    agent_run_plan.json
    agent_execution_trace.json
    reports/

target_project_artifacts/
  v493/
    beta_readiness_report.json
    shared_truth_index.json
    architecture_baseline.json
```

## Stop Conditions

Codex must stop before implementation when:

- root contracts or adapter policy are unread;
- no canonical owner can be resolved;
- a requested write exceeds allowed write surfaces;
- the development project root is absent, implicit, production, or resolves to
  the mounted AI Game Dev OS package;
- the persisted project identity does not match the requested project;
- required evidence cannot be generated for a requested promotion or
  qualification action;
- promotion or qualification is requested without its required
  `agent_execution_trace.json`;
- a requested promotion has beta readiness blockers;
- the task would require `.dev_os_meta/` as runtime package content.

## Validation

Use the repository validators as the promotion/qualification acceptance
boundary, not as a prerequisite for ordinary development task-state updates:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_agent_execution_trace.py \
  --run-plan <agent_run_plan.json> \
  --trace <agent_execution_trace.json>
```

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/evaluate_pack_beta_readiness.py \
  --project-root <project_root> \
  --artifact-root <artifact_root> \
  --agent-trace <agent_execution_trace.json> \
  --write-report <report.json>
```

Fixture success is regression evidence only. Real-project promotion requires a
runtime-produced trace and reviewed project evidence.
