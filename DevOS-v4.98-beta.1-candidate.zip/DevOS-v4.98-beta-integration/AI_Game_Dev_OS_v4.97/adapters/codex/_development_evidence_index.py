"""Disposable metadata keyword index for project development Evidence."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from ._development_evidence_common import (
    DEVELOPMENT_PROJECT_EVIDENCE_RELATIVE_PATH,
    INDEX_RELATIVE_PATH,
    MAX_QUERY_CHARS,
    MAX_RECORD_FILES,
    MAX_RESULTS,
    atomic_write,
    canonical_bytes,
    pretty_bytes,
    sha256_bytes,
)


def inventory(store: Any) -> dict[str, Any]:
    rows: list[dict[str, str]] = []
    valid: list[dict[str, Any]] = []
    skipped: list[str] = []
    truncated = False
    if not store._validate_root(create=False):
        return _inventory_result(rows, valid, skipped, truncated)
    records = store._directory(Path("records"), create=False)
    if records is None:
        return _inventory_result(rows, valid, skipped, truncated)
    paths = sorted(records.glob("*.json"))
    truncated = len(paths) > MAX_RECORD_FILES
    for path in paths[:MAX_RECORD_FILES]:
        try:
            raw = path.read_bytes()
        except OSError:
            raw = b""
        rows.append({
            "filename": path.name,
            "record_sha256": sha256_bytes(raw),
        })
        try:
            result = store.verify(path.stem)
        except ValueError:
            skipped.append(path.stem)
            continue
        if result["status"] == "ok":
            valid.append(result)
        else:
            skipped.append(path.stem)
    return _inventory_result(rows, valid, skipped, truncated)


def _inventory_result(
    rows: list[dict[str, str]],
    valid: list[dict[str, Any]],
    skipped: list[str],
    truncated: bool,
) -> dict[str, Any]:
    return {
        "inventory_sha256": sha256_bytes(canonical_bytes(rows)),
        "valid": valid,
        "skipped": skipped,
        "truncated": truncated,
    }


def rebuild_index(store: Any) -> dict[str, Any]:
    store._validate_root(create=True)
    observed = inventory(store)
    entries: list[dict[str, Any]] = []
    for result in observed["valid"]:
        record = result["evidence"]
        entries.append({
            "evidence_id": record["evidence_id"],
            "evidence_kind": record["evidence_kind"],
            "task_id": record["task_id"],
            "source_revision": record["source_revision"],
            "title": record["title"],
            "summary": record["summary"],
            "verification_status": record["verification_status"],
            "content_sha256": record["content"]["sha256"],
            "record_sha256": result["record_sha256"],
        })
    entries.sort(key=lambda item: item["evidence_id"])
    index = {
        "schema_version": "1.0.0",
        "artifact_type": "project_evidence_index",
        "project_id": store._project_id,
        "record_inventory_sha256": observed["inventory_sha256"],
        "entries": entries,
        "skipped_invalid_evidence_ids": sorted(observed["skipped"]),
        "scan_truncated": observed["truncated"],
        "limitations": [
            "derived_disposable_index",
            "metadata_keyword_only",
            "not_evidence_authority",
            "not_automatic_context_or_memory_promotion",
        ],
    }
    index_dir = store._directory(Path("index"), create=True)
    assert index_dir is not None
    target = index_dir / INDEX_RELATIVE_PATH.name
    serialized = pretty_bytes(index)
    atomic_write(target, serialized)
    return {
        "status": (
            "rebuilt"
            if not observed["skipped"] and not observed["truncated"]
            else "review_needed"
        ),
        "index": index,
        "index_ref": target.relative_to(store._project_root).as_posix(),
        "index_sha256": sha256_bytes(serialized),
    }


def search(store: Any, query: str, *, limit: int = 10) -> dict[str, Any]:
    if not isinstance(query, str):
        raise ValueError("codex_project_evidence_query_invalid")
    normalized_query = query.strip()
    if len(normalized_query) > MAX_QUERY_CHARS:
        raise ValueError("codex_project_evidence_query_too_long")
    if (
        isinstance(limit, bool)
        or not isinstance(limit, int)
        or not 1 <= limit <= MAX_RESULTS
    ):
        raise ValueError("codex_project_evidence_limit_invalid")
    response = {
        "status": "review_needed",
        "query": normalized_query,
        "limit": limit,
        "results": [],
        "issues": [],
        "limitations": [
            "read_only_metadata_keyword_retrieval",
            "index_result_is_not_project_truth",
            "index_result_grants_no_authority",
        ],
    }
    if not store._validate_root(create=False):
        response["issues"] = ["evidence_store_missing"]
        return response
    index_path = store._project_root / (
        DEVELOPMENT_PROJECT_EVIDENCE_RELATIVE_PATH / INDEX_RELATIVE_PATH
    )
    if index_path.is_symlink() or not index_path.is_file():
        response["issues"] = ["evidence_index_missing"]
        return response
    try:
        index = json.loads(index_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        response["issues"] = ["evidence_index_unreadable"]
        return response
    if (
        not isinstance(index, Mapping)
        or index.get("artifact_type") != "project_evidence_index"
        or index.get("schema_version") != "1.0.0"
        or index.get("project_id") != store._project_id
        or not isinstance(index.get("entries"), list)
    ):
        response["issues"] = ["evidence_index_invalid"]
        return response
    observed = inventory(store)
    if index.get("record_inventory_sha256") != observed["inventory_sha256"]:
        response["issues"] = ["evidence_index_stale"]
        return response
    if observed["skipped"] or observed["truncated"]:
        response["issues"] = ["evidence_inventory_not_clean"]
        return response
    try:
        ranked = _ranked_results(index["entries"], normalized_query)
    except (KeyError, TypeError, ValueError):
        response["issues"] = ["evidence_index_entry_invalid"]
        return response
    response["status"] = "ok"
    response["results"] = ranked[:limit]
    return response


def _ranked_results(
    entries: list[Any], query: str,
) -> list[dict[str, Any]]:
    tokens = list(dict.fromkeys(
        token.casefold() for token in query.split() if token
    ))
    matches: list[dict[str, Any]] = []
    for entry in entries:
        if not isinstance(entry, Mapping):
            raise ValueError("codex_project_evidence_index_entry_invalid")
        if entry.get("verification_status") != "verified":
            continue
        title = str(entry.get("title", ""))
        searchable = " ".join(
            str(entry.get(field, ""))
            for field in (
                "title", "summary", "evidence_kind", "task_id",
                "source_revision", "content_sha256",
            )
        ).casefold()
        matched = sum(token in searchable for token in tokens)
        if tokens and matched == 0:
            continue
        score = matched + (
            2 if query and query.casefold() in title.casefold() else 0
        )
        matches.append({"score": score, "evidence": dict(entry)})
    matches.sort(key=lambda item: item["evidence"]["evidence_id"])
    matches.sort(key=lambda item: item["score"], reverse=True)
    return matches
