"""Bounded Godot execution primitives for a single Production Worker.

This module is a development adapter, not an Agent invoker and not an
authority source.  A host runtime (Codex, another approved Adapter, or a test)
selects the task, Agent, Skill, project, and declared write envelope.  This
adapter then:

* resolves one explicit Godot executable without using a shell;
* verifies that the selected project is a bounded Godot project;
* binds one selected Agent and Skill contract and treats both as additional
  write *limits*, never as grants;
* exposes typed project-load, script, and scene execution operations; and
* returns attributable, JSON-serializable command results with timeout and
  focused failure classification.

It does not edit project files, invoke an LLM, qualify a package, pass a Gate,
promote evidence, build a release, or contact live/production state.
"""

from __future__ import annotations

import fnmatch
import hashlib
import json
import os
import plistlib
import re
import shutil
import signal
import subprocess
import tempfile
import time
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Sequence


DEFAULT_BINDING_RELATIVE_PATH = Path(".ai_dev_os/capability_bindings.json")
DEFAULT_MAX_OUTPUT_BYTES = 128 * 1024
DEFAULT_TIMEOUT_SECONDS = 30.0
SUPPORTED_LAUNCH_MODES = {"direct", "macos_launchservices"}
_ANSI_ESCAPE_PATTERN = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
_KNOWN_IMPORT_PROGRESS_ERROR_MESSAGES = (
    "do not use progress dialog (task) while flushing the message queue or using call_deferred()!",
    'condition "!tasks.has(p_task)" is true. returning: canceled',
    'condition "!tasks.has(p_task)" is true.',
)

_HARD_FORBIDDEN_WRITE_PREFIXES = (
    ".git",
    ".godot",
    ".ai_dev_os",
)
_HARD_FORBIDDEN_WRITE_PATHS = {
    "project.godot",
}


class GodotExecutionAdapterError(RuntimeError):
    """Base error for invalid adapter inputs or execution boundaries."""


class ProjectBoundaryError(GodotExecutionAdapterError):
    """Raised when a project path or resource escapes the selected project."""


class CapabilityBindingError(GodotExecutionAdapterError):
    """Raised when the Godot binary or Skill binding cannot be resolved."""


class WriteEnvelopeError(GodotExecutionAdapterError):
    """Raised when a proposed production write is outside both envelopes."""


@dataclass(frozen=True)
class GodotCommandResult:
    """One attributable Godot tool result.

    ``status`` is a factual tool outcome only.  It is not a QA, Human,
    qualification, Gate, Pack-promotion, or release verdict.
    """

    schema_version: str
    artifact_type: str
    run_id: str
    task_id: str
    attempt_id: int
    actor_id: str
    agent_id: str
    skill_id: str
    operation: str
    project_root: str
    command: tuple[str, ...]
    started_at: str
    duration_ms: int
    exit_code: int | None
    status: str
    failure_kind: str | None
    expected_pass_token: str | None
    pass_token_observed: bool | None
    stdout: str
    stderr: str
    stdout_truncated: bool
    stderr_truncated: bool
    timed_out: bool
    ignored_diagnostic_count: int
    ignored_diagnostic_messages: tuple[str, ...]
    non_claims: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["command"] = list(self.command)
        value["ignored_diagnostic_messages"] = list(
            self.ignored_diagnostic_messages
        )
        value["non_claims"] = list(self.non_claims)
        return value


def _read_json_object(path: Path, *, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise CapabilityBindingError(f"missing {label}: {path}") from exc
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise CapabilityBindingError(f"invalid {label}: {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise CapabilityBindingError(f"{label} must be a JSON object: {path}")
    return value


def _contract_list(
    contract: dict[str, Any],
    *,
    canonical_field: str,
    legacy_field: str,
    label: str,
    require_nonempty: bool,
) -> list[Any]:
    """Read one canonical v4.97 field or its inherited legacy spelling.

    When both spellings are present they must be byte-equivalent.  Supporting
    the canonical shape here is Adapter rendering compatibility; it does not
    add paths or turn either contract into execution authority.
    """

    canonical = contract.get(canonical_field)
    legacy = contract.get(legacy_field)
    if canonical is not None and legacy is not None and canonical != legacy:
        raise CapabilityBindingError(
            f"{label} has conflicting {canonical_field} and {legacy_field}"
        )
    selected = canonical if canonical is not None else legacy
    if selected is None and not require_nonempty:
        return []
    if not isinstance(selected, list) or (require_nonempty and not selected):
        qualifier = "non-empty " if require_nonempty else ""
        raise CapabilityBindingError(f"{label} must declare a {qualifier}list")
    return selected


def _contract_pack_id(contract: dict[str, Any], *, label: str) -> str:
    canonical = contract.get("pack_id")
    legacy = contract.get("primary_pack")
    if canonical is not None and legacy is not None and canonical != legacy:
        raise CapabilityBindingError(
            f"{label} has conflicting pack_id and primary_pack"
        )
    selected = canonical if canonical is not None else legacy
    if not isinstance(selected, str) or not selected.strip():
        raise CapabilityBindingError(f"{label} has no pack identity")
    return selected.strip()


def _normalize_pattern(pattern: str) -> str:
    if not isinstance(pattern, str) or not pattern.strip():
        raise CapabilityBindingError("write patterns must be non-empty strings")
    normalized = pattern.strip().replace("\\", "/")
    if normalized.startswith("res://"):
        normalized = normalized[len("res://") :]
    if normalized.startswith("/"):
        raise CapabilityBindingError(f"unsafe write pattern: {pattern!r}")
    while normalized.startswith("./"):
        normalized = normalized[2:]
    parts = PurePosixPath(normalized).parts
    if ".." in parts or "\x00" in normalized:
        raise CapabilityBindingError(f"unsafe write pattern: {pattern!r}")
    return normalized


def _matches_any(relative_path: str, patterns: Sequence[str]) -> bool:
    return any(
        fnmatch.fnmatchcase(relative_path, _normalize_pattern(pattern))
        for pattern in patterns
    )


def _truncate_output(raw: bytes, limit: int) -> tuple[str, bool]:
    truncated = len(raw) > limit
    if truncated:
        raw = raw[:limit]
    return raw.decode("utf-8", errors="replace"), truncated


def _regular_file_identity(path: Path) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file():
        raise CapabilityBindingError(f"tool identity path is not a regular file: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return {
        "path": str(path),
        "byte_count": path.stat().st_size,
        "content_sha256": digest.hexdigest(),
    }


def _classify_failure(stderr: str, stdout: str) -> str:
    combined = f"{stderr}\n{stdout}".lower()
    if "parse error" in combined or "parser error" in combined:
        return "script_parse_error"
    if (
        "failed loading resource" in combined
        or "failed to load resource" in combined
        or "could not load resource" in combined
        or "can't open" in combined
        or "cannot open file" in combined
    ):
        return "resource_load_error"
    if "command not found" in combined or "no such file or directory" in combined:
        return "tool_unavailable"
    return "command_failed"


def _scan_error_diagnostics(
    stderr: str,
    stdout: str,
    *,
    ignored_error_messages: Sequence[str] = (),
) -> tuple[bool, tuple[str, ...]]:
    """Classify Godot diagnostics and retain each exact ignored message."""

    has_unignored_error = False
    ignored_messages: list[str] = []
    for line in f"{stderr}\n{stdout}".splitlines():
        normalized = _ANSI_ESCAPE_PATTERN.sub("", line).strip().lower()
        if normalized.startswith(("error:", "script error:", "parse error:")):
            prefix, _, message = normalized.partition(":")
            normalized_message = message.strip()
            if prefix == "error" and normalized_message in ignored_error_messages:
                ignored_messages.append(normalized_message)
                continue
            has_unignored_error = True
        if "project export for preset" in normalized and "failed" in normalized:
            has_unignored_error = True
    return has_unignored_error, tuple(ignored_messages)


class GodotExecutionAdapter:
    """Typed, bounded Godot tool surface for one task attempt."""

    def __init__(
        self,
        *,
        project_root: str | Path,
        task_id: str,
        attempt_id: int,
        actor_id: str,
        agent_contract_path: str | Path,
        skill_contract_path: str | Path,
        declared_write_patterns: Sequence[str],
        agent_id: str | None = None,
        godot_binary: str | Path | None = None,
        launch_mode: str = "direct",
        macos_open_binary: str | Path = "/usr/bin/open",
        godot_app_bundle: str | Path | None = None,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
        max_output_bytes: int = DEFAULT_MAX_OUTPUT_BYTES,
    ) -> None:
        self.project_root = Path(project_root).resolve(strict=True)
        if not self.project_root.is_dir():
            raise ProjectBoundaryError(
                f"selected project root is not a directory: {self.project_root}"
            )
        self._project_marker = self._resolve_existing_project_path("project.godot")
        if not self._project_marker.is_file():
            raise ProjectBoundaryError(
                f"selected project has no regular project.godot: {self.project_root}"
            )

        self.task_id = self._required_identifier(task_id, "task_id")
        self.actor_id = self._required_identifier(actor_id, "actor_id")
        if not isinstance(attempt_id, int) or isinstance(attempt_id, bool) or attempt_id < 1:
            raise ValueError("attempt_id must be an integer >= 1")
        self.attempt_id = attempt_id

        if not declared_write_patterns:
            raise WriteEnvelopeError("declared_write_patterns must not be empty")
        self.declared_write_patterns = tuple(
            _normalize_pattern(pattern) for pattern in declared_write_patterns
        )

        self.agent_contract_path = Path(agent_contract_path).resolve(strict=True)
        self.agent_contract = _read_json_object(
            self.agent_contract_path,
            label="Production Agent contract",
        )
        contract_agent_id = self._required_identifier(
            str(self.agent_contract.get("agent_id", "")),
            "agent_contract.agent_id",
        )
        if agent_id is not None and self._required_identifier(agent_id, "agent_id") != contract_agent_id:
            raise CapabilityBindingError(
                "selected agent_id does not match Production Agent contract"
            )
        self.agent_id = contract_agent_id
        agent_allowed = _contract_list(
            self.agent_contract,
            canonical_field="allowed_write_patterns",
            legacy_field="can_modify",
            label="Production Agent contract write allowance",
            require_nonempty=True,
        )
        agent_forbidden = _contract_list(
            self.agent_contract,
            canonical_field="forbidden_write_patterns",
            legacy_field="must_not_modify",
            label="Production Agent contract write prohibition",
            require_nonempty=False,
        )
        self.agent_allowed_write_patterns = tuple(
            _normalize_pattern(pattern) for pattern in agent_allowed
        )
        self.agent_forbidden_write_patterns = tuple(
            _normalize_pattern(pattern) for pattern in agent_forbidden
        )

        self.skill_contract_path = Path(skill_contract_path).resolve(strict=True)
        self.skill_contract = _read_json_object(
            self.skill_contract_path,
            label="Production Skill contract",
        )
        self.skill_id = self._required_identifier(
            str(self.skill_contract.get("skill_id", "")),
            "skill_contract.skill_id",
        )
        allowed = _contract_list(
            self.skill_contract,
            canonical_field="allowed_write_patterns",
            legacy_field="allowed_writes",
            label="Production Skill contract write allowance",
            require_nonempty=True,
        )
        forbidden = _contract_list(
            self.skill_contract,
            canonical_field="forbidden_write_patterns",
            legacy_field="forbidden_writes",
            label="Production Skill contract write prohibition",
            require_nonempty=False,
        )
        self.skill_allowed_write_patterns = tuple(
            _normalize_pattern(pattern) for pattern in allowed
        )
        self.skill_forbidden_write_patterns = tuple(
            _normalize_pattern(pattern) for pattern in forbidden
        )
        agent_pack = self._required_identifier(
            _contract_pack_id(self.agent_contract, label="Production Agent contract"),
            "agent_contract.pack_id",
        )
        skill_pack = self._required_identifier(
            _contract_pack_id(self.skill_contract, label="Production Skill contract"),
            "skill_contract.pack_id",
        )
        if agent_pack != skill_pack:
            raise CapabilityBindingError(
                "Production Agent and Skill contracts name different packs"
            )
        self.pack_id = agent_pack

        if not isinstance(timeout_seconds, (int, float)) or timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be > 0")
        if not isinstance(max_output_bytes, int) or max_output_bytes < 1024:
            raise ValueError("max_output_bytes must be an integer >= 1024")
        self.timeout_seconds = float(timeout_seconds)
        self.max_output_bytes = max_output_bytes
        self.godot_binary = self._resolve_godot_binary(godot_binary)
        if launch_mode not in SUPPORTED_LAUNCH_MODES:
            raise CapabilityBindingError(
                f"unsupported Godot launch_mode: {launch_mode!r}"
            )
        self.launch_mode = launch_mode
        self.macos_open_binary: Path | None = None
        self.godot_app_bundle: Path | None = None
        if self.launch_mode == "macos_launchservices":
            self.macos_open_binary = self._resolve_executable_path(
                macos_open_binary,
                label="macos_open_binary",
            )
            if godot_app_bundle is None:
                try:
                    candidate_bundle = self.godot_binary.parents[2]
                except IndexError as exc:
                    raise CapabilityBindingError(
                        "cannot derive a macOS app bundle from godot_binary"
                    ) from exc
            else:
                candidate_bundle = Path(godot_app_bundle)
            resolved_bundle = candidate_bundle.resolve(strict=True)
            if not resolved_bundle.is_dir() or resolved_bundle.suffix != ".app":
                raise CapabilityBindingError(
                    f"Godot app bundle is not a .app directory: {resolved_bundle}"
                )
            expected_binary_root = resolved_bundle / "Contents" / "MacOS"
            try:
                self.godot_binary.relative_to(expected_binary_root)
            except ValueError as exc:
                raise CapabilityBindingError(
                    "godot_binary is not inside the selected Godot app bundle"
                ) from exc
            self.godot_app_bundle = resolved_bundle

    @staticmethod
    def _required_identifier(value: str, label: str) -> str:
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{label} must be a non-empty string")
        if "\x00" in value:
            raise ValueError(f"{label} contains a NUL byte")
        return value.strip()

    def _resolve_godot_binary(self, requested: str | Path | None) -> Path:
        if requested is None:
            binding_path = self.project_root / DEFAULT_BINDING_RELATIVE_PATH
            binding = _read_json_object(binding_path, label="capability binding")
            requested = binding.get("godot_binary")
        if isinstance(requested, Path):
            raw = str(requested)
        elif isinstance(requested, str):
            raw = requested.strip()
        else:
            raise CapabilityBindingError("godot_binary must be a path or command name")
        if not raw or "\x00" in raw:
            raise CapabilityBindingError("godot_binary must be a non-empty safe string")

        candidate = Path(raw)
        if candidate.is_absolute():
            resolved = candidate.resolve(strict=True)
        else:
            if "/" in raw or "\\" in raw:
                raise CapabilityBindingError(
                    "relative godot_binary paths are forbidden; use an absolute path "
                    "or a PATH command name"
                )
            found = shutil.which(raw)
            if found is None:
                raise CapabilityBindingError(f"Godot executable is unavailable: {raw}")
            resolved = Path(found).resolve(strict=True)
        if not resolved.is_file() or not os.access(resolved, os.X_OK):
            raise CapabilityBindingError(
                f"Godot executable is not an executable file: {resolved}"
            )
        return resolved

    @staticmethod
    def _resolve_executable_path(
        requested: str | Path,
        *,
        label: str,
    ) -> Path:
        raw = str(requested).strip()
        if not raw or "\x00" in raw:
            raise CapabilityBindingError(f"{label} must be a non-empty safe path")
        candidate = Path(raw)
        if candidate.is_absolute():
            resolved = candidate.resolve(strict=True)
        else:
            if "/" in raw or "\\" in raw:
                raise CapabilityBindingError(
                    f"relative {label} paths are forbidden"
                )
            found = shutil.which(raw)
            if found is None:
                raise CapabilityBindingError(f"{label} is unavailable: {raw}")
            resolved = Path(found).resolve(strict=True)
        if not resolved.is_file() or not os.access(resolved, os.X_OK):
            raise CapabilityBindingError(
                f"{label} is not an executable file: {resolved}"
            )
        return resolved

    def _normalize_project_relative(self, raw_path: str | Path) -> str:
        raw = str(raw_path).replace("\\", "/")
        if raw.startswith("res://"):
            raw = raw[len("res://") :]
        if not raw or raw.startswith("/") or "\x00" in raw:
            raise ProjectBoundaryError(f"unsafe project-relative path: {raw_path!r}")
        pure = PurePosixPath(raw)
        if ".." in pure.parts or pure.is_absolute():
            raise ProjectBoundaryError(f"path escapes selected project: {raw_path!r}")
        normalized = pure.as_posix()
        while normalized.startswith("./"):
            normalized = normalized[2:]
        if not normalized:
            raise ProjectBoundaryError(f"empty project-relative path: {raw_path!r}")
        return normalized

    def _resolve_project_path(self, raw_path: str | Path) -> tuple[str, Path]:
        relative = self._normalize_project_relative(raw_path)
        candidate = (self.project_root / relative).resolve(strict=False)
        try:
            candidate.relative_to(self.project_root)
        except ValueError as exc:
            raise ProjectBoundaryError(
                f"resolved path escapes selected project: {raw_path!r}"
            ) from exc
        return relative, candidate

    def _resolve_existing_project_path(self, raw_path: str | Path) -> Path:
        _relative, candidate = self._resolve_project_path(raw_path)
        if not candidate.exists():
            raise ProjectBoundaryError(f"project path does not exist: {raw_path!r}")
        return candidate

    def authorize_write(self, raw_path: str | Path) -> str:
        """Return the normalized path only when both write envelopes allow it.

        The caller's declared write set is the task-specific envelope.  The
        Agent and Skill contracts are additional upper bounds.  None is
        authority by itself; the host remains responsible for selecting an
        authorized task.
        """

        relative, _candidate = self._resolve_project_path(raw_path)
        parts = PurePosixPath(relative).parts
        if relative in _HARD_FORBIDDEN_WRITE_PATHS or any(
            parts and parts[0] == prefix for prefix in _HARD_FORBIDDEN_WRITE_PREFIXES
        ):
            raise WriteEnvelopeError(f"hard-forbidden production write: {relative}")
        if _matches_any(relative, self.skill_forbidden_write_patterns):
            raise WriteEnvelopeError(f"Skill-forbidden production write: {relative}")
        if _matches_any(relative, self.agent_forbidden_write_patterns):
            raise WriteEnvelopeError(f"Agent-forbidden production write: {relative}")
        if not _matches_any(relative, self.declared_write_patterns):
            raise WriteEnvelopeError(
                f"write is outside the task-declared envelope: {relative}"
            )
        if not _matches_any(relative, self.skill_allowed_write_patterns):
            raise WriteEnvelopeError(
                f"write is outside the selected Skill envelope: {relative}"
            )
        if not _matches_any(relative, self.agent_allowed_write_patterns):
            raise WriteEnvelopeError(
                f"write is outside the selected Agent envelope: {relative}"
            )
        return relative

    def preflight(self) -> dict[str, Any]:
        version = self._run(
            operation="godot_version",
            arguments=("--version",),
            expected_pass_token=None,
        )
        app_bundle_identity: dict[str, Any] | None = None
        if self.godot_app_bundle is not None:
            info_plist = self.godot_app_bundle / "Contents" / "Info.plist"
            try:
                with info_plist.open("rb") as handle:
                    info = plistlib.load(handle)
            except (OSError, plistlib.InvalidFileException) as exc:
                raise CapabilityBindingError(
                    f"cannot read Godot app bundle identity: {info_plist}: {exc}"
                ) from exc
            app_bundle_identity = {
                "path": str(self.godot_app_bundle),
                "bundle_identifier": info.get("CFBundleIdentifier"),
                "short_version": info.get("CFBundleShortVersionString"),
                "build_version": info.get("CFBundleVersion"),
                "info_plist": _regular_file_identity(info_plist),
            }
        return {
            "schema_version": "1.0.0",
            "artifact_type": "godot_execution_preflight",
            "task_id": self.task_id,
            "attempt_id": self.attempt_id,
            "actor_id": self.actor_id,
            "agent_id": self.agent_id,
            "agent_status": self.agent_contract.get(
                "lifecycle_status", self.agent_contract.get("status", "unknown")
            ),
            "skill_id": self.skill_id,
            "skill_status": self.skill_contract.get(
                "lifecycle_status", self.skill_contract.get("status", "unknown")
            ),
            "pack_id": self.pack_id,
            "project_root": str(self.project_root),
            "project_marker": str(self._project_marker),
            "godot_binary": str(self.godot_binary),
            "godot_binary_identity": _regular_file_identity(self.godot_binary),
            "godot_app_bundle_identity": app_bundle_identity,
            "launch_mode": self.launch_mode,
            "status": "ready" if version.status == "pass" else "blocked",
            "version_probe": version.to_dict(),
            "write_envelope_semantics": "task_agent_and_skill_intersection_only",
            "non_claims": [
                "agent_status_is_not_execution_authority",
                "skill_status_is_not_execution_authority",
                "preflight_is_not_qualification",
                "preflight_is_not_gate_or_release_evidence",
            ],
        }

    def run_project_load(self) -> GodotCommandResult:
        """Load the project only after Godot has completed pending imports."""

        return self._run(
            operation="project_load",
            arguments=(
                "--headless",
                "--path",
                str(self.project_root),
                "--import",
            ),
            expected_pass_token=None,
            fail_on_error_diagnostic=True,
            ignored_error_messages=_KNOWN_IMPORT_PROGRESS_ERROR_MESSAGES,
        )

    def run_script(
        self,
        script_path: str | Path,
        *,
        expected_pass_token: str | None = None,
    ) -> GodotCommandResult:
        relative = self._normalize_project_relative(script_path)
        source = self._resolve_existing_project_path(relative)
        if not source.is_file() or source.suffix.lower() != ".gd":
            raise ProjectBoundaryError(
                f"Godot script must be an existing .gd file: {relative}"
            )
        return self._run(
            operation="script",
            arguments=(
                "--headless",
                "--path",
                str(self.project_root),
                "--script",
                f"res://{relative}",
            ),
            expected_pass_token=expected_pass_token,
        )

    def run_scene(
        self,
        scene_path: str | Path,
        *,
        expected_pass_token: str | None = None,
    ) -> GodotCommandResult:
        relative = self._normalize_project_relative(scene_path)
        source = self._resolve_existing_project_path(relative)
        if not source.is_file() or source.suffix.lower() not in {".tscn", ".scn"}:
            raise ProjectBoundaryError(
                f"Godot scene must be an existing .tscn or .scn file: {relative}"
            )
        return self._run(
            operation="scene",
            arguments=(
                "--headless",
                "--path",
                str(self.project_root),
                f"res://{relative}",
                "--quit",
            ),
            expected_pass_token=expected_pass_token,
        )

    def _resolve_external_artifact_output(
        self,
        raw_path: str | Path,
        *,
        allowed_artifact_root: str | Path,
        required_suffix: str,
    ) -> Path:
        artifact_root = Path(allowed_artifact_root)
        if not artifact_root.is_absolute() or "\x00" in str(artifact_root):
            raise ProjectBoundaryError(
                "allowed artifact root must be an absolute safe path"
            )
        artifact_root = artifact_root.resolve(strict=True)
        if not artifact_root.is_dir():
            raise ProjectBoundaryError(
                f"allowed artifact root is not a directory: {artifact_root}"
            )
        try:
            artifact_root.relative_to(self.project_root)
        except ValueError:
            pass
        else:
            raise ProjectBoundaryError(
                "allowed artifact root must stay outside the project root"
            )
        candidate = Path(raw_path)
        if not candidate.is_absolute() or "\x00" in str(candidate):
            raise ProjectBoundaryError(
                "development-build output must be an absolute safe path"
            )
        resolved = candidate.resolve(strict=False)
        try:
            resolved.relative_to(self.project_root)
        except ValueError:
            pass
        else:
            raise ProjectBoundaryError(
                "development-build output must stay outside the project root"
            )
        try:
            resolved.relative_to(artifact_root)
        except ValueError as exc:
            raise ProjectBoundaryError(
                "development-build output is outside the allowed artifact root"
            ) from exc
        if resolved.suffix.lower() != required_suffix:
            raise ProjectBoundaryError(
                f"development-build output must end with {required_suffix}: {resolved}"
            )
        if not resolved.parent.is_dir():
            raise ProjectBoundaryError(
                f"development-build output parent does not exist: {resolved.parent}"
            )
        if resolved.exists():
            raise ProjectBoundaryError(
                f"development-build output already exists: {resolved}"
            )
        return resolved

    def run_export_debug(
        self,
        preset_name: str,
        output_path: str | Path,
        *,
        allowed_artifact_root: str | Path,
    ) -> GodotCommandResult:
        """Export one fresh macOS development app outside the project tree."""

        preset = self._required_identifier(preset_name, "preset_name")
        output = self._resolve_external_artifact_output(
            output_path,
            allowed_artifact_root=allowed_artifact_root,
            required_suffix=".app",
        )
        return self._run(
            operation="export_debug",
            arguments=(
                "--headless",
                "--path",
                str(self.project_root),
                "--export-debug",
                preset,
                str(output),
            ),
            expected_pass_token=None,
            fail_on_error_diagnostic=True,
        )

    def run_export_pack(
        self,
        preset_name: str,
        output_path: str | Path,
        *,
        allowed_artifact_root: str | Path,
    ) -> GodotCommandResult:
        """Export one fresh PCK outside the project tree."""

        preset = self._required_identifier(preset_name, "preset_name")
        output = self._resolve_external_artifact_output(
            output_path,
            allowed_artifact_root=allowed_artifact_root,
            required_suffix=".pck",
        )
        return self._run(
            operation="export_pack",
            arguments=(
                "--headless",
                "--path",
                str(self.project_root),
                "--export-pack",
                preset,
                str(output),
            ),
            expected_pass_token=None,
            fail_on_error_diagnostic=True,
        )

    def run_main_pack(
        self,
        pack_path: str | Path,
        *,
        allowed_artifact_root: str | Path,
        quit_after: int = 10,
    ) -> GodotCommandResult:
        """Load a built PCK through the selected Godot engine."""

        artifact_root = Path(allowed_artifact_root).resolve(strict=True)
        if not artifact_root.is_dir():
            raise ProjectBoundaryError(
                f"allowed artifact root is not a directory: {artifact_root}"
            )
        pack = Path(pack_path).resolve(strict=True)
        if not pack.is_file() or pack.suffix.lower() != ".pck":
            raise ProjectBoundaryError(f"built pack is not a .pck file: {pack}")
        try:
            pack.relative_to(artifact_root)
        except ValueError as exc:
            raise ProjectBoundaryError(
                f"built pack is outside the allowed artifact root: {pack}"
            ) from exc
        if not isinstance(quit_after, int) or isinstance(quit_after, bool) or quit_after < 1:
            raise ValueError("quit_after must be an integer >= 1")
        return self._run(
            operation="main_pack_launch",
            arguments=(
                "--headless",
                "--main-pack",
                str(pack),
                "--quit-after",
                str(quit_after),
            ),
            expected_pass_token=None,
            fail_on_error_diagnostic=True,
        )

    def _run(
        self,
        *,
        operation: str,
        arguments: Sequence[str],
        expected_pass_token: str | None,
        fail_on_error_diagnostic: bool = False,
        ignored_error_messages: Sequence[str] = (),
    ) -> GodotCommandResult:
        if expected_pass_token is not None:
            expected_pass_token = self._required_identifier(
                expected_pass_token,
                "expected_pass_token",
            )
        raw_arguments = tuple(str(item) for item in arguments)
        temporary_log_directory = None
        launch_log_path: Path | None = None
        if self.launch_mode == "macos_launchservices":
            if "--log-file" in raw_arguments:
                raise CapabilityBindingError(
                    "caller-supplied --log-file is forbidden in LaunchServices mode"
                )
            assert self.macos_open_binary is not None
            assert self.godot_app_bundle is not None
            temporary_log_directory = tempfile.TemporaryDirectory(
                prefix="ai-dev-os-godot-launch-"
            )
            launch_log_path = (
                Path(temporary_log_directory.name) / "godot-command.log"
            )
            command = (
                str(self.macos_open_binary),
                "-W",
                "-n",
                str(self.godot_app_bundle),
                "--args",
                *raw_arguments,
                "--log-file",
                str(launch_log_path),
            )
        else:
            command = (str(self.godot_binary), *raw_arguments)
        started_at = datetime.now(timezone.utc).isoformat()
        started = time.monotonic()
        timed_out = False
        exit_code: int | None = None
        stdout_bytes = b""
        stderr_bytes = b""

        try:
            process = subprocess.Popen(
                command,
                cwd=self.project_root,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                shell=False,
                start_new_session=(os.name == "posix"),
            )
            try:
                stdout_bytes, stderr_bytes = process.communicate(
                    timeout=self.timeout_seconds
                )
                exit_code = process.returncode
            except subprocess.TimeoutExpired:
                timed_out = True
                self._terminate_process(process)
                stdout_bytes, stderr_bytes = process.communicate()
                exit_code = process.returncode
            if launch_log_path is not None and launch_log_path.is_file():
                launch_bytes = launch_log_path.read_bytes()
                if stdout_bytes and launch_bytes:
                    launch_bytes += b"\n"
                stdout_bytes = launch_bytes + stdout_bytes
        finally:
            if temporary_log_directory is not None:
                temporary_log_directory.cleanup()

        duration_ms = max(0, round((time.monotonic() - started) * 1000))
        stdout, stdout_truncated = _truncate_output(
            stdout_bytes,
            self.max_output_bytes,
        )
        stderr, stderr_truncated = _truncate_output(
            stderr_bytes,
            self.max_output_bytes,
        )
        has_unignored_error, ignored_diagnostic_messages = (
            _scan_error_diagnostics(
                stderr,
                stdout,
                ignored_error_messages=ignored_error_messages,
            )
        )
        observed: bool | None = None
        failure_kind: str | None = None
        if timed_out:
            status = "timeout"
            failure_kind = "timeout"
        elif exit_code is not None and exit_code < 0:
            status = "fail"
            failure_kind = "process_signaled"
        elif exit_code != 0:
            status = "fail"
            failure_kind = _classify_failure(stderr, stdout)
        elif fail_on_error_diagnostic and has_unignored_error:
            status = "fail"
            failure_kind = _classify_failure(stderr, stdout)
        elif expected_pass_token is not None:
            observed = expected_pass_token in stdout or expected_pass_token in stderr
            if observed:
                status = "pass"
            else:
                status = "fail"
                failure_kind = "missing_pass_token"
        else:
            status = "pass"

        return GodotCommandResult(
            schema_version="1.0.0",
            artifact_type="godot_command_result",
            run_id=f"godot-run-{uuid.uuid4().hex}",
            task_id=self.task_id,
            attempt_id=self.attempt_id,
            actor_id=self.actor_id,
            agent_id=self.agent_id,
            skill_id=self.skill_id,
            operation=operation,
            project_root=str(self.project_root),
            command=command,
            started_at=started_at,
            duration_ms=duration_ms,
            exit_code=exit_code,
            status=status,
            failure_kind=failure_kind,
            expected_pass_token=expected_pass_token,
            pass_token_observed=observed,
            stdout=stdout,
            stderr=stderr,
            stdout_truncated=stdout_truncated,
            stderr_truncated=stderr_truncated,
            timed_out=timed_out,
            ignored_diagnostic_count=len(ignored_diagnostic_messages),
            ignored_diagnostic_messages=ignored_diagnostic_messages,
            non_claims=(
                "tool_result_is_not_independent_qa",
                "tool_result_is_not_qualification",
                "tool_result_is_not_gate_or_release_authority",
            ),
        )

    @staticmethod
    def _terminate_process(process: subprocess.Popen[bytes]) -> None:
        if process.poll() is not None:
            return
        if os.name == "posix":
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                return
        else:
            process.terminate()
        try:
            process.wait(timeout=1.0)
            return
        except subprocess.TimeoutExpired:
            pass
        if os.name == "posix":
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                return
        else:
            process.kill()
        process.wait(timeout=1.0)
