# Codex Adapter Contract

This directory retains the v4.93 promotion-facing Codex contract and v4.94
non-qualifying development-task surface, then adds the first v4.95 bounded
Production execution surface. It is an Adapter integration layer, not a copy
of the production pack and not an authority source.

Use these files:

- `../../DESIGN_AND_CAPABILITY_ARCHITECTURE.md` - whole-system architecture and
  capability-flow contract Codex must read before routing work.
- `codex_integration_policy.json` - Codex read order, boundaries, evidence,
  validation, and runtime-output policy.
- `codex_invocation_profile.json` - goal-class routing profile from user intent
  to root, Orchestrator, pack, workflow, and validator surfaces.
- `codex_runtime_adapter_contract.md` - human-readable Codex execution contract.
- `production_worker.py` - single-attempt Production Worker with exact declared
  reads, task/Agent/Skill-intersection writes, compare-and-swap replacement,
  and typed Godot operations. It does not invoke an LLM or admit its own task.
- `godot_execution_adapter.py` - shell-free, bounded Godot version/load/script/
  scene/export/packaged-app execution with tool identity, diagnostic-aware
  outcomes, timeouts, and factual command results.
- `godot_development_build.py` - clean-source, double-export macOS development
  delivery with full app/PCK identity, signature and launch checks, isolated
  restore verification, failed-replacement rollback, and an atomic factual
  receipt.
- `godot_focused_qa.py` - clean-Git-source, ordered Godot must-pass execution
  with PASS-token checking, before/after source identity, and atomic external
  `qa_evidence_bundle` output. A changed source becomes `BLOCKED`; a failed
  must-pass check becomes `REVIEW_NEEDED`. Neither result is Human acceptance,
  qualification, Gate, release, or live authority.
- `candidate1_focused_qa_runtime_v1_2_0.py` - Candidate 1 successor wrapper
  that materializes the exact macOS Godot application into each fresh external
  run root before any Godot process starts. Self-contained `_sc_` and
  `editor_data` state remain disposable runtime scratch; the shared support
  root is content-and-metadata checked before and after execution.
- `candidate1_focused_qa_runtime_v1_3_0.py` - terminal-lifecycle successor.
  It delegates exact execution to the unchanged v1.2.0 runtime, retains
  Evidence/logs, and compacts terminal workspace/cache/disposable-Godot bytes
  after a returned terminal result by default. Every raised attempt remains
  for recovery or forensics until explicitly classified and finalized;
  diagnostic retention is also an explicit success-path opt-out. Existing
  exact Assemblies continue to execute their bound v1.2.0 operation and may
  call only the separate finalizer afterward; the wrapper itself requires
  explicit admission by a future invocation envelope.
- `production_cell_composition.py` - engine-neutral four-stage composition
  contract for an implementation checkpoint, target feedback, development
  build, and focused QA. It owns stage ordering, first-non-success short-circuit
  semantics, and a schema-valid factual receipt; it imports no engine adapter
  and writes no project source.
- `production_spec_input_bridge.py` - read-only deterministic bridge from one
  schema-valid `game_design_production_spec` into the composition contract's
  `selected_feature_spec`. The default path maps task identity, title,
  acceptance criteria, source trace, and document provenance. The request must
  explicitly supply feature/profile/source-revision/write-envelope bindings.
  Optional `augmentations` may add input/evidence refs, bind abstract write or
  QA contracts, and carry selected-profile options. They cannot override
  accepted behavior, target another profile, or expand the declared write
  envelope. Profile-specific option validation remains profile-owned.
- `godot_local_development_profile.py` - the only v4.95 concrete composition
  profile. It verifies a clean committed Worker-bound implementation checkpoint,
  then binds the existing Godot feedback, macOS development-build, and focused-
  QA primitives. The checkpoint does not claim that the profile authored or
  committed the implementation.
- `../../scripts/development/run_godot_development_build.py` - reusable CLI for
  that development-build delivery. It creates no qualification, Gate, release,
  or authority result.
- `../../scripts/development/run_godot_focused_qa.py` - reusable CLI for the
  focused-QA runner; its byte-identical Pack-layer surface is
  `../../pack_layer/scripts/development/run_godot_focused_qa.py`. Evidence must
  be written outside the selected source repository.
- `bindings/godot_runtime_feature_slice.binding.json` - machine-readable
  binding from the existing Godot Production Agent/Skill pair to the worker
  and engine operations. Binding status restricts execution; it grants none.
- `bindings/godot_focused_qa.binding.json` - machine-readable binding from the
  existing Focused QA Agent/Skill pair to the focused-QA runner and Godot
  adapter. It contains no production-source write operation and grants no
  authority.
- `bindings/godot_production_spec_input.binding.json` - the concrete Godot
  compatibility route from a full Production Spec into
  `godot_local_development_v1`. It owns accepted handoff routes and points to,
  but does not alter, the independently identified composition profile binding.
  This separation preserves historical profile-replay evidence identity.
- `bindings/godot_local_development.profile.json` - machine-readable concrete
  composition profile binding. Godot-specific backend references stay here and
  in the concrete profile; the composition and input-bridge cores remain
  engine-neutral.
- `examples/production_spec_input_bridge_request.example.json` - minimal
  request example. Omitting `augmentations` selects the default mapping path.
- `development_project_evidence.py` - project-local Evidence Continuity MVP.
  It copies only explicitly allowlisted files up to 2 MiB into immutable
  SHA-256-addressed objects, writes stable immutable Evidence records, verifies
  records and objects without an index, rebuilds a disposable metadata-keyword
  index only on request, and assembles deterministic advisory evolve-input
  bundles from verified Evidence. Registration, verification, retrieval, and
  bundling grant no Human, qualification, Gate, release, or live authority.
- `development_project_memory.py` - preserves the v4.94 explicit closed-task
  memory path and adds format-v2 promotion from verified same-task,
  same-source-revision Evidence. Promotion remains an explicit curation action;
  search never injects memory into task context automatically.
- `team_memory_provider.py` - optional, default-off Provider contract and
  failure-isolating client bound to one exact project/team scope.
- `local_team_memory_provider.py` - same-host reference Provider. Its state is
  coordinator-owned and remains outside project source; activation, review,
  publish, retrieval, and lifecycle actions are deny-by-default.
- `team_memory_status.py` - read-only function-first projection of Provider
  installation/activation health and the current caller-supplied actor's exact
  permission decisions. It calls no Memory retrieval operation and exposes no
  records, counts, content, or filesystem paths.
- `../../bin/ai-dev-os team-memory status` - package-local human table / agent
  JSON entrypoint for that projection. It does not authenticate the actor,
  mutate Provider state, or grant qualification, Gate, release, or live
  authority.
- `examples/team_memory_status_policy.example.json` and
  `examples/team_memory_status_actor_context.example.json` - generic
  deny-by-default inputs for the status CLI. The example grants only
  read/propose to its exact actor and scope.
- `../../scripts/development/run_project_evidence_continuity.py` - reusable CLI
  for register, exact verify, explicit index rebuild, read-only search,
  evidence-linked memory promotion, and advisory evolve-bundle assembly. Its
  byte-identical Pack-layer mirror is
  `../../pack_layer/scripts/development/run_project_evidence_continuity.py`.
- `development_task_adapter.py` - thin project-local APIs for queueing,
  preparing/starting, selecting/resuming, and claiming development tasks, plus
  independent commit-bound PASS closure or FAIL return-for-rework through
  Runtime State.
  A completion claim requires implementation references bound to one real
  commit whose named paths exist as blobs in the selected project's local Git
  repository; output-only, missing-path, or mixed-commit claims remain ordinary
  work in progress. This check does not require a clean worktree. The
  independent reviewer repeats the same availability check once before
  recording PASS; FAIL remains available to return an unavailable claim for
  repair.
  An interrupted `VERIFIED` to `CLOSED` step can be resumed by the same
  reviewer after its persisted PASS binding is rechecked.
  A reviewer can list currently actionable claimed tasks without locking or
  assigning them. Project-local task, issue and handoff lists use filtered
  100-row pages, so retained terminal objects do not turn the page size into a
  total project limit. Before review, the accountable producer or latest claimant
  may withdraw its completion claim for ordinary rework without Human
  disposition. `begin_task()` remains the create-and-start shortcut;
  `queue_task()` keeps future work in `CREATED`, while `prepare_task()` and
  `start_task()` execute the existing resumable actions without creating a
  second queue model. A fresh session may auto-select only when exactly one
  unfinished task exists;
  otherwise it must use an explicit task ID. The producer adapter can also
  persist linked blockers, resolve them, and resume work when no active
  blockers remain. Its optional Git inspection reports the current branch,
  HEAD, and project-local changes without requiring a clean worktree or a Git
  repository. Development
  handoffs may be sent, discovered by the named recipient, accepted and
  completed without transferring the source task's accountable producer. The
  recipient may also reject a sent handoff or return accepted work with a
  reason. An on-demand resume context combines the selected task, active
  blockers, open and assigned handoffs, and the Git observation without
  persisting a new checkpoint. It also derives the current development attempt
  from existing transition history and binds only progress recorded during
  that attempt; no attempt object or retry ledger is created. When several
  unfinished tasks exist, `list_resume_candidates()` exposes their title,
  feature, state, owner, next action and current attempt for explicit selection
  without choosing or updating a task. Local
  `project://` and revision-bound
  `git://...@<commit>/...`
  task inputs can be inspected for presence or change; other reference schemes
  remain explicitly uninspectable rather than being rejected. An on-demand
  task readset can load bounded UTF-8 content from only those explicit local
  and exact Git inputs; it never scans the whole project and is not loaded by
  default during resume. A caller that needs a directly usable recovery view
  may explicitly pass `include_input_contents=True` to `get_resume_context()`;
  the returned readset uses the same selected task and Git observation. An
  on-demand impact preview scans unfinished tasks and groups only their changed
  or missing inspectable inputs; it does not mark tasks stale or block work. An
  externally supplied exact Git revision change may be applied to unfinished
  tasks that still name the old revision. Unstarted tasks are rebound directly;
  started or claimed tasks receive one idempotent revalidation blocker. This
  consumes a change decision made outside the adapter and does not create or
  imply Human approval. Only the accountable producer or latest claimant may
  complete revalidation, and only while the replacement revision still matches
  the project worktree. A selected Pack-layer `production_spec_patch` object
  can use the same path through a thin bridge that reads its existing identity
  and accepted behavior summary. The bridge does not validate the artifact or
  assert its approval. An active task may also store one latest-only progress
  summary and next step so a later session can resume without creating a
  separate event ledger. `checkpoint_for_interruption()` combines that same
  progress write with a fresh resume context; an exact retry in the same
  attempt reuses the saved revision. It is not a snapshot or backup.
  Obsolete unfinished tasks may be cancelled by the accountable producer or
  latest claimant with a reason, removing them from resume selection while
  retaining their record; active handoffs must finish first.
  A closed task can be projected into a read-only development completion
  summary containing its task revision, Git implementation binding,
  independent review, outputs, and close event. The projection creates no
  state object. A caller may explicitly distill that result into one immutable
  project-local development memory; closing a task never promotes it
  automatically. Manual keyword/tag search is bounded and never injects
  results into task context. A read-only production-spec replay can also map an
  explicit old/new Git input pair onto affected tasks and suggest focused
  review actions without rebinding, blocking, reopening, or validating them.
  Historical tasks may be preview-matched through one unambiguous legacy
  commit-prefix plus exact `project://` path pair; this never enables mutating
  propagation from a short ref.
- `examples/codex_project_binding.example.json` - example target-project
  binding shape for `.ai_dev_os/`.
- `examples/real_project_adoption_inputs.example.json` - real-project
  adoption input checklist for Codex-mediated runs.
- `examples/real_project_adoption_inputs.schema.json` - schema for the
  adoption input checklist.

Canonical agents, skills, workflows, schemas, and validators remain in
`pack_layer/` and root compatibility paths. This adapter references those
surfaces; it does not redefine them.

The development-task API writes task state only to the explicitly selected
game project under `.ai_dev_os/development/runtime_state/`. Explicit memory
promotion writes separately under `.ai_dev_os/development/project_memory/`;
that directory is not created by task close, resume, or memory search. Task
revisions and selected memories are operational development context, not
execution-trace, qualification, Gate, or release evidence. Evidence continuity
writes immutable objects, records, and its disposable index under
`.ai_dev_os/development/evidence/` only when explicitly invoked. The MVP is not
a full Evidence Core service, full Project LTM lifecycle, semantic RAG, or an
automatic evolution decision. CLI usage is not required.
