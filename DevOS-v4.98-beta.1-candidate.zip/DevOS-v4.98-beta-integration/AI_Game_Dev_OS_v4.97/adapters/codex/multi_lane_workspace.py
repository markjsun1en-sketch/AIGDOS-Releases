"""Read-only Git workspace identity helpers for concrete lane profiles."""

from __future__ import annotations

import hashlib
import json
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath
from typing import Any

from .multi_lane_coordinator import MultiLaneContractError


class WorkspaceIdentityError(MultiLaneContractError):
    """Raised when a concrete workspace or bound file identity is invalid."""


def required_text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip() or "\x00" in value:
        raise WorkspaceIdentityError(f"{label} must be a non-empty safe string")
    return value.strip()


def absolute_existing_path(value: str | Path, label: str) -> Path:
    try:
        path = Path(value)
    except TypeError as exc:
        raise WorkspaceIdentityError(f"{label} must be a path") from exc
    if not path.is_absolute():
        raise WorkspaceIdentityError(f"{label} must be absolute")
    try:
        return path.resolve(strict=True)
    except OSError as exc:
        raise WorkspaceIdentityError(f"{label} does not exist: {path}") from exc


def project_relative_path(value: str, label: str) -> str:
    relative = required_text(value, label)
    if "\\" in relative or relative.startswith("/"):
        raise WorkspaceIdentityError(
            f"{label} must use project-relative POSIX syntax"
        )
    parts = PurePosixPath(relative).parts
    if not parts or any(part in {"", ".", ".."} for part in parts):
        raise WorkspaceIdentityError(f"{label} is not a safe project-relative path")
    if any(token in relative for token in ("*", "?", "[", "]")):
        raise WorkspaceIdentityError(f"{label} must be an exact path")
    return relative


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def json_file(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise WorkspaceIdentityError(f"{label} is not valid JSON: {path}") from exc
    if not isinstance(value, dict):
        raise WorkspaceIdentityError(f"{label} must contain a JSON object")
    return value


def run_git(
    workspace_root: Path,
    *arguments: str,
    allowed_exit_codes: tuple[int, ...] = (0,),
) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        ("git", "-C", str(workspace_root), *arguments),
        check=False,
        capture_output=True,
        text=True,
        timeout=30,
    )
    if completed.returncode not in allowed_exit_codes:
        message = completed.stderr.strip() or completed.stdout.strip()
        raise WorkspaceIdentityError(
            f"git {' '.join(arguments)} failed with {completed.returncode}: {message}"
        )
    return completed


@dataclass(frozen=True)
class GitWorkspaceObservation:
    workspace_root: str
    repository_root: str
    git_dir: str
    git_common_dir: str
    branch: str
    head: str
    tree: str
    base_revision: str
    base_is_ancestor: bool
    status_lines: tuple[str, ...]
    observed_write_paths: tuple[str, ...]
    commit_revisions: tuple[str, ...]
    diff_check_status: str

    @property
    def isolated_workspace(self) -> bool:
        return self.workspace_root == self.repository_root

    @property
    def clean(self) -> bool:
        return not self.status_lines

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        for key in ("status_lines", "observed_write_paths", "commit_revisions"):
            value[key] = list(value[key])
        value["isolated_workspace"] = self.isolated_workspace
        value["clean"] = self.clean
        return value


def observe_git_workspace(
    workspace_root: str | Path,
    *,
    base_revision: str,
) -> GitWorkspaceObservation:
    """Mechanically observe one exact project worktree without mutation."""

    workspace = absolute_existing_path(workspace_root, "workspace_root")
    if not workspace.is_dir() or not (workspace / "project.godot").is_file():
        raise WorkspaceIdentityError(
            f"workspace is not a concrete Godot project root: {workspace}"
        )
    base = required_text(base_revision, "base_revision")
    repository_root = Path(
        run_git(workspace, "rev-parse", "--show-toplevel").stdout.strip()
    ).resolve(strict=True)
    git_dir = run_git(
        workspace,
        "rev-parse",
        "--path-format=absolute",
        "--git-dir",
    ).stdout.strip()
    common_dir = run_git(
        workspace,
        "rev-parse",
        "--path-format=absolute",
        "--git-common-dir",
    ).stdout.strip()
    run_git(workspace, "rev-parse", "--verify", f"{base}^{{commit}}")
    head = run_git(workspace, "rev-parse", "HEAD").stdout.strip()
    tree = run_git(workspace, "rev-parse", "HEAD^{tree}").stdout.strip()
    branch = run_git(workspace, "branch", "--show-current").stdout.strip() or "HEAD"
    status_lines = tuple(
        line
        for line in run_git(
            workspace,
            "status",
            "--porcelain=v1",
            "--untracked-files=all",
        ).stdout.splitlines()
        if line
    )
    ancestry = run_git(
        workspace,
        "merge-base",
        "--is-ancestor",
        base,
        head,
        allowed_exit_codes=(0, 1),
    )
    raw_paths = run_git(
        workspace,
        "diff",
        "--name-only",
        "--diff-filter=ACDMRTUXB",
        "-z",
        f"{base}..{head}",
    ).stdout
    observed_write_paths = tuple(
        sorted(
            {
                project_relative_path(path, "observed Git path")
                for path in raw_paths.split("\x00")
                if path
            }
        )
    )
    commits = tuple(
        line
        for line in run_git(
            workspace,
            "rev-list",
            "--reverse",
            f"{base}..{head}",
        ).stdout.splitlines()
        if line
    )
    diff_check = run_git(
        workspace,
        "diff",
        "--check",
        f"{base}..{head}",
        allowed_exit_codes=(0, 2),
    )
    return GitWorkspaceObservation(
        workspace_root=str(workspace),
        repository_root=str(repository_root),
        git_dir=git_dir,
        git_common_dir=common_dir,
        branch=branch,
        head=head,
        tree=tree,
        base_revision=base,
        base_is_ancestor=ancestry.returncode == 0,
        status_lines=status_lines,
        observed_write_paths=observed_write_paths,
        commit_revisions=commits,
        diff_check_status="pass" if diff_check.returncode == 0 else "fail",
    )
