"""Codex-facing task lifecycle for a mounted game project in development."""

from __future__ import annotations

import hashlib
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
from typing import Any, Mapping, Sequence

from .development_project_evidence import DevelopmentProjectEvidenceStore
from .development_project_compatibility_migration import (
    DevelopmentProjectCompatibilityMigration,
)
from .development_project_memory import DevelopmentProjectMemoryStore
from .development_project_permissions import (
    ProjectPermissionPolicy,
    ProjectPrincipalContext,
)
from .permission_aware_project_retrieval import (
    PermissionAwareProjectRetrieval,
)
from os_layer.scripts.runtime_state.task_workflow import DevelopmentTaskSession
from os_layer.scripts.runtime_state.truth_invalidation import (
    preview_truth_replacement_impact,
)


_RESUME_ACTIONS = {
    "CREATED": "prepare_task",
    "READY": "start_task",
    "IN_PROGRESS": "continue_task",
    "CLAIMED_DONE": "await_independent_review",
    "VERIFIED": "await_independent_close",
    "REOPENED": "resume_task",
    "BLOCKED": "resolve_blocker",
}
_ASSIGNED_HANDOFF_STATES = frozenset({
    "SENT", "ACCEPTED", "IN_EXECUTION",
})
_GIT_INPUT_REF = re.compile(
    r"git://(?P<repository>[^@\s]+)@(?P<commit>[0-9a-f]{40})/(?P<path>.+)"
)
_LEGACY_GIT_COMMIT_REF = re.compile(
    r"git://(?P<repository>[^@\s]+)@(?P<commit>[0-9a-f]{8,39})"
)
_GIT_IMPLEMENTATION_REF = re.compile(
    r"git://(?P<repository>[^@\s]+)@(?P<commit>[0-9a-f]{40})/(?P<path>\S+)"
)
_INPUT_INSPECTION_STATUSES = (
    "present", "unchanged", "changed", "missing", "uninspectable",
)
_TASK_READSET_MAX_FILES = 8
_TASK_READSET_MAX_FILE_BYTES = 32_768
_TASK_READSET_MAX_TOTAL_BYTES = 98_304


def _single_git_implementation_commit(refs: Any) -> str | None:
    """Return the one commit carried by an all-Git implementation-ref set."""
    if not isinstance(refs, (list, tuple)) or not refs:
        return None
    commits: set[str] = set()
    for value in refs:
        if not isinstance(value, str):
            return None
        match = _GIT_IMPLEMENTATION_REF.fullmatch(value)
        if match is None:
            return None
        commits.add(match.group("commit"))
    if len(commits) != 1:
        return None
    return next(iter(commits))


def _safe_relative_project_path(value: str) -> str | None:
    path = PurePosixPath(value)
    if (
        not value or value.startswith("/")
        or any(character in value for character in ("\x00", "\r", "\n"))
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        return None
    return path.as_posix()


def _git_read_at(
    project_root: Path, *arguments: str,
) -> subprocess.CompletedProcess[str]:
    environment = os.environ.copy()
    environment["GIT_OPTIONAL_LOCKS"] = "0"
    environment["LC_ALL"] = "C"
    return subprocess.run(
        ["git", "-C", str(project_root), *arguments],
        check=False,
        capture_output=True,
        text=True,
        timeout=5,
        env=environment,
    )


def _require_local_git_implementation_refs(
    project_root: Path, refs: Any,
) -> str:
    """Require refs to name real blobs in one selected-project Git commit."""
    claimed_commit = _single_git_implementation_commit(refs)
    if claimed_commit is None:
        raise ValueError("codex_claim_single_git_commit_required")

    parsed_paths: list[str] = []
    for reference in refs:
        match = _GIT_IMPLEMENTATION_REF.fullmatch(reference)
        relative = (
            _safe_relative_project_path(match.group("path"))
            if match is not None else None
        )
        if relative is None:
            raise ValueError("codex_claim_git_path_invalid")
        parsed_paths.append(relative)

    try:
        root_probe = _git_read_at(project_root, "rev-parse", "--show-toplevel")
        if root_probe.returncode != 0:
            raise ValueError(
                "codex_claim_git_context_unavailable:not_git_repository"
            )
        repository_root = Path(root_probe.stdout.strip()).resolve()
        try:
            project_prefix = project_root.relative_to(repository_root)
        except ValueError as error:
            raise ValueError(
                "codex_claim_git_repository_identity_mismatch"
            ) from error
        repository_paths = [
            (
                PurePosixPath(project_prefix.as_posix(), relative).as_posix()
                if project_prefix.parts else relative
            )
            for relative in parsed_paths
        ]

        commit_probe = _git_read_at(
            project_root, "cat-file", "-e", f"{claimed_commit}^{{commit}}",
        )
        if commit_probe.returncode != 0:
            raise ValueError(
                f"codex_claim_git_commit_missing:{claimed_commit}"
            )
        for relative, repository_path in zip(parsed_paths, repository_paths):
            path_probe = _git_read_at(
                project_root, "cat-file", "-t",
                f"{claimed_commit}:{repository_path}",
            )
            if (
                path_probe.returncode != 0
                or path_probe.stdout.strip() != "blob"
            ):
                raise ValueError(f"codex_claim_git_path_missing:{relative}")
    except FileNotFoundError as error:
        raise ValueError(
            "codex_claim_git_context_unavailable:git_unavailable"
        ) from error
    except subprocess.TimeoutExpired as error:
        raise ValueError(
            "codex_claim_git_context_unavailable:inspection_timed_out"
        ) from error
    return claimed_commit


def _latest_task_transition(
    task: Mapping[str, Any], to_state: str,
) -> Mapping[str, Any] | None:
    history = task.get("state_history", [])
    if not isinstance(history, list):
        return None
    for event in reversed(history):
        if isinstance(event, Mapping) and event.get("to") == to_state:
            return event
    return None


def _development_completion_summary(
    task: Mapping[str, Any],
) -> dict[str, Any]:
    """Project a closed task into a small, non-authoritative read model."""
    if task.get("state") != "CLOSED":
        raise ValueError(
            f"codex_completion_summary_state_invalid:{task.get('state')}"
        )

    claim_event = _latest_task_transition(task, "CLAIMED_DONE")
    review_event = _latest_task_transition(task, "VERIFIED")
    close_event = _latest_task_transition(task, "CLOSED")
    if claim_event is None or review_event is None or close_event is None:
        raise ValueError("codex_completion_summary_history_incomplete")
    claim_context = claim_event.get("context")
    review_context = review_event.get("context")
    close_context = close_event.get("context")
    if not all(
        isinstance(context, Mapping)
        for context in (claim_context, review_context, close_context)
    ):
        raise ValueError("codex_completion_summary_context_invalid")

    implementation_refs = task.get("implementation_refs", [])
    output_refs = task.get("output_refs", [])
    implementation_commit = _single_git_implementation_commit(
        implementation_refs,
    )
    reviewed_commit = review_context.get("reviewed_commit")
    reviewer_id = review_context.get("verified_by")
    review_ref = f"review://{reviewer_id}/{reviewed_commit}/PASS"
    if (
        implementation_commit is None
        or claim_context.get("claimed_commit") != implementation_commit
        or reviewed_commit != implementation_commit
        or review_context.get("verdict") != "PASS"
        or review_context.get("scope") != "bounded_functional_review"
        or not isinstance(reviewer_id, str)
        or not isinstance(output_refs, list)
        or review_ref not in output_refs
    ):
        raise ValueError("codex_completion_summary_binding_unavailable")

    return {
        "summary_type": "development_completion_summary",
        "format_version": 1,
        "scope": "project_local_development",
        "task": {
            "object_id": task.get("object_id"),
            "project_id": task.get("project_id"),
            "feature_id": task.get("feature_id"),
            "title": task.get("title"),
            "revision": task.get("revision"),
            "state": "CLOSED",
            "accountable_producer_id": task.get(
                "accountable_producer_id", task.get("owner"),
            ),
        },
        "inputs": list(task.get("input_refs", [])),
        "implementation": {
            "claimed_by": claim_context.get("claimed_by"),
            "commit": implementation_commit,
            "refs": list(implementation_refs),
            "claimed_at": claim_event.get("at"),
        },
        "review": {
            "reviewer_id": reviewer_id,
            "verdict": "PASS",
            "scope": "bounded_functional_review",
            "reviewed_commit": reviewed_commit,
            "finding_counts": dict(review_context.get("finding_counts", {})),
            "ref": review_ref,
            "reviewed_at": review_event.get("at"),
        },
        "outputs": list(output_refs),
        "closed": {
            "closed_by": close_context.get("closed_by"),
            "closed_at": close_event.get("at"),
        },
        "limitations": [
            "development_only",
            "not_qualification",
            "not_gate_or_release",
        ],
    }


class CodexDevelopmentTaskAdapter:
    """Thin Codex workflow over the persistent development task session.

    This adapter can start work and claim it done. It deliberately cannot
    verify, close, qualify, promote, or release a task.
    """

    def __init__(
        self, *, os_layer_root: str | Path, project_root: str | Path,
        project_id: str, actor_id: str,
    ) -> None:
        self._actor_id = actor_id
        self._project_id = project_id
        self._project_root = Path(project_root).resolve()
        self._tasks = DevelopmentTaskSession(
            package_root=os_layer_root,
            project_root=project_root,
            project_id=project_id,
            actor_id=actor_id,
        )

    def start(self) -> "CodexDevelopmentTaskAdapter":
        self._tasks.start()
        return self

    def __enter__(self) -> "CodexDevelopmentTaskAdapter":
        return self.start()

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self._tasks.__exit__(exc_type, exc, traceback)

    @property
    def start_result(self) -> dict[str, Any]:
        return self._tasks.start_result

    def begin_task(
        self, *, title: str, feature_id: str, summary: str = "",
        input_refs: Sequence[str] = (), issue_refs: Sequence[str] = (),
    ) -> dict[str, Any]:
        """Create a task and advance it to the first executable state."""
        task = self.queue_task(
            title=title,
            feature_id=feature_id,
            summary=summary,
            input_refs=input_refs,
            issue_refs=issue_refs,
        )
        ready = self.prepare_task(task["object_id"])
        return self.start_task(ready["object_id"])

    def queue_task(
        self, *, title: str, feature_id: str, summary: str = "",
        input_refs: Sequence[str] = (), issue_refs: Sequence[str] = (),
    ) -> dict[str, Any]:
        """Create a task without starting its development attempt."""
        return self._tasks.create_task(
            title=title,
            feature_id=feature_id,
            summary=summary,
            input_refs=input_refs,
            issue_refs=issue_refs,
        )

    def prepare_task(self, object_id: str) -> dict[str, Any]:
        """Advance one queued task to READY; an exact retry is idempotent."""
        task = self._tasks.get_task(object_id)
        if task["state"] == "READY":
            return task
        if task["state"] != "CREATED":
            raise ValueError(
                f"codex_task_prepare_state_invalid:{task['state']}"
            )
        return self._tasks.transition_task(
            object_id, "READY",
            context={"prepared_by": self._actor_id, "adapter": "codex"},
        )

    def start_task(self, object_id: str) -> dict[str, Any]:
        """Start one READY task; an exact retry is idempotent."""
        task = self._tasks.get_task(object_id)
        if task["state"] == "IN_PROGRESS":
            return task
        if task["state"] != "READY":
            raise ValueError(
                f"codex_task_start_state_invalid:{task['state']}"
            )
        return self._tasks.transition_task(
            object_id, "IN_PROGRESS",
            context={"started_by": self._actor_id, "adapter": "codex"},
        )

    def get_task(self, object_id: str) -> dict[str, Any]:
        return self._tasks.get_task(object_id)

    def get_development_completion_summary(
        self, object_id: str,
    ) -> dict[str, Any]:
        """Read a closed task summary without creating another state object."""
        return _development_completion_summary(self._tasks.get_task(object_id))

    def promote_closed_task_to_project_memory(
        self, object_id: str, *, title: str, content: str,
        tags: Sequence[str] = (),
    ) -> dict[str, Any]:
        """Explicitly retain one closed result as development memory."""
        summary = self.get_development_completion_summary(object_id)
        return DevelopmentProjectMemoryStore(
            self._project_root, project_id=self._project_id,
        ).promote(
            summary,
            actor_id=self._actor_id,
            title=title,
            content=content,
            tags=tags,
        )

    def search_project_memories(
        self, query: str = "", *, tags: Sequence[str] = (), limit: int = 5,
    ) -> dict[str, Any]:
        """Manually query project memory without injecting it into context."""
        return DevelopmentProjectMemoryStore(
            self._project_root, project_id=self._project_id,
        ).search(query, tags=tags, limit=limit)

    def record_project_memory_lifecycle_action(
        self,
        memory_id: str,
        *,
        action: str,
        permission_policy: ProjectPermissionPolicy,
        principal_kind: str,
        expected_prior_lifecycle_revision: int,
        reason_code: str,
        reason: str,
        source_evidence_refs: Sequence[str],
        memory_key: str | None = None,
        successor_memory_id: str | None = None,
        conflicts_with: Sequence[str] = (),
        recovers_receipt_id: str | None = None,
        team_id: str | None = None,
        role_claims: Sequence[str] = (),
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        """Append one permission-checked Memory lifecycle receipt."""

        context = ProjectPrincipalContext(
            principal_id=self._actor_id,
            principal_kind=principal_kind,
            project_id=self._project_id,
            team_id=team_id,
            role_claims=tuple(role_claims),
        )
        return DevelopmentProjectMemoryStore(
            self._project_root, project_id=self._project_id,
        ).lifecycle_store().append_action(
            memory_id,
            action=action,
            actor_context=context,
            permission_policy=permission_policy,
            expected_prior_lifecycle_revision=(
                expected_prior_lifecycle_revision
            ),
            reason_code=reason_code,
            reason=reason,
            source_evidence_refs=source_evidence_refs,
            memory_key=memory_key,
            successor_memory_id=successor_memory_id,
            conflicts_with=conflicts_with,
            recovers_receipt_id=recovers_receipt_id,
            recorded_at=recorded_at,
        )

    def resolve_project_memory_lifecycle(
        self, memory_id: str, *, as_of: str | None = None,
    ) -> dict[str, Any]:
        """Resolve Memory state without changing the immutable source."""

        return DevelopmentProjectMemoryStore(
            self._project_root, project_id=self._project_id,
        ).resolve_memory_lifecycle(memory_id, as_of=as_of)

    def rebuild_project_knowledge_index(
        self,
        *,
        permission_policy: ProjectPermissionPolicy,
        principal_kind: str,
        team_id: str | None = None,
        role_claims: Sequence[str] = (),
        effective_as_of: str | None = None,
    ) -> dict[str, Any]:
        """Explicitly rebuild the disposable permission-aware index."""

        context = ProjectPrincipalContext(
            principal_id=self._actor_id,
            principal_kind=principal_kind,
            project_id=self._project_id,
            team_id=team_id,
            role_claims=tuple(role_claims),
        )
        return PermissionAwareProjectRetrieval(
            self._project_root, project_id=self._project_id,
        ).rebuild_index(
            actor_context=context,
            permission_policy=permission_policy,
            effective_as_of=effective_as_of,
        )

    def search_project_knowledge(
        self,
        query: str,
        *,
        permission_policy: ProjectPermissionPolicy,
        principal_kind: str,
        team_id: str | None = None,
        role_claims: Sequence[str] = (),
        limit: int = 10,
        emit_audit: bool = False,
        queried_at: str | None = None,
    ) -> dict[str, Any]:
        """Retrieve permitted sources after lifecycle filtering."""

        context = ProjectPrincipalContext(
            principal_id=self._actor_id,
            principal_kind=principal_kind,
            project_id=self._project_id,
            team_id=team_id,
            role_claims=tuple(role_claims),
        )
        return PermissionAwareProjectRetrieval(
            self._project_root, project_id=self._project_id,
        ).search(
            query,
            actor_context=context,
            permission_policy=permission_policy,
            limit=limit,
            emit_audit=emit_audit,
            queried_at=queried_at,
        )

    def get_exact_project_knowledge_source(
        self,
        source_kind: str,
        source_id: str,
        *,
        permission_policy: ProjectPermissionPolicy,
        principal_kind: str,
        team_id: str | None = None,
        role_claims: Sequence[str] = (),
    ) -> dict[str, Any]:
        """Authorized exact lookup that does not depend on the index."""

        context = ProjectPrincipalContext(
            principal_id=self._actor_id,
            principal_kind=principal_kind,
            project_id=self._project_id,
            team_id=team_id,
            role_claims=tuple(role_claims),
        )
        return PermissionAwareProjectRetrieval(
            self._project_root, project_id=self._project_id,
        ).exact_lookup(
            source_kind,
            source_id,
            actor_context=context,
            permission_policy=permission_policy,
        )

    def dry_run_v495_project_knowledge_migration(
        self,
        evidence_ids: Sequence[str],
        *,
        memory_ids: Sequence[str] = (),
        permission_policy: ProjectPermissionPolicy,
        principal_kind: str,
        team_id: str | None = None,
        role_claims: Sequence[str] = (),
        effective_as_of: str | None = None,
    ) -> dict[str, Any]:
        """Read a selected v4.95-compatible set without writing state."""

        context = ProjectPrincipalContext(
            principal_id=self._actor_id,
            principal_kind=principal_kind,
            project_id=self._project_id,
            team_id=team_id,
            role_claims=tuple(role_claims),
        )
        return DevelopmentProjectCompatibilityMigration(
            self._project_root, project_id=self._project_id,
        ).dry_run(
            evidence_ids,
            memory_ids=memory_ids,
            actor_context=context,
            permission_policy=permission_policy,
            effective_as_of=effective_as_of,
        )

    def migrate_v495_project_knowledge(
        self,
        evidence_ids: Sequence[str],
        *,
        memory_ids: Sequence[str] = (),
        permission_policy: ProjectPermissionPolicy,
        principal_kind: str,
        team_id: str | None = None,
        role_claims: Sequence[str] = (),
        effective_as_of: str,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        """Materialize only a migration receipt and disposable index."""

        context = ProjectPrincipalContext(
            principal_id=self._actor_id,
            principal_kind=principal_kind,
            project_id=self._project_id,
            team_id=team_id,
            role_claims=tuple(role_claims),
        )
        return DevelopmentProjectCompatibilityMigration(
            self._project_root, project_id=self._project_id,
        ).migrate(
            evidence_ids,
            memory_ids=memory_ids,
            actor_context=context,
            permission_policy=permission_policy,
            effective_as_of=effective_as_of,
            recorded_at=recorded_at,
        )

    def discard_project_knowledge_migration_index(
        self,
        expected_index_revision: str,
        *,
        permission_policy: ProjectPermissionPolicy,
        principal_kind: str,
        team_id: str | None = None,
        role_claims: Sequence[str] = (),
    ) -> dict[str, Any]:
        """Discard derived discovery state without touching source records."""

        context = ProjectPrincipalContext(
            principal_id=self._actor_id,
            principal_kind=principal_kind,
            project_id=self._project_id,
            team_id=team_id,
            role_claims=tuple(role_claims),
        )
        return DevelopmentProjectCompatibilityMigration(
            self._project_root, project_id=self._project_id,
        ).discard_derived_index(
            expected_index_revision,
            actor_context=context,
            permission_policy=permission_policy,
        )

    def register_project_evidence(
        self,
        source_path: str | Path,
        *,
        task_id: str,
        source_revision: str,
        evidence_kind: str,
        title: str,
        summary: str,
        verification_status: str = "observed",
        validator_id: str | None = None,
        allowed_source_roots: Sequence[str | Path] = (),
    ) -> dict[str, Any]:
        """Register one small factual file without promoting its authority."""
        return DevelopmentProjectEvidenceStore(
            self._project_root,
            project_id=self._project_id,
            allowed_source_roots=allowed_source_roots,
        ).register_file(
            source_path,
            task_id=task_id,
            source_revision=source_revision,
            evidence_kind=evidence_kind,
            title=title,
            summary=summary,
            recorded_by=self._actor_id,
            verification_status=verification_status,
            validator_id=validator_id,
        )

    def verify_project_evidence(self, evidence_id: str) -> dict[str, Any]:
        """Resolve one stable Evidence ID without using the derived index."""
        return DevelopmentProjectEvidenceStore(
            self._project_root, project_id=self._project_id,
        ).verify(evidence_id)

    def record_project_evidence_lifecycle_action(
        self,
        evidence_id: str,
        *,
        action: str,
        permission_policy_revision: str,
        expected_prior_lifecycle_revision: int,
        reason_code: str,
        reason: str,
        source_evidence_refs: Sequence[str],
        successor_evidence_id: str | None = None,
        retain_until: str | None = None,
        recovers_receipt_id: str | None = None,
        migration_source_schema: str | None = None,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        """Append one factual lifecycle action; mutate no Evidence bytes."""

        store = DevelopmentProjectEvidenceStore(
            self._project_root,
            project_id=self._project_id,
        )
        return store.lifecycle_store().append_action(
            evidence_id,
            action=action,
            actor_id=self._actor_id,
            permission_policy_revision=permission_policy_revision,
            expected_prior_lifecycle_revision=(
                expected_prior_lifecycle_revision
            ),
            reason_code=reason_code,
            reason=reason,
            source_evidence_refs=source_evidence_refs,
            successor_evidence_id=successor_evidence_id,
            retain_until=retain_until,
            recovers_receipt_id=recovers_receipt_id,
            migration_source_schema=migration_source_schema,
            recorded_at=recorded_at,
        )

    def resolve_project_evidence_lifecycle(
        self,
        evidence_id: str,
        *,
        as_of: str | None = None,
    ) -> dict[str, Any]:
        """Resolve current or explicit historical Evidence eligibility."""

        return DevelopmentProjectEvidenceStore(
            self._project_root,
            project_id=self._project_id,
        ).resolve_evidence_lifecycle(evidence_id, as_of=as_of)

    def rebuild_project_evidence_index(self) -> dict[str, Any]:
        """Explicitly rebuild the disposable metadata keyword index."""
        return DevelopmentProjectEvidenceStore(
            self._project_root, project_id=self._project_id,
        ).rebuild_index()

    def search_project_evidence(
        self, query: str, *, limit: int = 10,
    ) -> dict[str, Any]:
        """Query the existing read-only index without implicit writes."""
        return DevelopmentProjectEvidenceStore(
            self._project_root, project_id=self._project_id,
        ).search(query, limit=limit)

    def promote_evidence_to_project_memory(
        self,
        evidence_refs: Sequence[str],
        *,
        title: str,
        content: str,
        tags: Sequence[str] = (),
    ) -> dict[str, Any]:
        """Explicitly retain verified same-task evidence as selected memory."""
        return DevelopmentProjectMemoryStore(
            self._project_root, project_id=self._project_id,
        ).promote_from_evidence(
            evidence_refs,
            actor_id=self._actor_id,
            title=title,
            content=content,
            tags=tags,
        )

    def build_project_evolution_evidence_bundle(
        self,
        evidence_ids: Sequence[str],
        *,
        memory_ids: Sequence[str] = (),
    ) -> dict[str, Any]:
        """Return a deterministic advisory evolve input; write no state."""
        return DevelopmentProjectEvidenceStore(
            self._project_root, project_id=self._project_id,
        ).build_evolution_bundle(evidence_ids, memory_ids=memory_ids)

    def list_tasks(self) -> list[dict[str, Any]]:
        return self._tasks.list_tasks()

    def _git_read(self, *arguments: str) -> subprocess.CompletedProcess[str]:
        environment = os.environ.copy()
        environment["GIT_OPTIONAL_LOCKS"] = "0"
        environment["LC_ALL"] = "C"
        return subprocess.run(
            ["git", "-C", str(self._project_root), *arguments],
            check=False,
            capture_output=True,
            text=True,
            timeout=5,
            env=environment,
        )

    def _git_read_bytes(
        self, *arguments: str,
    ) -> subprocess.CompletedProcess[bytes]:
        environment = os.environ.copy()
        environment["GIT_OPTIONAL_LOCKS"] = "0"
        environment["LC_ALL"] = "C"
        return subprocess.run(
            ["git", "-C", str(self._project_root), *arguments],
            check=False,
            capture_output=True,
            timeout=5,
            env=environment,
        )

    def inspect_work_context(self) -> dict[str, Any]:
        """Observe project-local Git context without gating task execution."""
        result: dict[str, Any] = {
            "status": "inspection_failed",
            "project_root": str(self._project_root),
            "repository_root": None,
            "branch": None,
            "head_commit": None,
            "detached_head": None,
            "worktree_dirty": None,
            "changes": [],
        }
        if not self._project_root.is_dir():
            result["status"] = "project_root_unavailable"
            return result

        try:
            probe = self._git_read("rev-parse", "--is-inside-work-tree")
            if probe.returncode != 0 or probe.stdout.strip() != "true":
                result["status"] = "not_git_repository"
                return result
            root_probe = self._git_read("rev-parse", "--show-toplevel")
            if root_probe.returncode != 0:
                return result
            repository_root = Path(root_probe.stdout.strip()).resolve()
            if (
                repository_root != self._project_root
                and repository_root not in self._project_root.parents
            ):
                result["status"] = "repository_identity_mismatch"
                return result

            head_probe = self._git_read("rev-parse", "--verify", "HEAD")
            head_commit = (
                head_probe.stdout.strip() if head_probe.returncode == 0 else None
            )
            branch_probe = self._git_read(
                "symbolic-ref", "--quiet", "--short", "HEAD",
            )
            branch = branch_probe.stdout.strip() if branch_probe.returncode == 0 else None
            status_probe = self._git_read(
                "status", "--short", "--untracked-files=normal", "--", ".",
            )
            if status_probe.returncode != 0:
                return result
        except FileNotFoundError:
            result["status"] = "git_unavailable"
            return result
        except subprocess.TimeoutExpired:
            result["status"] = "inspection_timed_out"
            return result

        changes = [line for line in status_probe.stdout.splitlines() if line]
        result.update({
            "status": "available",
            "repository_root": str(repository_root),
            "branch": branch,
            "head_commit": head_commit,
            "detached_head": head_commit is not None and branch is None,
            "worktree_dirty": bool(changes),
            "changes": changes,
        })
        return result

    @staticmethod
    def _safe_relative_input_path(value: str) -> str | None:
        return _safe_relative_project_path(value)

    def _require_git_implementation_refs(self, refs: Any) -> str:
        """Require claim refs to name real blobs in one local Git commit."""
        return _require_local_git_implementation_refs(
            self._project_root, refs,
        )

    def _inspect_task_inputs(
        self, task: dict[str, Any], work_context: dict[str, Any],
    ) -> dict[str, Any]:
        observations: list[dict[str, Any]] = []
        input_refs = task.get("input_refs", [])
        if not isinstance(input_refs, list):
            input_refs = []

        for input_ref in input_refs:
            reference = str(input_ref)
            observation: dict[str, Any] = {
                "ref": reference,
                "kind": "external_reference",
                "status": "uninspectable",
                "path": None,
                "baseline_commit": None,
                "reason": "external_reference_scheme",
            }
            if reference.startswith("project://"):
                relative = self._safe_relative_input_path(
                    reference.removeprefix("project://"),
                )
                observation["kind"] = "project_path"
                if relative is None:
                    observation["reason"] = "project_path_invalid_or_escape"
                else:
                    target = (self._project_root / relative).resolve()
                    if (
                        target != self._project_root
                        and self._project_root not in target.parents
                    ):
                        observation["reason"] = "project_path_escape"
                    else:
                        observation.update({
                            "status": "present" if target.exists() else "missing",
                            "path": relative,
                            "reason": None if target.exists() else "project_path_missing",
                        })
                observations.append(observation)
                continue

            match = _GIT_INPUT_REF.fullmatch(reference)
            if match is None:
                observations.append(observation)
                continue
            relative = self._safe_relative_input_path(match.group("path"))
            observation.update({
                "kind": "git_revision_path",
                "path": relative,
                "baseline_commit": match.group("commit"),
                "repository": match.group("repository"),
            })
            if relative is None:
                observation["reason"] = "git_path_invalid_or_escape"
                observations.append(observation)
                continue
            if work_context.get("status") != "available":
                observation["reason"] = "git_context_unavailable"
                observations.append(observation)
                continue

            repository_root_value = work_context.get("repository_root")
            if not isinstance(repository_root_value, str):
                observation["reason"] = "git_repository_root_unavailable"
                observations.append(observation)
                continue
            try:
                project_prefix = self._project_root.relative_to(
                    Path(repository_root_value).resolve(),
                )
            except ValueError:
                observation["reason"] = "git_repository_identity_mismatch"
                observations.append(observation)
                continue
            repository_relative = (
                PurePosixPath(project_prefix.as_posix(), relative).as_posix()
                if project_prefix.parts else relative
            )

            commit = match.group("commit")
            try:
                commit_probe = self._git_read(
                    "cat-file", "-e", f"{commit}^{{commit}}",
                )
                if commit_probe.returncode != 0:
                    observation.update({
                        "status": "missing",
                        "reason": "baseline_commit_missing",
                    })
                    observations.append(observation)
                    continue
                path_probe = self._git_read(
                    "cat-file", "-e", f"{commit}:{repository_relative}",
                )
                if path_probe.returncode != 0:
                    observation.update({
                        "status": "missing",
                        "reason": "baseline_path_missing",
                    })
                    observations.append(observation)
                    continue
                target = (self._project_root / relative).resolve()
                if (
                    target != self._project_root
                    and self._project_root not in target.parents
                ):
                    observation["reason"] = "git_worktree_path_escape"
                    observations.append(observation)
                    continue
                if not target.exists():
                    observation.update({
                        "status": "missing",
                        "reason": "worktree_path_missing",
                    })
                    observations.append(observation)
                    continue
                diff_probe = self._git_read(
                    "diff", "--quiet", "--no-ext-diff", commit, "--",
                    f":(top,literal){repository_relative}",
                )
            except (FileNotFoundError, subprocess.TimeoutExpired):
                observation["reason"] = "git_inspection_unavailable"
                observations.append(observation)
                continue

            if diff_probe.returncode == 0:
                observation.update({"status": "unchanged", "reason": None})
            elif diff_probe.returncode == 1:
                observation.update({
                    "status": "changed", "reason": "worktree_differs_from_baseline",
                })
            else:
                observation["reason"] = "git_diff_unavailable"
            observations.append(observation)

        counts = {
            status: sum(item["status"] == status for item in observations)
            for status in _INPUT_INSPECTION_STATUSES
        }
        return {
            "status": "observed",
            "task_id": str(task["object_id"]),
            "git_context_status": work_context.get("status"),
            "summary": {"total": len(observations), **counts},
            "inputs": observations,
        }

    def _require_current_replacement_ref(
        self, previous_ref: str, replacement_ref: str,
    ) -> dict[str, Any]:
        previous = (
            _GIT_INPUT_REF.fullmatch(previous_ref)
            if isinstance(previous_ref, str) else None
        )
        replacement = (
            _GIT_INPUT_REF.fullmatch(replacement_ref)
            if isinstance(replacement_ref, str) else None
        )
        if previous is None or replacement is None:
            raise ValueError("codex_input_change_git_refs_required")
        previous_path = self._safe_relative_input_path(previous.group("path"))
        replacement_path = self._safe_relative_input_path(
            replacement.group("path"),
        )
        if (
            previous_path is None
            or replacement_path is None
            or previous.group("repository") != replacement.group("repository")
            or previous_path != replacement_path
            or previous.group("commit") == replacement.group("commit")
        ):
            raise ValueError("codex_input_change_identity_invalid")
        inspection = self._inspect_task_inputs(
            {"object_id": "replacement-input", "input_refs": [replacement_ref]},
            self.inspect_work_context(),
        )
        observation = inspection["inputs"][0]
        if observation["status"] != "unchanged":
            raise ValueError(
                "codex_replacement_input_not_current:"
                f"{observation['status']}:{observation['reason']}"
            )
        return observation

    def inspect_task_inputs(self, object_id: str) -> dict[str, Any]:
        """Inspect local task inputs without mutating or invalidating the task."""
        task = self._tasks.get_task(object_id)
        return self._inspect_task_inputs(task, self.inspect_work_context())

    @staticmethod
    def _task_readset_text_item(
        item: dict[str, Any], raw: bytes, *, binding: str,
    ) -> dict[str, Any]:
        byte_count = len(raw)
        item["bytes"] = byte_count
        if byte_count > _TASK_READSET_MAX_FILE_BYTES:
            item["reason"] = "task_readset_file_too_large"
            return item
        if b"\x00" in raw:
            item["reason"] = "task_readset_binary_content"
            return item
        try:
            content = raw.decode("utf-8")
        except UnicodeDecodeError:
            item["reason"] = "task_readset_non_utf8_content"
            return item
        item.update({
            "status": "loaded",
            "reason": None,
            "binding": binding,
            "content": content,
        })
        return item

    def _load_task_readset_reference(
        self, reference: str, work_context: dict[str, Any],
    ) -> dict[str, Any]:
        item: dict[str, Any] = {
            "ref": reference,
            "kind": "external_reference",
            "path": None,
            "status": "skipped",
            "reason": "external_reference_scheme",
            "binding": None,
            "bytes": None,
            "content": None,
        }
        if reference.startswith("project://"):
            item["kind"] = "project_path"
            relative = self._safe_relative_input_path(
                reference.removeprefix("project://"),
            )
            item["path"] = relative
            if relative is None:
                item["reason"] = "project_path_invalid_or_escape"
                return item
            target = (self._project_root / relative).resolve()
            if (
                target != self._project_root
                and self._project_root not in target.parents
            ):
                item["reason"] = "project_path_escape"
                return item
            if not target.is_file():
                item["reason"] = "project_file_missing"
                return item
            try:
                item["bytes"] = target.stat().st_size
                if item["bytes"] > _TASK_READSET_MAX_FILE_BYTES:
                    item["reason"] = "task_readset_file_too_large"
                    return item
                raw = target.read_bytes()
            except OSError:
                item["reason"] = "project_file_unreadable"
                return item
            return self._task_readset_text_item(
                item, raw, binding="current_worktree",
            )

        match = _GIT_INPUT_REF.fullmatch(reference)
        if match is None:
            return item
        item.update({
            "kind": "git_revision_path",
            "path": self._safe_relative_input_path(match.group("path")),
            "baseline_commit": match.group("commit"),
            "repository": match.group("repository"),
        })
        relative = item["path"]
        if not isinstance(relative, str):
            item["reason"] = "git_path_invalid_or_escape"
            return item
        repository_root_value = work_context.get("repository_root")
        if (
            work_context.get("status") != "available"
            or not isinstance(repository_root_value, str)
        ):
            item["reason"] = "git_context_unavailable"
            return item
        try:
            project_prefix = self._project_root.relative_to(
                Path(repository_root_value).resolve(),
            )
        except ValueError:
            item["reason"] = "git_repository_identity_mismatch"
            return item
        repository_relative = (
            PurePosixPath(project_prefix.as_posix(), relative).as_posix()
            if project_prefix.parts else relative
        )
        object_ref = f"{match.group('commit')}:{repository_relative}"
        try:
            size_probe = self._git_read_bytes("cat-file", "-s", object_ref)
            if size_probe.returncode != 0:
                item["reason"] = "git_revision_path_missing"
                return item
            item["bytes"] = int(size_probe.stdout.strip())
            if item["bytes"] > _TASK_READSET_MAX_FILE_BYTES:
                item["reason"] = "task_readset_file_too_large"
                return item
            content_probe = self._git_read_bytes(
                "cat-file", "blob", object_ref,
            )
        except (
            FileNotFoundError, subprocess.TimeoutExpired, ValueError,
        ):
            item["reason"] = "git_content_unavailable"
            return item
        if content_probe.returncode != 0:
            item["reason"] = "git_content_unavailable"
            return item
        return self._task_readset_text_item(
            item, content_probe.stdout,
            binding="exact_git_revision",
        )

    def _load_verified_truth_replacement(
        self, original_ref: str, replacement: Mapping[str, Any],
        work_context: dict[str, Any],
    ) -> dict[str, Any]:
        replacement_ref = str(replacement["replacement_ref"])
        item = self._load_task_readset_reference(
            replacement_ref, work_context,
        )
        item.update({
            "ref": original_ref,
            "replacement_ref": replacement_ref,
            "truth_binding_ids": list(replacement["truth_binding_ids"]),
            "replacement_binding_id": replacement["binding_id"],
            "replacement_artifact_revision": replacement[
                "artifact_revision"
            ],
            "replacement_artifact_sha256": replacement["artifact_sha256"],
        })
        if item["status"] != "loaded":
            item["replacement_load_reason"] = item["reason"]
            item["reason"] = "truth_replacement_content_unavailable"
            return item

        content_sha256 = hashlib.sha256(
            str(item["content"]).encode("utf-8"),
        ).hexdigest()
        item["replacement_content_sha256"] = content_sha256
        if content_sha256 != replacement["artifact_sha256"]:
            item.update({
                "status": "skipped",
                "reason": "truth_replacement_content_hash_mismatch",
                "binding": None,
                "content": None,
            })
            return item
        item["reason"] = "truth_replacement_loaded"
        return item

    def _load_task_readset(
        self, task: Mapping[str, Any], work_context: dict[str, Any],
        *, truth_exclusions: Mapping[str, Sequence[str]] | None = None,
        truth_replacements: Mapping[str, Mapping[str, Any]] | None = None,
    ) -> dict[str, Any]:
        input_refs = task.get("input_refs", [])
        if not isinstance(input_refs, list):
            input_refs = []
        items: list[dict[str, Any]] = []
        seen: set[str] = set()
        loaded_count = 0
        loaded_bytes = 0
        excluded = truth_exclusions or {}
        replacements = truth_replacements or {}
        for value in input_refs:
            reference = str(value)
            if reference in seen:
                items.append({
                    "ref": reference,
                    "kind": "duplicate_reference",
                    "path": None,
                    "status": "skipped",
                    "reason": "task_readset_duplicate_reference",
                    "binding": None,
                    "bytes": None,
                    "content": None,
                })
                continue
            seen.add(reference)
            if reference in excluded:
                replacement = replacements.get(reference)
                if replacement is None:
                    item = {
                        "ref": reference,
                        "kind": "truth_bound_reference",
                        "path": None,
                        "status": "skipped",
                        "reason": "truth_revalidation_required",
                        "binding": None,
                        "bytes": None,
                        "content": None,
                        "truth_binding_ids": list(excluded[reference]),
                    }
                elif replacement["status"] != "ready":
                    item = {
                        "ref": reference,
                        "replacement_ref": replacement["replacement_ref"],
                        "kind": "truth_bound_reference",
                        "path": None,
                        "status": "skipped",
                        "reason": replacement["reason"],
                        "binding": None,
                        "bytes": None,
                        "content": None,
                        "truth_binding_ids": list(excluded[reference]),
                    }
                else:
                    item = self._load_verified_truth_replacement(
                        reference, replacement, work_context,
                    )
            else:
                item = self._load_task_readset_reference(
                    reference, work_context,
                )
            if item["status"] == "loaded":
                byte_count = int(item["bytes"])
                if loaded_count >= _TASK_READSET_MAX_FILES:
                    item.update({
                        "status": "skipped",
                        "reason": "task_readset_file_count_limit",
                        "binding": None,
                        "content": None,
                    })
                elif loaded_bytes + byte_count > _TASK_READSET_MAX_TOTAL_BYTES:
                    item.update({
                        "status": "skipped",
                        "reason": "task_readset_total_size_limit",
                        "binding": None,
                        "content": None,
                    })
                else:
                    loaded_count += 1
                    loaded_bytes += byte_count
            items.append(item)
        return {
            "status": "loaded",
            "task_id": str(task["object_id"]),
            "task_revision": int(task["revision"]),
            "authority_status": "reference_content_only",
            "summary": {
                "total_refs": len(items),
                "loaded": loaded_count,
                "skipped": len(items) - loaded_count,
                "loaded_bytes": loaded_bytes,
            },
            "limits": {
                "max_files": _TASK_READSET_MAX_FILES,
                "max_file_bytes": _TASK_READSET_MAX_FILE_BYTES,
                "max_total_bytes": _TASK_READSET_MAX_TOTAL_BYTES,
            },
            "items": items,
        }

    def load_task_readset(
        self, object_id: str, *,
        truth_resolution: Mapping[str, Any] | None = None,
        artifact_bindings: Sequence[Mapping[str, Any]] | None = None,
        truth_replacements: Mapping[str, str] | None = None,
    ) -> dict[str, Any]:
        """Load a bounded text readset from one task's explicit input refs."""
        task = self._tasks.get_task(object_id)
        truth_revalidation = self._optional_task_truth_revalidation(
            task,
            truth_resolution=truth_resolution,
            artifact_bindings=artifact_bindings,
        )
        truth_exclusions = self._truth_readset_exclusions(
            truth_revalidation,
        )
        verified_replacements = self._truth_readset_replacements(
            task, truth_revalidation, artifact_bindings,
            truth_replacements,
        )
        readset = self._load_task_readset(
            task, self.inspect_work_context(),
            truth_exclusions=truth_exclusions,
            truth_replacements=verified_replacements,
        )
        if truth_revalidation is not None:
            readset["truth_revalidation"] = truth_revalidation
            readset["truth_excluded_ref_count"] = len(truth_exclusions)
            readset["truth_replaced_ref_count"] = sum(
                item.get("reason") == "truth_replacement_loaded"
                for item in readset["items"]
            )
        return readset

    def persist_truth_input_replacements(
        self, object_id: str, *, truth_resolution: Mapping[str, Any],
        artifact_bindings: Sequence[Mapping[str, Any]],
        truth_replacements: Mapping[str, str],
    ) -> dict[str, Any]:
        """Persist producer-confirmed replacements after readset verification."""
        if not isinstance(truth_replacements, Mapping) or not truth_replacements:
            raise ValueError("codex_truth_replacements_required")
        if any(
            not isinstance(previous_ref, str)
            or not isinstance(replacement_ref, str)
            or _GIT_INPUT_REF.fullmatch(replacement_ref) is None
            for previous_ref, replacement_ref in truth_replacements.items()
        ):
            raise ValueError("codex_truth_persistent_rebind_requires_git_ref")
        selected = truth_resolution.get("selected_truth")
        selected_truth_id = (
            selected.get("truth_id") if isinstance(selected, Mapping) else None
        )
        selected_truth_revision = (
            selected.get("source_revision")
            if isinstance(selected, Mapping) else None
        )
        selected_truth_sha256 = (
            selected.get("source_sha256")
            if isinstance(selected, Mapping) else None
        )
        if (
            truth_resolution.get("status") != "resolved"
            or truth_resolution.get("verdict")
            != "resolved_current_authority"
            or not isinstance(selected_truth_id, str)
            or not selected_truth_id
            or not isinstance(selected_truth_revision, str)
            or len(selected_truth_revision) != 40
            or not isinstance(selected_truth_sha256, str)
            or len(selected_truth_sha256) != 64
        ):
            raise ValueError("codex_truth_replacement_selection_required")

        task = self._tasks.get_task(object_id)
        producer = task.get("accountable_producer_id", task.get("owner"))
        if self._actor_id != producer:
            raise ValueError("task_session_truth_rebind_not_authorized")
        resolution_scope = truth_resolution.get("scope")
        if (
            not isinstance(resolution_scope, Mapping)
            or resolution_scope.get("project_id") != task.get("project_id")
        ):
            raise ValueError("codex_truth_replacement_project_mismatch")
        existing = task.get("development_truth_rebind")
        if (
            isinstance(existing, Mapping)
            and existing.get("status") == "bound"
            and existing.get("selected_truth_id") == selected_truth_id
            and existing.get("selected_truth_revision")
            == selected_truth_revision
            and existing.get("selected_truth_sha256")
            == selected_truth_sha256
            and isinstance(existing.get("replacements"), list)
        ):
            stored = {
                item.get("previous_ref"): item.get("replacement_ref")
                for item in existing["replacements"]
                if isinstance(item, Mapping)
            }
            input_refs = task.get("input_refs", [])
            if (
                stored == dict(truth_replacements)
                and isinstance(input_refs, list)
                and all(
                    previous_ref not in input_refs
                    and replacement_ref in input_refs
                    for previous_ref, replacement_ref
                    in truth_replacements.items()
                )
            ):
                return {
                    "status": "already_rebound",
                    "task": task,
                    "lifecycle_state_changed": False,
                }

        readset = self.load_task_readset(
            object_id,
            truth_resolution=truth_resolution,
            artifact_bindings=artifact_bindings,
            truth_replacements=truth_replacements,
        )
        items = {
            item.get("ref"): item for item in readset["items"]
            if isinstance(item, Mapping)
        }
        verified: list[dict[str, Any]] = []
        failed_refs: list[str] = []
        for previous_ref, replacement_ref in sorted(
            truth_replacements.items(),
        ):
            item = items.get(previous_ref)
            if (
                not isinstance(item, Mapping)
                or item.get("status") != "loaded"
                or item.get("reason") != "truth_replacement_loaded"
                or item.get("replacement_ref") != replacement_ref
            ):
                failed_refs.append(previous_ref)
                continue
            verified.append({
                "previous_ref": previous_ref,
                "replacement_ref": replacement_ref,
                "truth_binding_ids": item["truth_binding_ids"],
                "binding_id": item["replacement_binding_id"],
                "artifact_revision": item["replacement_artifact_revision"],
                "artifact_sha256": item["replacement_artifact_sha256"],
                "content_sha256": item["replacement_content_sha256"],
            })
        if failed_refs:
            raise ValueError(
                "codex_truth_replacement_not_verified:"
                + ",".join(failed_refs)
            )

        result = self._tasks.rebind_truth_inputs(
            object_id,
            selected_truth_id=selected_truth_id,
            selected_truth_revision=selected_truth_revision,
            selected_truth_sha256=selected_truth_sha256,
            verified_replacements=verified,
            expected_revision=int(readset["task_revision"]),
        )
        return {
            **result,
            "selected_truth_id": selected_truth_id,
            "selected_truth_revision": selected_truth_revision,
            "selected_truth_sha256": selected_truth_sha256,
            "verified_replacements": verified,
        }

    def preview_input_impacts(self) -> dict[str, Any]:
        """Preview changed or missing inputs for unfinished development tasks."""
        work_context = self.inspect_work_context()
        unfinished_tasks = [
            task for task in self._tasks.list_tasks()
            if task.get("state") in _RESUME_ACTIONS
        ]
        potentially_affected_tasks: list[dict[str, Any]] = []
        changed_input_count = 0
        missing_input_count = 0
        uninspectable_reference_count = 0

        for task in unfinished_tasks:
            inspection = self._inspect_task_inputs(task, work_context)
            changed_inputs = [
                item for item in inspection["inputs"]
                if item["status"] == "changed"
            ]
            missing_inputs = [
                item for item in inspection["inputs"]
                if item["status"] == "missing"
            ]
            changed_input_count += len(changed_inputs)
            missing_input_count += len(missing_inputs)
            uninspectable_reference_count += inspection["summary"][
                "uninspectable"
            ]
            if changed_inputs or missing_inputs:
                potentially_affected_tasks.append({
                    "task_id": str(task["object_id"]),
                    "title": task.get("title"),
                    "state": task.get("state"),
                    "changed_inputs": changed_inputs,
                    "missing_inputs": missing_inputs,
                })

        return {
            "status": "observed",
            "work_context": work_context,
            "scanned_unfinished_task_count": len(unfinished_tasks),
            "potentially_affected_task_count": len(
                potentially_affected_tasks
            ),
            "changed_input_count": changed_input_count,
            "missing_input_count": missing_input_count,
            "uninspectable_reference_count": uninspectable_reference_count,
            "potentially_affected_tasks": potentially_affected_tasks,
        }

    def _task_truth_revalidation(
        self, task: Mapping[str, Any], truth_resolution: Mapping[str, Any],
        artifact_bindings: Sequence[Mapping[str, Any]],
    ) -> dict[str, Any]:
        impact = preview_truth_replacement_impact(
            truth_resolution, artifact_bindings,
        )
        selected_truth = truth_resolution.get("selected_truth")
        selected_truth = (
            selected_truth if isinstance(selected_truth, Mapping) else {}
        )
        task_id = str(task["object_id"])
        base = {
            "task_id": task_id,
            "project_id": task.get("project_id"),
            "task_revision": int(task["revision"]),
            "authority_status": "development_advisory_only",
            "task_state_changed": False,
            "non_blocking": True,
            "impact_status": impact["status"],
            "impact_verdict": impact["verdict"],
            "scanned_binding_count": impact["scanned_binding_count"],
            "selected_truth_id": impact.get("selected_truth_id"),
            "selected_truth_revision": selected_truth.get("source_revision"),
            "selected_truth_sha256": selected_truth.get("source_sha256"),
            "superseded_truth_ids": impact.get(
                "superseded_truth_ids", [],
            ),
        }
        resolution_scope = truth_resolution.get("scope")
        if (
            not isinstance(resolution_scope, Mapping)
            or resolution_scope.get("project_id") != task.get("project_id")
        ):
            return {
                **base,
                "status": "unresolved",
                "revalidation_required": False,
                "required_action": None,
                "reason": "truth_resolution_project_mismatch",
                "affected_bindings": [],
                "unlinked_affected_binding_count": 0,
            }
        if impact["status"] != "ready":
            return {
                **base,
                "status": "unresolved",
                "revalidation_required": False,
                "required_action": None,
                "reason": impact["reason"],
                "affected_bindings": [],
                "unlinked_affected_binding_count": 0,
            }

        binding_by_id = {
            str(binding["binding_id"]): binding
            for binding in artifact_bindings
        }
        input_refs = {
            item for item in task.get("input_refs", [])
            if isinstance(item, str)
        }
        rebound_binding_ids: set[str] = set()
        rebound = task.get("development_truth_rebind")
        if (
            isinstance(rebound, Mapping)
            and rebound.get("status") == "bound"
            and rebound.get("selected_truth_id") == impact.get(
                "selected_truth_id"
            )
            and rebound.get("selected_truth_revision")
            == base["selected_truth_revision"]
            and rebound.get("selected_truth_sha256")
            == base["selected_truth_sha256"]
            and isinstance(rebound.get("replacements"), list)
        ):
            for item in rebound["replacements"]:
                if (
                    not isinstance(item, Mapping)
                    or item.get("previous_ref") in input_refs
                    or item.get("replacement_ref") not in input_refs
                    or not isinstance(item.get("truth_binding_ids"), list)
                ):
                    continue
                rebound_binding_ids.update(
                    binding_id for binding_id in item["truth_binding_ids"]
                    if isinstance(binding_id, str)
                )
        affected_bindings: list[dict[str, Any]] = []
        for binding_id in impact["affected_binding_ids"]:
            if binding_id in rebound_binding_ids:
                continue
            binding = binding_by_id[binding_id]
            artifact_id = str(binding["artifact_id"])
            scope = binding["scope"]
            linked_by: list[str] = []
            if scope.get("task_id") == task_id:
                linked_by.append("task_scope")
            if (
                binding.get("artifact_kind") == "task"
                and artifact_id == task_id
            ):
                linked_by.append("task_artifact_identity")
            if artifact_id in input_refs:
                linked_by.append("explicit_input_ref")
            if linked_by:
                affected_bindings.append({
                    "binding_id": binding_id,
                    "artifact_id": artifact_id,
                    "linked_by": linked_by,
                    "superseded_truth_ids": sorted(set(
                        binding["truth_ids"],
                    ).intersection(impact["superseded_truth_ids"])),
                })

        affected_binding_ids = {
            item["binding_id"] for item in affected_bindings
        }
        required = bool(affected_bindings)
        return {
            **base,
            "status": "observed",
            "revalidation_required": required,
            "required_action": (
                "revalidate_linked_truth_inputs" if required else None
            ),
            "reason": (
                "task_has_explicitly_linked_superseded_truth_binding"
                if required
                else "no_affected_binding_is_explicitly_linked_to_task"
            ),
            "affected_bindings": affected_bindings,
            "rebound_binding_ids": sorted(
                rebound_binding_ids.intersection(
                    impact["affected_binding_ids"],
                )
            ),
            "unlinked_affected_binding_count": sum(
                binding_id not in affected_binding_ids
                and binding_id not in rebound_binding_ids
                for binding_id in impact["affected_binding_ids"]
            ),
        }

    def _optional_task_truth_revalidation(
        self, task: Mapping[str, Any], *,
        truth_resolution: Mapping[str, Any] | None,
        artifact_bindings: Sequence[Mapping[str, Any]] | None,
    ) -> dict[str, Any] | None:
        if truth_resolution is None and artifact_bindings is None:
            return None
        if truth_resolution is None or artifact_bindings is None:
            raise ValueError("codex_truth_impact_inputs_incomplete")
        return self._task_truth_revalidation(
            task, truth_resolution, artifact_bindings,
        )

    @staticmethod
    def _truth_readset_exclusions(
        truth_revalidation: Mapping[str, Any] | None,
    ) -> dict[str, list[str]]:
        if (
            truth_revalidation is None
            or truth_revalidation.get("status") != "observed"
            or truth_revalidation.get("revalidation_required") is not True
        ):
            return {}
        exclusions: dict[str, list[str]] = {}
        for binding in truth_revalidation.get("affected_bindings", []):
            if (
                not isinstance(binding, Mapping)
                or "explicit_input_ref" not in binding.get("linked_by", [])
                or not isinstance(binding.get("artifact_id"), str)
                or not isinstance(binding.get("binding_id"), str)
            ):
                continue
            exclusions.setdefault(binding["artifact_id"], []).append(
                binding["binding_id"],
            )
        return {
            reference: sorted(binding_ids)
            for reference, binding_ids in sorted(exclusions.items())
        }

    def _truth_readset_replacements(
        self, task: Mapping[str, Any],
        truth_revalidation: Mapping[str, Any] | None,
        artifact_bindings: Sequence[Mapping[str, Any]] | None,
        truth_replacements: Mapping[str, str] | None,
    ) -> dict[str, dict[str, Any]]:
        if truth_replacements is None:
            return {}
        if not isinstance(truth_replacements, Mapping) or any(
            not isinstance(previous_ref, str)
            or not previous_ref
            or not isinstance(replacement_ref, str)
            or not replacement_ref
            or previous_ref == replacement_ref
            for previous_ref, replacement_ref in truth_replacements.items()
        ):
            raise ValueError("codex_truth_replacements_invalid")
        if not truth_replacements:
            return {}
        if (
            truth_revalidation is None
            or truth_revalidation.get("status") != "observed"
            or artifact_bindings is None
        ):
            raise ValueError("codex_truth_replacements_impact_unresolved")

        exclusions = self._truth_readset_exclusions(truth_revalidation)
        if any(
            previous_ref not in exclusions
            for previous_ref in truth_replacements
        ):
            raise ValueError("codex_truth_replacement_source_not_excluded")

        project_id = task.get("project_id")
        task_id = str(task["object_id"])
        selected_truth_id = truth_revalidation.get("selected_truth_id")
        superseded_truth_ids = set(
            truth_revalidation.get("superseded_truth_ids", []),
        )
        results: dict[str, dict[str, Any]] = {}
        for previous_ref, replacement_ref in sorted(
            truth_replacements.items(),
        ):
            candidates = [
                binding for binding in artifact_bindings
                if binding.get("artifact_id") == replacement_ref
                and binding.get("binding_status") == "current"
                and selected_truth_id in binding.get("truth_ids", [])
                and not superseded_truth_ids.intersection(
                    binding.get("truth_ids", []),
                )
                and isinstance(binding.get("scope"), Mapping)
                and binding["scope"].get("project_id") == project_id
                and binding["scope"].get("task_id") in (None, task_id)
            ]
            base = {
                "replacement_ref": replacement_ref,
                "truth_binding_ids": exclusions[previous_ref],
            }
            if not candidates:
                results[previous_ref] = {
                    **base,
                    "status": "rejected",
                    "reason": "truth_replacement_binding_not_current",
                }
                continue
            if len(candidates) != 1:
                results[previous_ref] = {
                    **base,
                    "status": "rejected",
                    "reason": "truth_replacement_binding_ambiguous",
                }
                continue
            binding = candidates[0]
            git_match = _GIT_INPUT_REF.fullmatch(replacement_ref)
            if (
                git_match is not None
                and binding.get("artifact_revision")
                != git_match.group("commit")
            ):
                results[previous_ref] = {
                    **base,
                    "status": "rejected",
                    "reason": "truth_replacement_revision_mismatch",
                }
                continue
            results[previous_ref] = {
                **base,
                "status": "ready",
                "reason": "current_truth_binding_verified",
                "binding_id": binding["binding_id"],
                "artifact_revision": binding["artifact_revision"],
                "artifact_sha256": binding["artifact_sha256"],
            }
        return results

    def apply_input_revision_change(
        self, *, previous_ref: str, replacement_ref: str,
        change_ref: str, reason: str,
    ) -> dict[str, Any]:
        """Persist revalidation blockers for tasks bound to one old Git ref."""
        if (
            not isinstance(change_ref, str) or not change_ref.strip()
            or not isinstance(reason, str) or not reason.strip()
        ):
            raise ValueError("codex_input_change_ref_and_reason_required")
        replacement_observation = self._require_current_replacement_ref(
            previous_ref, replacement_ref,
        )
        affected = [
            task for task in self._tasks.list_tasks()
            if task.get("state") in _RESUME_ACTIONS
            and previous_ref in task.get("input_refs", [])
        ]
        results: list[dict[str, Any]] = []
        for task in affected:
            prior_state = task["state"]
            marked = self._tasks.mark_input_revalidation_required(
                task["object_id"],
                previous_ref=previous_ref,
                replacement_ref=replacement_ref,
                change_ref=change_ref.strip(),
                reason=reason.strip(),
            )
            issue = marked.get("issue")
            results.append({
                "task_id": task["object_id"],
                "prior_state": prior_state,
                "resulting_state": marked["task"]["state"],
                "disposition": marked["status"],
                "blocker_issue_id": (
                    issue.get("object_id") if isinstance(issue, dict) else None
                ),
            })
        return {
            "claim_status": "NON_QUALIFYING",
            "change_ref": change_ref.strip(),
            "previous_ref": previous_ref,
            "replacement_ref": replacement_ref,
            "replacement_observation": replacement_observation,
            "affected_task_count": len(results),
            "affected_tasks": results,
        }

    @staticmethod
    def _normalize_production_spec_patch(
        production_spec_patch: Mapping[str, Any],
    ) -> dict[str, str]:
        if not isinstance(production_spec_patch, Mapping):
            raise ValueError("codex_production_spec_patch_object_required")
        if (
            production_spec_patch.get("artifact_type")
            != "production_spec_patch"
        ):
            raise ValueError("codex_production_spec_patch_type_invalid")
        if production_spec_patch.get("schema_version") != "1.0.0":
            raise ValueError("codex_production_spec_patch_version_unsupported")
        identity_fields = {
            key: production_spec_patch.get(key)
            for key in (
                "task_id", "patch_id", "source_merge_record_ref",
                "accepted_behavior_delta",
            )
        }
        if any(
            not isinstance(value, str) or not value.strip()
            for value in identity_fields.values()
        ):
            raise ValueError("codex_production_spec_patch_identity_incomplete")
        return {
            key: str(value).strip() for key, value in identity_fields.items()
        }

    @staticmethod
    def _production_replay_input_binding(
        task: Mapping[str, Any], previous_ref: str,
    ) -> dict[str, Any] | None:
        """Match exact inputs or one unambiguous legacy commit/path pair."""
        input_refs = task.get("input_refs", [])
        if not isinstance(input_refs, list):
            return None
        references = [
            reference for reference in input_refs
            if isinstance(reference, str)
        ]
        if previous_ref in references:
            return {
                "kind": "exact_git_ref",
                "matched_refs": [previous_ref],
            }

        previous = _GIT_INPUT_REF.fullmatch(previous_ref)
        if previous is None:
            return None
        project_ref = f"project://{previous.group('path')}"
        if project_ref not in references:
            return None

        legacy_refs = sorted({
            reference for reference in references
            if (
                (legacy := _LEGACY_GIT_COMMIT_REF.fullmatch(reference))
                is not None
                and legacy.group("repository")
                == previous.group("repository")
                and previous.group("commit").startswith(
                    legacy.group("commit")
                )
            )
        })
        if len(legacy_refs) != 1:
            return None
        legacy = _LEGACY_GIT_COMMIT_REF.fullmatch(legacy_refs[0])
        if legacy is None:
            return None
        return {
            "kind": "legacy_short_commit_plus_project_path",
            "matched_refs": [legacy_refs[0], project_ref],
            "legacy_commit_prefix": legacy.group("commit"),
        }

    def preview_production_spec_patch_replay(
        self, *, production_spec_patch: Mapping[str, Any],
        previous_ref: str, replacement_ref: str,
    ) -> dict[str, Any]:
        """Preview task impact and focused review without changing state."""
        normalized = self._normalize_production_spec_patch(
            production_spec_patch,
        )
        replacement_observation = self._require_current_replacement_ref(
            previous_ref, replacement_ref,
        )
        patch_trace_ref = (
            f"production_spec_patch:{normalized['task_id']}"
            f"#{normalized['patch_id']}"
        )
        tasks = self._tasks.list_tasks()
        affected: list[dict[str, Any]] = []
        action_by_state = {
            "CREATED": "rebind_before_start",
            "READY": "rebind_before_start",
            "IN_PROGRESS": "focused_revalidation",
            "CLAIMED_DONE": "focused_revalidation_before_review",
            "VERIFIED": "focused_revalidation_before_close",
            "REOPENED": "focused_revalidation",
            "BLOCKED": "include_in_existing_recovery",
            "CLOSED": "review_closed_task_for_possible_reopen",
            "CANCELLED": "confirm_cancelled_task_needs_no_action",
        }
        for task in tasks:
            input_binding = self._production_replay_input_binding(
                task, previous_ref,
            )
            if input_binding is None:
                continue
            state = str(task.get("state"))
            affected.append({
                "task_id": task.get("object_id"),
                "title": task.get("title"),
                "feature_id": task.get("feature_id"),
                "task_revision": task.get("revision"),
                "current_state": state,
                "input_binding": input_binding,
                "recommended_action": action_by_state.get(
                    state, "manual_task_state_review",
                ),
                "focused_review": {
                    "behavior_delta": normalized["accepted_behavior_delta"],
                    "previous_ref": previous_ref,
                    "replacement_ref": replacement_ref,
                    "suggested_checks": [
                        "review_task_behavior_against_delta",
                        "inspect_replacement_input",
                        "run_task_relevant_functional_checks",
                    ],
                },
            })
        affected.sort(key=lambda item: str(item["task_id"]))
        legacy_affected_task_count = sum(
            item["input_binding"]["kind"]
            == "legacy_short_commit_plus_project_path"
            for item in affected
        )
        return {
            "status": "ready",
            "mode": "read_only_preview",
            "claim_status": "NON_QUALIFYING",
            "change_ref": patch_trace_ref,
            "production_spec_patch": {
                "artifact_type": "production_spec_patch",
                "schema_version": "1.0.0",
                "task_id": normalized["task_id"],
                "patch_id": normalized["patch_id"],
                "source_merge_record_ref": normalized[
                    "source_merge_record_ref"
                ],
            },
            "previous_ref": previous_ref,
            "replacement_ref": replacement_ref,
            "replacement_observation": replacement_observation,
            "scanned_task_count": len(tasks),
            "affected_task_count": len(affected),
            "legacy_affected_task_count": legacy_affected_task_count,
            "unaffected_task_count": len(tasks) - len(affected),
            "affected_tasks": affected,
            "state_changes_applied": False,
            "artifact_validation_status": "not_performed",
            "authority_status": "external_not_asserted",
            "limitations": [
                "read_only_preview",
                "legacy_short_ref_matching_is_preview_only",
                "caller_supplied_patch_not_authority_verified",
                "no_task_rebind_or_revalidation_performed",
                "no_production_gate_or_release_authority",
            ],
        }

    def propagate_production_spec_patch_input_revision(
        self, *, production_spec_patch: Mapping[str, Any],
        previous_ref: str, replacement_ref: str,
    ) -> dict[str, Any]:
        """Bridge one selected production spec patch into task revalidation."""
        normalized = self._normalize_production_spec_patch(
            production_spec_patch,
        )
        patch_trace_ref = (
            f"production_spec_patch:{normalized['task_id']}"
            f"#{normalized['patch_id']}"
        )
        propagated = self.apply_input_revision_change(
            previous_ref=previous_ref,
            replacement_ref=replacement_ref,
            change_ref=patch_trace_ref,
            reason=normalized["accepted_behavior_delta"],
        )
        return {
            **propagated,
            "production_spec_patch": {
                "artifact_type": "production_spec_patch",
                "schema_version": "1.0.0",
                "task_id": normalized["task_id"],
                "patch_id": normalized["patch_id"],
                "source_merge_record_ref": normalized[
                    "source_merge_record_ref"
                ],
            },
            "artifact_validation_status": "not_performed",
            "authority_status": "external_not_asserted",
        }

    def complete_task_input_revalidation(
        self, object_id: str, *, evidence_refs: Sequence[str] = (),
    ) -> dict[str, Any]:
        """Rebind one task after its replacement Git input is current."""
        task = self._tasks.get_task(object_id)
        marker = task.get("development_input_revalidation")
        if not isinstance(marker, dict):
            raise ValueError("codex_input_revalidation_not_pending")
        previous_ref = marker.get("previous_ref")
        replacement_ref = marker.get("replacement_ref")
        if not isinstance(previous_ref, str) or not isinstance(
            replacement_ref, str,
        ):
            raise ValueError("codex_input_revalidation_marker_invalid")
        replacement_observation = self._require_current_replacement_ref(
            previous_ref, replacement_ref,
        )
        result = self._tasks.complete_input_revalidation(
            object_id, evidence_refs=evidence_refs,
        )
        return {**result, "replacement_observation": replacement_observation}

    def resume_task(self, object_id: str | None = None) -> dict[str, Any]:
        """Select one unfinished task and expose its next development action.

        A caller may omit ``object_id`` only when the project has exactly one
        unfinished task. This keeps a fresh Codex session from guessing among
        concurrent tasks while avoiding a separate active-task registry.
        """
        if object_id is not None:
            if not isinstance(object_id, str) or not object_id.strip():
                raise ValueError("codex_resume_task_id_invalid")
            task = self._tasks.get_task(object_id.strip())
            selected_by = "explicit_task_id"
        else:
            candidates = [
                task for task in self._tasks.list_tasks()
                if task.get("state") in _RESUME_ACTIONS
            ]
            if not candidates:
                raise LookupError("codex_no_resumable_task")
            if len(candidates) != 1:
                candidate_ids = ",".join(sorted(
                    str(task.get("object_id", "")) for task in candidates
                ))
                raise ValueError(
                    f"codex_task_selection_ambiguous:{candidate_ids}"
                )
            task = candidates[0]
            selected_by = "single_unfinished_task"

        state = task.get("state")
        next_action = _RESUME_ACTIONS.get(state)
        if next_action is None:
            raise ValueError(f"codex_task_not_resumable:{state}")
        return {
            "status": "resumable",
            "selected_by": selected_by,
            "task": task,
            "next_action": next_action,
        }

    @staticmethod
    def _current_attempt_projection(
        task: Mapping[str, Any],
    ) -> dict[str, Any] | None:
        if task.get("state") in {
            "CREATED", "READY", "CANCELLED", "CLOSED",
        }:
            return None
        history = task.get("state_history", [])
        if not isinstance(history, list):
            return None

        boundaries: list[tuple[int, Mapping[str, Any]]] = []
        reopened_waiting_for_start = False
        for index, event in enumerate(history):
            if not isinstance(event, Mapping):
                continue
            target = event.get("to")
            context = event.get("context")
            context = context if isinstance(context, Mapping) else {}
            if target == "REOPENED":
                boundaries.append((index, event))
                reopened_waiting_for_start = True
                continue
            if target != "IN_PROGRESS":
                continue
            if reopened_waiting_for_start:
                reopened_waiting_for_start = False
                continue
            if context.get("resolved_blocker"):
                continue
            boundaries.append((index, event))
        if not boundaries:
            return None

        boundary_index, boundary = boundaries[-1]
        boundary_context = boundary.get("context")
        boundary_context = (
            boundary_context
            if isinstance(boundary_context, Mapping) else {}
        )
        entered_at = boundary.get("at")
        work_started_at = None
        for event in history[boundary_index:]:
            if isinstance(event, Mapping) and event.get("to") == "IN_PROGRESS":
                work_started_at = event.get("at")
                break

        if boundary.get("to") == "REOPENED":
            trigger_kind = "reopened_for_rework"
        elif boundary_context.get("withdrawn_by"):
            trigger_kind = "claim_withdrawn_for_rework"
        elif boundary_context.get("returned_for_rework"):
            trigger_kind = "review_returned_for_rework"
        elif boundary_context.get("started_by"):
            trigger_kind = "initial_work_started"
        else:
            trigger_kind = "work_cycle_started"
        triggered_by = next((
            boundary_context.get(key)
            for key in (
                "started_by", "withdrawn_by", "reviewed_by", "reopened_by",
            )
            if isinstance(boundary_context.get(key), str)
            and boundary_context.get(key)
        ), None)

        phase = {
            "IN_PROGRESS": "active",
            "BLOCKED": "paused_blocked",
            "CLAIMED_DONE": "awaiting_review",
            "VERIFIED": "review_passed_awaiting_close",
            "REOPENED": "pending_rework",
        }.get(str(task.get("state")), "inactive")
        attempt_id = (
            f"{task.get('object_id')}:development-attempt:"
            f"{len(boundaries)}"
        )
        progress = task.get("development_progress")
        progress_is_current = (
            isinstance(progress, Mapping)
            and (
                progress.get("attempt_id") == attempt_id
                or (
                    progress.get("attempt_id") is None
                    and len(boundaries) == 1
                    and isinstance(progress.get("recorded_at"), str)
                    and isinstance(entered_at, str)
                    and progress["recorded_at"] >= entered_at
                )
            )
        )
        return {
            "attempt_id": attempt_id,
            "attempt_number": len(boundaries),
            "phase": phase,
            "task_state": task.get("state"),
            "entered_at": entered_at,
            "work_started_at": work_started_at,
            "trigger_kind": trigger_kind,
            "triggered_by": triggered_by,
            "latest_progress": dict(progress) if progress_is_current else None,
            "progress_status": (
                "current" if progress_is_current
                else "not_recorded_for_attempt"
            ),
            "projection_only": True,
        }

    @staticmethod
    def _checkpoint_work_snapshot(
        work_context: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Reduce Git context to a stable checkpoint without storing paths."""
        raw_changes = work_context.get("changes", [])
        changes = (
            sorted(item for item in raw_changes if isinstance(item, str))
            if isinstance(raw_changes, list) else []
        )
        changes_sha256 = hashlib.sha256(
            "\0".join(changes).encode("utf-8")
        ).hexdigest()
        return {
            "status": work_context.get("status"),
            "branch": work_context.get("branch"),
            "head_commit": work_context.get("head_commit"),
            "detached_head": work_context.get("detached_head"),
            "worktree_dirty": work_context.get("worktree_dirty"),
            "change_count": len(changes),
            "changes_summary_sha256": changes_sha256,
        }

    @classmethod
    def _checkpoint_recovery_projection(
        cls, current_attempt: Mapping[str, Any] | None,
        work_context: Mapping[str, Any],
    ) -> dict[str, Any] | None:
        if not isinstance(current_attempt, Mapping):
            return None
        progress = current_attempt.get("latest_progress")
        if not isinstance(progress, Mapping):
            return None
        checkpoint_snapshot = progress.get("checkpoint_context")
        if not isinstance(checkpoint_snapshot, Mapping):
            return None

        saved = dict(checkpoint_snapshot)
        current = cls._checkpoint_work_snapshot(work_context)
        if saved.get("status") != "available" or current["status"] != "available":
            status = "context_unavailable"
            recommended_action = "inspect_work_context"
        elif saved == current:
            status = "unchanged"
            recommended_action = "continue_from_checkpoint"
        else:
            status = "review_changes"
            recommended_action = "review_worktree_changes"
        return {
            "status": status,
            "recommended_action": recommended_action,
            "checkpoint_snapshot": saved,
            "current_snapshot": current,
            "non_blocking": True,
            "projection_only": True,
        }

    def list_resume_candidates(self) -> list[dict[str, Any]]:
        """List unfinished tasks with enough context for explicit selection."""
        candidates: list[dict[str, Any]] = []
        for task in self._tasks.list_tasks():
            state = task.get("state")
            next_action = _RESUME_ACTIONS.get(state)
            if next_action is None:
                continue
            candidates.append({
                "task_id": task.get("object_id"),
                "title": task.get("title"),
                "feature_id": task.get("feature_id"),
                "state": state,
                "owner": task.get("owner"),
                "next_action": next_action,
                "current_attempt": self._current_attempt_projection(task),
            })
        return candidates

    def get_resume_context(
        self, object_id: str | None = None, *,
        include_input_contents: bool = False,
        truth_resolution: Mapping[str, Any] | None = None,
        artifact_bindings: Sequence[Mapping[str, Any]] | None = None,
        truth_replacements: Mapping[str, str] | None = None,
    ) -> dict[str, Any]:
        """Aggregate current development context without writing new state."""
        if not isinstance(include_input_contents, bool):
            raise ValueError("codex_resume_include_input_contents_invalid")
        if truth_replacements is not None and not include_input_contents:
            raise ValueError("codex_truth_replacements_require_readset")
        selected = self.resume_task(object_id)
        task = selected["task"]
        task_id = str(task["object_id"])
        open_handoffs = self._tasks.list_open_handoffs(task_id)
        assigned_handoffs = [
            handoff for handoff in open_handoffs
            if handoff.get("to_owner") == self._actor_id
            and handoff.get("state") in _ASSIGNED_HANDOFF_STATES
        ]
        work_context = self.inspect_work_context()
        current_attempt = self._current_attempt_projection(task)
        context: dict[str, Any] = {
            "status": selected["status"],
            "selected_by": selected["selected_by"],
            "next_action": selected["next_action"],
            "task": task,
            "current_attempt": current_attempt,
            "active_blockers": self._tasks.list_active_blockers(task_id),
            "open_handoffs": open_handoffs,
            "assigned_handoffs": assigned_handoffs,
            "work_context": work_context,
            "input_inspection": self._inspect_task_inputs(task, work_context),
        }
        checkpoint_recovery = self._checkpoint_recovery_projection(
            current_attempt, work_context,
        )
        if checkpoint_recovery is not None:
            context["checkpoint_recovery"] = checkpoint_recovery
        truth_revalidation = self._optional_task_truth_revalidation(
            task,
            truth_resolution=truth_resolution,
            artifact_bindings=artifact_bindings,
        )
        if truth_revalidation is not None:
            context["truth_revalidation"] = truth_revalidation
        if include_input_contents:
            truth_exclusions = self._truth_readset_exclusions(
                truth_revalidation,
            )
            verified_replacements = self._truth_readset_replacements(
                task, truth_revalidation, artifact_bindings,
                truth_replacements,
            )
            context["input_readset"] = self._load_task_readset(
                task, work_context,
                truth_exclusions=truth_exclusions,
                truth_replacements=verified_replacements,
            )
            if truth_revalidation is not None:
                context["input_readset"]["truth_revalidation"] = (
                    truth_revalidation
                )
                context["input_readset"]["truth_excluded_ref_count"] = len(
                    truth_exclusions
                )
                context["input_readset"]["truth_replaced_ref_count"] = sum(
                    item.get("reason") == "truth_replacement_loaded"
                    for item in context["input_readset"]["items"]
                )
        return context

    def record_progress(
        self, object_id: str, *, summary: str, next_step: str = "",
    ) -> dict[str, Any]:
        """Store one latest-only progress note for cross-session resumption."""
        task = self._tasks.get_task(object_id)
        attempt = self._current_attempt_projection(task)
        if task.get("state") not in {"IN_PROGRESS", "BLOCKED"}:
            return self._tasks.record_progress(
                object_id, summary=summary, next_step=next_step,
            )
        if attempt is None:
            raise ValueError("codex_progress_current_attempt_unavailable")
        return self._tasks.record_progress(
            object_id, summary=summary, next_step=next_step,
            attempt_id=attempt["attempt_id"],
        )

    def checkpoint_for_interruption(
        self, object_id: str, *, summary: str, next_step: str = "",
    ) -> dict[str, Any]:
        """Save progress plus compact Git context, then return resume context."""
        before = self._tasks.get_task(object_id)
        attempt = self._current_attempt_projection(before)
        if before.get("state") in {"IN_PROGRESS", "BLOCKED"} and attempt is None:
            raise ValueError("codex_progress_current_attempt_unavailable")
        checkpoint_context = self._checkpoint_work_snapshot(
            self.inspect_work_context()
        )
        updated = self._tasks.record_progress(
            object_id, summary=summary, next_step=next_step,
            attempt_id=(attempt["attempt_id"] if attempt is not None else None),
            checkpoint_context=checkpoint_context,
        )
        resume_context = self.get_resume_context(object_id)
        if resume_context["task"]["revision"] != updated["revision"]:
            raise RuntimeError("codex_checkpoint_revision_mismatch")
        attempt = resume_context["current_attempt"]
        return {
            "status": (
                "already_checkpointed"
                if updated["revision"] == before["revision"]
                else "checkpointed"
            ),
            "checkpoint_kind": "development_progress",
            "task_revision": updated["revision"],
            "attempt_id": attempt["attempt_id"] if attempt is not None else None,
            "resume_context": resume_context,
        }

    def cancel_task(self, object_id: str, *, reason: str) -> dict[str, Any]:
        """Cancel obsolete development work without deleting its record."""
        return self._tasks.cancel_task(object_id, reason=reason)

    def report_blocker(
        self, object_id: str, *, title: str, summary: str = "",
        severity: str = "high",
    ) -> dict[str, Any]:
        """Persist a blocker and move the linked task to ``BLOCKED``."""
        return self._tasks.report_blocker(
            object_id, title=title, summary=summary, severity=severity,
        )

    def resolve_blocker(
        self, object_id: str, issue_id: str, *, resolution_notes: str,
        evidence_refs: Sequence[str] = (),
    ) -> dict[str, Any]:
        """Resolve one blocker and resume the task if no blockers remain."""
        return self._tasks.resolve_blocker(
            object_id, issue_id,
            resolution_notes=resolution_notes,
            evidence_refs=evidence_refs,
        )

    def send_handoff(
        self, object_id: str, *, to_actor_id: str, required_action: str,
        expected_outputs: Sequence[str], acceptance_condition: str,
    ) -> dict[str, Any]:
        """Send delegated development work without transferring task ownership."""
        return self._tasks.send_handoff(
            object_id,
            to_actor_id=to_actor_id,
            required_action=required_action,
            expected_outputs=expected_outputs,
            acceptance_condition=acceptance_condition,
        )

    def list_assigned_handoffs(self) -> list[dict[str, Any]]:
        """List unfinished handoffs addressed to this adapter actor."""
        return [
            handoff for handoff in self._tasks.list_handoffs()
            if handoff.get("to_owner") == self._actor_id
            and handoff.get("state") in _ASSIGNED_HANDOFF_STATES
        ]

    def accept_handoff(self, handoff_id: str) -> dict[str, Any]:
        return self._tasks.accept_handoff(handoff_id)

    def reject_handoff(
        self, handoff_id: str, *, reason: str,
    ) -> dict[str, Any]:
        return self._tasks.reject_handoff(handoff_id, reason=reason)

    def return_handoff(
        self, handoff_id: str, *, reason: str,
    ) -> dict[str, Any]:
        return self._tasks.return_handoff(handoff_id, reason=reason)

    def complete_handoff(
        self, handoff_id: str, *, completion_notes: str,
        output_refs: Sequence[str] = (),
    ) -> dict[str, Any]:
        return self._tasks.complete_handoff(
            handoff_id,
            completion_notes=completion_notes,
            output_refs=output_refs,
        )

    def claim_task_done(
        self, object_id: str, *, implementation_refs: Sequence[str] = (),
        output_refs: Sequence[str] = (),
    ) -> dict[str, Any]:
        """Record work products and make a non-verifying completion claim."""
        current = self._tasks.get_task(object_id)
        if current["state"] != "IN_PROGRESS":
            raise ValueError(
                f"codex_task_not_in_progress:{current['state']}"
            )
        effective_implementation_refs = (
            list(implementation_refs)
            if implementation_refs else current.get("implementation_refs", [])
        )
        claimed_commit = self._require_git_implementation_refs(
            effective_implementation_refs,
        )
        recorded = current
        if implementation_refs or output_refs:
            recorded = self._tasks.record_work_products(
                object_id,
                implementation_refs=implementation_refs,
                output_refs=output_refs,
            )
        return self._tasks.transition_task(
            recorded["object_id"], "CLAIMED_DONE",
            context={
                "claimed_by": self._actor_id,
                "claimed_commit": claimed_commit,
                "adapter": "codex",
            },
        )

    def withdraw_task_claim(
        self, object_id: str, *, reason: str,
    ) -> dict[str, Any]:
        """Return an unreviewed development claim to ordinary implementation."""
        if not isinstance(reason, str) or not reason.strip():
            raise ValueError("codex_claim_withdrawal_reason_required")
        current = self._tasks.get_task(object_id)
        if current["state"] != "CLAIMED_DONE":
            raise ValueError(
                f"codex_claim_withdrawal_state_invalid:{current['state']}"
            )
        accountable_producer = current.get(
            "accountable_producer_id", current.get("owner"),
        )
        last_context = current.get("last_transition_context", {})
        claimed_by = (
            last_context.get("claimed_by")
            if isinstance(last_context, dict) else None
        )
        if self._actor_id not in {accountable_producer, claimed_by}:
            raise ValueError("codex_claim_withdrawal_not_authorized")
        return self._tasks.transition_task(
            object_id, "IN_PROGRESS",
            context={
                "withdrawn_by": self._actor_id,
                "reason": reason.strip(),
                "development_only": True,
            },
        )

    def close(self) -> None:
        self._tasks.close()


class CodexDevelopmentReviewAdapter:
    """Independent development review for task closure or bounded rework."""

    def __init__(
        self, *, os_layer_root: str | Path, project_root: str | Path,
        project_id: str, actor_id: str,
    ) -> None:
        self._actor_id = actor_id
        self._project_root = Path(project_root).resolve()
        self._tasks = DevelopmentTaskSession(
            package_root=os_layer_root,
            project_root=project_root,
            project_id=project_id,
            actor_id=actor_id,
        )

    def start(self) -> "CodexDevelopmentReviewAdapter":
        self._tasks.start()
        return self

    def __enter__(self) -> "CodexDevelopmentReviewAdapter":
        return self.start()

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self._tasks.__exit__(exc_type, exc, traceback)

    def list_review_queue(self) -> list[dict[str, Any]]:
        """List claimed tasks this actor may independently review."""
        return [
            task for task in self._tasks.list_tasks()
            if task.get("state") == "CLAIMED_DONE"
            and task.get(
                "accountable_producer_id", task.get("owner"),
            ) != self._actor_id
        ]

    def _require_review_binding(
        self, current: dict[str, Any], reviewed_commit: str,
    ) -> None:
        producer = current.get(
            "accountable_producer_id", current.get("owner"),
        )
        if producer == self._actor_id:
            raise ValueError("codex_review_must_be_independent")
        claim_context = current.get("last_transition_context", {})
        claimed_commit = (
            claim_context.get("claimed_commit")
            if isinstance(claim_context, dict) else None
        )
        if claimed_commit != reviewed_commit:
            raise ValueError("codex_review_commit_not_claimed")
        if (
            _single_git_implementation_commit(
                current.get("implementation_refs", []),
            )
            != reviewed_commit
        ):
            raise ValueError("codex_review_commit_not_implemented")

    def close_verified_task(
        self, object_id: str, *, reviewed_commit: str,
    ) -> dict[str, Any]:
        """Resume the close half of an already persisted PASS transition."""
        if re.fullmatch(r"[A-Za-z0-9._-]+", self._actor_id) is None:
            raise ValueError("codex_review_actor_invalid")
        if re.fullmatch(r"[0-9a-f]{40}", reviewed_commit) is None:
            raise ValueError("codex_review_commit_invalid")
        current = self._tasks.get_task(object_id)
        if current["state"] != "VERIFIED":
            raise ValueError(f"codex_task_not_verified:{current['state']}")
        review_context = current.get("last_transition_context", {})
        if (
            not isinstance(review_context, dict)
            or review_context.get("verified_by") != self._actor_id
            or review_context.get("reviewed_commit") != reviewed_commit
            or review_context.get("verdict") != "PASS"
            or review_context.get("scope") != "bounded_functional_review"
            or _single_git_implementation_commit(
                current.get("implementation_refs", []),
            ) != reviewed_commit
            or f"review://{self._actor_id}/{reviewed_commit}/PASS"
            not in current.get("output_refs", [])
        ):
            raise ValueError("codex_verified_review_binding_invalid")
        open_handoffs = self._tasks.list_open_handoffs(object_id)
        if open_handoffs:
            handoff_ids = ",".join(sorted(
                str(handoff["object_id"]) for handoff in open_handoffs
            ))
            raise ValueError(
                f"codex_verified_close_open_handoffs:{handoff_ids}"
            )
        return self._tasks.transition_task(
            current["object_id"], "CLOSED",
            context={
                "closed_by": self._actor_id,
                "development_review_only": True,
                "not_qualification_or_release": True,
            },
        )

    def verify_and_close_task(
        self, object_id: str, *, reviewed_commit: str,
        p2_findings: int = 0,
    ) -> dict[str, Any]:
        """Close one independently reviewed local task without promotion claims."""
        if re.fullmatch(r"[A-Za-z0-9._-]+", self._actor_id) is None:
            raise ValueError("codex_review_actor_invalid")
        if re.fullmatch(r"[0-9a-f]{40}", reviewed_commit) is None:
            raise ValueError("codex_review_commit_invalid")
        if (
            isinstance(p2_findings, bool)
            or not isinstance(p2_findings, int)
            or p2_findings < 0
        ):
            raise ValueError("codex_review_p2_count_invalid")

        current = self._tasks.get_task(object_id)
        if current["state"] == "VERIFIED":
            return self.close_verified_task(
                object_id, reviewed_commit=reviewed_commit,
            )
        if current["state"] != "CLAIMED_DONE":
            raise ValueError(f"codex_task_not_claimed_done:{current['state']}")
        self._require_review_binding(current, reviewed_commit)
        open_handoffs = self._tasks.list_open_handoffs(object_id)
        if open_handoffs:
            handoff_ids = ",".join(sorted(
                str(handoff["object_id"]) for handoff in open_handoffs
            ))
            raise ValueError(
                f"codex_review_open_handoffs:{handoff_ids}"
            )
        _require_local_git_implementation_refs(
            self._project_root, current.get("implementation_refs", []),
        )

        review_ref = f"review://{self._actor_id}/{reviewed_commit}/PASS"
        output_refs = list(current.get("output_refs", []))
        if review_ref not in output_refs:
            output_refs.append(review_ref)
        recorded = self._tasks.record_work_products(
            object_id, output_refs=output_refs,
        )
        verified = self._tasks.transition_task(
            recorded["object_id"], "VERIFIED",
            context={
                "verified_by": self._actor_id,
                "reviewed_commit": reviewed_commit,
                "verdict": "PASS",
                "scope": "bounded_functional_review",
                "finding_counts": {"p0": 0, "p1": 0, "p2": p2_findings},
            },
        )
        return self.close_verified_task(
            verified["object_id"], reviewed_commit=reviewed_commit,
        )

    def reject_task_claim(
        self, object_id: str, *, reviewed_commit: str,
        findings_summary: str,
    ) -> dict[str, Any]:
        """Return a commit-bound completion claim for ordinary rework."""
        if re.fullmatch(r"[A-Za-z0-9._-]+", self._actor_id) is None:
            raise ValueError("codex_review_actor_invalid")
        if re.fullmatch(r"[0-9a-f]{40}", reviewed_commit) is None:
            raise ValueError("codex_review_commit_invalid")
        if (
            not isinstance(findings_summary, str)
            or not findings_summary.strip()
        ):
            raise ValueError("codex_review_findings_summary_required")

        current = self._tasks.get_task(object_id)
        if current["state"] != "CLAIMED_DONE":
            raise ValueError(f"codex_task_not_claimed_done:{current['state']}")
        self._require_review_binding(current, reviewed_commit)

        review_ref = f"review://{self._actor_id}/{reviewed_commit}/FAIL"
        output_refs = list(current.get("output_refs", []))
        if review_ref not in output_refs:
            output_refs.append(review_ref)
        recorded = self._tasks.record_work_products(
            object_id, output_refs=output_refs,
        )
        return self._tasks.transition_task(
            recorded["object_id"], "IN_PROGRESS",
            context={
                "reviewed_by": self._actor_id,
                "reviewed_commit": reviewed_commit,
                "verdict": "FAIL",
                "scope": "bounded_functional_review",
                "findings_summary": findings_summary.strip(),
                "returned_for_rework": True,
            },
        )

    def close(self) -> None:
        self._tasks.close()
