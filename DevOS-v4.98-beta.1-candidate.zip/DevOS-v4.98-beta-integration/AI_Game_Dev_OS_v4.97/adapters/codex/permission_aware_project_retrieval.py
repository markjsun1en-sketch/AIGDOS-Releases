"""Permission-first, lifecycle-aware project Evidence/Memory retrieval.

This is a metadata/keyword path, not semantic RAG.  Its index is disposable;
exact Evidence and Memory lookup never depends on it.
"""

from __future__ import annotations

import fcntl
import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from ._development_evidence_common import (
    atomic_write,
    canonical_bytes,
    normalized_text,
    pretty_bytes,
    sha256_bytes,
)
from ._development_evidence_index import inventory as evidence_inventory
from .development_project_evidence import DevelopmentProjectEvidenceStore
from .development_project_memory import DevelopmentProjectMemoryStore
from .development_project_permissions import (
    ProjectPermissionPolicy,
    ProjectPrincipalContext,
)


PROJECT_RETRIEVAL_RELATIVE_PATH = Path(
    ".ai_dev_os/development/project_retrieval"
)
INDEX_RELATIVE_PATH = Path("index/project_knowledge_index.json")
AUDITS_RELATIVE_PATH = Path("audits")
MAX_QUERY_CHARS = 500
MAX_RESULTS = 20
SOURCE_CAPABILITY = {
    "project_evidence": "project_evidence_read",
    "project_memory": "project_memory_read",
}
RESULT_NON_CLAIM = (
    "retrieval_result_is_advisory_and_not_project_truth_acceptance_or_authority"
)
AUDIT_NON_CLAIMS = (
    "audit_contains_no_retrieved_payload_or_unauthorized_source_count",
    "audit_is_not_human_acceptance_or_gate_evidence",
    "audit_grants_no_release_production_or_live_authority",
)


def _timestamp(value: str, *, field: str) -> str:
    normalized = normalized_text(value, field=field, maximum=100)
    try:
        parsed = datetime.fromisoformat(normalized.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"codex_project_retrieval_{field}_invalid") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(
            f"codex_project_retrieval_{field}_timezone_required"
        )
    return parsed.astimezone(timezone.utc).isoformat()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class PermissionAwareProjectRetrieval:
    """Build and query one local derived index with permission-first ranking."""

    def __init__(self, project_root: str | Path, *, project_id: str) -> None:
        self._project_root = Path(project_root).resolve()
        if not self._project_root.is_dir():
            raise ValueError("codex_project_retrieval_project_root_invalid")
        self._project_id = normalized_text(
            project_id, field="retrieval_project_id", maximum=200
        )
        self._root = self._project_root / PROJECT_RETRIEVAL_RELATIVE_PATH
        self._evidence_store = DevelopmentProjectEvidenceStore(
            self._project_root, project_id=self._project_id
        )
        self._memory_store = DevelopmentProjectMemoryStore(
            self._project_root, project_id=self._project_id
        )

    def _path(self, relative: Path, *, create_parent: bool) -> Path:
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("codex_project_retrieval_path_escape")
        cursor = self._project_root
        for part in PROJECT_RETRIEVAL_RELATIVE_PATH.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                raise ValueError("codex_project_retrieval_symlink_rejected")
        for part in relative.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                raise ValueError("codex_project_retrieval_symlink_rejected")
        if create_parent:
            cursor.parent.mkdir(parents=True, exist_ok=True)
        return cursor

    def _check_scope(
        self,
        context: ProjectPrincipalContext,
        policy: ProjectPermissionPolicy,
    ) -> None:
        if not isinstance(context, ProjectPrincipalContext) or not isinstance(
            policy, ProjectPermissionPolicy
        ):
            raise ValueError("codex_project_retrieval_permission_context_invalid")
        if (
            context.project_id != self._project_id
            or policy.project_id != self._project_id
        ):
            raise PermissionError("codex_project_permission_denied")

    def rebuild_index(
        self,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        effective_as_of: str | None = None,
    ) -> dict[str, Any]:
        """Rebuild the disposable index from current eligible local sources."""
        self._check_scope(actor_context, permission_policy)
        permission_policy.require(actor_context, "project_evidence_read")
        permission_policy.require(actor_context, "project_memory_read")
        selected_as_of = _timestamp(
            effective_as_of or _now(), field="effective_as_of"
        )

        evidence_observed = evidence_inventory(self._evidence_store)
        evidence_views = self._evidence_store.lifecycle_store().resolve_all(
            as_of=selected_as_of
        )
        memory_views = self._memory_store.lifecycle_store().resolve_all(
            as_of=selected_as_of
        )
        entries: list[dict[str, Any]] = []
        for result in evidence_observed["valid"]:
            evidence = result["evidence"]
            view = evidence_views["views"].get(evidence["evidence_id"])
            if (
                view is None
                or view["status"] != "ok"
                or not view["retrieval_eligible"]
                or evidence["verification_status"] != "verified"
            ):
                continue
            entries.append(
                self._evidence_entry(result, view)
            )
        for memory_id, view in memory_views["views"].items():
            if view["status"] != "ok" or not view["retrieval_eligible"]:
                continue
            exact = self._memory_store.get(memory_id)
            if exact["status"] != "ok":
                continue
            entries.append(self._memory_entry(exact["memory"], view))
        entries.sort(key=lambda item: (item["source_kind"], item["source_id"]))

        issues: list[str] = []
        if evidence_observed["skipped"]:
            issues.append("invalid_evidence_isolated")
        if evidence_observed["truncated"]:
            issues.append("evidence_inventory_truncated")
        if evidence_views["status"] != "ok":
            issues.append("evidence_lifecycle_review_needed")
        if memory_views["skipped_invalid_memory_ids"]:
            issues.append("invalid_memory_isolated")
        if memory_views["scan_truncated"]:
            issues.append("memory_inventory_truncated")
        if memory_views["status"] != "ok":
            issues.append("memory_lifecycle_review_needed")

        body = {
            "schema_version": "1.0.0",
            "artifact_type": "permission_aware_project_retrieval_index",
            "project_id": self._project_id,
            "permission_policy_revision": permission_policy.policy_revision,
            "effective_as_of": selected_as_of,
            "source_inventory": {
                "evidence_records_sha256": evidence_observed[
                    "inventory_sha256"
                ],
                "evidence_lifecycle_sha256": evidence_views[
                    "lifecycle_inventory_sha256"
                ],
                "memory_records_sha256": memory_views[
                    "memory_inventory_sha256"
                ],
                "memory_lifecycle_sha256": memory_views[
                    "lifecycle_inventory_sha256"
                ],
            },
            "eligible_source_set_sha256": sha256_bytes(
                canonical_bytes(
                    [
                        {
                            "source_kind": item["source_kind"],
                            "source_id": item["source_id"],
                            "record_sha256": item["record_sha256"],
                            "lifecycle_revision": item["lifecycle_revision"],
                        }
                        for item in entries
                    ]
                )
            ),
            "entries": entries,
            "build_status": "ok" if not issues else "review_needed",
            "bounded_issues": sorted(dict.fromkeys(issues)),
            "limitations": [
                "derived_disposable_keyword_index",
                "team_memory_provider_disabled",
                "not_semantic_rag",
                "index_is_not_source_authority",
            ],
        }
        index_revision = sha256_bytes(canonical_bytes(body))
        index = {**body, "index_revision": index_revision}
        target = self._path(INDEX_RELATIVE_PATH, create_parent=True)
        serialized = pretty_bytes(index)
        lock_path = target.parent / ".index.lock"
        if lock_path.is_symlink():
            raise ValueError("codex_project_retrieval_index_lock_symlink_rejected")
        with lock_path.open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            atomic_write(target, serialized)
        return {
            "status": index["build_status"],
            "index": index,
            "index_ref": target.relative_to(self._project_root).as_posix(),
            "index_sha256": sha256_bytes(serialized),
        }

    def _evidence_entry(
        self, result: Mapping[str, Any], view: Mapping[str, Any],
    ) -> dict[str, Any]:
        evidence = result["evidence"]
        return {
            "source_kind": "project_evidence",
            "source_id": evidence["evidence_id"],
            "project_id": self._project_id,
            "source_revision": evidence["source_revision"],
            "record_sha256": result["record_sha256"],
            "content_sha256": evidence["content"]["sha256"],
            "lifecycle_state": view["effective_state"],
            "lifecycle_revision": view["lifecycle_revision"],
            "memory_key": None,
            "title": evidence["title"],
            "text": evidence["summary"],
            "tags": [evidence["evidence_kind"], evidence["task_id"]],
            "source_evidence_ids": [evidence["evidence_id"]],
            "exact_source_ref": result["record_ref"],
        }

    def _memory_entry(
        self, memory: Mapping[str, Any], view: Mapping[str, Any],
    ) -> dict[str, Any]:
        source = memory["source"]
        return {
            "source_kind": "project_memory",
            "source_id": memory["memory_id"],
            "project_id": self._project_id,
            "source_revision": source["source_revision"],
            "record_sha256": view["record_sha256"],
            "content_sha256": sha256_bytes(
                memory["content"].encode("utf-8")
            ),
            "lifecycle_state": view["effective_state"],
            "lifecycle_revision": view["lifecycle_revision"],
            "memory_key": view["memory_key"],
            "title": memory["title"],
            "text": memory["content"],
            "tags": list(memory["tags"]),
            "source_evidence_ids": list(source["evidence_refs"]),
            "exact_source_ref": (
                self._memory_store._root
                / f"{memory['memory_id']}.json"
            ).relative_to(self._project_root).as_posix(),
        }

    def search(
        self,
        query: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        limit: int = 10,
        emit_audit: bool = False,
        queried_at: str | None = None,
    ) -> dict[str, Any]:
        """Filter source classes by permission before keyword ranking."""
        self._check_scope(actor_context, permission_policy)
        if not isinstance(query, str):
            raise ValueError("codex_project_retrieval_query_invalid")
        normalized_query = query.strip()
        if len(normalized_query) > MAX_QUERY_CHARS:
            raise ValueError("codex_project_retrieval_query_too_long")
        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= MAX_RESULTS
        ):
            raise ValueError("codex_project_retrieval_limit_invalid")
        selected_time = _timestamp(queried_at or _now(), field="queried_at")
        allowed_kinds = self._allowed_source_kinds(
            actor_context, permission_policy
        )
        if not allowed_kinds:
            audit = self._audit(
                query=normalized_query,
                context=actor_context,
                policy=permission_policy,
                index_revision=None,
                query_status="ok",
                results=[],
                exclusion_counts={},
                recorded_at=selected_time,
            )
            return self._search_response(
                status="ok", results=[], issues=[], audit=audit,
                audit_ref=self._maybe_write_audit(
                    audit,
                    emit=emit_audit,
                    context=actor_context,
                    policy=permission_policy,
                ),
            )

        loaded = self._load_index(permission_policy.policy_revision)
        if loaded["status"] != "ok":
            audit = self._audit(
                query=normalized_query,
                context=actor_context,
                policy=permission_policy,
                index_revision=loaded.get("index_revision"),
                query_status="review_needed",
                results=[],
                exclusion_counts={},
                recorded_at=selected_time,
            )
            return self._search_response(
                status="review_needed",
                results=[],
                issues=loaded["issues"],
                audit=audit,
                audit_ref=self._maybe_write_audit(
                    audit,
                    emit=emit_audit,
                    context=actor_context,
                    policy=permission_policy,
                ),
            )
        index = loaded["index"]
        try:
            stale_issues = self._stale_issues(index, allowed_kinds)
        except (KeyError, TypeError, ValueError, OSError):
            stale_issues = ["authorized_source_state_unreadable"]
        if stale_issues:
            audit = self._audit(
                query=normalized_query,
                context=actor_context,
                policy=permission_policy,
                index_revision=index["index_revision"],
                query_status="review_needed",
                results=[],
                exclusion_counts={},
                recorded_at=selected_time,
            )
            return self._search_response(
                status="review_needed",
                results=[],
                issues=stale_issues,
                audit=audit,
                audit_ref=self._maybe_write_audit(
                    audit,
                    emit=emit_audit,
                    context=actor_context,
                    policy=permission_policy,
                ),
            )

        # This filter is intentionally before _rank_entries.  Unauthorized
        # title/text/tags never enter scoring or visible candidate counts.
        authorized_entries = [
            item
            for item in index["entries"]
            if isinstance(item, Mapping)
            and item.get("source_kind") in allowed_kinds
        ]
        try:
            visible_index_revision = self._visible_index_revision(
                index, authorized_entries, allowed_kinds
            )
            ranked, exclusion_counts = self._rank_entries(
                authorized_entries, normalized_query, visible_index_revision
            )
        except (KeyError, TypeError, ValueError):
            visible_index_revision = index["index_revision"]
            audit = self._audit(
                query=normalized_query,
                context=actor_context,
                policy=permission_policy,
                index_revision=visible_index_revision,
                query_status="review_needed",
                results=[],
                exclusion_counts={},
                recorded_at=selected_time,
            )
            return self._search_response(
                status="review_needed",
                results=[],
                issues=["authorized_index_entry_invalid"],
                audit=audit,
                audit_ref=self._maybe_write_audit(
                    audit,
                    emit=emit_audit,
                    context=actor_context,
                    policy=permission_policy,
                ),
            )
        visible = ranked[:limit]
        if len(ranked) > limit:
            exclusion_counts["limit_truncated"] = len(ranked) - limit
        visible_index_issues = self._visible_index_issues(
            index["bounded_issues"], allowed_kinds
        )
        audit = self._audit(
            query=normalized_query,
            context=actor_context,
            policy=permission_policy,
            index_revision=visible_index_revision,
            query_status="ok" if not visible_index_issues else "review_needed",
            results=visible,
            exclusion_counts=exclusion_counts,
            recorded_at=selected_time,
        )
        return self._search_response(
            status=audit["query_status"],
            results=visible,
            issues=visible_index_issues,
            audit=audit,
            audit_ref=self._maybe_write_audit(
                audit,
                emit=emit_audit,
                context=actor_context,
                policy=permission_policy,
            ),
        )

    @staticmethod
    def _allowed_source_kinds(
        context: ProjectPrincipalContext,
        policy: ProjectPermissionPolicy,
    ) -> set[str]:
        evidence_allowed = policy.allows(context, "project_evidence_read")
        memory_allowed = policy.allows(context, "project_memory_read")
        allowed: set[str] = set()
        if evidence_allowed:
            allowed.add("project_evidence")
        # Memory results disclose their exact source Evidence IDs.  Requiring
        # both capabilities prevents memory_read from becoming an Evidence-ID
        # side channel.
        if memory_allowed and evidence_allowed:
            allowed.add("project_memory")
        return allowed

    @staticmethod
    def _visible_index_revision(
        index: Mapping[str, Any],
        authorized_entries: Sequence[Mapping[str, Any]],
        allowed_kinds: set[str],
    ) -> str:
        if allowed_kinds == {"project_evidence", "project_memory"}:
            return index["index_revision"]
        inventory = index["source_inventory"]
        selected_inventory = {
            "evidence_records_sha256": inventory["evidence_records_sha256"],
            "evidence_lifecycle_sha256": inventory[
                "evidence_lifecycle_sha256"
            ],
        }
        if "project_memory" in allowed_kinds:
            selected_inventory.update(
                {
                    "memory_records_sha256": inventory[
                        "memory_records_sha256"
                    ],
                    "memory_lifecycle_sha256": inventory[
                        "memory_lifecycle_sha256"
                    ],
                }
            )
        return sha256_bytes(
            canonical_bytes(
                {
                    "project_id": index["project_id"],
                    "permission_policy_revision": index[
                        "permission_policy_revision"
                    ],
                    "effective_as_of": index["effective_as_of"],
                    "allowed_source_kinds": sorted(allowed_kinds),
                    "source_inventory": selected_inventory,
                    "entries": list(authorized_entries),
                }
            )
        )
    @staticmethod
    def _visible_index_issues(
        issues: Sequence[str], allowed_kinds: set[str],
    ) -> list[str]:
        visible_prefixes: set[str] = set()
        if allowed_kinds & {"project_evidence", "project_memory"}:
            visible_prefixes.add("evidence_")
            visible_prefixes.add("invalid_evidence")
        if "project_memory" in allowed_kinds:
            visible_prefixes.add("memory_")
            visible_prefixes.add("invalid_memory")
        return [
            issue
            for issue in issues
            if any(issue.startswith(prefix) for prefix in visible_prefixes)
        ]

    def _load_index(self, policy_revision: str) -> dict[str, Any]:
        target = self._path(INDEX_RELATIVE_PATH, create_parent=False)
        if target.is_symlink() or not target.is_file():
            return {"status": "review_needed", "issues": ["index_missing"]}
        try:
            value = json.loads(target.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            return {"status": "review_needed", "issues": ["index_unreadable"]}
        if not isinstance(value, Mapping):
            return {"status": "review_needed", "issues": ["index_invalid"]}
        required = {
            "schema_version",
            "artifact_type",
            "project_id",
            "permission_policy_revision",
            "effective_as_of",
            "source_inventory",
            "eligible_source_set_sha256",
            "entries",
            "build_status",
            "bounded_issues",
            "limitations",
            "index_revision",
        }
        body = {key: item for key, item in value.items() if key != "index_revision"}
        inventory = value.get("source_inventory")
        inventory_fields = {
            "evidence_records_sha256",
            "evidence_lifecycle_sha256",
            "memory_records_sha256",
            "memory_lifecycle_sha256",
        }
        valid_inventory = bool(
            isinstance(inventory, Mapping)
            and set(inventory) == inventory_fields
            and all(self._is_sha256(item) for item in inventory.values())
        )
        try:
            _timestamp(value.get("effective_as_of"), field="effective_as_of")
            valid_effective_as_of = True
        except (TypeError, ValueError):
            valid_effective_as_of = False
        bounded_issues = value.get("bounded_issues")
        if (
            set(value) != required
            or value.get("schema_version") != "1.0.0"
            or value.get("artifact_type")
            != "permission_aware_project_retrieval_index"
            or value.get("project_id") != self._project_id
            or value.get("permission_policy_revision") != policy_revision
            or not isinstance(value.get("entries"), list)
            or not valid_inventory
            or not valid_effective_as_of
            or not self._is_sha256(value.get("eligible_source_set_sha256"))
            or value.get("build_status") not in {"ok", "review_needed"}
            or not isinstance(bounded_issues, list)
            or any(not isinstance(item, str) for item in bounded_issues)
            or value.get("index_revision") != sha256_bytes(canonical_bytes(body))
        ):
            return {"status": "review_needed", "issues": ["index_invalid"]}
        return {
            "status": "ok",
            "index": dict(value),
            "index_revision": value["index_revision"],
            "issues": [],
        }

    @staticmethod
    def _is_sha256(value: Any) -> bool:
        return bool(
            isinstance(value, str)
            and len(value) == 64
            and all(character in "0123456789abcdef" for character in value)
        )

    def _stale_issues(
        self, index: Mapping[str, Any], allowed_kinds: set[str],
    ) -> list[str]:
        expected = index.get("source_inventory")
        if not isinstance(expected, Mapping):
            return ["index_inventory_invalid"]
        issues: list[str] = []
        evidence_needed = bool(
            allowed_kinds & {"project_evidence", "project_memory"}
        )
        if evidence_needed:
            observed = evidence_inventory(self._evidence_store)
            evidence_lifecycle = self._evidence_store.lifecycle_store()
            if expected.get("evidence_records_sha256") != observed[
                "inventory_sha256"
            ]:
                issues.append("evidence_index_stale")
            if expected.get(
                "evidence_lifecycle_sha256"
            ) != evidence_lifecycle.inventory_sha256():
                issues.append("evidence_lifecycle_index_stale")
        if "project_memory" in allowed_kinds:
            memory = self._memory_store.lifecycle_store().resolve_all(
                as_of=index["effective_as_of"]
            )
            if expected.get("memory_records_sha256") != memory[
                "memory_inventory_sha256"
            ]:
                issues.append("memory_index_stale")
            if expected.get("memory_lifecycle_sha256") != memory[
                "lifecycle_inventory_sha256"
            ]:
                issues.append("memory_lifecycle_index_stale")
        return sorted(dict.fromkeys(issues))

    @staticmethod
    def _rank_entries(
        entries: Sequence[Mapping[str, Any]],
        query: str,
        index_revision: str,
    ) -> tuple[list[dict[str, Any]], dict[str, int]]:
        tokens = list(
            dict.fromkeys(token.casefold() for token in query.split() if token)
        )
        ranked: list[dict[str, Any]] = []
        no_match = 0
        for entry in entries:
            required = {
                "source_kind",
                "source_id",
                "project_id",
                "source_revision",
                "record_sha256",
                "content_sha256",
                "lifecycle_state",
                "lifecycle_revision",
                "memory_key",
                "title",
                "text",
                "tags",
                "source_evidence_ids",
                "exact_source_ref",
            }
            if set(entry) != required:
                raise ValueError("codex_project_retrieval_index_entry_invalid")
            searchable = " ".join(
                [
                    entry["title"],
                    entry["text"],
                    *entry["tags"],
                    entry["source_revision"],
                ]
            ).casefold()
            matched = sum(token in searchable for token in tokens)
            if tokens and matched == 0:
                no_match += 1
                continue
            score = matched
            if query and query.casefold() in entry["title"].casefold():
                score += 2
            ranked.append(
                {
                    "score": score,
                    "source_kind": entry["source_kind"],
                    "source_id": entry["source_id"],
                    "project_id": entry["project_id"],
                    "source_revision": entry["source_revision"],
                    "record_sha256": entry["record_sha256"],
                    "content_sha256": entry["content_sha256"],
                    "effective_lifecycle_state": entry["lifecycle_state"],
                    "lifecycle_revision": entry["lifecycle_revision"],
                    "retrieval_index_revision": index_revision,
                    "memory_key": entry["memory_key"],
                    "title": entry["title"],
                    "text": entry["text"],
                    "source_evidence_ids": list(entry["source_evidence_ids"]),
                    "exact_source_ref": entry["exact_source_ref"],
                    "advisory_non_claim": RESULT_NON_CLAIM,
                }
            )
        ranked.sort(key=lambda item: (item["source_kind"], item["source_id"]))
        ranked.sort(key=lambda item: item["score"], reverse=True)
        exclusions = {"query_no_match": no_match} if no_match else {}
        return ranked, exclusions

    def _audit(
        self,
        *,
        query: str,
        context: ProjectPrincipalContext,
        policy: ProjectPermissionPolicy,
        index_revision: str | None,
        query_status: str,
        results: Sequence[Mapping[str, Any]],
        exclusion_counts: Mapping[str, int],
        recorded_at: str,
    ) -> dict[str, Any]:
        body = {
            "schema_version": "1.0.0",
            "artifact_type": "project_retrieval_query_audit",
            "project_id": self._project_id,
            "principal_id": context.principal_id,
            "principal_kind": context.principal_kind,
            "team_scope": context.team_id,
            "policy_revision": policy.policy_revision,
            "index_revision": index_revision,
            "query_sha256": sha256_bytes(query.encode("utf-8")),
            "query_status": query_status,
            "returned_source_refs": [
                {
                    "source_kind": item["source_kind"],
                    "source_id": item["source_id"],
                }
                for item in results
            ],
            "returned_count": len(results),
            "bounded_exclusion_reason_counts": {
                key: min(int(value), MAX_RESULTS)
                for key, value in sorted(exclusion_counts.items())
                if value > 0
            },
            "recorded_at": recorded_at,
            "non_claims": list(AUDIT_NON_CLAIMS),
        }
        digest = sha256_bytes(canonical_bytes(body))
        return {
            **body,
            "audit_id": f"project-retrieval-audit-{digest[:24]}",
            "content_sha256": digest,
        }

    def _maybe_write_audit(
        self,
        audit: Mapping[str, Any],
        *,
        emit: bool,
        context: ProjectPrincipalContext,
        policy: ProjectPermissionPolicy,
    ) -> str | None:
        if not emit:
            return None
        policy.require(context, "project_retrieval_audit")
        directory = self._path(AUDITS_RELATIVE_PATH / ".keep", create_parent=True)
        target = directory.parent / f"{audit['audit_id']}.json"
        serialized = pretty_bytes(audit)
        if target.exists():
            if target.is_symlink() or target.read_bytes() != serialized:
                raise ValueError("codex_project_retrieval_audit_conflict")
        else:
            temporary = target.parent / f".{target.name}.{uuid.uuid4().hex}.tmp"
            try:
                with temporary.open("xb") as output:
                    output.write(serialized)
                    output.flush()
                    os.fsync(output.fileno())
                os.replace(temporary, target)
            finally:
                if temporary.exists():
                    temporary.unlink()
        return target.relative_to(self._project_root).as_posix()

    @staticmethod
    def _search_response(
        *,
        status: str,
        results: Sequence[Mapping[str, Any]],
        issues: Sequence[str],
        audit: Mapping[str, Any],
        audit_ref: str | None,
    ) -> dict[str, Any]:
        return {
            "status": status,
            "results": [dict(item) for item in results],
            "result_count": len(results),
            "issues": list(issues),
            "audit": dict(audit),
            "audit_ref": audit_ref,
            "limitations": [
                "permissions_filtered_before_ranking",
                "keyword_metadata_content_retrieval_only",
                "team_memory_provider_disabled",
                "retrieval_grants_no_acceptance_gate_or_release_authority",
            ],
        }

    def exact_lookup(
        self,
        source_kind: str,
        source_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
    ) -> dict[str, Any]:
        """Authorized exact lookup independent of index and current eligibility."""
        self._check_scope(actor_context, permission_policy)
        selected_kind = normalized_text(
            source_kind, field="retrieval_source_kind", maximum=40
        )
        if selected_kind not in SOURCE_CAPABILITY:
            raise ValueError("codex_project_retrieval_source_kind_invalid")
        if not permission_policy.allows(
            actor_context, SOURCE_CAPABILITY[selected_kind]
        ):
            return {
                "status": "not_found",
                "source": None,
                "non_disclosure": True,
                "advisory_non_claim": RESULT_NON_CLAIM,
            }
        if selected_kind == "project_memory" and not permission_policy.allows(
            actor_context, "project_evidence_read"
        ):
            return {
                "status": "not_found",
                "source": None,
                "non_disclosure": True,
                "advisory_non_claim": RESULT_NON_CLAIM,
            }
        if selected_kind == "project_evidence":
            exact = self._evidence_store.verify(source_id)
        else:
            exact = self._memory_store.get(source_id)
        return {
            "status": exact["status"],
            "source": exact,
            "non_disclosure": False,
            "advisory_non_claim": RESULT_NON_CLAIM,
        }
