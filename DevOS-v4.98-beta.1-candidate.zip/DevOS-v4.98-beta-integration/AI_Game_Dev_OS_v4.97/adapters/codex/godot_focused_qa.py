"""Reusable, no-production-source-write focused QA for Godot projects.

The host selects one accepted task, its focused Godot scripts, and the exact
files whose identity must remain stable.  This runner binds the existing
``focused_qa_evidence_runner`` Agent/Skill contracts to the shell-free Godot
execution adapter, requires an exact clean Git source, writes evidence only to
an external artifact root, and emits a schema-valid ``qa_evidence_bundle``.

It is not a scheduler, an LLM or Agent invoker, a source repair surface, a
qualification runner, a Gate, or release authority.
"""

from __future__ import annotations

import hashlib
import json
import re
import shlex
import shutil
import subprocess
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Sequence

from adapters.codex.godot_execution_adapter import (
    GodotCommandResult,
    GodotExecutionAdapter,
    ProjectBoundaryError,
)


DEFAULT_TIMEOUT_SECONDS = 120.0
DEFAULT_GIT_TIMEOUT_SECONDS = 15.0
DEFAULT_QA_WRITE_ENVELOPE = ("res://tests/**",)
_EVIDENCE_NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
_REQUIRED_OPERATION_BINDINGS = {
    "focused_qa_preflight": "preflight",
    "godot_script_checks": "run_checks",
    "source_integrity_check": "capture_source_integrity",
    "emit_qa_evidence_bundle": "run",
}


class GodotFocusedQaError(RuntimeError):
    """Base error for invalid focused-QA inputs or execution boundaries."""


class FocusedQaConfigurationError(GodotFocusedQaError):
    """Raised when contracts, checks, or evidence configuration are invalid."""


class FocusedQaSourceError(GodotFocusedQaError):
    """Raised when QA is not bound to an exact clean Git source."""


@dataclass(frozen=True)
class FocusedQaCheck:
    """One must-observe Godot script and its required stdout token."""

    script_path: str
    pass_token: str


@dataclass(frozen=True)
class GodotFocusedQaRunResult:
    """Compact result for one external evidence-bundle run."""

    schema_version: str
    artifact_type: str
    task_id: str
    attempt_id: int
    actor_id: str
    agent_id: str
    skill_id: str
    binding_id: str
    status: str
    verdict: str
    source_commit: str
    evidence_root: str
    evidence_bundle_path: str
    command_count: int
    failed_check_count: int
    non_claims: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["non_claims"] = list(self.non_claims)
        return value


def _required_text(value: str, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise FocusedQaConfigurationError(f"{label} must be a non-empty string")
    if "\x00" in value:
        raise FocusedQaConfigurationError(f"{label} contains a NUL byte")
    return value.strip()


def _read_json_object(path: Path, *, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise FocusedQaConfigurationError(f"missing {label}: {path}") from exc
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise FocusedQaConfigurationError(f"invalid {label}: {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise FocusedQaConfigurationError(f"{label} must be a JSON object: {path}")
    return value


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json(path: Path, value: object) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


class GodotFocusedQaRunner:
    """Run one clean-source, externally evidenced Godot focused-QA attempt."""

    def __init__(
        self,
        *,
        project_root: str | Path,
        artifact_root: str | Path,
        evidence_name: str,
        task_id: str,
        attempt_id: int,
        actor_id: str,
        acceptance_criteria: Sequence[str],
        checks: Sequence[FocusedQaCheck],
        integrity_paths: Sequence[str | Path],
        failure_owner: str,
        next_skill_route: str,
        agent_contract_path: str | Path,
        skill_contract_path: str | Path,
        tool_binding_path: str | Path,
        evidence_schema_path: str | Path,
        godot_binary: str | Path,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    ) -> None:
        if not isinstance(attempt_id, int) or isinstance(attempt_id, bool) or attempt_id < 1:
            raise FocusedQaConfigurationError("attempt_id must be an integer >= 1")
        self.task_id = _required_text(task_id, "task_id")
        self.attempt_id = attempt_id
        self.actor_id = _required_text(actor_id, "actor_id")
        self.failure_owner = _required_text(failure_owner, "failure_owner")
        self.next_skill_route = _required_text(next_skill_route, "next_skill_route")

        criteria = tuple(
            _required_text(item, "acceptance_criteria item")
            for item in acceptance_criteria
        )
        if not criteria:
            raise FocusedQaConfigurationError("acceptance_criteria must not be empty")
        self.acceptance_criteria = criteria

        self.agent_contract_path = Path(agent_contract_path).resolve(strict=True)
        self.skill_contract_path = Path(skill_contract_path).resolve(strict=True)
        self.tool_binding_path = Path(tool_binding_path).resolve(strict=True)
        self.evidence_schema_path = Path(evidence_schema_path).resolve(strict=True)
        self.tool_binding = _read_json_object(
            self.tool_binding_path,
            label="focused-QA tool binding",
        )

        self.execution = GodotExecutionAdapter(
            project_root=project_root,
            task_id=self.task_id,
            attempt_id=self.attempt_id,
            actor_id=self.actor_id,
            agent_contract_path=self.agent_contract_path,
            skill_contract_path=self.skill_contract_path,
            declared_write_patterns=DEFAULT_QA_WRITE_ENVELOPE,
            godot_binary=godot_binary,
            timeout_seconds=timeout_seconds,
        )
        self.project_root = self.execution.project_root
        self.agent_id = self.execution.agent_id
        self.skill_id = self.execution.skill_id
        self.binding_id = self._validate_tool_binding()

        self.repository_root = self._resolve_repository_root()
        self.artifact_root = self._resolve_artifact_root(artifact_root)
        self.evidence_name = self._validate_evidence_name(evidence_name)
        self.evidence_root = self.artifact_root / self.evidence_name
        if self.evidence_root.exists():
            raise ProjectBoundaryError(
                f"focused-QA evidence output already exists: {self.evidence_root}"
            )

        if not checks:
            raise FocusedQaConfigurationError("checks must not be empty")
        normalized_checks: list[FocusedQaCheck] = []
        seen_scripts: set[str] = set()
        for check in checks:
            if not isinstance(check, FocusedQaCheck):
                raise FocusedQaConfigurationError(
                    "checks must contain FocusedQaCheck values"
                )
            relative = self.execution._normalize_project_relative(check.script_path)
            token = _required_text(check.pass_token, "check.pass_token")
            if relative in seen_scripts:
                raise FocusedQaConfigurationError(
                    f"duplicate focused-QA script: {relative}"
                )
            self._resolve_project_file(relative, required_suffix=".gd")
            seen_scripts.add(relative)
            normalized_checks.append(FocusedQaCheck(relative, token))
        self.checks = tuple(normalized_checks)

        if not integrity_paths:
            raise FocusedQaConfigurationError("integrity_paths must not be empty")
        normalized_integrity: list[str] = []
        for raw_path in integrity_paths:
            relative = self.execution._normalize_project_relative(raw_path)
            if relative in normalized_integrity:
                raise FocusedQaConfigurationError(
                    f"duplicate integrity path: {relative}"
                )
            self._resolve_project_file(relative)
            normalized_integrity.append(relative)
        missing_check_integrity = sorted(seen_scripts - set(normalized_integrity))
        if missing_check_integrity:
            raise FocusedQaConfigurationError(
                "every focused-QA script must be an integrity path: "
                + ", ".join(missing_check_integrity)
            )
        self.integrity_paths = tuple(normalized_integrity)

    def _validate_tool_binding(self) -> str:
        binding = self.tool_binding
        if binding.get("artifact_type") != "focused_qa_tool_binding":
            raise FocusedQaConfigurationError(
                "focused-QA binding has the wrong artifact_type"
            )
        if binding.get("binding_status") != "draft":
            raise FocusedQaConfigurationError(
                "focused-QA binding has an unsupported binding_status"
            )
        binding_id = _required_text(str(binding.get("binding_id", "")), "binding_id")
        if binding.get("agent_id") != self.agent_id:
            raise FocusedQaConfigurationError(
                "focused-QA binding does not match selected Agent"
            )
        if binding.get("skill_id") != self.skill_id:
            raise FocusedQaConfigurationError(
                "focused-QA binding does not match selected Skill"
            )
        if binding.get("runtime_api") != "adapters/codex/godot_focused_qa.py":
            raise FocusedQaConfigurationError(
                "focused-QA binding names an unsupported runtime API"
            )
        if binding.get("engine_adapter") != (
            "adapters/codex/godot_execution_adapter.py"
        ):
            raise FocusedQaConfigurationError(
                "focused-QA binding names an unsupported engine adapter"
            )
        if binding.get("write_semantics") != (
            "external_evidence_only_no_production_source_write"
        ):
            raise FocusedQaConfigurationError(
                "focused-QA binding has unsafe write semantics"
            )

        version_root = self.tool_binding_path.parents[3]
        references = {
            "agent_contract": self.agent_contract_path,
            "skill_contract": self.skill_contract_path,
            "evidence_schema": self.evidence_schema_path,
        }
        for field, selected_path in references.items():
            raw_reference = binding.get(field)
            if not isinstance(raw_reference, str) or not raw_reference:
                raise FocusedQaConfigurationError(
                    f"focused-QA binding has no {field}"
                )
            resolved_reference = (version_root / raw_reference).resolve(strict=True)
            if resolved_reference != selected_path:
                raise FocusedQaConfigurationError(
                    f"focused-QA binding {field} does not match selected path"
                )

        operations = binding.get("operation_bindings")
        if not isinstance(operations, list):
            raise FocusedQaConfigurationError(
                "focused-QA binding operation_bindings must be a list"
            )
        observed: dict[str, str] = {}
        for operation in operations:
            if not isinstance(operation, dict):
                raise FocusedQaConfigurationError(
                    "focused-QA binding operation must be an object"
                )
            operation_id = operation.get("operation_id")
            runner_method = operation.get("runner_method")
            if not isinstance(operation_id, str) or not isinstance(runner_method, str):
                raise FocusedQaConfigurationError(
                    "focused-QA binding operation needs string IDs and methods"
                )
            if operation_id in observed:
                raise FocusedQaConfigurationError(
                    f"duplicate focused-QA binding operation: {operation_id}"
                )
            observed[operation_id] = runner_method
        for operation_id, expected_method in _REQUIRED_OPERATION_BINDINGS.items():
            if observed.get(operation_id) != expected_method:
                raise FocusedQaConfigurationError(
                    f"missing or invalid focused-QA binding: {operation_id}"
                )
        return binding_id

    def _git(
        self,
        *arguments: str,
        require_success: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        try:
            result = subprocess.run(
                ["git", "-C", str(self.project_root), *arguments],
                check=False,
                capture_output=True,
                text=True,
                timeout=DEFAULT_GIT_TIMEOUT_SECONDS,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise FocusedQaSourceError(f"Git inspection failed: {exc}") from exc
        if require_success and result.returncode != 0:
            detail = (result.stderr or result.stdout).strip()
            raise FocusedQaSourceError(
                f"Git command failed ({result.returncode}): {detail}"
            )
        return result

    def _resolve_repository_root(self) -> Path:
        value = self._git("rev-parse", "--show-toplevel").stdout.strip()
        try:
            repository_root = Path(value).resolve(strict=True)
            self.project_root.relative_to(repository_root)
        except (OSError, ValueError) as exc:
            raise FocusedQaSourceError(
                "focused-QA project must be inside its resolved Git repository"
            ) from exc
        return repository_root

    def _resolve_artifact_root(self, raw_path: str | Path) -> Path:
        candidate = Path(raw_path)
        if not candidate.is_absolute() or "\x00" in str(candidate):
            raise ProjectBoundaryError(
                "focused-QA artifact_root must be an absolute safe path"
            )
        resolved = candidate.resolve(strict=True)
        if not resolved.is_dir():
            raise ProjectBoundaryError(
                f"focused-QA artifact_root is not a directory: {resolved}"
            )
        try:
            resolved.relative_to(self.repository_root)
        except ValueError:
            return resolved
        raise ProjectBoundaryError(
            "focused-QA artifact_root must stay outside the source repository"
        )

    @staticmethod
    def _validate_evidence_name(value: str) -> str:
        name = _required_text(value, "evidence_name")
        if not _EVIDENCE_NAME_PATTERN.fullmatch(name) or name in {".", ".."}:
            raise ProjectBoundaryError(
                "evidence_name must be one safe directory name"
            )
        return name

    def _resolve_project_file(
        self,
        relative_path: str,
        *,
        required_suffix: str | None = None,
    ) -> Path:
        current = self.project_root
        for part in PurePosixPath(relative_path).parts:
            current = current / part
            if current.is_symlink():
                raise ProjectBoundaryError(
                    f"symlinked focused-QA input is unsupported: {relative_path}"
                )
        try:
            resolved = current.resolve(strict=True)
            resolved.relative_to(self.project_root)
        except (OSError, ValueError) as exc:
            raise ProjectBoundaryError(
                f"focused-QA input escapes selected project: {relative_path}"
            ) from exc
        if not resolved.is_file():
            raise ProjectBoundaryError(
                f"focused-QA input is not a regular file: {relative_path}"
            )
        if required_suffix is not None and resolved.suffix.lower() != required_suffix:
            raise FocusedQaConfigurationError(
                f"focused-QA script must end with {required_suffix}: {relative_path}"
            )
        return resolved

    def capture_source_integrity(self) -> dict[str, Any]:
        head = self._git("rev-parse", "HEAD")
        tree = self._git("rev-parse", "HEAD^{tree}")
        status = self._git("status", "--porcelain=v1", "--untracked-files=all")
        diff_check = self._git("diff", "--check", require_success=False)
        return {
            "repository_root": str(self.repository_root),
            "project_root": str(self.project_root),
            "head": head.stdout.strip(),
            "tree": tree.stdout.strip(),
            "status_porcelain": status.stdout,
            "status_exit_code": status.returncode,
            "diff_check_stdout": diff_check.stdout,
            "diff_check_stderr": diff_check.stderr,
            "diff_check_exit_code": diff_check.returncode,
            "file_sha256": {
                relative: _sha256_file(self._resolve_project_file(relative))
                for relative in self.integrity_paths
            },
        }

    @staticmethod
    def _is_clean_source(state: dict[str, Any]) -> bool:
        return (
            state["status_exit_code"] == 0
            and state["status_porcelain"] == ""
            and state["diff_check_exit_code"] == 0
        )

    def preflight(self) -> dict[str, Any]:
        execution_preflight = self.execution.preflight()
        return {
            "schema_version": "1.0.0",
            "artifact_type": "godot_focused_qa_preflight",
            "task_id": self.task_id,
            "attempt_id": self.attempt_id,
            "actor_id": self.actor_id,
            "agent_id": self.agent_id,
            "skill_id": self.skill_id,
            "binding_id": self.binding_id,
            "binding_status": self.tool_binding.get("binding_status"),
            "acceptance_criteria": list(self.acceptance_criteria),
            "checks": [asdict(check) for check in self.checks],
            "integrity_paths": list(self.integrity_paths),
            "evidence_root": str(self.evidence_root),
            "execution_preflight": execution_preflight,
            "status": execution_preflight.get("status"),
            "write_semantics": (
                "external_evidence_only_no_production_source_write"
            ),
            "non_claims": [
                "qa_binding_status_is_not_execution_authority",
                "preflight_is_not_qualification_or_gate_evidence",
                "preflight_grants_no_source_write_or_release_authority",
            ],
        }

    def run_checks(self) -> tuple[GodotCommandResult, ...]:
        return tuple(
            self.execution.run_script(
                check.script_path,
                expected_pass_token=check.pass_token,
            )
            for check in self.checks
        )

    @staticmethod
    def _artifact_record(path: Path, kind: str) -> dict[str, str]:
        return {
            "path": path.name,
            "kind": kind,
            "hash": f"sha256:{_sha256_file(path)}",
        }

    def _command_record(
        self,
        result: GodotCommandResult,
        stdout_path: Path,
    ) -> dict[str, Any]:
        return {
            "command": shlex.join(result.command),
            "cwd": str(self.project_root),
            "exit_code": int(result.exit_code) if result.exit_code is not None else -1,
            "pass_token": (
                result.expected_pass_token if result.status == "pass" else None
            ),
            "stdout_path": stdout_path.name,
            "status": "pass" if result.status == "pass" else "fail",
        }

    def _git_diff_command_record(
        self,
        state: dict[str, Any],
        integrity_path: Path,
    ) -> dict[str, Any]:
        command = (
            "git",
            "-C",
            str(self.project_root),
            "diff",
            "--check",
        )
        exit_code = int(state["diff_check_exit_code"])
        return {
            "command": shlex.join(command),
            "cwd": str(self.project_root),
            "exit_code": exit_code,
            "pass_token": None,
            "stdout_path": integrity_path.name,
            "status": "pass" if exit_code == 0 else "fail",
        }

    def _validate_bundle(self, bundle: dict[str, Any], staging_root: Path) -> None:
        try:
            import jsonschema
        except ImportError as exc:
            raise FocusedQaConfigurationError(
                "jsonschema is required to validate focused-QA evidence"
            ) from exc
        schema = _read_json_object(
            self.evidence_schema_path,
            label="qa_evidence_bundle schema",
        )
        try:
            jsonschema.Draft7Validator(schema).validate(bundle)
        except jsonschema.ValidationError as exc:
            raise FocusedQaConfigurationError(
                f"generated focused-QA bundle is schema-invalid: {exc.message}"
            ) from exc

        for command in bundle["commands"]:
            stdout_path = staging_root / command["stdout_path"]
            if not stdout_path.is_file():
                raise FocusedQaConfigurationError(
                    f"generated focused-QA stdout is missing: {stdout_path.name}"
                )
            token = command.get("pass_token")
            if token and token not in stdout_path.read_text(
                encoding="utf-8",
                errors="replace",
            ):
                raise FocusedQaConfigurationError(
                    f"generated focused-QA stdout lacks PASS token: {token!r}"
                )
        for artifact in bundle["artifacts"]:
            if not (staging_root / artifact["path"]).is_file():
                raise FocusedQaConfigurationError(
                    "generated focused-QA artifact is missing: "
                    f"{artifact['path']}"
                )

    def run(self) -> GodotFocusedQaRunResult:
        before = self.capture_source_integrity()
        if not self._is_clean_source(before):
            raise FocusedQaSourceError(
                "focused-QA requires a clean exact Git source before execution"
            )
        if self.evidence_root.exists():
            raise ProjectBoundaryError(
                f"focused-QA evidence output already exists: {self.evidence_root}"
            )

        staging_root = self.artifact_root / (
            f".{self.evidence_name}.tmp-{uuid.uuid4().hex}"
        )
        staging_root.mkdir()
        try:
            preflight = self.preflight()
            if preflight["status"] != "ready":
                raise FocusedQaConfigurationError("Godot focused-QA preflight blocked")
            preflight_path = staging_root / "00_preflight.json"
            _write_json(preflight_path, preflight)

            run_results = self.run_checks()
            run_result_paths: list[Path] = []
            run_stdout_paths: list[Path] = []
            run_stderr_paths: list[Path] = []
            for index, result in enumerate(run_results, start=1):
                result_path = staging_root / f"{index:02d}_godot_check.result.json"
                stdout_path = staging_root / f"{index:02d}_godot_check.stdout.txt"
                stderr_path = staging_root / f"{index:02d}_godot_check.stderr.txt"
                _write_json(result_path, result.to_dict())
                stdout_path.write_text(result.stdout, encoding="utf-8")
                stderr_path.write_text(result.stderr, encoding="utf-8")
                run_result_paths.append(result_path)
                run_stdout_paths.append(stdout_path)
                run_stderr_paths.append(stderr_path)

            after = self.capture_source_integrity()
            source_unchanged = before == after
            source_clean_after = self._is_clean_source(after)
            integrity = {
                "schema_version": "1.0.0",
                "artifact_type": "focused_qa_source_integrity",
                "task_id": self.task_id,
                "attempt_id": self.attempt_id,
                "actor_id": self.actor_id,
                "before": before,
                "after": after,
                "source_unchanged": source_unchanged,
                "source_clean_before": True,
                "source_clean_after": source_clean_after,
                "non_claims": [
                    "source_integrity_is_not_qualification_or_gate_evidence",
                    "clean_source_does_not_promote_the_qa_recommendation",
                ],
            }
            integrity_path = staging_root / "99_source_integrity.json"
            _write_json(integrity_path, integrity)

            failed_check_count = sum(
                result.status != "pass" for result in run_results
            )
            if not source_unchanged or not source_clean_after:
                verdict = "BLOCKED"
            elif failed_check_count:
                verdict = "REVIEW_NEEDED"
            else:
                verdict = "DONE"
            bundle = {
                "schema_version": "1.0.0",
                "artifact_type": "qa_evidence_bundle",
                "task_id": self.task_id,
                "commands": [
                    self._git_diff_command_record(before, integrity_path),
                    *(
                        self._command_record(result, path)
                        for result, path in zip(
                            run_results,
                            run_stdout_paths,
                            strict=True,
                        )
                    ),
                    self._git_diff_command_record(after, integrity_path),
                ],
                "artifacts": [
                    self._artifact_record(preflight_path, "report"),
                    *(
                        artifact
                        for result_path, stdout_path, stderr_path in zip(
                            run_result_paths,
                            run_stdout_paths,
                            run_stderr_paths,
                            strict=True,
                        )
                        for artifact in (
                            self._artifact_record(result_path, "report"),
                            self._artifact_record(stdout_path, "stdout"),
                            self._artifact_record(stderr_path, "stderr"),
                        )
                    ),
                    self._artifact_record(integrity_path, "report"),
                ],
                "verdict": verdict,
                "failure_owner": None if verdict == "DONE" else self.failure_owner,
                "next_skill_route": (
                    None if verdict == "DONE" else self.next_skill_route
                ),
            }
            self._validate_bundle(bundle, staging_root)
            bundle_path = staging_root / "qa_evidence_bundle.json"
            _write_json(bundle_path, bundle)

            staging_root.replace(self.evidence_root)
            final_bundle_path = self.evidence_root / bundle_path.name
            return GodotFocusedQaRunResult(
                schema_version="1.0.0",
                artifact_type="godot_focused_qa_run",
                task_id=self.task_id,
                attempt_id=self.attempt_id,
                actor_id=self.actor_id,
                agent_id=self.agent_id,
                skill_id=self.skill_id,
                binding_id=self.binding_id,
                status=verdict.lower(),
                verdict=verdict,
                source_commit=str(after["head"]),
                evidence_root=str(self.evidence_root),
                evidence_bundle_path=str(final_bundle_path),
                command_count=len(bundle["commands"]),
                failed_check_count=failed_check_count,
                non_claims=(
                    "focused_qa_done_is_a_local_recommendation_only",
                    "focused_qa_is_not_human_acceptance",
                    "focused_qa_is_not_qualification_gate_or_release_authority",
                    "focused_qa_grants_no_production_or_live_authority",
                ),
            )
        except Exception:
            if staging_root.exists():
                shutil.rmtree(staging_root)
            raise
