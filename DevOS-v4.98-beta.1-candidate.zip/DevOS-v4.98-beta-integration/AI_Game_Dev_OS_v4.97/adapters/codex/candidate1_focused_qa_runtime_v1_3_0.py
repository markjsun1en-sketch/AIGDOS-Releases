"""Terminal-artifact lifecycle successor for Candidate 1 focused QA.

The exact v1.2.0 runtime remains unchanged because accepted Assembly Evidence
binds its bytes.  This successor delegates the QA operation to v1.2.0 and,
after a terminal receipt exists, compacts only the per-run workspace, cache,
and disposable Godot copy.  Evidence, logs, the source clone, the shared Godot
support root, and the v4.97 package are durable or protected roots.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from adapters.codex import candidate1_focused_qa_runtime_v1_2_0 as runtime_v1_2_0
from os_layer.scripts.portable_workspace.resource_lifecycle import (
    ResourceLifecycleError,
    ResourceLifecycleService,
    normalize_allocation_request,
)
from production_runtime.execution_artifact_lifecycle import (
    COMPACTION_RECEIPT_NAME,
    compact_terminal_run_root,
)


VERSION_ROOT = Path(__file__).resolve().parents[2]
ALLOWED_CHECKS = runtime_v1_2_0.ALLOWED_CHECKS
Candidate1FocusedQaAssemblyError = (
    runtime_v1_2_0.Candidate1FocusedQaAssemblyError
)
INTEGRITY_PATHS = runtime_v1_2_0.INTEGRITY_PATHS
_materialize_disposable_godot = runtime_v1_2_0._materialize_disposable_godot
_support_root_manifest = runtime_v1_2_0._support_root_manifest
verify_focused_qa_authorization = runtime_v1_2_0.verify_focused_qa_authorization
LEGACY_MATERIALIZATION_REASON = (
    "accepted_candidate1_v1_2_0_legacy_physical_copy_wrapper"
)
ACCEPTED_RUNTIME_RAW_SHA256 = (
    "310719ab09e6d4757274080fde546de81c47ab5e25294349e688f0480927b025"
)


def _managed_request(
    value: Mapping[str, Any],
    *,
    source_clone_root: Path,
    external_root: Path,
    execution_id: str,
    attempt_id: int,
) -> dict[str, Any]:
    request = normalize_allocation_request(value)
    identity = request["identity"]
    materialization = request["materialization"]
    authority = request["authority"]
    expected_run_root = external_root / execution_id
    exact = {
        "resource_class": "execution_root",
        "purpose": "independent_qa",
        "attempt_id": attempt_id,
    }
    for field, expected in exact.items():
        if identity[field] != expected:
            raise Candidate1FocusedQaAssemblyError(
                f"resource_request_identity_mismatch:{field}"
            )
    materialization_exact = {
        "profile": "full_tracked_cow",
        "source_path": str(source_clone_root),
        "admitted_parent": str(external_root),
        "requested_path": str(expected_run_root),
        "physical_fallback_allowed": True,
        "full_materialization_reason": LEGACY_MATERIALIZATION_REASON,
    }
    for field, expected in materialization_exact.items():
        if materialization[field] != expected:
            raise Candidate1FocusedQaAssemblyError(
                f"resource_request_materialization_mismatch:{field}"
            )
    if authority != {
        "project_write": False,
        "git_branch_create": False,
        "engine_execute": True,
        "historical_cleanup": False,
        "authority_ref": authority["authority_ref"],
    }:
        raise Candidate1FocusedQaAssemblyError(
            "resource_request_authority_mismatch"
        )
    return request


def _close_exact_consumers(
    lifecycle: ResourceLifecycleService,
    lease: Mapping[str, Any],
    consumer_ids: Sequence[str],
) -> dict[str, Any]:
    if isinstance(consumer_ids, (str, bytes)) or not consumer_ids:
        raise Candidate1FocusedQaAssemblyError(
            "terminal_consumer_ids_invalid"
        )
    selected = list(consumer_ids)
    if len(set(selected)) != len(selected):
        raise Candidate1FocusedQaAssemblyError(
            "terminal_consumer_ids_duplicate"
        )
    current = dict(lease)
    known = {
        consumer["consumer_id"]
        for consumer in current["retention"]["consumer_ids"]
    }
    if not set(selected).issubset(known):
        raise Candidate1FocusedQaAssemblyError(
            "terminal_consumer_id_not_in_lease"
        )
    for consumer_id in selected:
        observed = next(
            consumer
            for consumer in current["retention"]["consumer_ids"]
            if consumer["consumer_id"] == consumer_id
        )
        if observed["disposition"] == "complete":
            continue
        current = lifecycle.set_consumer_disposition(
            current["resource_id"],
            expected_generation=current["generation"],
            consumer_id=consumer_id,
            disposition="complete",
        )
    return current


def _failure_blocker(run_root: Path) -> str:
    failure_path = (
        run_root
        / "evidence"
        / "candidate1_focused_qa_failure_receipt.json"
    )
    if failure_path.is_file() and not failure_path.is_symlink():
        try:
            failure = json.loads(failure_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return "recovery_pending"
        support = failure.get("shared_godot_support_root")
        if isinstance(support, Mapping) and support.get("unchanged") is False:
            return "boundary_incident_unreviewed"
    return "recovery_pending"


def finalize_candidate1_focused_qa_artifacts(
    *,
    run_root: str | Path,
    execution_id: str,
    terminal_state: str,
    terminal_receipt_path: str | Path,
    source_clone_root: str | Path,
    godot_support_root: str | Path,
    resource_lease_binding: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Compact one terminal Candidate 1 run without changing QA Evidence."""

    return compact_terminal_run_root(
        run_root,
        execution_id=execution_id,
        terminal_state=terminal_state,
        terminal_receipt_path=terminal_receipt_path,
        transient_children=("workspace", "cache", "godot_tool"),
        durable_children=("evidence", "logs"),
        protected_roots=(source_clone_root, godot_support_root, VERSION_ROOT),
        resource_lease_binding=resource_lease_binding,
    )


def finalize_managed_candidate1_focused_qa_artifacts(
    *,
    resource_lifecycle_service: ResourceLifecycleService,
    resource_id: str,
    lease_generation: int,
    run_root: str | Path,
    execution_id: str,
    terminal_state: str,
    terminal_receipt_path: str | Path,
    source_clone_root: str | Path,
    godot_support_root: str | Path,
    terminal_consumer_ids: Sequence[str] = ("focused-qa",),
) -> dict[str, Any]:
    """Close exact consumers and compact one centrally leased QA run."""

    lifecycle = resource_lifecycle_service
    if not isinstance(lifecycle, ResourceLifecycleService):
        raise TypeError("resource_lifecycle_service_required")
    run = Path(run_root).resolve(strict=True)
    lease = lifecycle.lease(resource_id)
    if lease is None or lease["generation"] != lease_generation:
        raise Candidate1FocusedQaAssemblyError(
            "resource_lease_identity_mismatch"
        )
    if lease["canonical_path"] not in {None, str(run)}:
        raise Candidate1FocusedQaAssemblyError(
            "resource_lease_run_root_mismatch"
        )
    if lease["state"] == "compacted":
        compaction_path = run / COMPACTION_RECEIPT_NAME
        if not compaction_path.is_file() or compaction_path.is_symlink():
            raise Candidate1FocusedQaAssemblyError(
                "managed_compaction_receipt_missing"
            )
        compaction = json.loads(compaction_path.read_text(encoding="utf-8"))
        completion = lifecycle.complete_finalization(
            resource_id,
            expected_generation=lease_generation,
            terminal_receipt=compaction,
        )
        return {"compaction": compaction, **completion}
    if lease["state"] == "blocked":
        resume_state = lease["blocked_from_state"]
        if resume_state not in {
            "materializing",
            "active",
            "consumer_hold",
            "terminal",
            "finalizing",
        }:
            raise Candidate1FocusedQaAssemblyError(
                "managed_resource_not_resumable"
            )
        lease = lifecycle.transition(
            resource_id,
            expected_generation=lease_generation,
            to_state=resume_state,
            outcome=(
                terminal_state
                if resume_state in {"terminal", "finalizing"}
                else None
            ),
        )
    if lease["state"] == "materializing":
        lease = lifecycle.transition(
            resource_id,
            expected_generation=lease_generation,
            to_state="active",
            canonical_path=run,
            materialization_receipt={
                "method": "accepted_candidate1_v1_2_0_recovered_run_root",
                "accepted_runtime_raw_sha256": ACCEPTED_RUNTIME_RAW_SHA256,
                "physical_fallback_used": True,
                "full_materialization_reason": LEGACY_MATERIALIZATION_REASON,
            },
        )
    if lease["state"] in {"active", "consumer_hold"}:
        lease = _close_exact_consumers(
            lifecycle, lease, terminal_consumer_ids
        )
    prepared = lifecycle.prepare_finalization(
        resource_id,
        expected_generation=lease_generation,
        outcome=terminal_state,
    )
    if not prepared["ready"]:
        return {
            "compaction": None,
            "lease": prepared["lease"],
            "cleanup_receipt": None,
            "blockers": prepared["blockers"],
        }
    binding = lifecycle.finalization_binding(
        resource_id, expected_generation=lease_generation
    )
    compaction = finalize_candidate1_focused_qa_artifacts(
        run_root=run,
        execution_id=execution_id,
        terminal_state=terminal_state,
        terminal_receipt_path=terminal_receipt_path,
        source_clone_root=source_clone_root,
        godot_support_root=godot_support_root,
        resource_lease_binding=binding,
    )
    completion = lifecycle.complete_finalization(
        resource_id,
        expected_generation=lease_generation,
        terminal_receipt=compaction,
    )
    return {"compaction": compaction, **completion, "blockers": []}


def run_candidate1_focused_qa(
    *,
    assembly_lock: Mapping[str, Any] | str | Path,
    assembly_component_paths: Sequence[str | Path],
    project_binding: Mapping[str, Any] | str | Path,
    qa_evidence_policy: Mapping[str, Any] | str | Path,
    stage_contract_binding: Mapping[str, Any] | str | Path,
    source_clone_root: str | Path,
    external_root: str | Path,
    execution_id: str,
    attempt_id: int,
    check_paths: Sequence[str],
    acceptance_criteria: Sequence[str],
    godot_host_tool_identity: Mapping[str, Any] | str | Path,
    git_host_tool_identity: Mapping[str, Any] | str | Path,
    godot_support_root: str | Path,
    resource_lifecycle_service: ResourceLifecycleService,
    resource_allocation_request: Mapping[str, Any],
    terminal_consumer_ids: Sequence[str] = ("focused-qa",),
    timeout_seconds: float = 120.0,
    project_load_timeout_seconds: float = 300.0,
    retain_terminal_artifacts: bool = False,
) -> dict[str, Any]:
    """Run exact v1.2.0 QA, then compact its terminal transient payload.

    ``retain_terminal_artifacts=True`` is the explicit diagnostic opt-out.
    A raised attempt remains available for recovery or forensic review because
    the wrapper cannot infer that every protected boundary is still exact.
    After explicit failure classification, a caller may pass the failure
    receipt to ``finalize_candidate1_focused_qa_artifacts`` with terminal state
    ``failed``.
    """

    if not isinstance(retain_terminal_artifacts, bool):
        raise Candidate1FocusedQaAssemblyError(
            "retain_terminal_artifacts_not_boolean"
        )
    lifecycle = resource_lifecycle_service
    if not isinstance(lifecycle, ResourceLifecycleService):
        raise TypeError("resource_lifecycle_service_required")
    source = Path(source_clone_root).resolve(strict=True)
    external = Path(external_root).resolve(strict=True)
    request = _managed_request(
        resource_allocation_request,
        source_clone_root=source,
        external_root=external,
        execution_id=execution_id,
        attempt_id=attempt_id,
    )
    reservation = lifecycle.reserve(request)
    if reservation["lease"] is None:
        recommendation = reservation["gc_recommendation"]
        raise Candidate1FocusedQaAssemblyError(
            f"resource_allocation_blocked:{recommendation['blocker_code']}"
        )
    lease = reservation["lease"]
    run_root = external / execution_id
    owns_materialization = False
    arguments = {
        "assembly_lock": assembly_lock,
        "assembly_component_paths": assembly_component_paths,
        "project_binding": project_binding,
        "qa_evidence_policy": qa_evidence_policy,
        "stage_contract_binding": stage_contract_binding,
        "source_clone_root": source_clone_root,
        "external_root": external_root,
        "execution_id": execution_id,
        "attempt_id": attempt_id,
        "check_paths": check_paths,
        "acceptance_criteria": acceptance_criteria,
        "godot_host_tool_identity": godot_host_tool_identity,
        "git_host_tool_identity": git_host_tool_identity,
        "godot_support_root": godot_support_root,
        "timeout_seconds": timeout_seconds,
        "project_load_timeout_seconds": project_load_timeout_seconds,
    }
    try:
        lease = lifecycle.transition(
            lease["resource_id"],
            expected_generation=lease["generation"],
            to_state="materializing",
        )
        owns_materialization = True
        result = runtime_v1_2_0.run_candidate1_focused_qa(**arguments)
        observed_root = Path(result["run_root"]).resolve(strict=True)
        if observed_root != run_root:
            raise Candidate1FocusedQaAssemblyError(
                "managed_runtime_run_root_mismatch"
            )
        lease = lifecycle.transition(
            lease["resource_id"],
            expected_generation=lease["generation"],
            to_state="active",
            canonical_path=observed_root,
            materialization_receipt={
                "method": "accepted_candidate1_v1_2_0_legacy_physical_copy",
                "accepted_runtime_raw_sha256": ACCEPTED_RUNTIME_RAW_SHA256,
                "physical_fallback_used": True,
                "full_materialization_reason": LEGACY_MATERIALIZATION_REASON,
            },
        )
    except Exception:
        if owns_materialization:
            current = lifecycle.lease(lease["resource_id"])
            if current is not None and current["state"] not in {
                "blocked",
                "finalizing",
                "compacted",
                "released",
            }:
                try:
                    lifecycle.mark_blocked(
                        current["resource_id"],
                        expected_generation=current["generation"],
                        blocker_code=_failure_blocker(run_root),
                    )
                except ResourceLifecycleError:
                    pass
        raise

    if retain_terminal_artifacts:
        held = lifecycle.transition(
            lease["resource_id"],
            expected_generation=lease["generation"],
            to_state="consumer_hold",
            outcome=result.get("status"),
        )
        return {
            **result,
            "terminal_artifacts_retained": True,
            "durable_artifacts_retained": True,
            "compaction_receipt_path": None,
            "resource_id": held["resource_id"],
            "resource_lease_generation": held["generation"],
            "resource_state": held["state"],
        }
    status = result.get("status")
    if status not in {"passed", "review_needed"}:
        raise Candidate1FocusedQaAssemblyError(
            "focused_qa_result_status_not_terminal"
        )
    managed = finalize_managed_candidate1_focused_qa_artifacts(
        resource_lifecycle_service=lifecycle,
        resource_id=lease["resource_id"],
        lease_generation=lease["generation"],
        run_root=result["run_root"],
        execution_id=execution_id,
        terminal_state=status,
        terminal_receipt_path=result["result_path"],
        source_clone_root=source_clone_root,
        godot_support_root=godot_support_root,
        terminal_consumer_ids=terminal_consumer_ids,
    )
    compaction = managed["compaction"]
    if compaction is None:
        return {
            **result,
            "terminal_artifacts_retained": True,
            "durable_artifacts_retained": True,
            "compaction_receipt_path": None,
            "resource_id": managed["lease"]["resource_id"],
            "resource_lease_generation": managed["lease"]["generation"],
            "resource_state": managed["lease"]["state"],
            "resource_blockers": managed["blockers"],
        }
    return {
        **result,
        "terminal_artifacts_retained": False,
        "durable_artifacts_retained": True,
        "workspace_root_available": False,
        "compaction_receipt_path": str(
            Path(result["run_root"])
            / "execution_artifact_compaction_receipt.json"
        ),
        "compaction_status": compaction["status"],
        "resource_id": managed["lease"]["resource_id"],
        "resource_lease_generation": managed["lease"]["generation"],
        "resource_state": managed["lease"]["state"],
        "resource_cleanup_receipt_sha256": managed["cleanup_receipt"][
            "receipt_sha256"
        ],
    }


__all__ = [
    "ALLOWED_CHECKS",
    "Candidate1FocusedQaAssemblyError",
    "INTEGRITY_PATHS",
    "_materialize_disposable_godot",
    "_support_root_manifest",
    "finalize_candidate1_focused_qa_artifacts",
    "finalize_managed_candidate1_focused_qa_artifacts",
    "run_candidate1_focused_qa",
    "verify_focused_qa_authorization",
]
