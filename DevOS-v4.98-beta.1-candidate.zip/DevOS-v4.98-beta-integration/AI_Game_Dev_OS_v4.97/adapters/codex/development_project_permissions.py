"""Small deny-by-default permission model for project knowledge operations.

The policy is an explicit input to lifecycle and retrieval operations.  It is
not an authentication system and grants no authority outside the named local
project capabilities.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence


PRINCIPAL_KINDS = frozenset(
    {"project", "team", "user", "agent", "skill", "pack", "tool"}
)
PROJECT_KNOWLEDGE_CAPABILITIES = frozenset(
    {
        "project_evidence_read",
        "project_memory_read",
        "project_memory_propose",
        "project_memory_publish",
        "project_memory_supersede",
        "project_memory_deprecate",
        "project_memory_invalidate",
        "project_memory_redact",
        "project_memory_recover",
        "project_retrieval_audit",
        "project_compatibility_migrate",
        "project_derived_state_discard",
        "team_memory_activate",
        "team_memory_read",
        "team_memory_propose",
        "team_memory_review",
        "team_memory_publish",
        "team_memory_supersede",
        "team_memory_invalidate",
        "team_memory_redact",
        "team_memory_export_receipt",
    }
)


def _text(value: Any, *, field: str, maximum: int = 200) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"codex_project_permission_{field}_required")
    normalized = value.strip()
    if len(normalized) > maximum:
        raise ValueError(f"codex_project_permission_{field}_too_long")
    return normalized


def _optional_text(value: Any, *, field: str) -> str | None:
    if value is None:
        return None
    return _text(value, field=field)


def _unique_texts(
    values: Sequence[str], *, field: str, allowed: frozenset[str] | None = None,
) -> tuple[str, ...]:
    if isinstance(values, (str, bytes)) or not isinstance(values, Sequence):
        raise ValueError(f"codex_project_permission_{field}_invalid")
    normalized = tuple(
        dict.fromkeys(_text(value, field=field, maximum=100) for value in values)
    )
    if allowed is not None and any(value not in allowed for value in normalized):
        raise ValueError(f"codex_project_permission_{field}_unsupported")
    return normalized


@dataclass(frozen=True)
class ProjectPrincipalContext:
    """Authenticated-or-otherwise-identified caller context supplied by host."""

    principal_id: str
    principal_kind: str
    project_id: str
    team_id: str | None = None
    role_claims: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "principal_id", _text(self.principal_id, field="principal_id")
        )
        kind = _text(self.principal_kind, field="principal_kind", maximum=40)
        if kind not in PRINCIPAL_KINDS:
            raise ValueError("codex_project_permission_principal_kind_unsupported")
        object.__setattr__(self, "principal_kind", kind)
        object.__setattr__(
            self, "project_id", _text(self.project_id, field="project_id")
        )
        object.__setattr__(
            self, "team_id", _optional_text(self.team_id, field="team_id")
        )
        object.__setattr__(
            self,
            "role_claims",
            _unique_texts(self.role_claims, field="role_claim"),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "principal_id": self.principal_id,
            "principal_kind": self.principal_kind,
            "project_id": self.project_id,
            "team_id": self.team_id,
            "role_claims": list(self.role_claims),
        }


@dataclass(frozen=True)
class ProjectPermissionGrant:
    """Policy-owned capability grant for one exact principal and scope."""

    principal_id: str
    principal_kind: str
    project_id: str
    team_id: str | None = None
    roles: tuple[str, ...] = ()
    capabilities: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "principal_id", _text(self.principal_id, field="principal_id")
        )
        kind = _text(self.principal_kind, field="principal_kind", maximum=40)
        if kind not in PRINCIPAL_KINDS:
            raise ValueError("codex_project_permission_principal_kind_unsupported")
        object.__setattr__(self, "principal_kind", kind)
        object.__setattr__(
            self, "project_id", _text(self.project_id, field="project_id")
        )
        object.__setattr__(
            self, "team_id", _optional_text(self.team_id, field="team_id")
        )
        object.__setattr__(
            self, "roles", _unique_texts(self.roles, field="role")
        )
        object.__setattr__(
            self,
            "capabilities",
            _unique_texts(
                self.capabilities,
                field="capability",
                allowed=PROJECT_KNOWLEDGE_CAPABILITIES,
            ),
        )

    def matches(self, context: ProjectPrincipalContext) -> bool:
        return bool(
            self.principal_id == context.principal_id
            and self.principal_kind == context.principal_kind
            and self.project_id == context.project_id
            and self.team_id == context.team_id
            and set(context.role_claims).issubset(self.roles)
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "principal_id": self.principal_id,
            "principal_kind": self.principal_kind,
            "project_id": self.project_id,
            "team_id": self.team_id,
            "roles": list(self.roles),
            "capabilities": list(self.capabilities),
        }


@dataclass(frozen=True)
class ProjectPermissionPolicy:
    """Revision-bound local policy; no matching grant means no capability."""

    policy_revision: str
    project_id: str
    grants: tuple[ProjectPermissionGrant, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "policy_revision",
            _text(self.policy_revision, field="policy_revision"),
        )
        object.__setattr__(
            self, "project_id", _text(self.project_id, field="project_id")
        )
        grants = tuple(self.grants)
        if not all(isinstance(item, ProjectPermissionGrant) for item in grants):
            raise ValueError("codex_project_permission_grants_invalid")
        if any(item.project_id != self.project_id for item in grants):
            raise ValueError("codex_project_permission_grant_project_mismatch")
        identities = [
            (item.principal_kind, item.principal_id, item.team_id)
            for item in grants
        ]
        if len(identities) != len(set(identities)):
            raise ValueError("codex_project_permission_duplicate_grant")
        object.__setattr__(self, "grants", grants)

    def resolved_grant(
        self, context: ProjectPrincipalContext,
    ) -> ProjectPermissionGrant | None:
        if context.project_id != self.project_id:
            return None
        return next((item for item in self.grants if item.matches(context)), None)

    def allows(self, context: ProjectPrincipalContext, capability: str) -> bool:
        selected = _text(capability, field="capability", maximum=100)
        if selected not in PROJECT_KNOWLEDGE_CAPABILITIES:
            return False
        grant = self.resolved_grant(context)
        return bool(grant is not None and selected in grant.capabilities)

    def require(
        self, context: ProjectPrincipalContext, capability: str,
    ) -> ProjectPermissionGrant:
        grant = self.resolved_grant(context)
        if grant is None or capability not in grant.capabilities:
            raise PermissionError("codex_project_permission_denied")
        return grant

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": "1.0.0",
            "artifact_type": "project_permission_policy",
            "policy_revision": self.policy_revision,
            "project_id": self.project_id,
            "default_effect": "deny",
            "grants": [item.to_dict() for item in self.grants],
            "non_claims": [
                "policy_applies_only_to_named_project_knowledge_operations",
                "policy_grants_no_gate_release_production_or_live_authority",
            ],
        }

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "ProjectPermissionPolicy":
        if not isinstance(value, Mapping):
            raise ValueError("codex_project_permission_policy_invalid")
        try:
            grants = tuple(
                ProjectPermissionGrant(
                    principal_id=item["principal_id"],
                    principal_kind=item["principal_kind"],
                    project_id=item["project_id"],
                    team_id=item.get("team_id"),
                    roles=tuple(item.get("roles", ())),
                    capabilities=tuple(item.get("capabilities", ())),
                )
                for item in value["grants"]
            )
            return cls(
                policy_revision=value["policy_revision"],
                project_id=value["project_id"],
                grants=grants,
            )
        except (KeyError, TypeError) as exc:
            raise ValueError("codex_project_permission_policy_invalid") from exc
