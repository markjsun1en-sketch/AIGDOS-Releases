"""Read-only multi-lane checker over exact Godot QA/build receipts."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from .godot_lane_receipts import (
    verify_bundle_artifacts,
    verify_development_delivery,
)
from .multi_lane_coordinator import LaneBackendOutcome, LaneExecutionContext
from .multi_lane_workspace import (
    WorkspaceIdentityError,
    absolute_existing_path,
    json_file,
    observe_git_workspace,
    required_text,
    sha256_file,
)


class GodotFocusedQaReceiptLaneBackend:
    """Validate one QA bundle without granting project-source writes."""

    backend_id = "codex_godot_focused_qa_receipt_backend_v1"

    def __init__(
        self,
        *,
        lane_id: str,
        capabilities: Sequence[str],
        workspace_root: str | Path,
        expected_branch: str,
        expected_output_revision: str,
        result_artifact_type: str,
        qa_bundle_path: str | Path,
        qa_integrity_path: str | Path,
        development_delivery_receipt: str | Path,
        common_identities: Mapping[str, Any],
        expected_attempt_id: int,
    ) -> None:
        self.lane_id = required_text(lane_id, "lane_id")
        self.capabilities = tuple(
            required_text(value, "capability") for value in capabilities
        )
        self.workspace_root = absolute_existing_path(
            workspace_root,
            "workspace_root",
        )
        self.expected_branch = required_text(expected_branch, "expected_branch")
        self.expected_output_revision = required_text(
            expected_output_revision,
            "expected_output_revision",
        )
        self.result_artifact_type = required_text(
            result_artifact_type,
            "result_artifact_type",
        )
        self.qa_bundle_path = absolute_existing_path(
            qa_bundle_path,
            "qa_bundle_path",
        )
        self.qa_integrity_path = absolute_existing_path(
            qa_integrity_path,
            "qa_integrity_path",
        )
        self.development_delivery_receipt = absolute_existing_path(
            development_delivery_receipt,
            "development_delivery_receipt",
        )
        self.common_identities = json.loads(
            json.dumps(dict(common_identities), ensure_ascii=False, sort_keys=True)
        )
        if not isinstance(expected_attempt_id, int) or expected_attempt_id < 1:
            raise WorkspaceIdentityError("expected_attempt_id must be positive")
        self.expected_attempt_id = expected_attempt_id

    def _failed(
        self,
        context: LaneExecutionContext,
        *,
        failure_kind: str,
        facts: Mapping[str, Any],
    ) -> LaneBackendOutcome:
        return LaneBackendOutcome(
            state="failed",
            input_source_revision=context.plan.expected_source_revision,
            output_revision=None,
            result_artifact_type=None,
            facts=dict(facts),
            failure_kind=failure_kind,
            failure_owner=context.lane.primary_principal_id,
            next_action=(
                "rerun_independent_focused_qa_for_the_exact_integrated_revision"
            ),
        )

    def _verify_source_and_receipts(
        self,
        context: LaneExecutionContext,
    ) -> tuple[Any, dict, dict, dict[str, dict[str, Any]], dict[str, Any]]:
        workspace = observe_git_workspace(
            self.workspace_root,
            base_revision=context.plan.expected_source_revision,
        )
        if (
            not workspace.isolated_workspace
            or not workspace.clean
            or not workspace.base_is_ancestor
            or workspace.branch != self.expected_branch
            or workspace.head != self.expected_output_revision
        ):
            raise WorkspaceIdentityError("checker source workspace identity mismatch")
        bundle = json_file(self.qa_bundle_path, "QA evidence bundle")
        if (
            bundle.get("artifact_type") != "qa_evidence_bundle"
            or bundle.get("verdict") != "DONE"
        ):
            raise WorkspaceIdentityError("QA bundle does not have verdict DONE")
        verify_bundle_artifacts(self.qa_bundle_path, bundle)
        integrity = json_file(
            self.qa_integrity_path,
            "QA source-integrity receipt",
        )
        before = integrity.get("before")
        after = integrity.get("after")
        if not isinstance(before, dict) or not isinstance(after, dict):
            raise WorkspaceIdentityError(
                "QA integrity receipt has no before/after identity"
            )
        if (
            before.get("head") != workspace.head
            or after.get("head") != workspace.head
            or before.get("tree") != workspace.tree
            or after.get("tree") != workspace.tree
            or integrity.get("source_clean_before") is not True
            or integrity.get("source_clean_after") is not True
            or integrity.get("source_unchanged") is not True
        ):
            raise WorkspaceIdentityError("QA source-integrity identity mismatch")
        validator_results: dict[str, dict[str, Any]] = {
            "source_integrity_before_after": {"status": "pass"},
        }
        evidence_root = self.qa_bundle_path.parent.resolve(strict=True)
        for artifact in bundle["artifacts"]:
            relative = str(artifact.get("path", ""))
            if not relative.endswith("_godot_check.result.json"):
                continue
            result = json_file(
                evidence_root / relative,
                "Godot QA command result",
            )
            command = result.get("command")
            if not isinstance(command, list) or "--script" not in command:
                raise WorkspaceIdentityError(
                    "QA command result has no script binding"
                )
            script_index = command.index("--script") + 1
            if script_index >= len(command):
                raise WorkspaceIdentityError("QA command result has no script path")
            script_path = str(command[script_index]).removeprefix("res://")
            validator_id = Path(script_path).stem
            validator_results[validator_id] = {
                "status": result.get("status"),
                "run_id": result.get("run_id"),
                "pass_token_observed": result.get("pass_token_observed"),
                "ignored_diagnostic_count": result.get(
                    "ignored_diagnostic_count",
                    0,
                ),
            }
            if (
                result.get("status") != "pass"
                or result.get("pass_token_observed") is not True
            ):
                raise WorkspaceIdentityError(
                    f"QA validator did not pass: {validator_id}"
                )
        build_identity = verify_development_delivery(
            self.development_delivery_receipt,
            expected_source_revision=workspace.head,
        )
        validator_results["development_artifact_identity"] = {"status": "pass"}
        missing = sorted(
            set(context.lane.required_validators) - set(validator_results)
        )
        if missing:
            raise WorkspaceIdentityError(
                f"QA bundle is missing required validators: {missing}"
            )
        if any(
            validator_results[validator_id].get("status") != "pass"
            for validator_id in context.lane.required_validators
        ):
            raise WorkspaceIdentityError("one required QA validator did not pass")
        current = observe_git_workspace(
            self.workspace_root,
            base_revision=context.plan.expected_source_revision,
        )
        if (
            not current.clean
            or current.head != workspace.head
            or current.tree != workspace.tree
        ):
            raise WorkspaceIdentityError("checker observation changed project source")
        return workspace, bundle, integrity, validator_results, build_identity

    def run(self, context: LaneExecutionContext) -> LaneBackendOutcome:
        if context.lane.lane_id != self.lane_id:
            raise WorkspaceIdentityError(
                "checker backend received the wrong lane"
            )
        if context.attempt_id != self.expected_attempt_id:
            return self._failed(
                context,
                failure_kind="lane_attempt_identity_mismatch",
                facts={
                    "context_attempt_id": context.attempt_id,
                    "expected_attempt_id": self.expected_attempt_id,
                },
            )
        try:
            (
                workspace,
                bundle,
                _integrity,
                validator_results,
                build_identity,
            ) = self._verify_source_and_receipts(context)
        except WorkspaceIdentityError as exc:
            return self._failed(
                context,
                failure_kind="focused_qa_receipt_verification_failed",
                facts={"message": str(exc)},
            )
        return LaneBackendOutcome(
            state="accepted",
            input_source_revision=context.plan.expected_source_revision,
            output_revision=workspace.head,
            result_artifact_type=self.result_artifact_type,
            facts={
                "validator_results": validator_results,
                "checker_project_source_writes": 0,
                "source_unchanged_by_checker": True,
            },
            observed_write_paths=(),
            artifact_identities={
                **self.common_identities,
                "validated_workspace_source": workspace.to_dict(),
                "development_build": build_identity,
                "focused_qa": {
                    "bundle_path": str(self.qa_bundle_path),
                    "bundle_sha256": sha256_file(self.qa_bundle_path),
                    "integrity_path": str(self.qa_integrity_path),
                    "integrity_sha256": sha256_file(self.qa_integrity_path),
                    "verdict": bundle.get("verdict"),
                },
            },
            evidence_refs=(
                str(self.qa_bundle_path),
                str(self.qa_integrity_path),
                str(self.development_delivery_receipt),
            ),
        )
