"""Engine-neutral composition contract for one bounded Production Cell run.

The composition core knows four lifecycle stages: implementation checkpoint,
target feedback, development build, and focused QA.  It calls explicitly
selected backends in that order, stops after the first non-successful factual
outcome, and can emit one schema-validated receipt.

Backend-owned facts are opaque to this module.  Engine commands, export
configuration, packaged-resource formats, project file types, and test runner
details belong to a concrete profile, never to this contract.

This module does not select a task, invoke an LLM, commit source, approve a
feature, run qualification, evaluate a Gate, promote evidence, or grant
release, production, or live authority.
"""

from __future__ import annotations

import json
import os
import re
import time
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Protocol, Sequence, runtime_checkable


REQUIRED_STAGE_ORDER = (
    "implementation",
    "target_feedback",
    "development_build",
    "focused_qa",
)
SUCCESSFUL_STAGE_STATUS = "succeeded"
STAGE_STATUSES = {
    SUCCESSFUL_STAGE_STATUS,
    "review_needed",
    "failed",
    "blocked",
    "not_run",
}
RUN_STATUSES = {"completed", "review_needed", "failed", "blocked"}
_SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")


class ProductionCellCompositionError(RuntimeError):
    """Base error for invalid composition input or backend behavior."""


class CompositionContractError(ProductionCellCompositionError):
    """Raised when a spec, backend, outcome, or receipt violates the contract."""


class CompositionReceiptError(ProductionCellCompositionError):
    """Raised when a receipt path or schema is invalid."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _required_text(value: str, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise CompositionContractError(f"{label} must be a non-empty string")
    if "\x00" in value:
        raise CompositionContractError(f"{label} contains a NUL byte")
    return value.strip()


def _text_tuple(values: Sequence[str], label: str) -> tuple[str, ...]:
    if isinstance(values, (str, bytes)):
        raise CompositionContractError(f"{label} must be a sequence of strings")
    normalized = tuple(
        _required_text(value, f"{label} item")
        for value in values
    )
    if not normalized:
        raise CompositionContractError(f"{label} must not be empty")
    if len(set(normalized)) != len(normalized):
        raise CompositionContractError(f"{label} must not contain duplicates")
    return normalized


def _json_object(value: Mapping[str, Any], label: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise CompositionContractError(f"{label} must be a mapping")
    try:
        encoded = json.dumps(value, ensure_ascii=False, sort_keys=True)
        decoded = json.loads(encoded)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise CompositionContractError(
            f"{label} must contain only JSON-serializable values"
        ) from exc
    if not isinstance(decoded, dict):
        raise CompositionContractError(f"{label} must serialize to an object")
    return decoded


@dataclass(frozen=True)
class SelectedFeatureSpec:
    """Human/host-selected development input, not an approval or Gate result."""

    feature_id: str
    task_id: str
    title: str
    acceptance_criteria: tuple[str, ...]
    input_refs: tuple[str, ...]
    declared_write_surfaces: tuple[str, ...]
    target_profile_id: str
    expected_source_revision: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "feature_id", _required_text(self.feature_id, "feature_id"))
        object.__setattr__(self, "task_id", _required_text(self.task_id, "task_id"))
        object.__setattr__(self, "title", _required_text(self.title, "title"))
        object.__setattr__(
            self,
            "acceptance_criteria",
            _text_tuple(self.acceptance_criteria, "acceptance_criteria"),
        )
        object.__setattr__(self, "input_refs", _text_tuple(self.input_refs, "input_refs"))
        object.__setattr__(
            self,
            "declared_write_surfaces",
            _text_tuple(self.declared_write_surfaces, "declared_write_surfaces"),
        )
        object.__setattr__(
            self,
            "target_profile_id",
            _required_text(self.target_profile_id, "target_profile_id"),
        )
        if self.expected_source_revision is not None:
            object.__setattr__(
                self,
                "expected_source_revision",
                _required_text(
                    self.expected_source_revision,
                    "expected_source_revision",
                ),
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": "1.0.0",
            "artifact_type": "selected_feature_spec",
            "feature_id": self.feature_id,
            "task_id": self.task_id,
            "title": self.title,
            "acceptance_criteria": list(self.acceptance_criteria),
            "input_refs": list(self.input_refs),
            "declared_write_surfaces": list(self.declared_write_surfaces),
            "target_profile_id": self.target_profile_id,
            "expected_source_revision": self.expected_source_revision,
            "non_claims": [
                "selected_feature_spec_is_not_design_or_human_acceptance",
                "selected_feature_spec_is_not_gate_or_protected_authority",
            ],
        }


@dataclass(frozen=True)
class ProductionCellBackendOutcome:
    """Factual, backend-owned result returned to the neutral coordinator."""

    status: str
    artifact_type: str
    facts: Mapping[str, Any]
    evidence_refs: tuple[str, ...] = ()
    failure_kind: str | None = None
    failure_owner: str | None = None
    next_action: str | None = None

    def __post_init__(self) -> None:
        if self.status not in STAGE_STATUSES - {"not_run"}:
            raise CompositionContractError(
                f"backend outcome has unsupported status: {self.status!r}"
            )
        object.__setattr__(
            self,
            "artifact_type",
            _required_text(self.artifact_type, "backend outcome artifact_type"),
        )
        object.__setattr__(self, "facts", _json_object(self.facts, "backend outcome facts"))
        refs = tuple(
            _required_text(value, "evidence_refs item")
            for value in self.evidence_refs
        )
        if len(set(refs)) != len(refs):
            raise CompositionContractError("evidence_refs must not contain duplicates")
        object.__setattr__(self, "evidence_refs", refs)
        for field in ("failure_kind", "failure_owner", "next_action"):
            value = getattr(self, field)
            if value is not None:
                object.__setattr__(self, field, _required_text(value, field))
        if self.status != SUCCESSFUL_STAGE_STATUS and not self.failure_owner:
            raise CompositionContractError(
                "a non-successful backend outcome requires failure_owner"
            )


@dataclass(frozen=True)
class ProductionCellStageResult:
    schema_version: str
    artifact_type: str
    stage_id: str
    backend_id: str
    status: str
    result_artifact_type: str | None
    facts: dict[str, Any]
    evidence_refs: tuple[str, ...]
    failure_kind: str | None
    failure_owner: str | None
    next_action: str | None
    started_at: str | None
    duration_ms: int | None
    non_claims: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["evidence_refs"] = list(self.evidence_refs)
        value["non_claims"] = list(self.non_claims)
        return value


@dataclass(frozen=True)
class ProductionCellContext:
    feature_spec: SelectedFeatureSpec
    prior_stage_results: tuple[ProductionCellStageResult, ...]


@runtime_checkable
class ProductionCellStageBackend(Protocol):
    """Smallest backend surface understood by the neutral coordinator."""

    stage_id: str
    backend_id: str

    def run(self, context: ProductionCellContext) -> ProductionCellBackendOutcome:
        """Execute one factual stage and return a non-authoritative outcome."""


@dataclass(frozen=True)
class ProductionCellCompositionResult:
    schema_version: str
    artifact_type: str
    run_id: str
    profile_id: str
    profile_binding_id: str
    profile_binding_sha256: str
    status: str
    feature_spec: dict[str, Any]
    stages: tuple[ProductionCellStageResult, ...]
    failure_stage: str | None
    completed_at: str
    non_claims: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "artifact_type": self.artifact_type,
            "run_id": self.run_id,
            "profile_id": self.profile_id,
            "profile_binding_id": self.profile_binding_id,
            "profile_binding_sha256": self.profile_binding_sha256,
            "status": self.status,
            "feature_spec": self.feature_spec,
            "stages": [stage.to_dict() for stage in self.stages],
            "failure_stage": self.failure_stage,
            "completed_at": self.completed_at,
            "non_claims": list(self.non_claims),
        }


class ProductionCellComposition:
    """Run the fixed neutral stage contract through explicit profile backends."""

    def __init__(
        self,
        *,
        profile_id: str,
        profile_binding_id: str,
        profile_binding_sha256: str,
        backends: Sequence[ProductionCellStageBackend],
    ) -> None:
        self.profile_id = _required_text(profile_id, "profile_id")
        self.profile_binding_id = _required_text(
            profile_binding_id,
            "profile_binding_id",
        )
        digest = _required_text(
            profile_binding_sha256,
            "profile_binding_sha256",
        ).lower()
        if not _SHA256_PATTERN.fullmatch(digest):
            raise CompositionContractError(
                "profile_binding_sha256 must be 64 lowercase hex characters"
            )
        self.profile_binding_sha256 = digest
        if len(backends) != len(REQUIRED_STAGE_ORDER):
            raise CompositionContractError(
                "composition requires exactly four ordered stage backends"
            )
        normalized: list[ProductionCellStageBackend] = []
        for expected_stage, backend in zip(
            REQUIRED_STAGE_ORDER,
            backends,
            strict=True,
        ):
            if not isinstance(backend, ProductionCellStageBackend):
                raise CompositionContractError(
                    f"backend does not implement the stage protocol: {expected_stage}"
                )
            if backend.stage_id != expected_stage:
                raise CompositionContractError(
                    f"expected backend for {expected_stage}, got {backend.stage_id!r}"
                )
            _required_text(backend.backend_id, f"{expected_stage}.backend_id")
            normalized.append(backend)
        self.backends = tuple(normalized)

    @staticmethod
    def _stage_result(
        *,
        backend: ProductionCellStageBackend,
        outcome: ProductionCellBackendOutcome,
        started_at: str,
        duration_ms: int,
    ) -> ProductionCellStageResult:
        if not isinstance(outcome, ProductionCellBackendOutcome):
            raise CompositionContractError(
                f"backend {backend.backend_id} returned an invalid outcome"
            )
        return ProductionCellStageResult(
            schema_version="1.0.0",
            artifact_type="production_cell_stage_result",
            stage_id=backend.stage_id,
            backend_id=backend.backend_id,
            status=outcome.status,
            result_artifact_type=outcome.artifact_type,
            facts=dict(outcome.facts),
            evidence_refs=outcome.evidence_refs,
            failure_kind=outcome.failure_kind,
            failure_owner=outcome.failure_owner,
            next_action=outcome.next_action,
            started_at=started_at,
            duration_ms=duration_ms,
            non_claims=(
                "stage_result_is_factual_not_authority",
                "stage_result_is_not_qualification_gate_or_release_evidence",
            ),
        )

    @staticmethod
    def _not_run_result(
        backend: ProductionCellStageBackend,
        blocking_stage: str,
    ) -> ProductionCellStageResult:
        return ProductionCellStageResult(
            schema_version="1.0.0",
            artifact_type="production_cell_stage_result",
            stage_id=backend.stage_id,
            backend_id=backend.backend_id,
            status="not_run",
            result_artifact_type=None,
            facts={"blocked_by_prior_stage": blocking_stage},
            evidence_refs=(),
            failure_kind="prior_stage_not_successful",
            failure_owner=None,
            next_action=None,
            started_at=None,
            duration_ms=None,
            non_claims=(
                "not_run_is_not_a_pass_or_waiver",
                "stage_result_is_not_qualification_gate_or_release_evidence",
            ),
        )

    def run(self, feature_spec: SelectedFeatureSpec) -> ProductionCellCompositionResult:
        if not isinstance(feature_spec, SelectedFeatureSpec):
            raise CompositionContractError(
                "feature_spec must be a SelectedFeatureSpec"
            )
        if feature_spec.target_profile_id != self.profile_id:
            raise CompositionContractError(
                "selected feature target_profile_id does not match composition profile"
            )

        stage_results: list[ProductionCellStageResult] = []
        failure_stage: str | None = None
        run_status = "completed"
        for index, backend in enumerate(self.backends):
            started_at = _utc_now()
            started_clock = time.monotonic()
            outcome = backend.run(
                ProductionCellContext(
                    feature_spec=feature_spec,
                    prior_stage_results=tuple(stage_results),
                )
            )
            duration_ms = max(0, round((time.monotonic() - started_clock) * 1000))
            stage_result = self._stage_result(
                backend=backend,
                outcome=outcome,
                started_at=started_at,
                duration_ms=duration_ms,
            )
            stage_results.append(stage_result)
            if stage_result.status != SUCCESSFUL_STAGE_STATUS:
                failure_stage = stage_result.stage_id
                run_status = stage_result.status
                for skipped in self.backends[index + 1 :]:
                    stage_results.append(
                        self._not_run_result(skipped, stage_result.stage_id)
                    )
                break

        if run_status not in RUN_STATUSES:
            raise CompositionContractError(
                f"composition produced unsupported run status: {run_status}"
            )
        return ProductionCellCompositionResult(
            schema_version="1.0.0",
            artifact_type="production_cell_composition_result",
            run_id=f"production-cell-{uuid.uuid4().hex}",
            profile_id=self.profile_id,
            profile_binding_id=self.profile_binding_id,
            profile_binding_sha256=self.profile_binding_sha256,
            status=run_status,
            feature_spec=feature_spec.to_dict(),
            stages=tuple(stage_results),
            failure_stage=failure_stage,
            completed_at=_utc_now(),
            non_claims=(
                "composition_result_is_not_human_experience_acceptance",
                "composition_result_is_not_qualification_or_gate_evidence",
                "composition_result_is_not_release_or_pack_promotion_authority",
                "composition_result_grants_no_production_or_live_authority",
            ),
        )


def write_composition_receipt(
    *,
    receipt_path: str | Path,
    result: ProductionCellCompositionResult,
    schema_path: str | Path,
) -> Path:
    """Validate and create one receipt without overwriting an existing file."""

    if not isinstance(result, ProductionCellCompositionResult):
        raise CompositionReceiptError(
            "result must be a ProductionCellCompositionResult"
        )
    candidate = Path(receipt_path)
    if not candidate.is_absolute() or "\x00" in str(candidate):
        raise CompositionReceiptError("receipt_path must be an absolute safe path")
    parent = candidate.parent.resolve(strict=True)
    if not parent.is_dir() or parent.is_symlink():
        raise CompositionReceiptError("receipt parent must be a regular directory")
    final_path = parent / candidate.name
    if final_path.exists() or final_path.is_symlink():
        raise CompositionReceiptError(
            f"composition receipt already exists: {final_path}"
        )

    schema_file = Path(schema_path).resolve(strict=True)
    try:
        schema = json.loads(schema_file.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise CompositionReceiptError(
            f"invalid composition receipt schema: {schema_file}: {exc}"
        ) from exc
    try:
        import jsonschema
    except ImportError as exc:
        raise CompositionReceiptError(
            "jsonschema is required to validate composition receipts"
        ) from exc
    value = result.to_dict()
    try:
        jsonschema.Draft7Validator(schema).validate(value)
    except jsonschema.ValidationError as exc:
        raise CompositionReceiptError(
            f"composition receipt is schema-invalid: {exc.message}"
        ) from exc

    temporary = parent / f".{final_path.name}.tmp-{uuid.uuid4().hex}"
    payload = (
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    try:
        descriptor = os.open(
            temporary,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL,
            0o600,
        )
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, final_path)
    except FileExistsError as exc:
        raise CompositionReceiptError(
            f"composition receipt already exists: {final_path}"
        ) from exc
    finally:
        if temporary.exists():
            temporary.unlink()
    return final_path
