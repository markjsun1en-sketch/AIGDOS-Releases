"""Single-attempt Production Worker for a bounded Godot feature slice.

The worker converts an admitted task envelope plus existing Agent/Skill
contracts into a small executable surface.  It can read only declared task
inputs, write only through the task/Agent/Skill intersection, and call only
typed Godot operations exposed by :mod:`godot_execution_adapter`.

The host remains responsible for task admission, Human decisions, and any
independent review.  This module invokes no LLM, grants no authority, performs
no qualification, and creates no Gate or release evidence.
"""

from __future__ import annotations

import hashlib
import json
import os
import stat
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Sequence

from .godot_execution_adapter import (
    CapabilityBindingError,
    GodotCommandResult,
    GodotExecutionAdapter,
    ProjectBoundaryError,
)


DEFAULT_MAX_INPUT_BYTES = 256 * 1024
DEFAULT_MAX_WRITE_BYTES = 1024 * 1024

_REQUIRED_OPERATION_BINDINGS = {
    "worker_preflight": "preflight",
    "inspect_declared_inputs": "inspect_inputs",
    "read_declared_text_input": "read_input_text",
    "write_project_text": "write_text",
    "godot_project_load": "run_project_load",
    "godot_script_smoke": "run_script",
    "godot_scene_smoke": "run_scene",
    "godot_development_build": "build_macos_development",
}


class ProductionWorkerError(RuntimeError):
    """Base error for invalid worker context or bounded worker operations."""


class UndeclaredInputError(ProductionWorkerError):
    """Raised when the worker is asked to read outside its exact input set."""


class ConcurrentWriteError(ProductionWorkerError):
    """Raised when a target no longer has the caller's expected identity."""


@dataclass(frozen=True)
class ProductionInputObservation:
    schema_version: str
    artifact_type: str
    task_id: str
    attempt_id: int
    relative_path: str
    status: str
    byte_count: int | None
    content_sha256: str | None
    observed_at: str
    non_claims: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["non_claims"] = list(self.non_claims)
        return value


@dataclass(frozen=True)
class ProductionWriteResult:
    schema_version: str
    artifact_type: str
    write_id: str
    task_id: str
    attempt_id: int
    actor_id: str
    agent_id: str
    skill_id: str
    relative_path: str
    operation: str
    before_sha256: str | None
    after_sha256: str
    byte_count: int
    written_at: str
    status: str
    non_claims: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["non_claims"] = list(self.non_claims)
        return value


def _sha256_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _is_sha256(value: str) -> bool:
    return len(value) == 64 and all(character in "0123456789abcdef" for character in value)


def _load_json_object(path: Path, *, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise CapabilityBindingError(f"missing {label}: {path}") from exc
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise CapabilityBindingError(f"invalid {label}: {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise CapabilityBindingError(f"{label} must be a JSON object: {path}")
    return value


class CodexProductionWorker:
    """One bounded worker context for one task attempt.

    A worker instance is deliberately not a scheduler or an Agent runtime.  An
    external host supplies the reasoning loop and calls these deterministic
    operations for the selected Agent/Skill/task tuple.
    """

    def __init__(
        self,
        *,
        project_root: str | Path,
        task_id: str,
        attempt_id: int,
        actor_id: str,
        agent_contract_path: str | Path,
        skill_contract_path: str | Path,
        skill_tool_binding_path: str | Path,
        declared_input_paths: Sequence[str | Path],
        declared_write_patterns: Sequence[str],
        godot_binary: str | Path | None = None,
        godot_launch_mode: str = "direct",
        godot_app_bundle: str | Path | None = None,
        macos_open_binary: str | Path = "/usr/bin/open",
        development_artifact_root: str | Path | None = None,
        codesign_binary: str | Path = "/usr/bin/codesign",
        require_clean_build_source: bool = True,
        timeout_seconds: float = 30.0,
        max_input_bytes: int = DEFAULT_MAX_INPUT_BYTES,
        max_write_bytes: int = DEFAULT_MAX_WRITE_BYTES,
    ) -> None:
        self.execution = GodotExecutionAdapter(
            project_root=project_root,
            task_id=task_id,
            attempt_id=attempt_id,
            actor_id=actor_id,
            agent_contract_path=agent_contract_path,
            skill_contract_path=skill_contract_path,
            declared_write_patterns=declared_write_patterns,
            godot_binary=godot_binary,
            launch_mode=godot_launch_mode,
            macos_open_binary=macos_open_binary,
            godot_app_bundle=godot_app_bundle,
            timeout_seconds=timeout_seconds,
        )
        self.project_root = self.execution.project_root
        self.task_id = self.execution.task_id
        self.attempt_id = self.execution.attempt_id
        self.actor_id = self.execution.actor_id
        self.agent_id = self.execution.agent_id
        self.skill_id = self.execution.skill_id
        self.macos_open_binary = Path(macos_open_binary)
        self.codesign_binary = Path(codesign_binary)
        self.require_clean_build_source = bool(require_clean_build_source)
        if development_artifact_root is None:
            self.development_artifact_root: Path | None = None
        else:
            artifact_root = Path(development_artifact_root)
            if not artifact_root.is_absolute():
                raise ProjectBoundaryError(
                    "development_artifact_root must be an absolute path"
                )
            self.development_artifact_root = artifact_root.resolve(strict=True)
            if not self.development_artifact_root.is_dir():
                raise ProjectBoundaryError(
                    "development_artifact_root must be an existing directory"
                )
            try:
                self.development_artifact_root.relative_to(self.project_root)
            except ValueError:
                pass
            else:
                raise ProjectBoundaryError(
                    "development_artifact_root must stay outside the project"
                )

        if not declared_input_paths:
            raise UndeclaredInputError("declared_input_paths must not be empty")
        normalized_inputs = tuple(
            self.execution._normalize_project_relative(path)
            for path in declared_input_paths
        )
        if len(set(normalized_inputs)) != len(normalized_inputs):
            raise UndeclaredInputError("declared_input_paths contains duplicates")
        self.declared_input_paths = normalized_inputs

        if not isinstance(max_input_bytes, int) or max_input_bytes < 1024:
            raise ValueError("max_input_bytes must be an integer >= 1024")
        if not isinstance(max_write_bytes, int) or max_write_bytes < 1024:
            raise ValueError("max_write_bytes must be an integer >= 1024")
        self.max_input_bytes = max_input_bytes
        self.max_write_bytes = max_write_bytes

        self.skill_tool_binding_path = Path(skill_tool_binding_path).resolve(
            strict=True
        )
        self.skill_tool_binding = _load_json_object(
            self.skill_tool_binding_path,
            label="Production Skill tool binding",
        )
        self.binding_id = self._validate_tool_binding()

    def _validate_tool_binding(self) -> str:
        binding = self.skill_tool_binding
        if binding.get("artifact_type") != "production_skill_tool_binding":
            raise CapabilityBindingError(
                "Skill tool binding has the wrong artifact_type"
            )
        if binding.get("binding_status") != "draft":
            raise CapabilityBindingError(
                "Skill tool binding has an unsupported binding_status"
            )
        binding_id = binding.get("binding_id")
        if not isinstance(binding_id, str) or not binding_id.strip():
            raise CapabilityBindingError("Skill tool binding has no binding_id")
        if binding.get("agent_id") != self.agent_id:
            raise CapabilityBindingError(
                "Skill tool binding does not match selected Agent"
            )
        if binding.get("skill_id") != self.skill_id:
            raise CapabilityBindingError(
                "Skill tool binding does not match selected Skill"
            )
        if binding.get("runtime_api") != "adapters/codex/production_worker.py":
            raise CapabilityBindingError(
                "Skill tool binding names an unsupported runtime API"
            )
        operations = binding.get("operation_bindings")
        if not isinstance(operations, list):
            raise CapabilityBindingError(
                "Skill tool binding operation_bindings must be a list"
            )
        observed: dict[str, str] = {}
        for operation in operations:
            if not isinstance(operation, dict):
                raise CapabilityBindingError(
                    "Skill tool binding operation must be an object"
                )
            operation_id = operation.get("operation_id")
            worker_method = operation.get("worker_method")
            if not isinstance(operation_id, str) or not isinstance(worker_method, str):
                raise CapabilityBindingError(
                    "Skill tool binding operation needs string IDs and methods"
                )
            if operation_id in observed:
                raise CapabilityBindingError(
                    f"duplicate Skill tool binding operation: {operation_id}"
                )
            observed[operation_id] = worker_method
        for operation_id, expected_method in _REQUIRED_OPERATION_BINDINGS.items():
            if observed.get(operation_id) != expected_method:
                raise CapabilityBindingError(
                    f"missing or invalid Skill tool binding: {operation_id}"
                )
        return binding_id.strip()

    def _lexical_path(self, relative_path: str) -> Path:
        return self.project_root.joinpath(*PurePosixPath(relative_path).parts)

    def _reject_symlink_components(self, relative_path: str) -> None:
        current = self.project_root
        for part in PurePosixPath(relative_path).parts:
            current = current / part
            if current.is_symlink():
                raise ProjectBoundaryError(
                    f"symlinked project path is outside worker support: {relative_path}"
                )

    def _observe_input(self, relative_path: str) -> ProductionInputObservation:
        self._reject_symlink_components(relative_path)
        lexical = self._lexical_path(relative_path)
        observed_at = datetime.now(timezone.utc).isoformat()
        if not lexical.exists():
            status = "missing"
            byte_count = None
            digest = None
        elif not lexical.is_file():
            status = "not_regular_file"
            byte_count = None
            digest = None
        else:
            byte_count = lexical.stat().st_size
            if byte_count > self.max_input_bytes:
                status = "too_large"
                digest = None
            else:
                content = lexical.read_bytes()
                status = "present"
                byte_count = len(content)
                digest = _sha256_bytes(content)
        return ProductionInputObservation(
            schema_version="1.0.0",
            artifact_type="production_input_observation",
            task_id=self.task_id,
            attempt_id=self.attempt_id,
            relative_path=relative_path,
            status=status,
            byte_count=byte_count,
            content_sha256=digest,
            observed_at=observed_at,
            non_claims=(
                "input_observation_is_not_truth_approval",
                "input_observation_is_not_qualification_or_gate_evidence",
            ),
        )

    def inspect_inputs(self) -> list[ProductionInputObservation]:
        """Return identities for the exact declared input set; never scan."""

        return [self._observe_input(path) for path in self.declared_input_paths]

    def read_input_text(self, raw_path: str | Path) -> str:
        """Read one declared, bounded UTF-8 task input."""

        relative = self.execution._normalize_project_relative(raw_path)
        if relative not in self.declared_input_paths:
            raise UndeclaredInputError(
                f"input is outside the task-declared read set: {relative}"
            )
        observation = self._observe_input(relative)
        if observation.status != "present":
            raise UndeclaredInputError(
                f"declared input is unavailable ({observation.status}): {relative}"
            )
        if observation.byte_count is None or observation.byte_count > self.max_input_bytes:
            raise UndeclaredInputError(
                f"declared input exceeds the read budget: {relative}"
            )
        try:
            return self._lexical_path(relative).read_text(encoding="utf-8")
        except UnicodeError as exc:
            raise UndeclaredInputError(
                f"declared input is not UTF-8 text: {relative}"
            ) from exc

    def preflight(self) -> dict[str, Any]:
        """Check binding, exact inputs, engine availability, and write semantics."""

        engine = self.execution.preflight()
        inputs = self.inspect_inputs()
        ready = engine["status"] == "ready" and all(
            item.status == "present" and item.byte_count is not None
            and item.byte_count <= self.max_input_bytes
            for item in inputs
        )
        return {
            "schema_version": "1.0.0",
            "artifact_type": "production_worker_preflight",
            "task_id": self.task_id,
            "attempt_id": self.attempt_id,
            "actor_id": self.actor_id,
            "agent_id": self.agent_id,
            "skill_id": self.skill_id,
            "binding_id": self.binding_id,
            "status": "ready" if ready else "blocked",
            "input_observations": [item.to_dict() for item in inputs],
            "godot_preflight": engine,
            "development_build": {
                "status": (
                    "configured"
                    if self.development_artifact_root is not None
                    else "not_configured"
                ),
                "artifact_root": (
                    str(self.development_artifact_root)
                    if self.development_artifact_root is not None
                    else None
                ),
                "source_requirement": (
                    "clean_git_revision"
                    if self.require_clean_build_source
                    else "caller_selected_dirty_source"
                ),
            },
            "write_envelope_semantics": "task_agent_and_skill_intersection_only",
            "non_claims": [
                "worker_preflight_is_not_task_admission",
                "worker_preflight_is_not_human_acceptance",
                "worker_preflight_is_not_independent_qa",
                "worker_preflight_is_not_qualification_gate_or_release_evidence",
            ],
        }

    def write_text(
        self,
        raw_path: str | Path,
        content: str,
        *,
        expected_before_sha256: str | None,
    ) -> ProductionWriteResult:
        """Atomically create or replace one authorized UTF-8 project file.

        ``None`` means the caller expects a new path.  Replacing an existing
        file requires its exact current SHA-256, preventing an unobserved
        concurrent change from being overwritten.
        """

        if not isinstance(content, str):
            raise TypeError("content must be a string")
        encoded = content.encode("utf-8")
        if len(encoded) > self.max_write_bytes:
            raise ProductionWorkerError("write content exceeds the worker budget")
        if expected_before_sha256 is not None:
            if not isinstance(expected_before_sha256, str):
                raise ConcurrentWriteError("expected_before_sha256 must be a string")
            expected_before_sha256 = expected_before_sha256.lower()
            if not _is_sha256(expected_before_sha256):
                raise ConcurrentWriteError(
                    "expected_before_sha256 must be 64 lowercase hex characters"
                )

        relative = self.execution.authorize_write(raw_path)
        self._reject_symlink_components(relative)
        target = self._lexical_path(relative)
        if target.exists() and not target.is_file():
            raise ProjectBoundaryError(
                f"production write target is not a regular file: {relative}"
            )
        before: bytes | None = target.read_bytes() if target.exists() else None
        before_sha256 = _sha256_bytes(before) if before is not None else None
        if expected_before_sha256 is None:
            if before is not None:
                raise ConcurrentWriteError(
                    f"expected a new production path but it already exists: {relative}"
                )
        elif before_sha256 != expected_before_sha256:
            raise ConcurrentWriteError(
                f"production write identity changed before update: {relative}"
            )

        target.parent.mkdir(parents=True, exist_ok=True)
        self._reject_symlink_components(relative)
        temporary = target.parent / f".{target.name}.v495-{uuid.uuid4().hex}.tmp"
        mode = stat.S_IMODE(target.stat().st_mode) if target.exists() else 0o644
        try:
            descriptor = os.open(
                temporary,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL,
                0o600,
            )
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.chmod(temporary, mode)
            self._reject_symlink_components(relative)
            current = target.read_bytes() if target.exists() else None
            current_sha256 = _sha256_bytes(current) if current is not None else None
            if current_sha256 != before_sha256:
                raise ConcurrentWriteError(
                    f"production write identity changed during update: {relative}"
                )
            os.replace(temporary, target)
        finally:
            if temporary.exists():
                temporary.unlink()

        after_sha256 = _sha256_bytes(encoded)
        return ProductionWriteResult(
            schema_version="1.0.0",
            artifact_type="production_write_result",
            write_id=f"production-write-{uuid.uuid4().hex}",
            task_id=self.task_id,
            attempt_id=self.attempt_id,
            actor_id=self.actor_id,
            agent_id=self.agent_id,
            skill_id=self.skill_id,
            relative_path=relative,
            operation="created" if before is None else "updated",
            before_sha256=before_sha256,
            after_sha256=after_sha256,
            byte_count=len(encoded),
            written_at=datetime.now(timezone.utc).isoformat(),
            status="written",
            non_claims=(
                "write_result_is_not_independent_review",
                "write_result_is_not_human_acceptance",
                "write_result_is_not_qualification_gate_or_release_evidence",
            ),
        )

    def run_project_load(self) -> GodotCommandResult:
        return self.execution.run_project_load()

    def run_script(
        self,
        script_path: str | Path,
        *,
        expected_pass_token: str | None = None,
    ) -> GodotCommandResult:
        return self.execution.run_script(
            script_path,
            expected_pass_token=expected_pass_token,
        )

    def run_scene(
        self,
        scene_path: str | Path,
        *,
        expected_pass_token: str | None = None,
    ) -> GodotCommandResult:
        return self.execution.run_scene(
            scene_path,
            expected_pass_token=expected_pass_token,
        )

    def build_macos_development(
        self,
        *,
        preset_name: str,
        artifact_name: str,
        quit_after: int = 10,
    ):
        """Deliver one reproducible local macOS development app and receipt."""

        if self.development_artifact_root is None:
            raise ProductionWorkerError(
                "development_artifact_root was not configured for this worker"
            )
        from .godot_development_build import GodotDevelopmentBuild

        builder = GodotDevelopmentBuild(
            execution=self.execution,
            artifact_root=self.development_artifact_root,
            macos_open_binary=self.macos_open_binary,
            codesign_binary=self.codesign_binary,
            require_clean_source=self.require_clean_build_source,
        )
        return builder.deliver_macos_app(
            preset_name=preset_name,
            artifact_name=artifact_name,
            quit_after=quit_after,
        )
