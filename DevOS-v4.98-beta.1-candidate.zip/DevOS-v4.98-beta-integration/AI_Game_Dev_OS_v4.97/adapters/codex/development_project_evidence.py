"""Project-local factual Evidence continuity for bounded development work.

The store keeps immutable small evidence objects and immutable metadata records
below one project. Exact lookup does not depend on the disposable keyword
index. No operation grants acceptance, Gate, qualification, release,
production, or live authority.
"""

from __future__ import annotations

import fcntl
import json
import mimetypes
from pathlib import Path
from typing import Any, Mapping, Sequence

from ._development_evidence_bundle import (
    build_evolution_bundle as assemble_evolution_bundle,
)
from ._development_evidence_common import (
    DEVELOPMENT_PROJECT_EVIDENCE_RELATIVE_PATH,
    MAX_OBJECT_BYTES,
    RECORD_NON_CLAIMS,
    SAFE_EVIDENCE_ID,
    SAFE_KIND,
    SHA256,
    VERIFICATION_STATUSES,
    atomic_write,
    canonical_bytes,
    is_within,
    normalized_text,
    pretty_bytes,
    record_shape_issues,
    sha256_bytes,
)
from ._development_evidence_index import (
    rebuild_index as rebuild_evidence_index,
    search as search_evidence_index,
)


class DevelopmentProjectEvidenceStore:
    """Keep immutable factual development Evidence for one local project."""

    def __init__(
        self,
        project_root: str | Path,
        *,
        project_id: str,
        allowed_source_roots: Sequence[str | Path] = (),
    ) -> None:
        self._project_root = Path(project_root).resolve()
        if not self._project_root.is_dir():
            raise ValueError("codex_project_evidence_project_root_invalid")
        self._project_id = normalized_text(
            project_id, field="project_id", maximum=200,
        )
        self._root = (
            self._project_root / DEVELOPMENT_PROJECT_EVIDENCE_RELATIVE_PATH
        )
        roots: list[Path] = [self._project_root]
        if isinstance(allowed_source_roots, (str, bytes)):
            raise ValueError("codex_project_evidence_source_roots_invalid")
        for value in allowed_source_roots:
            raw = Path(value)
            if raw.is_symlink():
                raise ValueError(
                    "codex_project_evidence_source_root_symlink_rejected"
                )
            try:
                resolved = raw.resolve(strict=True)
            except OSError as error:
                raise ValueError(
                    "codex_project_evidence_source_root_unavailable"
                ) from error
            if not resolved.is_dir():
                raise ValueError(
                    "codex_project_evidence_source_root_not_directory"
                )
            if resolved not in roots:
                roots.append(resolved)
        self._allowed_source_roots = tuple(roots)

    def _validate_root(self, *, create: bool) -> bool:
        cursor = self._project_root
        for part in DEVELOPMENT_PROJECT_EVIDENCE_RELATIVE_PATH.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                raise ValueError(
                    "codex_project_evidence_storage_symlink_rejected"
                )
        if not self._root.exists():
            if not create:
                return False
            self._root.mkdir(parents=True, exist_ok=True)
        if not self._root.is_dir():
            raise ValueError("codex_project_evidence_root_not_directory")
        if not is_within(self._root.resolve(), self._project_root):
            raise ValueError("codex_project_evidence_storage_path_escape")
        return True

    def _directory(self, relative: Path, *, create: bool) -> Path | None:
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("codex_project_evidence_storage_path_escape")
        cursor = self._root
        for part in relative.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                raise ValueError(
                    "codex_project_evidence_storage_symlink_rejected"
                )
        if not cursor.exists():
            if not create:
                return None
            cursor.mkdir(parents=True, exist_ok=True)
        if not cursor.is_dir() or not is_within(
            cursor.resolve(), self._project_root,
        ):
            raise ValueError("codex_project_evidence_storage_path_escape")
        return cursor

    def _source_bytes(self, source_path: str | Path) -> tuple[Path, bytes]:
        raw = Path(source_path)
        if raw.is_symlink():
            raise ValueError("codex_project_evidence_source_symlink_rejected")
        try:
            source = raw.resolve(strict=True)
        except OSError as error:
            raise ValueError(
                "codex_project_evidence_source_unavailable"
            ) from error
        if not source.is_file():
            raise ValueError("codex_project_evidence_source_not_file")
        if not any(
            is_within(source, root) for root in self._allowed_source_roots
        ):
            raise ValueError("codex_project_evidence_source_outside_allowlist")
        try:
            with source.open("rb") as source_file:
                value = source_file.read(MAX_OBJECT_BYTES + 1)
        except OSError as error:
            raise ValueError(
                "codex_project_evidence_source_unreadable"
            ) from error
        if len(value) > MAX_OBJECT_BYTES:
            raise ValueError("codex_project_evidence_source_too_large")
        return source, value

    @staticmethod
    def _identity(
        *,
        project_id: str,
        task_id: str,
        source_revision: str,
        evidence_kind: str,
        content_sha256: str,
        verification_status: str,
        validator_id: str | None,
    ) -> str:
        identity = {
            "project_id": project_id,
            "task_id": task_id,
            "source_revision": source_revision,
            "evidence_kind": evidence_kind,
            "content_sha256": content_sha256,
            "verification_status": verification_status,
            "validator_id": validator_id,
        }
        return "dev-evidence-" + sha256_bytes(
            canonical_bytes(identity)
        )[:24]

    def register_file(
        self,
        source_path: str | Path,
        *,
        task_id: str,
        source_revision: str,
        evidence_kind: str,
        title: str,
        summary: str,
        recorded_by: str,
        verification_status: str = "observed",
        validator_id: str | None = None,
        media_type: str | None = None,
    ) -> dict[str, Any]:
        """Copy one small allowlisted file and register immutable metadata."""
        task = normalized_text(task_id, field="task_id", maximum=200)
        revision = normalized_text(
            source_revision, field="source_revision", maximum=200,
        )
        kind = normalized_text(
            evidence_kind, field="evidence_kind", maximum=64,
        )
        if SAFE_KIND.fullmatch(kind) is None:
            raise ValueError("codex_project_evidence_kind_invalid")
        evidence_title = normalized_text(title, field="title", maximum=300)
        evidence_summary = normalized_text(
            summary, field="summary", maximum=4_000,
        )
        recorder = normalized_text(
            recorded_by, field="recorded_by", maximum=200,
        )
        if verification_status not in VERIFICATION_STATUSES:
            raise ValueError(
                "codex_project_evidence_verification_status_invalid"
            )
        validator = None
        if validator_id is not None:
            validator = normalized_text(
                validator_id, field="validator_id", maximum=200,
            )
        if verification_status == "verified" and validator is None:
            raise ValueError(
                "codex_project_evidence_verified_validator_required"
            )

        source, content = self._source_bytes(source_path)
        content_sha256 = sha256_bytes(content)
        evidence_id = self._identity(
            project_id=self._project_id,
            task_id=task,
            source_revision=revision,
            evidence_kind=kind,
            content_sha256=content_sha256,
            verification_status=verification_status,
            validator_id=validator,
        )
        selected_media_type = media_type or mimetypes.guess_type(source.name)[0]
        selected_media_type = normalized_text(
            selected_media_type or "application/octet-stream",
            field="media_type",
            maximum=200,
        )
        object_relative = (
            Path("objects/sha256") / content_sha256[:2] / content_sha256
        )
        record = {
            "schema_version": "1.0.0",
            "artifact_type": "project_evidence_record",
            "evidence_id": evidence_id,
            "project_id": self._project_id,
            "task_id": task,
            "source_revision": revision,
            "evidence_kind": kind,
            "title": evidence_title,
            "summary": evidence_summary,
            "recorded_by": recorder,
            "validator_id": validator,
            "verification_status": verification_status,
            "content": {
                "sha256": content_sha256,
                "byte_count": len(content),
                "media_type": selected_media_type,
                "object_ref": (
                    DEVELOPMENT_PROJECT_EVIDENCE_RELATIVE_PATH
                    / object_relative
                ).as_posix(),
                "source_locator": source.as_posix(),
            },
            "authority_status": "not_asserted",
            "non_claims": list(RECORD_NON_CLAIMS),
        }
        return self._persist_record(
            record=record,
            content=content,
            object_relative=object_relative,
        )

    def _persist_record(
        self,
        *,
        record: Mapping[str, Any],
        content: bytes,
        object_relative: Path,
    ) -> dict[str, Any]:
        serialized = pretty_bytes(record)
        self._validate_root(create=True)
        records = self._directory(Path("records"), create=True)
        objects = self._directory(object_relative.parent, create=True)
        assert records is not None and objects is not None
        object_target = objects / object_relative.name
        record_target = records / f"{record['evidence_id']}.json"
        lock_path = self._root / ".registration.lock"
        if lock_path.is_symlink():
            raise ValueError("codex_project_evidence_lock_symlink_rejected")
        with lock_path.open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            self._write_immutable_object(object_target, content)
            status = self._write_immutable_record(record_target, serialized)
        return {
            "status": status,
            "evidence": dict(record),
            "record_ref": record_target.relative_to(
                self._project_root,
            ).as_posix(),
            "object_ref": object_target.relative_to(
                self._project_root,
            ).as_posix(),
        }

    @staticmethod
    def _write_immutable_object(target: Path, content: bytes) -> None:
        if not target.exists():
            atomic_write(target, content)
            return
        if target.is_symlink():
            raise ValueError("codex_project_evidence_object_symlink_rejected")
        try:
            existing = target.read_bytes()
        except OSError as error:
            raise ValueError(
                "codex_project_evidence_object_unreadable"
            ) from error
        if existing != content:
            raise ValueError("codex_project_evidence_object_hash_conflict")

    @staticmethod
    def _write_immutable_record(target: Path, serialized: bytes) -> str:
        if not target.exists():
            atomic_write(target, serialized)
            return "registered"
        if target.is_symlink():
            raise ValueError("codex_project_evidence_record_symlink_rejected")
        try:
            existing = target.read_bytes()
        except OSError as error:
            raise ValueError(
                "codex_project_evidence_record_unreadable"
            ) from error
        if existing != serialized:
            raise ValueError("codex_project_evidence_record_conflict")
        return "already_registered"

    def verify(self, evidence_id: str) -> dict[str, Any]:
        """Verify one record and its copied object without using the index."""
        normalized_id = normalized_text(
            evidence_id, field="evidence_id", maximum=64,
        )
        if SAFE_EVIDENCE_ID.fullmatch(normalized_id) is None:
            raise ValueError("codex_project_evidence_id_invalid")
        response: dict[str, Any] = {
            "status": "not_found",
            "evidence_id": normalized_id,
            "record_ref": None,
            "record_sha256": None,
            "evidence": None,
            "issues": [],
        }
        if not self._validate_root(create=False):
            return response
        records = self._directory(Path("records"), create=False)
        if records is None:
            return response
        target = records / f"{normalized_id}.json"
        if not target.exists():
            return response
        response["record_ref"] = target.relative_to(
            self._project_root,
        ).as_posix()
        if target.is_symlink():
            response["status"] = "invalid"
            response["issues"] = ["record_symlink_rejected"]
            return response
        try:
            raw = target.read_bytes()
            value = json.loads(raw.decode("utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            response["status"] = "invalid"
            response["issues"] = ["record_unreadable"]
            return response
        response["record_sha256"] = sha256_bytes(raw)
        response["evidence"] = value
        issues = record_shape_issues(
            value, expected_evidence_id=normalized_id,
        )
        if isinstance(value, Mapping) and value.get("project_id") != (
            self._project_id
        ):
            issues.append("project_id_mismatch")
        content = value.get("content") if isinstance(value, Mapping) else None
        if isinstance(content, Mapping):
            self._verify_object(content, issues)
        response["issues"] = list(dict.fromkeys(issues))
        response["status"] = "ok" if not response["issues"] else "invalid"
        return response

    def _verify_object(
        self, content: Mapping[str, Any], issues: list[str],
    ) -> None:
        content_sha256 = content.get("sha256")
        if not isinstance(content_sha256, str) or SHA256.fullmatch(
            content_sha256,
        ) is None:
            return
        expected_ref = (
            DEVELOPMENT_PROJECT_EVIDENCE_RELATIVE_PATH
            / "objects/sha256"
            / content_sha256[:2]
            / content_sha256
        ).as_posix()
        if content.get("object_ref") != expected_ref:
            issues.append("object_ref_mismatch")
        object_path = self._project_root / expected_ref
        if object_path.is_symlink():
            issues.append("object_symlink_rejected")
            return
        if not object_path.is_file():
            issues.append("object_missing")
            return
        try:
            object_bytes = object_path.read_bytes()
        except OSError:
            issues.append("object_unreadable")
            return
        if sha256_bytes(object_bytes) != content_sha256:
            issues.append("object_hash_mismatch")
        if len(object_bytes) != content.get("byte_count"):
            issues.append("object_byte_count_mismatch")

    def get(self, evidence_id: str) -> dict[str, Any]:
        """Alias exact lookup to integrity verification."""
        return self.verify(evidence_id)

    def rebuild_index(self) -> dict[str, Any]:
        """Rebuild the disposable metadata keyword index deterministically."""
        return rebuild_evidence_index(self)

    def search(self, query: str, *, limit: int = 10) -> dict[str, Any]:
        """Read the current derived index; never rebuild it implicitly."""
        return search_evidence_index(self, query, limit=limit)

    def lifecycle_store(self) -> Any:
        """Return the v4.96 append-only lifecycle overlay for this store."""

        from .development_evidence_lifecycle import (
            DevelopmentEvidenceLifecycleStore,
        )

        return DevelopmentEvidenceLifecycleStore(self)

    def resolve_evidence_lifecycle(
        self,
        evidence_id: str,
        *,
        as_of: str | None = None,
    ) -> dict[str, Any]:
        """Resolve current eligibility without changing immutable Evidence."""

        return self.lifecycle_store().resolve(evidence_id, as_of=as_of)

    def resolve_all_evidence_lifecycle(
        self,
        *,
        as_of: str | None = None,
    ) -> dict[str, Any]:
        """Resolve every valid record while isolating item-local defects."""

        return self.lifecycle_store().resolve_all(as_of=as_of)

    def build_evolution_bundle(
        self,
        evidence_ids: Sequence[str],
        *,
        memory_ids: Sequence[str] = (),
    ) -> dict[str, Any]:
        """Build a deterministic advisory evolve input from verified facts."""
        return assemble_evolution_bundle(
            self,
            evidence_ids,
            memory_ids=memory_ids,
        )
