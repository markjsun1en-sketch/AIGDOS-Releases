"""Reproducible macOS development-build delivery for one Production Worker.

This module turns the existing typed Godot execution adapter into a bounded
build primitive.  It exports the same pinned source twice, compares the full
app content trees, validates the ad-hoc signature, promotes one app atomically,
launches that exact promoted artifact, and emits a factual JSON delivery
receipt.  It also exercises a byte-for-byte restore of the embedded PCK and
restores a prior delivered app if post-promotion launch verification fails.

The result is local development output.  It is not a release, notarization,
qualification result, Gate decision, or authority grant.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import signal
import stat
import subprocess
import tempfile
import time
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Sequence

from .godot_execution_adapter import (
    GodotCommandResult,
    GodotExecutionAdapter,
    ProjectBoundaryError,
)


DEFAULT_MAX_TOOL_OUTPUT_BYTES = 128 * 1024
SOURCE_IDENTITY_MAX_GIT_OUTPUT_BYTES = 8 * 1024 * 1024
_UID_VALUE_PATTERN = re.compile(r"uid://[a-z0-9]+")
_IMPORT_UID_PATTERN = re.compile(r'^uid="(uid://[a-z0-9]+)"$', re.MULTILINE)
_RESOURCE_UID_PATTERN = re.compile(r'\buid="(uid://[a-z0-9]+)"')
_ANSI_ESCAPE_PATTERN = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
_GODOT_DIRECT_SOURCE_SUFFIXES = {
    ".cfg",
    ".csv",
    ".gd",
    ".gdshader",
    ".ini",
    ".json",
    ".po",
    ".res",
    ".scn",
    ".translation",
    ".tres",
    ".tscn",
    ".txt",
}


class DevelopmentBuildError(RuntimeError):
    """Base error for invalid or incomplete development-build delivery."""


class SourceIdentityError(DevelopmentBuildError):
    """Raised when the selected source is not an exact clean Git revision."""


class ArtifactBoundaryError(DevelopmentBuildError):
    """Raised when an artifact path escapes the selected output root."""


@dataclass(frozen=True)
class GodotDevelopmentBuildDelivery:
    schema_version: str
    artifact_type: str
    delivery_id: str
    task_id: str
    attempt_id: int
    actor_id: str
    agent_id: str
    skill_id: str
    preset_name: str
    artifact_name: str
    started_at: str
    finished_at: str
    status: str
    failure_kind: str | None
    source_identity: dict[str, Any]
    engine_preflight: dict[str, Any] | None
    build_runs: tuple[dict[str, Any], ...]
    reproducibility: dict[str, Any]
    artifact_identity: dict[str, Any] | None
    code_signature_verification: dict[str, Any] | None
    launch_verification: dict[str, Any] | None
    recovery_verification: dict[str, Any]
    receipt_path: str
    non_claims: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["build_runs"] = list(self.build_runs)
        value["non_claims"] = list(self.non_claims)
        return value


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _file_identity(path: Path) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file():
        raise ArtifactBoundaryError(f"artifact is not a regular file: {path}")
    return {
        "byte_count": path.stat().st_size,
        "content_sha256": _sha256_file(path),
    }


def _tree_identity(root: Path) -> dict[str, Any]:
    if root.is_symlink() or not root.is_dir():
        raise ArtifactBoundaryError(f"artifact is not a regular directory: {root}")
    entries: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix()):
        relative = path.relative_to(root).as_posix()
        if path.is_symlink():
            raise ArtifactBoundaryError(
                f"symlinked development artifact is outside v1 support: {relative}"
            )
        if path.is_dir():
            continue
        if not path.is_file():
            raise ArtifactBoundaryError(
                f"non-regular development artifact entry: {relative}"
            )
        identity = _file_identity(path)
        entries.append(
            {
                "relative_path": relative,
                "byte_count": identity["byte_count"],
                "content_sha256": identity["content_sha256"],
                "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
            }
        )
    if not entries:
        raise ArtifactBoundaryError(f"development artifact is empty: {root}")
    tree_digest = hashlib.sha256()
    for entry in entries:
        canonical = json.dumps(
            entry,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        tree_digest.update(len(canonical).to_bytes(8, "big"))
        tree_digest.update(canonical)
    packs = [
        entry
        for entry in entries
        if PurePosixPath(entry["relative_path"]).suffix.lower() == ".pck"
    ]
    if len(packs) != 1:
        raise ArtifactBoundaryError(
            f"macOS development app must contain exactly one PCK; observed {len(packs)}"
        )
    return {
        "identity_type": "content_tree_sha256_v1",
        "tree_sha256": tree_digest.hexdigest(),
        "file_count": len(entries),
        "byte_count": sum(entry["byte_count"] for entry in entries),
        "embedded_pck": dict(packs[0]),
        "files": entries,
    }


def _truncate(raw: bytes, limit: int) -> tuple[str, bool]:
    if len(raw) <= limit:
        return raw.decode("utf-8", errors="replace"), False
    return raw[:limit].decode("utf-8", errors="replace"), True


def _diagnostic_error_count(*outputs: str) -> int:
    count = 0
    for line in "\n".join(outputs).splitlines():
        normalized = _ANSI_ESCAPE_PATTERN.sub("", line).strip().lower()
        if normalized.startswith(("error:", "script error:", "parse error:")):
            count += 1
        elif "project export for preset" in normalized and "failed" in normalized:
            count += 1
    return count


def _terminate_process(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    if os.name == "posix":
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            return
    else:
        process.terminate()
    try:
        process.wait(timeout=1.0)
        return
    except subprocess.TimeoutExpired:
        pass
    if os.name == "posix":
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            return
    else:
        process.kill()
    process.wait(timeout=1.0)


def _run_bounded_command(
    command: Sequence[str],
    *,
    cwd: Path,
    timeout_seconds: float,
    max_output_bytes: int,
) -> dict[str, Any]:
    started_at = _utc_now()
    started = time.monotonic()
    timed_out = False
    process = subprocess.Popen(
        tuple(command),
        cwd=cwd,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=False,
        start_new_session=(os.name == "posix"),
    )
    try:
        stdout_raw, stderr_raw = process.communicate(timeout=timeout_seconds)
    except subprocess.TimeoutExpired:
        timed_out = True
        _terminate_process(process)
        stdout_raw, stderr_raw = process.communicate()
    stdout, stdout_truncated = _truncate(stdout_raw, max_output_bytes)
    stderr, stderr_truncated = _truncate(stderr_raw, max_output_bytes)
    exit_code = process.returncode
    if timed_out:
        status = "timeout"
        failure_kind = "timeout"
    elif exit_code is not None and exit_code < 0:
        status = "fail"
        failure_kind = "process_signaled"
    elif exit_code != 0:
        status = "fail"
        failure_kind = "command_failed"
    else:
        status = "pass"
        failure_kind = None
    return {
        "command": list(command),
        "started_at": started_at,
        "duration_ms": max(0, round((time.monotonic() - started) * 1000)),
        "exit_code": exit_code,
        "status": status,
        "failure_kind": failure_kind,
        "stdout": stdout,
        "stderr": stderr,
        "stdout_truncated": stdout_truncated,
        "stderr_truncated": stderr_truncated,
        "timed_out": timed_out,
    }


class GodotDevelopmentBuild:
    """Build and deliver one reproducible macOS development app."""

    def __init__(
        self,
        *,
        execution: GodotExecutionAdapter,
        artifact_root: str | Path,
        macos_open_binary: str | Path = "/usr/bin/open",
        codesign_binary: str | Path = "/usr/bin/codesign",
        require_clean_source: bool = True,
        max_tool_output_bytes: int = DEFAULT_MAX_TOOL_OUTPUT_BYTES,
    ) -> None:
        self.execution = execution
        self.project_root = execution.project_root
        root = Path(artifact_root)
        if not root.is_absolute():
            raise ArtifactBoundaryError("artifact_root must be an absolute path")
        self.artifact_root = root.resolve(strict=True)
        if not self.artifact_root.is_dir():
            raise ArtifactBoundaryError(
                f"artifact_root is not a directory: {self.artifact_root}"
            )
        try:
            self.artifact_root.relative_to(self.project_root)
        except ValueError:
            pass
        else:
            raise ArtifactBoundaryError(
                "artifact_root must stay outside the selected project"
            )
        self.macos_open_binary = self._resolve_executable(
            macos_open_binary,
            label="macos_open_binary",
        )
        self.codesign_binary = self._resolve_executable(
            codesign_binary,
            label="codesign_binary",
        )
        self.require_clean_source = bool(require_clean_source)
        if not isinstance(max_tool_output_bytes, int) or max_tool_output_bytes < 1024:
            raise ValueError("max_tool_output_bytes must be an integer >= 1024")
        self.max_tool_output_bytes = max_tool_output_bytes

    @staticmethod
    def _resolve_executable(raw_path: str | Path, *, label: str) -> Path:
        path = Path(raw_path)
        if not path.is_absolute() or "\x00" in str(path):
            raise ArtifactBoundaryError(f"{label} must be an absolute safe path")
        resolved = path.resolve(strict=True)
        if not resolved.is_file() or not os.access(resolved, os.X_OK):
            raise ArtifactBoundaryError(
                f"{label} is not an executable file: {resolved}"
            )
        return resolved

    @staticmethod
    def _artifact_name(raw_name: str) -> str:
        if not isinstance(raw_name, str) or not raw_name.strip() or "\x00" in raw_name:
            raise ArtifactBoundaryError("artifact_name must be a non-empty safe string")
        name = raw_name.strip()
        if Path(name).name != name or name in {".", ".."} or not name.endswith(".app"):
            raise ArtifactBoundaryError(
                "artifact_name must be one simple filename ending in .app"
            )
        return name

    def _git(self, *arguments: str) -> str:
        result = _run_bounded_command(
            ("git", "-C", str(self.project_root), *arguments),
            cwd=self.project_root,
            timeout_seconds=min(self.execution.timeout_seconds, 15.0),
            max_output_bytes=self.max_tool_output_bytes,
        )
        if result["status"] != "pass":
            raise SourceIdentityError(
                f"Git source identity command failed: {' '.join(arguments)}: "
                f"{result['stderr'].strip()}"
            )
        return str(result["stdout"]).strip()

    def _tracked_project_paths(self) -> set[str]:
        result = _run_bounded_command(
            (
                "git",
                "-C",
                str(self.project_root),
                "ls-files",
                "-z",
                "--",
                ".",
            ),
            cwd=self.project_root,
            timeout_seconds=min(self.execution.timeout_seconds, 15.0),
            max_output_bytes=SOURCE_IDENTITY_MAX_GIT_OUTPUT_BYTES,
        )
        if result["status"] != "pass" or result["stdout_truncated"]:
            detail = str(result["stderr"]).strip()
            if result["stdout_truncated"]:
                detail = "tracked path inventory exceeded the bounded output limit"
            raise SourceIdentityError(
                f"Git tracked-path inventory failed: {detail or result['failure_kind']}"
            )
        return {
            value
            for value in str(result["stdout"]).split("\0")
            if value
        }

    def _godot_source_sidecar_identity(self) -> dict[str, Any]:
        """Bind active Godot source sidecars, including Git-ignored files."""

        tracked_paths = self._tracked_project_paths()
        sidecar_paths: list[str] = []
        direct_source_paths: list[str] = []
        gdignore_markers: list[str] = []
        issues: list[str] = []
        for required in ("project.godot", "export_presets.cfg"):
            if required not in tracked_paths:
                issues.append(f"required build source is not tracked: {required}")

        for current_raw, directories, filenames in os.walk(
            self.project_root,
            topdown=True,
            followlinks=False,
        ):
            current = Path(current_raw)
            relative_directory = current.relative_to(self.project_root)
            directories[:] = sorted(
                name
                for name in directories
                if name not in {".git", ".godot"}
                and not (current / name).is_symlink()
            )
            if ".gdignore" in filenames:
                marker = (relative_directory / ".gdignore").as_posix()
                gdignore_markers.append(marker)
                marker_path = current / ".gdignore"
                if marker_path.is_symlink() or not marker_path.is_file():
                    issues.append(f"unsafe .gdignore marker: {marker}")
                if marker not in tracked_paths:
                    issues.append(f"untracked .gdignore marker: {marker}")
                directories[:] = []
                continue
            for name in sorted(filenames):
                relative = (relative_directory / name).as_posix()
                if name.endswith((".import", ".uid")):
                    sidecar_paths.append(relative)
                elif Path(name).suffix.lower() in _GODOT_DIRECT_SOURCE_SUFFIXES:
                    direct_source_paths.append(relative)

        uid_owners: dict[str, list[str]] = {}
        manifest_entries: list[dict[str, Any]] = []
        import_count = 0
        uid_count = 0
        text_resource_uid_count = 0
        for relative in sidecar_paths:
            sidecar = self.project_root / relative
            suffix = ".import" if relative.endswith(".import") else ".uid"
            source_relative = relative[: -len(suffix)]
            source = self.project_root / source_relative
            if sidecar.is_symlink() or not sidecar.is_file():
                issues.append(f"unsafe sidecar: {relative}")
                continue
            if relative not in tracked_paths:
                issues.append(f"untracked active sidecar: {relative}")
            if source.is_symlink() or not source.is_file():
                issues.append(f"orphan active sidecar: {relative}")
            elif source_relative not in tracked_paths:
                issues.append(f"sidecar source is not tracked: {source_relative}")
            try:
                text = sidecar.read_text(encoding="utf-8")
            except (OSError, UnicodeError) as exc:
                issues.append(f"unreadable sidecar: {relative}: {exc}")
                continue
            if suffix == ".uid":
                uid_count += 1
                candidate = text.strip()
                uid = candidate if _UID_VALUE_PATTERN.fullmatch(candidate) else None
            else:
                import_count += 1
                match = _IMPORT_UID_PATTERN.search(text)
                uid = match.group(1) if match else None
            if uid is None:
                issues.append(f"invalid or missing sidecar UID: {relative}")
            else:
                uid_owners.setdefault(uid, []).append(relative)
            manifest_entries.append(
                {
                    "relative_path": relative,
                    "content_sha256": _sha256_file(sidecar),
                }
            )

        for relative in direct_source_paths:
            source = self.project_root / relative
            if source.is_symlink() or not source.is_file():
                issues.append(f"unsafe active Godot source: {relative}")
                continue
            if relative not in tracked_paths:
                issues.append(f"untracked active Godot source: {relative}")
            if not relative.endswith((".tscn", ".tres")):
                continue
            try:
                with source.open("r", encoding="utf-8") as handle:
                    first_line = handle.readline(4096)
            except (OSError, UnicodeError) as exc:
                issues.append(f"unreadable Godot text resource: {relative}: {exc}")
                continue
            match = _RESOURCE_UID_PATTERN.search(first_line)
            if match:
                text_resource_uid_count += 1
                uid_owners.setdefault(match.group(1), []).append(relative)

        for uid, owners in sorted(uid_owners.items()):
            if len(owners) > 1:
                issues.append(f"duplicate Godot resource UID {uid}: {', '.join(owners)}")
        if issues:
            preview = "; ".join(issues[:8])
            if len(issues) > 8:
                preview += f"; ... {len(issues) - 8} more"
            raise SourceIdentityError(
                f"Godot source sidecar identity is incomplete: {preview}"
            )

        digest = hashlib.sha256()
        for entry in manifest_entries:
            canonical = json.dumps(
                entry,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8")
            digest.update(len(canonical).to_bytes(8, "big"))
            digest.update(canonical)
        return {
            "identity_type": "godot_tracked_source_sidecars_v1",
            "status": "complete",
            "sidecar_count": len(manifest_entries),
            "import_sidecar_count": import_count,
            "uid_sidecar_count": uid_count,
            "direct_source_count": len(direct_source_paths),
            "text_resource_uid_count": text_resource_uid_count,
            "gdignore_markers": sorted(gdignore_markers),
            "manifest_sha256": digest.hexdigest(),
        }

    def _source_identity(
        self,
        *,
        require_complete_godot_sidecars: bool = False,
    ) -> dict[str, Any]:
        repository_root = Path(self._git("rev-parse", "--show-toplevel")).resolve(
            strict=True
        )
        try:
            project_relative = self.project_root.relative_to(repository_root).as_posix()
        except ValueError as exc:
            raise SourceIdentityError(
                "selected Godot project is outside its reported Git repository"
            ) from exc
        commit = self._git("rev-parse", "HEAD")
        tree = self._git("rev-parse", "HEAD^{tree}")
        status_output = self._git(
            "status",
            "--porcelain=v1",
            "--untracked-files=all",
            "--",
            ".",
        )
        status_lines = [line for line in status_output.splitlines() if line]
        if self.require_clean_source and status_lines:
            preview = "; ".join(status_lines[:8])
            raise SourceIdentityError(
                f"development build requires clean pinned source: {preview}"
            )
        project_marker = self.project_root / "project.godot"
        export_presets = self.project_root / "export_presets.cfg"
        if not export_presets.is_file():
            raise SourceIdentityError(
                f"selected project has no export_presets.cfg: {export_presets}"
            )
        identity = {
            "identity_type": "git_commit_tree_and_build_config_v1",
            "repository_root": str(repository_root),
            "project_root": str(self.project_root),
            "project_relative_path": project_relative or ".",
            "git_commit": commit,
            "git_tree": tree,
            "git_status": "clean" if not status_lines else "dirty",
            "git_status_lines": status_lines,
            "project_godot": _file_identity(project_marker),
            "export_presets": _file_identity(export_presets),
        }
        if require_complete_godot_sidecars:
            identity["godot_source_sidecars"] = (
                self._godot_source_sidecar_identity()
            )
        return identity

    @staticmethod
    def _source_identity_fingerprint(identity: dict[str, Any]) -> dict[str, Any]:
        return {
            "git_commit": identity["git_commit"],
            "git_tree": identity["git_tree"],
            "project_godot": identity["project_godot"],
            "export_presets": identity["export_presets"],
            "godot_sidecar_manifest_sha256": (
                identity.get("godot_source_sidecars", {}).get("manifest_sha256")
            ),
        }

    def _verify_source_stability(
        self,
        expected: dict[str, Any],
        *,
        phase: str,
        require_complete_godot_sidecars: bool,
    ) -> tuple[dict[str, Any], dict[str, Any] | None]:
        try:
            observed = self._source_identity(
                require_complete_godot_sidecars=require_complete_godot_sidecars,
            )
        except SourceIdentityError as exc:
            return (
                {
                    "phase": phase,
                    "status": "failed",
                    "error_type": type(exc).__name__,
                    "message": str(exc),
                },
                None,
            )
        expected_fingerprint = self._source_identity_fingerprint(expected)
        observed_fingerprint = self._source_identity_fingerprint(observed)
        matches = all(
            observed_fingerprint[key] == value
            for key, value in expected_fingerprint.items()
            if value is not None
        )
        return (
            {
                "phase": phase,
                "status": "pass" if matches else "failed",
                "expected": expected_fingerprint,
                "observed": observed_fingerprint,
            },
            observed,
        )

    def _verify_code_signature(self, app_path: Path) -> dict[str, Any]:
        result = _run_bounded_command(
            (
                str(self.codesign_binary),
                "--verify",
                "--deep",
                "--strict",
                "--verbose=2",
                str(app_path),
            ),
            cwd=self.artifact_root,
            timeout_seconds=self.execution.timeout_seconds,
            max_output_bytes=self.max_tool_output_bytes,
        )
        result["verification_type"] = "macos_codesign_structure"
        result["non_claims"] = [
            "codesign_structure_pass_is_not_notarization",
            "codesign_structure_pass_is_not_release_approval",
        ]
        return result

    def _launch_application(
        self,
        app_path: Path,
        *,
        log_path: Path,
        quit_after: int,
    ) -> dict[str, Any]:
        command = (
            str(self.macos_open_binary),
            "-W",
            "-n",
            str(app_path),
            "--args",
            "--headless",
            "--verbose",
            "--quit-after",
            str(quit_after),
            "--log-file",
            str(log_path),
        )
        result = _run_bounded_command(
            command,
            cwd=self.artifact_root,
            timeout_seconds=self.execution.timeout_seconds,
            max_output_bytes=self.max_tool_output_bytes,
        )
        if log_path.is_file():
            log_raw = log_path.read_bytes()
            log_text, log_truncated = _truncate(
                log_raw,
                self.max_tool_output_bytes,
            )
        else:
            log_text = ""
            log_truncated = False
        diagnostic_count = _diagnostic_error_count(
            str(result["stdout"]),
            str(result["stderr"]),
            log_text,
        )
        if result["status"] == "pass" and not log_text:
            result["status"] = "fail"
            result["failure_kind"] = "missing_launch_log"
        elif result["status"] == "pass" and diagnostic_count:
            result["status"] = "fail"
            result["failure_kind"] = "launch_diagnostic_error"
        result.update(
            {
                "verification_type": "promoted_macos_app_headless_launch",
                "launch_log": log_text,
                "launch_log_truncated": log_truncated,
                "diagnostic_error_count": diagnostic_count,
                "quit_after_frames": quit_after,
                "timeout_cleanup_scope": "launcher_wait_process",
                "non_claims": [
                    "launch_pass_is_not_independent_qa",
                    "launch_pass_is_not_qualification_or_gate_evidence",
                ],
            }
        )
        return result

    @staticmethod
    def _embedded_pack_path(app_root: Path, identity: dict[str, Any]) -> Path:
        relative = identity["embedded_pck"]["relative_path"]
        path = (app_root / relative).resolve(strict=True)
        try:
            path.relative_to(app_root.resolve(strict=True))
        except ValueError as exc:
            raise ArtifactBoundaryError("embedded PCK path escapes app bundle") from exc
        return path

    def _verify_pack_recovery(
        self,
        pack_path: Path,
        *,
        staging_root: Path,
    ) -> dict[str, Any]:
        expected = _file_identity(pack_path)
        probe = staging_root / "recovery-probe.pck"
        snapshot = staging_root / "recovery-snapshot.pck"
        shutil.copy2(pack_path, probe)
        shutil.copy2(probe, snapshot)
        probe.write_bytes(b"v4.95 isolated recovery probe\n")
        os.replace(snapshot, probe)
        observed = _file_identity(probe)
        probe.unlink()
        return {
            "verification_type": "isolated_embedded_pck_restore_round_trip",
            "status": "pass" if observed == expected else "fail",
            "expected_identity": expected,
            "restored_identity": observed,
            "mutated_delivered_artifact": False,
            "non_claims": [
                "isolated_restore_pass_is_not_live_recovery_proof",
                "isolated_restore_pass_is_not_release_or_gate_evidence",
            ],
        }

    @staticmethod
    def _atomic_write_receipt(path: Path, value: dict[str, Any]) -> None:
        temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        payload = json.dumps(
            value,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        ) + "\n"
        try:
            temporary.write_text(payload, encoding="utf-8")
            os.replace(temporary, path)
        finally:
            if temporary.exists():
                temporary.unlink()

    def _delivery(
        self,
        *,
        delivery_id: str,
        started_at: str,
        preset_name: str,
        artifact_name: str,
        status: str,
        failure_kind: str | None,
        source_identity: dict[str, Any],
        engine_preflight: dict[str, Any] | None,
        build_runs: Sequence[GodotCommandResult],
        reproducibility: dict[str, Any],
        artifact_identity: dict[str, Any] | None,
        code_signature_verification: dict[str, Any] | None,
        launch_verification: dict[str, Any] | None,
        recovery_verification: dict[str, Any],
        receipt_path: Path,
    ) -> GodotDevelopmentBuildDelivery:
        delivery = GodotDevelopmentBuildDelivery(
            schema_version="1.0.0",
            artifact_type="godot_development_build_delivery",
            delivery_id=delivery_id,
            task_id=self.execution.task_id,
            attempt_id=self.execution.attempt_id,
            actor_id=self.execution.actor_id,
            agent_id=self.execution.agent_id,
            skill_id=self.execution.skill_id,
            preset_name=preset_name,
            artifact_name=artifact_name,
            started_at=started_at,
            finished_at=_utc_now(),
            status=status,
            failure_kind=failure_kind,
            source_identity=source_identity,
            engine_preflight=engine_preflight,
            build_runs=tuple(result.to_dict() for result in build_runs),
            reproducibility=reproducibility,
            artifact_identity=artifact_identity,
            code_signature_verification=code_signature_verification,
            launch_verification=launch_verification,
            recovery_verification=recovery_verification,
            receipt_path=str(receipt_path),
            non_claims=(
                "development_build_is_not_release_candidate",
                "local_double_build_is_not_hermetic_cross_machine_reproducibility",
                "delivery_receipt_is_not_independent_qa",
                "delivery_receipt_is_not_qualification_or_gate_evidence",
                "delivery_receipt_grants_no_production_or_release_authority",
            ),
        )
        self._atomic_write_receipt(receipt_path, delivery.to_dict())
        return delivery

    def deliver_macos_app(
        self,
        *,
        preset_name: str,
        artifact_name: str,
        quit_after: int = 10,
    ) -> GodotDevelopmentBuildDelivery:
        """Export twice, compare, recover, promote, launch, and receipt one app."""

        preset = self.execution._required_identifier(preset_name, "preset_name")
        name = self._artifact_name(artifact_name)
        if not isinstance(quit_after, int) or isinstance(quit_after, bool) or quit_after < 1:
            raise ValueError("quit_after must be an integer >= 1")
        started_at = _utc_now()
        delivery_id = f"godot-build-{uuid.uuid4().hex}"
        final_path = self.artifact_root / name
        receipt_path = self.artifact_root / f"{name}.delivery.json"
        source_identity = self._source_identity(
            require_complete_godot_sidecars=True,
        )
        engine_preflight: dict[str, Any] | None = None
        build_runs: list[GodotCommandResult] = []
        reproducibility: dict[str, Any] = {"status": "not_run"}
        recovery: dict[str, Any] = {"status": "not_run"}
        staging_root = Path(
            tempfile.mkdtemp(prefix=".v495-godot-build-", dir=self.artifact_root)
        )
        prior_backup = staging_root / "prior-delivery.app"
        prior_identity: dict[str, Any] | None = None
        promoted = False
        try:
            engine_preflight = {
                **self.execution.preflight(),
                "delivery_tool_identity": {
                    "macos_open_binary": _file_identity(self.macos_open_binary),
                    "codesign_binary": _file_identity(self.codesign_binary),
                },
            }
            if engine_preflight.get("status") != "ready":
                return self._delivery(
                    delivery_id=delivery_id,
                    started_at=started_at,
                    preset_name=preset,
                    artifact_name=name,
                    status="failed",
                    failure_kind="engine_preflight_blocked",
                    source_identity=source_identity,
                    engine_preflight=engine_preflight,
                    build_runs=build_runs,
                    reproducibility=reproducibility,
                    artifact_identity=None,
                    code_signature_verification=None,
                    launch_verification=None,
                    recovery_verification=recovery,
                    receipt_path=receipt_path,
                )

            import_preparation = self.execution.run_project_load()
            engine_preflight["import_preparation"] = import_preparation.to_dict()
            if import_preparation.status != "pass":
                return self._delivery(
                    delivery_id=delivery_id,
                    started_at=started_at,
                    preset_name=preset,
                    artifact_name=name,
                    status="failed",
                    failure_kind=(
                        import_preparation.failure_kind
                        or "import_preparation_failed"
                    ),
                    source_identity=source_identity,
                    engine_preflight=engine_preflight,
                    build_runs=build_runs,
                    reproducibility=reproducibility,
                    artifact_identity=None,
                    code_signature_verification=None,
                    launch_verification=None,
                    recovery_verification=recovery,
                    receipt_path=receipt_path,
                )
            import_stability, prepared_identity = self._verify_source_stability(
                source_identity,
                phase="after_import_preparation",
                require_complete_godot_sidecars=True,
            )
            reproducibility["source_stability"] = {
                "after_import_preparation": import_stability,
            }
            if import_stability["status"] != "pass" or prepared_identity is None:
                source_identity["import_stability"] = import_stability
                return self._delivery(
                    delivery_id=delivery_id,
                    started_at=started_at,
                    preset_name=preset,
                    artifact_name=name,
                    status="failed",
                    failure_kind="source_identity_not_stable_after_import",
                    source_identity=source_identity,
                    engine_preflight=engine_preflight,
                    build_runs=build_runs,
                    reproducibility=reproducibility,
                    artifact_identity=None,
                    code_signature_verification=None,
                    launch_verification=None,
                    recovery_verification=recovery,
                    receipt_path=receipt_path,
                )
            source_identity = {
                **prepared_identity,
                "pre_import_fingerprint": self._source_identity_fingerprint(
                    source_identity
                ),
                "import_stability": import_stability,
            }

            first_path = staging_root / "build-a.app"
            second_path = staging_root / "build-b.app"
            first_run = self.execution.run_export_debug(
                preset,
                first_path,
                allowed_artifact_root=staging_root,
            )
            build_runs.append(first_run)
            if first_run.status != "pass" or not first_path.is_dir():
                return self._delivery(
                    delivery_id=delivery_id,
                    started_at=started_at,
                    preset_name=preset,
                    artifact_name=name,
                    status="failed",
                    failure_kind=first_run.failure_kind or "first_export_missing",
                    source_identity=source_identity,
                    engine_preflight=engine_preflight,
                    build_runs=build_runs,
                    reproducibility=reproducibility,
                    artifact_identity=None,
                    code_signature_verification=None,
                    launch_verification=None,
                    recovery_verification=recovery,
                    receipt_path=receipt_path,
                )
            first_identity = _tree_identity(first_path)
            first_source_stability, _ = self._verify_source_stability(
                source_identity,
                phase="after_first_export",
                require_complete_godot_sidecars=True,
            )
            reproducibility["source_stability"]["after_first_export"] = (
                first_source_stability
            )
            if first_source_stability["status"] != "pass":
                return self._delivery(
                    delivery_id=delivery_id,
                    started_at=started_at,
                    preset_name=preset,
                    artifact_name=name,
                    status="failed",
                    failure_kind="source_identity_changed_during_export",
                    source_identity=source_identity,
                    engine_preflight=engine_preflight,
                    build_runs=build_runs,
                    reproducibility=reproducibility,
                    artifact_identity=None,
                    code_signature_verification=None,
                    launch_verification=None,
                    recovery_verification=recovery,
                    receipt_path=receipt_path,
                )

            second_run = self.execution.run_export_debug(
                preset,
                second_path,
                allowed_artifact_root=staging_root,
            )
            build_runs.append(second_run)
            if second_run.status != "pass" or not second_path.is_dir():
                return self._delivery(
                    delivery_id=delivery_id,
                    started_at=started_at,
                    preset_name=preset,
                    artifact_name=name,
                    status="failed",
                    failure_kind=second_run.failure_kind or "second_export_missing",
                    source_identity=source_identity,
                    engine_preflight=engine_preflight,
                    build_runs=build_runs,
                    reproducibility=reproducibility,
                    artifact_identity=None,
                    code_signature_verification=None,
                    launch_verification=None,
                    recovery_verification=recovery,
                    receipt_path=receipt_path,
                )
            second_identity = _tree_identity(second_path)
            second_source_stability, _ = self._verify_source_stability(
                source_identity,
                phase="after_second_export",
                require_complete_godot_sidecars=True,
            )
            reproducibility["source_stability"]["after_second_export"] = (
                second_source_stability
            )
            if second_source_stability["status"] != "pass":
                return self._delivery(
                    delivery_id=delivery_id,
                    started_at=started_at,
                    preset_name=preset,
                    artifact_name=name,
                    status="failed",
                    failure_kind="source_identity_changed_during_export",
                    source_identity=source_identity,
                    engine_preflight=engine_preflight,
                    build_runs=build_runs,
                    reproducibility=reproducibility,
                    artifact_identity=None,
                    code_signature_verification=None,
                    launch_verification=None,
                    recovery_verification=recovery,
                    receipt_path=receipt_path,
                )
            matches = first_identity["tree_sha256"] == second_identity["tree_sha256"]
            source_stability = reproducibility["source_stability"]
            reproducibility = {
                "status": "byte_identical" if matches else "mismatch",
                "comparison_scope": "complete_macos_app_content_tree",
                "build_a_identity": first_identity,
                "build_b_identity": second_identity,
                "source_stability": source_stability,
            }
            if not matches:
                return self._delivery(
                    delivery_id=delivery_id,
                    started_at=started_at,
                    preset_name=preset,
                    artifact_name=name,
                    status="failed",
                    failure_kind="non_reproducible_output",
                    source_identity=source_identity,
                    engine_preflight=engine_preflight,
                    build_runs=build_runs,
                    reproducibility=reproducibility,
                    artifact_identity=None,
                    code_signature_verification=None,
                    launch_verification=None,
                    recovery_verification=recovery,
                    receipt_path=receipt_path,
                )

            signature = self._verify_code_signature(first_path)
            if signature["status"] != "pass":
                return self._delivery(
                    delivery_id=delivery_id,
                    started_at=started_at,
                    preset_name=preset,
                    artifact_name=name,
                    status="failed",
                    failure_kind="invalid_code_signature",
                    source_identity=source_identity,
                    engine_preflight=engine_preflight,
                    build_runs=build_runs,
                    reproducibility=reproducibility,
                    artifact_identity=None,
                    code_signature_verification=signature,
                    launch_verification=None,
                    recovery_verification=recovery,
                    receipt_path=receipt_path,
                )

            pack_path = self._embedded_pack_path(first_path, first_identity)
            recovery = self._verify_pack_recovery(
                pack_path,
                staging_root=staging_root,
            )
            if recovery["status"] != "pass":
                return self._delivery(
                    delivery_id=delivery_id,
                    started_at=started_at,
                    preset_name=preset,
                    artifact_name=name,
                    status="failed",
                    failure_kind="recovery_verification_failed",
                    source_identity=source_identity,
                    engine_preflight=engine_preflight,
                    build_runs=build_runs,
                    reproducibility=reproducibility,
                    artifact_identity=None,
                    code_signature_verification=signature,
                    launch_verification=None,
                    recovery_verification=recovery,
                    receipt_path=receipt_path,
                )

            if final_path.exists():
                if final_path.is_symlink() or not final_path.is_dir():
                    raise ArtifactBoundaryError(
                        f"existing delivery is not a regular app directory: {final_path}"
                    )
                prior_identity = _tree_identity(final_path)
                os.replace(final_path, prior_backup)
            os.replace(first_path, final_path)
            promoted = True
            promoted_identity = _tree_identity(final_path)
            if promoted_identity["tree_sha256"] != first_identity["tree_sha256"]:
                raise DevelopmentBuildError(
                    "promoted app identity differs from reproducible candidate"
                )

            launch_log = staging_root / "promoted-launch.log"
            launch = self._launch_application(
                final_path,
                log_path=launch_log,
                quit_after=quit_after,
            )
            if launch["status"] != "pass":
                quarantined = staging_root / "failed-promoted.app"
                os.replace(final_path, quarantined)
                promoted = False
                if prior_backup.exists():
                    os.replace(prior_backup, final_path)
                    restored = _tree_identity(final_path)
                    rollback_matches = (
                        prior_identity is not None
                        and restored["tree_sha256"] == prior_identity["tree_sha256"]
                    )
                    recovery = {
                        **recovery,
                        "delivery_rollback_status": (
                            "restored_previous" if rollback_matches else "restore_mismatch"
                        ),
                        "previous_identity": prior_identity,
                        "restored_identity": restored,
                    }
                else:
                    recovery = {
                        **recovery,
                        "delivery_rollback_status": "failed_candidate_quarantined_no_previous",
                    }
                return self._delivery(
                    delivery_id=delivery_id,
                    started_at=started_at,
                    preset_name=preset,
                    artifact_name=name,
                    status="failed",
                    failure_kind=launch["failure_kind"] or "launch_failed",
                    source_identity=source_identity,
                    engine_preflight=engine_preflight,
                    build_runs=build_runs,
                    reproducibility=reproducibility,
                    artifact_identity=None,
                    code_signature_verification=signature,
                    launch_verification=launch,
                    recovery_verification=recovery,
                    receipt_path=receipt_path,
                )

            final_signature = self._verify_code_signature(final_path)
            if final_signature["status"] != "pass":
                raise DevelopmentBuildError(
                    "promoted app lost its valid code-signature structure"
                )
            artifact_identity = {
                **promoted_identity,
                "relative_path": name,
            }
            recovery = {
                **recovery,
                "delivery_rollback_status": "not_required",
                "previous_artifact_present": prior_identity is not None,
            }
            return self._delivery(
                delivery_id=delivery_id,
                started_at=started_at,
                preset_name=preset,
                artifact_name=name,
                status="delivered",
                failure_kind=None,
                source_identity=source_identity,
                engine_preflight=engine_preflight,
                build_runs=build_runs,
                reproducibility=reproducibility,
                artifact_identity=artifact_identity,
                code_signature_verification=final_signature,
                launch_verification=launch,
                recovery_verification=recovery,
                receipt_path=receipt_path,
            )
        except Exception:
            if promoted and final_path.exists():
                failed = staging_root / "exception-promoted.app"
                os.replace(final_path, failed)
                if prior_backup.exists():
                    os.replace(prior_backup, final_path)
            raise
        finally:
            shutil.rmtree(staging_root, ignore_errors=True)
