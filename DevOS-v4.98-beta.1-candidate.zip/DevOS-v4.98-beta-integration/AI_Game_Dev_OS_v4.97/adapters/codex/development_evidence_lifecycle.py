"""Append-only lifecycle overlay for immutable project Evidence.

The v4.95 Evidence records and content objects remain byte-identical.  This
module stores only lifecycle receipts and derives a current view.  Exact
historical lookup continues through ``DevelopmentProjectEvidenceStore.get``.
"""

from __future__ import annotations

import fcntl
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from ._development_evidence_common import (
    MAX_RECORD_FILES,
    SAFE_EVIDENCE_ID,
    canonical_bytes,
    normalized_evidence_ids,
    normalized_text,
    sha256_bytes,
)
from ._development_evidence_index import inventory as evidence_inventory


LIFECYCLE_ACTIONS = frozenset(
    {
        "invalidate",
        "supersede",
        "retain_until",
        "deprecate",
        "redact_from_retrieval",
        "recover",
        "migrate",
    }
)
LIFECYCLE_RECEIPTS_RELATIVE_PATH = Path("lifecycle/receipts")
MAX_LIFECYCLE_RECEIPTS = MAX_RECORD_FILES * 4
SAFE_RECEIPT_ID = re.compile(r"evidence-lifecycle-[0-9a-f]{24}")
RECEIPT_NON_CLAIMS = (
    "lifecycle_receipt_is_not_evidence_or_memory_promotion",
    "lifecycle_receipt_is_not_human_acceptance_or_gate_authority",
    "lifecycle_receipt_grants_no_release_production_or_live_authority",
)


def _timestamp(value: str, *, field: str) -> tuple[str, datetime]:
    normalized = normalized_text(value, field=field, maximum=100)
    candidate = normalized.replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(candidate)
    except ValueError as exc:
        raise ValueError(
            f"codex_project_evidence_lifecycle_{field}_invalid"
        ) from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(
            f"codex_project_evidence_lifecycle_{field}_timezone_required"
        )
    utc = parsed.astimezone(timezone.utc)
    return utc.isoformat(), utc


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _receipt_digest(value: Mapping[str, Any]) -> str:
    body = {
        key: item
        for key, item in value.items()
        if key not in {"receipt_id", "content_sha256"}
    }
    return sha256_bytes(canonical_bytes(body))


class DevelopmentEvidenceLifecycleStore:
    """Derive current Evidence eligibility from append-only receipts."""

    def __init__(self, evidence_store: Any) -> None:
        required = ("_project_root", "_project_id", "_validate_root", "_directory")
        if any(not hasattr(evidence_store, field) for field in required):
            raise ValueError("codex_project_evidence_lifecycle_store_invalid")
        self._evidence_store = evidence_store
        self._project_root = evidence_store._project_root
        self._project_id = evidence_store._project_id

    def _receipts_directory(self, *, create: bool) -> Path | None:
        if not self._evidence_store._validate_root(create=create):
            return None
        return self._evidence_store._directory(
            LIFECYCLE_RECEIPTS_RELATIVE_PATH,
            create=create,
        )

    def _verify_evidence(self, evidence_id: str) -> dict[str, Any]:
        result = self._evidence_store.verify(evidence_id)
        if result["status"] != "ok":
            raise ValueError(
                "codex_project_evidence_lifecycle_target_invalid:"
                f"{evidence_id}"
            )
        return result

    def append_action(
        self,
        target_evidence_id: str,
        *,
        action: str,
        actor_id: str,
        permission_policy_revision: str,
        expected_prior_lifecycle_revision: int,
        reason_code: str,
        reason: str,
        source_evidence_refs: Sequence[str],
        successor_evidence_id: str | None = None,
        retain_until: str | None = None,
        recovers_receipt_id: str | None = None,
        migration_source_schema: str | None = None,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        target = normalized_text(
            target_evidence_id,
            field="lifecycle_target_evidence_id",
            maximum=64,
        )
        if SAFE_EVIDENCE_ID.fullmatch(target) is None:
            raise ValueError("codex_project_evidence_lifecycle_target_id_invalid")
        selected_action = normalized_text(
            action,
            field="lifecycle_action",
            maximum=64,
        )
        if selected_action not in LIFECYCLE_ACTIONS:
            raise ValueError("codex_project_evidence_lifecycle_action_invalid")
        actor = normalized_text(actor_id, field="lifecycle_actor_id", maximum=200)
        policy_revision = normalized_text(
            permission_policy_revision,
            field="lifecycle_permission_policy_revision",
            maximum=200,
        )
        code = normalized_text(
            reason_code,
            field="lifecycle_reason_code",
            maximum=100,
        )
        explanation = normalized_text(
            reason,
            field="lifecycle_reason",
            maximum=4_000,
        )
        if (
            isinstance(expected_prior_lifecycle_revision, bool)
            or not isinstance(expected_prior_lifecycle_revision, int)
            or expected_prior_lifecycle_revision < 0
        ):
            raise ValueError(
                "codex_project_evidence_lifecycle_expected_revision_invalid"
            )
        source_refs = tuple(normalized_evidence_ids(source_evidence_refs))
        if not source_refs:
            raise ValueError(
                "codex_project_evidence_lifecycle_source_refs_required"
            )
        successor = None
        if successor_evidence_id is not None:
            successor = normalized_text(
                successor_evidence_id,
                field="lifecycle_successor_evidence_id",
                maximum=64,
            )
            if SAFE_EVIDENCE_ID.fullmatch(successor) is None:
                raise ValueError(
                    "codex_project_evidence_lifecycle_successor_id_invalid"
                )
        retained_until = None
        if retain_until is not None:
            retained_until, _ = _timestamp(
                retain_until,
                field="retain_until",
            )
        recovers = None
        if recovers_receipt_id is not None:
            recovers = normalized_text(
                recovers_receipt_id,
                field="lifecycle_recovers_receipt_id",
                maximum=100,
            )
            if SAFE_RECEIPT_ID.fullmatch(recovers) is None:
                raise ValueError(
                    "codex_project_evidence_lifecycle_recovery_receipt_id_invalid"
                )
        migration_schema = None
        if migration_source_schema is not None:
            migration_schema = normalized_text(
                migration_source_schema,
                field="lifecycle_migration_source_schema",
                maximum=200,
            )
        recorded, _ = _timestamp(
            recorded_at or _now(),
            field="recorded_at",
        )
        self._validate_action_fields(
            action=selected_action,
            target=target,
            successor=successor,
            retain_until=retained_until,
            recovers=recovers,
            migration_schema=migration_schema,
        )
        self._verify_evidence(target)
        for source_ref in source_refs:
            self._verify_evidence(source_ref)
        if successor is not None:
            self._verify_evidence(successor)

        receipts_dir = self._receipts_directory(create=True)
        assert receipts_dir is not None
        lock_path = receipts_dir.parent / ".lifecycle.lock"
        if lock_path.is_symlink():
            raise ValueError(
                "codex_project_evidence_lifecycle_lock_symlink_rejected"
            )
        with lock_path.open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            existing_receipts, existing_issues = self._valid_receipts_for_target(
                target
            )
            if existing_issues:
                raise ValueError(
                    "codex_project_evidence_lifecycle_target_review_needed"
                )
            latest_revision = (
                existing_receipts[-1]["resulting_lifecycle_revision"]
                if existing_receipts
                else 0
            )
            if latest_revision != expected_prior_lifecycle_revision:
                raise ValueError(
                    "codex_project_evidence_lifecycle_stale_expected_revision"
                )
            if existing_receipts:
                _, last_recorded_at = _timestamp(
                    existing_receipts[-1]["recorded_at"],
                    field="recorded_at",
                )
                _, next_recorded_at = _timestamp(
                    recorded,
                    field="recorded_at",
                )
                if next_recorded_at < last_recorded_at:
                    raise ValueError(
                        "codex_project_evidence_lifecycle_recorded_at_regression"
                    )
            current = self._derive_effective_view(
                target,
                existing_receipts,
                as_of=recorded,
                issues=[],
            )
            if current["status"] != "ok":
                raise ValueError(
                    "codex_project_evidence_lifecycle_target_review_needed"
                )
            self._validate_transition(
                action=selected_action,
                current=current,
                existing_receipts=existing_receipts,
                recovers=recovers,
            )
            resulting_revision = expected_prior_lifecycle_revision + 1
            body: dict[str, Any] = {
                "schema_version": "1.0.0",
                "artifact_type": "evidence_lifecycle_receipt",
                "project_id": self._project_id,
                "target_evidence_id": target,
                "action": selected_action,
                "actor_id": actor,
                "permission_policy_revision": policy_revision,
                "expected_prior_lifecycle_revision": (
                    expected_prior_lifecycle_revision
                ),
                "resulting_lifecycle_revision": resulting_revision,
                "reason_code": code,
                "reason": explanation,
                "source_evidence_refs": list(source_refs),
                "successor_evidence_id": successor,
                "retain_until": retained_until,
                "recovers_receipt_id": recovers,
                "migration_source_schema": migration_schema,
                "resulting_effective_state": "pending_derivation",
                "recorded_at": recorded,
                "non_claims": list(RECEIPT_NON_CLAIMS),
            }
            candidate = dict(body)
            candidate["receipt_id"] = "evidence-lifecycle-pending"
            candidate["content_sha256"] = "0" * 64
            predicted = self._derive_effective_view(
                target,
                [*existing_receipts, candidate],
                as_of=recorded,
                issues=[],
            )
            body["resulting_effective_state"] = predicted["effective_state"]
            digest = _receipt_digest(body)
            receipt_id = f"evidence-lifecycle-{digest[:24]}"
            receipt = {
                **body,
                "receipt_id": receipt_id,
                "content_sha256": digest,
            }
            filename = (
                f"{target}.{resulting_revision:08d}.{receipt_id}.json"
            )
            target_path = receipts_dir / filename
            serialized = (
                json.dumps(
                    receipt,
                    ensure_ascii=False,
                    indent=2,
                    sort_keys=True,
                )
                + "\n"
            ).encode("utf-8")
            try:
                with target_path.open("xb") as output:
                    output.write(serialized)
                    output.flush()
                    os.fsync(output.fileno())
            except FileExistsError as exc:
                raise ValueError(
                    "codex_project_evidence_lifecycle_receipt_conflict"
                ) from exc
        return {
            "status": "recorded",
            "receipt": receipt,
            "receipt_ref": target_path.relative_to(self._project_root).as_posix(),
            "effective_view": self._resolve_one(target, as_of=recorded),
        }

    @staticmethod
    def _validate_action_fields(
        *,
        action: str,
        target: str,
        successor: str | None,
        retain_until: str | None,
        recovers: str | None,
        migration_schema: str | None,
    ) -> None:
        if action == "supersede":
            if successor is None or successor == target:
                raise ValueError(
                    "codex_project_evidence_lifecycle_successor_required"
                )
        elif successor is not None:
            raise ValueError(
                "codex_project_evidence_lifecycle_successor_not_applicable"
            )
        if (action == "retain_until") != (retain_until is not None):
            raise ValueError(
                "codex_project_evidence_lifecycle_retain_until_shape_invalid"
            )
        if (action == "recover") != (recovers is not None):
            raise ValueError(
                "codex_project_evidence_lifecycle_recover_shape_invalid"
            )
        if (action == "migrate") != (migration_schema is not None):
            raise ValueError(
                "codex_project_evidence_lifecycle_migration_shape_invalid"
            )

    @staticmethod
    def _validate_transition(
        *,
        action: str,
        current: Mapping[str, Any],
        existing_receipts: Sequence[Mapping[str, Any]],
        recovers: str | None,
    ) -> None:
        if action == "supersede" and current.get("successor_evidence_id"):
            raise ValueError(
                "codex_project_evidence_lifecycle_successor_already_active"
            )
        if action != "recover":
            return
        receipts_by_id = {
            receipt["receipt_id"]: receipt for receipt in existing_receipts
        }
        recovered = {
            receipt["recovers_receipt_id"]
            for receipt in existing_receipts
            if receipt["action"] == "recover"
        }
        referenced = receipts_by_id.get(recovers)
        if (
            referenced is None
            or referenced["action"] in {"recover", "migrate"}
            or recovers in recovered
        ):
            raise ValueError(
                "codex_project_evidence_lifecycle_recovery_target_invalid"
            )

    def _receipt_paths(self) -> tuple[list[Path], bool]:
        receipts_dir = self._receipts_directory(create=False)
        if receipts_dir is None:
            return [], False
        paths = sorted(receipts_dir.glob("*.json"))
        return paths[:MAX_LIFECYCLE_RECEIPTS], (
            len(paths) > MAX_LIFECYCLE_RECEIPTS
        )

    def inventory_sha256(self) -> str:
        paths, truncated = self._receipt_paths()
        rows: list[dict[str, Any]] = []
        for path in paths:
            try:
                raw = path.read_bytes()
            except OSError:
                raw = b""
            rows.append(
                {
                    "filename": path.name,
                    "sha256": sha256_bytes(raw),
                }
            )
        return sha256_bytes(
            canonical_bytes({"rows": rows, "truncated": truncated})
        )

    def _valid_receipts_for_target(
        self,
        evidence_id: str,
    ) -> tuple[list[dict[str, Any]], list[str]]:
        paths, truncated = self._receipt_paths()
        prefix = f"{evidence_id}."
        matching = [path for path in paths if path.name.startswith(prefix)]
        issues: list[str] = []
        if truncated:
            issues.append("lifecycle_receipt_scan_truncated")
        candidates: list[dict[str, Any]] = []
        for path in matching:
            if path.is_symlink():
                issues.append(f"receipt_symlink_rejected:{path.name}")
                continue
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, UnicodeError, json.JSONDecodeError):
                issues.append(f"receipt_unreadable:{path.name}")
                continue
            shape_issues = self._receipt_shape_issues(
                value,
                expected_evidence_id=evidence_id,
            )
            if shape_issues:
                issues.extend(f"{item}:{path.name}" for item in shape_issues)
                continue
            candidates.append(dict(value))
        candidates.sort(
            key=lambda value: (
                value["resulting_lifecycle_revision"],
                value["receipt_id"],
            )
        )
        accepted: list[dict[str, Any]] = []
        revision = 0
        seen_receipt_ids: set[str] = set()
        for receipt in candidates:
            if receipt["receipt_id"] in seen_receipt_ids:
                issues.append(
                    f"duplicate_receipt_id:{receipt['receipt_id']}"
                )
                continue
            if (
                receipt["expected_prior_lifecycle_revision"] != revision
                or receipt["resulting_lifecycle_revision"] != revision + 1
            ):
                issues.append(
                    f"stale_or_noncontiguous_revision:{receipt['receipt_id']}"
                )
                continue
            accepted.append(receipt)
            seen_receipt_ids.add(receipt["receipt_id"])
            revision += 1
        return accepted, list(dict.fromkeys(issues))

    def _receipt_shape_issues(
        self,
        value: Any,
        *,
        expected_evidence_id: str,
    ) -> list[str]:
        if not isinstance(value, Mapping):
            return ["receipt_not_object"]
        required = {
            "schema_version",
            "artifact_type",
            "receipt_id",
            "project_id",
            "target_evidence_id",
            "action",
            "actor_id",
            "permission_policy_revision",
            "expected_prior_lifecycle_revision",
            "resulting_lifecycle_revision",
            "reason_code",
            "reason",
            "source_evidence_refs",
            "successor_evidence_id",
            "retain_until",
            "recovers_receipt_id",
            "migration_source_schema",
            "resulting_effective_state",
            "recorded_at",
            "content_sha256",
            "non_claims",
        }
        issues: list[str] = []
        if set(value) != required:
            issues.append("receipt_fields_invalid")
        if value.get("schema_version") != "1.0.0":
            issues.append("schema_version_invalid")
        if value.get("artifact_type") != "evidence_lifecycle_receipt":
            issues.append("artifact_type_invalid")
        receipt_id = value.get("receipt_id")
        if not isinstance(receipt_id, str) or SAFE_RECEIPT_ID.fullmatch(
            receipt_id
        ) is None:
            issues.append("receipt_id_invalid")
        if value.get("project_id") != self._project_id:
            issues.append("project_id_mismatch")
        if value.get("target_evidence_id") != expected_evidence_id:
            issues.append("target_evidence_id_mismatch")
        if value.get("action") not in LIFECYCLE_ACTIONS:
            issues.append("action_invalid")
        if value.get("non_claims") != list(RECEIPT_NON_CLAIMS):
            issues.append("non_claims_invalid")
        if not isinstance(value.get("source_evidence_refs"), list) or not value.get(
            "source_evidence_refs"
        ):
            issues.append("source_evidence_refs_invalid")
        for field in (
            "actor_id",
            "permission_policy_revision",
            "reason_code",
            "reason",
            "resulting_effective_state",
            "recorded_at",
        ):
            if not isinstance(value.get(field), str) or not value.get(field):
                issues.append(f"{field}_invalid")
        for field in (
            "expected_prior_lifecycle_revision",
            "resulting_lifecycle_revision",
        ):
            item = value.get(field)
            if isinstance(item, bool) or not isinstance(item, int) or item < 0:
                issues.append(f"{field}_invalid")
        digest = value.get("content_sha256")
        if not isinstance(digest, str) or digest != _receipt_digest(value):
            issues.append("content_sha256_mismatch")
        if isinstance(receipt_id, str) and isinstance(digest, str) and (
            receipt_id != f"evidence-lifecycle-{digest[:24]}"
        ):
            issues.append("receipt_id_hash_mismatch")
        return issues

    def _derive_effective_view(
        self,
        evidence_id: str,
        receipts: Sequence[Mapping[str, Any]],
        *,
        as_of: str,
        issues: Sequence[str],
    ) -> dict[str, Any]:
        _, as_of_time = _timestamp(as_of, field="as_of")
        applicable_receipts: list[Mapping[str, Any]] = []
        semantic_issues = list(issues)
        for receipt in receipts:
            try:
                _, receipt_time = _timestamp(
                    receipt["recorded_at"],
                    field="recorded_at",
                )
            except (KeyError, TypeError, ValueError):
                semantic_issues.append(
                    f"invalid_recorded_at:{receipt.get('receipt_id', 'unknown')}"
                )
                continue
            if receipt_time <= as_of_time:
                applicable_receipts.append(receipt)
        receipts_by_id = {
            receipt["receipt_id"]: receipt for receipt in applicable_receipts
        }
        recovered: set[str] = set()
        for receipt in applicable_receipts:
            if receipt["action"] != "recover":
                continue
            target_receipt_id = receipt["recovers_receipt_id"]
            referenced = receipts_by_id.get(target_receipt_id)
            if (
                referenced is None
                or referenced["resulting_lifecycle_revision"]
                >= receipt["resulting_lifecycle_revision"]
                or referenced["action"] in {"recover", "migrate"}
                or target_receipt_id in recovered
            ):
                semantic_issues.append(
                    f"invalid_recovery_reference:{receipt['receipt_id']}"
                )
                continue
            recovered.add(target_receipt_id)

        effective_state = "current"
        current_eligible = True
        retrieval_eligible = True
        payload_visible = True
        successor = None
        retained_until = None
        migrations: list[str] = []
        for receipt in applicable_receipts:
            if receipt["action"] == "recover" or receipt["receipt_id"] in recovered:
                continue
            action = receipt["action"]
            if action == "invalidate":
                effective_state = "invalidated"
                current_eligible = False
                retrieval_eligible = False
            elif action == "supersede":
                effective_state = "superseded"
                current_eligible = False
                retrieval_eligible = False
                successor = receipt["successor_evidence_id"]
            elif action == "retain_until":
                retained_until = receipt["retain_until"]
                _, boundary = _timestamp(retained_until, field="retain_until")
                if as_of_time >= boundary:
                    effective_state = "retention_expired"
                    current_eligible = False
                    retrieval_eligible = False
                else:
                    effective_state = "retained"
            elif action == "deprecate":
                effective_state = "deprecated"
                current_eligible = False
                retrieval_eligible = False
            elif action == "redact_from_retrieval":
                effective_state = "retrieval_redacted"
                retrieval_eligible = False
                payload_visible = False
            elif action == "migrate":
                migrations.append(receipt["receipt_id"])

        if semantic_issues:
            current_eligible = False
            retrieval_eligible = False
        return {
            "status": "ok" if not semantic_issues else "review_needed",
            "evidence_id": evidence_id,
            "lifecycle_revision": (
                applicable_receipts[-1]["resulting_lifecycle_revision"]
                if applicable_receipts
                else 0
            ),
            "effective_state": effective_state,
            "current_eligible": current_eligible,
            "retrieval_eligible": retrieval_eligible,
            "payload_visible": payload_visible,
            "successor_evidence_id": successor,
            "retain_until": retained_until,
            "applied_receipt_ids": [
                receipt["receipt_id"] for receipt in applicable_receipts
            ],
            "recovered_receipt_ids": sorted(recovered),
            "migration_receipt_ids": migrations,
            "as_of": as_of,
            "issues": list(dict.fromkeys(semantic_issues)),
        }

    def _resolve_one(self, evidence_id: str, *, as_of: str) -> dict[str, Any]:
        exact = self._evidence_store.verify(evidence_id)
        if exact["status"] != "ok":
            return {
                "status": "not_found" if exact["status"] == "not_found" else "invalid",
                "evidence_id": evidence_id,
                "lifecycle_revision": 0,
                "effective_state": "unavailable",
                "current_eligible": False,
                "retrieval_eligible": False,
                "payload_visible": False,
                "successor_evidence_id": None,
                "retain_until": None,
                "applied_receipt_ids": [],
                "recovered_receipt_ids": [],
                "migration_receipt_ids": [],
                "as_of": as_of,
                "issues": list(exact.get("issues", [])),
            }
        receipts, issues = self._valid_receipts_for_target(evidence_id)
        return self._derive_effective_view(
            evidence_id,
            receipts,
            as_of=as_of,
            issues=issues,
        )

    def resolve(
        self,
        evidence_id: str,
        *,
        as_of: str | None = None,
    ) -> dict[str, Any]:
        normalized_id = normalized_text(
            evidence_id,
            field="lifecycle_target_evidence_id",
            maximum=64,
        )
        if SAFE_EVIDENCE_ID.fullmatch(normalized_id) is None:
            raise ValueError("codex_project_evidence_lifecycle_target_id_invalid")
        selected_as_of, _ = _timestamp(as_of or _now(), field="as_of")
        return self._resolve_one(normalized_id, as_of=selected_as_of)

    def resolve_all(self, *, as_of: str | None = None) -> dict[str, Any]:
        selected_as_of, _ = _timestamp(as_of or _now(), field="as_of")
        observed = evidence_inventory(self._evidence_store)
        views = {
            result["evidence"]["evidence_id"]: self._resolve_one(
                result["evidence"]["evidence_id"],
                as_of=selected_as_of,
            )
            for result in observed["valid"]
        }
        cycle_members = self._successor_cycle_members(views)
        for evidence_id in cycle_members:
            view = views[evidence_id]
            view["status"] = "review_needed"
            view["current_eligible"] = False
            view["retrieval_eligible"] = False
            view["issues"] = list(
                dict.fromkeys([*view["issues"], "successor_cycle"])
            )
        status = "ok"
        if (
            observed["skipped"]
            or observed["truncated"]
            or any(view["status"] != "ok" for view in views.values())
        ):
            status = "review_needed"
        return {
            "status": status,
            "project_id": self._project_id,
            "as_of": selected_as_of,
            "lifecycle_inventory_sha256": self.inventory_sha256(),
            "views": {key: views[key] for key in sorted(views)},
            "skipped_invalid_evidence_ids": sorted(observed["skipped"]),
            "scan_truncated": observed["truncated"],
            "non_claims": [
                "effective_view_is_not_evidence_mutation_or_deletion",
                "effective_view_is_not_memory_promotion_or_human_acceptance",
                "effective_view_grants_no_gate_release_production_or_live_authority",
            ],
        }

    @staticmethod
    def _successor_cycle_members(
        views: Mapping[str, Mapping[str, Any]],
    ) -> set[str]:
        successor = {
            evidence_id: view["successor_evidence_id"]
            for evidence_id, view in views.items()
            if view.get("successor_evidence_id") in views
        }
        cycle_members: set[str] = set()
        completed: set[str] = set()
        for start in sorted(successor):
            if start in completed:
                continue
            path: list[str] = []
            positions: dict[str, int] = {}
            current = start
            while current in successor and current not in completed:
                if current in positions:
                    cycle_members.update(path[positions[current] :])
                    break
                positions[current] = len(path)
                path.append(current)
                current = successor[current]
            completed.update(path)
        return cycle_members
