"""Small project-local memory store for explicit development promotion."""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
from typing import Any, Mapping, Sequence
import uuid


DEVELOPMENT_PROJECT_MEMORY_RELATIVE_PATH = Path(
    ".ai_dev_os/development/project_memory"
)
_SAFE_ID = re.compile(r"[A-Za-z0-9_-]+")
_SAFE_MEMORY_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,199}")
_SAFE_EVIDENCE_ID = re.compile(r"dev-evidence-[0-9a-f]{24}")
_MAX_TITLE_CHARS = 200
_MAX_CONTENT_CHARS = 16_384
_MAX_TAGS = 8
_MAX_TAG_CHARS = 64
_MAX_QUERY_CHARS = 500
_MAX_RESULT_LIMIT = 20
_MAX_SCAN_FILES = 200


def _normalized_text(value: Any, *, field: str, maximum: int) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"codex_project_memory_{field}_required")
    normalized = value.strip()
    if len(normalized) > maximum:
        raise ValueError(f"codex_project_memory_{field}_too_long")
    return normalized


def _normalized_tags(value: Sequence[str]) -> list[str]:
    if (
        not isinstance(value, Sequence)
        or isinstance(value, (str, bytes))
        or len(value) > _MAX_TAGS
    ):
        raise ValueError("codex_project_memory_tags_invalid")
    normalized: list[str] = []
    for item in value:
        tag = _normalized_text(
            item, field="tag", maximum=_MAX_TAG_CHARS,
        )
        if tag not in normalized:
            normalized.append(tag)
    return normalized


class DevelopmentProjectMemoryStore:
    """Persist immutable selected memories below one game project."""

    def __init__(
        self, project_root: str | Path, *, project_id: str,
    ) -> None:
        self._project_root = Path(project_root).resolve()
        self._project_id = _normalized_text(
            project_id, field="project_id", maximum=200,
        )
        self._root = (
            self._project_root / DEVELOPMENT_PROJECT_MEMORY_RELATIVE_PATH
        )

    def _validate_root(self, *, create: bool) -> bool:
        cursor = self._project_root
        for part in DEVELOPMENT_PROJECT_MEMORY_RELATIVE_PATH.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                raise ValueError("codex_project_memory_symlink_rejected")
        if not self._root.exists():
            if not create:
                return False
            self._root.mkdir(parents=True, exist_ok=True)
        if not self._root.is_dir():
            raise ValueError("codex_project_memory_root_not_directory")
        resolved = self._root.resolve()
        if self._project_root not in resolved.parents:
            raise ValueError("codex_project_memory_path_escape")
        return True

    def _write_record(
        self, *, memory_id: str, record: Mapping[str, Any],
    ) -> dict[str, Any]:
        if _SAFE_MEMORY_ID.fullmatch(memory_id) is None:
            raise ValueError("codex_project_memory_id_invalid")
        serialized = (
            json.dumps(
                record, ensure_ascii=False, indent=2, sort_keys=True,
            )
            + "\n"
        ).encode("utf-8")
        self._validate_root(create=True)
        target = self._root / f"{memory_id}.json"
        lock_path = self._root / ".promotion.lock"
        with lock_path.open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            if target.exists():
                if target.is_symlink():
                    raise ValueError(
                        "codex_project_memory_existing_symlink_rejected"
                    )
                try:
                    existing = target.read_bytes()
                except OSError as error:
                    raise ValueError(
                        "codex_project_memory_existing_unreadable"
                    ) from error
                if existing == serialized:
                    status = "already_promoted"
                else:
                    raise ValueError("codex_project_memory_already_promoted")
            else:
                temporary = (
                    self._root / f".{memory_id}.{uuid.uuid4().hex}.tmp"
                )
                try:
                    with temporary.open("xb") as output:
                        output.write(serialized)
                        output.flush()
                        os.fsync(output.fileno())
                    os.replace(temporary, target)
                finally:
                    if temporary.exists():
                        temporary.unlink()
                status = "promoted"
        return {
            "status": status,
            "memory": dict(record),
            "relative_path": target.relative_to(
                self._project_root,
            ).as_posix(),
        }

    @staticmethod
    def _source_identity(
        completion_summary: Mapping[str, Any],
    ) -> tuple[str, str, int]:
        if (
            completion_summary.get("summary_type")
            != "development_completion_summary"
            or completion_summary.get("format_version") != 1
            or completion_summary.get("scope")
            != "project_local_development"
        ):
            raise ValueError("codex_project_memory_summary_invalid")
        task = completion_summary.get("task")
        if not isinstance(task, Mapping) or task.get("state") != "CLOSED":
            raise ValueError("codex_project_memory_source_not_closed")
        project_id = task.get("project_id")
        task_id = task.get("object_id")
        revision = task.get("revision")
        if (
            not isinstance(project_id, str)
            or not project_id
            or not isinstance(task_id, str)
            or _SAFE_ID.fullmatch(task_id) is None
            or isinstance(revision, bool)
            or not isinstance(revision, int)
            or revision < 1
        ):
            raise ValueError("codex_project_memory_source_identity_invalid")
        return project_id, task_id, revision

    def promote(
        self, completion_summary: Mapping[str, Any], *, actor_id: str,
        title: str, content: str, tags: Sequence[str] = (),
    ) -> dict[str, Any]:
        """Promote one selected closed-task summary; never auto-capture."""
        project_id, task_id, revision = self._source_identity(
            completion_summary,
        )
        if project_id != self._project_id:
            raise ValueError("codex_project_memory_project_mismatch")
        actor = _normalized_text(
            actor_id, field="actor_id", maximum=200,
        )
        memory_title = _normalized_text(
            title, field="title", maximum=_MAX_TITLE_CHARS,
        )
        memory_content = _normalized_text(
            content, field="content", maximum=_MAX_CONTENT_CHARS,
        )
        memory_tags = _normalized_tags(tags)
        memory_id = f"completion-{task_id}-r{revision}"
        record = {
            "record_type": "development_project_memory",
            "format_version": 1,
            "memory_id": memory_id,
            "project_id": project_id,
            "title": memory_title,
            "content": memory_content,
            "tags": memory_tags,
            "promoted_by": actor,
            "source": {
                "task_id": task_id,
                "task_revision": revision,
                "completion_summary": dict(completion_summary),
            },
            "limitations": [
                "project_local_development",
                "explicit_promotion_only",
                "not_global_ltm",
                "not_qualification_gate_or_release",
            ],
        }
        return self._write_record(memory_id=memory_id, record=record)

    def promote_from_evidence(
        self,
        evidence_refs: Sequence[str],
        *,
        actor_id: str,
        title: str,
        content: str,
        tags: Sequence[str] = (),
    ) -> dict[str, Any]:
        """Explicitly promote one same-task set of verified evidence."""
        if isinstance(evidence_refs, (str, bytes)) or not isinstance(
            evidence_refs, Sequence,
        ):
            raise ValueError("codex_project_memory_evidence_refs_invalid")
        normalized_refs = sorted(dict.fromkeys(
            _normalized_text(
                value, field="evidence_ref", maximum=64,
            )
            for value in evidence_refs
        ))
        if not normalized_refs:
            raise ValueError("codex_project_memory_evidence_refs_required")
        if any(
            _SAFE_EVIDENCE_ID.fullmatch(value) is None
            for value in normalized_refs
        ):
            raise ValueError("codex_project_memory_evidence_ref_invalid")

        from adapters.codex.development_project_evidence import (  # noqa: WPS433
            DevelopmentProjectEvidenceStore,
        )

        evidence_store = DevelopmentProjectEvidenceStore(
            self._project_root, project_id=self._project_id,
        )
        evidence_lifecycle = evidence_store.lifecycle_store()
        task_ids: set[str] = set()
        source_revisions: set[str] = set()
        for evidence_id in normalized_refs:
            result = evidence_store.verify(evidence_id)
            if result["status"] != "ok":
                raise ValueError(
                    "codex_project_memory_evidence_invalid:"
                    f"{evidence_id}"
                )
            evidence = result["evidence"]
            if evidence["verification_status"] != "verified":
                raise ValueError(
                    "codex_project_memory_evidence_unverified:"
                    f"{evidence_id}"
                )
            effective = evidence_lifecycle.resolve(evidence_id)
            if (
                effective["status"] != "ok"
                or not effective["retrieval_eligible"]
            ):
                raise ValueError(
                    "codex_project_memory_evidence_lifecycle_ineligible:"
                    f"{evidence_id}"
                )
            task_ids.add(evidence["task_id"])
            source_revisions.add(evidence["source_revision"])
        if len(task_ids) != 1 or len(source_revisions) != 1:
            raise ValueError(
                "codex_project_memory_evidence_identity_mismatch"
            )

        actor = _normalized_text(
            actor_id, field="actor_id", maximum=200,
        )
        memory_title = _normalized_text(
            title, field="title", maximum=_MAX_TITLE_CHARS,
        )
        memory_content = _normalized_text(
            content, field="content", maximum=_MAX_CONTENT_CHARS,
        )
        memory_tags = _normalized_tags(tags)
        identity = json.dumps(
            normalized_refs,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
        memory_id = "evidence-" + hashlib.sha256(identity).hexdigest()[:24]
        record = {
            "record_type": "development_project_memory",
            "format_version": 2,
            "memory_id": memory_id,
            "project_id": self._project_id,
            "title": memory_title,
            "content": memory_content,
            "tags": memory_tags,
            "promoted_by": actor,
            "source": {
                "task_id": next(iter(task_ids)),
                "source_revision": next(iter(source_revisions)),
                "evidence_refs": normalized_refs,
            },
            "limitations": [
                "project_local_development",
                "explicit_promotion_only",
                "evidence_linked",
                "not_global_ltm",
                "not_qualification_gate_or_release",
            ],
        }
        return self._write_record(memory_id=memory_id, record=record)

    @staticmethod
    def _searchable_record(value: Any, *, project_id: str) -> bool:
        if not isinstance(value, Mapping):
            return False
        tags = value.get("tags")
        return bool(
            value.get("record_type") == "development_project_memory"
            and value.get("format_version") in {1, 2}
            and value.get("project_id") == project_id
            and isinstance(value.get("memory_id"), str)
            and isinstance(value.get("title"), str)
            and isinstance(value.get("content"), str)
            and isinstance(tags, list)
            and all(isinstance(tag, str) for tag in tags)
            and (
                value.get("format_version") == 1
                or (
                    isinstance(value.get("source"), Mapping)
                    and isinstance(
                        value.get("source", {}).get("evidence_refs"), list,
                    )
                    and bool(value.get("source", {}).get("evidence_refs"))
                    and all(
                        isinstance(ref, str)
                        and _SAFE_EVIDENCE_ID.fullmatch(ref) is not None
                        for ref in value.get("source", {}).get(
                            "evidence_refs", []
                        )
                    )
                )
            )
        )

    def get(self, memory_id: str) -> dict[str, Any]:
        """Read one selected memory by stable ID without searching."""
        normalized_id = _normalized_text(
            memory_id, field="memory_id", maximum=200,
        )
        if _SAFE_MEMORY_ID.fullmatch(normalized_id) is None:
            raise ValueError("codex_project_memory_id_invalid")
        response: dict[str, Any] = {
            "status": "not_found",
            "memory_id": normalized_id,
            "relative_path": None,
            "memory": None,
            "issues": [],
        }
        if not self._validate_root(create=False):
            return response
        target = self._root / f"{normalized_id}.json"
        if not target.exists():
            return response
        response["relative_path"] = target.relative_to(
            self._project_root,
        ).as_posix()
        if target.is_symlink():
            response["status"] = "invalid"
            response["issues"] = ["memory_symlink_rejected"]
            return response
        try:
            value = json.loads(target.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            response["status"] = "invalid"
            response["issues"] = ["memory_unreadable"]
            return response
        response["memory"] = value
        if (
            not self._searchable_record(value, project_id=self._project_id)
            or value.get("memory_id") != normalized_id
        ):
            response["status"] = "invalid"
            response["issues"] = ["memory_shape_invalid"]
            return response
        response["status"] = "ok"
        return response

    def lifecycle_store(self) -> Any:
        """Return the append-only v4.96 lifecycle overlay."""

        from .development_project_memory_lifecycle import (
            DevelopmentProjectMemoryLifecycleStore,
        )

        return DevelopmentProjectMemoryLifecycleStore(self)

    def resolve_memory_lifecycle(
        self, memory_id: str, *, as_of: str | None = None,
    ) -> dict[str, Any]:
        """Resolve one current or explicit historical Memory view."""

        return self.lifecycle_store().resolve(memory_id, as_of=as_of)

    def resolve_all_memory_lifecycle(
        self, *, as_of: str | None = None,
    ) -> dict[str, Any]:
        """Resolve all Memory heads while isolating item-local defects."""

        return self.lifecycle_store().resolve_all(as_of=as_of)

    def search(
        self, query: str = "", *, tags: Sequence[str] = (), limit: int = 5,
    ) -> dict[str, Any]:
        """Search selected local memories without loading them implicitly."""
        if not isinstance(query, str):
            raise ValueError("codex_project_memory_query_invalid")
        normalized_query = query.strip()
        if len(normalized_query) > _MAX_QUERY_CHARS:
            raise ValueError("codex_project_memory_query_too_long")
        requested_tags = _normalized_tags(tags)
        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= _MAX_RESULT_LIMIT
        ):
            raise ValueError("codex_project_memory_limit_invalid")

        response: dict[str, Any] = {
            "status": "ok",
            "scope": "project_local_development",
            "query": normalized_query,
            "tags": requested_tags,
            "limit": limit,
            "scanned_files": 0,
            "scan_truncated": False,
            "skipped_invalid_files": [],
            "memories": [],
            "limitations": [
                "manual_query_only",
                "not_automatic_context_injection",
                "not_global_ltm",
            ],
        }
        if not self._validate_root(create=False):
            return response

        candidates = sorted(self._root.glob("*.json"))
        response["scan_truncated"] = len(candidates) > _MAX_SCAN_FILES
        candidates = candidates[:_MAX_SCAN_FILES]
        query_tokens = list(dict.fromkeys(
            token.casefold() for token in normalized_query.split() if token
        ))
        required_tags = {tag.casefold() for tag in requested_tags}
        matches: list[dict[str, Any]] = []
        skipped: list[str] = []
        for path in candidates:
            response["scanned_files"] += 1
            if path.is_symlink():
                skipped.append(path.name)
                continue
            try:
                record = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, UnicodeError, json.JSONDecodeError):
                skipped.append(path.name)
                continue
            if not self._searchable_record(
                record, project_id=self._project_id,
            ):
                skipped.append(path.name)
                continue
            record_tags = {tag.casefold() for tag in record["tags"]}
            if not required_tags.issubset(record_tags):
                continue
            title = record["title"].casefold()
            searchable = " ".join((
                title,
                record["content"].casefold(),
                " ".join(record_tags),
            ))
            matched_tokens = sum(
                token in searchable for token in query_tokens
            )
            if query_tokens and matched_tokens == 0:
                continue
            score = matched_tokens + len(required_tags)
            if normalized_query and normalized_query.casefold() in title:
                score += 2
            source = record.get("source")
            completion = (
                source.get("completion_summary")
                if isinstance(source, Mapping) else None
            )
            closed = (
                completion.get("closed")
                if isinstance(completion, Mapping) else None
            )
            closed_at = (
                closed.get("closed_at")
                if isinstance(closed, Mapping) else ""
            )
            matches.append({
                "score": score,
                "relative_path": path.relative_to(
                    self._project_root,
                ).as_posix(),
                "memory": record,
                "closed_at": closed_at if isinstance(closed_at, str) else "",
            })

        matches.sort(key=lambda item: item["memory"]["memory_id"])
        matches.sort(key=lambda item: item["closed_at"], reverse=True)
        matches.sort(key=lambda item: item["score"], reverse=True)
        for match in matches[:limit]:
            match.pop("closed_at", None)
        response["skipped_invalid_files"] = skipped
        response["memories"] = matches[:limit]
        return response
