"""Concrete Godot local-development profile for the neutral Production Cell.

This profile binds a clean committed Worker checkpoint, focused target-engine
feedback, the existing reproducible macOS development build, and independent
focused QA.  The neutral composition module neither imports nor interprets
these concrete details.

The implementation stage verifies an already committed Worker-bound source
checkpoint.  It deliberately does not claim that this deterministic profile
performed the host's implementation reasoning or Git commit.
"""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

from adapters.codex.godot_focused_qa import (
    GodotFocusedQaError,
    GodotFocusedQaRunner,
)
from adapters.codex.godot_development_build import DevelopmentBuildError
from adapters.codex.godot_execution_adapter import ProjectBoundaryError
from adapters.codex.production_cell_composition import (
    CompositionContractError,
    ProductionCellBackendOutcome,
    ProductionCellComposition,
    ProductionCellCompositionResult,
    ProductionCellContext,
    SelectedFeatureSpec,
    write_composition_receipt,
)
from adapters.codex.production_worker import (
    CodexProductionWorker,
    ProductionWorkerError,
)


PROFILE_ID = "godot_local_development_v1"
_COMMIT_PATTERN = re.compile(r"^[0-9a-f]{40}$")
_EXPECTED_STAGE_BINDINGS = {
    "implementation": (
        "godot_worker_committed_checkpoint_v1",
        "adapters/codex/production_worker.py",
    ),
    "target_feedback": (
        "godot_target_feedback_v1",
        "adapters/codex/godot_execution_adapter.py",
    ),
    "development_build": (
        "godot_macos_development_build_v1",
        "adapters/codex/godot_development_build.py",
    ),
    "focused_qa": (
        "godot_focused_qa_v1",
        "adapters/codex/godot_focused_qa.py",
    ),
}


class GodotLocalDevelopmentProfileError(RuntimeError):
    """Raised for invalid profile bindings, configuration, or boundaries."""


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _required_text(value: str, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise GodotLocalDevelopmentProfileError(
            f"{label} must be a non-empty string"
        )
    if "\x00" in value:
        raise GodotLocalDevelopmentProfileError(f"{label} contains a NUL byte")
    return value.strip()


def _read_json_object(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise GodotLocalDevelopmentProfileError(f"missing {label}: {path}") from exc
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise GodotLocalDevelopmentProfileError(
            f"invalid {label}: {path}: {exc}"
        ) from exc
    if not isinstance(value, dict):
        raise GodotLocalDevelopmentProfileError(
            f"{label} must be a JSON object: {path}"
        )
    return value


def _git(
    project_root: Path,
    *arguments: str,
    require_success: bool = True,
) -> subprocess.CompletedProcess[str]:
    try:
        result = subprocess.run(
            ["git", "-C", str(project_root), *arguments],
            check=False,
            capture_output=True,
            text=True,
            timeout=15,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise GodotLocalDevelopmentProfileError(
            f"Git source inspection failed: {exc}"
        ) from exc
    if require_success and result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        raise GodotLocalDevelopmentProfileError(
            f"Git source inspection failed ({result.returncode}): {detail}"
        )
    return result


def _source_identity(project_root: Path) -> dict[str, Any]:
    repository_root = Path(
        _git(project_root, "rev-parse", "--show-toplevel").stdout.strip()
    ).resolve(strict=True)
    try:
        project_root.relative_to(repository_root)
    except ValueError as exc:
        raise GodotLocalDevelopmentProfileError(
            "selected project is outside its resolved Git repository"
        ) from exc
    status = _git(
        project_root,
        "status",
        "--porcelain=v1",
        "--untracked-files=all",
    )
    diff_check = _git(project_root, "diff", "--check", require_success=False)
    return {
        "repository_root": str(repository_root),
        "project_root": str(project_root),
        "head": _git(project_root, "rev-parse", "HEAD").stdout.strip(),
        "tree": _git(project_root, "rev-parse", "HEAD^{tree}").stdout.strip(),
        "status_porcelain": status.stdout,
        "status_exit_code": status.returncode,
        "diff_check_stdout": diff_check.stdout,
        "diff_check_stderr": diff_check.stderr,
        "diff_check_exit_code": diff_check.returncode,
    }


def _clean_source(identity: dict[str, Any]) -> bool:
    return (
        identity["status_exit_code"] == 0
        and identity["status_porcelain"] == ""
        and identity["diff_check_exit_code"] == 0
    )


@dataclass(frozen=True)
class GodotFeedbackCheck:
    operation: str
    resource_path: str | None = None
    pass_token: str | None = None

    def __post_init__(self) -> None:
        if self.operation not in {"project_load", "script", "scene"}:
            raise GodotLocalDevelopmentProfileError(
                f"unsupported Godot feedback operation: {self.operation!r}"
            )
        if self.operation == "project_load":
            if self.resource_path is not None or self.pass_token is not None:
                raise GodotLocalDevelopmentProfileError(
                    "project_load feedback takes no resource_path or pass_token"
                )
            return
        if self.resource_path is None:
            raise GodotLocalDevelopmentProfileError(
                f"{self.operation} feedback requires resource_path"
            )
        object.__setattr__(
            self,
            "resource_path",
            _required_text(self.resource_path, "feedback resource_path"),
        )
        if self.pass_token is not None:
            object.__setattr__(
                self,
                "pass_token",
                _required_text(self.pass_token, "feedback pass_token"),
            )


class GodotCommittedImplementationBackend:
    stage_id = "implementation"
    backend_id = "godot_worker_committed_checkpoint_v1"

    def __init__(
        self,
        *,
        worker: CodexProductionWorker,
        expected_commit: str,
        evidence_refs: Sequence[str],
    ) -> None:
        if not isinstance(worker, CodexProductionWorker):
            raise GodotLocalDevelopmentProfileError(
                "implementation backend requires CodexProductionWorker"
            )
        commit = _required_text(expected_commit, "expected_commit").lower()
        if not _COMMIT_PATTERN.fullmatch(commit):
            raise GodotLocalDevelopmentProfileError(
                "expected_commit must be one exact 40-character Git commit"
            )
        refs = tuple(
            _required_text(value, "implementation evidence ref")
            for value in evidence_refs
        )
        if not refs or len(set(refs)) != len(refs):
            raise GodotLocalDevelopmentProfileError(
                "implementation evidence_refs must be non-empty and unique"
            )
        self.worker = worker
        self.expected_commit = commit
        self.evidence_refs = refs

    def run(self, context: ProductionCellContext) -> ProductionCellBackendOutcome:
        if context.feature_spec.task_id != self.worker.task_id:
            raise CompositionContractError(
                "selected feature task_id does not match Production Worker"
            )
        preflight = self.worker.preflight()
        identity = _source_identity(self.worker.project_root)
        expected = context.feature_spec.expected_source_revision
        mismatch = (
            preflight.get("status") != "ready"
            or not _clean_source(identity)
            or identity["head"] != self.expected_commit
            or (expected is not None and expected != self.expected_commit)
        )
        if mismatch:
            return ProductionCellBackendOutcome(
                status="blocked",
                artifact_type="production_worker_committed_checkpoint",
                facts={
                    "mode": "verify_existing_committed_implementation",
                    "expected_commit": self.expected_commit,
                    "worker_preflight": preflight,
                    "source_identity": identity,
                },
                evidence_refs=self.evidence_refs,
                failure_kind="implementation_checkpoint_mismatch",
                failure_owner="godot_runtime_slice_engineer",
                next_action="repair_or_select_the_exact_clean_committed_source",
            )
        return ProductionCellBackendOutcome(
            status="succeeded",
            artifact_type="production_worker_committed_checkpoint",
            facts={
                "mode": "verify_existing_committed_implementation",
                "expected_commit": self.expected_commit,
                "worker_preflight": preflight,
                "source_identity": identity,
                "non_claims": [
                    "checkpoint_does_not_claim_the_profile_authored_source",
                    "checkpoint_is_not_human_acceptance_or_gate_authority",
                ],
            },
            evidence_refs=self.evidence_refs,
        )


class GodotTargetFeedbackBackend:
    stage_id = "target_feedback"
    backend_id = "godot_target_feedback_v1"

    def __init__(
        self,
        *,
        worker: CodexProductionWorker,
        checks: Sequence[GodotFeedbackCheck],
    ) -> None:
        if not isinstance(worker, CodexProductionWorker):
            raise GodotLocalDevelopmentProfileError(
                "feedback backend requires CodexProductionWorker"
            )
        if not checks or not all(isinstance(item, GodotFeedbackCheck) for item in checks):
            raise GodotLocalDevelopmentProfileError(
                "feedback checks must contain at least one GodotFeedbackCheck"
            )
        self.worker = worker
        self.checks = tuple(checks)

    def run(self, context: ProductionCellContext) -> ProductionCellBackendOutcome:
        if context.feature_spec.task_id != self.worker.task_id:
            raise CompositionContractError(
                "selected feature task_id does not match feedback Worker"
            )
        results = []
        for check in self.checks:
            if check.operation == "project_load":
                result = self.worker.run_project_load()
            elif check.operation == "script":
                result = self.worker.run_script(
                    check.resource_path or "",
                    expected_pass_token=check.pass_token,
                )
            else:
                result = self.worker.run_scene(
                    check.resource_path or "",
                    expected_pass_token=check.pass_token,
                )
            results.append(result)

        failed = [result for result in results if result.status != "pass"]
        if any(result.status == "timeout" for result in failed):
            status = "blocked"
            failure_kind = "target_feedback_timeout"
        elif failed:
            status = "review_needed"
            failure_kind = "target_feedback_failed"
        else:
            status = "succeeded"
            failure_kind = None
        return ProductionCellBackendOutcome(
            status=status,
            artifact_type="godot_feedback_result",
            facts={
                "check_count": len(results),
                "failed_check_count": len(failed),
                "checks": [result.to_dict() for result in results],
            },
            failure_kind=failure_kind,
            failure_owner=(
                None if status == "succeeded" else "godot_runtime_slice_engineer"
            ),
            next_action=(
                None if status == "succeeded" else "return_feedback_to_same_feature_attempt"
            ),
        )


class GodotDevelopmentBuildBackend:
    stage_id = "development_build"
    backend_id = "godot_macos_development_build_v1"

    def __init__(
        self,
        *,
        worker: CodexProductionWorker,
        preset_name: str,
        artifact_name: str,
        quit_after: int,
    ) -> None:
        if not isinstance(worker, CodexProductionWorker):
            raise GodotLocalDevelopmentProfileError(
                "build backend requires CodexProductionWorker"
            )
        self.worker = worker
        self.preset_name = _required_text(preset_name, "preset_name")
        self.artifact_name = _required_text(artifact_name, "artifact_name")
        if not isinstance(quit_after, int) or isinstance(quit_after, bool) or quit_after < 1:
            raise GodotLocalDevelopmentProfileError(
                "quit_after must be an integer >= 1"
            )
        self.quit_after = quit_after

    def run(self, context: ProductionCellContext) -> ProductionCellBackendOutcome:
        if context.feature_spec.task_id != self.worker.task_id:
            raise CompositionContractError(
                "selected feature task_id does not match build Worker"
            )
        try:
            delivery = self.worker.build_macos_development(
                preset_name=self.preset_name,
                artifact_name=self.artifact_name,
                quit_after=self.quit_after,
            )
        except (
            DevelopmentBuildError,
            ProductionWorkerError,
            ProjectBoundaryError,
        ) as exc:
            return ProductionCellBackendOutcome(
                status="blocked",
                artifact_type="godot_development_build_delivery",
                facts={"error_type": type(exc).__name__, "message": str(exc)},
                failure_kind="development_build_boundary_error",
                failure_owner="godot_runtime_slice_engineer",
                next_action="repair_build_configuration_or_source_boundary",
            )
        status = "succeeded" if delivery.status == "delivered" else "failed"
        evidence_refs = (
            (delivery.receipt_path,)
            if delivery.receipt_path and Path(delivery.receipt_path).is_file()
            else ()
        )
        return ProductionCellBackendOutcome(
            status=status,
            artifact_type="godot_development_build_delivery",
            facts=delivery.to_dict(),
            evidence_refs=evidence_refs,
            failure_kind=(None if status == "succeeded" else delivery.failure_kind),
            failure_owner=(
                None if status == "succeeded" else "godot_runtime_slice_engineer"
            ),
            next_action=(
                None if status == "succeeded" else "repair_or_reconfigure_development_build"
            ),
        )


class GodotFocusedQaBackend:
    stage_id = "focused_qa"
    backend_id = "godot_focused_qa_v1"

    def __init__(self, *, runner: GodotFocusedQaRunner) -> None:
        if not isinstance(runner, GodotFocusedQaRunner):
            raise GodotLocalDevelopmentProfileError(
                "QA backend requires GodotFocusedQaRunner"
            )
        self.runner = runner

    def run(self, context: ProductionCellContext) -> ProductionCellBackendOutcome:
        if context.feature_spec.task_id != self.runner.task_id:
            raise CompositionContractError(
                "selected feature task_id does not match focused-QA runner"
            )
        try:
            result = self.runner.run()
        except (GodotFocusedQaError, ProjectBoundaryError) as exc:
            return ProductionCellBackendOutcome(
                status="blocked",
                artifact_type="godot_focused_qa_run",
                facts={"error_type": type(exc).__name__, "message": str(exc)},
                failure_kind="focused_qa_boundary_error",
                failure_owner=self.runner.failure_owner,
                next_action=self.runner.next_skill_route,
            )
        status = {
            "DONE": "succeeded",
            "REVIEW_NEEDED": "review_needed",
            "BLOCKED": "blocked",
            "DEFER": "review_needed",
        }.get(result.verdict, "failed")
        return ProductionCellBackendOutcome(
            status=status,
            artifact_type="godot_focused_qa_run",
            facts=result.to_dict(),
            evidence_refs=(result.evidence_bundle_path,),
            failure_kind=(None if status == "succeeded" else "focused_qa_not_done"),
            failure_owner=(None if status == "succeeded" else self.runner.failure_owner),
            next_action=(None if status == "succeeded" else self.runner.next_skill_route),
        )


@dataclass(frozen=True)
class GodotLocalDevelopmentRunResult:
    composition: ProductionCellCompositionResult
    receipt_path: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": "1.0.0",
            "artifact_type": "godot_local_development_profile_run",
            "status": self.composition.status,
            "profile_id": self.composition.profile_id,
            "composition_run_id": self.composition.run_id,
            "receipt_path": self.receipt_path,
            "composition_result": self.composition.to_dict(),
            "non_claims": [
                "profile_run_is_not_human_experience_acceptance",
                "profile_run_is_not_qualification_gate_release_or_live_authority",
                "godot_profile_does_not_claim_cross_engine_support",
            ],
        }


class GodotLocalDevelopmentProfile:
    """Bind and execute one concrete Godot profile over the neutral core."""

    def __init__(
        self,
        *,
        worker: CodexProductionWorker,
        qa_runner: GodotFocusedQaRunner,
        expected_commit: str,
        implementation_evidence_refs: Sequence[str],
        feedback_checks: Sequence[GodotFeedbackCheck],
        build_preset_name: str,
        build_artifact_name: str,
        build_quit_after: int,
        profile_binding_path: str | Path,
        profile_binding_schema_path: str | Path,
        composition_result_schema_path: str | Path,
    ) -> None:
        if not isinstance(worker, CodexProductionWorker):
            raise GodotLocalDevelopmentProfileError(
                "profile requires CodexProductionWorker"
            )
        if not isinstance(qa_runner, GodotFocusedQaRunner):
            raise GodotLocalDevelopmentProfileError(
                "profile requires GodotFocusedQaRunner"
            )
        if worker.project_root != qa_runner.project_root:
            raise GodotLocalDevelopmentProfileError(
                "Worker and focused-QA runner must select the same project"
            )
        if worker.task_id != qa_runner.task_id:
            raise GodotLocalDevelopmentProfileError(
                "Worker and focused-QA runner must select the same task"
            )
        self.worker = worker
        self.qa_runner = qa_runner
        self.project_root = worker.project_root
        self.profile_binding_path = Path(profile_binding_path).resolve(strict=True)
        self.profile_binding_schema_path = Path(
            profile_binding_schema_path
        ).resolve(strict=True)
        self.composition_result_schema_path = Path(
            composition_result_schema_path
        ).resolve(strict=True)
        self.profile_binding = self._validate_profile_binding()
        self.profile_id = str(self.profile_binding["profile_id"])
        self.binding_id = str(self.profile_binding["binding_id"])
        self.binding_sha256 = _sha256_file(self.profile_binding_path)

        self.backends = (
            GodotCommittedImplementationBackend(
                worker=worker,
                expected_commit=expected_commit,
                evidence_refs=implementation_evidence_refs,
            ),
            GodotTargetFeedbackBackend(worker=worker, checks=feedback_checks),
            GodotDevelopmentBuildBackend(
                worker=worker,
                preset_name=build_preset_name,
                artifact_name=build_artifact_name,
                quit_after=build_quit_after,
            ),
            GodotFocusedQaBackend(runner=qa_runner),
        )
        self.composition = ProductionCellComposition(
            profile_id=self.profile_id,
            profile_binding_id=self.binding_id,
            profile_binding_sha256=self.binding_sha256,
            backends=self.backends,
        )

    def _validate_profile_binding(self) -> dict[str, Any]:
        binding = _read_json_object(
            self.profile_binding_path,
            "Production Cell profile binding",
        )
        schema = _read_json_object(
            self.profile_binding_schema_path,
            "Production Cell profile binding schema",
        )
        try:
            import jsonschema
        except ImportError as exc:
            raise GodotLocalDevelopmentProfileError(
                "jsonschema is required to validate the profile binding"
            ) from exc
        try:
            jsonschema.Draft7Validator(schema).validate(binding)
        except jsonschema.ValidationError as exc:
            raise GodotLocalDevelopmentProfileError(
                f"Godot local-development profile binding is invalid: {exc.message}"
            ) from exc
        if binding.get("profile_id") != PROFILE_ID or binding.get("engine_id") != "godot":
            raise GodotLocalDevelopmentProfileError(
                "profile binding does not identify Godot local development v1"
            )
        if binding.get("profile_api") != (
            "adapters/codex/godot_local_development_profile.py"
        ):
            raise GodotLocalDevelopmentProfileError(
                "profile binding names an unsupported concrete profile API"
            )
        version_root = self.profile_binding_path.parents[3]
        schema_reference = binding.get("composition_result_schema")
        if not isinstance(schema_reference, str) or (
            version_root / schema_reference
        ).resolve(strict=True) != self.composition_result_schema_path:
            raise GodotLocalDevelopmentProfileError(
                "profile binding composition result schema does not match"
            )
        observed = {
            item.get("stage_id"): (
                item.get("backend_id"),
                item.get("backend_api"),
            )
            for item in binding.get("stage_bindings", [])
            if isinstance(item, dict)
        }
        if observed != _EXPECTED_STAGE_BINDINGS:
            raise GodotLocalDevelopmentProfileError(
                "profile binding stage backends do not match the implemented profile"
            )
        return binding

    def _resolve_receipt_path(self, raw_path: str | Path) -> Path:
        candidate = Path(raw_path)
        if not candidate.is_absolute() or "\x00" in str(candidate):
            raise GodotLocalDevelopmentProfileError(
                "composition receipt path must be absolute and safe"
            )
        parent = candidate.parent.resolve(strict=True)
        repository_root = Path(
            _git(self.project_root, "rev-parse", "--show-toplevel").stdout.strip()
        ).resolve(strict=True)
        final_path = parent / candidate.name
        try:
            final_path.relative_to(repository_root)
        except ValueError:
            return final_path
        raise GodotLocalDevelopmentProfileError(
            "composition receipt must stay outside the source repository"
        )

    def run(
        self,
        *,
        feature_spec: SelectedFeatureSpec,
        receipt_path: str | Path,
    ) -> GodotLocalDevelopmentRunResult:
        if feature_spec.target_profile_id != self.profile_id:
            raise GodotLocalDevelopmentProfileError(
                "selected feature targets a different Production Cell profile"
            )
        worker_writes = set(self.worker.execution.declared_write_patterns)
        selected_writes = {
            value[len("res://") :] if value.startswith("res://") else value
            for value in feature_spec.declared_write_surfaces
        }
        if selected_writes != worker_writes:
            raise GodotLocalDevelopmentProfileError(
                "selected feature write surfaces do not match the Worker envelope"
            )
        final_receipt = self._resolve_receipt_path(receipt_path)
        result = self.composition.run(feature_spec)
        written = write_composition_receipt(
            receipt_path=final_receipt,
            result=result,
            schema_path=self.composition_result_schema_path,
        )
        return GodotLocalDevelopmentRunResult(
            composition=result,
            receipt_path=str(written),
        )
