"""Local same-host reference implementation of the Team Memory Provider."""

from __future__ import annotations

import fcntl
import json
import os
from datetime import datetime, timezone
from pathlib import Path
import re
from typing import Any, Mapping, Sequence

from ._development_evidence_common import (
    atomic_write,
    canonical_bytes,
    normalized_evidence_ids,
    pretty_bytes,
    sha256_bytes,
)
from .development_project_evidence import DevelopmentProjectEvidenceStore
from .development_project_permissions import (
    ProjectPermissionPolicy,
    ProjectPrincipalContext,
)
from .team_memory_provider import (
    TEAM_MEMORY_PROVIDER_OPERATIONS,
    SAFE_SCOPE_ID,
    TeamMemoryProviderUnavailable,
)


PROVIDER_ID = "local-same-host-team-memory-v1"
PROVIDER_RELATIVE_PATH = Path(".ai_dev_os/team_memory_reference_provider")
SAFE_MEMORY_ID = re.compile(r"team-memory-[0-9a-f]{24}")
SAFE_EVENT_ID = re.compile(r"team-memory-event-[0-9a-f]{24}")
SAFE_MEMORY_KEY = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}")
MAX_RECORDS = 200
MAX_EVENTS = 100
MAX_QUERY_CHARS = 500
MAX_RESULTS = 20
RECORD_NON_CLAIMS = (
    "candidate_is_not_published_memory_or_automatic_context",
    "team_memory_is_advisory_and_source_linked",
    "record_grants_no_production_gate_release_or_live_authority",
    "reference_provider_proves_same_host_sharing_only",
)
EVENT_NON_CLAIMS = (
    "event_is_team_memory_data_not_human_acceptance_or_gate_evidence",
    "event_grants_no_production_release_or_live_authority",
)
ACTIVATION_NON_CLAIMS = (
    "activation_does_not_grant_review_publish_or_production_authority",
    "activation_grants_no_gate_release_or_live_authority",
    "reference_provider_proves_same_host_sharing_only",
)
ACTION_CAPABILITY = {
    "review": "team_memory_review",
    "publish": "team_memory_publish",
    "supersede": "team_memory_supersede",
    "invalidate": "team_memory_invalidate",
    "redact_from_retrieval": "team_memory_redact",
}


def _text(value: Any, *, field: str, maximum: int) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"codex_team_memory_{field}_required")
    normalized = value.strip()
    if len(normalized) > maximum:
        raise ValueError(f"codex_team_memory_{field}_too_long")
    return normalized


def _scope(value: str, *, field: str) -> str:
    normalized = _text(value, field=field, maximum=200)
    if SAFE_SCOPE_ID.fullmatch(normalized) is None:
        raise ValueError(f"codex_team_memory_{field}_invalid")
    return normalized


def _timestamp(value: str, *, field: str) -> str:
    normalized = _text(value, field=field, maximum=100)
    try:
        parsed = datetime.fromisoformat(normalized.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"codex_team_memory_{field}_invalid") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"codex_team_memory_{field}_timezone_required")
    return parsed.astimezone(timezone.utc).isoformat()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _digest(value: Mapping[str, Any], *, excluded: Sequence[str]) -> str:
    return sha256_bytes(
        canonical_bytes(
            {key: item for key, item in value.items() if key not in excluded}
        )
    )


class LocalSameHostTeamMemoryProvider:
    """Coordinator-owned, append-event Team Memory for one local host."""

    provider_id = PROVIDER_ID

    def __init__(self, coordinator_root: str | Path) -> None:
        root = Path(coordinator_root).resolve()
        if not root.is_dir():
            raise ValueError("codex_team_memory_coordinator_root_invalid")
        self._coordinator_root = root
        self.state_root = root / PROVIDER_RELATIVE_PATH

    def capabilities(self) -> dict[str, Any]:
        return {
            "status": "ok",
            "provider_id": self.provider_id,
            "provider_version": "1.0.0",
            "operations": list(TEAM_MEMORY_PROVIDER_OPERATIONS),
            "default_enabled": False,
            "sharing_scope": "same_host_only",
            "semantic_retrieval": False,
            "cross_machine_sync": False,
        }

    def health(self) -> dict[str, Any]:
        if not self._coordinator_root.is_dir():
            raise TeamMemoryProviderUnavailable("coordinator_root_unavailable")
        if self.state_root.is_symlink():
            raise TeamMemoryProviderUnavailable("provider_root_symlink_rejected")
        return {
            "status": "ok",
            "provider_id": self.provider_id,
            "team_memory_available": True,
            "same_host_only": True,
        }

    def _directory(self, relative: Path, *, create: bool) -> Path:
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("codex_team_memory_path_escape")
        cursor = self.state_root
        if cursor.is_symlink():
            raise ValueError("codex_team_memory_storage_symlink_rejected")
        for part in relative.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                raise ValueError("codex_team_memory_storage_symlink_rejected")
        if create:
            cursor.mkdir(parents=True, exist_ok=True)
        return cursor

    def _scope_directory(
        self, kind: str, project_id: str, team_id: str, *, create: bool,
    ) -> Path:
        project = _scope(project_id, field="project_id")
        team = _scope(team_id, field="team_id")
        return self._directory(Path(kind) / project / team, create=create)

    def _activation_path(
        self, project_id: str, team_id: str, *, create: bool,
    ) -> Path:
        directory = self._scope_directory(
            "activations", project_id, team_id, create=create
        )
        return directory / "activation.json"

    def activation_status(
        self,
        project_id: str,
        team_id: str,
        *,
        policy_revision: str | None = None,
    ) -> dict[str, Any]:
        target = self._activation_path(
            project_id, team_id, create=False
        )
        if not target.is_file():
            return {
                "status": "installed_not_enabled",
                "enabled": False,
                "binding": None,
                "issues": [],
            }
        if target.is_symlink():
            raise TeamMemoryProviderUnavailable("activation_symlink_rejected")
        try:
            value = json.loads(target.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise TeamMemoryProviderUnavailable(
                "activation_unreadable"
            ) from exc
        issues = self._activation_issues(
            value, project_id=project_id, team_id=team_id
        )
        if issues:
            return {
                "status": "activation_review_needed",
                "enabled": False,
                "binding": None,
                "issues": issues,
            }
        if policy_revision is not None and value[
            "permission_policy_revision"
        ] != policy_revision:
            return {
                "status": "policy_revision_mismatch",
                "enabled": False,
                "binding": dict(value),
                "issues": ["activation_policy_revision_mismatch"],
            }
        return {
            "status": "enabled" if value["enabled"] else "disabled",
            "enabled": value["enabled"],
            "binding": dict(value),
            "issues": [],
        }

    @staticmethod
    def _activation_issues(
        value: Any, *, project_id: str, team_id: str,
    ) -> list[str]:
        required = {
            "schema_version",
            "artifact_type",
            "provider_id",
            "project_id",
            "team_id",
            "enabled",
            "binding_revision",
            "permission_policy_revision",
            "actor_id",
            "principal_kind",
            "recorded_at",
            "content_sha256",
            "non_claims",
        }
        if not isinstance(value, Mapping):
            return ["activation_not_object"]
        issues = []
        if set(value) != required:
            issues.append("activation_fields_invalid")
        if value.get("schema_version") != "1.0.0":
            issues.append("activation_schema_invalid")
        if value.get("artifact_type") != "team_memory_activation_binding":
            issues.append("activation_artifact_type_invalid")
        if value.get("provider_id") != PROVIDER_ID:
            issues.append("activation_provider_mismatch")
        if value.get("project_id") != project_id:
            issues.append("activation_project_mismatch")
        if value.get("team_id") != team_id:
            issues.append("activation_team_mismatch")
        if not isinstance(value.get("enabled"), bool):
            issues.append("activation_enabled_invalid")
        revision = value.get("binding_revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or revision < 1
        ):
            issues.append("activation_revision_invalid")
        for field in (
            "permission_policy_revision", "actor_id", "principal_kind"
        ):
            if not isinstance(value.get(field), str) or not value.get(field):
                issues.append(f"activation_{field}_invalid")
        try:
            _timestamp(value.get("recorded_at"), field="recorded_at")
        except (TypeError, ValueError):
            issues.append("activation_recorded_at_invalid")
        if value.get("non_claims") != list(ACTIVATION_NON_CLAIMS):
            issues.append("activation_non_claims_invalid")
        if value.get("content_sha256") != _digest(
            value, excluded=("content_sha256",)
        ):
            issues.append("activation_content_hash_mismatch")
        return issues

    def _set_activation(
        self,
        project_id: str,
        team_id: str,
        *,
        enabled: bool,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        recorded_at: str | None,
    ) -> dict[str, Any]:
        project, team = self._require_scope(
            project_id, team_id, actor_context, permission_policy
        )
        permission_policy.require(actor_context, "team_memory_activate")
        target = self._activation_path(project, team, create=True)
        lock_path = target.parent / ".activation.lock"
        if lock_path.is_symlink():
            raise ValueError("codex_team_memory_activation_lock_symlink_rejected")
        with lock_path.open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            current = self.activation_status(project, team)
            if current["status"] == "activation_review_needed":
                raise ValueError(
                    "codex_team_memory_activation_review_needed"
                )
            binding = current.get("binding")
            revision = (
                binding["binding_revision"] + 1
                if isinstance(binding, Mapping)
                and isinstance(binding.get("binding_revision"), int)
                else 1
            )
            body = {
                "schema_version": "1.0.0",
                "artifact_type": "team_memory_activation_binding",
                "provider_id": self.provider_id,
                "project_id": project,
                "team_id": team,
                "enabled": enabled,
                "binding_revision": revision,
                "permission_policy_revision": permission_policy.policy_revision,
                "actor_id": actor_context.principal_id,
                "principal_kind": actor_context.principal_kind,
                "recorded_at": _timestamp(
                    recorded_at or _now(), field="recorded_at"
                ),
                "non_claims": list(ACTIVATION_NON_CLAIMS),
            }
            value = {**body, "content_sha256": _digest(body, excluded=())}
            atomic_write(target, pretty_bytes(value))
        return {
            "status": "enabled" if enabled else "disabled",
            "enabled_for_scope": enabled,
            "binding": value,
            "binding_ref": target.relative_to(
                self.state_root.parent
            ).as_posix(),
        }

    def activate(
        self,
        project_id: str,
        team_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        return self._set_activation(
            project_id,
            team_id,
            enabled=True,
            actor_context=actor_context,
            permission_policy=permission_policy,
            recorded_at=recorded_at,
        )

    def disable(
        self,
        project_id: str,
        team_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        return self._set_activation(
            project_id,
            team_id,
            enabled=False,
            actor_context=actor_context,
            permission_policy=permission_policy,
            recorded_at=recorded_at,
        )

    def _require_scope(
        self,
        project_id: str,
        team_id: str,
        context: ProjectPrincipalContext,
        policy: ProjectPermissionPolicy,
    ) -> tuple[str, str]:
        project = _scope(project_id, field="project_id")
        team = _scope(team_id, field="team_id")
        if (
            not isinstance(context, ProjectPrincipalContext)
            or not isinstance(policy, ProjectPermissionPolicy)
            or context.project_id != project
            or context.team_id != team
            or policy.project_id != project
        ):
            raise PermissionError("codex_project_permission_denied")
        return project, team

    def _require_enabled(
        self,
        project_id: str,
        team_id: str,
        context: ProjectPrincipalContext,
        policy: ProjectPermissionPolicy,
    ) -> tuple[str, str]:
        project, team = self._require_scope(
            project_id, team_id, context, policy
        )
        activation = self.activation_status(
            project,
            team,
            policy_revision=policy.policy_revision,
        )
        if not activation["enabled"]:
            raise TeamMemoryProviderUnavailable(
                f"team_memory_{activation['status']}"
            )
        return project, team

    @staticmethod
    def _tags(values: Sequence[str]) -> list[str]:
        if isinstance(values, (str, bytes)) or not isinstance(values, Sequence):
            raise ValueError("codex_team_memory_tags_invalid")
        result = []
        for value in values:
            tag = _text(value, field="tag", maximum=64)
            if tag not in result:
                result.append(tag)
        if len(result) > 8:
            raise ValueError("codex_team_memory_tags_too_many")
        return result

    def propose(
        self,
        project_root: str | Path,
        project_id: str,
        team_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        memory_key: str,
        title: str,
        content: str,
        source_evidence_ids: Sequence[str],
        tags: Sequence[str] = (),
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        project, team = self._require_enabled(
            project_id, team_id, actor_context, permission_policy
        )
        permission_policy.require(actor_context, "team_memory_propose")
        key = _text(memory_key, field="memory_key", maximum=200)
        if SAFE_MEMORY_KEY.fullmatch(key) is None:
            raise ValueError("codex_team_memory_memory_key_invalid")
        selected_title = _text(title, field="title", maximum=200)
        selected_content = _text(content, field="content", maximum=16_384)
        selected_tags = self._tags(tags)
        evidence_ids = normalized_evidence_ids(source_evidence_ids)
        if not evidence_ids:
            raise ValueError("codex_team_memory_source_evidence_required")
        source_rows = self._verified_evidence_rows(
            project_root,
            project,
            evidence_ids,
        )
        identity = {
            "project_id": project,
            "team_id": team,
            "memory_key": key,
            "title": selected_title,
            "content_sha256": sha256_bytes(selected_content.encode("utf-8")),
            "source_evidence": source_rows,
        }
        identity_sha256 = sha256_bytes(canonical_bytes(identity))
        memory_id = f"team-memory-{identity_sha256[:24]}"
        records = self._scope_directory(
            "records", project, team, create=True
        )
        target = records / f"{memory_id}.json"
        lock_path = records / ".records.lock"
        if lock_path.is_symlink():
            raise ValueError("codex_team_memory_records_lock_symlink_rejected")
        with lock_path.open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            if target.exists():
                existing = self._read_record(target, expected_memory_id=memory_id)
                if existing["identity_sha256"] != identity_sha256:
                    raise ValueError("codex_team_memory_record_conflict")
                status = "already_proposed"
                record = existing
            else:
                body = {
                    "schema_version": "1.0.0",
                    "artifact_type": "team_memory_candidate_record",
                    "provider_id": self.provider_id,
                    "memory_id": memory_id,
                    "identity_sha256": identity_sha256,
                    "project_id": project,
                    "team_id": team,
                    "memory_key": key,
                    "title": selected_title,
                    "content": selected_content,
                    "tags": selected_tags,
                    "source_evidence": source_rows,
                    "proposed_by": actor_context.principal_id,
                    "proposer_kind": actor_context.principal_kind,
                    "permission_policy_revision": (
                        permission_policy.policy_revision
                    ),
                    "proposed_at": _timestamp(
                        recorded_at or _now(), field="proposed_at"
                    ),
                    "initial_state": "candidate",
                    "non_claims": list(RECORD_NON_CLAIMS),
                }
                record = {
                    **body,
                    "record_sha256": _digest(body, excluded=()),
                }
                self._write_immutable(target, record)
                status = "proposed"
        return {
            "status": status,
            "memory": self._resolved_memory(record, project, team),
            "record_ref": target.relative_to(self.state_root.parent).as_posix(),
        }

    def _verified_evidence_rows(
        self,
        project_root: str | Path,
        project_id: str,
        evidence_ids: Sequence[str],
    ) -> list[dict[str, Any]]:
        store = DevelopmentProjectEvidenceStore(
            project_root, project_id=project_id
        )
        lifecycle = store.lifecycle_store()
        rows = []
        for evidence_id in evidence_ids:
            exact = store.verify(evidence_id)
            effective = lifecycle.resolve(evidence_id)
            if (
                exact["status"] != "ok"
                or exact["evidence"]["verification_status"] != "verified"
                or effective["status"] != "ok"
                or not effective["retrieval_eligible"]
            ):
                raise ValueError(
                    f"codex_team_memory_source_evidence_ineligible:{evidence_id}"
                )
            evidence = exact["evidence"]
            rows.append(
                {
                    "evidence_id": evidence_id,
                    "source_revision": evidence["source_revision"],
                    "record_sha256": exact["record_sha256"],
                    "content_sha256": evidence["content"]["sha256"],
                    "lifecycle_revision": effective["lifecycle_revision"],
                }
            )
        return rows

    def _source_evidence_issues(
        self, record: Mapping[str, Any], project_root: str | Path,
    ) -> list[str]:
        try:
            store = DevelopmentProjectEvidenceStore(
                project_root, project_id=record["project_id"]
            )
            lifecycle = store.lifecycle_store()
            rows = record["source_evidence"]
        except (KeyError, TypeError, ValueError):
            return ["source_evidence_unavailable"]
        for row in rows:
            try:
                exact = store.verify(row["evidence_id"])
                effective = lifecycle.resolve(row["evidence_id"])
                evidence = exact.get("evidence")
                if (
                    exact["status"] != "ok"
                    or not isinstance(evidence, Mapping)
                    or evidence["verification_status"] != "verified"
                    or exact["record_sha256"] != row["record_sha256"]
                    or evidence["content"]["sha256"]
                    != row["content_sha256"]
                    or evidence["source_revision"] != row["source_revision"]
                    or effective["status"] != "ok"
                    or not effective["retrieval_eligible"]
                ):
                    return ["source_evidence_ineligible"]
            except (KeyError, TypeError, ValueError):
                return ["source_evidence_ineligible"]
        return []

    @staticmethod
    def _write_immutable(target: Path, value: Mapping[str, Any]) -> None:
        serialized = pretty_bytes(value)
        try:
            with target.open("xb") as output:
                output.write(serialized)
                output.flush()
                os.fsync(output.fileno())
        except FileExistsError as exc:
            raise ValueError("codex_team_memory_record_conflict") from exc

    def _read_record(
        self, path: Path, *, expected_memory_id: str,
    ) -> dict[str, Any]:
        if path.is_symlink():
            raise ValueError("codex_team_memory_record_symlink_rejected")
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise ValueError("codex_team_memory_record_unreadable") from exc
        required = {
            "schema_version",
            "artifact_type",
            "provider_id",
            "memory_id",
            "identity_sha256",
            "project_id",
            "team_id",
            "memory_key",
            "title",
            "content",
            "tags",
            "source_evidence",
            "proposed_by",
            "proposer_kind",
            "permission_policy_revision",
            "proposed_at",
            "initial_state",
            "non_claims",
            "record_sha256",
        }
        if (
            not isinstance(value, Mapping)
            or set(value) != required
            or value.get("schema_version") != "1.0.0"
            or value.get("artifact_type") != "team_memory_candidate_record"
            or value.get("provider_id") != self.provider_id
            or value.get("memory_id") != expected_memory_id
            or SAFE_MEMORY_ID.fullmatch(expected_memory_id) is None
            or value.get("initial_state") != "candidate"
            or value.get("non_claims") != list(RECORD_NON_CLAIMS)
            or value.get("record_sha256")
            != _digest(value, excluded=("record_sha256",))
        ):
            raise ValueError("codex_team_memory_record_invalid")
        source_rows = value.get("source_evidence")
        identity = {
            "project_id": value.get("project_id"),
            "team_id": value.get("team_id"),
            "memory_key": value.get("memory_key"),
            "title": value.get("title"),
            "content_sha256": sha256_bytes(
                str(value.get("content", "")).encode("utf-8")
            ),
            "source_evidence": source_rows,
        }
        if (
            not isinstance(source_rows, list)
            or not source_rows
            or value.get("identity_sha256")
            != sha256_bytes(canonical_bytes(identity))
            or value.get("memory_id")
            != f"team-memory-{str(value.get('identity_sha256', ''))[:24]}"
        ):
            raise ValueError("codex_team_memory_record_identity_invalid")
        return dict(value)

    def _record_path(
        self, project_id: str, team_id: str, memory_id: str,
    ) -> Path:
        if not isinstance(memory_id, str) or SAFE_MEMORY_ID.fullmatch(
            memory_id
        ) is None:
            raise ValueError("codex_team_memory_id_invalid")
        return self._scope_directory(
            "records", project_id, team_id, create=False
        ) / f"{memory_id}.json"

    def _events_directory(
        self,
        project_id: str,
        team_id: str,
        memory_id: str,
        *,
        create: bool,
    ) -> Path:
        if SAFE_MEMORY_ID.fullmatch(memory_id) is None:
            raise ValueError("codex_team_memory_id_invalid")
        return self._scope_directory(
            "events", project_id, team_id, create=create
        ) / memory_id

    def _events(
        self, project_id: str, team_id: str, memory_id: str,
    ) -> tuple[list[dict[str, Any]], list[str]]:
        directory = self._events_directory(
            project_id, team_id, memory_id, create=False
        )
        if not directory.is_dir():
            return [], []
        paths = sorted(directory.glob("*.json"))
        issues = ["event_scan_truncated"] if len(paths) > MAX_EVENTS else []
        candidates = []
        for path in paths[:MAX_EVENTS]:
            if path.is_symlink():
                issues.append("event_symlink_rejected")
                continue
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, UnicodeError, json.JSONDecodeError):
                issues.append("event_unreadable")
                continue
            if self._event_issues(value, memory_id=memory_id):
                issues.append("event_invalid")
                continue
            candidates.append(dict(value))
        candidates.sort(
            key=lambda item: (item["resulting_revision"], item["event_id"])
        )
        accepted = []
        revision = 0
        for event in candidates:
            if (
                event["expected_prior_revision"] != revision
                or event["resulting_revision"] != revision + 1
            ):
                issues.append("event_revision_noncontiguous")
                continue
            accepted.append(event)
            revision += 1
        return accepted, list(dict.fromkeys(issues))

    @staticmethod
    def _event_issues(value: Any, *, memory_id: str) -> list[str]:
        required = {
            "schema_version",
            "artifact_type",
            "event_id",
            "provider_id",
            "memory_id",
            "action",
            "actor_id",
            "principal_kind",
            "permission_policy_revision",
            "required_capability",
            "expected_prior_revision",
            "resulting_revision",
            "decision",
            "successor_memory_id",
            "reason",
            "recorded_at",
            "content_sha256",
            "non_claims",
        }
        if not isinstance(value, Mapping):
            return ["event_not_object"]
        issues = []
        if set(value) != required:
            issues.append("event_fields_invalid")
        if value.get("schema_version") != "1.0.0":
            issues.append("event_schema_invalid")
        if value.get("artifact_type") != "team_memory_lifecycle_event":
            issues.append("event_artifact_type_invalid")
        if value.get("provider_id") != PROVIDER_ID:
            issues.append("event_provider_mismatch")
        if value.get("memory_id") != memory_id:
            issues.append("event_memory_mismatch")
        event_id = value.get("event_id")
        if not isinstance(event_id, str) or SAFE_EVENT_ID.fullmatch(event_id) is None:
            issues.append("event_id_invalid")
        action = value.get("action")
        if action not in ACTION_CAPABILITY:
            issues.append("event_action_invalid")
        if value.get("required_capability") != ACTION_CAPABILITY.get(action):
            issues.append("event_capability_mismatch")
        if value.get("non_claims") != list(EVENT_NON_CLAIMS):
            issues.append("event_non_claims_invalid")
        if value.get("content_sha256") != _digest(
            value, excluded=("event_id", "content_sha256")
        ):
            issues.append("event_content_hash_mismatch")
        if (
            isinstance(event_id, str)
            and isinstance(value.get("content_sha256"), str)
            and event_id
            != f"team-memory-event-{value['content_sha256'][:24]}"
        ):
            issues.append("event_id_hash_mismatch")
        for field in ("expected_prior_revision", "resulting_revision"):
            item = value.get(field)
            if isinstance(item, bool) or not isinstance(item, int) or item < 0:
                issues.append(f"event_{field}_invalid")
        if action == "review":
            if value.get("decision") not in {"approve", "reject"}:
                issues.append("event_decision_invalid")
        elif value.get("decision") is not None:
            issues.append("event_decision_not_applicable")
        successor = value.get("successor_memory_id")
        if action == "supersede":
            if not isinstance(successor, str) or SAFE_MEMORY_ID.fullmatch(
                successor
            ) is None:
                issues.append("event_successor_invalid")
        elif successor is not None:
            issues.append("event_successor_not_applicable")
        try:
            _timestamp(value.get("recorded_at"), field="recorded_at")
        except (TypeError, ValueError):
            issues.append("event_recorded_at_invalid")
        return issues

    def _resolved_memory(
        self,
        record: Mapping[str, Any],
        project_id: str,
        team_id: str,
    ) -> dict[str, Any]:
        events, issues = self._events(
            project_id, team_id, record["memory_id"]
        )
        state = "candidate"
        review = None
        successor = None
        payload_visible = True
        for event in events:
            action = event["action"]
            if action == "review":
                review = {
                    "decision": event["decision"],
                    "reviewer_id": event["actor_id"],
                    "policy_revision": event["permission_policy_revision"],
                    "event_id": event["event_id"],
                }
                state = "reviewed" if event["decision"] == "approve" else "rejected"
            elif action == "publish":
                state = "published"
            elif action == "supersede":
                state = "superseded"
                successor = event["successor_memory_id"]
            elif action == "invalidate":
                state = "invalidated"
            elif action == "redact_from_retrieval":
                state = "retrieval_redacted"
                payload_visible = False
        if issues:
            state = "review_needed"
            payload_visible = False
        return {
            "status": "ok" if not issues else "review_needed",
            "memory_id": record["memory_id"],
            "memory_key": record["memory_key"],
            "project_id": project_id,
            "team_id": team_id,
            "state": state,
            "revision": events[-1]["resulting_revision"] if events else 0,
            "review": review,
            "successor_memory_id": successor,
            "payload_visible": payload_visible,
            "record_sha256": record["record_sha256"],
            "event_inventory_sha256": sha256_bytes(
                canonical_bytes(
                    [
                        {
                            "event_id": item["event_id"],
                            "content_sha256": item["content_sha256"],
                        }
                        for item in events
                    ]
                )
            ),
            "title": record["title"] if payload_visible else None,
            "content": record["content"] if payload_visible else None,
            "tags": list(record["tags"]) if payload_visible else [],
            "source_evidence": list(record["source_evidence"]),
            "proposed_by": record["proposed_by"],
            "permission_policy_revision": record[
                "permission_policy_revision"
            ],
            "issues": issues,
            "advisory_non_claim": (
                "team_memory_does_not_become_truth_acceptance_or_authority"
            ),
        }

    def _exact_resolved(
        self, project_id: str, team_id: str, memory_id: str,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        path = self._record_path(project_id, team_id, memory_id)
        if not path.is_file():
            raise ValueError("codex_team_memory_not_found")
        record = self._read_record(path, expected_memory_id=memory_id)
        if (
            record["project_id"] != project_id
            or record["team_id"] != team_id
        ):
            raise ValueError("codex_team_memory_record_scope_mismatch")
        return record, self._resolved_memory(record, project_id, team_id)

    def review(
        self,
        project_root: str | Path,
        project_id: str,
        team_id: str,
        memory_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        decision: str,
        reason: str,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        selected = _text(decision, field="review_decision", maximum=20)
        if selected not in {"approve", "reject"}:
            raise ValueError("codex_team_memory_review_decision_invalid")
        return self._append_event(
            project_root,
            project_id,
            team_id,
            memory_id,
            action="review",
            actor_context=actor_context,
            permission_policy=permission_policy,
            decision=selected,
            successor_memory_id=None,
            reason=reason,
            recorded_at=recorded_at,
        )

    def publish(
        self,
        project_root: str | Path,
        project_id: str,
        team_id: str,
        memory_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        reason: str,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        return self._append_event(
            project_root,
            project_id,
            team_id,
            memory_id,
            action="publish",
            actor_context=actor_context,
            permission_policy=permission_policy,
            decision=None,
            successor_memory_id=None,
            reason=reason,
            recorded_at=recorded_at,
        )

    def supersede(
        self,
        project_root: str | Path,
        project_id: str,
        team_id: str,
        memory_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        successor_memory_id: str,
        reason: str,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        if successor_memory_id == memory_id:
            raise ValueError("codex_team_memory_self_supersession")
        return self._append_event(
            project_root,
            project_id,
            team_id,
            memory_id,
            action="supersede",
            actor_context=actor_context,
            permission_policy=permission_policy,
            decision=None,
            successor_memory_id=successor_memory_id,
            reason=reason,
            recorded_at=recorded_at,
        )

    def invalidate(
        self,
        project_root: str | Path,
        project_id: str,
        team_id: str,
        memory_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        reason: str,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        return self._append_event(
            project_root,
            project_id,
            team_id,
            memory_id,
            action="invalidate",
            actor_context=actor_context,
            permission_policy=permission_policy,
            decision=None,
            successor_memory_id=None,
            reason=reason,
            recorded_at=recorded_at,
        )

    def redact_from_retrieval(
        self,
        project_root: str | Path,
        project_id: str,
        team_id: str,
        memory_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        reason: str,
        recorded_at: str | None = None,
    ) -> dict[str, Any]:
        return self._append_event(
            project_root,
            project_id,
            team_id,
            memory_id,
            action="redact_from_retrieval",
            actor_context=actor_context,
            permission_policy=permission_policy,
            decision=None,
            successor_memory_id=None,
            reason=reason,
            recorded_at=recorded_at,
        )

    def _append_event(
        self,
        project_root: str | Path,
        project_id: str,
        team_id: str,
        memory_id: str,
        *,
        action: str,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        decision: str | None,
        successor_memory_id: str | None,
        reason: str,
        recorded_at: str | None,
    ) -> dict[str, Any]:
        project, team = self._require_enabled(
            project_id, team_id, actor_context, permission_policy
        )
        capability = ACTION_CAPABILITY[action]
        permission_policy.require(actor_context, capability)
        explanation = _text(reason, field="reason", maximum=4_000)
        record, current = self._exact_resolved(project, team, memory_id)
        self._validate_transition(
            action,
            project_root=project_root,
            record=record,
            current=current,
            actor_context=actor_context,
            permission_policy=permission_policy,
            successor_memory_id=successor_memory_id,
        )
        events_directory = self._events_directory(
            project, team, memory_id, create=True
        )
        events_directory.mkdir(parents=True, exist_ok=True)
        lock_path = events_directory / ".events.lock"
        if lock_path.is_symlink():
            raise ValueError("codex_team_memory_events_lock_symlink_rejected")
        with lock_path.open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            # Re-resolve under the write lock so concurrent review/publish
            # cannot use the same expected revision.
            record, current = self._exact_resolved(project, team, memory_id)
            self._validate_transition(
                action,
                project_root=project_root,
                record=record,
                current=current,
                actor_context=actor_context,
                permission_policy=permission_policy,
                successor_memory_id=successor_memory_id,
            )
            revision = current["revision"] + 1
            body = {
                "schema_version": "1.0.0",
                "artifact_type": "team_memory_lifecycle_event",
                "provider_id": self.provider_id,
                "memory_id": memory_id,
                "action": action,
                "actor_id": actor_context.principal_id,
                "principal_kind": actor_context.principal_kind,
                "permission_policy_revision": permission_policy.policy_revision,
                "required_capability": capability,
                "expected_prior_revision": current["revision"],
                "resulting_revision": revision,
                "decision": decision,
                "successor_memory_id": successor_memory_id,
                "reason": explanation,
                "recorded_at": _timestamp(
                    recorded_at or _now(), field="recorded_at"
                ),
                "non_claims": list(EVENT_NON_CLAIMS),
            }
            digest = _digest(body, excluded=())
            event_id = f"team-memory-event-{digest[:24]}"
            event = {
                **body,
                "event_id": event_id,
                "content_sha256": digest,
            }
            target = events_directory / f"{revision:08d}.{event_id}.json"
            self._write_immutable(target, event)
        return {
            "status": f"{action}_recorded",
            "event": event,
            "memory": self._resolved_memory(record, project, team),
            "event_ref": target.relative_to(self.state_root.parent).as_posix(),
        }

    def _validate_transition(
        self,
        action: str,
        *,
        project_root: str | Path,
        record: Mapping[str, Any],
        current: Mapping[str, Any],
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        successor_memory_id: str | None,
    ) -> None:
        state = current["state"]
        if current["status"] != "ok":
            raise ValueError("codex_team_memory_review_needed")
        if action == "review":
            if state != "candidate":
                raise ValueError("codex_team_memory_review_state_invalid")
            if actor_context.principal_id == record["proposed_by"]:
                raise ValueError("codex_team_memory_independent_review_required")
        elif action == "publish":
            if state != "reviewed" or current["review"] is None:
                raise ValueError("codex_team_memory_publish_review_required")
            if current["review"]["policy_revision"] != (
                permission_policy.policy_revision
            ):
                raise ValueError("codex_team_memory_review_policy_stale")
            if self._source_evidence_issues(record, project_root):
                raise ValueError(
                    "codex_team_memory_source_evidence_ineligible"
                )
        elif action == "supersede":
            if state != "published":
                raise ValueError("codex_team_memory_supersede_state_invalid")
            if (
                not isinstance(successor_memory_id, str)
                or SAFE_MEMORY_ID.fullmatch(successor_memory_id) is None
            ):
                raise ValueError("codex_team_memory_successor_invalid")
            successor_record, successor = self._exact_resolved(
                current["project_id"], current["team_id"], successor_memory_id
            )
            if (
                successor["state"] != "published"
                or successor["memory_key"] != current["memory_key"]
            ):
                raise ValueError("codex_team_memory_successor_not_current")
            if self._source_evidence_issues(successor_record, project_root):
                raise ValueError(
                    "codex_team_memory_successor_source_ineligible"
                )
        elif action in {"invalidate", "redact_from_retrieval"}:
            if state not in {"candidate", "reviewed", "published"}:
                raise ValueError("codex_team_memory_lifecycle_state_invalid")

    def get(
        self,
        project_root: str | Path,
        project_id: str,
        team_id: str,
        memory_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
    ) -> dict[str, Any]:
        project, team = self._require_enabled(
            project_id, team_id, actor_context, permission_policy
        )
        # Check permission before resolving the path or record existence.
        if not permission_policy.allows(actor_context, "team_memory_read"):
            return {"status": "not_found", "memory": None}
        try:
            record, memory = self._exact_resolved(project, team, memory_id)
        except ValueError:
            return {"status": "not_found", "memory": None}
        if memory["status"] != "ok" or memory["state"] != "published":
            return {"status": "not_found", "memory": None}
        source_issues = self._source_evidence_issues(record, project_root)
        if source_issues:
            return {
                "status": "review_needed",
                "memory": None,
                "issues": source_issues,
            }
        return {"status": "ok", "memory": memory}

    def search(
        self,
        project_root: str | Path,
        project_id: str,
        team_id: str,
        query: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
        limit: int = 10,
    ) -> dict[str, Any]:
        project, team = self._require_enabled(
            project_id, team_id, actor_context, permission_policy
        )
        if not permission_policy.allows(actor_context, "team_memory_read"):
            return {"status": "ok", "results": [], "result_count": 0}
        if not isinstance(query, str) or len(query.strip()) > MAX_QUERY_CHARS:
            raise ValueError("codex_team_memory_query_invalid")
        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= MAX_RESULTS
        ):
            raise ValueError("codex_team_memory_limit_invalid")
        normalized = query.strip()
        tokens = list(
            dict.fromkeys(token.casefold() for token in normalized.split() if token)
        )
        records = self._scope_directory(
            "records", project, team, create=False
        )
        paths = sorted(records.glob("team-memory-*.json")) if records.is_dir() else []
        issues = ["record_scan_truncated"] if len(paths) > MAX_RECORDS else []
        ranked = []
        for path in paths[:MAX_RECORDS]:
            try:
                record = self._read_record(path, expected_memory_id=path.stem)
                memory = self._resolved_memory(record, project, team)
            except ValueError:
                issues.append("invalid_record_isolated")
                continue
            if memory["status"] != "ok" or memory["state"] != "published":
                continue
            source_issues = self._source_evidence_issues(record, project_root)
            if source_issues:
                issues.extend(source_issues)
                continue
            searchable = " ".join(
                [memory["title"], memory["content"], *memory["tags"]]
            ).casefold()
            matched = sum(token in searchable for token in tokens)
            if tokens and matched == 0:
                continue
            score = matched + (
                2
                if normalized and normalized.casefold() in memory["title"].casefold()
                else 0
            )
            ranked.append({"score": score, "memory": memory})
        ranked.sort(key=lambda item: item["memory"]["memory_id"])
        ranked.sort(key=lambda item: item["score"], reverse=True)
        results = ranked[:limit]
        return {
            "status": "ok" if not issues else "review_needed",
            "results": results,
            "result_count": len(results),
            "issues": list(dict.fromkeys(issues)),
            "limitations": [
                "same_host_team_memory_only",
                "permission_filtered_before_record_enumeration_and_ranking",
                "not_semantic_rag_or_automatic_context",
            ],
        }

    def export_receipt(
        self,
        project_root: str | Path,
        project_id: str,
        team_id: str,
        memory_id: str,
        *,
        actor_context: ProjectPrincipalContext,
        permission_policy: ProjectPermissionPolicy,
    ) -> dict[str, Any]:
        project, team = self._require_enabled(
            project_id, team_id, actor_context, permission_policy
        )
        permission_policy.require(actor_context, "team_memory_export_receipt")
        record, memory = self._exact_resolved(project, team, memory_id)
        events, issues = self._events(project, team, memory_id)
        body = {
            "schema_version": "1.0.0",
            "artifact_type": "team_memory_export_receipt",
            "provider_id": self.provider_id,
            "project_id": project,
            "team_id": team,
            "memory_id": memory_id,
            "record_sha256": record["record_sha256"],
            "effective_state": memory["state"],
            "revision": memory["revision"],
            "event_refs": [
                {
                    "event_id": event["event_id"],
                    "content_sha256": event["content_sha256"],
                }
                for event in events
            ],
            "issues": issues,
            "exported_by": actor_context.principal_id,
            "permission_policy_revision": permission_policy.policy_revision,
            "non_claims": list(EVENT_NON_CLAIMS),
        }
        return {**body, "content_sha256": _digest(body, excluded=())}
