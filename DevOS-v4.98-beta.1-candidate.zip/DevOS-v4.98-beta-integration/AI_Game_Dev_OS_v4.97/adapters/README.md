# AI IDE Adapters

This directory contains AI IDE/runtime integration contracts for
`AI_Game_Dev_OS_v4.93`.

Adapters are not canonical implementation layers. They explain how an external
runtime such as Codex, Cursor, or WorkBuddy should read root contracts, resolve
owners, respect write boundaries, produce runtime evidence, and stop when
required evidence is missing.

Use these surfaces:

- `../DESIGN_AND_CAPABILITY_ARCHITECTURE.md` - whole-system architecture,
  founding constraints, truth hierarchy, and capability flow all adapters must
  respect.
- `AI_IDE_ADAPTER_BASE.md` - shared contract for all AI IDE adapters.
- `codex/` - Codex-specific policy, invocation profile, runtime contract, and
  examples.
- `cursor/` - Cursor-specific policy, invocation profile, and runtime contract.
- `workbuddy_private/` - WorkBuddy private-runtime policy, invocation profile,
  and runtime contract.

Canonical agents, skills, workflows, schemas, and validators remain in
`pack_layer/` and root compatibility paths. Adapter files reference those
surfaces; they must not redefine them.
