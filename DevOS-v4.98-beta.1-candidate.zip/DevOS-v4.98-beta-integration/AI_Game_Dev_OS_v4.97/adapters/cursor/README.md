# Cursor Adapter Contract

This directory defines the v4.93 Cursor adapter surface. It specializes the
shared AI IDE adapter base for Cursor's rules and worktree-oriented parallel
agent model.

Use these files:

- `../../DESIGN_AND_CAPABILITY_ARCHITECTURE.md` - whole-system architecture and
  capability-flow contract Cursor must read before routing work.
- `cursor_integration_policy.json` - Cursor read order, boundaries, evidence,
  validation, and runtime-output policy.
- `cursor_invocation_profile.json` - goal-class routing profile from user
  intent to root, Orchestrator, pack, workflow, and validator surfaces.
- `cursor_runtime_adapter_contract.md` - human-readable Cursor execution
  contract.

Canonical agents, skills, workflows, schemas, and validators remain in
`pack_layer/` and root compatibility paths. This adapter references those
surfaces; it does not redefine them.
