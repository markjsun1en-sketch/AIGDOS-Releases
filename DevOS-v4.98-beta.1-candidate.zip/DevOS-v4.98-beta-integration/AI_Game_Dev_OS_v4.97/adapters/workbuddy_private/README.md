# WorkBuddy Private Adapter Contract

This directory defines the v4.93 WorkBuddy private-runtime adapter surface. It
specializes the shared AI IDE adapter base for project-defined private runtime
coordination.

Use these files:

- `../../DESIGN_AND_CAPABILITY_ARCHITECTURE.md` - whole-system architecture and
  capability-flow contract WorkBuddy must read before routing work.
- `workbuddy_private_integration_policy.json` - WorkBuddy read order,
  boundaries, evidence, validation, and runtime-output policy.
- `workbuddy_private_invocation_profile.json` - goal-class routing profile from
  user intent to root, Orchestrator, pack, workflow, and validator surfaces.
- `workbuddy_private_runtime_adapter_contract.md` - human-readable WorkBuddy
  execution contract.

Canonical agents, skills, workflows, schemas, and validators remain in
`pack_layer/` and root compatibility paths. This adapter references those
surfaces; it does not redefine them.
