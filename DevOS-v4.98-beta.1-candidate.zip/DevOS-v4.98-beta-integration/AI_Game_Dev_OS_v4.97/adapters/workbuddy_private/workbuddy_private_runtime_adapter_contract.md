# WorkBuddy Private Runtime Adapter Contract

WorkBuddy private is an external AI IDE/runtime operator. v4.93 is the
contract source. Repository scripts generate plans, reports, diagnostics, and
validations; they do not call LLM agents automatically.

WorkBuddy must apply `adapters/AI_IDE_ADAPTER_BASE.md` first, then specialize
execution through `os_layer/config/profiles/workbuddy_private.json`.

## WorkBuddy-Specific Runtime Model

- Coordination model: `private_coordinated`.
- Isolation unit: `project_defined`.
- Merge mode: `serial`.
- Write-back owner: main session.
- Rule loading: project-defined private runtime rules.

Private coordination does not weaken v4.93 ownership. WorkBuddy must still
resolve each lane through:

- `DESIGN_AND_CAPABILITY_ARCHITECTURE.md`;
- `os_layer/os_control_plane/leads/orchestrator.capability.json`;
- `pack_layer/packs/game_system_packs/end_to_end_production/capability_pack.json`;
- `pack_layer/packs/game_system_packs/end_to_end_production/references/end_to_end_delivery_workflow.json`;
- `pack_layer/packs/game_system_packs/end_to_end_production/docs/agent_harness/RUNTIME_ADAPTER_SPEC.md`.

## Runtime Evidence

WorkBuddy-generated run state belongs under the target project `.ai_dev_os/`
root defined by `RUNTIME_INSTANCE_CONTRACT.md`. Shareable review evidence
belongs under `<target_project_artifacts>/v493/`.

WorkBuddy-mediated work must produce or preserve:

- `agent_run_plan.json`;
- `agent_execution_trace.json`;
- validation output;
- beta readiness or blocker reports when real-project adoption is in scope.

Fixture success is regression evidence only. Real-project promotion requires a
runtime-produced trace and reviewed project evidence.
