# AI IDE Adapter Base Contract

Version: `AI_Game_Dev_OS_v4.93`

This contract applies to every AI IDE/runtime adapter under `adapters/`.
Adapter-specific files may specialize runtime behavior, but they must not
replace the canonical root, OS-layer, or pack-layer contracts.

## Shared Read Order

Use this order when integrating or changing a route. For a continuing task,
reuse unchanged context and load only applicable instructions, current state
and relevant contracts as described in `IDE_INTEGRATION.md`.

1. `INDEX.md`
2. `MANIFEST.json`
3. `README.md`
4. `DESIGN_AND_CAPABILITY_ARCHITECTURE.md`
5. `MODULES_AND_INVOCATION.md`
6. `RUNTIME_INSTANCE_CONTRACT.md`
7. `REAL_PROJECT_ADOPTION_CONTRACT.md`
8. `ROOT_MIRROR_POLICY.md`
9. `IDE_INTEGRATION.md`
10. adapter-specific policy and invocation profile
11. `os_layer/os_control_plane/leads/orchestrator.capability.json`
12. `pack_layer/packs/game_system_packs/end_to_end_production/capability_pack.json`
13. `pack_layer/packs/game_system_packs/end_to_end_production/references/end_to_end_delivery_workflow.json`
14. `pack_layer/packs/game_system_packs/end_to_end_production/docs/agent_harness/RUNTIME_ADAPTER_SPEC.md`

## Canonical Source Rule

Adapters reference canonical sources. They do not define canonical agents,
skills, workflows, schemas, validators, lifecycle state, or release authority.

If an adapter file conflicts with a root contract, Orchestrator capability
sheet, production pack manifest, or delivery workflow, the AI IDE must stop and
request a contract repair.

## Invocation Rule

Follow the task-level invocation and evidence rules in
[IDE_INTEGRATION.md](../IDE_INTEGRATION.md). Reuse the existing scope, owner,
write boundary and validation plan; update changed facts rather than generating
a declaration before each edit or command. Ordinary authorized local work
does not need a routing override. Explicit adapter/Agent Harness invocations
still supply all machine-required plan and trace fields.

## Runtime State Rule

Generated runtime state belongs in the target project or an explicit artifact
root, not in canonical v4.93 definitions.

Use `RUNTIME_INSTANCE_CONTRACT.md` for:

- `<target_project>/.ai_dev_os/capability_bindings.json`;
- `<target_project>/.ai_dev_os/agent_run_plan.json`;
- `<target_project>/.ai_dev_os/agent_execution_trace.json`;
- `<target_project>/.ai_dev_os/reports/`;
- `<target_project_artifacts>/v493/`.

## Context IO Adoption

For projects adopting bounded context IO, follow [CONTEXT_IO.md](../CONTEXT_IO.md).
Read mandatory instructions and the current task summary, then locate needed
history through indexes and bounded excerpts. Cold-start path lists are
navigation, not a request to read every historical log in full. The optional
`--context-io` boot flag exposes this route without changing default output.

Prefer the structured writer for supported log deltas and current summaries.
Preview and apply within existing authorization; no extra Human confirmation
is introduced. Keep blockers and pause boundaries explicit, link detailed
evidence, and configure project paths/budgets in the project policy. Unsupported
documents use their existing owner workflow; do not silently migrate them.
These tools do not replace Sprint rollups or Evidence/Memory promotion.

## Evidence Rule

Repository scripts may generate plans, reports, validators, and diagnostics.
They do not automatically call LLM agents. External runtimes execute or
delegate the work and return evidence for validation.

Fixture success, dry-run reports, and synthetic traces are regression evidence.
They are not real-project adoption evidence.

## Stop Conditions

Stop the affected operation when:

- applicable root contracts are unread or inconsistent;
- no canonical owner can be resolved;
- the requested write surface is outside allowed writes;
- prerequisite evidence required for that operation is missing; evidence to be
  produced by the task is not a prerequisite to starting it;
- an adapter result is being consumed or declared complete without the trace
  required by its execution contract;
- an attempted qualification/promotion has beta-readiness blockers; those do
  not by themselves stop separately authorized development;
- the task would make repository-root `.dev_os_meta/` a runtime package
  dependency.
