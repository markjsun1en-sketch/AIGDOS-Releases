# AI Game Dev OS v4.97 Root Mirror Policy

This policy carries the inherited production-pack compatibility-path decision
into v4.97:

```text
AI_Game_Dev_OS_v4.97/
  packs/
  scripts/
  tests/
```

## Decision

Keep root `packs/`, `scripts/`, and `tests/` as stable public compatibility
surfaces for the inherited production pack during v4.97 development.

The canonical production implementation still lives in `pack_layer/`. The root
paths are compatibility mirrors for users, automation, and AI IDEs that already
call the pre-split v4.93 entrypoints.

## Authority

| Surface | Authority |
| --- | --- |
| Whole-version entrypoint, module catalog, invocation instructions | Root docs |
| Production pack implementation | `pack_layer/packs/game_system_packs/end_to_end_production/` |
| Delivery scripts | `pack_layer/scripts/delivery/`, mirrored at `scripts/delivery/` |
| Delivery tests | `pack_layer/tests/delivery/`, mirrored at `tests/delivery/` |
| User-facing compatibility commands | Root `scripts/` and `tests/` paths |

The mirror paths must not define root-only agents, skills, workflows, schemas,
or script behavior. If a production-pack implementation changes, update the
pack-layer source and its root mirror together.

## Command Policy

Root commands are the stable public commands shown in root docs. Pack-layer
commands are layer-local equivalents for maintainers working directly inside
`pack_layer/`.

Both forms are valid while this policy is active:

```bash
python3 -m pytest AI_Game_Dev_OS_v4.97/tests/delivery/test_v493_end_to_end_skill_contracts.py -q --tb=short
python3 -m pytest AI_Game_Dev_OS_v4.97/pack_layer/tests/delivery/test_v493_end_to_end_skill_contracts.py -q --tb=short
```

Do not introduce a new command that exists only in one surface unless the
mirror policy is updated at the same time.

## Validation Gate

Mirror sync is a source-tree and release gate while root mirrors exist:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_pack_layer_mirror.py
```

The validator compares:

- `packs/game_system_packs/end_to_end_production/`
- `scripts/delivery/`
- `tests/delivery/`

It ignores transient execution artifacts and the generated exploratory fixture
directory `tests/delivery/fixtures/gdd_formal_output_tests/`.

## Deprecation Rule

Root mirrors may be deprecated only through an explicit future migration that:

- updates root docs, `MANIFEST.json`, and AI IDE read order;
- updates `CLI_COMMAND_MATRIX.md`;
- provides a compatibility window;
- removes or rewrites mirror validation;
- keeps root-level module and invocation guidance authoritative.

Until then, divergence between root mirrors and `pack_layer/` is an error, not
an allowed implementation choice.
