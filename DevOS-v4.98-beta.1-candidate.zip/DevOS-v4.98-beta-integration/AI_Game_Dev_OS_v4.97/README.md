# AI Game Dev OS v4.97 — Limited Candidate Release

> 2026-09-14 current disposition: **limited candidate closed**, package lifecycle **draft**.
> Read [v497 release notes](V497_RELEASE_NOTES.md) and
> [closure state](V497_RELEASE_CLOSURE.json). The dated development records below
> remain historical; their earlier pending-work/release wording does not reopen
> this limited closure. Full qualification and professional efficacy are unverified.

> This directory is the v4.97 Production Assembly development package. Read
> `V497_DEVELOPMENT_STATUS.md` for the completed Slice 0/1 baseline, accepted
> pre-choice non-writing consumer-derived-state contract baseline, exact
> Candidate 1 Human scope admission, and implemented but unqualified Slice 2-4
> Assembly/quality/Godot/Codex development baselines, plus the Slice 6/7
> package-local workspace, portable-state, terminal-artifact lifecycle and
> non-writing Pack Registry/reuse-preview baselines, and
> `V497_PACKAGE_IDENTITY_RECONCILIATION.md` for the exact inherited/current
> boundary. This root identity is not qualification, Gate passage, package
> promotion, supported adoption, or release acceptance.

`AI_Game_Dev_OS_v4.97/` is the active v4.97 development source tree derived
from the exact accepted v4.96 package subtree. Root package identity and
command paths are reconciled without relabeling inherited v4.96/v4.95/v4.94
records, the OS-layer release inventory, or the v4.93 production-pack
namespace.

Start here:

- `V497_DEVELOPMENT_STATUS.md` - current exact successor, Slice 0 boundary,
  Runtime State repair, accepted pre-choice read-only contract baseline,
  Candidate 1 scope admission, Slice 2-4 development facts, verification,
  remaining work, and non-claims.
- `V497_PACKAGE_IDENTITY_RECONCILIATION.md` - reproducible v4.96-to-v4.97
  inventory, root identity boundary, and preserved provenance.
- `V497_KICKOFF_BASELINE.md` - historical Slice 0 successor and authority
  boundary at kickoff.
- `V497_SLICE0_QUALIFICATION_PILOT_CHOICES.md` - read-only project inventory
  and Pilot alternatives plus the exact 2026-08-29 Human selection.
- `V496_DEVELOPMENT_STATUS.md` - inherited multi-lane Production, Evidence,
  Memory, permission-aware retrieval, Team Memory, Pilot, verification, and
  non-claims.
- `V496_PACKAGE_IDENTITY_RECONCILIATION.md` - reproducible v4.95-to-v4.96
  inventory, root identity boundary, and preserved provenance.
- `V495_DEVELOPMENT_STATUS.md` - inherited v4.95 Production foundation and
  Evidence Continuity development record.
- `V495_PACKAGE_IDENTITY_RECONCILIATION.md` - historical v4.94-to-v4.95 root
  identity refresh and preserved provenance.
- `V494_DEVELOPMENT_STATUS.md` - inherited function-first capabilities, write
  boundaries, remaining work, and non-claims.
- `V494_PACKAGE_IDENTITY_RECONCILIATION.md` - exact inherited/current package
  inventory and identity-refresh boundary for the historical v4.94 line.
- `INDEX.md` - version-level navigation across root, OS layer, pack layer,
  capability, status, and validation surfaces.
- `MANIFEST.json` - machine-readable manifest for root, layer, pack,
  Orchestrator, evidence, delivery policy, and validation entrypoints.
- `DESIGN_AND_CAPABILITY_ARCHITECTURE.md` - whole-system architecture map,
  founding constraints, truth hierarchy, layer model, and capability flow.
- `MODULES_AND_INVOCATION.md` - authoritative root-level module catalog,
  invocation routes, write boundaries, and command map.
- `RUNTIME_INSTANCE_CONTRACT.md` - target-project `.ai_dev_os/` and artifact
  root contract for generated bindings, run plans, traces, and reports.
- `REAL_PROJECT_ADOPTION_CONTRACT.md` - real-project evidence and lifecycle
  promotion gate.
- `ROOT_MIRROR_POLICY.md` - compatibility decision for root `packs/`,
  `scripts/`, and `tests/` mirrors.
- `IDE_INTEGRATION.md` - bootstrap guide for Codex, WorkBuddy, Cursor, and
  other AI IDE/runtime integrations.
- `USER_MANUAL.md` - user-facing workflow manual for Codex/runtime-adapter use.
- `OS_PACK_LAYER_MAP.md` - boundary map for `os_layer/`, `pack_layer/`, and
  compatibility paths.
- `DELIVERY_CONTRACT.md` - source tree, release snapshot, mirror sync, and
  workspace-governance delivery boundary.
- `CHANGELOG.md` - version history, migration notes, roadmap alignment, and
  provenance details.
- `RESTRUCTURING_PLAN.md` - inherited v4.93 restructuring record retained as
  provenance for the split-layer baseline.

## What This Version Contains

v4.97 is a Production Assembly development successor on the exact accepted
v4.96 split-layer package. After the Slice 0/1 identity baseline and one
accepted pre-choice, read-only, non-writing consumer-derived-state contract
baseline, it adds implemented but unqualified Slice 2-4 development surfaces:

```text
AI_Game_Dev_OS_v4.97/
  os_layer/
  pack_layer/
  adapters/
  engine_profiles/    # concrete Godot development profile and runtime
  production_packs/   # neutral Candidate 1 Pack, Recipe, Agents, Skills
  schemas/
  production_runtime/ # composition, quality, contracts, fixtures, tests
  packs/      # root compatibility mirror
  scripts/    # root compatibility mirror
  tests/      # root compatibility mirror
```

- `os_layer/` preserves the full v4.92 OS baseline and carries later OS-layer
  additions, including v4.94 Runtime State development integration. The v4.92
  source name is provenance; a complete v4.97 checkout must not require an external v4.92 release directory.
- `pack_layer/` carries the inherited v4.93 `end_to_end_production_pack`
  overlay and delivery validation harness.
- `adapters/` carries AI IDE/runtime integration contracts such as the Codex
  adapter policy and invocation profile, plus shared Cursor and WorkBuddy
  runtime adapter contracts. It inherits the v4.95 Worker, typed Godot
  execution/build/QA, Production Spec bridge, Production Cell, and project
  Evidence/Memory foundation. The v4.96 increment adds engine-neutral
  multi-lane DAG coordination, isolated Godot lane backends, controlled
  integration, bounded retry and partial recovery, append-only Evidence/Memory
  lifecycle, compatibility-first migration, permission-aware retrieval, and an
  optional default-off local Team Memory Provider with a non-enumerating CLI.
- `production_runtime/` retains the frozen Slice 0 Gate-local fixture and the
  accepted pre-choice consumer-derived-state baseline, then adds deterministic
  Production Assembly resolution/completion, all four Composition Profiles,
  quality evaluation, Candidate 1 contracts, exact host bindings, fixtures and
  focused tests. Its terminal-artifact lifecycle keeps per-attempt isolation
  while the portable-workspace resource service reserves every managed
  execution root before materialization, applies exact semantic/disk quotas,
  tracks consumers/processes/references, and compacts allowlisted
  workspace/snapshot/cache/build/tool bytes only after durable terminal
  Evidence exists. Resolve/inspect/evaluate operations are non-writing; only
  an exact Project Binding can provide separate project permission.
- `production_runtime/pack_registry.py` scans only explicit exact manifests,
  previews same-core cross-project reuse with deny-by-default inheritance
  exclusions, freezes the target write/validation/rollback plan, and verifies
  committed rollback identity through an isolated temporary Git index. The
  current receipt is explicitly post-hoc because both project executions
  preceded this registry implementation; it closes only the current exact
  `DPE-003` evidence gap and grants no lifecycle or qualification authority.
- `production_runtime/integrated_closure.py` replays one clean package identity
  and both exact Assemblies, binds hash-checked evidence, requires all seven
  outcome dimensions and eight negative families, and exposes every bounded,
  synthetic, unsupported or missing cell without an aggregate score. A
  structural pre-closure cannot authenticate Evidence Authority or grant
  qualification.
- `production_packs/runtime_feature_slice/` contains the draft engine-neutral
  Read-only Hero / Run Summary Pack and Recipe, four Agent contracts and seven
  Skill contracts. Availability does not create permission, project obligation
  or professional-efficacy evidence.
- `engine_profiles/godot/` contains the implemented Godot 4.4 development
  profile, separate exact Godot/Git host-tool requirements and clean-snapshot
  execution runtime. Each authority-sensitive use freshly verifies both tools
  and rebuilds the exact Git archive/object inventory. The managed artifact
  wrapper reserves a lease before invoking the byte-frozen v1.0.1 snapshot
  creator; its finalizer refuses compaction while a process, Human observation
  or recovery remains pending. It is a
  bounded concrete profile, not a general OS sandbox, qualification, release,
  or production/live authority.
- `schemas/` carries root contract schemas for the version manifest, AI IDE
  adapters, Production tool bindings, build/QA receipts, and composition
  profiles/results, including lane/aggregate/recovery, lifecycle, permissions,
  compatibility migration, retrieval, Team Memory/status, derived-state
  bindings, typed discrepancies, validation routes, portable-workspace
  registration/source snapshots and SQLite Team Memory receipts.
- `os_layer/scripts/portable_workspace/` contains the Slice 6 exact project
  registry, WAL-backed single-writer/fenced SQLite service, typed registration
  receipts, thin source-linked boards and default-off SQLite Team Memory
  Provider. Its host-exact fixture binds each clone's tracked-tree state and
  canonical read-policy SHA without writing either clone. Slice 7 now includes
  package-local portable bundle/recovery and Codex conformance. The resource
  lifecycle extension adds six fenced SQLite tables, deterministic allocation
  requests/leases, metadata/sparse/COW/full-tracked profiles, read-only audit
  and non-executable GC planning. Its CLI intentionally exposes read/audit/
  plan only. Real WorkBuddy conformance remains separately unauthorized and
  open.
- `packs/`, `scripts/`, and `tests/` are compatibility mirrors that keep
  current root-level validation and user commands stable under
  `ROOT_MIRROR_POLICY.md`.

The current source is a v4.97 Production Assembly development candidate. The
accepted v4.96 exact-scope capability remains inherited provenance. Slice 1
repairs four inherited static Runtime State fixture/source-contract tests and
binds their exact coverage without claiming full Runtime State qualification.
The whole package remains `lifecycle_status: "draft"`; L3/PC-3 disposition,
qualification-Pilot completion, Pack/Adapter promotion, supported adoption,
release, and production/live authority remain separate.
The consumer-derived-state baseline remains pre-choice and sanitized; the
later Candidate 1 selection does not change its semantics or make it project
authority. The selected feature, lanes, clone path allowlists and WorkBuddy
read/recovery-only scope are recorded separately and do not themselves create
Assembly, Pilot or qualification evidence.
That pre-choice baseline's exact Stage/route binding and internal ID/receipt
consistency are not complete Assembly-lock or Evidence-store provenance or
authenticity. The later Slice 2 resolver closes a declared component bundle
only after every authority-sensitive use supplies exact component paths,
re-resolves the complete bundle and requires object equality with the lock; it
still does not authenticate Pilot Evidence or create qualification.

The exact LessIsMore host chain has produced the A8 runnable successor and its
distinct bounded Human-observation pass. The forward-only A8 Assembly does not
inherit or rewrite A7 evidence and is not qualification. RandomHeroes remains
resolve-only, startup-only and non-writing pending a corrected Human-approved
scope; no export preset may be added. The quality receipt runtime can represent
a positive real-project result only with a separately accepted external
evidence-authority binding; A8 has no real eleven-subject invocation/EVAL-V494
or authority/sink bundle, so professional efficacy remains incomplete.
WorkBuddy has not been contacted or invoked.

The package also contains a closed professional-efficacy dispatch-envelope
schema, exact no-tool/no-fallback policy and prompt, and a package-native
validator/dry-run preview. The dry-run surface exposes no model-call operation
and reads only explicitly supplied repository-relative artifacts. Its
recommended `gpt-5.6-sol` / `high` target remains non-dispatchable because an
immutable model build is not bound and separate Human dispatch authority has
not been granted. The external envelope and independent custody audit are
Evidence Sink artifacts outside this runtime package.

The documentation model is root-first. The root directory owns the entrypoint,
module catalog, invocation instructions, delivery rules, and AI IDE bootstrap.
Layer-local README files are pointers only and should not be used as separate
onboarding guides.

## Current Status

- Layer: `game_system_pack`
- Pack id: `end_to_end_production_pack`
- Lifecycle status: `draft`
- Engine support: `godot_2d`, `engine_agnostic`
- Supported phases: `mvp`, `production`
- Main implementation surfaces:
  - `os_layer/`
  - `pack_layer/`
  - `production_runtime/fixtures/gate_local/sp128_g7_non_writing.stage_contract_binding.json`
  - `production_runtime/tests/test_slice0_gate_local_fixture.py`
  - `production_runtime/cli.py`
  - `production_runtime/composition/`
  - `production_runtime/fixtures/derived_state/lessismore_sp129_sanitized/`
  - `production_runtime/tests/test_validation_cli.py`
  - `production_runtime/tests/test_validation_contract_schemas.py`
  - `production_runtime/tests/test_validation_derived_state.py`
  - `production_runtime/tests/test_validation_route_resolution.py`
  - `schemas/derived_state_binding.schema.json`
  - `schemas/validation_discrepancy.schema.json`
  - `schemas/validation_route.schema.json`
  - `production_packs/runtime_feature_slice/`
  - `production_runtime/composition/assembly.py`
  - `production_runtime/composition/completion.py`
  - `production_runtime/contracts/composition_profiles/`
  - `production_runtime/contracts/candidate1/`
  - `production_runtime/contracts/professional_efficacy_dispatch/`
  - `production_runtime/quality/`
  - `production_runtime/fixtures/assembly/`
  - `production_runtime/fixtures/quality/`
  - `production_runtime/tests/test_assembly_*.py`
  - `production_runtime/tests/test_quality_*.py`
  - `schemas/professional_efficacy_dispatch_envelope.schema.json`
  - `production_runtime/tests/test_godot_engine_profile.py`
  - `production_runtime/tests/test_candidate1_host_bindings.py`
  - `engine_profiles/godot/`
  - `adapters/codex/v497_candidate1.execution_adapter.json`
  - `adapters/codex/references/`
  - `adapters/AI_IDE_ADAPTER_BASE.md`
  - `adapters/codex/`
  - `adapters/codex/development_task_adapter.py`
  - `adapters/codex/multi_lane_coordinator.py`
  - `adapters/codex/multi_lane_workspace.py`
  - `adapters/codex/godot_multi_lane_profile.py`
  - `adapters/codex/development_evidence_lifecycle.py`
  - `adapters/codex/development_project_memory.py`
  - `adapters/codex/development_project_memory_lifecycle.py`
  - `adapters/codex/development_project_permissions.py`
  - `adapters/codex/permission_aware_project_retrieval.py`
  - `adapters/codex/development_project_compatibility_migration.py`
  - `adapters/codex/team_memory_provider.py`
  - `adapters/codex/local_team_memory_provider.py`
  - `adapters/codex/team_memory_status.py`
  - `bin/ai-dev-os`
  - `adapters/codex/production_worker.py`
  - `adapters/codex/godot_execution_adapter.py`
  - `adapters/codex/godot_development_build.py`
  - `adapters/codex/godot_focused_qa.py`
  - `adapters/codex/production_cell_composition.py`
  - `adapters/codex/godot_local_development_profile.py`
  - `adapters/codex/bindings/godot_runtime_feature_slice.binding.json`
  - `adapters/codex/bindings/godot_focused_qa.binding.json`
  - `adapters/codex/bindings/godot_local_development.profile.json`
  - `scripts/development/run_godot_development_build.py`
  - `scripts/development/run_godot_focused_qa.py`
  - `adapters/cursor/`
  - `adapters/workbuddy_private/`
  - `packs/game_system_packs/end_to_end_production/`
  - `scripts/delivery/`
  - `tests/delivery/`

Current closure surfaces:

- GDD orchestration.
- Shared Truth.
- Architecture Baseline.
- Controlled Small Refactor.
- Agent Harness.
- Beta Readiness.
- FixOps/problem intake.
- OS/Pack resource routing.
- Real-project attachment preflight.
- Real-project adoption contract.
- Development Runtime State task workflow.
- Development temporal-truth input binding.
- Explicit project-local development memory.
- Read-only production-spec impact replay.
- Bounded Production Worker and typed Godot local-development execution.
- Reproducible identified development build and recovery verification.
- Reusable focused QA.
- Read-only Production Spec to selected feature input bridge.
- Engine-neutral Production Cell composition.
- Godot local-development Production Cell profile.
- Project-local content-addressed Evidence Continuity MVP.
- Explicit evidence-linked Project Memory v2.
- Deterministic disposable metadata keyword index and advisory evolve bundle.
- Engine-neutral multi-lane DAG coordination and truthful aggregate state.
- Godot workspace isolation, controlled integration/build, and read-only QA.
- Append-only Evidence and Project Memory lifecycle overlays.
- Compatibility-first selected v4.95-to-v4.96 migration.
- Permission-aware source-linked retrieval before ranking.
- Optional default-off same-host Team Memory and permission-aware status CLI.
- Thin project-separated workspace summaries and a default-off single-writer
  SQLite Team Memory Provider with additive read-only v4.96 JSON import.
- Human-accepted exact LessIsMore limit-stage feedback Pilot.
- Slice 2 engine-neutral Production Assembly development baseline.
- Slice 3 Agent/Skill quality-contract harness with professional efficacy
  explicitly incomplete.
- Slice 4 Godot/Codex exact host-binding development baseline: LessIsMore
  ordinary execution-ready and RandomHeroes resolve-only.

Current v4.97 status lives in `V497_DEVELOPMENT_STATUS.md`. The canonical
pack-layer `PHASE_STATUS.md` continues to describe the inherited v4.93
Production Pack lifecycle; its root mirror remains a compatibility alias.
Version history and migration notes live in `CHANGELOG.md`.

## Capability Layers

### OS Layer

`os_layer/` provides the inherited full OS baseline:

- control plane and Orchestrator capability sheet;
- agent packs and skill foundations;
- capability protocol schemas;
- runtime, runtime DB, LTM, self-evolution, governance, mount, hub, and profile
  surfaces;
- promoted docs-only FixOps foundation in `os_layer/docs/31_fixops/`.

The OS layer is not the v4.97 total-version entrypoint. Use the root files for
whole-version navigation.

### Pack Layer

`pack_layer/` provides the inherited v4.93 production pack overlay:

- production GDD orchestration;
- specialist GDD authoring and review agents;
- delivery artifact schemas and semantic validation;
- runtime/data/art/QA handoff contracts;
- Shared Truth and Architecture Baseline validators;
- controlled refactor evidence contracts;
- Agent Harness run-plan and execution-trace protocol;
- beta readiness evaluator and report renderer;
- fixture-backed contract tests.

### Compatibility Paths

Root `packs/`, `scripts/`, and `tests/` mirror the current pack-layer
implementation for stable user commands and validation entrypoints. They should
remain aligned with `pack_layer/` until a deliberate migration removes the
compatibility surface. Use `scripts/delivery/validate_pack_layer_mirror.py` to
verify this boundary. `ROOT_MIRROR_POLICY.md` records the current decision to
keep those mirrors as stable public compatibility surfaces for the inherited
production pack while v4.97 development continues.

## AI IDE Operating Model

Codex, WorkBuddy, Cursor, or another mounted AI runtime should treat the root
files as the version contract before choosing a layer-local resource. Use this
read order for first contact:

`INDEX.md` points to the v4.97 development status before the inherited pack
contracts below are selected.

1. `INDEX.md`
2. `MANIFEST.json`
3. `README.md`
4. `DESIGN_AND_CAPABILITY_ARCHITECTURE.md`
5. `MODULES_AND_INVOCATION.md`
6. `RUNTIME_INSTANCE_CONTRACT.md`
7. `REAL_PROJECT_ADOPTION_CONTRACT.md`
8. `ROOT_MIRROR_POLICY.md`
9. `IDE_INTEGRATION.md`
10. `adapters/AI_IDE_ADAPTER_BASE.md`
11. `USER_MANUAL.md`
12. `OS_PACK_LAYER_MAP.md`
13. `os_layer/os_control_plane/leads/orchestrator.capability.json`
14. `pack_layer/packs/game_system_packs/end_to_end_production/capability_pack.json`
15. `pack_layer/packs/game_system_packs/end_to_end_production/references/end_to_end_delivery_workflow.json`
16. `pack_layer/packs/game_system_packs/end_to_end_production/docs/roadmap/PHASE_STATUS.md`

The routing shape is always:

```text
user goal
-> goal class
-> selected layer or workspace governance surface
-> owner agent or control capability
-> owner skill or workflow state
-> allowed write surfaces
-> required evidence
-> validation command
-> stop condition
```

Repository Python scripts may generate plans, contracts, reports, and
validators. They do not become an automatic LLM router and do not silently
execute agents. External runtimes consume the generated contracts, execute the
human/agent work, then return evidence such as `agent_execution_trace.json` for
validation.

AI IDE-specific adapter contracts live under `adapters/`. All adapters inherit
the shared base in `adapters/AI_IDE_ADAPTER_BASE.md`. Codex, Cursor, and
WorkBuddy have sibling adapter directories that specialize runtime behavior
without redefining canonical agents, skills, workflows, schemas, or validators.

Generated runtime state belongs in the target project or an explicit artifact
root, not in canonical v4.97 definitions. `RUNTIME_INSTANCE_CONTRACT.md`
defines the required separation between `AI_Game_Dev_OS_v4.97/`,
`target_project/.ai_dev_os/`, `target_project_artifacts/v493/`, and
repository-root `.dev_os_meta/`.

## `.dev_os_meta` Delivery Policy

The repository-root `.dev_os_meta/` directory is workspace governance state. It
is not part of the `AI_Game_Dev_OS_v4.97/` runtime package by default.

For delivery:

- exclude `.dev_os_meta/` from the version payload unless the delivery contract
  explicitly asks for workspace governance evidence;
- include `.dev_os_meta` references in manifests or reports as evidence
  pointers, not as executable package inputs;
- package accepted OS behavior only after promotion into `os_layer/`;
- package accepted production-pack behavior only after promotion into
  `pack_layer/` or the root compatibility mirrors;
- deliver raw Problem/Fix/Pattern/Self-Evo cards as a separate governance
  appendix when reviewers need provenance;
- never make runtime startup, pack validation, or agent routing depend on
  `.dev_os_meta/` being present.

## Primary Pack Resources

The root module and command map lives in `MODULES_AND_INVOCATION.md`. The files
below are implementation resources selected by that root-level contract.

- `pack_layer/packs/game_system_packs/end_to_end_production/capability_pack.json`
  - pack manifest, lifecycle status, dependency packs, agents, skills,
  allowed writes, forbidden writes, and validation commands.
- `pack_layer/packs/game_system_packs/end_to_end_production/references/end_to_end_delivery_workflow.json`
  - skill ownership, artifact routes, and workflow closure rules.
- `pack_layer/packs/game_system_packs/end_to_end_production/docs/agent_harness/RUNTIME_ADAPTER_SPEC.md`
  - external runtime adapter contract for consuming run plans and producing
  execution traces.
- `pack_layer/packs/game_system_packs/end_to_end_production/docs/beta/REAL_PROJECT_ADOPTION_CHECKLIST.md`
  - required real-project evidence before beta promotion.
- `pack_layer/packs/game_system_packs/end_to_end_production/docs/roadmap/PHASE_STATUS.md`
  - current completion state and remaining promotion prerequisites.

Primary local agents:

- `gdd_production_author`
- `gdd_creative_director`
- `gdd_module_author`
- `gameplay_systems_designer`
- `balance_economy_designer`
- `content_progression_designer`
- `gdd_review_steward`
- `game_researcher`
- `approval_gate_steward`
- `playtest_session_recorder`
- `playtest_design_synthesizer`
- `rawdata_chain_executor`
- `godot_runtime_slice_engineer`
- `ui_asset_runtime_binder`
- `focused_qa_evidence_runner`
- `visual_stop_steward`
- `delivery_readiness_runner`

## Minimal Workflows

### Start A GDD Run

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/run_gdd_orchestrator.py start \
  --intent "反向塔防：护送怪物下班"
```

This writes a planned run package, not the final authored GDD prose. A runtime
adapter or AI IDE must read the generated agent brief, execute the owner agents,
and return artifacts for validation.

Validate the run package or completed outputs:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/run_gdd_orchestrator.py validate \
  --artifact-root <artifact_root>
```

### Attach A Real Project

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/evaluate_pack_beta_readiness.py \
  --project-root <project_root> \
  --artifact-root <delivery_artifact_root> \
  --dry-run \
  --write-report /tmp/v493_beta_readiness_dry_run.json
```

A first real-project dry run may be `BLOCKED`. Treat blockers as routing input,
not as proof that the OS failed.

### Use An External Agent Runtime

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/generate_agent_run_plan.py \
  --artifact-root <delivery_artifact_root> \
  --write-plan /tmp/v493_agent_run_plan.json
```

The runtime adapter consumes the plan and returns an `agent_execution_trace.json`.
Validate it with:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_agent_execution_trace.py \
  --run-plan /tmp/v493_agent_run_plan.json \
  --trace <agent_execution_trace.json>
```

Only runtime-produced traces can support beta promotion. Sample traces are
regression evidence only.

## Validation

Root compatibility contract tests:

```bash
python3 -m pytest AI_Game_Dev_OS_v4.97/tests/delivery/test_v493_end_to_end_skill_contracts.py -q --tb=short
```

Pack-layer mirror contract tests:

```bash
python3 -m pytest AI_Game_Dev_OS_v4.97/pack_layer/tests/delivery/test_v493_end_to_end_skill_contracts.py -q --tb=short
```

OS-layer boundary docs test:

```bash
python3 -m pytest AI_Game_Dev_OS_v4.97/os_layer/tests/test_v493_layer_boundary_docs.py -q --tb=short
```

Project Evidence Continuity tests:

```bash
python3 -m pytest AI_Game_Dev_OS_v4.97/os_layer/tests/runtime_state/test_codex_development_project_evidence.py -q --tb=short
```

Complete successor-local Production Runtime contract, Assembly, quality,
Godot-profile and host-binding tests:

```bash
python3 -m pytest AI_Game_Dev_OS_v4.97/production_runtime/tests -q --tb=short
```

Focused non-executing professional-efficacy dispatch-envelope tests:

```bash
python3 -m pytest AI_Game_Dev_OS_v4.97/production_runtime/tests/test_quality_dispatch.py -q --tb=short
```

After an external envelope is frozen, its zero-write preview is invoked with:

```bash
PYTHONPATH=AI_Game_Dev_OS_v4.97 python3 -m production_runtime.quality.dispatch \
  dry-run --envelope <external_dispatch_envelope.json> --repository-root .
```

This command validates exact bytes and Git objects, prints to stdout, and
cannot call a model, access a project clone, use the network, or contact
WorkBuddy.

Passing this entrypoint verifies the development contracts and implementations
under test. It is not Pilot completion, professional-efficacy evidence, Human
observation, adoption, release, or production/live authority.

Markdown path checks:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_markdown_local_paths.py
python3 AI_Game_Dev_OS_v4.97/pack_layer/scripts/delivery/validate_markdown_local_paths.py
```

Mirror sync check:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_pack_layer_mirror.py
```

Release snapshot freshness diagnosis for ordinary development:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_release_snapshot_freshness.py
```

This diagnostic may report a missing or stale snapshot without blocking
ordinary development. The `--strict` form is release-snapshot-only and is
listed in `DELIVERY_CONTRACT.md`; it applies only after that delivery scope is
explicitly selected.

Transient file diagnosis:

```bash
python3 AI_Game_Dev_OS_v4.97/scripts/delivery/validate_delivery_transients.py --strict
```

Patch hygiene:

```bash
git diff --check -- AI_Game_Dev_OS_v4.97
```

## Boundaries

- Do not treat `os_layer/README.md` as the full v4.97 version README.
- Do not treat `pack_layer/README.md` as the full v4.97 version README.
- Do not auto-call LLM agents from repository scripts.
- Do not promote `lifecycle_status` from `draft` without real-project beta
  readiness evidence and a reviewed runtime-produced agent trace.
- Do not make repository-root `.dev_os_meta/` runtime package content.
- Do not treat fixture-only success as real-project adoption evidence.
- Do not treat LessIsMore ordinary execution-readiness as qualification or as
  evidence that the feature/build has already run.
- Do not write or execute RandomHeroes while its host chain is resolve-only.
- Do not contact WorkBuddy without the separately approved exact non-writing
  invocation.
- Do not commit generated exploratory GDD outputs unless they are intentional
  regression fixtures.
