# v4.95 Package Identity Reconciliation

Status: bounded development-package identity refresh; not qualification, Gate,
package promotion, checksum rebuild, release acceptance, or live authority.

## Comparison Boundary

The reproducible package-root comparison is:

```text
v4.94 source commit:          b7e400db6ee7da3f9b0fcb56fe976c762ebd12e3
v4.94 package tree:           d64399d0a43ca293d6717b4a4ddf0a6c3b178d50
v4.95 first commit:           1107d39b0ea01ca923f734b69ad64580f4f4631f
identity-refresh preimage:    a653655dd2770e4f678b2957240f30afaa4b9303
v4.95 preimage package tree:  a48092626bddb74e9be2326cc669d6dc7818affd
```

The trees are compared as package roots, not by their different directory
names:

```bash
git diff --no-renames --name-status \
  b7e400db6ee7da3f9b0fcb56fe976c762ebd12e3:AI_Game_Dev_OS_v4.94 \
  a653655dd2770e4f678b2957240f30afaa4b9303:AI_Game_Dev_OS_v4.95
```

This report and the subsequent identity-refresh edits are intentionally outside
that preimage. The inventory remains reproducible after the refresh.

## Exact Preimage Inventory

The frozen v4.94 package contains 2,377 tracked files. The v4.95 preimage
contains 2,401 tracked files:

- 2,367 inherited paths are byte-identical to the v4.94 package baseline;
- 24 paths are added by v4.95 Production-foundation development;
- 10 inherited paths have bounded v4.95 modifications;
- no inherited path is deleted or renamed.

| Package area | Added | Modified | Meaning |
| --- | ---: | ---: | --- |
| root | 1 | 2 | v4.95 status plus README/changelog development pointers |
| `adapters/` | 9 | 4 | Worker, Godot execution/build/QA, composition, bindings, and Codex routing |
| `os_layer/` | 5 | 0 | focused tests for the new Production primitives |
| `pack_layer/` | 2 | 2 | reusable development CLIs and bounded Godot Agent/Skill operations |
| root `packs/` mirror | 0 | 2 | byte-aligned Agent/Skill compatibility mirror updates |
| root `schemas/` | 5 | 0 | Worker/build/QA/composition binding and receipt contracts |
| root `scripts/` mirror | 2 | 0 | byte-aligned reusable development CLIs |
| **total** | **24** | **10** | **34 paths differ from v4.94** |

The added and modified surface is exactly the v4.95 Production-foundation line
recorded in `V495_DEVELOPMENT_STATUS.md`. It does not include an engine profile
other than `godot_local_development_v1`.

## Manifest Findings

At the identity-refresh preimage:

| Object | Blob | Finding |
| --- | --- | --- |
| root `MANIFEST.json` | `5b45bf7f3e93d46d3b8609f99c694fbb5a776677` | byte-identical to v4.94 and still declares the v4.94 root identity |
| root version-manifest schema | `0de20a27561165d743239dfaa277c3d38ffde01d` | byte-identical to v4.94 and constrains current paths to v4.94 |
| `os_layer/MANIFEST.json` | `1b09d98cb2cb3a21d53cee2d71ca8b7879fae27d` | inherited Core view declaring `4.92-Release`; provenance only |
| `os_layer/RELEASE_MANIFEST.json` | `1ec7216b3f32bbb9ac2d383e12b54029eef5dac4` | inherited v4.94-era OS-layer inventory, not v4.95 whole-package closure |
| `os_layer/CHECKSUMS.sha` | `0d944c3abf13722238843f3a7327aca385309334` | inherited OS-layer checksum surface, not v4.95 whole-package closure |

Changing only `version_id` would be false identity because the root schema,
entrypoint paths, adapter inventory, command roots, and provenance boundary
would still disagree.

## Reconciliation Decision

The v4.95 development package identity is the whole
`AI_Game_Dev_OS_v4.95/` source tree. The bounded refresh therefore updates:

1. the root manifest and its direct schema;
2. current root entry documents and command paths;
3. the current Codex/Production capability inventory;
4. mirrored static assertions that validate the root identity; and
5. the v4.95 changelog and development status.

The refresh deliberately preserves:

- the frozen v4.94 comparison commit and package-tree identity above;
- `V494_DEVELOPMENT_STATUS.md` and
  `V494_PACKAGE_IDENTITY_RECONCILIATION.md` as historical records;
- the inherited v4.93 production-pack IDs, artifact namespace, fixtures, and
  historical test filenames;
- the OS-layer Core manifest, release manifest, checksums, and `VERSION` bytes
  as provenance rather than relabeling them as v4.95 closure;
- the OS-layer `V494_RUNTIME_STATE_PACKAGE_APPROVAL` environment-classifier
  paths and fixture contract literals. They are deliberately pinned to their
  protected v4.94 approval identity and must not be relabeled as v4.95 without
  a separately authorized migration and qualification transaction;
- `lifecycle_status: "draft"` and every qualification, Gate, promotion,
  release, distribution, and production/live non-claim.

## Resulting Identity Boundary

After this refresh, `MANIFEST.json` may identify the root as a v4.95
Production-foundation development candidate. That means the current root
entrypoints and validation commands resolve coherently from the v4.95 package
directory. It does not mean:

- the inherited OS-layer release inventory has been rebuilt;
- the v4.93 production pack has changed lifecycle status;
- qualification or any Gate has run;
- a release snapshot, tag, distribution artifact, or production deployment
  exists; or
- the Godot profile implies support for another engine.

Ordinary root-document incompleteness remains repairable development work. A
false current identity, overwritten historical provenance, promoted authority,
or relabeled stale release inventory is a hard stop.
