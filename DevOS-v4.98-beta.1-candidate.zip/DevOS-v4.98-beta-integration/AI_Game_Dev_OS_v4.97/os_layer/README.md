# AI Game Dev OS v4.93 OS Layer Pointer

> **v4.93 embedding note**: inside `AI_Game_Dev_OS_v4.93/`, this directory is
> the `os_layer/` baseline and promoted OS-layer surface. It is the
> implementation surface for the inherited v4.92 OS baseline and promoted
> OS-layer additions. It is not the full v4.93 entrypoint.

Start from the v4.93 root files:

1. `../README.md`
2. `../INDEX.md`
3. `../MANIFEST.json`
4. `../MODULES_AND_INVOCATION.md`
5. `../IDE_INTEGRATION.md`
6. `../USER_MANUAL.md`
7. `../OS_PACK_LAYER_MAP.md`

For v4.93, external onboarding should start at the repository root, not inside
this layer.

v4.93 onboarding, evaluation, and trial runs enter through the repository root
by default, then route into this directory only for selected OS-layer resources.

## Scope

This layer contains OS implementation and baseline resources:

- `agent_packs/`
- `capability_protocols/`
- `docs/`
- `docs/31_fixops/`
- `evolution/`
- `hub/`
- `ltm/`
- `os_control_plane/`
- `runtime/`
- `runtime_db/`
- `schemas/`
- `skills/`

The v4.92 release identity and older v4.90/v4.91 lineage remain baseline
provenance. v4.93 onboarding, module selection, invocation instructions,
delivery rules, and AI IDE integration are centralized at the version root.

## Boundary

- Do not treat this README as the v4.93 version README.
- Do not add v4.93 production-pack calling instructions here.
- Promote accepted OS behavior into this layer only after root-level governance
  and delivery rules allow it.
- Keep whole-version facts in `../README.md`, `../INDEX.md`,
  `../MANIFEST.json`, and `../MODULES_AND_INVOCATION.md`.
