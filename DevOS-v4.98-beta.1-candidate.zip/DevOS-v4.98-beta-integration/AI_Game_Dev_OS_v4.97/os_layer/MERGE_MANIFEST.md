# MERGE MANIFEST

This package is distributed with the archive root directory:
`AI_Game_Dev_OS_v4.92_Release`

## Packaging rule

The manifest root directory name is intended to match the actual top-level directory created when the package is extracted.

## Current release rule

1. `AI_Game_Dev_OS_v4.92_Release/` is the formal entry package
2. process-oriented build history may exist in sibling directories, but is not part of the clean release identity
3. required release content is defined by `RELEASE_MANIFEST.json`
4. byte-lock baseline for the tree is captured in `CHECKSUMS.sha` (see `RELEASE_NOTES.md` §8 for the verification recipe)
