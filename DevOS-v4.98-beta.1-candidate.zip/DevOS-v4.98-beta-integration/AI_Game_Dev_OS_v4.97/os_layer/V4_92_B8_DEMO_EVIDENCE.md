# v4.92 Batch 8 — Capability Foundation Demo & Evidence Summary

> **Status**: Demo complete · **Date**: 2026-05-31 · **Author**: Kai
> **Scope**: OS tree (`AI_Game_Dev_OS_v4.92`) — no target-project changes in this batch.

This document is the consolidated, reproducible evidence for the v4.92
**AI Production Capability Foundation**. It ties Batches 0–7 together and points
at the single end-to-end demo that exercises the whole stack.

---

## 1. One-command reproduction

The demo runs the entire capability chain against the two real packs in this
tree, in a throwaway project dir (the OS tree is never written):

```bash
cd AI_Game_Dev_OS_v4.92
python3 scripts/capability/run_capability_demo.py          # human-readable
python3 scripts/capability/run_capability_demo.py --json   # machine summary
```

Expected tail:

```
STEP 1 — B5 set_nested_value v2 — $key array-element injection
  PASS — grouped by hero_id, indexed by state; unmatched key raised
STEP 2 — B2 governance — boundary linter (both packs) + practicality gate
  PASS — boundary linter clean over both packs
  PASS — practicality gate PASS over 3 data_pipeline skills
STEP 3 — B3 adoption — recommend -> adopt -> validate -> lock (verified)
  PASS — data_pipeline_pack reached adoption_status=verified with a lock
STEP 4 — B6 evidence — rollback note + validation evidence + verify
  PASS — rollback + evidence recorded; verify confirms a complete set
STEP 5 — summary
  PASS — all capability stages passed
DEMO_OK
```

The demo invokes its sub-tools with the *same* interpreter that launches it, so
running it under the managed `python3` (which has **no jsonschema**) proves the
whole chain is zero-dependency. `tests/capability/test_capability_demo.py`
asserts both the standard run and the bare-interpreter run reach `DEMO_OK`.

---

## 2. What the demo chains (and where it comes from)

| Demo step | Batch | Artifact exercised |
|---|---|---|
| 1. `$key` array injection | **B5** | `packs/game_system_packs/data_pipeline/reference/nested_set.py` |
| 2. boundary linter | **B2** | `scripts/capability/run_boundary_linter.py` over both packs |
| 2. practicality gate | **B2** | `scripts/capability/run_practicality_gate.py` over 3 skills |
| 3. adopt → verified + lock | **B3** | `scripts/capability/adopt_pack.py` (recommend/adopt/validate/lock) |
| 4. rollback + evidence + verify | **B6** | `scripts/capability/record_task_evidence.py` |

The packs themselves (B4 godot_2d adapter, B5 data_pipeline) embody B1's three
contracts (pack / agent / skill schemas), so step 2's clean linter/gate run is
also implicit proof of B1.

---

## 3. Batch-by-batch deliverables (B0–B8)

| Batch | P0 | Deliverable | Key artifacts |
|---|---|---|---|
| **B0** | — | Planning alignment | tree cut (1368 files), Charter §10 signed, scope lock |
| **B1** | P0-1/2/3 | Capability schemas | `capability_protocols/{capability_pack,agent_contract,skill_contract}.schema.json` + 3 docs |
| **B2** | P0-4/5 | Validators (zero-dep) | `run_practicality_gate.py`, `run_boundary_linter.py` + 7 fixtures |
| **B3** | P0-6/7 | Adoption runtime | `adopt_pack.py`, adoption_state + pack_lock schemas |
| **B4** | P0-8 | Godot 2D adapter pack | `packs/engine_adapters/godot_2d/` (manifest+agent+2 skills+4 templates+validator) |
| **B5** | P0-9 | Data Pipeline vertical slice | `packs/game_system_packs/data_pipeline/` + reference impls; **target fix** (`set_nested_value` v2) committed in target repo `52e5008` |
| **B6** | P0-10 | Production three-piece set | handoff/rollback/evidence schemas + `record_task_evidence.py` |
| **B7** | — | Minimal hooks + lint roots | 5 hook stubs (R7) + lint-root extension (caught 5 project-name leaks) |
| **B8** | — | Demo & evidence | `run_capability_demo.py` + this summary |
| **B5.5** | P0-9 (closure) | Output Adapter true abstraction | `reference/{output_adapter,adapter_contract,json_adapter}.py` + `test_output_adapter.py`; Phase 4 tools `{list_available_packs,validate_active_packs,export_pack_report}.py` |

---

## 4. Cumulative acceptance (as of B8)

| Metric | Value |
|---|---|
| capability tests | **71 passed** (`tests/capability/`) |
| joint regression (capability + contracts + manifest) | green |
| governance suite | 152 passed |
| layer-separation lint roots | **72**, 0 violations (zero project proper-names) |
| docs front-matter | clean |
| `RELEASE_MANIFEST.json` required count | **1281** (`--check` clean) |
| v4.91 byte-lock (inv_001) | **untouched** across all of v4.92 |

---

## 5. The vertical slice, proven (B5)

The headline outcome: a numeric-game data pipeline pain point solved end-to-end
on a real target project.

- **Defect**: a composite per-entity table (`heroes`) used `$hero_id` to inject
  animation/sfx rows into array elements; the naive `set_nested_value` couldn't
  walk into arrays, forcing `skip_convert: true` and a hand-merged JSON.
- **Fix**: `set_nested_value` v2 — `$key` segment groups rows by a field,
  matches the array element, indexes sub-records by `state`, and raises (never
  silently drops) on an unmatched key. A `postprocess_heroes` step reshapes flat
  columns into the nested runtime contract (`base_stats`/`growth`/`leveling`).
- **Full-chain acceptance**: edit `heroes.xlsx` `base_hp` 100→150 → auto-convert
  → validator PASS → runtime reads `base_stats.hp == 150`. The pity Monte Carlo
  script, wrapped by `pity_gate.py`, now acts as a blocking pipeline gate.

This is the concrete demonstration that the capability foundation produces
**working, runtime-faithful** output — not just well-formed contracts.

### P0-9 closure (Batch 5.5)

An EP review caught that the output stage was hardwired to JSON. Rather than
hardwire it *or* speculatively build a `.tres` adapter the real (pure-JSON)
target would never use, B5.5 made the output stage a **true abstraction**: an
`OutputAdapter` interface (`name` / `target_extension` / `write → AdapterResult`)
plus `check_adapter` — the universal compliance contract — with `json_adapter`
as the first concrete implementation. Adding SQLite/`.tres` later is a
*one-file, contract-verified* task that changes **zero** existing pack code.
Phase 4 project-adoption tools (`list_available_packs` / `validate_active_packs`
/ `export_pack_report`) were completed in the same batch. See
`docs/30_capability_packs/DATA_PIPELINE_PACK.md` §7–§9.

---

## 6. Next

**Batch 9 = Release Gate + tag** — full gate replay, RELEASE_NOTES, manifest
final check, and the v4.92 tag. This closes the v4.92 batch ladder.
