# AI Game Dev OS v4.94 Source Package Notes

> **PKG-1 Tranche 1 status (2026-08-01)**: source implementation only. The
> package has not been imported, executed, migrated, fixture-run, tested, or
> qualified by this tranche. Gate B remains blocked pending independently
> reviewed Tranche 2 authority and results.

The v4.94 canonical OS layer adds a single-profile, fixture-only Runtime State
Service design bound to `B2-FIXTURE-LOCAL@1.0.3` and `SEC-0`. The State Service
command API is the sole mutation surface. Service lifetime locking, monotonic
writer epochs, client/internal-context separation, compare-and-swap,
idempotency, commit-chain receipts, projection bindings, and verified fixture
backup/restore are represented in source, contracts, and not-yet-run tests.

The assurance slice packages `EVAL-V494`, `THREAT-V494`, `DATA-V494`,
`MIR-V494`, and `TRACE-V494` 1.0.0 contracts with M0A-N01..N20 synthetic
negative fixtures. A producer cannot be the sole final evaluator.

This source package makes no physical-isolation, portability, performance,
recovery, security-qualification, production, promotion, adoption, or Human
approval claim. It creates no `.ai_dev_os/state` root or runtime database.

## Historical embedded v4.92 notes

> **v4.93 embedding note**: this is historical OS baseline provenance inherited
> into `AI_Game_Dev_OS_v4.93/os_layer/`. It is not a v4.93 release note and it
> is not a v4.93 entrypoint. If v4.93 needs release notes, they belong at the
> `AI_Game_Dev_OS_v4.93/` root next to `README.md`, `CHANGELOG.md`, and
> `MODULES_AND_INVOCATION.md`.

> **Release target**: `v4.92-release` (annotated tag)
> **Release date**: 2026-06-04
> **Package root**: `AI_Game_Dev_OS_v4.92_Release/`
> **Predecessor**: `AI_Game_Dev_OS_v4.91_Release/`
> **Theme**: production capability protocol, pack adoption, agent/skill migration,
> and evidence-gated v4.92 closure.

## v4.92 Final Scope

v4.92 supersedes the earlier `v4.92-Capability_Foundation` checkpoint with the
REOPEN B10-B13 closure line:

1. B10 agent migration and contract alignment.
2. B11 skill migration closure, including deprecated-read-only handling for old
   skill surfaces.
3. B11.5 executive-producer control-plane hardening.
4. B12 evidence-gate hardening and validation evidence repair.
5. B13 whole-version consistency scan, release-dir identity transition, and
   clean release package preparation.

The release package carries `4.92-Release`, `AI_Game_Dev_OS_v4.92_Release`,
`package_name = AI_Game_Dev_OS_v4.92`, `base_from =
AI_Game_Dev_OS_v4.91_Release`, and `.core_os_root = v4.92-marker`.

## Evidence Summary

- pytest successor baseline: 1949 passed / 2 skipped.
- Layer 1 lint successor baseline: 72 roots / 0 violations.
- frozen v4.90 RC3 closure gate remains unchanged; the dispatcher adds v4.92
  successor C1/C2 and release-dir C9-C13 overlays.
- full closure with deliverables is valid only after the annotated
  `v4.92-release` tag and workspace-level release rehearsal evidence exist.

## Historical Notes

The cumulative v4.90/v4.91/v4.92 notes continue below for lineage. Historical
v4.90 gate descriptions below are not the current v4.92 release gate; current
v4.92 full closure uses the frozen RC3 A/B contract plus v4.92 C1/C2 and
C9-C13 overlays.

# AI Game Dev OS v4.90 Release Notes

> **Release target**: `v4.90-release` (annotated tag)
> **Release date**: 2026-05-17 (frozen + hygiene-aligned + portability-aligned + polish-aligned + precision-aligned + stability-aligned + hardening-aligned + fast-full-split-aligned + dual-gate-semantics-aligned + pipe-deadlock-hardened) + 2026-05-18 (v4.91 F-T-01 + F-V-01 — Multi-Tenant Runtime Sovereignty: tenancy boundary contract + tenancy-aware verifier/lint) + 2026-05-19 (v4.91 B0 — Gate Runner Final Polish: gate_report 5-state status; v4.91 B1 — Central Runtime Hub Core: 8 CLIs + flock+2PC + 5 schemas + 35 hub tests + F9 hub-smoke fast-gate item; v4.91 B2 — Project Mount + Boundary Contracts: 2 mount schemas + 26 mount tests + validate_project_mount two-tier acceptance + MOUNT_CONTRACT.md) + 2026-05-20 (v4.91 B3 — Version Lock & Core Update Policy: 4 version schemas + 3 hub CLIs (lock_core_version + check_core_update_impact + generate_upgrade_plan) + Core abstract identity surface (MANIFEST.json + CHECKSUMS.txt) + policies/core_update_policy.md + 19 version tests + F10 version-lock-smoke fast-gate item — Milestone A CLOSED, tag v4.91-M-A, fast 13/13) + **2026-05-20 (v4.91 Addendum-A — External Core Mount by Default Rule: schema 1.0.0 → 1.1.0 widening on mount + version_lock + host_profile + detect_embedded_release_bundle.py + 12 VPM-* checks + 4 host profile YAMLs (workbuddy/codex/cursor/claude_code) + docs reorg (MOUNT_CONTRACT to 20_project_mount/) + 4 new docs + policies/charter_anti_patterns.md (14-pattern SSoT) + 44 tests + F11 detect-bundle-smoke fast-gate item — Charter anti-pattern #14 No Full Release Copy by Default formalised, tag v4.91-Addendum-A, fast 14/14) + **2026-05-21 (v4.91 M-B B4 — Shared LTM v3 Read-Side Pipeline: 4 v3 schemas (retrieval_policy + routing_report + preflight_case + preflight_metric) + 2 read-only CLIs (retrieve_with_routing + generate_routing_report) + ltm/retrieval_policy.yaml default + 7 skeleton dirs (cross_project + preflight) + 3 docs in docs/22_ltm_v3 + 35 tests (incl. Charter #7 alpha→beta end-to-end isolation) + F12 ltm-v3-smoke fast-gate item — Milestone B B4 CLOSED, tag v4.91-M-B-B4, fast 15/15)** + **2026-05-21 (v4.91 M-B B5 — LTM Write/Promotion Gates: 4 ledger/policy schemas (promotion_policy + promotion_ledger + reject_ledger + supersede_ledger) + promote_memory_candidate v3 extension (auto-migrate to approved_patterns/) + 2 NEW lifecycle CLIs (reject_memory_candidate + supersede_memory_candidate) + ltm/promotion_policy.yaml default + docs/22_ltm_v3/PROMOTION_LIFECYCLE.md + 43 tests (incl. multi-step roundtrip + audit chain cross-ref) + F13 ltm-lifecycle-smoke fast-gate item — Milestone B B5 CLOSED, tag v4.91-M-B-B5, fast 16/16)** + **2026-05-22 (v4.91 M-B B5B — Multi-Agent Preflight Consensus Enforcement: 2 schemas (preflight_policy + preflight_consensus_event_ledger, 1.0.0) + run_preflight_consensus.py + lock_core_version preflight gate (EXIT_PREFLIGHT_NOT_APPROVED=5) + generate_upgrade_plan stub emission + 45 tests + F14 preflight-consensus-smoke fast-gate item — Milestone B B5B CLOSED, tag v4.91-M-B-B5B, fast 17/17)** + **2026-05-22 (v4.91 M-B B6 — Evolution Capture: memory_candidate +OPTIONAL capture_source 5-enum (schema_version 1.0.0 const) + capture_evolution_proposal NEW (dual-rail mutex) + capture_sprint_close auto-emit on gate=blocked (preserves EXIT_GATE_BLOCKED) + extract_failure_candidates --source 2-enum + docs/22_ltm_v3/EVOLUTION_CAPTURE.md + 33 tests + F15 capture-pipeline-smoke fast-gate item — Milestone B B6 CLOSED, tag v4.91-M-B-B6, fast 18/18)** + **2026-05-22 (v4.91 M-B integral close: B4 + B5 + B5B + B6 rolled up — Milestone B CLOSED, tag v4.91-M-B, fast 18/18)** + **2026-05-22 (v4.91 Addendum-B — Link Alias Removal: schema enum narrowed across 6 schemas (project_mount + version_lock + host_profile + 3 hub schemas) from 4 values to 3 forward-only [external_core, thin_scaffold, vendor_snapshot] — Charter anti-pattern #15 No mount_mode aliases formalised, Addendum-B CLOSED, tag v4.91-Addendum-B, fast 19/19)** + **2026-05-31 (v4.92 Capability Foundation — AI Production Capability packs/agents/skills layer: B1 capability schemas (capability_pack + agent_contract + skill_contract, P0-1/2/3) + B2 zero-dep validators (Practicality Gate + Boundary Linter, P0-4/5) + B3 adoption runtime (adopt_pack recommend→adopt→validate→lock + adoption_state/pack_lock schemas, P0-6/7) + B4 Godot 2D engine-adapter pack (P0-8) + B5 Data Pipeline vertical slice (set_nested_value v2 $key array-injection + reshape + schema_check + pity_gate, validated on a real pure-JSON Godot target, P0-9) + B6 production three-piece evidence (handoff/rollback/evidence + record_task_evidence, P0-10) + B7 minimal hooks + packs/ lint-root family + B8 zero-dep end-to-end demo + **B5.5 P0-9 closure: OutputAdapter true abstraction (interface + adapter_contract + json_adapter first impl) + Phase-4 adoption tools (list_available_packs / validate_active_packs / export_pack_report)** + B9 release gate (full closure gate 13/13 PASS, baseline override re-based 1763/67 → 1874/72 EP-approved) — capability tests 93, joint regression 1874/2, layer separation 72 roots / 0 violations, v4.91 + v4.89 byte-locks untouched, tag v4.92-Capability_Foundation)**
> **Predecessor**: `AI_Game_Dev_OS_v4.89_Release/` (byte-locked baseline tree SHA `bb48af169f9b…87767`, 540 files)
> **Branch at freeze**: `release/v4.90-fork`
> **Theme**: Progressive Adoption & Protocol-Compatible Memory-Governed Pack Runtime
> **Patches**: v4.90.1 (identity unification + clean-tree checker) → v4.90.2 (portability + doc baseline + pack baseline dual-track) → v4.90.3 (final polish: pytest baseline 920 + RELEASE_NOTES sync + ltm consult status + clean_transients helper + closure gate timeout flag) → v4.90.4 (doc polish: CLI_USAGE_GUIDE skeleton sweep + RELEASE_NOTES §4 heading + 2026-05-1X / 待打 sweep + README --pytest-timeout hint) → v4.90.5 (doc precision: CLI script names + Current leaf shape + RELEASE_NOTES fact corrections) → v4.90.6 (active-state label sweep) → v4.90.7 (aggregate stability: schema_self_validation reordering + PYTEST_DISABLE_PLUGIN_AUTOLOAD isolation + closure gate `--aggregate-timeout` flag) → v4.90.8 (closure gate hardening: process-group-safe `_run()` Popen + `killpg` + opt-in `--pytest-disable-plugin-autoload` for C1 + slow-CI doc upgrade) → v4.90.9 (B-CG closed: fast/full closure gate split via new `run_release_closure_gate.py` dispatcher + PG-safe runner extraction to `_process_runner.py` shared by closure gate / required regressions / consistency aggregate + project_profile schema 1.0.0→1.1.0 with required `game_dev_phase` field decoupled from lifecycle `stage` + `init_project_runtime.py --game-dev-phase` auto-derives from `--stage`) → **v4.90.10 (optional polish: soft `benchmark target` / `typical range` timing language replacing hard ≤10s / ≤180s claims + dual-gate semantics — fast = reviewer smoke gate, full = final release evidence gate, with explicit "fast is NOT a substitute for full at release time" — plus a maintainer laptop verification record: pytest 946/2 in 29.46s, full gate 8/8 in 31.74s, fast gate 3-run avg 6.35s) → v4.90.11 (fast gate F5/F7 pipe-deadlock hardening via `run_pg_safe_to_file` file-capture replacing `subprocess.PIPE` whose 64 KB OS buffer used to wedge fast gate on slow CI / sandbox; new `--fast-aggregate-wall-timeout` flag (default 300s) decouples wall-clock budget from per-sub-check timeout; full release evidence gate **13/13 PASS** on maintainer laptop; doc alignment: §4 title now reflects v4.90.11 patched state, evidence bands 8/8 = A+B / 13/13 = A+B+C explicit; +7 tests → 953 passed) → **v4.91 Batch 14.19 (Gate Runner Architecture Patch — fast gate restructured from "nested pytest validator" into a flat, killable, log-recorded, non-recursive smoke gate. Concrete deltas: (a) `_process_runner.py` v2 API — `RunResult` dataclass + new `cleanup_process_group_on_exit` keyword on both PIPE and file-capture runners reaps lingering grandchildren after a normal child exit; (b) F7 (single big nested-pytest item) split into F7 (4 direct CLI smoke commands) + F8a/F8b/F8c/F8d (4 small safe pytest batches); fast gate now 11 items total, gate-runner self-tests deliberately excluded from fast gate to break the "gate validates itself" recursion; (c) new `--fast-total-timeout SECS` (default 600) outer wall-time supervisor caps the entire fast gate so the dispatcher cannot hang past budget; (d) every F-item writes its captured stdout/stderr to `exports/closure/fast_gate_logs/`; the dispatcher emits `exports/closure/fast_gate_report.{json,md}`; (e) pytest markers `fast_gate_safe` / `gate_runner` / `full_regression` registered, conftest auto-tags by file path; (f) 6 governance / contracts test fixtures migrated from plain `subprocess.run(capture_output=True, timeout=...)` to `run_pg_safe_to_file_v2`; (g) new anti-hang test suite `test_process_runner_grandchild_cleanup.py` (5 tests). Patch chain banner: `v4.90.1..v4.91-batch14.19`. At that v4.91 patch point, full gate (--profile full) still used the RC3 13-check contract.)**. This document reflects the v4.91 Batch 14.19 patched state.

---

## 1. What v4.90 is

v4.90 is the AI Game Dev OS release that turns "real-project adoption experience" into productised, protocol-compatible infrastructure. It is the line that makes:

- a **legacy project** able to incrementally pick up the OS surface without big-bang rewrites (Progressive Adoption);
- a **state surface** auditable in two strictly separated layers — OS Core spec vs. Project case study (State Surface Governance);
- a **memory layer** capable of capturing, retrieving, promoting, and quarantining LTM/failure-fix entries (LTM v2);
- an **agent library** with cluster-organised packs and lifecycle states (Agent Library / Pack);
- a **self-evolution** ledger that accepts proposals but never auto-mutates canonical content (proposal-only);
- a **unified CLI** entry that aggregates migration / ltm / pack / evolve leaves (governance scripts are invoked directly, not via the wrapper);
- a **protected behavior contract** with 7 enforced invariants guarding byte-lock, Layer 1, state machines, audit envelope, naming, capability_id, and schema_version.

v4.90 is **Tier 2 release-grade for the listed surfaces**, with **proposal-only / SCAFFOLD-or-GUIDED tiering** explicitly declared per surface.

---

## 2. What's new since v4.89

### 2.1 Progressive Adoption Framework — `docs/13_migration/` (Batch 1, Batch 2, Batch 2.5)

- 9 docs (`PROGRESSIVE_ADOPTION_GUIDE`, `CAPABILITY_COMPATIBILITY_MATRIX`, `LEGACY_CONFLICT_RESOLUTION_GUIDE`, `MIGRATION_RISK_REGISTER`, `PROJECT_INIT_GUIDE`, `PROJECT_RUNTIME_PROTOCOL`, `ADOPTION_STATE_MODEL`, `V4_82_TO_V4_89_COMPATIBILITY_NOTES`, `README`).
- 14-row capability compatibility matrix (`docs/13_migration/CAPABILITY_COMPATIBILITY_MATRIX.md`); 14/14 scored.
- `scripts/migration/` — `scan_legacy_project.py`, `detect_project_protocol.py`, `adopt_capability.py`, `generate_capability_queue.py`, `generate_migration_report.py`, `validate_capability_adoption.py`, `validate_protocol_compatibility.py` — 7 GUIDED entry points; `ai-dev-os migration {handshake,plan,verify,report}` are CLI alias forms over the same dispatch (see `docs/18_cli/CLI_USAGE_GUIDE.md §4`).
- `scripts/adoption/` — `init_project_runtime.py` (GUIDED) + `validate_adoption.py` (GUIDED) + `run_mock_harness.py` (GUIDED CLI with 4 fixture presets). Note: `scan_legacy_project.py` lives under `scripts/migration/` (not `scripts/adoption/`); v4.90.0 RELEASE_NOTES had this misplaced and v4.90.5 corrected it.
- `tests/fixtures/mock_legacy_project_baseline/` — Layer 1 root fixture for harness testing.
- New schemas: `adoption_report.schema.json`, `legacy_scan_result.schema.json`, `capability_adoption_state.schema.json`.

### 2.2 State Surface Governance — `docs/14_state_surface_governance/` (Batch 3, Batch 3.5)

- 7 docs total (incl. one Layer 2 case `STATE_SURFACE_MIGRATION_CASE_SP115.md`).
- Strict Layer 1 / Layer 2 separation rule: **OS Core Spec MUST NOT contain project names; CI greps and asserts zero hits.**
- 3 governance schemas: `state_surface_policy`, `current_state_surface`, `cold_start_readset`.
- 5 governance scripts (GUIDED): `audit_state_surface_size`, `validate_current_state_surface`, `validate_cold_start_readset`, `validate_registry_sync_guard`, `lint_layer_separation`.
- `project_runtime_protocol` schema gains a `governance` node.

### 2.3 LTM v2 + Failure-Fix Memory — `docs/15_ltm_v2/` (Batch 4)

- LTM v2 docs + failure-fix schema (`schemas/ltm/failure_fix_entry.schema.json`).
- `scripts/ltm/` — `validate_failure_fix_entry` (GUIDED), `capture_sprint_close` (GUIDED, lifted from STUB during Batch 5.5), `extract_failure_candidates`, `promote_memory_candidate`, `quarantine_entry`, `validate_memory_quality`.
- Layer B FTS5 retrieval engine (`runtime/ltm/_fts5_index.py`) with opt-in fallback (Layer A engine remains primary).
- Seed entry `ltm/failures/2026-05-10_ff_2026_001_v489_to_v490_direct_replace_failure.md` (consumes the SP-115 case).
- `consult.py` gains `--engine` and `--rebuild-index` CLI flags.

### 2.4 Agent Library / Pack Architecture — `docs/16_agent_library/` (Batch 5)

- 5 docs (`README`, `AGENT_ROLE_CATALOG` 8-enum, `PACK_BOUNDARY_SPEC`, `PACK_LIFECYCLE_GUIDE`, `PACK_CLUSTER_TAXONOMY` 7-cluster).
- 3 schemas: `agent_role`, `agent_pack_entry`, `agent_pack_state` (draft-07, 0.1.0-beta).
- `agent_packs/` — 5 cluster seed packs (`ap_2026_001_executive_cluster` … `ap_2026_005_support_cluster`), all in `draft` state.
- `scripts/agent_library/` — `validate_agent_pack` (GUIDED), `list_packs`, `activate_pack` (long→short ID auto-truncation per D-13.4.c.3=A).

### 2.5 Self-Evolution Skeleton — `docs/17_self_evolution/` (Batch 6)

- 4 docs + 3 schemas (`proposal_entry`, `proposal_state` 9 states, `proposal_ledger`, plus `validation_result`).
- `scripts/self_evolution/validate_proposal.py` — GUIDED, **read-only by design** (proposal-only invariant).
- `scripts/self_evolution/propose_skeleton.py` — proposal generator.
- `proposals/evo_2026_001_layer_separation_principle.md` — seed accepted proposal that ratifies the Layer 1/2 separation principle.
- Naming alias: `schemas/evolution/` README points to canonical `schemas/self_evolution/` per EP D-13.3.2=B.

### 2.6 Unified CLI — `docs/18_cli/` (Batch 13)

- `scripts/cli/ai_dev_os.py` — aggregate entry with subcommand groups: `migration`, `ltm`, `pack`, `evolve`. (Note: governance scripts live under `scripts/governance/` but are not a CLI namespace; they are invoked directly, e.g. `python3 scripts/governance/run_v490_rc3_closure_gate.py`.)
- **22 leaves wired / 0 STUB** (post-v4.90.3 corrected total; the v4.90.0 freeze shipped 17 leaves + 1 `ltm consult` STUB, but Batch 13.1 wired `consult` end-to-end via `runtime.ltm.__main__` and Batch 13.4.b added `ltm quarantine`; `evolve propose` was also added in Batch 13).
- Current invocation: `python3 -m scripts.cli.ai_dev_os <group> <leaf> ...`. A `bin/ai-dev-os` shim and `pyproject.toml` console_scripts entry are planned for v4.91 (so `ai-dev-os ...` works directly).

### 2.7 Protected Behavior Contract Phase 1 — `runtime/protected_contracts/` (Batch 14)

7 invariants in `enforced` mode, gated by `scripts/governance/check_required_regressions.py`:

| ID | Invariant |
|---|---|
| inv_001 | v4.89_Release tree SHA byte-lock |
| inv_002 | Layer 1 separation lint clean (zero project names in OS Core) |
| inv_003 | State machine doc-schema alignment |
| inv_004 | No v4.89 active stale references in v4.90 (whitelist controlled) |
| inv_005 | Naming alias catalog valid |
| inv_006 | capability_id format (14-row enum) |
| inv_007 | schema_version const + required field on declared schemas |

These invariants survive any future change unless explicitly waived via the proposed (v4.91+) waiver mechanism.

---

## 3. v4.90.1 hygiene patch (post-freeze, 2026-05-16)

After the initial `v4.90-release` freeze (`e0103a5`), an audit revealed and fixed:

- 4 process-residue files removed (RC1/RC2 release notes, smoke verdict JSON, batch-13 worklog) → release artifact 1035 → 1027 files; aligned with v4.89_Release baseline hygiene.
- Identity unification: 8 entry-level files cleaned of v4.89 self-identification (README / USER_GUIDE / START_HERE / RELEASE_NOTES / CHECKLIST / VERSION / `.core_os_root` / `check_core_os_root.py`); package now reads consistently as v4.90.
- `V4_90_README.md` §5.17 Batch 14 closure ledger updated (no more `_pending_` rows).
- `scripts/governance/verify_release_clean_tree.py` introduced — detects extra/orphan files vs. manifest baseline (closes the gap that `shasum -c` does not detect "extra files").
- Doc-status drift refreshed in `docs/15_ltm_v2/README.md` and `docs/18_cli/README.md` (STUB → GUIDED for `capture_sprint_close.py`).
- `RELEASE_MANIFEST.json` `package_root_dir` aligned with physical directory `AI_Game_Dev_OS_v4.90_Release`.

This document already reflects the patched state.

---

## 4. Verification baseline (v4.90.11 patched state; test baseline 953 unchanged within v4.90.11)

```bash
cd AI_Game_Dev_OS_v4.90_Release
python3 -m pytest tests/                                                # 953 passed / 2 skipped (post v4.90.11)
python3 scripts/governance/run_release_closure_gate.py --profile fast   # reviewer smoke gate — 7/7 PASS; benchmark target under 10s on a 2024-class laptop (v4.90.11+ pipe-deadlock-hardened)
python3 scripts/governance/run_release_closure_gate.py --profile full   # final release evidence gate — RC3 A/B + v4.92 overlays
python3 scripts/governance/run_v490_rc3_closure_gate.py                 # 13/13 PASS (RC3 contract — backward-compat entry)
python3 scripts/governance/verify_release_clean_tree.py                 # tree clean ✓
python3 scripts/check_core_os_root.py                                   # verdict=PASS / current_expected_prefix=v4.90
python3 scripts/governance/lint_layer_separation.py                     # 33 roots / 0 violations
python3 scripts/governance/check_required_regressions.py                # 7 invariants enforced PASS (PG-safe via _process_runner)
shasum -a 256 -c CHECKSUMS.sha                                          # 0 FAILED
```

**Two layered gates (v4.90.9+, semantics clarified in v4.90.10, F5/F7 pipe-deadlock-hardened in v4.90.11)**:

- **Fast = reviewer smoke gate**. `--profile fast` runs a 7-check
  subset for high-frequency CI fan-out and external "is the package
  healthy?" checks. Benchmark target: under 10s on a 2024-class
  laptop (v4.90.11 measured ~8.5s on the maintainer's laptop).
  Typical range: 5–15 seconds; longer on CI / sandbox is fine —
  there is no hard upper bound, only per-step subprocess timeouts.
  v4.90.11 hardens F5 (consistency aggregate) and F7 (curated
  pytest subset) against pipe-buffer back-pressure deadlock by
  capturing nested-process output to temporary files instead of
  `subprocess.PIPE` (whose 64 KB OS buffer used to wedge fast gate
  on slow CI / sandbox machines when the 6 aggregate sub-checks
  collectively exceeded the buffer).
- **Full = final release evidence gate**. In the historical v4.90.11
  baseline, `--profile full` delegated to the RC3 13-check closure
  contract. In v4.92, the dispatcher preserves the frozen RC3 A/B
  contract and overlays v4.92 C1/C2 baselines plus v4.92 C9-C13
  release-dir deliverable checks. **The fast gate is NOT a substitute
  for the full gate at release time.** Run the full gate before every
  annotated tag and before any external evidence-quality claim.

**Two evidence bands for the full gate (v4.90.11 explicit)**:

- **8/8 = A+B contract without deliverables** (`--profile full --skip-deliverables`)
  — code & test (C1-C6) + protected behavior (C7-C8). Useful during
  development to validate everything except the release-ceremony
  artefacts. v4.90.10 measured 31.74s on the maintainer's laptop.
- **13/13 = full release ceremony with deliverables** (`--profile full`, default)
  — in v4.92, the 8 above + C section: C9 v4.92 release notes target,
  C10 v4.92 release identity, C11 v4.92 entry docs and hub identity,
  C12 annotated `v4.92-release` tag, C13 clean release rehearsal with
  zip sha256 evidence.
- **Only 13/13 is acceptable as an external freeze evidence claim.**
  Never publish a "fast PASS" or "8/8 PASS" record as proof the
  package is ready for external consumption.

> **Slow CI / external regression machines (v4.90.8+)**: lift the
> default budgets explicitly and (optionally) isolate the C1 full
> pytest run from third-party plugins:
>
> ```bash
> python3 -m pytest tests/                                                    # ~25s on dev laptop
> python3 scripts/governance/run_release_closure_gate.py --profile full \
>     --pytest-timeout 1800 --aggregate-timeout 1800 \
>     --pytest-disable-plugin-autoload
> ```
>
> The closure gate's full pytest budget defaults to 240s and the
> per-check consistency-aggregate budget to 600s. Adoption-harness
> tests fan out subprocesses; on slow machines either budget can
> trip without these flags. v4.90.8 additionally hardens the
> closure-gate timeout itself (process-group-safe `Popen` + `killpg`)
> so no fan-out subprocess can leak past `--pytest-timeout`. **v4.90.9
> extends that hardening to `check_required_regressions.py` and
> `check_consistency_aggregate.py` via the shared
> `scripts/governance/_process_runner.py` helper, so every governance
> subprocess site is now PG-safe.**

---

## 5. What's NOT in v4.90 (deferred)

- ❌ Live TAPD / Jira / Git writeback — adapters remain in stub/GUIDED form; live integration is v4.92 work.
- ❌ Full runtime panel / SaaS / engine plugin — out of scope per plan §1.
- ❌ Self-Evolution auto-merge — proposal-only forever (canonical never mutated by validator).
- ❌ Vector DB / live LLM consult layer — Layer B FTS5 only; vector retrieval planned post-v4.91.
- ❌ `bin/ai-dev-os` shim and `pyproject.toml` console_scripts — packaging layer arrives in v4.91.
- ❌ Project mount file naming finalisation (`01_project_runtime_protocol.yaml` numeric vs unnumbered) — locked when v4.91 Multi-Project Hub lands.
- ❌ Pack ID long↔short canonical map table — current auto-truncation in `activate_pack.py` is sufficient; explicit catalog is v4.91 nice-to-have.
- ❌ Waiver system for protected invariants — v4.91+.

---

## 6. Lineage summary

```
v4.7        Runtime governance / contract / adapter shapes first appeared
v4.78       Tier1 directory layout
v4.8.2      Final Integrated suite
v4.87       Runtime Core solidified + Route A trio
v4.88 RC12  Portable Core skeleton (runtime muscle missing)
v4.88-stable      v4.87 runtime re-mounted onto v4.88 + B+ Bridge Hardening
v4.89             Beta Sprint Exit hardening + 11 permanent contracts + LTM Layer A
                  + 5-profile parity + schema-driven cross-checker + lift gate
                  + skills library + cold-start governance + cross-project LTM
v4.90       ← this release: Progressive Adoption + State Surface Governance
                  + LTM v2 + Agent Library/Pack + Self-Evolution skeleton + CLI
                  + Protected Behavior Contract Phase 1
```

---

## 7. Tag tree

| Tag | Pointer | Purpose |
|---|---|---|
| `v4.90-rc1` | Batch 12 closure | working-tree milestone |
| `v4.90-rc2` | Batch 13 closure | working-tree milestone |
| `v4.90-rc3` | Batch 14 closure (`9cc4ff4`) | full closure gate 13/13 |
| `v4.90-release` | post-hygiene + identity patch | **frozen artifact**, the recommended consumption tag |

---

## 8. Immediate next reads

1. `V4_90_README.md` — per-batch ground truth (Batch 0 → Batch 14 + §5.18 hygiene + §5.19 v4.90.1 patch).
2. `CHANGELOG.md` — full per-batch changelog entries.
3. `USER_GUIDE.md` — first-read user-facing guide (5/15-minute paths).
4. `docs/00_entry/START_HERE.md` — the canonical Run/Review entry.
5. `docs/13_migration/PROGRESSIVE_ADOPTION_GUIDE.md` — v4.90 main path.
6. `docs/18_cli/README.md` — unified CLI surface.

---

## 9. v4.91 starter conditions

- **Baseline**: HEAD on `release/v4.90-fork` after v4.90.1 retag (`v4.90-release` annotated).
- **Theme**: `Multi-Project Service-isation` (D-14.333.scope locked).
- **Fork**: `cp -r AI_Game_Dev_OS_v4.90_Release AI_Game_Dev_OS_v4.91`; v4.90_Release tree SHA becomes the v4.91 byte-lock anchor (inv_001).
- **Deferred items now scheduled**: 333 Phase 2/3, waiver system, Self-Evolution real loop, cross-project platformisation, packaging shim, project mount naming.

---

## Patch History

### v4.90.11 — Fast gate F5/F7 pipe-deadlock hardening + 13/13 evidence + doc alignment (2026-05-17)

- **Pipe-deadlock root cause.** EP review of the v4.90.10 final exposed an intermittent fast-gate hang on slow CI / sandbox machines. Standalone runs of `check_consistency_aggregate.py` were 6/6 PASS; nested invocations through `run_release_closure_gate.py --profile fast` could hang indefinitely. Diagnosis: F5 used `_process_runner.run_pg_safe`, which captures stdout/stderr via `subprocess.PIPE`. The pipe has a fixed-size OS buffer (typically 64 KB on Linux/macOS); when the aggregate's 6 sub-checks collectively wrote more than that, a grandchild blocked on `write()` while the parent blocked on `communicate()` waiting for EOF — a classic pipe deadlock that `os.killpg` cannot rescue (no timeout fires; the parent is reading, not waiting).
- **Fix.** New helper `scripts/governance/_process_runner.run_pg_safe_to_file` is a drop-in replacement that captures output to temporary files instead of pipes (file writes are not pipe-buffered, so the back-pressure path simply does not exist). It preserves the v4.90.8 PG-safe contract verbatim — Popen(start_new_session=True), os.killpg(SIGTERM) 10s grace, escalate SIGKILL 5s drain on TimeoutExpired, rc=124 on timeout / 126 on OSError / otherwise child exit. F5 (consistency aggregate) and F7 (curated targeted-pytest subset) both migrate to it; F1 (collect-only floor) remains on `run_pg_safe` because its output is bounded.
- **Independent fast-gate wall-clock budget.** New CLI flag `--fast-aggregate-wall-timeout` (default 300s, fast-profile-only) decouples the F5 wall-clock cap from `--aggregate-timeout` (per-sub-check). v4.90.10 used `aggregate_timeout * 6 + 60`, which made fast-gate wall-time unpredictable when reviewers raised `--aggregate-timeout` to 1800 (giving the outer wall-clock a ~3 hour ceiling that masked real hangs). Slow CI machines can lift this with `--fast-aggregate-wall-timeout 900`.
- **`run_pg_safe_to_file` 5 new tests** in `tests/governance/test_process_runner_to_file.py`: 200 KB stdout round-trip without deadlock (with sibling `run_pg_safe` parity assertion); grandchild process-group reaping when child fan-outs sleeper; extra_env round-trip; shell=True pipeline path; OSError → rc=126.
- **Dispatcher 2 new tests** in `tests/governance/test_release_closure_gate_dispatcher.py`: `--fast-aggregate-wall-timeout` default (300) + override (900); `--help` advertises the flag with v4.90.11 marker, `(fast profile only)`, and `default 300`.
- **Test count: 946 → 953 (+7)**. EXPECTED_PYTEST + C1 row label updated to 953/2.
- **Evidence record (2026-05-17 19:50+ on maintainer laptop)**:
  - `pytest tests/`: 953 passed / 2 skipped in 33.67s
  - `--profile full --skip-deliverables --pytest-disable-plugin-autoload`: 8/8 PASS in ~32s
  - **`--profile full --pytest-timeout 1800 --aggregate-timeout 1800 --pytest-disable-plugin-autoload` (full release ceremony with deliverables): 13/13 PASS in ~36s**
  - `--profile fast`: 7/7 PASS in ~8.5s
  - `--profile fast --aggregate-timeout 1800 --pytest-disable-plugin-autoload` (the v4.90.10 reproducer that EP observed hanging): **7/7 PASS in ~8.4s** ✓ (fix verified)
- **Documentation alignment** (P2 from EP review):
  - RELEASE_NOTES.md §4 title `Verification baseline (v4.90.9 final)` → `Verification baseline (v4.90.11 patched state; test baseline 953 unchanged within v4.90.11)` (resolves §4 vs frontmatter inconsistency).
  - New `Two evidence bands for the full gate (v4.90.11 explicit)` paragraph — 8/8 = A+B without deliverables; 13/13 = A+B+C with deliverables; only 13/13 is acceptable as external freeze evidence.
  - README.md / V4_90_README.md / RELEASE_NOTES_v4.90-rc3.md / CHANGELOG.md / docs/MANIFEST_HISTORY.md / USER_GUIDE.md all synced.
- **No schema or invariant changes.** v4.89 byte-lock SHA `bb48af16…87767` unchanged; project_profile schema 1.1.0 unchanged; 7 protected invariants 7/7 enforced PASS (PG-safe runner from v4.90.9, file-captured F5/F7 from v4.90.11).
- **MEMORY.md §5 NEW item 14** (permanent project convention): pipe-deadlock prevention — any nested governance subprocess that fan-outs children must use `run_pg_safe_to_file`, not `run_pg_safe`. Diagnostic signature: standalone run PASSes, nested run hangs.

### v4.90.10 — Optional polish: gate timing language + dual-gate semantics + v4.90.9 evidence record (2026-05-17)

- **Soft timing language.** All hard ≤10s / ≤180s claims are replaced with `benchmark target` + `typical range` phrasing across the dispatcher source, the README §Verification quote-block, RELEASE_NOTES §4 baseline, V4_90_README, and the RELEASE_NOTES_v4.90-rc3 §8 patch table. The 180s assertion in `tests/governance/test_release_closure_gate_dispatcher.py::test_fast_profile_runs_seven_checks_in_under_three_minutes` is documented as a CI safeguard, not a benchmark.
- **Dual-gate semantics.** README, RELEASE_NOTES, V4_90_README, and the dispatcher's module docstring + `--help` text now state the two gates explicitly and consistently:
  - **Fast = reviewer smoke gate** — high-frequency CI fan-out / external "is the package healthy?" checks.
  - **Full = final release evidence gate** — what release tags / RELEASE_NOTES reference; what must be all-green before any ship-ready claim.
  - **The fast gate is NOT a substitute for the full gate at release time.**
- **v4.90.9 evidence record.** This patch records a maintainer laptop verification run on 2026-05-17 17:05+:
  - `pytest tests/` → **946 passed / 2 skipped** in **29.46s**.
  - `run_release_closure_gate.py --profile full --skip-deliverables --pytest-disable-plugin-autoload` → **8/8 PASS** (A+B section) in **31.74s**. Full RC3 contract verified: C1 pytest 946/2 / C2 Layer 1 33/0 / C3 byte-lock mode=source_tree `bb48af16…87767` / C4 alignment 3/3 / C5 v4.89 audit Class C: 0 / C6 alias 6/6 / C7 7/7 invariants enforced / C8 aggregate 6/6.
  - `run_release_closure_gate.py --profile fast` 3-run sample → **7/7 PASS** in **6.22 / 6.50 / 6.32 seconds** (avg 6.35s).
- **No source/schema/test logic changes.** This is a pure documentation + comment polish patch. EXPECTED_PYTEST stays at 946; the dispatcher's CHECKS list is unchanged; manifest required count stays at 903.

### v4.90.9 — B-CG closed: fast/full closure gate split + PG-safe runner extraction + game-dev phase split (2026-05-17)

- **PG-safe runner extraction.** `scripts/governance/_process_runner.py` is a new module that promotes the v4.90.8 closure-gate `_run()` body to a shared helper `run_pg_safe(cmd, *, cwd, timeout, extra_env=None, shell=False)`. It preserves the v4.90.8 contract verbatim — `subprocess.Popen(..., start_new_session=True)` + `os.killpg(SIGTERM)` 10s grace + escalation to `SIGKILL` 5s drain on `TimeoutExpired`, returning rc=124 on timeout / rc=126 on `OSError` / otherwise the child exit. Three callers migrate to it: `run_v490_rc3_closure_gate._run()` (now a one-line adapter), `check_required_regressions.execute()` (its `subprocess.run(..., shell=True, timeout=300)` is replaced; the shell-string contract for `protected_invariant.required_validation` commands is preserved via the `shell=True` parameter), and `check_consistency_aggregate._run()` (each of the 6 sub-checks now goes through the PG-safe path). Closes the v4.90.8 hardening gap: every governance subprocess site is now PG-safe.
- **Fast/full closure gate split (B-CG closed).** `scripts/governance/run_release_closure_gate.py` is a new dispatcher recommended as the v4.90.9+ entry point. `--profile fast` runs 7 minimal checks — F1 pytest --collect-only floor / F2 release clean-tree (with auto-clean of `__pycache__` / `.pytest_cache` transients before verification, and ordered to run last so prior pytest steps cannot create false-positive drift) / F3 v4.89 active-stale Class C: 0 / F4 Layer 1 separation 33/0 / F5 consistency aggregate 6/6 / F6 protected regressions 7/7 / F7 a curated targeted-pytest subset (cli + contracts + clean-tree + 4 governance sub-files; explicitly omits the dispatcher's own e2e tests to avoid recursion). Total ≈ 6.5s on a developer laptop, ≤ 180s on slow CI. `--profile full` (default) imports and forwards every passthrough flag (`--skip-deliverables / --pytest-timeout / --aggregate-timeout / --pytest-disable-plugin-autoload / --format`) to the existing RC3 13-check gate so the contract source-of-truth is unchanged. Both profiles print a banner that documents the underlying contract — `v4.90.1..v4.90.9` patch chain plus the RC3 contract file path — so external reviewers see at a glance what the dispatcher is layered on. The original `run_v490_rc3_closure_gate.py` script remains the closure-contract source of truth; it gains a one-line docstring note pointing at the dispatcher as the recommended entry but is otherwise unchanged.
- **Project profile schema 1.0.0 → 1.1.0 with required `game_dev_phase` field.** `schemas/adoption/project_profile.schema.json` introduces a new required field `game_dev_phase` whose enum is decoupled from the existing `stage` lifecycle enum. The 7 phase values follow industry convention: `prototype / mvp / vertical_slice / alpha_build / beta_build / production / post_launch`. The package ships zero pre-existing `02_project_profile.yaml` instances, so the required-field bump needs no on-disk backfill; new instances generated by `init_project_runtime.py` automatically include the field. `tests/test_schema_promote_wave_2_final.py` updates the project_profile entry from `1.0.0` to `1.1.0`; `tests/adoption/test_project_profile_schema.py` adds three sentinel cases (game_dev_phase required / enum-bound / schema_version const="1.1.0").
- **`init_project_runtime.py --game-dev-phase` with stage-derived default.** A new optional CLI flag accepts any of the 7 phase values. When omitted, a deterministic mapping (`incubation→prototype`, `alpha→alpha_build`, `beta→mvp`, `release_candidate→vertical_slice`, `production→production`, `maintenance/sunset→post_launch`) derives a sensible default from `--stage` so every pre-v4.90.9 call site keeps working. The template `templates/project_runtime/02_project_profile.yaml.tmpl` and the harness `scripts/adoption/run_mock_harness.py --emit-game-dev-phase` are wired through.
- **Test count: 926 → 946 (+20)**. New suite `tests/governance/test_process_runner.py` (4 cases: grandchild process-group reaping / extra_env round-trip / shell=True path / OSError → rc=126). New suite `tests/governance/test_release_closure_gate_dispatcher.py` (5 cases: --help documents both profiles + every passthrough flag / `_argv_for_full` serialises every flag / default profile=full / banner references v4.90.9 + RC3 / fast e2e ≤ 180s with all 7 IDs visible). New suite `tests/adoption/test_init_stage_aliases.py` (8 cases: explicit dual-field happy path / phase derivation when omitted / cross-stage coverage of the derivation map (3 parametrised) / bad phase rejected / generated yaml validates against schema 1.1.0 / schema_version literal sentinel). Plus 3 schema-self-validation cases in `tests/adoption/test_project_profile_schema.py`.
- **`EXPECTED_PYTEST` 926 → 946** + C1 row label `pytest 926/2 skipped` → `pytest 946/2 skipped`.
- **README.md / USER_GUIDE.md / V4_90_README.md / docs/13_migration/PROJECT_INIT_GUIDE.md / RELEASE_NOTES_v4.90-rc3.md §8 Patch History** all synced to v4.90.9 baseline. README §Verification gains a `--profile fast` one-liner with a sub-quote explaining the dispatcher's relationship to the RC3 contract.
- **B-CG closed.** New v4.91 backlog item: B-DUAL-PHASE-DOC (an authoritative stage × game_dev_phase decision-matrix doc — v4.90.9 only ships the schema + CLI; the workflow narrative is deferred).
- **RELEASE_MANIFEST.json rebuild.** required_manifest_files 896 → **903** (+7: `_process_runner.py`, `run_release_closure_gate.py`, 3 new test files, plus 2 modified files surfaced by checksum drift). optional_seed_files / test_fixtures unchanged. RC release integrity test still 3/3 PASS.

### v4.90.8 — Closure gate hardening (2026-05-17)

- `scripts/governance/run_v490_rc3_closure_gate.py` `_run()` rewritten to be process-group-safe. Pre-v4.90.8 it used `subprocess.run(..., timeout=...)`, which only signals the *direct* child on timeout; pytest's adoption-harness fan-out spawns grandchildren that inherit stdout/stderr pipes, and external CI machines were observed to deadlock on `communicate()` after timeout because a grandchild kept the pipe alive. v4.90.8 spawns the child with `subprocess.Popen(..., start_new_session=True)` and on `TimeoutExpired` calls `os.killpg(SIGTERM)` (with a 10s grace, escalating to `SIGKILL` + 5s drain) so the entire fan-out tree is reaped. The contract is unchanged: 124 on timeout, 126 on `OSError`, otherwise the child exit code.
- New optional flag `--pytest-disable-plugin-autoload` on `run_v490_rc3_closure_gate.py` (C1 only). Sets `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1` in the C1 full pytest env via `_run`'s new `extra_env` parameter — the same isolation primitive C8's aggregate runner already uses for the `schema_self_validation` sub-check (v4.90.7). Default OFF (no laptop-run behavior change); opt-in for slow CI where third-party pytest plugins slow or deadlock teardown. The fast-vs-full closure-gate split itself remains deferred to v4.91 (B-CG backlog item).
- `EXPECTED_PYTEST` 923 → **926** + C1 row label `pytest 923/2 skipped` → `pytest 926/2 skipped` to absorb the +3 governance tests added below.
- README.md §Verification slow-CI quote-block heading `(v4.90.3+)` → `(v4.90.8+)`; invocation upgraded from `--pytest-timeout 1800` to `--pytest-timeout 1800 --aggregate-timeout 1800` plus a follow-on note for `--pytest-disable-plugin-autoload` and the Popen + killpg hardening summary.
- README.md L69 expect line: `923 passed / 2 skipped (post v4.90.7)` → `926 passed / 2 skipped (post v4.90.8)`.
- USER_GUIDE.md baseline summary line: `923 passed / post v4.90.7` → `926 passed / post v4.90.8`.
- RELEASE_NOTES.md §4 heading `(v4.90.7 final)` → `(v4.90.8 final)`. §4 body `923 passed (post v4.90.7)` → `926 passed (post v4.90.8)`. §4 slow-CI quote-block heading `(v4.90.7+)` → `(v4.90.8+)` with `--pytest-disable-plugin-autoload` appended to the invocation and a closing sentence describing the Popen + killpg hardening.
- Test count: 923 → **926** (+3: `tests/governance/test_closure_gate_timeout_hardening.py` covers (1) process-group-safe timeout — child spawns 30s grandchild with shared stdout, `_run(timeout=2)` must return rc=124 within 25s and the grandchild PID must be reaped; (2) `extra_env` round-trip into the C1 child; (3) `--help` advertises the flag with its v4.90.8 marker).

### v4.90.7 — Aggregate stability + RELEASE_NOTES §4 sync (2026-05-17)

- `scripts/governance/check_consistency_aggregate.py` reordered: `schema_self_validation` now runs at position 5 (before `required_regressions` at 6). External sandbox replays revealed the previous order could deadlock when workspace-wide pytest plugins (coverage / distributed / third-party hooks) auto-loaded into the schema-self-validation sub-suite while the regressions router held subprocess locks; running the pure-pytest sub-suite first flushes the plugin-load cache cleanly.
- New `--timeout SECS` CLI flag on `check_consistency_aggregate.py` (default 180; raise to 600+ on slow CI). Each of the 6 sub-checks gets the same independent budget.
- `schema_self_validation` subprocess now runs with `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1` injected so external pytest plugins cannot stall the aggregate. Only that one sub-check is isolated; the other 5 inherit the parent env unchanged.
- Closure gate `run_v490_rc3_closure_gate.py` C8 now passes `--timeout AGGREGATE_TIMEOUT` (default 600s) and exposes a new `--aggregate-timeout SECS` CLI flag independent of `--pytest-timeout`. C8 row label now surfaces the per-check budget.
- RELEASE_NOTES.md §4 heading `Verification baseline (v4.90.5 final)` → `(v4.90.7 final)`. §4 commands updated: `920 passed / 2 skipped (post v4.90.5)` → `923 passed / 2 skipped (post v4.90.7)`. New quote-block at the end of §4 documents the slow-CI invocation pattern (`--pytest-timeout 1800 --aggregate-timeout 1800`).
- Test count: 920 → **923** (+3: `tests/governance/test_consistency_aggregate_stability.py` covers the new ordering invariant, the `--timeout` flag, and the `ISOLATED_PYTEST_NAMES` marker).

### v4.90.6 — Active-state label sweep (2026-05-17)

- README.md L69 + USER_GUIDE.md L21 qualifier `(post v4.90.3)` → `(post v4.90.5)` (the qualifier identifies which patch last established the 920-test baseline, not the latest patch in the chain).
- V4_90_README.md plan-files reference line appended `+ v4.90.5 inline plan (3 commits) + v4.90.6 inline plan (2 commits)` citations.
- Test count: 920 → **920** (pure label sweep).

### v4.90.5 — Doc precision (2026-05-17)

- `docs/18_cli/README.md` + `CLI_USAGE_GUIDE.md` corrected two wrong script names (review-found post v4.90.4): `list_agent_packs.py` → **`list_packs.py`** (the actual `scripts/agent_library/` filename); `propose_evolution.py` → **`propose_skeleton.py`** (the actual `scripts/self_evolution/` filename). The CLI dispatcher already imports the correct modules; only the doc wraps-line annotations were stale.
- `docs/18_cli/CLI_USAGE_GUIDE.md` 4 namespace sections promoted from "Planned leaf shape" to **"Current leaf shape"** with the actual command lists post Batch 11.x + Batch 13 closure: migration's 4 alias leaves now visible (handshake / plan / verify / report); pack agent-library's list + activate added; evolve's propose added.
- `RELEASE_NOTES.md` 4 fact corrections: (1) frontmatter "v4.90.3 patched state" → "v4.90.5 patched state"; (2) §1 + §2.6 dropped fictitious `governance` CLI namespace (governance scripts are invoked directly, not via `ai-dev-os`); (3) §2.1 `scripts/migration/` "(mix of GUIDED + STUB)" → enumerated 7 GUIDED entry points with the alias-form note; (4) §2.1 `scripts/adoption/` removed the misplaced `scan_legacy_project.py` reference (that file lives under `scripts/migration/`, not `scripts/adoption/`).
- Test count: 920 → **920** (pure doc precision; no code, schema, or test change).

### v4.90.4 — Doc polish (2026-05-17)

- `docs/18_cli/CLI_USAGE_GUIDE.md` skeleton/placeholder sweep: header `Status: Step 11.1 skeleton` → `GUIDED wrapper / 22 leaves wired / 0 STUB`. §4-§7 namespace `Status: placeholder until Step 11.x` → `GUIDED — N leaves wired (Batch 11.x closure ...)` matching its sister `docs/18_cli/README.md`.
- `RELEASE_NOTES.md` §4 heading `Verification baseline (v4.90.1 final)` → `Verification baseline (v4.90.3 final)` (body was already 920 passed post v4.90.3 c2).
- `2026-05-1X` placeholder dates and `tag v4.90.{2,3}-release（待打）` labels swept across `USER_GUIDE.md` / `CHANGELOG.md` / `V4_90_README.md` to `2026-05-16` + `（annotated，已打）`. Bonus: `USER_GUIDE.md` v4.90.2 entry test count corrected from `906 → 911` to `906 → 915`.
- `README.md` §Verification gains a quote-block flagging `--pytest-timeout 1800` for slow CI / external regression machines (the closure gate flag was added in v4.90.3 c5 but never advertised in onboarding docs).
- Test count: 920 → **920** (pure doc; no test change).

### v4.90.3 — Final polish (2026-05-16)

- pytest baseline unified to **920 passed / 2 skipped** across all consumer-facing docs (README.md / USER_GUIDE.md / RELEASE_NOTES.md / CHANGELOG.md / V4_90_README.md). v4.90.2 left residual `911 passed` in two onboarding files; this patch fully resolves the drift.
- `RELEASE_NOTES.md` re-aligned to current state (was stuck at v4.90.1 narrative + 906 verification line; now v4.90.3 with full Patch History block at the end).
- `docs/18_cli/README.md` + `CLI_USAGE_GUIDE.md` corrected: status `17 leaves wired + 1 STUB (ltm consult)` → **22 leaves wired / 0 STUB**. `ltm consult` was fully wired in Batch 13.1 (substring + FTS5 retrieval, exit 0/1/3/4 per plan §9); `quarantine` (Batch 13.4.b) and `evolve propose` were also added since the Batch 11 freeze. Routing-policy advanced enforcement still deferred to v4.91+.
- `scripts/governance/clean_transients.py` shipped — clears `__pycache__/` / `.pytest_cache/` / `*.pyc` / `.DS_Store` / `._*` so users can re-pass `verify_release_clean_tree.py` after running tests or CLI commands inside an extracted release pack. README.md §Verification documents the post-test housekeeping flow.
- `scripts/governance/run_v490_rc3_closure_gate.py` gains `--pytest-timeout` flag (default 240s; raise to 1800s+ on slow CI / external machines). Fast vs full closure-gate split deferred to v4.91 (B-CG backlog item).
- Test count: 915 → **920 passed / 2 skipped** (+2 cli metadata, +2 clean_transients, +1 closure gate timeout).

### v4.90.2 — Portability + doc baseline + pack baseline dual-track (2026-05-16)

- `inv_001` byte-lock invariant rewired through `scripts/governance/check_v4_89_byte_lock.py` — a portable mode-aware checker (source_tree / release_package / skipped). External release-zip deployments now reach 13/13 closure gate PASS without depending on the maintainer's absolute git path.
- `RELEASE_MANIFEST.json` schema 2.1 → 2.2 with new top-level `byte_lock` field carrying ref_pack / tree_sha / verification_modes / release_package_proof / fingerprint metadata. Proof file at `tests/contracts/v4_89_byte_lock_fingerprint.txt` (761 entries; aggregate sha256 `f79c20527d63…e98`).
- `game_type_packs/` 6 manifests gain `baseline_versions: ["v4.89_Release", "v4.90_Release"]` dual-track + `baseline_alias_note`. Legacy `required_runtime_baseline` / `depends_on_run_baseline` strings preserved for inv_004 reference-baseline integrity.
- 4 pack `README.md` + 6 `STARTER_ATTACHMENT_RULES.md` carry an onboarding alias-note quote block.
- `USER_GUIDE.md` §1.1 inherited narrative rewritten: v4.89 ← previous Beta Sprint Exit baseline; v4.90 ← this pack. §2 directory tree distinguishes active (v4.90_Release) vs reference (v4.89_Release immutable).
- `docs/18_cli/README.md` status: skeleton → GUIDED wrapper. Test count: 906 → 915 passed / 2 skipped.

### v4.90.1 — Hygiene patch (2026-05-16)

- 8 files identity unification (v4.89 → v4.90 across `.core_os_root` / `VERSION` / `check_core_os_root.py`).
- `verify_release_clean_tree.py` + 5 tests added; `package_root_dir` aligned to physical release dir.
- Test count: 901 → 906 passed / 2 skipped.

---

### v4.91 Batch 14.19 — Gate Runner Architecture Patch (2026-05-17)

**Theme**: Fast gate restructured from "nested pytest validator" into a flat, killable, log-recorded, non-recursive smoke gate. Closes the last grandchild-leak hole and the recursive-validation foot-gun.

**Root-cause re-fix (not another timeout)** — pre-v4.91 fast gate stack was:

```
run_release_closure_gate.py
  → F7 targeted pytest
    → pytest
      → governance test fixture
        → subprocess.run(...)
          → governance script
            → possibly more grandchildren
```

Each prior patch (v4.90.7 / .8 / .9 / .11) sealed one layer; the next one re-emerged. v4.91 Batch 14.19 changes the **model**:

1. **`_process_runner.py` v2 API** — new `RunResult` dataclass exposes `rc / stdout / stderr / elapsed / timed_out / killed_pg / cleanup_invoked / spawn_error`. New `cleanup_process_group_on_exit=True` keyword on both `run_pg_safe_v2` and `run_pg_safe_to_file_v2` SIGTERMs the child's process group AFTER a normal child exit (best-effort, escalates to SIGKILL with short grace) so any forked grandchild is reaped before the call returns. Legacy `run_pg_safe` / `run_pg_safe_to_file` keep their `tuple[int, str, str]` signatures and are now thin wrappers over v2.

2. **F7 split + F8a-d** — old F7 was one big targeted-pytest invocation that mixed the CLI surface with governance internals AND included gate-runner self-tests. New F7 = 4 direct CLI smoke commands (no pytest, no fan-out): `ai-dev-os --help` / `pack agent-library list --format json` / `ltm consult progressive --limit 2 --format json` / `evolve propose --help`. New F8a/F8b/F8c/F8d carry the small safe pytest batches (tests/cli, byte-lock + clean-tree contract, schema + state machine, cold-start + registry guard). Total: 11 fast-gate items. Excluded from fast gate (now gate-runner-only): `test_process_runner*`, `test_release_closure_gate_dispatcher`, `test_consistency_aggregate_stability`, `test_closure_gate_timeout_hardening`, `test_closure_gate_timeout_flag`.

3. **`--fast-total-timeout SECS`** (default 600) — outer wall-time supervisor caps the entire fast gate. Watchdog thread reaps the in-flight item's process group when budget is exhausted, marks `SUPERVISOR_TIMEOUT`, skips remaining items, exits 1. Independent from `--fast-aggregate-wall-timeout` (which only caps F5).

4. **Per-item logs + report** — every F-item writes captured stdout/stderr to `exports/closure/fast_gate_logs/Fxx_<slug>.{stdout,stderr}`; the dispatcher emits `exports/closure/fast_gate_report.{json,md}` listing every item's id / label / command / timeout / stdout_file / stderr_file / exit_code / elapsed / summary. Logs and report are written AFTER F2 finishes wiping `exports/`, so they appear on disk only after F2's verdict is fixed. Hung items become identifiable post-mortem instead of "the dispatcher just sat there".

5. **pytest markers** — `fast_gate_safe` / `gate_runner` / `full_regression` registered in `pytest.ini`. `tests/conftest.py::pytest_collection_modifyitems` auto-tags by file path so the fast gate's test selection is path-driven, not boilerplate-driven, and so a future test added to a tagged file inherits the marker without per-file pytestmark.

6. **Fixture migration** — `tests/governance/conftest.py::run_script` + 5 governance / contracts test files migrated from plain `subprocess.run(capture_output=True, timeout=...)` to `run_pg_safe_to_file_v2(cleanup_process_group_on_exit=True)`. The PIPE 64 KB back-pressure deadlock pattern is now removed at the test fixture layer too (previously only the gate runner itself was hardened).

7. **Anti-hang test suite** — new `tests/governance/test_process_runner_grandchild_cleanup.py` (5 tests, `gate_runner` marker): parent-exits-grandchild-alive (file-capture path), parent-exits-grandchild-alive (PIPE-documented-limitation path; locks the contract that PIPE + grandchild-inheriting-stdout MUST hit outer timeout, not silently hang), grandchild-holds-stdout (file-capture cure), nested-pytest-child-hangs (rc=124 within timeout+grace), runner-timeout-supervisor-cooperation. These tests exist to lock the v4.91 fix permanently.

**Patch chain banner**: `v4.90.1..v4.91-batch14.19`. At that v4.91 patch point, full gate (`--profile full`) still used the RC3 13-check contract.

**Test count**: 953 → **960** (+7). Components: +5 anti-hang grandchild-cleanup tests in `test_process_runner_grandchild_cleanup.py`, +2 dispatcher tests for the new `--fast-total-timeout` flag in `test_release_closure_gate_dispatcher.py`. Pure pytest baseline: `960 passed, 2 skipped` (post v4.91 Batch 14.19, maintainer laptop).

---

**End of v4.91 Batch 14.19 patched Release Notes.**

---

## v4.91 Feature Track — Multi-Tenant Runtime Sovereignty

> Starting with v4.91, post-baseline work follows a charter-aligned **feature ID** scheme rather than continued `Batch 14.x` numbering:
> `F-T-` Tenancy / `F-V-` Verifiability / `F-I-` Isolation / `F-X-` eXperience flow.
>
> v4.91 release theme: extend the Layer 1/2 invariant from doc/schema layer down into the runtime filesystem, so an external Core can serve multiple projects in a stable / verifiable / isolated way and let experience flow only across intent boundaries with human approval.

### F-T-01 — Tenancy Boundary Schema (v4.91, landed 2026-05-17)

**Charter dimension**: Isolated. **Closes gaps**: 1, 2 (filesystem tenancy boundary contract; runtime data vs core release content distinction).

The Core's `RELEASE_MANIFEST.json` and adopting projects' `.ai_dev_os/project_runtime_protocol.yaml` now carry a **bidirectional tenancy occupation contract**. A path in the Core release tree is recognised as legitimate tenant runtime data only when (a) the manifest declares a generic `path_template` (e.g. `ltm/project/<project_id>/**`) under `classification_rules.tenant_runtime`, AND (b) exactly one adopting project explicitly claims the concrete instantiation in its `runtime_namespace.claims[]` block. Either side missing leaves the path as `extra` to clean-tree audits.

Concrete deliverables:

- `schemas/tenancy/tenancy_boundary.schema.json` (new) — formal contract for both halves; schema_version `1.0.0`.
- `schemas/protocol/project_runtime_protocol.schema.json` — extended with optional `runtime_namespace.claims[]`. **schema_version unchanged at `1.0.0`** per `inv_007` lock + the extend-don't-replace charter.
- `RELEASE_MANIFEST.json` — `manifest_schema_version` 2.2 → 2.3; new `classification_rules.tenant_runtime`; new top-level `tenant_runtime_entries[]` (1 entry: `ltm/project/<project_id>/**`).
- `docs/19_tenancy/TENANCY_CONTRACT.md` (new, Layer 1) + `docs/19_tenancy/README.md` (new, Layer 1).
- `tests/governance/test_tenancy_boundary_schema.py` (new, 15 tests).

**Layer 1 invariant evolution**: `inv_002_layer_1_no_project_names` formally evolves from "33 roots scanned" to **"35 roots scanned"** with the addition of `docs/19_tenancy` + `schemas/tenancy` to `LAYER_1_ROOTS`. `must_preserve` updated; `trigger_files` extended; `TENANCY_CASE_*.md` exemption pattern added (parallel to `STATE_SURFACE_MIGRATION_CASE_*`). `inv_002` enforced PASS post-change.

**Test count**: 960 → **975** (+15 schema/contract tests). `lint_layer_separation` post-evolution: **35 roots / 0 violations**.

**The RH "extra files" symptom does NOT close at this commit** — F-T-01 only declares the contract. The clean-tree verifier becomes contract-aware in F-V-01 (next), at which point any project that adds the `runtime_namespace` block to its yaml is automatically recognised. There is no patch / no whitelist / no project-name in the Core.

### F-V-01 — Tenancy-Aware Verifier + Linter (v4.91, landed 2026-05-18)

**Charter dimension**: Verifiable. **Closes gaps**: 1, 3 (filesystem tenancy boundary verification; lint scope extended from doc layer to runtime tree).

5 atomic commits implement the bidirectional tenancy contract enforcement that F-T-01 declared:

```
00b9768  feat(v4.91 F-V-01 c1): _tenancy_reader.py — pure-fn helper for bidirectional tenancy reconciliation
fdc860c  feat(v4.91 F-V-01 c2): verify_release_clean_tree.py — tenancy-aware audit
f57353b  feat(v4.91 F-V-01 c3): lint_layer_separation.py — runtime tree leak detection
<c4>     test(v4.91 F-V-01 c4): tenancy-aware verifier + runtime-tree lint tests
<c5>     release(v4.91 F-V-01 c5): RELEASE_MANIFEST sha sync + RELEASE_NOTES F-V-01 section
```

**What changed**:

- `scripts/governance/_tenancy_reader.py` (new, 405 lines, Layer 1) — pure-fn helper exposing `load_manifest_tenant_entries`, `load_project_claims`, `discover_project_yamls`, `discover_default_project_yamls`, `reconcile_path`. Outcome codes: `TENANT_ACCEPTED`, `NO_TEMPLATE_MATCH`, `NO_CLAIM_MATCH`, `CROSS_TENANT_SQUAT`. Manifest path templates compile to regex with `<project_id>` becoming a capture group `(?P<pid>[a-z][a-z0-9_-]+)`. Zero project names in the helper itself.
- `scripts/governance/verify_release_clean_tree.py` — `verify(...)` now returns `(extras, transients, tenant_accepted)`. After the existing transient + generated-runtime checks, each candidate path is reconciled against manifest entries + project claims. `TENANT_ACCEPTED` paths move into `tenant_accepted`; `NO_*` and `CROSS_*` outcomes remain extras (the gate intentionally does not distinguish those subtypes — that is a diagnostics tool's job). When manifest carries no `tenant_runtime_entries[]`, the tenancy logic is skipped entirely (zero overhead, pre-F-T-01 behaviour preserved).
- `scripts/governance/verify_release_clean_tree.py` CLI:
  - **NEW** `--adopting-project-root <PATH>` (`action=append`, repeatable) — names adopting-project roots whose `runtime_namespace.claims[]` to honour. The pre-existing `--project-root` (release artifact root, single positional) is preserved with unchanged semantics; the two flags address opposite sides of the contract and never overlap.
  - **NEW** `--report-tenant-accepted` flag — diagnostics output listing each accepted path with `project_id` / template / project_root.
  - JSON output gains `tenant_accepted_count` + `tenant_accepted[]` fields.
  - Text output always appends `N tenant runtime files accepted (F-V-01 bidirectional tenancy contract).`.
  - **NO `--allow-extra` / `--skip-tenant` flags** by design. The bidirectional contract has no escape hatch.
  - Default discovery: when `--adopting-project-root` is omitted, scan `<project_root>/trial_workspaces/*/.ai_dev_os/project_runtime_protocol.yaml`. Empty on a vanilla v4.91 tree → behaviour identical to pre-F-V-01.
- `scripts/governance/lint_layer_separation.py` — new INDEPENDENT pass `scan_runtime_tree(repo_root, adopting_project_roots)` runs alongside the existing layer-1 content scan. Two new constants:
  - `RUNTIME_TREE_ROOTS = ['ltm/project']` — the only manifest tenant_runtime entry as of F-T-01. Future tenant_runtime entries must extend this list in lockstep.
  - `RUNTIME_TREE_GENERIC_FILES = {'README.md', 'INDEX.md', '.keep', '.gitkeep'}` — generic Core-shipped scaffolding, exempt from path reconciliation.
  - Same `--adopting-project-root` flag wired in. With no oracle in scope (default vanilla tree), the runtime-tree pass short-circuits and returns no violations — preserving pre-F-V-01 lint behaviour.
- `tests/governance/test_tenancy_aware_verifier.py` (new, 10 tests) covering TV1–TV9 + escape-hatch flag rejection guard.
- `tests/governance/test_runtime_layer_lint.py` (new, 7 tests) covering TL1–TL6 + escape-hatch flag rejection guard. Test fixtures use only generic project ids (`acme_demo` / `sample_project`); the layer-1 leak literal in TL3 is constructed at runtime via string concatenation so the test source file itself stays layer-1 clean.

**Test counts**: 975 → **991** (+16 new tests; `tenant_accepted_count` field tested across both JSON shape and text-output assertions).

**Verification matrix on the v4.91 tree**:

| V | Command | Result |
|---|---|---|
| V1 | `pytest tests/governance/test_tenancy_aware_verifier.py` | 10/10 PASS |
| V2 | `pytest tests/governance/test_runtime_layer_lint.py` | 7/7 PASS |
| V3 | `verify_release_clean_tree.py` (no `--adopting-project-root`) | clean ✓, "0 tenant runtime files accepted" |
| V8 | `run_release_closure_gate.py --profile fast` | 11/11 PASS |
| V9 | full pytest | 991 passed / 2 skipped |
| V10 | `lint_layer_separation.py` (no `--adopting-project-root`) | clean ✓ (35 roots + 1 runtime tree root) |

**Charter alignment**: gap 1 (filesystem tenancy boundary) is now both DECLARED (F-T-01) and ENFORCED (F-V-01). gap 3 (lint scope) extended from doc/schema layer down into runtime tree subtrees declared by `tenant_runtime_entries[]`.

**Side effect, not a task**: the moment any adopting project adds a `runtime_namespace.claims[]` block to its `.ai_dev_os/project_runtime_protocol.yaml` and is passed via `--adopting-project-root`, that project's LTM files transition from `extra` to `tenant_accepted` WITHOUT any patch to manifest exclusions, transient_patterns, or generated_runtime_outputs. The 5 historical RH ltm/project/rh/* files unblock structurally rather than by whitelist.

**Anti-patterns explicitly avoided**:

- did NOT add `ltm/project/**` to `transient_patterns` / `generated_runtime_outputs` (would bypass the contract)
- did NOT add `--allow-extra` / `--skip-tenant` escape-hatch flags (compile-time guarded by tests)
- did NOT hard-code any project name in Core code, schemas, or non-fixture tests
- did NOT replace `project_runtime_protocol.yaml` schema (extended via optional `runtime_namespace` in F-T-01 c1)
- did NOT collapse runtime-tree leak into the layer-1 content scan; the two passes have orthogonal contracts (path-level vs content-level) and remain structurally distinct
- did NOT treat the RH ltm/project/rh/* unblock as a separate task ID — it is the expected side effect of the bidirectional contract becoming enforced

---

## v4.91 Milestone A — Core Reliability (in flight)

### B0 — Gate Runner Final Polish (v4.91, landed 2026-05-19)

**Closes**: the last residual ambiguity in `fast_gate_report.json` carried over from v4.90.11. v4.91 Batch 14.19 already restructured the fast gate into a flat, killable, log-recorded supervisor (PG-safe runner + `cleanup_process_group_on_exit` + per-item logs + `--fast-total-timeout`). What B0 adds is the **explicit 5-state status vocabulary** that downstream tooling can consume directly instead of re-deriving failure modes from the legacy `(ok, supervisor_timeout)` boolean pair.

**Commits** (2):

```
e2b81ba  feat(v4.91 B0 c1): gate_report schema + 5-state status field
<c2>     docs(v4.91 B0 c2): RELEASE_NOTES + Maintainer evidence record
```

**c1 deliverables**:

- `schemas/governance/gate_report.schema.json` (NEW, draft-07): locks the 5-state status enum (`pass / fail / timeout / killed / skipped`) + `schema_version: 1.0.0` + per-record shape contract. The legacy `ok` boolean and `supervisor_timeout` boolean are retained as required fields for backward compatibility — `status` is authoritative.
- `scripts/governance/run_release_closure_gate.py`: adds `GATE_REPORT_SCHEMA_VERSION = "1.0.0"`, 5 `GATE_STATUS_*` enum constants, and `_derive_gate_status(record)` helper. `_persist_logs_and_reports()` now stamps `schema_version` into the payload root and `status` into every cleaned record. Status is derived from the in-memory record (which still has `stdout_text` / `stderr_text`) before those fields are stripped, so the runner's `"process group unreaped"` sentinel is still visible to the killed-state mapping.
- `tests/governance/test_gate_report_schema.py` (NEW, 3 tests):
  1. schema file shape contract — title / `schema_version` const / status enum is exactly the 5 values / `status` is required.
  2. synthesised payload round-trips through `jsonschema.validate` with one record per status state. Deliberately does NOT spawn the live fast gate to avoid coupling the schema test to RELEASE_MANIFEST hash drift.
  3. `_derive_gate_status` maps the 5 states correctly from realistic `(ok, supervisor_timeout, summary, stderr_text, elapsed, command)` signal combinations.
- `RELEASE_MANIFEST.json`: 912 → 914 `required_manifest_files`. Surgical hand-edit (insert 2 new files in sorted order + sha refresh on `run_release_closure_gate.py`), NOT a full `rebuild_release_manifest.py` rerun — the rebuilder is unaware of v4.91 F-T-01's `manifest_schema_version` 2.3 and `tenant_runtime` block, and would silently strip them. **Action item for v4.92**: teach the rebuilder about F-T-01 fields; for v4.91 the surgical-edit pattern is the correct workaround.

**Status mapping rules** (locked by `_derive_gate_status` and the schema):

| Status | Trigger |
|---|---|
| `pass` | `ok=True` |
| `skipped` | supervisor never dispatched (`supervisor_timeout=True` ∧ `elapsed=0` ∧ empty `command`), or summary contains `"SKIPPED"` |
| `timeout` | supervisor watchdog tripped on a dispatched item, or summary/stderr contains `"TIMEOUT"` |
| `killed` | stderr contains `"process group unreaped"` (forward-compat for `run_pg_safe_v2.killed_pg=True` surfacing) |
| `fail` | everything else with `ok=False` |

Exactly one status per record. The mapping is total over the legacy signal space.

**Anti-patterns explicitly avoided**:

- did NOT remove `ok` or `supervisor_timeout` from the report (downstream v4.90.x readers stay green)
- did NOT change the dispatcher's exit-code semantics (status is reporting metadata, not control flow)
- did NOT couple the schema test to a live fast gate spawn (would fail any time RELEASE_MANIFEST sha drifted from working tree)
- did NOT widen the status enum past 5 values without a `schema_version` bump
- did NOT use `rebuild_release_manifest.py` for the manifest sync (would have silently dropped F-T-01's tenancy block)

**Maintainer laptop evidence record** (2026-05-19):

| V | Command | Result |
|---|---|---|
| V1 | `pytest tests/governance/test_gate_report_schema.py` | 3/3 PASS in 0.04s |
| V2 | full `pytest tests/` | **995 passed / 2 skipped** in ~40s (was 992; +3 from B0 c1) |
| V3 | `run_release_closure_gate.py --profile fast` | 11/11 PASS in ~5s; all records `status=pass`; payload `schema_version=1.0.0` |
| V4 | `lint_layer_separation.py` | clean ✓ (35 roots / 0 violations + 1 runtime tree root / 0 leaks) |

**Charter alignment**: B0 is the v4.91 Milestone A first commit toward "Gate Runner Final Polish" required by the v4.91 plan §3 contract, not a regression fix. v4.90.11 + v4.91 batch14.19 already removed the structural failure modes (pipe deadlock, recursive self-test, grandchild leak); B0 c1 is the metadata layer that makes the gate's verdict externally machine-readable.

---

### B1 — Central Runtime Hub Core (v4.91, landed 2026-05-19)

**Closes**: the foundation of v4.91's Local-First Central Runtime Hub. Materialises the on-disk layout (`hub/`), the schema contracts (`schemas/hub/`), the lifecycle CLIs (`scripts/hub/`), and the Hub-CLI integration test surface — everything Milestone A's later batches (B2 mount/boundary increment, B3 version-lock) build on.

**Commits** (6):

```
a34ff41  feat(v4.91 B1 c1): hub/ 5 schemas (schema-first foundation)
d6d739d  feat(v4.91 B1 c2): hub/ skeleton + 4 state files + Layer 1 root extension
<c3>     feat(v4.91 B1 c3): scripts/hub init/link/list/unlink CLIs + flock+2PC helper
<c4>     feat(v4.91 B1 c4): inspect/validate/health/export-report CLIs + transients hygiene
9d45c61  test(v4.91 B1 c5): hub CLI lifecycle integration suite (8 tests)
<c6>     release(v4.91 B1 c6): F9 hub-smoke fast-gate item + RELEASE_NOTES B1 section
```

**EP design decisions baked in** (2026-05-19):

| # | Decision | Implementation |
|---|---|---|
| 1 | Atomic write mode | `fcntl.flock(LOCK_EX \| LOCK_NB)` advisory lock + `tempfile + os.replace` per file |
| 2 | Multi-file mutation | `HubTransaction` two-phase commit with byte-level snapshot rollback |
| 3 | Hub identity | `--hub-id` REQUIRED on `init_hub.py`; no auto-derivation from path or hostname |

**8 Hub CLIs delivered** (all under `scripts/hub/`):

| CLI | Purpose | Mutates state? |
|---|---|---|
| `init_hub.py` | Transition `hub_status` from `uninitialised` → `initialised` | yes (via 2PC) |
| `link_project.py` | Register a project mount | yes (via 2PC) |
| `unlink_project.py` | Remove a project; → `drained` when count=0 | yes (via 2PC) |
| `list_projects.py` | Print catalogue (table or JSON) | no |
| `inspect_project.py` | Print one project's index entry + mount snapshot | no |
| `validate_project_mount.py` | Schema-check one project's runtime protocol yaml | optional (`--refresh-fingerprint`) |
| `health_all_projects.py` | Run 3 checks per project; aggregate + atomic update | yes (via 2PC) |
| `export_hub_report.py` | Emit Hub-wide overview snapshot | optional (file write) |

**5 schemas delivered** (all `schemas/hub/`, `schema_version: "1.0.0"`):

- `global_os_config.schema.json` — Hub identity + bound Core + policies
- `projects_index.schema.json` — read-only project catalogue
- `mounts.schema.json` — Hub-side snapshot of each project's mount yaml
- `hub_state.schema.json` — Hub lifecycle state (`uninitialised`/`initialised`/`active`/`drained`)
- `health_report.schema.json` — `health_all_projects` + `export_hub_report` payload

**On-disk skeleton** (4 inert pre-init state files, ship in `hub/`):

- `global_os_config.yaml` (uninitialised_hub)
- `projects.index.json` (empty projects[])
- `mounts.yaml` (empty mounts[])
- `hub_state.json` (`hub_status: uninitialised`)
- `README.md` orientation note
- `logs/.gitkeep`, `reports/.gitkeep`, `preflight/.gitkeep`

**Hygiene plumbing** added in c4:

- `RELEASE_MANIFEST.json` `transient_patterns` extends with `hub/.hub.lock`, `hub/logs/`, `hub/reports/` (8 entries total)
- `verify_release_clean_tree.py::_is_transient` rewritten to support multi-segment dir prefixes + multi-segment exact paths (backwards-compatible)
- `verify_release_clean_tree.py::_is_generated_runtime` reads manifest's `generated_runtime_outputs[]` (was hard-coded to `exports/**`)
- `clean_transients.py` extends `_walk_targets` with `hub_lock` + `hub_runtime` kinds; never touches the 4 persistent state files

**Layer 1 governance extension** (across c2 + c3):

- `LAYER_1_ROOTS` 35 → 38 (`schemas/hub` + `tests/hub` in c2, `scripts/hub` in c3)
- `inv_002_layer_1_no_project_names` `trigger_files` extends; `must_preserve` evidence string updated 35 → 38

**Fast gate component**: c6 adds **F9 Hub CLI smoke** to `run_release_closure_gate.py --profile fast`, raising the smoke gate from 11 → **12 components**:

```
F9  Hub CLI smoke (v4.91 B1)         8/8 Hub CLI smoke commands OK
```

The 8 commands are the 2 read-only CLIs (`list_projects --format json`, `export_hub_report --stdout-only`) plus 6 `--help` invocations across the 6 mutating CLIs (`init_hub` / `link_project` / `unlink_project` / `inspect_project` / `validate_project_mount` / `health_all_projects`). Mutating commands are NOT executed in fast gate so the gate stays idempotent across repeated runs.

**Tests delivered**:

- `tests/hub/test_hub_schemas.py` — 22 tests (5 meta + 5 happy + 12 rejection)
- `tests/hub/test_hub_skeleton.py` — 5 tests (skeleton schema-validates)
- `tests/hub/test_hub_cli_lifecycle.py` — 8 tests (full lifecycle + 6 negative + 1 cross-file 2PC invariant)

**Anti-patterns explicitly avoided**:

- did NOT copy Core into the project root on `link_project` — links are logical references (Charter anti-pattern #9)
- did NOT auto-derive `hub_id` from path / hostname — explicit `--hub-id` required (Charter anti-pattern #2 + EP decision)
- did NOT support `mount_mode=copy` in `link_project` — schema enum locked to `["link"]` only
- did NOT support idempotent `unlink_project` — silent no-op on unknown id would mask typos
- did NOT use `subprocess.PIPE` for `HubTransaction` rollback — byte-level snapshot stored in memory
- did NOT add `--allow-mismatch` / `--skip-validation` escape hatches anywhere

**Maintainer laptop evidence record** (2026-05-19):

| V | Command | Result |
|---|---|---|
| V1 | `pytest tests/hub/` | **35/35 PASS** in ~1.8s (22 schema + 5 skeleton + 8 lifecycle) |
| V2 | full `pytest tests/` | **1030 passed / 2 skipped** (was 992 at v4.91 F-V-01; +38 across B0+B1) |
| V3 | `run_release_closure_gate.py --profile fast` | **12/12 PASS** in ~5.8s; F9 = `8/8 Hub CLI smoke commands OK` |
| V4 | `lint_layer_separation.py` | clean ✓ (38 roots / 0 violations + 1 runtime tree root / 0 leaks) |

**Charter alignment**: B1 closes the foundational requirement of v4.91 Plan §3 — "Central Runtime Hub Core". The Hub is local-first (no SaaS dashboard, no live services), schema-validated end-to-end, atomic across cross-file mutations, and never copies Core into projects. B2 (Project Mount + Boundary increment) and B3 (Version Lock & Core Update Policy) build on this foundation; subsequent milestones (B4 Shared LTM, B5 Cross-Project Inheritance, B5B Multi-Agent Preflight Consensus) consume Hub state via the schemas defined here.

---

### B2 — Project Mount + Boundary Contracts (v4.91, landed 2026-05-19)

**Closes**: the mount-level superset of the F-T-01 tenancy contract. F-T-01 (`project_runtime_protocol.yaml`) declares `runtime_namespace.claims[]`; B2 (`project_mount.yaml`) declares the mount-level write boundaries (`write_scope` / `cannot_write`), the lifecycle (stage / game_dev_phase split per v4.90.9 schema 1.1.0), and the optional preflight + host-profile blocks. The two coexist; F-T-01 stays canonical for tenancy.

**Note**: F-T-01 + F-V-01 (the v4.91 tenancy schema + verifier delivered 2026-05-18 at `c74d6f6` and `e6e408c`) **are part of B2's scope** per the v4.91 plan §1 backwards declaration — B2 c1-c3 is the mount-level increment built on top of that already-landed foundation.

**Commits** (3, all 2026-05-19):

```
5b34a60  feat(v4.91 B2 c1): schemas/mount project_mount + host_profile (mount-level superset)
5ea96e7  feat(v4.91 B2 c2): validate_project_mount honours project_mount.yaml + 8 tests
<c3>     docs(v4.91 B2 c3): MOUNT_CONTRACT.md + RELEASE_NOTES B2 section
```

**c1 deliverables** — schemas + tests:

- `schemas/mount/project_mount.schema.json` (NEW, draft-07, schema_version 1.0.0)
- `schemas/mount/host_profile.schema.json` (NEW, draft-07, schema_version 1.0.0; encodes Charter anti-pattern #13 with `auto_subagent_without_explicit_request: const false`)
- `tests/mount/__init__.py` (NEW)
- `tests/mount/test_mount_schemas.py` (NEW, **18 tests**: 2 meta + 2 happy + 14 rejection)

**c2 deliverables** — validator + tests:

- `scripts/hub/validate_project_mount.py` (REWRITTEN). Two-tier acceptance:
  - `project_mount.yaml` present → MUST schema-validate; cross-field checks (project_id match, write_scope ∩ cannot_write = ∅) enforced.
  - `project_mount.yaml` absent + `project_runtime_protocol.yaml` present → F-T-01 fallback accepted; deprecation hint printed.
  - Both absent → exit 1.
- New helper `_validate_project_mount_yaml(yaml_path)` — soft jsonschema dep.
- New helper `_check_write_scope_cannot_write_overlap(parsed)` — rejects direct equality + glob containment in either direction.
- `--refresh-fingerprint` captures sha256 of whichever yaml was actually validated.
- `tests/mount/test_project_mount_validation.py` (NEW, **8 tests**, fake-Core fixture mechanic).

**c3 deliverables** — docs:

- `docs/19_tenancy/MOUNT_CONTRACT.md` (NEW). 8-section human-readable reference covering: required fields, optional fields, validation policy two-tier table, what the Hub does NOT do (anti-pattern review), 8-row anti-pattern enforcement table, F-T-01-only → B2 migration recipe, cross-references to all 5 related schemas + the F-T-01 TENANCY_CONTRACT.

**Layer 1 governance extension** (across c1):

- `LAYER_1_ROOTS` 38 → 40 (`schemas/mount` + `tests/mount`)
- `inv_002_layer_1_no_project_names` `trigger_files` extends with `schemas/mount/**` + `tests/mount/**`; evidence string updated 38 → 40 roots

**Cross-field validation rules** (locked at validator level):

| # | Rule | Failure mode |
|---|---|---|
| 1 | `project_id` in mount.yaml MUST match the linked project_id | exit 1 + `'does not match linked project_id'` |
| 2 | `write_scope` ∩ `cannot_write` = ∅ | exit 1 + `'contained within write_scope'` / `'overlap'` |
| 3 | Every `write_scope` entry MUST be rooted at `.ai_dev_os/` and end with `**` | schema pattern violation, exit 1 |
| 4 | `stage` ∈ 7-enum, `game_dev_phase` ∈ 7-enum (independent) | schema enum violation, exit 1 |
| 5 | `preflight.policy_path` MUST point under `.ai_dev_os/preflight/` | schema pattern violation, exit 1 |

**Anti-patterns explicitly forbidden** (8 enforced at schema or validator level — see MOUNT_CONTRACT §6):

- `mount_mode: "copy"` — schema enum `["link"]` only
- `auto_subagent_without_explicit_request: true` in any host_profile — schema `const: false`
- Hard-coded project name in Core schema / non-fixture test — Layer 1 lint inv_002
- `--allow-extra` / `--skip-validation` flags — compile-time absence
- Auto-promote a project to `production` without explicit operator — schema enum
- Idempotent `unlink_project` (silent no-op) — exit 2
- Cross-tenant memory promotion without human approval — B5 `auto_apply_allowed: false`
- Adding `ltm/project/**` to manifest `transient_patterns` — F-V-01 bidirectional contract makes whitelist unnecessary

**Maintainer laptop evidence record** (2026-05-19):

| V | Command | Result |
|---|---|---|
| V1 | `pytest tests/mount/test_mount_schemas.py` | **18/18 PASS** in 0.07s |
| V2 | `pytest tests/mount/test_project_mount_validation.py` | **8/8 PASS** in 2.07s |
| V3 | `pytest tests/mount/` | **26/26 PASS** in ~2s |
| V4 | full `pytest tests/` | **1056 passed / 2 skipped** (was 1030; +26 from B2 c1+c2) |
| V5 | `run_release_closure_gate.py --profile fast` | **12/12 PASS** in ~6s |
| V6 | `lint_layer_separation.py` | clean ✓ (40 roots / 0 violations + 1 runtime tree root / 0 leaks) |

**Charter alignment**: B2 closes Plan §3 "Project Mount + Boundary Contracts" with the F-T-01 tenancy contract still canonical for runtime_namespace claims. The mount yaml is a strict superset that adds write boundaries the Hub MUST honour. Combined with B1's `HubTransaction` two-phase commit, validate_project_mount + flock + atomic state files give every Hub mutation cross-file consistency without requiring a project to opt into mount.yaml — F-T-01-only mounts continue to validate. B3 next hardens core_version_lock (currently a warn-only check in health_all_projects) into a proper `version_lock.yaml` contract.

---

### B3 — Version Lock & Core Update Policy (v4.91, landed 2026-05-20)

**Closes**: Milestone A. Hardens the warn-only `core_version_lock` check from B1 into a proper Hub-side contract: `hub/versions.lock` (atomically pinned), per-project upgrade plans (`hub/update_plans/<plan_id>.yaml`), and cross-project impact reports (`hub/reports/impact_<…>.json`). Lays the forward-compat preflight hook (`require_preflight_for[]`) that B5B will enforce.

**Commits** (4):

```
4d907a1  feat(v4.91 B3 c1): schemas/version + Core abstract identity files (MANIFEST.json + CHECKSUMS.txt + VERSION)
4dffaf8  feat(v4.91 B3 c2): hub-side version lock CLIs (lock_core_version + check_core_update_impact + generate_upgrade_plan) + state files
db1fca0  test(v4.91 B3 c3): policies/core_update_policy.md + 11 lock CLI / impact report tests
<c4>     release(v4.91 B3 c4): F10 fast-gate item + RELEASE_NOTES B3 + M-A close evidence + 9-doc sync + tag v4.91-M-A
```

**EP design decisions baked in** (handoff §5.5, locked 2026-05-20):

| # | Question | Decision | Rationale |
|---|---|---|---|
| Q1 | Top-level `MANIFEST.json` | New standalone Core abstract-identity view (coexists with `RELEASE_MANIFEST.json`) | Clean separation: Core identity vs release artifact view |
| Q2 | `lock_core_version` location | `scripts/hub/` (composes with existing 8 hub CLIs) | Avoids new LAYER_1_ROOTS entry; hub-global operations belong together |
| Q3 | `require_preflight_for[]` timing | Forward-compat declaration at B3 c1 (B5B enforces) | Schema once, no churn at B5B |

**c1 deliverables** — schemas + Core identity:

- 4 new schemas under `schemas/version/` (all `schema_version: "1.0.0"`, draft-07):
  - `version_lock.schema.json` — Hub global version pin (`hub_id` + `core_os_package` + `project_locks{}`)
  - `update_plan.schema.json` — per-project upgrade plan (`update_class` ∈ hotfix/minor/major; ordered actions[]; forward-compat `preflight_required` + `preflight_triggers[]`)
  - `impact_report.schema.json` — cross-project impact (`summary` sum invariant + per-project verdicts compatible/needs_review/blocked/deferred)
  - `core_update_policy.schema.json` — declarative policy with 5-trigger `require_preflight_for[]` enum
- Core abstract identity surface (3 NEW top-level files):
  - `MANIFEST.json` — package_name / package_version / lineage / schema refs / version_taxonomy / cross-link to RELEASE_MANIFEST.json
  - `CHECKSUMS.txt` — SHA-256 of VERSION + MANIFEST.json + 4 schemas (Core identity surface only)
  - `VERSION` — unchanged at `4.91-WIP`
- `tests/version/` (NEW): `test_version_schemas.py` (8 tests: 4 meta + 4 happy-path)

**c2 deliverables** — hub-side CLIs + state:

- `scripts/hub/lock_core_version.py` (NEW) — pre-conditions: hub_status ∈ {initialised, active, drained}; hub_id agreement between hub_state + global_config; linked_projects > 0 OR `--allow-empty-projects`. Atomic write via `HubLock` (flock+timeout) + `atomic_write_text` (sibling tempfile + os.replace). Schema-validates payload before write.
- `scripts/hub/check_core_update_impact.py` (NEW) — classifies `(from_version, to_version)` via X/Y/Z bump (suffixes stripped); produces impact_report payload with sum-invariant summary and per-project verdicts. Writes to `hub/reports/<report_id>.json` (transient kind).
- `scripts/hub/generate_upgrade_plan.py` (NEW) — composes ordered Charter-aligned action steps; `update_class=major` automatically sets `preflight_required=true` + `preflight_triggers=["major_version_bump"]`. `--defer` collapses to single `manual_owner_decision` step. Writes to `hub/update_plans/<plan_id>.yaml`.
- `hub/update_plans/.gitkeep` (NEW) — placeholder; `<plan_id>.yaml` files are runtime-only.
- `hub/versions.lock` — runtime-only; written by lock_core_version. Added to `RELEASE_MANIFEST.json :: exclusions.transient_patterns` and to `clean_transients.py :: hub_lock` category.
- `clean_transients.py` extends hub artifact walker: also reaps `hub/versions.lock` and `hub/update_plans/<file>`. The 4 persistent state files (`hub_state.json` / `global_os_config.yaml` / `projects.index.json` / `mounts.yaml`) remain untouched.

**c3 deliverables** — policy doc + tests:

- `policies/core_update_policy.md` (NEW, 8 sections):
  1. Three-tier version taxonomy (hotfix/minor/major) with examples
  2. **Preflight requirement matrix** — 5 triggers (`major_version_bump` / `cross_project_memory_policy_change` / `intent_boundary_policy_change` / `protected_invariant_change` / `tenancy_contract_change`), each mapped to detection mechanism
  3. State surface table (versions.lock vs update_plans/* vs reports/*)
  4. Action vocabulary table — kinds × class with `manual_owner_decision` terminator (anti-pattern #10)
  5. Verdict semantics + sum invariant
  6. Drift handling (`fingerprint_drift_action: warn|block`; `deferred_upgrade_grace_days`)
  7. Exit code matrix per CLI
  8. Charter anti-patterns this policy enforces (#2 #6 #10 #11 #12)
- `tests/version/test_version_lock_cli.py` (NEW, 3 tests) — subprocess + isolated tmp_path workspace; lifecycle pre-conditions exercised end-to-end (hub_status, hub_id agreement, empty-projects refusal).
- `tests/version/test_impact_report.py` (NEW, 8 tests) — 6 parametrised classify_update boundary cases + 2 build_report sum-invariant cases; in-process import for fast iteration.

**c4 deliverables** — release commit + M-A close:

- `scripts/governance/run_release_closure_gate.py`: adds **F10 Version Lock CLI smoke** (3 `--help` invocations against the new hub CLIs), raising fast gate from 12 → **13 components**. F10 is pure read; no state mutation; idempotent across repeated runs.
- 9-doc sync (per v4.90.9+ regulation 11): RELEASE_NOTES (this section) + Maintainer evidence record. Other documents (README / USER_GUIDE / V4_90_README / RELEASE_NOTES_v4.90-rc3 / CHANGELOG / docs/MANIFEST_HISTORY / docs/13_migration / docs/18_cli) are touched only when factual content changes — v4.91 M-A scoped to v4.91 patch chain banner; v4.90 documents are static at `v4.90.11 final` and deliberately NOT touched (Charter §11 byte-lock invariant inv_001).
- `RELEASE_MANIFEST.json` final sync: required_manifest_files 944 → 958 (+14 across B3); optional_seed_files 23 → 24 (+update_plans/.gitkeep); transient_patterns 8 → 10.
- Annotated tag `v4.91-M-A` (this commit).

**Layer 1 governance extension** (across c1 + c3):

- `LAYER_1_ROOTS` 40 → **43** (+`schemas/version` +`tests/version` in c1; +`policies` in c3)
- `inv_002_layer_1_no_project_names` `trigger_files` extends with `schemas/version/**` + `tests/version/**` + `policies/**`; evidence string updated 40 → 43

**Anti-patterns explicitly forbidden** (Charter alignment, all enforced at schema or runtime):

- **#2** — no auto-derived `hub_id` (lock_core_version reads from state and re-validates)
- **#6** — no evidence-threshold auto-promotion (lock pins; plans propose; nothing auto-applies)
- **#10** — no `auto_apply_*` action kinds (action enum locked at 7 manual-aware values)
- **#11** — preflight is NOT a gate-pass / completion proof (it is a prerequisite gate before lock advancement)
- **#12** — preflight is NOT majority-vote auto-implementation (every trigger is advisory consensus)

**Maintainer laptop evidence record** (2026-05-20):

| V | Time | Command | Result |
|---|---|---|---|
| V1 | 14:04:00 | full `pytest tests/` | **1075 passed / 2 skipped** in 46.31s (was 1056 at B2 close; +19 across B3 c1+c3) |
| V2 | 14:04:54 | `run_release_closure_gate.py --profile fast` (R1) | **13/13 PASS** in 6.03s (F1 collect: 1077; F4: 43 roots; F10: 3/3 Version Lock CLI smoke OK) |
| V3 | 14:06:12 | `run_release_closure_gate.py --profile fast` (R2) | **13/13 PASS** in 6.84s |
| V4 | 14:06:19 | `run_release_closure_gate.py --profile fast` (R3) | **13/13 PASS** in 6.91s |
| V5 | — | fast gate 3-run avg | **≈ 6.59s** (benchmark target ≤ 10s on maintainer laptop) |
| V6 | 14:07:00 | `lint_layer_separation.py` | clean ✓ (**43 roots** / 0 violations + 1 runtime tree root / 0 leaks) |

**Note on full release evidence gate**: v4.90's full gate (`run_v490_rc3_closure_gate.py`) checks C1=`pytest 953/2` and C2=`Layer 1 lint 33 roots` literally (frozen v4.90 baseline). Under v4.91's evolved state (1075 tests / 43 roots) the v4.90 RC3 contract correctly reports `expected 953/33` mismatches — this is **by design**: full gate is the v4.90 freeze witness, fast gate is the v4.91 working evidence. A v4.91-RC closure gate (with refreshed expected counts) is planned for v4.91 freeze; until then, fast gate 13/13 is the authoritative M-A evidence.

**Charter alignment**: B3 closes Milestone A by giving the Hub a complete version-lock + update-policy contract that respects every Charter anti-pattern. Combined with B0 (gate report 5-state status), B1 (Hub Core), and B2 (Mount + Boundary contracts), Milestone A delivers the foundation v4.91 M-B (Shared LTM + Cross-Project Inheritance) and M-C (B5B Multi-Agent Preflight Consensus + B5C Optional IDE Auto Escalation Adapter) build on.

---

## v4.91 Milestone A — Closed (2026-05-20)

**Tag**: `v4.91-M-A` (annotated)
**HEAD**: pinned by tag annotation
**Test baseline**: 1075 passed / 2 skipped (post-M-A close, maintainer laptop)
**Fast gate**: 13/13 PASS in ≈ 6.59s (3-run avg)
**Layer 1 lint**: 43 roots scanned / 0 violations + 1 runtime tree root / 0 leaks
**Total atomic commits**: 15 across B0 (2) + B1 (6) + B2 (3) + B3 (4)

**What M-A delivers**:

| Batch | Capability | Schema(s) | CLIs | Tests | Fast gate component |
|---|---|---|---|---|---|
| B0 | Gate Runner Final Polish | `gate_report.schema.json` | (none — metadata layer) | +3 | (existing F1-F8) |
| B1 | Central Runtime Hub Core | 5 hub schemas | 8 hub CLIs | +35 | F9 hub-smoke |
| B2 | Project Mount + Boundary | 2 mount schemas | (validate_project_mount rewrite) | +26 | (F4 root extension) |
| B3 | Version Lock & Core Update Policy | 4 version schemas | 3 hub CLIs | +19 | F10 version-lock-smoke |
| **M-A total** | **4 batches** | **12 schemas** | **11 net hub CLIs** | **+83 tests** | **2 new fast gate items** |

**What M-A does NOT include** (deferred to M-B / M-C):

- Shared LTM v3 cross-project read pipeline (M-B)
- Cross-project candidate inheritance (M-B)
- B5B Multi-Agent Preflight Consensus enforcement (M-C — schema hook is forward-compat ready in B3 c1)
- B5C Optional IDE Auto Escalation Adapter (M-C)
- v4.91-RC closure gate contract (deferred until v4.91 freeze)

**Next**: M-B starts with B4 (Shared LTM v3 read-side pipeline). The Hub state surface delivered in M-A (`hub/global_os_config.yaml` + `projects.index.json` + `mounts.yaml` + `hub_state.json` + `versions.lock`) is the shared substrate B4 reads from.

---

## v4.91 Addendum-A — External Core Mount by Default Rule (CLOSED 2026-05-20)

**Tag**: `v4.91-Addendum-A` (annotated)
**Trigger**: 2026-05-18 design addendum (`AI_Dev_OS_v4.91_External_Core_Mount_Default_Rule_Addendum.md`) escalating Charter anti-pattern #14 — *No Full Release Copy by Default*. Triggered by Workbuddy v4.90 adoption behaviour copying the full release bundle into the project root.
**Schema bump**: `mount` + `host_profile` + `version_lock` schemas all 1.0.0 → **1.1.0** (backward-compatible: optional new blocks; `mount_mode` enum widens with `link` kept as deprecated alias).
**Test baseline**: 1075 → **1121 passed** / 2 skipped (+46 across c1+c5).
**Fast gate**: 13 → **14 components** in ≈ 7.41s (3-run avg).

### EP decision matrix (locked 2026-05-20 14:55)

| Q | Decision | Locked at |
|---|---|---|
| Q1 | Batch ID = **Addendum-A**; tag = `v4.91-Addendum-A` | c1 |
| Q2 | mount_mode enum widens to `[link, external_core, thin_scaffold, vendor_snapshot]`; `link` kept 1 minor as deprecated alias | c1 |
| Q3 | Full move: `MOUNT_CONTRACT.md` git-mv from `docs/19_tenancy/` to `docs/20_project_mount/` | c4 |
| Q4 | Charter #14 adopted + locked into inv_002 must_preserve | c6 |

### Commits (7)

```
0643b2b  feat(v4.91 Addendum-A c1): schema 1.0.0 -> 1.1.0 widening
7cd8ca5  feat(v4.91 Addendum-A c2): detect_embedded_release_bundle.py + 12 VPM-* checks
ddfae13  feat(v4.91 Addendum-A c3): 4 host profile YAMLs + profiles/ Layer 1 root
318643d  docs(v4.91 Addendum-A c4): docs reorg + 4 new docs
7286047  test(v4.91 Addendum-A c5): 44 tests covering schema 1.1.0 + version_lock + detect script
c0f7a19  docs(v4.91 Addendum-A c6): charter anti-pattern #14 formalisation + inv_002 sweep
<c7>     release(v4.91 Addendum-A c7): F11 fast-gate item + RELEASE_NOTES Addendum-A + tag
```

### 5-layer enforcement matrix (Charter anti-pattern #14)

| # | Layer | Mechanism |
|---|---|---|
| 1 | Schema (compile-time) | `host_profile.project_adoption.copy_full_release_bundle_by_default: const false` + `mount.release_bundle_policy.allow_full_release_copy: const false` + `mount.mounted_core.writable: const false` + `mount.ownership.{project_truth_owner,release_bundle_truth_owner}` const lock |
| 2 | Runtime (filesystem) | `scripts/hub/detect_embedded_release_bundle.py` scans 5 forbidden globs (`v490_release/`, `v491_release/`, `AI_Game_Dev_OS_v*/`, `AI_Game_Dev_OS_Core/`, `vendor/ai_dev_os/` conditional); 3-state verdict (clean/sanctioned/violation); integrated as VPM-003 in validate_project_mount |
| 3 | Validator (12 VPM-* checks) | VPM-001..VPM-012; PASS/FAIL/SKIP three-state per check; integrated into `validate_project_mount.py :: main()` |
| 4 | Host profile (4 YAMLs) | `profiles/{workbuddy,codex,cursor,claude_code}/host_profile.yaml` declare 7 forbidden_default_actions + 9 allowed_actions + `default_mount_mode=external_core` |
| 5 | Documentation (5 docs + reorg) | `docs/20_project_mount/{PROJECT_MOUNT_MODEL,MOUNT_CONTRACT,MOUNT_BOUNDARY_CONTRACT,PROJECT_STATE_ISOLATION_RULES}.md` + `docs/21_host_profiles/HOST_PROJECT_ADOPTION_BOUNDARY.md` + `policies/charter_anti_patterns.md` (14-pattern SSoT) |
| 6 | Test corpus (44 tests) | `tests/mount/test_schema_addendum_a.py` (20) + `tests/version/test_version_lock_addendum_a.py` (11) + `tests/hub/test_detect_embedded_release_bundle.py` (13) |

### Schema 1.1.0 deltas

**`schemas/mount/project_mount.schema.json` 1.0.0 → 1.1.0**
- `mount_mode` enum widened from `["link"]` to `["link", "external_core", "thin_scaffold", "vendor_snapshot"]`. `link` kept 1 minor as deprecated alias.
- 4 NEW optional blocks: `mounted_core` (writable: const false) / `release_bundle_policy` (8 readonly flags + `allow_full_release_copy: const false`) / `forbidden_generated_paths` / `ownership` (project_truth_owner: const ".ai_dev_os")

**`schemas/mount/host_profile.schema.json` 1.0.0 → 1.1.0**
- 3 NEW optional blocks: `project_adoption` (`default_mount_mode` enum forward-only [excludes `link`]; `copy_full_release_bundle_by_default: const false`) / `forbidden_default_actions` (7-enum array) / `allowed_actions` (9-enum array)

**`schemas/version/version_lock.schema.json` 1.0.0 → 1.1.0**
- 2 NEW top-level fields: `mount_mode` (mirrors hub global config) / `embedded_release_bundle` block (`detected` + `allowed` required)

### F11 fast-gate item

`scripts/governance/run_release_closure_gate.py`: adds **F11 Detect Bundle CLI smoke** (`detect_embedded_release_bundle.py --help`), raising fast gate from 13 → **14 components**. F11 is pure read; no state mutation; idempotent across repeated runs.

### Layer 1 governance extension (across c3 + c4)

- `LAYER_1_ROOTS`: 43 → **46** (+`profiles/` in c3, +`docs/20_project_mount/` +`docs/21_host_profiles/` in c4)
- `inv_002_layer_1_no_project_names :: trigger_files` extends with the 3 new roots' globs
- `inv_002_layer_1_no_project_names :: must_preserve` adds:
  - `"46 roots scanned, 0 violations (post v4.91 Addendum-A c4 — added docs/20_project_mount + docs/21_host_profiles)"`
  - `"14 charter anti-patterns enforced (post v4.91 Addendum-A c6 — added #14 No Full Release Copy by Default)"`

### Manifest deltas

- `required_manifest_files`: 958 → **973** (+15 across c1-c7: +1 detect script, +5 host profiles, +1 MOUNT_CONTRACT relocation (-old +new = 0 net), +4 new docs in 20+21, +3 test files, +1 charter doc; ~10 sha refreshes on touched governance / schema / test files)

### Maintainer laptop evidence record (2026-05-20)

| V | Time | Command | Result |
|---|---|---|---|
| V1 | 16:52:53 | full `pytest tests/` | **1121 passed / 2 skipped** in 50.01s (was 1075 at M-A close; +46 across c1+c5) |
| V2 | 16:53:52 | `run_release_closure_gate.py --profile fast` (R1) | **14/14 PASS** in 7.77s (F11: 1/1 Detect Bundle CLI smoke OK; F4: 46 roots; F1 collect: 1123) |
| V3 | 16:54:00 | `run_release_closure_gate.py --profile fast` (R2) | **14/14 PASS** in 7.13s |
| V4 | 16:54:07 | `run_release_closure_gate.py --profile fast` (R3) | **14/14 PASS** in 7.33s |
| V5 | — | fast gate 3-run avg | **≈ 7.41s** (benchmark target ≤ 10s on maintainer laptop) |
| V6 | 16:54:22 | `lint_layer_separation.py` | clean ✓ (**46 roots** / 0 violations + 1 runtime tree root / 0 leaks) |

### What Addendum-A delivers

| Aspect | Before (M-A) | After (Addendum-A) |
|---|---|---|
| `mount_mode` valid values | 1 (`link`) | 4 (link as deprecated alias + 3 forward-only) |
| Schema-level Charter #14 guards | 0 | 5 (mount × 4 + host_profile × 1) |
| Runtime detection | none | `detect_embedded_release_bundle.py` + 12 VPM-* |
| Host profiles | (host_profile schema only) | 4 YAMLs (workbuddy/codex/cursor/claude_code) |
| docs/19_tenancy/ + docs/20_project_mount/ | 19 carried both tenancy and mount | tenancy in 19, mount in 20 (separation of concerns) |
| Charter anti-patterns formalised | 13 (in MEMORY only) | 14 (in `policies/charter_anti_patterns.md` Layer 1) |
| Charter #14 enforcement layers | 0 | 6 (schema + runtime + validator + host profile + docs + tests) |

### What Addendum-A does NOT include (deferred)

- Project-side adoption tool that emits the new `mounted_core` + `release_bundle_policy` + `ownership` blocks by default — still EP-driven manual edit
- Migration tool for existing projects with embedded release bundles — `PROJECT_STATE_ISOLATION_RULES.md §4` documents the 7-step manual recipe
- `link` alias removal — scheduled for v4.91-Addendum-B (one minor deprecation window)
- B5B preflight enforcement of mount_mode change as `tenancy_contract_change` trigger — forward-compat hook, B5B owns enforcement

### Charter alignment

Anti-patterns enforced post-Addendum-A (14, all green):

1. tenant paths in manifest exclusions
2. project names in Core
3. separate cross-tenant promotion engine
4. replace `project_runtime_protocol` schema (extend-only)
5. hardcoded RH / project literals
6. evidence-threshold auto-promote
7. `--allow-extra` / `--skip-tenant` escape hatches
8. "fix RH N files" task ID
9. Hub copies Core into projects (mount_mode enum)
10. cross-project candidate auto-apply
11. preflight as gate-pass
12. preflight majority-vote
13. host_profile auto multi-agent default
14. **No Full Release Copy by Default (NEW)**

Layer 1. No project names. M-A unchanged. Charter contract count: 13 → **14**.


---

## v4.91 Addendum-B — Link Alias Removal (CLOSED 2026-05-22)

> **Status**: CLOSED 2026-05-22 — c1-c7 all landed on `release/v4.90-fork`; annotated tag `v4.91-Addendum-B` applied at c7. See "v4.91 Addendum-B — Closed" summary section below for the maintainer evidence record.
>
> **Trigger**: Addendum-A (2026-05-20) widened `mount_mode` enum from `["link"]` to 4 values, keeping `link` as deprecated alias of `external_core` for **one minor** as the deprecation window. RELEASE_NOTES line 946 explicitly scheduled the removal: *"`link` alias removal — scheduled for v4.91-Addendum-B (one minor deprecation window)"*. Addendum-B is that window's terminal commit.
>
> **Theme**: Charter anti-pattern #15 — *No mount_mode aliases*. Lock the discipline that once an enum value is removed via Addendum-style narrowing, it cannot be reintroduced under any pretext (compat, convenience, alias, shim, normalization).

### EP decision matrix (locked 2026-05-22 17:38)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **schema_version stays 1.1.0** | Addendum-A widening (1.0.0→1.1.0) and Addendum-B narrowing together = full minor cycle; schema_version is contract identity, not strict-semver API version |
| Q2 | **Hard removal** of `link` enum value | Charter SOP §11 deprecation window already promised via Addendum-A; v4.91-Addendum-B IS that window's terminal commit. No soft warn / no replace-on-read normalization |
| Q3 | **Add Charter anti-pattern #15** "No mount_mode aliases" | Prevent v4.92+ reintroduction; locks future schema discipline at the Charter layer |
| Q4 | **Add F16 link-removal-smoke** to fast gate | Cleanup work made visible in CI; fast gate 18 → 19 components |

### Commits (7 planned; c1-c5 landed)

```
77b14de  feat(v4.91 Addendum-B c1): schema enum narrowing — link removed (3 schemas, 1.1.0 unchanged)
76faba1  feat(v4.91 Addendum-B c2): runtime narrowing — 4 hub scripts default to external_core
f202395  chore(v4.91 Addendum-B c3): state migration + Charter anti-pattern #15
dc47f7f  docs(v4.91 Addendum-B c4): mount/host_profiles docs sweep (4 docs + 1 README)
b3e3a9e  test(v4.91 Addendum-B c5): 7 fixtures migrate + 9 new tests + 3 hub schema fixes (test discovery)
<c6>     docs(v4.91 Addendum-B c6): inv_002 sweep + RELEASE_NOTES Addendum-B intro
<c7>     release(v4.91 Addendum-B c7): F16 link-removal-smoke + RELEASE_NOTES close + tag v4.91-Addendum-B
```

### 6-layer enforcement matrix (Charter anti-pattern #15)

| # | Layer | Mechanism (Addendum-B) |
|---|---|---|
| 1 | Schema (compile-time) | 3 originally-planned schemas (project_mount × 2 enum touches + version_lock + host_profile description-only) PLUS 3 hub-side schemas discovered during c5 testing (global_os_config + projects_index + mounts) — total **6 schemas** narrowed from 4-value or `["link"]` enums to the 3 forward-only values `[external_core, thin_scaffold, vendor_snapshot]`. schema_version of all 1.1.0 schemas stays at `"1.1.0"` const |
| 2 | Runtime (filesystem) | `init_hub.py` mount_default `link` → `external_core`; `link_project.py` 2 default writes; `validate_project_mount.py` VPM-002 valid_modes set 4 → 3; `detect_embedded_release_bundle.py` VALID_MODES set 4 → 3 (argparse choices auto-narrow at parse time) |
| 3 | State surface | `hub/global_os_config.yaml` mount_default field migrated to `external_core` |
| 4 | Charter (Layer 1 doc) | `policies/charter_anti_patterns.md` table extended to 15 rows; new §2A "The 15th anti-pattern in detail" with 4 sub-sections (statement / removed values table / 5-layer enforcement / slippery-slope rationale) |
| 5 | Documentation | 4 mount/host_profiles docs + `profiles/README.md` swept — 9 remaining `link` mentions all intentional and cite Charter #15 / Addendum-B / migration recipe |
| 6 | Tests + fast gate | 7 existing fixture files migrated `link` → `external_core`; 1 NEW `tests/mount/test_addendum_b_link_removal.py` with 9 tests covering schema (4) + runtime (3) + state (1) + Charter doc (1); F16 link-removal-smoke fast-gate item lands in c7 |

### c1-c5 deliverables (5-layer view)

**c1 schema layer (3 schemas, +0 -0 net files)**:
- `schemas/mount/project_mount.schema.json`: top-level mount_mode enum 4 → 3 values; mounted_core.mount_mode enum 4 → 3 values; description rewrite drops `link is DEPRECATED` paragraph
- `schemas/version/version_lock.schema.json`: mount_mode enum 4 → 3 values; description drops `link is deprecated alias` phrasing
- `schemas/mount/host_profile.schema.json`: description-only update (default_mount_mode enum was already 3-value forward-only since Addendum-A)

**c2 runtime layer (4 hub scripts)**:
- `scripts/hub/init_hub.py`: global_os_config.policies.mount_default default `link` → `external_core`
- `scripts/hub/link_project.py`: new_index_entry.mount_mode + new_mount_record.mount_mode defaults `link` → `external_core` (function name `link_project` STAYS — it's the action verb, not a mount_mode value)
- `scripts/hub/validate_project_mount.py`: VPM-002 valid_modes set 4 → 3; VPM_CHECK_DESCRIPTIONS doc string updated
- `scripts/hub/detect_embedded_release_bundle.py`: VALID_MODES module-level set 4 → 3; argparse --mount-mode choices auto-narrow

**c3 state migration + Charter doc**:
- `hub/global_os_config.yaml`: policies.mount_default `link` → `external_core`
- `policies/charter_anti_patterns.md`: header 14 → 15; table row #15 added; new §2A 4-sub-section detail block; tail line updated

**c4 docs sweep (5 files)**:
- `docs/20_project_mount/MOUNT_CONTRACT.md`: §2 + §6 + minimal mount.yaml example
- `docs/20_project_mount/PROJECT_MOUNT_MODEL.md`: title + §1 lead paragraph rewritten
- `docs/20_project_mount/MOUNT_BOUNDARY_CONTRACT.md`: VPM-002 description
- `docs/21_host_profiles/HOST_PROJECT_ADOPTION_BOUNDARY.md`: §2 default mount mode + Allowed/Forbidden table
- `profiles/README.md`: anti-pattern list + tail line

**c5 tests + 3 schema discovery fixes**:
- 7 existing fixture migrations (mount × 3 + version × 2 + hub × 2)
- 1 NEW `tests/mount/test_addendum_b_link_removal.py` with 9 tests (+224 lines)
- 3 hub schema fixes uncovered during testing: `schemas/hub/{global_os_config, projects_index, mounts}.schema.json` — these B1-era schemas pre-dated Addendum-A and carried single-`["link"]` or `["link", "copy"]` enums; c5 brings them into compliance with the unified 3-mode set

### inv_002 must_preserve sweep (10th row, this commit)

`runtime/protected_contracts/protected_regression_matrix.yaml :: inv_002_layer_1_no_project_names`:

- `must_preserve` row 10 added: `"15 charter anti-patterns enforced (post v4.91 Addendum-B c6 — added #15 No mount_mode aliases; mount_mode enum narrowed across 6 schemas ... schema_version stays 1.1.0)"` (full text in the yaml)
- `trigger_files` adds `tests/mount/test_addendum_b_link_removal.py` (existing `tests/mount/**` glob already covers it; explicit listing improves audit traceability)
- Total: must_preserve **9 → 10 rows**; trigger_files **86 → 87**

### Maintainer evidence record (live)

Pre-c6 partial evidence (full evidence record lands in c7 RELEASE_NOTES Addendum-B close):

- pytest tests/ (post-c5): **1286 passed / 2 skipped / 1 failed** in 64.53s. The 1 failure is `test_release_manifest_round_trip` — expected at this cadence point because manifest sha sync is c7's job. All other tests including the 9 new `test_addendum_b_link_removal.py` tests pass.

c7 will add F16 fast-gate item (fast gate 18 → 19 components), refresh `RELEASE_MANIFEST.json` (count 1014 → 1015 with 1 new test file), record final maintainer evidence (V1-V6), and apply the annotated tag `v4.91-Addendum-B`.


## v4.91 Milestone B — Controlled Learning (CLOSED 2026-05-22)

> **Status**: CLOSED 2026-05-22 — B4 + B5 + B5B + B6 all closed, integral milestone tag `v4.91-M-B` (see `## v4.91 Milestone B — Closed (2026-05-22)` summary section near end of file).
>
> **Theme**: cross-project learning surface (Shared LTM v3 + B5 promote/quarantine + B5B preflight consensus + B6 evolution capture). M-A delivered the Hub state surface (B1) + version lock (B3) + tenancy/mount contracts (F-T-01 + Addendum-A); M-B uses that surface to deliver auditable learning across projects without breaking tenancy.

### B4 — Shared LTM v3 Read-Side Pipeline (in flight, c1-c6 landed 2026-05-20..21)

**Closes**: opens M-B by replacing v2 domain-priority routing with **scope-level** routing on top (the two coexist). v3 introduces explicit `calling_project_id` POV, hard-isolation of `other_project_private`, and an auditable `routing_report` per retrieval. Forward-compat preflight schemas (`preflight_case` + `preflight_metric`) land at the same time so M-C B5B can consume them directly.

**EP decision matrix** (locked 2026-05-20 17:11):

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **CLI-first** (`retrieve_with_routing.py --query --project-id`; runtime adapter import deferred to B8) | v4.91 charter wants every read pipeline auditable via stdout JSON |
| Q2 | **Hard isolation**: `other_project_private` always excluded; NO `--include-other-project` / `--allow-cross-project` escape hatch | Charter anti-pattern #7 enforced at routing layer |
| Q3 | **2 NEW v3 schemas** sibling to v2 `memory_retrieval_routing` | Scope routing and domain priority are orthogonal — no v2 bump needed |
| Q4 | **Preflight schemas built early at B4 c1** | M-C B5B consumes them directly without retroactive schema design |

**Commits** (7 planned; c1-c6 landed):

```
a8050cf  feat(v4.91 B4 c1): schemas/ltm v3 + preflight (4 NEW schemas, all 1.0.0)
ca909d4  feat(v4.91 B4 c2): retrieve_with_routing.py + generate_routing_report.py + default policy
60accc7  feat(v4.91 B4 c3): cross_project + preflight skeleton dirs (7 sub-dirs + 2 READMEs)
6f7ad2a  docs(v4.91 B4 c4): docs/22_ltm_v3 (3 new docs) + LAYER_1_ROOTS 46 -> 47
089b86d  test(v4.91 B4 c5): 35 tests covering v3 schemas + retrieve_with_routing end-to-end
<c6>     docs(v4.91 B4 c6): inv_002 sweep + RELEASE_NOTES M-B + B4 intro
<c7>     release(v4.91 B4 c7): F12 fast-gate item + RELEASE_NOTES B4 close + tag v4.91-M-B-B4
```

**c1 deliverables** — 4 NEW v3 schemas (all `schema_version: "1.0.0"`):

- `schemas/ltm/retrieval_policy.schema.json` — scope-level routing policy. `default_include[]` enum locked to `[current_project, os, approved_cross_project, pattern, failures]`; `default_exclude[]` enum locked to `[other_project_private, quarantine, rejected, unapproved_candidates, superseded]`; `tenancy_enforcement.mode` enum-locked to single value `"strict"` (Charter anti-pattern #7 compile-time guard).
- `schemas/ltm/routing_report.schema.json` — auditable per-retrieval output. `skipped_paths[]` items carry mandatory `reason` enum (`tenancy_reconciliation_failed` / `scope_excluded` / `schema_invalid` / `missing_evidence_ref`).
- `schemas/ltm/preflight_case.schema.json` — forward-compat for B5B. `consensus.decided_by` is a SINGLE string (Charter anti-pattern #11/#12 schema shape lock — no `votes[]` field exists).
- `schemas/ltm/preflight_metric.schema.json` — forward-compat for B5B. NO `promote_to` / `auto_apply` / `promotion_*` field (Charter anti-pattern #6).

**c2 deliverables** — 2 read-only CLIs + default policy:

- `scripts/ltm/retrieve_with_routing.py` — walks `<ltm_root>/**/*.md`, classifies each path into one of 9 scope categories, applies `default_include` / `default_exclude` from policy, scores by query term frequency × scope boost, validates output against `routing_report` schema (best-effort jsonschema), prints `{routing_report, ranked_results}` JSON to stdout. Hard-isolation: `other_project_private` paths skipped before include[] consultation.
- `scripts/ltm/generate_routing_report.py` — routing-only dry-run for policy debugging + B5B preflight pre-warm. Reuses `retrieve_with_routing` helpers via importlib (single source of truth).
- `ltm/retrieval_policy.yaml` — Layer 1 default policy. `tenancy_enforcement.mode='strict'`; boost 1.5/1.0/0.8 for current/os/approved_cross_project; `max_results=20`.

**c3 deliverables** — 7 skeleton dirs + 2 READMEs:

- `ltm/cross_project/{candidates,approved_patterns,rejected,superseded}/.gitkeep` — match v3 routing scopes (`unapproved_candidates` / `approved_cross_project` / `rejected` / `superseded`)
- `ltm/preflight/{cases,pattern_candidates,metrics}/.gitkeep` — B5B-owned write surface; v3 router does NOT route into `preflight/*` (operational data, not learning material)
- `ltm/preflight/README.md` (NEW) + `ltm/cross_project/README.md` updated with v4.91 B4 c3 4-way split + cross-link to preflight + retrieval_policy

**c4 deliverables** — `docs/22_ltm_v3/` (3 NEW docs):

- `SHARED_LTM_V3_OVERVIEW.md` — 6 sections (why v3 / scope vocabulary / read flow ASCII / charter alignment / forward-compat / next steps)
- `RETRIEVAL_POLICY.md` — 7 sections (required + optional fields / default policy / override discipline / versioning / charter)
- `ROUTING_REPORT.md` — 8 sections (required + results + skipped_paths reason enum / validation / audit obligations / backward-compat / charter)

**c5 deliverables** — 35 tests:

- `tests/ltm/test_v3_schemas.py` (23 tests): 4 meta-validation parametrised + 5 retrieval_policy reject + 5 routing_report (incl. 2-char project_id compat) + 5 preflight_case (incl. Charter #12 list-not-string reject) + 4 preflight_metric (incl. Charter #6 promote_to reject)
- `tests/ltm/test_retrieve_with_routing.py` (12 tests): subprocess + isolated tmp_path workspace fixture covering all 9 scopes; Charter #7 end-to-end test (`test_retrieve_hard_isolates_other_project_private`)

**Layer 1 governance extension** (across c3 + c4):

- `LAYER_1_ROOTS`: 46 → **47** (+`docs/22_ltm_v3` in c4; `ltm/cross_project/**` and `ltm/preflight/**` are runtime-state, not Layer 1 content)
- `inv_002 trigger_files` extends with `docs/22_ltm_v3/**` + the 4 v3 schemas + the 2 v3 CLIs + `ltm/retrieval_policy.yaml` + `ltm/cross_project/**` + `ltm/preflight/**` + the 2 new test files
- `inv_002 must_preserve` adds: `"Shared LTM v3 hard-isolation contract (post v4.91 B4 c6 — other_project_private always excluded; tenancy_enforcement.mode='strict' schema-locked; no override_* / allow_*_for_project / bypass_* fields permitted)"`

**Charter alignment**:

| # | Anti-pattern | B4 enforcement |
|---|---|---|
|  2 | Project names in Core | Scope vocabulary uses category tokens; classifier output references project_id only as POV input, never as scope label |
|  6 | Evidence-threshold auto-promote | preflight_metric schema rejects `promote_to`; scoring boosts only re-rank within scope |
|  7 | --allow-extra / --skip-tenant escape hatches | retrieval_policy schema additionalProperties=false rejects `override_*`; tenancy_enforcement.mode enum-locked to `strict`; CLI surface lacks any `--include-other-project` / `--allow-cross-project` flag |
| 11 | Preflight as gate-pass | preflight_case.consensus.outcome enum locked; v3 router does NOT route preflight/* by default |
| 12 | Preflight majority-vote | preflight_case.consensus.decided_by is single string (no `votes[]` field exists) |

**Anti-patterns the schema layer now refuses** (compile-time guards):

- retrieval_policy.yaml with `other_project_private` in `default_include[]` — schema enum reject
- retrieval_policy.yaml with `tenancy_enforcement.mode: lenient` — schema enum reject
- retrieval_policy.yaml with `override_*` / `allow_other_project_*` field — `additionalProperties: false` reject
- preflight_case.json with `votes[]` or `decided_by` as list — schema shape reject
- preflight_metric.json with `promote_to` field — `additionalProperties: false` reject

**c7 will land**: F12 Shared LTM v3 CLI smoke (`retrieve_with_routing` + `generate_routing_report` --help) raising fast gate from 14 → **15 components**, RELEASE_NOTES B4 close section + maintainer 3-run evidence, and the annotated tag `v4.91-M-B-B4`.


### B4 — close (landed 2026-05-21)

**c7 deliverables** — release commit + tag:

- `scripts/governance/run_release_closure_gate.py`: adds **F12 Shared LTM v3 CLI smoke** (2 `--help` invocations: `retrieve_with_routing.py` + `generate_routing_report.py`), raising fast gate from 14 → **15 components**. F12 is pure read; no state mutation; idempotent across repeated runs.
- RELEASE_NOTES.md: B4 close section (this section) + Release date line extended with the 2026-05-21 v4.91 B4 close phrase.
- `RELEASE_MANIFEST.json` final sync: `required_manifest_files` 992 → final (1 sha refresh on `run_release_closure_gate.py` + RELEASE_NOTES across c6/c7).
- Annotated tag `v4.91-M-B-B4`.

**Maintainer laptop evidence record** (2026-05-21):

| V | Time | Command | Result |
|---|---|---|---|
| V1 | 11:53:00 | full `pytest tests/` | **1156 passed / 2 skipped** in 55.67s (was 1121 at Addendum-A close; +35 from B4 c5) |
| V2 | 11:54:06 | `run_release_closure_gate.py --profile fast` (R1) | **15/15 PASS** in 7.78s (F12: 2/2 Shared LTM v3 CLI smoke OK; F1 collect: 1158; F4: 47 roots) |
| V3 | 11:54:14 | `run_release_closure_gate.py --profile fast` (R2) | **15/15 PASS** in 7.42s |
| V4 | 11:54:21 | `run_release_closure_gate.py --profile fast` (R3) | **15/15 PASS** in 7.26s |
| V5 | — | fast gate 3-run avg | **≈ 7.49s** (benchmark target ≤ 10s on maintainer laptop) |
| V6 | 11:54:35 | `lint_layer_separation.py` | clean ✓ (**47 roots** / 0 violations + 1 runtime tree root / 0 leaks) |

### Delta vs Addendum-A close (230356b)

| Aspect | Addendum-A close | B4 close |
|---|---|---|
| pytest | 1121 / 2 | **1156 / 2** (+35) |
| fast gate components | 14 | **15** (+F12 Shared LTM v3 smoke) |
| LAYER_1_ROOTS | 46 | **47** (+`docs/22_ltm_v3`) |
| schemas/ltm/ count | 5 (v2 era) | **9** (+4 v3) |
| scripts/ltm/ count | 6 (v2 era) | **8** (+retrieve_with_routing + generate_routing_report) |
| ltm/ subdirs | 8 | **15** (+4 cross_project sub +3 preflight sub) |
| docs roots | 4 in 19_tenancy/20_project_mount/21_host_profiles + (15_ltm_v2 etc.) | **+1** (`docs/22_ltm_v3`) |
| Charter contract surface (must_preserve) | 5 rows | **6 rows** (+v3 hard-isolation) |
| inv_002 trigger_files | (B4 c4 base) | **+16 entries** |
| required_manifest_files | 973 | **993** final (+20 net) |

### What B4 delivers

| Layer | Mechanism |
|---|---|
| 1 schema (compile-time) | 4 v3 schemas with const/enum/`additionalProperties: false` guards (5 explicit anti-pattern reject sites) |
| 2 runtime (CLI) | `retrieve_with_routing.py` hard-isolates `other_project_private` before consulting `default_include[]` |
| 3 state surface | `ltm/cross_project/{candidates,approved_patterns,rejected,superseded}/` + `ltm/preflight/{cases,pattern_candidates,metrics}/` (7 sub-dirs + .gitkeep × 7 + 2 READMEs) |
| 4 default policy | `ltm/retrieval_policy.yaml` with `tenancy_enforcement.mode='strict'` |
| 5 docs | 3 docs in `docs/22_ltm_v3/` (OVERVIEW + RETRIEVAL_POLICY + ROUTING_REPORT) |
| 6 tests | 35 tests across schemas + CLI smoke (incl. Charter #7 alpha→beta end-to-end isolation) |
| 7 fast gate | F12 Shared LTM v3 CLI smoke (2/2) |
| 8 inv_002 | +1 must_preserve row + 16 trigger_files entries |

### What B4 does NOT include (deferred)

- The promotion CLI from `cross_project/candidates/` → `cross_project/approved_patterns/` — owned by `promote_memory_candidate.py` from v4.90 Batch 8 + future B5 wiring
- B5B Multi-Agent Preflight Consensus enforcement — schema hooks (`preflight_case` + `preflight_metric` at 1.0.0) ready and frozen here; the consensus runtime is M-C
- The B6 Evolution Capture write-back into `ltm/_quarantine/` — deferred
- Runtime adapter import (Python module surface for in-process retrieval) — deferred to B8 per EP Q1=A
- A v4.91-RC closure gate — deferred to v4.91 freeze

### Charter alignment (B4 close)

Anti-patterns enforced post-B4 (14, all green):

- **#2** project names in Core — scope vocabulary uses category tokens
- **#6** evidence-threshold auto-promote — preflight_metric schema rejects `promote_to`; scoring boosts only re-rank
- **#7** escape hatches — schema enum + `additionalProperties: false` + CLI surface lacks override flags + inv_002 must_preserve row
- **#11** preflight as gate-pass — `preflight/*` not routed by v3 reader; `consensus.outcome` enum locked
- **#12** preflight majority-vote — `consensus.decided_by` single string; no `votes[]` field

### Next

M-B continues with B5 (LTM write/promotion gates: candidate intake + cross-domain gate), then B5B (Multi-Agent Preflight Consensus enforcement, consuming the c1 forward-compat preflight schemas), then B6 (Evolution Capture). M-A + Addendum-A unchanged across the milestone.

**Tag**: `v4.91-M-B-B4` (annotated)
**Branch**: `release/v4.90-fork`
**Commits**: 7 across c1+c2+c3+c4+c5+c6+c7

Layer 1. No project names. M-A + Addendum-A unchanged.


---

### B5 — LTM Write/Promotion Gates (in flight, c1-c6 landed 2026-05-21)

**Closes**: continues M-B by closing the LTM write loop. M-B B4 delivered the **read** pipeline (scope-level routing + hard isolation + auditable routing_report); B5 delivers the **write** pipeline: candidate → {promoted, rejected, superseded} state machine, each with a schema-locked sidecar ledger and a Charter-aligned forbidden_approvers vocabulary refused at runtime. Combined with B4, M-B's controlled-learning surface is now functional end-to-end (pending B5B preflight enforcement, B6 evolution capture).

**EP decision matrix** (locked 2026-05-21 13:55):

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **Auto-migrate**: `promote --to cross_project` lands content under `cross_project/approved_patterns/` automatically | Forces all new promotions through the v3 routing scope; v4.90 entries at top level still validate |
| Q2 | **Peer sibling CLIs**: `reject_memory_candidate.py` + `supersede_memory_candidate.py` | Same idempotency model as promote; same gate semantics; same output format |
| Q3 | **3 independent ledger schemas**: promotion_ledger + reject_ledger + supersede_ledger each at 1.0.0 | Semantic clarity > aggregate query convenience; schema shape per anti-pattern enforcement |
| Q4 | **New `ltm/promotion_policy.yaml` sibling to retrieval_policy.yaml** | Phase separation (read vs write); Charter audit boundary |

**Commits** (7 planned; c1-c6 landed):

```
d15c772  feat(v4.91 B5 c1): promotion_policy + 3 ledger schemas (4 NEW, all 1.0.0)
80d3459  feat(v4.91 B5 c2): promote v3 4-way migration + load promotion_policy.yaml + write schema-locked ledger
cd1b4b7  feat(v4.91 B5 c3): reject_memory_candidate + supersede_memory_candidate (2 NEW CLIs)
6bbd66a  docs(v4.91 B5 c4): docs/22_ltm_v3/PROMOTION_LIFECYCLE.md (8 sections)
48ff304  test(v4.91 B5 c5): 43 tests covering reject + supersede + roundtrip lifecycle
<c6>     docs(v4.91 B5 c6): inv_002 sweep (B5 surface) + RELEASE_NOTES B5 intro
<c7>     release(v4.91 B5 c7): F13 fast-gate item + RELEASE_NOTES B5 close + tag v4.91-M-B-B5
```

**c1 deliverables** — 4 NEW schemas (all `schema_version: "1.0.0"`):

- `schemas/ltm/promotion_policy.schema.json` — `thresholds.cross_project_min_evidence_refs` integer 2..16 (Charter anti-pattern #6: dual-bound prevents `set threshold to MAX_INT` bypass); `approval.mode` enum-locked to single value `"strict"`; `approval.forbidden_approvers` 6-token enum (auto/system/agent/automation/robot/ci); `supersede.must_reference_replacing_entry: const true`.
- `schemas/ltm/promotion_ledger.schema.json` — `event_type` const `"promoted"`; `ledger_id` pattern `"^promote_[a-z0-9_]*$"`; `promoted_by` pattern + minLength two-stage form (per the regex `{n,m}` quantifier trap MEMORY lesson from B4 c5).
- `schemas/ltm/reject_ledger.schema.json` — `event_type` const `"rejected"`; `rejection_reason` enum-locked to 7 values (insufficient_evidence/tenancy_violation/schema_invalid/duplicate_of_existing/out_of_scope/low_quality/policy_violation).
- `schemas/ltm/supersede_ledger.schema.json` — `event_type` const `"superseded"`; `replacing_entry_ledger_ref` pattern lock `"^promote_[a-z0-9_]*$"` (Charter audit chain: every supersede MUST cite a real promotion).

**c2 deliverables** — promote extension + default policy:

- `scripts/ltm/promote_memory_candidate.py` extension (NOT a new CLI): adds `_load_promotion_policy(ltm_root)` (best-effort YAML+jsonschema), `_slug_for_ledger_id(prefix, candidate_id)`, dynamic G3 threshold sourced from policy, runtime forbidden_approvers refusal (case-insensitive lower-cased compare), v3 schema-locked ledger sidecar when `policy_version` supplied. Auto-migrates `--to cross_project` to `cross_project/approved_patterns/` with `mkdir(parents=True, exist_ok=True)` so v4.90 callers that pre-create only `cross_project/` still work.
- `ltm/promotion_policy.yaml` (NEW) — Layer 1 default policy. Threshold `cross_project_min_evidence_refs=2` (preserves v4.90 baseline); `approval.mode='strict'`; 6 forbidden_approvers tokens; supersede const guard.

**c3 deliverables** — 2 NEW lifecycle CLIs (read-write, 1 mutation per invocation):

- `scripts/ltm/reject_memory_candidate.py` (232 lines) — copies candidate JSON to `cross_project/rejected/` (audit retention; source kept in `_quarantine/` as the idempotency anchor); writes `<candidate>.rejected.json` sidecar matching schema 1.0.0; idempotent via `candidate.rejected_by` field.
- `scripts/ltm/supersede_memory_candidate.py` (269 lines) — moves entry to `cross_project/superseded/`; writes `<moved>.superseded.json` sidecar; runtime double-check that `--replacing-entry-ledger` has `event_type='promoted'` AND `ledger_id` matches `'^promote_'`; idempotent via target file + ledger sidecar coexistence.
- DRY: both new CLIs `from scripts.ltm.promote_memory_candidate import _load_promotion_policy, _slug_for_ledger_id, DEFAULT_FORBIDDEN_APPROVERS` — single source of truth for charter enforcement across all 3 lifecycle CLIs.

**c4 deliverables** — `docs/22_ltm_v3/PROMOTION_LIFECYCLE.md` (NEW, 8 sections):

State machine ASCII (`_quarantine → {promoted, rejected, superseded}`), gates G1..G6, Charter alignment table, ledger conventions (type-disjoint id family + sidecar matrix + schema_version bump policy), CLI matrix with required flags + idempotency anchor + exit codes, **reject vs supersede decision tree** (the recurring confusion: reject blocks promotion, supersede continues a promotion lifecycle; want to remove a canonical entry without replacement is an anti-pattern), audit recipe (bash one-liner grep across 3 ledger_id prefixes), cross-link to sister docs.

**c5 deliverables** — 43 tests:

- `tests/ltm/test_reject_memory_candidate.py` (24 tests): 7 reason enum × parametrised + 6 forbidden approver lowercase + case-insensitive (AUTO) + audit retention + ledger_id pattern + event_type const + JSON format
- `tests/ltm/test_supersede_memory_candidate.py` (14 tests): audit chain cross-ref structural lock + replacing ledger event_type/prefix double-check + idempotent + retention
- `tests/ltm/test_promotion_lifecycle_roundtrip.py` (5 tests): subprocess-driven multi-step state machine paths matching PROMOTION_LIFECYCLE.md (quarantine→promote→retrieve / promote→supersede audit chain / reject terminal / hard isolation post-promote re-asserted at M-B boundary / ledger family disjoint)

**c6 deliverables** — inv_002 sweep + RELEASE_NOTES B5 intro:

- `runtime/protected_contracts/protected_regression_matrix.yaml`: `inv_002 trigger_files` extends with 12 new entries (4 schemas + 3 CLIs + 1 policy YAML + 3 test files + 1 lifecycle doc); `must_preserve` adds the canonical Charter audit chain enforcement evidence row:
  > "LTM lifecycle audit chain locked (post v4.91 B5 c6 — supersede_ledger.replacing_entry_ledger_ref pattern '^promote_' + runtime double-check; ledger_id family disjoint promote_/reject_/supersede_; event_type const-disjoint; forbidden_approvers vocabulary refused at runtime by all 3 lifecycle CLIs)"
- `RELEASE_NOTES.md`: this section.

**Charter alignment** (B5 enforcement layers):

| # | Anti-pattern | B5 enforcement |
|---|---|---|
|  6 | Evidence-threshold auto-promote | `promotion_policy.thresholds.*` integer-bounded 1..16 / 2..16; promote/reject/supersede all single-action CLIs (no auto-execute); preflight_metric schema (B4 c1) refuses `promote_to` field |
|  7 | --allow-extra / --skip-tenant escape hatches | All 3 lifecycle schemas `additionalProperties: false`; `approval.mode` enum-locked to `"strict"`; CLI surface lacks any `--bypass-policy` / `--skip-forbidden` / `--allow-cross-project` flag; case-insensitive forbidden_approvers refusal |
| 11 | Preflight as gate-pass | Promote/reject/supersede ledgers describe **outcome**, not preflight execution status; preflight_case (B4 c1) carries that contract |
| 12 | Preflight majority-vote | All 3 ledgers have a single string approver field (promoted_by / rejected_by / superseded_by_user); no `votes[]` surface exists |
| Audit chain | (M-B-locked) | `supersede_ledger.replacing_entry_ledger_ref` pattern lock + runtime double-check; `ledger_id` family disjoint (promote_/reject_/supersede_) verified by `test_lifecycle_ledger_id_family_disjoint` |

**c7 will land**: F13 LTM lifecycle CLI smoke (`reject_memory_candidate` + `supersede_memory_candidate` --help) raising fast gate from 15 → **16 components**, RELEASE_NOTES B5 close section + maintainer 3-run evidence, and the annotated tag `v4.91-M-B-B5`.


### B5 — close (landed 2026-05-21)

**c7 deliverables** — release commit + tag:

- `scripts/governance/run_release_closure_gate.py`: adds **F13 LTM lifecycle CLI smoke** (2 `--help` invocations: `reject_memory_candidate.py` + `supersede_memory_candidate.py`), raising fast gate from 15 → **16 components**. F13 is pure read; no state mutation; idempotent across repeated runs.
- RELEASE_NOTES.md: B5 close section (this section) + Release date line extended with the 2026-05-21 v4.91 B5 close phrase.
- `RELEASE_MANIFEST.json` final sync: 1 sha refresh on `run_release_closure_gate.py` + RELEASE_NOTES across c6/c7.
- Annotated tag `v4.91-M-B-B5`.

**Maintainer laptop evidence record** (2026-05-21):

| V | Time | Command | Result |
|---|---|---|---|
| V1 | 16:33:43 | full `pytest tests/` | **1199 passed / 2 skipped** in 164.97s (was 1156 at B4 close; +43 from B5 c5) |
| V2 | 16:38:46 | `run_release_closure_gate.py --profile fast` (R1) | **16/16 PASS** in 33.57s (F13: 2/2 LTM lifecycle CLI smoke OK; F1 collect: 1201; F4: 47 roots) |
| V3 | 16:39:27 | `run_release_closure_gate.py --profile fast` (R2) | **16/16 PASS** in 27.85s |
| V4 | 16:40:02 | `run_release_closure_gate.py --profile fast` (R3) | **16/16 PASS** in 14.83s |
| V5 | — | fast gate 3-run avg | **≈ 25.42s** (laptop slow run today; well under supervisor budget 600s) |
| V6 | 16:40:30 | `lint_layer_separation.py` | clean ✓ (**47 roots** / 0 violations + 1 runtime tree root / 0 leaks) |

### Delta vs B4 close (6553c88)

| Aspect | B4 close | B5 close |
|---|---|---|
| pytest | 1156 / 2 | **1199 / 2** (+43) |
| fast gate components | 15 | **16** (+F13 LTM lifecycle smoke) |
| LAYER_1_ROOTS | 47 | 47 (unchanged) |
| schemas/ltm/ count | 9 | **13** (+4 promotion/ledger schemas) |
| scripts/ltm/ count | 8 | **10** (+reject + supersede) |
| docs/22_ltm_v3/ count | 3 | **4** (+PROMOTION_LIFECYCLE) |
| Charter contract surface (must_preserve) | 6 rows | **7 rows** (+LTM lifecycle audit chain) |
| inv_002 trigger_files | (B4 c6 base) | **+12 entries** |
| required_manifest_files | 992 | **1003** (+11 net) |

### What B5 delivers

| Layer | Mechanism |
|---|---|
| 1 schema (compile-time) | 4 ledger/policy schemas with const/enum/`additionalProperties: false` guards (5 explicit anti-pattern reject sites) |
| 2 runtime (CLI) | promote extension + reject + supersede; forbidden_approvers refused case-insensitively; supersede audit chain runtime double-check |
| 3 state surface | `ltm/promotion_policy.yaml` Layer 1 default; `cross_project/{approved_patterns,rejected,superseded}/` populated by sibling CLIs |
| 4 docs | `docs/22_ltm_v3/PROMOTION_LIFECYCLE.md` (8 sections) + 14 charter anti-patterns SSoT pointer |
| 5 tests | 43 tests across schema validation + reject CLI + supersede CLI + multi-step roundtrip lifecycle |
| 6 fast gate | F13 LTM lifecycle CLI smoke (2/2) |
| 7 inv_002 | +12 trigger_files entries + 1 must_preserve "LTM lifecycle audit chain locked" |

### What B5 does NOT include (deferred)

- B5B Multi-Agent Preflight Consensus enforcement — the preflight schemas (B4 c1) carry the contract; M-C owns the runtime
- B6 Evolution Capture write-back into `ltm/_quarantine/` — deferred
- Cross-project candidate auto-application — Charter anti-pattern #10 forbidden (manual ledger always required)
- A v4.91-RC closure gate — deferred to v4.91 freeze

### Charter alignment (B5 close)

Anti-patterns enforced post-B5 (14, all green):

- **#6** evidence-threshold auto-promote — schema-bounded thresholds (1..16 / 2..16); preflight_metric refuses promote_to; promote/reject/supersede single-action CLIs
- **#7** escape hatches — schema additionalProperties:false + approval.mode=strict + CLI surface lacks override flags + case-insensitive forbidden_approvers
- **#11** preflight as gate-pass — ledgers describe outcome, not preflight state; preflight schemas carry their own contract
- **#12** preflight majority-vote — single string approver in all 3 ledgers; no votes[] surface
- Audit chain — supersede.replacing_entry_ledger_ref pattern lock + runtime double-check; ledger_id family disjoint

### Next

M-B continues with B5B (Multi-Agent Preflight Consensus enforcement, consuming the c1 forward-compat preflight schemas from B4) then B6 (Evolution Capture). M-A + Addendum-A + B4 unchanged across the milestone.

**Tag**: `v4.91-M-B-B5` (annotated)
**Branch**: `release/v4.90-fork`
**Commits**: 7 across c1+c2+c3+c4+c5+c6+c7

Layer 1. No project names. M-A + Addendum-A + B4 unchanged.


### B5B — Multi-Agent Preflight Consensus Enforcement (intro)

Following B5 close, B5B consumes the **forward-compat schemas** that
B4 c1 laid down (`preflight_case`, `preflight_metric`) and wires the
runtime + lock-time gate that turns them from declared contract into
enforced behavior. The 7-commit cadence mirrors B4/B5: c1 schema →
c2 runtime CLI → c3 lock_core_version gate → c4 docs → c5 tests →
c6 inv_002 sweep + intro → c7 fast-gate F14 + close + tag.

**EP decision matrix** (locked 2026-05-21 17:27, all four = A):

| Q | Decision |
|---|---|
| Q1 | **Hub-side stub creation** — `generate_upgrade_plan.py` auto-emits a deferred-state preflight_case stub when `preflight_required=true`; B5B CLI only finalizes |
| Q2 | **CLI flag injection** — `run_preflight_consensus.py finalize --decided-by ep --outcome <ENUM> [--rationale ...]`; 10-token `forbidden_deciders` enforced at runtime |
| Q3 | **`lock_core_version` entry-point gate** — single-point audit, no separate governance script, no `--skip-preflight` flag (Charter #7) |
| Q4 | **`preflight_metric` NOT widened** — stays 1.0.0 forward-compat; future widening goes via Addendum-style 1.x bump |

**Charter alignment** (B5B-specific enforcement):

| # | Anti-pattern | B5B enforcement |
|---|---|---|
| #6 | Evidence-threshold auto-promote | `preflight_policy.yaml` carries NO threshold/boost field; `preflight_metric` is read-only |
| #7 | Verifier escape hatches | No `--skip-preflight` / `--bypass-preflight` / `--force` / `--allow-extra` flag exists on either runtime CLI |
| #11 | Preflight as gate-pass | `preflight_policy.lock_gate.block_lock_when_outcome_not_approved` schema-const true; `lock_core_version` re-evaluates `outcome=='approved'` independently |
| #12 | Preflight majority-vote | `consensus.decided_by` single string at schema; `forbidden_deciders` includes 4 voting-specific tokens (majority/consensus/vote/tally) |

**Audit chain extension**: ledger_id family `preflight_consensus_*`
is **prefix-disjoint** from B5's `promote_*` / `reject_*` /
`supersede_*`; `event_type` const `consensus_finalized` is
const-disjoint from B5's `promoted` / `rejected` / `superseded`.
The four families never collide on `grep -h '^"ledger_id":'` audits.

**c7 will land** (close target): F14 preflight consensus CLI smoke
(`run_preflight_consensus.py --help` for both sub-commands) raising
fast gate from 16 → **17 components**, RELEASE_NOTES B5B close
section + maintainer 3-run evidence, and the annotated tag
`v4.91-M-B-B5B`.


### B5B — close (landed 2026-05-22)

**c7 deliverables** — release commit + tag:

- `scripts/governance/run_release_closure_gate.py`: adds **F14 preflight consensus CLI smoke** (3 `--help` invocations: `run_preflight_consensus.py` + sub-commands `init-stub` + `finalize`), raising fast gate from 16 → **17 components**. F14 is pure read; no state mutation; idempotent across repeated runs.
- RELEASE_NOTES.md: B5B close section (this section) + intro section qualifier `(in flight; intro)` -> `(intro)`.
- `RELEASE_MANIFEST.json` final sync: 1 sha refresh on `run_release_closure_gate.py` + RELEASE_NOTES across c6/c7.
- Annotated tag `v4.91-M-B-B5B`.

**Maintainer laptop evidence record** (2026-05-22):

| V | Time | Command | Result |
|---|---|---|---|
| V1 | 11:50:15 | full `pytest tests/` | **1244 passed / 2 skipped** in 61.20s (was 1199 at B5 close; +45 from B5B c5) |
| V2 | 11:51:31 | `run_release_closure_gate.py --profile fast` (R1) | **17/17 PASS** in 6.59s (F14: 3/3 preflight consensus CLI smoke OK; F1 collect: 1246; F4: 47 roots) |
| V3 | 11:51:37 | `run_release_closure_gate.py --profile fast` (R2) | **17/17 PASS** in 6.30s |
| V4 | 11:51:44 | `run_release_closure_gate.py --profile fast` (R3) | **17/17 PASS** in 6.29s |
| V5 | — | fast gate 3-run avg | **≈ 6.39s** (well under supervisor budget 600s; fastest cohort to date) |
| V6 | 11:51:50 | `lint_layer_separation.py` | clean ✓ (**47 roots** / 0 violations + 1 runtime tree root / 0 leaks) |

### Delta vs B5 close (e1e6d32)

| Aspect | B5 close | B5B close |
|---|---|---|
| pytest | 1199 / 2 | **1244 / 2** (+45) |
| fast gate components | 16 | **17** (+F14 preflight consensus smoke) |
| LAYER_1_ROOTS | 47 | 47 (unchanged) |
| schemas/ltm/ count | 13 | **15** (+preflight_policy + preflight_consensus_event_ledger) |
| scripts/ltm/ count | 10 | **11** (+run_preflight_consensus) |
| docs/22_ltm_v3/ count | 4 | **5** (+PREFLIGHT_CONSENSUS) |
| Charter contract surface (must_preserve) | 7 rows | **8 rows** (+Multi-Agent Preflight Consensus enforcement) |
| inv_002 trigger_files | 71 (post B5 c6) | **78** (+7 entries) |
| Charter anti-patterns | 14 | 14 (unchanged — no new anti-pattern; B5B enforces #6/#7/#11/#12 declared earlier) |
| required_manifest_files | 1003 | **1010** (+7 net: 3 NEW c1 + 1 NEW c2 + 1 NEW c4 + 2 NEW c5 + 0 net c3/c6/c7) |

### What B5B delivers

| Layer | Mechanism |
|---|---|
| 1 schema (compile-time) | 2 NEW schemas: preflight_policy (allowed_outcomes locked, lock_gate.block_lock_when_outcome_not_approved const true) + preflight_consensus_event_ledger (event_type='consensus_finalized' const, ledger_id family disjoint) |
| 2 runtime (CLI) | run_preflight_consensus.py (init-stub + finalize sub-commands; 10-token forbidden_deciders runtime refusal); generate_upgrade_plan.py best-effort stub emission (Hub side) |
| 3 lock-time gate | lock_core_version.py preflight gate at the entry point; EXIT_PREFLIGHT_NOT_APPROVED=5; no escape-hatch flags (Charter #7); refuses outcome != 'approved' AND defensively refuses decided_by='pending' |
| 4 state surface | `ltm/preflight_policy.yaml` Layer 1 default; `ltm/preflight/cases/<id>.json` (case + sibling .consensus.json ledger) + `ltm/preflight/metrics/<metric_id>.json` populated by finalize |
| 5 docs | `docs/22_ltm_v3/PREFLIGHT_CONSENSUS.md` (8 sections: state machine, gates, charter alignment, ledger conventions, CLI matrix, end-to-end recipe, audit recipe, where to look next) |
| 6 tests | 45 tests across schema validation + init-stub + finalize gate violations + finalize success path + audit chain + lock_core_version gate refusal/pass cases + Charter #7 escape-hatch verification |
| 7 fast gate | F14 preflight consensus CLI smoke (3/3 sub-command --help) |
| 8 inv_002 | +7 trigger_files entries + 1 must_preserve "Multi-Agent Preflight Consensus enforcement locked" |

### What B5B does NOT include (deferred)

- B6 Evolution Capture write-back into `ltm/_quarantine/` — deferred to next M-B batch
- Cross-project candidate auto-application — Charter anti-pattern #10 forbidden (manual ledger always required)
- A v4.91-RC closure gate — deferred to v4.91 freeze
- Multi-host-profile preflight UI — host_profile.yaml reads existing; UI surface is M-C territory

### Charter alignment (B5B close)

Anti-patterns enforced post-B5B (14 unchanged, all green):

- **#6** evidence-threshold auto-promote — preflight_policy carries NO threshold/boost; preflight_metric is read-only; runtime CLI never feeds metrics back into retrieval policy
- **#7** escape hatches — schema `additionalProperties:false` everywhere; CLI surfaces refuse `--skip-preflight` / `--bypass-preflight` / `--force` / `--allow-extra` flags (test_no_skip_preflight_flag_exists pinpoints this)
- **#11** preflight as gate-pass — `lock_gate.block_lock_when_outcome_not_approved` schema-const true; `lock_core_version` re-evaluates outcome=='approved' independently; finalize event ledger does NOT pass the lock by itself
- **#12** preflight majority-vote — `consensus.decided_by` single string at schema; `forbidden_deciders` includes 4 voting-specific tokens (majority/consensus/vote/tally); test_finalize_refuses_forbidden_decider parametrizes all 10
- Audit chain — preflight_consensus_* ledger_id family prefix-disjoint from B5's promote_*/reject_*/supersede_*; event_type 'consensus_finalized' const-disjoint from B5's promoted/rejected/superseded

### Next

M-B continues with B6 (Evolution Capture). M-A + Addendum-A + B4 + B5 unchanged across the milestone.

**Tag**: `v4.91-M-B-B5B` (annotated)
**Branch**: `release/v4.90-fork`
**Commits**: 7 across c1+c2+c3+c4+c5+c6+c7

Layer 1. No project names. M-A + Addendum-A + B4 + B5 unchanged.


### B6 — Evolution Capture (intro)

Following B5B close, B6 unifies four distinct capture pipelines that
feed `ltm/_quarantine/`, each tagged with a `capture_source` 5-enum
value so audit greps can attribute every candidate to its origin.
B6 does NOT introduce a new ledger family — capture flows through
the existing B5 promote pipeline (`promote_memory_candidate.py`)
which treats v4.90-style envelopes (no `capture_source`) and
B6-style envelopes identically.

**EP decision matrix** (locked 2026-05-22 15:06):

| Q | Decision |
|---|---|
| Q1 | **A 5-enum** `capture_source` vocabulary: `sprint_close_failure` / `extract_failure_candidates` / `working_note` / `quarantine_retraction` / `evolution_proposal` |
| Q2 | **A auto-emit** — `capture_sprint_close.py` writes a sibling candidate when `gate=blocked` (preserves `EXIT_GATE_BLOCKED` rc) |
| Q3 | **D dual-rail** — `capture_evolution_proposal.py` mutex group: `--proposal <path>` (works today) ⊕ `--proposal-id <evo_id>` (forward-compat for v4.92+ proposal_state runtime) |
| Q4 | **D F15 fast-gate** — 4 `--help` smoke + 1 `--dry-run` e2e against `tests/fixtures/ltm_evolution_capture/` (raises fast gate 17 → 18 components) |

**Charter alignment** (B6-specific enforcement):

| # | Anti-pattern | B6 enforcement |
|---|---|---|
| #4 | Replace, not extend | `capture_source` is OPTIONAL; `schema_version` stays **1.0.0 const** (no version bump per JSON Schema convention for optional-field additions); v4.90-era envelopes that omit `capture_source` remain schema-valid |
| #6 | Source-driven auto-promote | `promote_memory_candidate.py` (B5 c2) does NOT branch on `capture_source` for any gate decision — the field is descriptive only |
| #7 | Verifier escape hatches | No `--force` / `--skip-validation` / `--no-auto-emit` flag exists; `capture_evolution_proposal.py` argparse mutex enforces exactly one of `--proposal` / `--proposal-id`; `extract_failure_candidates.py --source` restricted to the 2 enum values it owns |
| #11 | Capture as gate-pass | Emitting a candidate does NOT mark anything approved; downstream B5 promote + B5B preflight gates apply independently. `capture_sprint_close.py` auto-emit preserves the original `EXIT_GATE_BLOCKED` rc unconditionally |

**Audit chain extension**: the `_quarantine/` directory remains a
single mixed pool; the `capture_source` enum distinguishes producer
sources without sub-directory split (which was explicitly rejected
to keep the `promote_memory_candidate.py` input contract uniform).

**c7 will land** (close target): F15 capture pipeline smoke
(4 `--help` invocations across capture_sprint_close /
extract_failure_candidates / quarantine_entry /
capture_evolution_proposal + 1 `--dry-run` e2e against
`tests/fixtures/ltm_evolution_capture/`) raising fast gate from
17 → **18 components**, RELEASE_NOTES B6 close section + maintainer
3-run evidence, and the annotated tag `v4.91-M-B-B6`.


### B6 — close (landed 2026-05-22)

**c7 deliverables** — release commit + tag:

- `scripts/governance/run_release_closure_gate.py`: adds **F15 capture pipeline smoke** (4 `--help` invocations: `capture_sprint_close.py` + `extract_failure_candidates.py` + `quarantine_entry.py` + `capture_evolution_proposal.py`, plus 1 `--dry-run` e2e exercising `extract_failure_candidates --source working_note` against `tests/fixtures/ltm_evolution_capture/working/`), raising fast gate from 17 → **18 components**.
- RELEASE_NOTES.md: B6 close section (this section) + intro section qualifier `(in flight; intro)` -> `(intro)`.
- `RELEASE_MANIFEST.json` final sync: 1 sha refresh on `run_release_closure_gate.py` + RELEASE_NOTES across c6/c7.
- Annotated tag `v4.91-M-B-B6`.

**Maintainer laptop evidence record** (2026-05-22):

| V | Time | Command | Result |
|---|---|---|---|
| V1a | (B6 c5 batch 1) | `pytest tests/ltm/` | **243 passed** in 213.75s (was 208 at B5B; +35 from B6 c5) |
| V1b | (B6 c5 batch 2) | `pytest tests/version+hub+contracts/` | **108 passed** in 40.71s |
| V1c | (B6 c5 batch 3) | `pytest tests/ (others)` | **928 passed / 2 skipped** in 225.18s |
| V1 | — | sum (full pytest equivalent) | **1279 passed / 2 skipped** (vs B5B 1244/2; +35) |
| V2 | 16:36:49 | `run_release_closure_gate.py --profile fast` (R1) | **18/18 PASS** in 9.81s (F15: 5/5 capture pipeline smoke OK; F1 collect: 1281; F4: 47 roots) |
| V3 | 16:36:59 | `run_release_closure_gate.py --profile fast` (R2) | **18/18 PASS** in 11.50s |
| V4 | 16:37:10 | `run_release_closure_gate.py --profile fast` (R3) | **18/18 PASS** in 11.38s |
| V5 | — | fast gate 3-run avg | **≈ 10.90s** (well under supervisor budget 600s; F15 dry-run e2e adds ~3-4s vs B5B baseline 6.39s) |
| V6 | 16:37:22 | `lint_layer_separation.py` | clean ✓ (**47 roots** / 0 violations + 1 runtime tree root / 0 leaks) |

### Delta vs B5B close (34e273e)

| Aspect | B5B close | B6 close |
|---|---|---|
| pytest | 1244 / 2 | **1279 / 2** (+35) |
| fast gate components | 17 | **18** (+F15 capture pipeline smoke) |
| LAYER_1_ROOTS | 47 | 47 (unchanged) |
| schemas/ltm/ count | 15 | 15 (capture_source is optional field add; no new schema file) |
| scripts/ltm/ count | 11 | **12** (+capture_evolution_proposal) |
| docs/22_ltm_v3/ count | 5 | **6** (+EVOLUTION_CAPTURE) |
| Charter contract surface (must_preserve) | 8 rows | **9 rows** (+capture pipeline lock) |
| inv_002 trigger_files | 78 | **86** (+8) |
| Charter anti-patterns | 14 | 14 (unchanged — no new anti-pattern; B6 enforces #4/#6/#7/#11) |
| required_manifest_files | 1010 | **1014** (+4 net: 1 NEW c2 capture_evolution_proposal + 1 NEW c4 EVOLUTION_CAPTURE.md + 1 NEW c5 test_capture_evolution_proposal + 1 NEW c5 fixture; pure-MOD c1/c3/c6/c7 net 0) |

### What B6 delivers

| Layer | Mechanism |
|---|---|
| 1 schema (compile-time) | memory_candidate.schema.json adds OPTIONAL `capture_source` 5-enum (sprint_close_failure / extract_failure_candidates / working_note / quarantine_retraction / evolution_proposal); schema_version stays 1.0.0 const |
| 2 runtime (CLI) | NEW capture_evolution_proposal.py (dual-rail mutex: --proposal markdown ⊕ --proposal-id state.json); MOD extract_failure_candidates.py (--source 2-enum: extract_failure_candidates / working_note); MOD capture_sprint_close.py (gate=blocked auto-emit candidate, idempotent via sprint_marker, EXIT_GATE_BLOCKED rc preserved) |
| 3 state surface | ltm/_quarantine/ stays a single mixed pool (sub-directory split rejected); capture_source distinguishes producers |
| 4 docs | docs/22_ltm_v3/EVOLUTION_CAPTURE.md (8 sections: capture pipelines diagram, 5-enum vocab table, charter alignment, per-pipeline detail, CLI matrix, end-to-end recipe, audit recipe, where to look next) |
| 5 tests | 33 tests (23 in test_capture_evolution_proposal NEW + 5 in test_capture_sprint_close MOD + 5 in test_extract_failure_candidates MOD); 1 fixture under tests/fixtures/ltm_evolution_capture/working/ for F15 dry-run smoke |
| 6 fast gate | F15 capture pipeline smoke (5/5: 4 --help + 1 --dry-run e2e) |
| 7 inv_002 | +8 trigger_files entries + 1 must_preserve "Capture pipeline locked" |

### What B6 does NOT include (deferred)

- `quarantine_entry.py` runtime emission for `capture_source=quarantine_retraction` — schema slot is reserved (B6 c2 5-enum), but the runtime emission is deferred. Future EP signal can extend `quarantine_entry.py` to ALSO emit a memory_candidate envelope when retraction needs review for re-promotion.
- Cross-project candidate auto-application — Charter anti-pattern #10 forbidden (manual ledger always required).
- A v4.91-RC closure gate — deferred to v4.91 freeze.
- self_evolution proposal_state.json runtime emission — Rail B of capture_evolution_proposal is forward-compat for v4.92+ when self_evolution agents populate state.json.

### Charter alignment (B6 close)

Anti-patterns enforced post-B6 (14 unchanged, all green):

- **#4** Replace, not extend — capture_source is OPTIONAL, schema_version stays 1.0.0 const; v4.90 envelopes remain valid (test_b6_v4_90_envelope_no_capture_source_still_schema_valid pinpoints this regression)
- **#6** Source-driven auto-promote — promote_memory_candidate.py (B5 c2) does NOT branch on capture_source; field is purely descriptive label
- **#7** Verifier escape hatches — no --force / --skip-validation / --no-auto-emit flag exists; argparse mutex enforces exactly one rail in capture_evolution_proposal; --source choices restricted to 2 of 5 in extract (test_no_escape_hatch_flags_exist parametrizes all common escape attempts)
- **#11** Capture as gate-pass — emitting candidate does NOT pass any gate; capture_sprint_close auto-emit preserves EXIT_GATE_BLOCKED rc unconditionally; downstream B5 promote / B5B preflight still apply independently

### Next

M-B continues with eventual closure tag `v4.91-M-B` covering B4 + B5 + B5B + B6 unified milestone. M-A + Addendum-A unchanged across the milestone.

**Tag**: `v4.91-M-B-B6` (annotated)
**Branch**: `release/v4.90-fork`
**Commits**: 7 across c1+c2+c3+c4+c5+c6+c7

Layer 1. No project names. M-A + Addendum-A + B4 + B5 + B5B unchanged.

---

## v4.91 Milestone B — Closed (2026-05-22)

**Tag**: `v4.91-M-B` (annotated; integral milestone tag)
**HEAD**: pinned by tag annotation (M-B integral close commit)
**Sub-tags rolled up**: `v4.91-M-B-B4` + `v4.91-M-B-B5` + `v4.91-M-B-B5B` + `v4.91-M-B-B6`
**Test baseline**: 1279 passed / 2 skipped (post-B6 close, maintainer laptop)
**Fast gate**: 18/18 PASS, 3-run avg ≈ 10.90s (V2-V4 timestamps in B6 close maintainer evidence)
**Layer 1 lint**: 47 roots scanned / 0 violations + 1 runtime tree root / 0 leaks
**Total atomic commits**: 28 across B4 (7) + B5 (7) + B5B (7) + B6 (7)

**What M-B delivers** — Controlled Learning surface across the cross-project axis:

| Batch | Capability | Schema(s) | CLIs | Tests | Fast gate component |
|---|---|---|---|---|---|
| B4 | Shared LTM v3 Read-Side Pipeline | 4 v3 schemas (retrieval_policy + routing_report + preflight_case + preflight_metric, all 1.0.0) | 2 read-only (retrieve_with_routing + generate_routing_report) | +35 | F12 ltm-v3-smoke |
| B5 | LTM Write/Promotion Gates | 4 schemas (promotion_policy + promotion_ledger + reject_ledger + supersede_ledger, all 1.0.0) | 2 NEW + 1 extension (promote_memory_candidate v3 + reject_memory_candidate + supersede_memory_candidate) | +43 | F13 ltm-lifecycle-smoke |
| B5B | Multi-Agent Preflight Consensus Enforcement | 2 schemas (preflight_policy + preflight_consensus_event_ledger, all 1.0.0) | 1 NEW + 2 MOD (run_preflight_consensus + lock_core_version gate + generate_upgrade_plan stub emit) | +45 | F14 preflight-consensus-smoke |
| B6 | Evolution Capture | 1 schema MOD (memory_candidate +OPTIONAL capture_source 5-enum; schema_version stays 1.0.0 const) | 1 NEW + 2 MOD (capture_evolution_proposal + capture_sprint_close auto-emit + extract_failure_candidates --source) | +33 | F15 capture-pipeline-smoke |
| **M-B total** | **4 sub-batches** | **10 NEW + 1 MOD optional-field-add** | **6 NEW + 5 MOD CLIs** | **+156 tests** | **4 new fast gate items (F12-F15)** |

**Charter contract surface** — inv_002 `must_preserve` rows added by M-B (4 of 9 total):

6. Shared LTM v3 hard-isolation contract (B4 c6)
7. LTM lifecycle audit chain locked (B5 c6)
8. Multi-Agent Preflight Consensus enforcement locked (B5B c6)
9. Capture pipeline locked (B6 c6 — capture_source 5-enum schema-locked optional field; schema_version stays 1.0.0 const; dual-rail mutex; auto-emit preserves EXIT_GATE_BLOCKED — Charter #4/#6/#7/#11)

(Total inv_002 must_preserve grew 5 → 9 rows across M-B; trigger_files 47 → 86; required_manifest_files grew from M-A end's 973 → 1014 across M-B + Addendum-A.)

**What M-B does NOT include** (deferred to v4.91 freeze / v4.92):

- v4.91-RC closure gate hardcoded count refresh (953 → 1279) — Direction D; deferred until v4.91 freeze prep
- `rebuild_release_manifest.py` extension to recognize F-T-01 / F-V-01 / B0-B6 fields — Direction E; v4.92 tooling debt
- B5C Optional IDE Auto Escalation Adapter — out of M-B scope; v4.91+ plan §3 contract still places it under M-C
- Cross-project candidate auto-apply pipeline — Charter anti-pattern #10; permanently refused (not deferred)

**Charter alignment** (14 anti-patterns enforced, all green):

M-B touches anti-patterns #4 (extend-don't-replace, B6 c1) / #6 (no source-driven auto-promote, B6 + B5) / #7 (no escape hatches, B4 + B5 + B5B + B6) / #10 (no cross-project auto-apply, B5) / #11 (preflight not gate-pass, B5B + B6) / #12 (preflight no majority-vote, B4 + B5B). Anti-pattern #14 (no full release copy by default) was already locked in Addendum-A; M-B inherits without modification.

**Maintainer laptop evidence record (2026-05-22, B6 close — reused for M-B integral close)**:

| V | Time | Result |
|---|---|---|
| V1 | (B6 c5) | pytest tests/ split 3-way → **1279 passed / 2 skipped** total |
| V2 | 16:36:49 | fast gate R1 — **18/18 PASS** in 9.81s |
| V3 | 16:36:59 | fast gate R2 — **18/18 PASS** in 11.50s |
| V4 | 16:37:10 | fast gate R3 — **18/18 PASS** in 11.38s |
| V5 | — | 3-run avg = **10.90s** (benchmark target ≤ 12s on maintainer laptop) |
| V6 | 16:37:22 | lint — **47/0** + 1 runtime / 0 leaks |

(M-B integral close commit reuses B6 close evidence; the source tree between B6 c7 and the M-B integral close commit changes only RELEASE_NOTES.md text + RELEASE_MANIFEST.json sha refresh — neither is test-touching, so the evidence band remains valid.)

**Tag annotation**: see `git tag -l --format='%(contents)' v4.91-M-B` for the canonical capability summary, sub-tag roll-up, EP decisions baked-in, and deferred items list.

**Next**: M-C planning, OR direct v4.91 freeze prep (Direction D — v4.91-RC closure gate). The Hub state surface (M-A) + tenancy/mount contracts (F-T-01 + F-V-01 + Addendum-A) + Controlled Learning surface (M-B) together form the v4.91 release candidate's substantive deliverables. Whether M-C is required for v4.91 or shifts to v4.92 is an open EP decision.

Layer 1. No project names. M-A + Addendum-A unchanged. Charter contract count: 14 (unchanged). inv_002 must_preserve: 9 (unchanged). Fast gate components: 18 (unchanged).


---

## v4.91 Addendum-C — Subagent Routing Gate (P1.5, CLOSED 2026-05-25)

> **Status**: CLOSED 2026-05-25 — c1 `bb5299e` (skill+schema+validator+ledger+F17), c2 `c1a7b01` (inv_008 + ap_2026_001), c3 `3aeabed` (test suite), c4 `61b0d4e` (docs/23_ + RELEASE_NOTES intro), c5 (this commit, manifest + matrix + memory log + closure summary). Annotated tag `v4.91-Addendum-C` to follow at the c5 release commit.
>
> **Trigger**: External governance proposal nominated `subagent-routing-gate` — a parent-thread preflight that converts implicit "I'll just do this myself" decisions into explicit, auditable routing. EP plan-approve (2026-05-25 11:44) accepted the proposal as a Layer 1 OS Core skill with a generic runtime mirror, slotted as **P1.5** (between P1 Addendum-B and P2 E rebuild_release_manifest) so the rest of the v4.91 freeze roadmap stays sequenced.
>
> **Theme**: A delegation decision is a **first-class audit event**, not a side-effect. The parent agent's choice between `SPAWN_SUBAGENT` / `LOCAL` / `ESCALATE` produces (a) a narrative record on the parent's own log surface and (b) a canonical line in `runtime/registries/delegation_decision_ledger.jsonl`. Charter anti-pattern #11 stays bright: a recorded decision is **not** a closure-gate pass.

### EP decision matrix (locked 2026-05-25 11:44)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **Layer 1 OS Core skill** (in `skills/_generic_core/orchestrator/`) | Routing discipline is universal; project bindings (narrative paths, owner catalog) live in Layer 2 only |
| Q2 | **Strong runtime mirror** (single canonical JSONL ledger, charter-exception minimal generic surface) | Aggregate audit needs a stable path; project narrative trees alone cannot be greppped uniformly across host projects |
| Q3 | **LOCAL `reason_code` is a closed 5-enum** (`LOCAL_TINY` / `LOCAL_BLOCKED` / `LOCAL_OWNER_SELF` / `LOCAL_TOOLING` / `LOCAL_PREP`) with optional `reason_note` ≤ 200 chars | Closed enum prevents free-text escape (Charter anti-pattern #7); `reason_note` carries context without becoming a code substitute |
| Q4 | **Independent batch (Addendum-C / P1.5)**, not folded into P1 (already closed) | Addendum-B was already tag-closed when the proposal arrived; opening a fresh letter keeps commit history reviewable |

### Commits (5; all landed)

```
bb5299e  feat(v4.91 Addendum-C c1): subagent-routing-gate source layer (1 skill + schema + validator + ledger + F17)
c1a7b01  feat(v4.91 Addendum-C c2): inv_008 wired + ap_2026_001 required skill (5 MOD)
3aeabed  test(v4.91 Addendum-C c3): delegation gate test suite (1 NEW + 1 fix, 11 tests)
61b0d4e  docs(v4.91 Addendum-C c4): docs/23_subagent_routing_gate/ + RELEASE_NOTES intro (3 NEW + 2 MOD)
<c5>     chore(v4.91 Addendum-C c5): manifest sync (+9 files) + inv_002 trigger expand + closure summary
```

### Surface added (c1)

| Path | Layer | Role |
|---|---|---|
| `skills/_generic_core/orchestrator/subagent-routing-gate/SKILL.md` | L1 source | Skill spec — preflight workflow, decision rules, output template |
| `skills/_generic_core/orchestrator/subagent-routing-gate/REFERENCES.md` | L1 source | Companion artifact map + Charter alignment |
| `schemas/governance/delegation_decision.schema.json` | L1 schema | Envelope contract (1.0.0 const) |
| `runtime/registries/delegation_decision_ledger.jsonl` | L1 runtime mirror | Append-only audit ledger (canonical empty at adoption time) |
| `scripts/governance/validate_delegation_decisions.py` | L1 governance | Validator: envelope shape + LOCAL enum + amends order + cross-line uniqueness |
| `scripts/governance/run_release_closure_gate.py` (MOD) | L1 governance | F17 fast-gate item (2 sub-checks: canonical empty PASS + LOCAL-without-reason_code FAIL) |

### Wiring added (c2)

- `runtime/protected_contracts/protected_regression_matrix.yaml`: invariants 7 → **8** (+`inv_008_delegation_gate_recorded`, ACTIVE/EP).
- `agent_packs/ap_2026_001_executive_cluster.md`: `skills.required` += `subagent-routing-gate`; references += SKILL.md + matrix yaml; tier note extended for Addendum-C.
- `tests/contracts/test_protected_invariant_schema.py`: invariant count assertion 7 → 8.
- F6 spanning dispatch + summary: `7/7` → `8/8`.

### Test additions (c3)

- `tests/governance/test_delegation_gate.py` (NEW, 11 tests): empty ledger / SPAWN_SUBAGENT recorded / LOCAL+LOCAL_TINY / ESCALATE empty required_evidence / LOCAL missing reason_code / unknown reason_code / event_id pattern / cross-line uniqueness / amends unresolved / amends required-iff-amended branches / CLI exit-code smoke.
- `tests/contracts/test_required_regressions_router.py`: c2 oversight folded in — `len(matrix["invariants"]) == 7` → `== 8`.

### Docs added (c4)

| Path | Role |
|---|---|
| `docs/23_subagent_routing_gate/README.md` | Adoption surface — Charter alignment table + Layer 2 binding contract + F17 + test coverage |
| `docs/23_subagent_routing_gate/DECISION_RULES.md` | When to pick SPAWN_SUBAGENT / LOCAL / ESCALATE — preconditions, 5-enum rationale, 3 worked shapes, edge cases, anti-decisions |
| `docs/23_subagent_routing_gate/AUDIT_LEDGER_CONTRACT.md` | Envelope 9-field + details 7+4-field contract, lifecycle (recorded / amended / withdrawn), validator exit codes, 17 violation rule names, schema-evolution policy |
| `skills/_generic_core/orchestrator/subagent-routing-gate/REFERENCES.md` (MOD) | Stale `docs/19_…` pointer corrected to `docs/23_…` (`19_tenancy/` already occupies the 19 slot) |

### Charter alignment (5 anti-patterns checked)

| Anti-pattern | Status |
|---|---|
| #2 / inv_002 — no project literals in Layer 1 | ✅ skill + schema + validator + ledger + 3 docs + 11 tests use only generic placeholders (`agent_alpha` / `agent_beta` / `scratch.md` / opaque `dd_…` event_ids) |
| #5 — Core does not bind to project narrative | ✅ skill names canonical narrative *types* only (orchestrator log / per-agent log / handoff / open-issues), never a project-specific filename |
| #7 — no free-text escape tokens | ✅ LOCAL `reason_code` is a closed 5-enum; `reason_note` capped at 200 chars |
| #11 — recorded decision ≠ closure-gate pass | ✅ validator enforces decision-record shape only; F17 tests the validator, not task completion |
| #15 — no soft alias | ✅ schema rejects unknown reason codes outright; recorded entries cannot carry `amends`, amended/withdrawn entries must |

### Maintainer evidence record (laptop, 2026-05-25)

| Run | Result |
|---|---|
| `pytest tests/governance/test_delegation_gate.py -q` | 11/11 PASS (0.16 s) |
| `pytest tests/governance tests/contracts -q` | **158/158 PASS** (25.80 s post-c5) |
| `python3 scripts/governance/lint_layer_separation.py` | clean — 47 roots / 0 violations + runtime tree clean |
| `python3 scripts/governance/validate_delegation_decisions.py` (canonical empty ledger) | rc=0 — "PASS — no violations" |
| `python3 scripts/governance/verify_release_clean_tree.py` | clean — actual − manifest − exclusions = 0 (post-c5 manifest sync) |
| `python3 scripts/governance/run_release_closure_gate.py --profile fast --format json` | overall=0 — **fast 20/20 PASS**; F17 "Delegation decisions smoke" PASS — "2/2 delegation-decisions smoke checks OK"; F2 clean-tree PASS post-c5 |

### Manifest sync (c5)

- `RELEASE_MANIFEST.json` `required_manifest_files`: 1015 → **1024** (+9 net all-NEW Addendum-C surface, no MOD-only sha refresh entries):
  - `docs/23_subagent_routing_gate/AUDIT_LEDGER_CONTRACT.md` / `DECISION_RULES.md` / `README.md` (3 c4 docs)
  - `runtime/registries/delegation_decision_ledger.jsonl` (canonical empty ledger; sha256 = e3b0c44…b855 = empty-string sha)
  - `schemas/governance/delegation_decision.schema.json`
  - `scripts/governance/validate_delegation_decisions.py`
  - `skills/_generic_core/orchestrator/subagent-routing-gate/SKILL.md` / `REFERENCES.md`
  - `tests/governance/test_delegation_gate.py`
- `required_manifest_count` = 1024.
- `CHECKSUMS.txt`: **unchanged** — that file pins only Core abstract identity files (VERSION + MANIFEST.json + 4 version schemas), none of which Addendum-C touched. No refresh needed.
- `runtime/protected_contracts/protected_regression_matrix.yaml` inv_002:
  - `trigger_files` += `docs/23_subagent_routing_gate/**` (Layer 1 lint scope expanded; 47 roots count unchanged because the new dir matched an existing `docs/**` glob root in the linter, not a fresh root).
  - `must_preserve` row added: *"Subagent routing gate locked (post v4.91 Addendum-C c5 — …)"* — captures the schema/script/ledger/F17 contract surface in one line for future regression policing.

### What Addendum-C does NOT include

- **No new runtime profile**, **no schema bump elsewhere**, **no
  release zip** — Addendum-C is purely additive on the source / test
  / docs surface; the v4.91 release-zip embargo (locked 2026-05-25
  per MEMORY §16) is unaffected.
- **No project-specific narrative paths** — those remain Layer 2
  bindings owned by host projects.
- **No automatic enforcement of "every delegation must record a
  ledger line"** — F17 verifies validator integrity, not parent-
  agent discipline. Discipline enforcement belongs to inv_008's
  human-review surface, not a fast-gate auto-fail.

### Next phase

P1.5 Addendum-C closes here. Annotated tag `v4.91-Addendum-C` is
applied at the c5 release commit, taking the v4.91 tag ladder from 8
→ **9** tags. The freeze roadmap continues with **P2 E
rebuild_release_manifest** (rebuilder tooling improvements + sha
audit pass) per the v4.91 freeze plan.


---

## v4.91 P2 — Rebuilder Tooling Refactor (CLOSED 2026-05-25)

> **Status**: CLOSED 2026-05-25 — c1 `44d8a8a` (rebuilder rewrite +
> --check + .gitkeep classification fix), c2 `74332e8` (9-test
> preservation suite), c3 `1d43dea` (manifest_schema_notes 13 → 29 +
> MANIFEST_HISTORY sync), c4 (this commit, RELEASE_NOTES + memory log).
> **No annotated tag**: P2 is tooling refactor, not a contract-surface
> batch; v4.91 tag ladder stays at 9 (M-A / Addendum-A / M-B-B4 / B5 /
> B5B / B6 / M-B / Addendum-B / Addendum-C).
>
> **Trigger**: Since v4.91 B0 every batch close has used surgical
> hand-edits to `RELEASE_MANIFEST.json::required_manifest_files`
> instead of running `scripts/rebuild_release_manifest.py`, because
> the rebuilder hardcoded metadata fields (manifest_schema_version /
> manifest_schema_notes / byte_lock / exclusions /
> classification_rules) in source and was last updated at v4.90.8.
> Re-running it would have silently STRIPPED `manifest_schema_version`
> 2.3 → 2.2, schema_notes 13 → 12, transient_patterns 10 → 5,
> classification_rules.tenant_runtime, and tenant_runtime_entries[]
> entirely. RELEASE_NOTES Addendum-A c5 (2026-05-21) flagged this as
> "Action item for v4.92"; EP brought it into v4.91 scope as P2.
>
> **Theme**: The rebuilder is a **sha refresher**, not a metadata
> author. Metadata travels through; file inventories are recomputed.

### Surface added (c1 + c2)

| Path | Role |
|---|---|
| `scripts/rebuild_release_manifest.py` (rewrite) | Preservation rebuilder: reads metadata from on-disk manifest and copies through; only recomputes `required_manifest_files` / `optional_seed_files` / `test_fixtures` + counts. New flags: `--check` (drift detection, exit 0/1), `--out PATH` (redirect output for tests), `--root PATH` (walk an alternate tree for tests). JSON now `ensure_ascii=False` for lossless UTF-8. |
| `tests/test_rebuild_release_manifest.py` (NEW, 9 tests) | Pin preservation contract: top-level fields, `classification_rules.tenant_runtime` key, `exclusions.transient_patterns` extended list, count-vs-list-length, `--check` clean / drift, transient refusal, idempotency, live-repo `--check` sanity guard. |

### Wiring (c3)

- `RELEASE_MANIFEST.json::manifest_schema_notes`: **13 → 29** entries (+16). Catches up the v4.90.9 / 10 / 11 trio (Batch 14.16 / 17 / 18) plus the v4.91 ladder (F-V-01, B0, B1, B2, B3, Addendum-A, B4, B5, B5B, B6, Addendum-B, Addendum-C, P2). The F-T-01 entry stays in chronological position.
- `docs/MANIFEST_HISTORY.md`:
  - §2 (schema-promote waves): 9 new sub-sections under v4.91 covering F-T-01 / F-V-01 / B0–B3 grouped table / Addendum-A / B4–B6 grouped table / Addendum-B / Addendum-C / P2.
  - §3 (LAYER_1_ROOTS): table extended 33 → 47 with rows for B1 / B2 / B3 / F-T-01 / Addendum-A; explicit row for Addendum-C noting the new doc dir matched the existing `docs/**` glob root.
  - §4 (Cross-references): "Generator" entry rewritten — rebuilder no longer carries the `manifest_schema_notes` payload in source.
  - §5 (How to append): step 1 rewritten — append directly to `RELEASE_MANIFEST.json`; step 5 adds the new preservation test to the gate command.

### Maintainer evidence record (laptop, 2026-05-25 post-c3)

| Run | Result |
|---|---|
| `python3 scripts/rebuild_release_manifest.py` | Rebuilt; metadata preserved: `manifest_schema_version=2.3`, `schema_notes=29`, `tenant_runtime_entries=1`, `preserved_keys=12`. required=1018 / optional_seed=31 / test_fixtures=120 / generated=0 / transient=0. |
| `python3 scripts/rebuild_release_manifest.py --check` | exit 0 — clean ✓ no drift |
| `pytest tests/test_rebuild_release_manifest.py -q` | 9/9 PASS (0.42 s) |
| `pytest tests/test_release_manifest_consistency.py tests/test_manifest_schema_notes_consistency.py tests/test_rebuild_release_manifest.py -q` | 13/13 PASS (0.42 s) |
| `pytest tests/governance tests/contracts -q` | 158/158 PASS (post-c3 baseline; unchanged from Addendum-C c5) |
| `python3 scripts/governance/lint_layer_separation.py` | clean — 47 roots / 0 violations + runtime tree clean |
| `python3 scripts/governance/verify_release_clean_tree.py` | clean ✓ (actual − manifest − exclusions = 0) |
| `python3 scripts/governance/run_release_closure_gate.py --profile fast --format json` | overall=0 — fast 20/20 PASS (unchanged from Addendum-C c5) |

### Side-effect: legacy classification fix

Re-running the new rebuilder revealed 7 `.gitkeep` files
mis-classified into `required_manifest_files` by past surgical
edits. The rebuilder's `OPTIONAL_SEED_SUFFIXES` rule has always
intended these for `optional_seed_files`; the surgical-edit
workflow had quietly accepted them under `required` since B4. The
new rebuilder fixes the classification:

```
ltm/cross_project/{approved_patterns,candidates,rejected,
                   superseded}/.gitkeep   (+4 → optional_seed)
ltm/preflight/{cases,metrics,
               pattern_candidates}/.gitkeep   (+3 → optional_seed)
```

Net counts: `required_manifest_files` 1024 → 1018 (-7 reclassified
+1 new test file from c2); `optional_seed_files` 24 → 31 (+7);
`test_fixtures` unchanged at 120; total tracked count unchanged.

### Charter alignment

| Anti-pattern | Status |
|---|---|
| #2 / inv_002 — Layer 1, no project literals | ✅ rebuilder + test fixture use only generic placeholders (fixture / fixture_*); schema_notes / history sections describe Core narrative, no project ids |
| #4 — extend, don't replace | ✅ `--check` / `--out` / `--root` are NEW flags; legacy default `python3 scripts/rebuild_release_manifest.py` still rebuilds and writes |
| #7 — no free-text escape | ✅ rebuilder cannot synthesise schema_notes entries; appending one is a deliberate hand-edit |
| #11 — manifest is not closure-gate evidence | ✅ `--check` returns drift, not "release ready"; closure gate keeps its own gate logic |
| #14 — no full release copy by default | ✅ rebuilder walks the working tree only; no release-directory creation |

### What P2 does NOT include

- **No tag**: tag ladder reserved for contract-surface batches
  (M-A / M-B sub-batches / Addendums). v4.91 tag ladder stays at 9.
- **No release zip / release-directory work**: per MEMORY §16
  v4.91-release-delay rule (locked 2026-05-25), only P10 ceremony
  cuts the release.
- **No closure-gate adoption** of the new `--check` flag. F18 (a
  potential `manifest-rebuild-smoke` fast-gate item) is a P9
  candidate, not P2 work. The `test_live_repo_check_is_clean` test
  in c2 is the manual sanity guard until then.
- **No CHECKSUMS.txt change**: that file pins Core abstract
  identity (VERSION + MANIFEST.json + 4 version schemas); P2
  doesn't touch any of those files.

### Next phase

P2 closes here. The freeze roadmap continues with **P3 — M-C B5C
Optional IDE Adapter** (host_profile harmonization + advisory
multi-agent-preflight-review skill + tests/profiles). Per the v4.91
release-delay rule, P3 closes with commit chain + annotated tag
only; release zip is reserved for P10.


---

## v4.91 Milestone C — Optional Automation (B5C, CLOSED 2026-05-25)

> **Status**: CLOSED 2026-05-25 — c1 `0b8ff46` (host_profile sweep), c2 `08b6487` (skill skeleton), c3 `10250c1` (8-test contract suite), c4 (this commit, RELEASE_NOTES + manifest sync). Annotated tag `v4.91-M-C` applied at the c4 release commit.
>
> **Trigger**: M-C is the v4.91 milestone for optional automation surfaces — work that EXTENDS the orchestrator's decision toolkit without introducing new enforcement gates. Addendum-A had already shipped 4 host_profile.yaml files (codex / cursor / claude_code / workbuddy); the gap was the explicit skill anchor that the host_profile `limitation_note` fields could point at, plus the test layer that pins the no-auto-multi-agent discipline (Charter anti-pattern #13).
>
> **Theme**: Multi-agent peer review is **opt-in advisory**, never auto-default. The new skill emits a narrative block on the parent's log surface and decides ENGAGE / SKIP; it does not write to a runtime ledger and does not substitute for the structural preflight gate at B5B (`scripts/ltm/run_preflight_consensus.py`). The host_profile sweep makes the opt-in path visible at the capability-declaration layer.

### EP decision matrix (locked 2026-05-25 16:18)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **c1 = host_profile harmonization sweep** (4 yaml `limitation_note` extension) | Original cosmic-forging plan's c1 (write 4 host_profile.yaml) was already done in Addendum-A; preserve 4-commit cadence by anchoring the c2 skill into existing yaml |
| Q2 | **Skill cluster path** = `skills/_generic_core/orchestrator/multi-agent-preflight-review/` | Sibling to subagent-routing-gate (Addendum-C); both are decision skills under orchestrator/ |
| Q3 | **No schema, no ledger** for the new skill | The skill is advisory (Charter anti-pattern #11); structural enforcement of preflight events lives at B5B's `preflight_consensus_event_ledger.jsonl` |
| Q4 | **No new fast-gate item** (no F18) | Adding a fast gate would imply enforcement; tests in `tests/profiles/` cover the contract instead |
| Q5 | **Annotated tag v4.91-M-C** | Milestone-driven tag policy (M-A / M-B / Addendum-A / B / C precedent); B5C is the only batch in M-C, so batch close = milestone close = tag |
| Q6 | **8 unique test functions** (20 collected after parametrize) | Original plan number; covers host_profile capability matrix + 7 forbidden_default_actions + skill skeleton + advisory posture drift catcher |

### Commits (4; all landed)

```
0b8ff46  docs(v4.91 M-C B5C c1): host_profile harmonization sweep — multi-agent-preflight-review opt-in anchor (4 MOD)
08b6487  feat(v4.91 M-C B5C c2): multi-agent-preflight-review skill skeleton (2 NEW)
10250c1  test(v4.91 M-C B5C c3): tests/profiles/ — 8 host_profile + skill contract tests (3 NEW)
<c4>     chore(v4.91 M-C B5C c4): RELEASE_NOTES M-C closure + manifest sync + tag v4.91-M-C
```

### Surface added

| Path | Layer | Role |
|---|---|---|
| `profiles/{codex,cursor,claude_code,workbuddy}/host_profile.yaml` (4 MOD) | L1 source | `limitation_note` clause names the canonical opt-in skill path |
| `skills/_generic_core/orchestrator/multi-agent-preflight-review/SKILL.md` (NEW) | L1 source | Workflow / Decision Rules / Output Format / "What this skill is NOT" sections |
| `skills/_generic_core/orchestrator/multi-agent-preflight-review/REFERENCES.md` (NEW) | L1 source | Companion artifact map + sibling-skill (subagent-routing-gate) comparison table |
| `tests/profiles/__init__.py` (NEW) | L1 test | Package marker |
| `tests/profiles/test_host_profile_no_auto_promise.py` (NEW, 5 functions × parametrize 4 hosts) | L1 test | host_profile capability + forbidden_default_actions + compile-time auto-prefix guard |
| `tests/profiles/test_execution_mode_required.py` (NEW, 3 functions) | L1 test | skill skeleton presence + REFERENCES cross-link + advisory-not-gate drift catcher |

### Charter alignment (4 anti-patterns checked)

| Anti-pattern | Status |
|---|---|
| #2 / inv_002 — no project literals in Layer 1 | ✅ profiles + skill text + tests use generic host names + role placeholders only |
| #11 — narrative ≠ closure-gate pass | ✅ skill is advisory; no schema / no ledger / no fast-gate item; B5B's `run_preflight_consensus.py` keeps the structural enforcement role |
| #13 — no host auto multi-agent default | ✅ all 4 host_profile.yaml `limitation_note` fields name the opt-in skill path; test_no_host_advertises_auto_multi_agent enforces compile-time |
| #14 — no full release copy by default | ✅ test_all_4_hosts_carry_forbidden_default_actions pins all 7 entries on every host |

### Maintainer evidence record (laptop, 2026-05-25)

| Run | Result |
|---|---|
| `pytest tests/profiles/ -q` | 20/20 PASS (0.04 s; 8 unique functions × parametrize) |
| `pytest tests/governance tests/contracts tests/test_rebuild_release_manifest.py tests/test_release_manifest_consistency.py tests/test_manifest_schema_notes_consistency.py tests/profiles -q` | 191/191 PASS (post-c3 + c4 manifest sync) |
| `python3 scripts/governance/lint_layer_separation.py` | clean — 47 roots / 0 violations + runtime tree clean |
| `python3 scripts/rebuild_release_manifest.py` | rebuilt; metadata preserved: schema_version=2.3, schema_notes=30, tenant_runtime_entries=1, preserved_keys=12. required=1023 / optional_seed=31 / test_fixtures=120 |
| `python3 scripts/rebuild_release_manifest.py --check` | exit 0 — clean ✓ no drift |
| `python3 scripts/governance/verify_release_clean_tree.py` | clean ✓ |
| `python3 scripts/governance/run_release_closure_gate.py --profile fast --format json` | overall=0; fast 20/20 PASS (unchanged from P2; no F18 added per Q4) |

### Manifest sync (c4)

- `manifest_schema_notes`: **29 → 30** (+1: M-C entry).
- `required_manifest_files`: **1018 → 1023** (+5: 2 skill files + 3 test files; 4 host_profile.yaml updates surface as sha refresh, not new entries).
- `optional_seed_files` / `test_fixtures` unchanged at 31 / 120.
- `tenant_runtime_entries` / `byte_lock` / `exclusions` / `classification_rules.tenant_runtime` / `manifest_schema_version` 2.3 all preserved verbatim by the P2 rebuilder.
- `CHECKSUMS.txt` not touched (P2-locked: only Core abstract identity files, none of which M-C affects).

### What M-C does NOT include

- **No new schema**: the multi-agent-preflight-review skill is narrative; structured ledger work lives at B5B (already shipped). Adding a schema here would imply enforcement, which Charter #11 forbids for advisory surfaces.
- **No new fast-gate item (F18)**: same reasoning. Tests in `tests/profiles/` cover the contract; the closure gate stays at 20 components.
- **No automatic multi-agent dispatcher**: engagement is opt-in by design. The skill's Workflow Step 5 makes the orchestrator wait for explicit user trigger.
- **No CHECKSUMS.txt change**: M-C does not touch VERSION / MANIFEST.json / 4 version schemas.
- **No release zip / release-directory work**: per MEMORY §16 (v4.91 release delay rule), only P10 ceremony cuts the release.

### Next phase

P3 / M-C closes here. The freeze roadmap continues with **P4 — M-D B7 Rollback / Checkpoint v0** (Milestone D Governance Foundations; B6 Intent Governance Layer v0 already shipped within M-B as B6 Evolution Capture). v4.91 tag ladder advances 9 → **10**.


---

## v4.91 Milestone D — Governance Foundations (B7, CLOSED 2026-05-25)

> **Status**: CLOSED 2026-05-25 — c1 `2e89255` (3 schemas), c2 `eab362e` (write/read CLIs), c3 `5fbd855` (plan/verify CLIs), c4 `781dc13` (17 tests + inv_009 wiring), c5 (this commit, F18 + RELEASE_NOTES + manifest sync). Annotated tag `v4.91-M-D` applied at the c5 release commit.
>
> **Trigger**: M-D delivers the rollback / checkpoint v0 toolchain (B7) — the v4.91 freeze plan's foundation for "I changed something risky; can the host project see what to revert?". Original brief named B6 Intent Governance Layer + B7 Rollback / Checkpoint as the M-D pair, but B6 was reframed and absorbed into M-B as B6 Evolution Capture (capture pipeline / dual-rail mutex). M-D therefore ships B7 alone, and B7 itself absorbs the original F-I-01 Adoption Lifecycle Transaction concept as a single value of the closed checkpoint_type 4-enum.
>
> **Theme**: Plan-only by design. The Core toolchain emits checkpoint envelopes, rollback plans, and verification documents; it never executes a rollback. The schema layer enforces this via the const-locked plan_only_flag; the script layer enforces it via the absence of any --apply / --execute argparse flag; the test layer enforces it via inv_009_no_auto_rollback_execution compile-time guards (Charter anti-pattern #7 + #11).

### EP decision matrix (locked 2026-05-25 17:01)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **5 commits** (c1 schemas / c2 write CLIs / c3 plan CLIs / c4 tests+inv_009 / c5 closure+tag) | Mirrors M-A / M-B sub-batch cadence; each commit independently reviewable |
| Q2 | **4 leaf scripts** under scripts/recovery/ (create_checkpoint / list_checkpoints / generate_rollback_plan / verify_rollback) | Same pattern as scripts/ltm/; testable in isolation |
| Q3 | **F-I-01 = single enum value** (`before_capability_adoption`), no separate schema | F-I-01 brief absorbed into B7 plan; collapsing to one of the 4-enum values keeps the surface minimal |
| Q4 | **Pointer-style snapshot** (path + sha256 + bytes only; no content copies) | Charter anti-pattern #14: no full release copy; smaller ledger; host owns rollback execution |
| Q5 | **No --apply / --execute flag** anywhere | Charter anti-pattern #7: no escape hatches. plan_only_flag is const-locked at the schema layer to prevent future drift |
| Q6 | **F18 = recovery schema smoke** (2 sub-checks: 3 schemas self-validate + 1 synthetic envelope) | Mirrors F17 pattern; fast-gate items document the contract surface without enforcing host completion |
| Q7 | **Per-project ledger path** (`.ai_dev_os/checkpoints/checkpoint_index.jsonl`) | Charter anti-patterns #2 / #5: Core defines envelope shape only; checkpoints live in adopting-project narrative trees, source_layer "L2" const-locked |
| Q8 | **Annotated tag v4.91-M-D** | Milestone-driven tag policy; B7 is M-D's only batch (B6 absorbed into M-B), so batch close = milestone close = tag |

### Commits (5; all landed)

```
2e89255  feat(v4.91 M-D B7 c1): recovery schema family — 3 schemas + inv_002 trigger expand (3 NEW + 1 MOD)
eab362e  feat(v4.91 M-D B7 c2): create_checkpoint + list_checkpoints CLIs (3 NEW)
5fbd855  feat(v4.91 M-D B7 c3): generate_rollback_plan + verify_rollback CLIs (2 NEW)
781dc13  test(v4.91 M-D B7 c4): tests/recovery + inv_009 wiring (4 NEW + 4 MOD, 17 tests)
<c5>     chore(v4.91 M-D B7 c5): F18 fast-gate item + RELEASE_NOTES + manifest sync + tag v4.91-M-D
```

### Surface added

| Path | Layer | Role |
|---|---|---|
| `schemas/recovery/checkpoint_manifest.schema.json` | L1 schema | Envelope contract for jsonl ledger entries; checkpoint_type 4-enum closed; pointer-style snapshot[] (path + sha256 + bytes); audit_status 3-enum (recorded / withdrawn / superseded) |
| `schemas/recovery/rollback_plan.schema.json` | L1 schema | Plan contract; **plan_only_flag const-locked literal true**; readiness 4-enum; op_kind 4-enum (revert_file / restore_file / remove_file / restore_state_field) |
| `schemas/recovery/rollback_verification.schema.json` | L1 schema | Verification result contract; overall 4-enum (ready / partial / blocked / error); per-step actual_sha256 + match boolean |
| `scripts/recovery/create_checkpoint.py` | L1 script | CLI to compute path + sha256 + bytes for --target-paths and append envelope to host ledger |
| `scripts/recovery/list_checkpoints.py` | L1 script | Read-only filter (--type / --since / --audit-status); --json (default) or --table output |
| `scripts/recovery/generate_rollback_plan.py` | L1 script | Synthesise plan from checkpoint envelope; readiness=pending; default op_kind=revert_file; **never applies** |
| `scripts/recovery/verify_rollback.py` | L1 script | Diff plan vs filesystem; emit verification doc; **never mutates** |
| `tests/recovery/test_schemas.py` | L1 test | 5 schema-shape pin tests |
| `tests/recovery/test_checkpoint_lifecycle.py` | L1 test | 5 functions × parametrize (4 hosts) = 8 lifecycle tests |
| `tests/recovery/test_no_auto_rollback.py` | L1 test | 4 compile-time guard tests for inv_009 |
| `runtime/protected_contracts/protected_regression_matrix.yaml` MOD | L1 contract | inv_002 trigger += recovery globs; inv_009_no_auto_rollback_execution NEW (8 → 9 invariants) |
| `scripts/governance/run_release_closure_gate.py` MOD | L1 governance | F6 dispatch label + summary 8/8 → 9/9; INVARIANT_SPANNING_FILES += recovery schema; F18 NEW fast-gate item |

### Charter alignment (5 anti-patterns checked)

| Anti-pattern | Status |
|---|---|
| #2 / inv_002 — Layer 1, no project literals | ✅ schemas + scripts + tests use generic placeholders only (`cp_aaaaaaaa` / `acme_demo`-style) |
| #5 — Core does not bind project narrative | ✅ source_layer const "L2"; default index path is `.ai_dev_os/checkpoints/...jsonl` (host adoption tree); --out-index / --index can override |
| #7 — no escape hatches | ✅ plan_only_flag const-locked true at schema layer; no --apply / --execute argparse flag in scripts/recovery/; inv_009 compile-time guard tests scan source for forbidden tokens |
| #11 — verification ≠ closure-gate pass | ✅ verify_rollback emits a doc; F18 tests schema validity, not rollback completion; rollback_verification.overall reports readiness, never authorises action |
| #14 — no full release copy | ✅ snapshot[] is pointer-only (path + sha256 + bytes); zero file content duplicated into ledger |

### Maintainer evidence record (laptop, 2026-05-25)

| Run | Result |
|---|---|
| `pytest tests/recovery/ -v` | 17/17 PASS (1.62 s; 14 unique functions × parametrize fan-out across 4 checkpoint types) |
| `pytest tests/governance tests/contracts tests/recovery -q` | 175/175 PASS (28.23 s; 158 baseline + 17 new) |
| `pytest tests/governance tests/contracts tests/recovery tests/profiles -q` | 195/195 PASS (post-c5 with profiles) |
| `python3 scripts/governance/lint_layer_separation.py` | clean — 47 roots / 0 violations + runtime tree clean |
| `python3 scripts/rebuild_release_manifest.py` | rebuilt; metadata preserved: schema_version=2.3, schema_notes=31, tenant_runtime_entries=1, preserved_keys=12; required=1037 / optional_seed=31 / test_fixtures=120 |
| `python3 scripts/rebuild_release_manifest.py --check` | exit 0 — clean ✓ no drift |
| `python3 scripts/governance/verify_release_clean_tree.py` | clean ✓ |
| `python3 scripts/governance/run_release_closure_gate.py --profile fast --format json` | overall=0; **fast 21/21 PASS** (+F18); F6 enforces 9/9 invariants; F18 emits "2/2 recovery schema smoke checks OK" |

### Manifest sync (c5)

- `manifest_schema_notes`: **30 → 31** (+1: M-D entry; uses v4.91-style `<batch tag>` form per P2 §5 step 3).
- `required_manifest_files`: **1023 → 1037** (+14: 3 schemas + 5 scripts (incl. __init__) + 4 tests + __init__; 4 contract / dispatcher / matrix MODs surface as sha refresh, not new entries).
- `optional_seed_files` / `test_fixtures` unchanged at 31 / 120.
- `tenant_runtime_entries` / `byte_lock` / `exclusions` / `classification_rules.tenant_runtime` / `manifest_schema_version` 2.3 all preserved verbatim by the P2 rebuilder.
- `CHECKSUMS.txt` not touched (P2-locked: only Core abstract identity files; M-D doesn't affect VERSION / MANIFEST.json / 4 version schemas).
- Fast gate raised 20 → 21 components (+F18 recovery schema smoke).

### What M-D B7 does NOT include (intentional non-features)

- **No rollback execution.** The Core never applies a plan; host project handles file operations outside this Core toolchain.
- **No --apply / --execute / --auto-apply flag** anywhere in scripts/recovery/. Charter anti-pattern #7 enforced at compile time by inv_009.
- **No content copying.** snapshot[] is pointer-only (path + sha256 + bytes). Host project handles content recovery via its own backup story.
- **No automatic checkpoint creation.** create_checkpoint is invoked deliberately by the host orchestrator before a state-changing action; there is no auto-trigger.
- **No release zip / release-directory work** (per MEMORY §16 v4.91 release delay rule; only P10 ceremony cuts the release).

### Next phase

P4 / M-D closes here. The freeze roadmap continues with **P5 — M-E B8 Memory Sync / Periodic Uplink** (Milestone E Observability, batch 1 of 2). v4.91 tag ladder advances 10 → **11**.


---

## v4.91 Milestone E — Memory Sync / Periodic Uplink (B8, CLOSED 2026-05-26)

> **Status**: CLOSED 2026-05-26 — c1 `0ba9c19` (3 schemas + 2 scripts + lint roots), c2 `640e0ed` (39 tests), c3 `144f926` (F19 + inv_010 wiring), c4 `4b99ab0` (3 docs + RELEASE_NOTES intro), c5 (this commit, manifest sync + tag). Annotated tag `v4.91-M-E-B8` applied at the c5 release commit.
>
> **Trigger**: M-E B8 is the first batch of Milestone E (Observability). It introduces the Layer 1 contract surface for periodic memory uplink: schema-conformant project + preflight summaries that adopting host projects emit at sprint closure / preflight finalisation, plus a structurally-gated 3-tier `uplink_record` ledger schema that the host's uplink consumer batches summaries into. The toolchain is one-way projection only — Core schemas + projection scripts; no Core engine reads the summaries back into a retrieval-policy boost or a cross-project promotion.
>
> **Theme**: Pointer-only summaries with structural human-confirmation. The schema layer enforces level-2 (`confirmed_by` + `confirmed_at`) and level-3 (additionally non-empty `rationale` ≤ 1000 chars) via `allOf` branches. The script layer ships zero escape hatches (no `--apply` / `--auto-confirm` / `--force` / `--bypass` / `--allow-extra` flag). The test layer includes a regex sweep + import sweep + schema-shape pin. The matrix layer adds `inv_010_no_auto_level_2_3_promotion` (Charter anti-pattern #6 + #7 + #11 jointly enforced).

### EP decision matrix (locked 2026-05-26)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **5 commits** (c1 schemas + scripts / c2 tests / c3 F19 + inv_010 / c4 docs + RELEASE_NOTES / c5 manifest sync + tag) | Mirrors M-D B7 cadence; each commit independently reviewable |
| Q2 | **3 schemas** (project_summary / preflight_summary / uplink_record) all 1.0.0 const | Mirrors M-D B7's 3-schema rollout; const-locked schema_version per Charter #4 |
| Q3 | **2 projection scripts** (sprint_close_hook + generate_preflight_summary) under scripts/memory/ | Same pattern as scripts/ltm/; pure read→emit; testable in isolation |
| Q4 | **uplink_record allOf gate at SCHEMA layer** for level-2/3 confirmation | Structural enforcement; cannot be bypassed by adopting any consumer that "forgets" to validate |
| Q5 | **Outcome enum mirrors preflight_case** (3-enum approved/rejected/deferred); withdrawn lives on audit_status, not outcome | Avoids contract drift with v4.91 B5B preflight_case schema |
| Q6 | **F19 = memory uplink smoke** (3 schema self-validate + level-2 round-trip BOTH branches) | Mirrors F17/F18 pattern; the negative branch (level-2 without confirmation) is the inv_010 escape-hatch detector |
| Q7 | **Per-project export path** (`.ai_dev_os/exports/summaries/` and `.ai_dev_os/exports/preflight_summaries/`) | Charter #5: source_layer const "L2"; summaries live in host adoption tree, not Core release tree |
| Q8 | **Annotated tag v4.91-M-E-B8** at c5 (M-E sub-batch tag) | Mirrors M-B-B4 / M-B-B5 / M-B-B5B / M-B-B6 sub-batch cadence; M-E integral close (P8) is a separate later tag |

### Commits (5; all landed)

```
0ba9c19  feat(v4.91 M-E B8 c1): memory sync schemas + projection scripts (5 NEW + 2 MOD)
640e0ed  test(v4.91 M-E B8 c2): tests/memory/ — 39 tests across 4 modules (5 NEW)
144f926  feat(v4.91 M-E B8 c3): F19 fast-gate item + inv_010 wiring (4 MOD)
4b99ab0  docs(v4.91 M-E B8 c4): docs/24_memory_sync/ + RELEASE_NOTES B8 intro (3 NEW + 3 MOD)
<c5>     chore(v4.91 M-E B8 c5): manifest sync + tag v4.91-M-E-B8
```

### Surface added (so far)

| Path | Layer | Role |
|---|---|---|
| `schemas/memory/project_summary.schema.json` | L1 schema | Sprint-close projection envelope; outcome 5-enum; uplink_level 1..3 closed; audit_status 3-enum (draft / recorded / withdrawn); pointer-only references |
| `schemas/memory/preflight_summary.schema.json` | L1 schema | Preflight-finalisation projection envelope; outcome 3-enum mirrors preflight_case; preflight_case_ref REQUIRED pointer |
| `schemas/memory/uplink_record.schema.json` | L1 schema | Append-only ledger entry; **uplink_level 1..3 with structural confirmation gate (allOf)**; summary_refs[] cap 64 pointers (kind 2-enum) |
| `scripts/memory/sprint_close_hook.py` | L1 script | Project-side sprint_close → project_summary projection; `--recorded` promotes audit_status |
| `scripts/memory/generate_preflight_summary.py` | L1 script | Project-side preflight_case → preflight_summary projection; outcome read-only mirror (Charter #12) |
| `scripts/memory/__init__.py` | L1 script | Module marker + Charter alignment notes |
| `tests/memory/test_schemas.py` | L1 test | 20 schema-shape pin tests |
| `tests/memory/test_sprint_close_hook.py` | L1 test | 7 lifecycle / negative tests + Charter #7 `--help` guard |
| `tests/memory/test_generate_preflight_summary.py` | L1 test | 6 lifecycle / negative tests + Charter #12 read-only mirror |
| `tests/memory/test_no_auto_uplink.py` | L1 test | 6 inv_010 compile-time guards (forbidden flags + forbidden imports + schema gate shape) |
| `docs/24_memory_sync/README.md` | L1 doc | Adoption surface README; Charter alignment table; cookbook |
| `docs/24_memory_sync/UPLINK_LEVEL_LADDER.md` | L1 doc | 3-tier ladder reference + decision rubric |
| `docs/24_memory_sync/PROJECTION_CONTRACT.md` | L1 doc | Projection contract; what scripts ARE / ARE NOT; exit code matrix |
| `runtime/protected_contracts/protected_regression_matrix.yaml` MOD | L1 contract | inv_002 trigger += memory + docs/24 globs (47 → 51 roots); inv_010_no_auto_level_2_3_promotion NEW (9 → 10 invariants) |
| `scripts/governance/run_release_closure_gate.py` MOD | L1 governance | F6 dispatch label + summary 9/9 → 10/10; INVARIANT_SPANNING_FILES += uplink schema; F19 NEW fast-gate item |
| `scripts/governance/lint_layer_separation.py` MOD | L1 governance | LAYER_1_ROOTS += schemas/memory + scripts/memory + tests/memory + docs/24_memory_sync (47 → 51 roots) |
| `tests/contracts/test_protected_invariant_schema.py` MOD | L1 test | invariant count 9 → 10 |
| `tests/contracts/test_required_regressions_router.py` MOD | L1 test | invariant count 9 → 10 |

### Charter alignment (5 anti-patterns checked)

| Anti-pattern | Status |
|---|---|
| #5 — Core does not bind project narrative | ✅ source_layer const "L2" on every memory schema; project_id opaque (`^[a-z0-9_-]+$`); summaries live in `.ai_dev_os/exports/...` (host adoption tree) |
| #6 — no auto-promote into retrieval policy | ✅ inv_010 must_preserve item-6 forbids retrieval_policy / promotion_policy / promote / reject imports; tests/memory/test_no_auto_uplink.py sweeps the imports at build time |
| #7 — no escape hatches | ✅ scripts/memory/ has zero `--apply` / `--auto-confirm` / `--force` / `--skip-confirm` / `--bypass` / `--allow-extra` flags; F19 round-trip negative branch catches schema drift toward unconfirmed level-2 |
| #11 — verification ≠ closure-gate pass | ✅ F19 emits SHAPE evidence only; the smoke explicitly does NOT assert any uplink completed |
| #14 — no full release copy | ✅ closure_report_ref / preflight_case_ref / event_ledger_ref / summary_refs[] are POINTERS; lessons[] cap 10×200; evidence_index[] cap 32; summary_refs[] cap 64 |

### Maintainer evidence record (laptop, 2026-05-26, c1..c5 closed)

| Run | Result |
|---|---|
| `pytest tests/memory/ -q` (after c2) | **39 passed** in 1.07 s |
| `pytest tests/memory/ tests/contracts/ -q` (after c3) | **57 passed** in 3.54 s |
| `pytest tests/ -q` (after c2) | **1381 passed** + 2 skipped + 2 expected-fail (manifest round-trip; resolved by c5 manifest sync) |
| `python3 scripts/governance/lint_layer_separation.py` (after c4) | clean — **51 roots** / 0 violations + runtime tree clean |
| `python3 scripts/governance/run_release_closure_gate.py --profile fast` (after c3) | overall=1; **21/22 PASS**; F2 expected fail (intermediate manifest state, restored by c5); F6 → "10/10 invariants enforced PASS"; F19 → "2/2 memory uplink smoke checks OK" |
| `python3 scripts/rebuild_release_manifest.py` (c5) | rebuilt; metadata preserved: `manifest_schema_version=2.3`, `schema_notes=32`, `tenant_runtime_entries=1`, `preserved_keys=12`; `required_manifest_files=1049` (was 1035) / `optional_seed=31` / `test_fixtures=120` |
| `python3 scripts/rebuild_release_manifest.py --check` (c5) | **exit 0 — clean ✓ no drift** |
| `pytest tests/ -q` (after c5) | **1383 passed** + 2 skipped (1344 baseline + 39 new in tests/memory/) in 63.12 s |
| `python3 scripts/governance/run_release_closure_gate.py --profile fast` (after c5) | **overall=0**; **22/22 PASS** in ~7 s (benchmark target: typical range 7–12 s on laptop) |
| `python3 scripts/governance/verify_release_clean_tree.py` (after c5) | clean ✓ |

### Manifest sync (c5)

- `manifest_schema_notes`: **31 → 32** (+1 entry: M-E B8 details, including the Charter #5/#6/#7 alignment notes and the `47 → 51` lint root delta).
- `required_manifest_files`: **1035 → 1049** (+14: 3 schemas + 3 scripts + 5 tests + 3 docs; lint + matrix + run_release_closure_gate + RELEASE_NOTES + 2 contracts test surface as sha refresh, not new entries).
- `optional_seed_files` / `test_fixtures` unchanged at 31 / 120.
- `manifest_schema_version` 2.3 preserved verbatim; no shape change.
- `tenant_runtime_entries` / `byte_lock` / `exclusions` / `classification_rules.tenant_runtime` all preserved by the P2 rebuilder canonical path.
- `CHECKSUMS.txt` not touched (P2-locked: only Core abstract identity files; B8 doesn't touch VERSION / MANIFEST.json / 4 version schemas).
- Fast gate raised 21 → 22 components (+F19 memory uplink smoke).

### What M-E B8 does NOT include (intentional non-features)

- **No automatic uplink.** Level 2/3 entries cannot be minted without `confirmed_by` + `confirmed_at` (and rationale for level 3); the schema's allOf branches block any consumer that tries.
- **No retrieval-policy feedback loop.** scripts/memory/ does not import retrieval_policy / promotion_policy / promote / reject (Charter #6); inv_010 must_preserve item-6 enforces this at compile time.
- **No content embedding.** All summary references are pointers (closure_report_ref / preflight_case_ref / event_ledger_ref / summary_refs[].ref).
- **No uplink consumer.** The host project owns the uplink_record ledger writer; B8 ships the schema + projection only.
- **No release-zip work** (per MEMORY §16 v4.91 release-delay rule; only P10 ceremony cuts the release).

### Next phase

P5 / M-E B8 closes here. The freeze roadmap continues with **P6 — M-E B9 Static Runtime Panel Export** (Milestone E, batch 2 of 2). v4.91 tag ladder advances 11 → **12**.


---

## v4.91 Milestone E — Static Runtime Panel Export (B9, CLOSED 2026-05-26)

> **Status**: CLOSED 2026-05-26 — c1 `4d98cd2` (script + 6 templates + lint roots), c2 `0494df4` (11 tests), c3 `3328e1d` (F20 + inv_011 wiring), c4 `0ad72a8` (2 docs + RELEASE_NOTES intro), c5 (this commit, manifest sync + tag). Annotated tag `v4.91-M-E-B9` applied at the c5 release commit.
>
> **Trigger**: M-E B9 is the second batch of Milestone E (Observability). It introduces a Layer 1 read-only HTML snapshot exporter that reads hub state, projects index, LTM ledgers, RELEASE_MANIFEST + VERSION, and the protected invariant matrix, and emits 6 static HTML pages into a host-side `exports/panel/` directory. The output is intended for human operator review; no machine consumer reads the panel HTML (that would create the exact reporting → auto-promote feedback the Charter forbids).
>
> **Theme**: Strictly read-only with respect to runtime state. No `--apply` / `--execute` / `--auto-confirm` / `--force` / `--bypass` flags; no imports of any state-mutating engine across governance / ltm / hub / recovery / memory; no destructive primitives (`shutil.rmtree` / `subprocess.*` / `os.system` / `os.unlink` / `os.remove`); writes ONLY to `out_dir / name`. inv_011_panel_no_runtime_mutation enforces the contract at the matrix layer; tests/panel/test_no_runtime_mutation.py enforces it at the build layer.

### EP decision matrix (locked 2026-05-26)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **5 commits** (c1 script + 6 templates / c2 11 tests / c3 F20 + inv_011 / c4 docs + RELEASE_NOTES / c5 manifest sync + tag) | Mirrors M-D B7 + M-E B8 cadence. |
| Q2 | **Plain string substitution** (no Jinja2 / no Mako / no eval) | Zero-dep; no template-language attack surface. |
| Q3 | **6 page kinds, fixed at the schema layer** (hub_overview / project_status_<pid> / cross_project_candidates / memory_health / version_lock_status / preflight_governance) | inv_011 must_preserve item-5 fixes the kind list; adding a kind requires EP + matrix-owner. |
| Q4 | **Default --out-dir = exports/panel/** (host-side gitignored) | exports/ is already classified as generated_runtime_outputs; panel output is never committed (Charter #14). |
| Q5 | **F20 = panel export smoke** (script exit 0 + 5 fixed pages emitted; project_status conditional) | Mirrors F18/F19 pattern; smoke tests COMPLETION, not semantic correctness. |
| Q6 | **inv_011 enforces at TWO layers** (matrix `must_preserve` items + `tests/panel/test_no_runtime_mutation.py` regex sweeps) | Charter #7 + #6 + #11 jointly enforced; structural drift caught at gate-time AND build-time. |
| Q7 | **Best-effort placeholders** when SoT files are missing (uninitialised hub still produces a useful panel) | Operator-friendly; never crashes the exporter on a fresh hub. |
| Q8 | **Annotated tag v4.91-M-E-B9** at c5 (M-E sub-batch tag) | Mirrors M-E-B8 cadence; M-E integral close (P8) is a separate later tag. |

### Commits (5; all landed)

```
4d98cd2  feat(v4.91 M-E B9 c1): static runtime panel export script + 6 templates (8 NEW + 2 MOD)
0494df4  test(v4.91 M-E B9 c2): tests/panel/ — 11 tests across 2 modules (3 NEW)
3328e1d  feat(v4.91 M-E B9 c3): F20 fast-gate item + inv_011 wiring (4 MOD)
0ad72a8  docs(v4.91 M-E B9 c4): docs/25_panel_export/ + RELEASE_NOTES B9 intro (2 NEW + 3 MOD)
<c5>     chore(v4.91 M-E B9 c5): manifest sync + tag v4.91-M-E-B9
```

### Surface added (so far)

| Path | Layer | Role |
|---|---|---|
| `scripts/panel/__init__.py` | L1 script | Module marker + Charter alignment notes. |
| `scripts/panel/export_static_panel.py` | L1 script | Read-only HTML snapshot exporter; emits 6 page kinds; default --out-dir exports/panel/; exit codes 0/1/2/3/4. |
| `templates/panel/hub_overview.html.tmpl` | resource | Hub identity + linked-projects table. |
| `templates/panel/project_status.html.tmpl` | resource | Per-project identity + adoption summary placeholder. |
| `templates/panel/cross_project_candidates.html.tmpl` | resource | Lifecycle counts + recent candidates table. |
| `templates/panel/memory_health.html.tmpl` | resource | LTM domain counts + quarantine + promote/reject/supersede ledger sizes. |
| `templates/panel/version_lock_status.html.tmpl` | resource | Core abstract identity + per-project version_lock state. |
| `templates/panel/preflight_governance.html.tmpl` | resource | Preflight cases by outcome + recent cases + protected invariant summary. |
| `tests/panel/test_export_idempotent.py` | L1 test | 7 idempotence / lifecycle tests. |
| `tests/panel/test_no_runtime_mutation.py` | L1 test | 4 inv_011 compile-time guards. |
| `docs/25_panel_export/README.md` | L1 doc | Adoption surface README; Charter alignment table; read-only contract. |
| `docs/25_panel_export/PAGE_REFERENCE.md` | L1 doc | Page-by-page field reference + placeholder behaviour + filename rules. |
| `runtime/protected_contracts/protected_regression_matrix.yaml` MOD | L1 contract | inv_002 trigger += panel + docs/25 globs (51 → 54 roots); inv_011_panel_no_runtime_mutation NEW (10 → 11 invariants). |
| `scripts/governance/run_release_closure_gate.py` MOD | L1 governance | F6 dispatch label + summary 10/10 → 11/11; INVARIANT_SPANNING_FILES += panel script; F20 NEW fast-gate item (22 → 23 components). |
| `scripts/governance/lint_layer_separation.py` MOD | L1 governance | LAYER_1_ROOTS += scripts/panel + tests/panel + docs/25_panel_export (51 → 54 roots). |
| `tests/contracts/test_protected_invariant_schema.py` MOD | L1 test | invariant count 10 → 11. |
| `tests/contracts/test_required_regressions_router.py` MOD | L1 test | invariant count 10 → 11. |

### Charter alignment (5 anti-patterns checked)

| Anti-pattern | Status |
|---|---|
| #5 — Core does not bind project narrative | ✅ Templates use generic placeholders only; project_id is read opaquely from JSON SoT and sanitised to `[a-zA-Z0-9_-]` before use as a filename component. |
| #6 — no auto-promote into retrieval policy | ✅ inv_011 must_preserve item-2 forbids imports of every state-mutating engine; tests/panel/test_no_runtime_mutation.py sweeps imports at build-time. |
| #7 — no escape hatches | ✅ scripts/panel/ has zero `--apply` / `--execute` / `--auto-confirm` / `--force` / `--skip-confirm` / `--bypass` / `--allow-extra` / `--run` / `--do-apply` flags. |
| #11 — verification ≠ closure-gate pass | ✅ F20 emits COMPLETION evidence (script ran + N pages); the smoke explicitly does NOT assert page contents are semantically correct. Page footers carry "panel never authorises" disclaimers. |
| #14 — no full release copy | ✅ Panel cites by path / count / id; never embeds the body of an underlying ledger entry. Output stays under host-side gitignored `exports/panel/`. |

### Maintainer evidence record (laptop, 2026-05-26, c1..c5 closed)

| Run | Result |
|---|---|
| `pytest tests/panel/ -q` (after c2) | **11 passed** in 0.45 s |
| `pytest tests/panel/ tests/contracts/ tests/memory/ -q` (after c3) | **68 passed** in 3.06 s |
| `pytest tests/ -q` (after c2) | **1392 passed** + 2 skipped + 2 expected-fail (manifest round-trip; resolved by c5 manifest sync) |
| `python3 scripts/governance/lint_layer_separation.py` (after c4) | clean — **54 roots** / 0 violations + runtime tree clean |
| `python3 scripts/governance/run_release_closure_gate.py --profile fast` (after c3) | overall=1; **22/23 PASS**; F2 expected fail (intermediate manifest state, restored by c5); F6 → "11/11 invariants enforced PASS"; F19 → "2/2 memory uplink smoke checks OK"; F20 → "2/2 panel export smoke checks OK (script exit 0 + 5 fixed pages emitted)" |
| `python3 scripts/rebuild_release_manifest.py` (c5) | rebuilt; metadata preserved: `manifest_schema_version=2.3`, `schema_notes=33`, `tenant_runtime_entries=1`, `preserved_keys=12`; `required_manifest_files=1062` (was 1049) / `optional_seed=31` / `test_fixtures=120` |
| `python3 scripts/rebuild_release_manifest.py --check` (c5) | **exit 0 — clean ✓ no drift** |
| `pytest tests/ -q` (after c5) | **1394 passed** + 2 skipped (1383 baseline + 11 new in tests/panel/) in 66.75 s |
| `python3 scripts/governance/run_release_closure_gate.py --profile fast` (after c5) | **overall=0**; **23/23 PASS** in ~7 s (benchmark target: typical range 7–12 s on laptop) |
| `python3 scripts/governance/verify_release_clean_tree.py` (after c5) | clean ✓ |

### Manifest sync (c5)

- `manifest_schema_notes`: **32 → 33** (+1 entry: M-E B9 details, including the Charter #6/#7/#11/#14 alignment notes and the `51 → 54` lint root delta).
- `required_manifest_files`: **1049 → 1062** (+13 net: 1 NEW script + 1 NEW __init__ + 6 NEW templates + 3 NEW tests + 2 NEW docs; lint + matrix + run_release_closure_gate + RELEASE_NOTES + 2 contracts test surface as sha refresh, not new entries).
- `optional_seed_files` / `test_fixtures` unchanged at 31 / 120.
- `manifest_schema_version` 2.3 preserved verbatim; no shape change.
- `tenant_runtime_entries` / `byte_lock` / `exclusions` / `classification_rules.tenant_runtime` all preserved by the P2 rebuilder canonical path.
- `CHECKSUMS.txt` not touched (P2-locked: only Core abstract identity files; B9 doesn't touch VERSION / MANIFEST.json / 4 version schemas).
- Fast gate raised 22 → 23 components (+F20 panel export smoke).

### What M-E B9 does NOT include (intentional non-features)

- **No state-mutating side effects.** The exporter is strictly read-only with respect to runtime state; inv_011 enforces this at the matrix layer + tests/panel/test_no_runtime_mutation.py at the build layer.
- **No JavaScript / no AJAX / no external assets.** Panel HTML is self-contained inline-styled markup; opens cleanly from a `file://` URL.
- **No machine consumer.** Panel HTML is for human operator review only. A machine consumer would create the exact reporting → auto-promote feedback loop the Charter forbids (anti-pattern #6 / #11).
- **No scheduled / daemon mode.** The exporter is a one-shot snapshot generator. Polling is the host project's outer scheduler's responsibility.
- **No release-zip work** (per MEMORY §16 v4.91 release-delay rule; only P10 ceremony cuts the release).

### Next phase

P6 / M-E B9 closes here. The freeze roadmap continues with **P7 — B-DUAL-PHASE-DOC** (doc-only batch; no tag).


---

## v4.91 P7 — B-DUAL-PHASE-DOC (CLOSED 2026-05-26, doc-only, no tag)

> **Status**: CLOSED 2026-05-26 — c1 `79f4efc` (3 docs + lint roots), c2 (this commit, manifest sync). NO annotated tag (per handoff §3.3 — P7 is doc-only).
>
> **Trigger**: P7 formalises the v4.90.9-era separation of `stage` (project lifecycle 7-enum) and `game_dev_phase` (game-build workflow 7-enum). The schema shipped in v4.90.9; the formal Layer 1 workflow documentation deliberately landed in P7 once Hub Core / Project Mount / Version Lock / Memory Sync / Panel Export were all available to reference.
>
> **Theme**: Doc-only. No schema change, no script change, no fast-gate item, no new invariant, no annotated tag. The 7×7 decision matrix is recommendation-only; no Layer 1 gate enforces a particular cell. Charter anti-patterns #4 (extend, don't replace — reinforces 1.0.0 → 1.1.0 minor-bump precedent) + #5 (Core does not bind to project narrative — both 7-enums use generic vocabulary) + #11 (recording != closure-gate pass — matrix is recommendation-only).

### EP decision matrix (locked 2026-05-26)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **2-commit ladder** (c1 docs + lint roots / c2 manifest sync) | Doc-only batches use a shorter ladder than schema/script batches. |
| Q2 | **`docs/26_dual_phase/`** (not 25 — 25 is occupied by panel export) | P6 took 25; P7 advances to 26. |
| Q3 | **3 doc files** (README + DECISION_MATRIX + WORKFLOW_GUIDE) | Mirrors the docs/23_subagent_routing_gate/ structure (README + DECISION_RULES + AUDIT_LEDGER_CONTRACT). |
| Q4 | **No tag** (handoff §3.3 specifies P7 is doc-only) | Tag economy: doc-only batches are absorbed into the next milestone tag. |
| Q5 | **Recommendation-only matrix** (no Layer 1 gate consults `game_dev_phase`) | Charter #5 — adding a gate that reads `game_dev_phase` would be a contract change requiring EP + matrix-owner approval. |

### Commits (2; all landed)

```
79f4efc  docs(v4.91 P7 c1): docs/26_dual_phase/ × 3 docs (3 NEW + 2 MOD)
<c2>     chore(v4.91 P7 c2): manifest sync + RELEASE_NOTES P7 entry (1 MOD)
```

### Surface added

| Path | Layer | Role |
|---|---|---|
| `docs/26_dual_phase/README.md` | L1 doc | Overview; explains the v4.90.9 split and Charter alignment. |
| `docs/26_dual_phase/DECISION_MATRIX.md` | L1 doc | The 7×7 cell table (49 cells: 13 TYPICAL / 9 EARLY / 17 LATE / 4 REVIEW / 7 TERMINAL); 4 worked examples; caveats. |
| `docs/26_dual_phase/WORKFLOW_GUIDE.md` | L1 doc | Adoption flow (first-time + migration); day-to-day field-change ownership; 3 common edge cases; 5-question FAQ. |
| `runtime/protected_contracts/protected_regression_matrix.yaml` MOD | L1 contract | inv_002 trigger += `docs/26_dual_phase/**` (54 → 55 roots). |
| `scripts/governance/lint_layer_separation.py` MOD | L1 governance | LAYER_1_ROOTS += `docs/26_dual_phase` (54 → 55 roots). |

### Charter alignment

| # | Anti-pattern | Status |
|---|---|---|
| 4 | Extend, don't replace | ✅ Doc reinforces the 1.0.0 → 1.1.0 minor-bump precedent. |
| 5 | Core does not bind project narrative | ✅ Both 7-enums use generic vocabulary; no project name appears in any of the 3 doc files. |
| 11 | Verification != closure-gate pass | ✅ Matrix is recommendation-only; no Layer 1 gate enforces a particular cell. |

### Maintainer evidence record (laptop, 2026-05-26)

| Run | Result |
|---|---|
| `python3 scripts/governance/lint_layer_separation.py` (after c1) | clean — **55 roots** / 0 violations + runtime tree clean |
| `python3 scripts/rebuild_release_manifest.py` (c2) | rebuilt; metadata preserved: `manifest_schema_version=2.3`, `schema_notes=34`, `tenant_runtime_entries=1`, `preserved_keys=12`; `required_manifest_files=1065` (was 1062) |
| `python3 scripts/rebuild_release_manifest.py --check` (c2) | **exit 0 — clean ✓ no drift** |
| `pytest tests/ -q` (after c2) | **1394 passed** + 2 skipped in 64.82 s (doc-only batch, count unchanged) |
| `python3 scripts/governance/run_release_closure_gate.py --profile fast` (after c2) | **overall=0**; **23/23 PASS** in ~8 s |

### Manifest sync (c2)

- `manifest_schema_notes`: **33 → 34** (+1 entry: P7 doc-only details).
- `required_manifest_files`: **1062 → 1065** (+3 net: 3 NEW docs; lint + matrix MODs surface as sha refresh, not new entries).
- `manifest_schema_version` 2.3 preserved verbatim; no shape change.
- All other metadata fields preserved by the P2 rebuilder canonical path.
- Fast gate item count UNCHANGED (still 23). No F21 added.
- Protected invariant count UNCHANGED (still 11). No inv_012 added.

### What P7 does NOT include (intentional non-features)

- **No schema change.** `project_profile.schema.json` stays at 1.1.0.
- **No script change.** `init_project_runtime.py` keeps its v4.90.9 derive-default behaviour.
- **No new fast-gate item.** No F21.
- **No new invariant.** No inv_012.
- **No annotated tag.** Doc-only per handoff §3.3.
- **No release-zip work** (per MEMORY §16 v4.91 release-delay rule).

### Next phase

P7 closes here. The freeze roadmap continues with **P8 — M-E integral close** (Milestone E rollup; tag `v4.91-M-E`). v4.91 tag ladder advances 13 → **14**.


---

## v4.91 Milestone E — Observability (CLOSED 2026-05-26, integral roll-up)

> **Status**: CLOSED 2026-05-26 — single roll-up commit on top of P7 c2 (`f234223`). Annotated tag `v4.91-M-E` covers **B8 + B9 + the dual-phase doc batch (P7)** as a unified milestone.
>
> **Constituent batches** (already individually tagged / committed):
> - `v4.91-M-E-B8` (commit `7e94fa2`) — Memory Sync / Periodic Uplink (closed 2026-05-26).
> - `v4.91-M-E-B9` (commit `b17ea4b`) — Static Runtime Panel Export (closed 2026-05-26).
> - P7 / B-DUAL-PHASE-DOC (commits `79f4efc` + `f234223`) — Dual-phase decision-matrix docs (closed 2026-05-26, no individual tag; absorbed here).
>
> **Theme**: Observability surface for adopting projects. Milestone E ships the three Layer 1 surfaces an operator needs to *see* and *record* the system without changing it: a one-way summary projection (B8), a static HTML snapshot (B9), and the formal decision matrix that ties stage × game_dev_phase together (P7). All three honour Charter anti-patterns #6 (no auto-promote) + #11 (recording != closure-gate pass) + #14 (no full release copy by default) jointly.

### What Milestone E delivers (rollup)

| Surface | From batch | One-line |
|---|---|---|
| `schemas/memory/{project_summary,preflight_summary,uplink_record}.schema.json` | B8 | 3 schemas (1.0.0 const) defining the periodic uplink projection contract. |
| `scripts/memory/{sprint_close_hook,generate_preflight_summary}.py` | B8 | Two pure projection scripts emitting summaries into host adoption tree. |
| `tests/memory/` (39 tests) | B8 | Schema-shape pin + lifecycle + Charter #6/#7 import / flag sweeps. |
| `docs/24_memory_sync/` (3 docs) | B8 | README + UPLINK_LEVEL_LADDER + PROJECTION_CONTRACT. |
| `inv_010_no_auto_level_2_3_promotion` | B8 | Matrix-layer enforcement of human-confirmation gate at uplink levels 2 / 3. |
| F19 `Memory uplink smoke (v4.91 M-E B8)` | B8 | Fast-gate item: 3 schemas self-validate + level-2 round-trip BOTH branches. |
| `scripts/panel/export_static_panel.py` + `__init__.py` | B9 | Read-only HTML snapshot exporter for hub state / projects / LTM ledgers. |
| `templates/panel/*.html.tmpl` (6 templates) | B9 | hub_overview / project_status / cross_project_candidates / memory_health / version_lock_status / preflight_governance. |
| `tests/panel/` (11 tests) | B9 | Idempotence / lifecycle + 4 inv_011 compile-time guards. |
| `docs/25_panel_export/` (2 docs) | B9 | README + PAGE_REFERENCE. |
| `inv_011_panel_no_runtime_mutation` | B9 | Matrix-layer enforcement of read-only-with-respect-to-runtime-state for the panel exporter. |
| F20 `Panel export smoke (v4.91 M-E B9)` | B9 | Fast-gate item: live-repo end-to-end smoke (script exit 0 + 5 fixed pages). |
| `docs/26_dual_phase/` (3 docs) | P7 | README + DECISION_MATRIX (49 cells, 5 postures) + WORKFLOW_GUIDE (3 edge cases + 5-Q FAQ). |

### Cumulative deltas across M-E

| Metric | Before M-E (post-M-D) | After M-E (this commit) | Δ |
|---|---|---|---|
| pytest tests/ | 1344 / 2 skip | 1394 / 2 skip | +50 (39 memory + 11 panel) |
| Fast-gate items | 21 (F1..F18 + F8a-d + F2) | 23 (+F19 +F20) | +2 |
| Protected invariants | 9 (latest inv_009) | 11 (latest inv_011) | +2 (inv_010 / inv_011) |
| Layer 1 lint roots | 47 | 55 | +8 (memory ×3 + docs/24 + panel ×2 + docs/25 + docs/26) |
| Manifest schema_notes | 31 | 34 | +3 (B8 / B9 / P7 entries) |
| Manifest required_files | 1035 | 1065 | +30 (B8 14 + B9 13 + P7 3) |
| v4.91 tag ladder | 11 | 14 (this commit completes) | +3 (M-E-B8 / M-E-B9 / M-E) |

### EP decision matrix (locked 2026-05-26)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **Single roll-up commit** (this commit) | Mirrors v4.91-M-B integral close pattern (`f0b2c69`). Constituent batches already independently tagged. |
| Q2 | **Tag covers B8 + B9 + P7 doc batch** | P7 is doc-only and intentionally tagless; it is absorbed by the milestone tag. B8 and B9 keep their sub-batch tags AND get covered by M-E. |
| Q3 | **No new schema / script / test / fast-gate item / invariant** in this commit | Roll-up commits are summary documentation only; the Charter forbids "secret content" in milestone-close commits. |
| Q4 | **Manifest sync via canonical path** (rebuilder + --check, MEMORY contract #17) | All manifest changes go through the rebuilder; no surgical hand-edit. |
| Q5 | **Annotated tag** `v4.91-M-E` (NOT lightweight) | MEMORY contract #12 — milestone-driven tag policy. |
| Q6 | **No release dir / no zip / no rehearsal** | MEMORY contract #16 — only P10 ceremony cuts the release. |

### Maintainer evidence record (laptop, 2026-05-26)

| Run | Result |
|---|---|
| `python3 scripts/governance/lint_layer_separation.py` | clean — **55 roots** / 0 violations + runtime tree clean |
| `python3 scripts/rebuild_release_manifest.py --check` (pre-commit) | exit 0 — clean ✓ no drift (will re-verify post-commit) |
| `pytest tests/ -q` | **1394 passed** + 2 skipped in 64.82 s |
| `python3 scripts/governance/run_release_closure_gate.py --profile fast` | **overall=0**; **23/23 PASS** in ~8 s |

### Charter alignment (cumulative across M-E)

| # | Anti-pattern | Where enforced |
|---|---|---|
| 4 | Extend, don't replace | All 3 memory schemas, all 6 panel templates, the dual-phase doc — every artefact carries const-locked schema_version 1.0.0 (memory) or extends a 1.1.0 schema (project_profile). |
| 5 | Core does not bind project narrative | source_layer "L2" const on every memory schema; project_id opaque; templates use generic placeholders; both 7-enums in the dual-phase matrix use generic vocabulary. |
| 6 | No auto-promote | inv_010 + inv_011 + tests/memory/ + tests/panel/ all forbid imports of retrieval_policy / promotion_policy / etc. |
| 7 | No escape hatches | scripts/memory/ + scripts/panel/ have zero `--apply` / `--auto-confirm` / `--force` / `--bypass` / `--allow-extra` flags. |
| 11 | Recording != closure-gate pass | F19 + F20 + the dual-phase decision matrix all explicitly carry "recording is evidence, not authorisation" disclaimers. |
| 14 | No full release copy | All summary refs / case refs / ledger refs are pointers; lessons[]/evidence_index[]/summary_refs[] capped; panel cites by path/count/id only. |

### What M-E does NOT include (intentional non-features)

- **No machine consumer** of the panel HTML — would create the exact reporting → auto-promote feedback the Charter forbids.
- **No automatic uplink** — Level-2/3 always requires human confirmation (inv_010 allOf gate).
- **No cross-batch coupling** — B8 and B9 surfaces are orthogonal; the dual-phase matrix doesn't gate either.
- **No release-zip work** (per MEMORY contract #16; only P10 ceremony cuts the release).

### Next phase

M-E closes here. The freeze roadmap continues with **P9 — D v4.91-RC closure gate** (RC criteria evidence record + any final fixes; tag `v4.91-RC1`). v4.91 tag ladder advances 14 → **15**.


---

## v4.91 Milestone F — Intent Governance Layer v0 (Batch 6, CLOSED 2026-05-28)

> **Status**: CLOSED 2026-05-28 — c1 `e9946d3` (3 schemas + ledger placeholder), c2 `5a37c06` (5 scripts + inv_012 + Layer 1 root expansion), c3 `4a14aec` (7 test files / 111 tests), c4 (this commit, 5 docs + RELEASE_NOTES + manifest sync), c5 (tag-only). Annotated tag `v4.91-M-F` applied at the c5 release commit.
>
> **Trigger**: Batch 6 was the only block from the 7 v4.91 plan documents (in `~/Downloads/AI_Dev_OS_v4.91_*.md`) that the prior P10 ceremony (2026-05-26) had not delivered. EP review on 2026-05-28 found that Charter anti-patterns #6 / #11 / #13 + Addendum-C delegation gate (inv_008) were carrying the "no auto-mutate intent" guarantee implicitly via reflexive enforcement, but no explicit Intent Governance schema + freeze gate + diff report existed. EP decision (recorded in `MEMORY.md` §1): reopen v4.91 freeze, retract the original `v4.91-release` tag (preserved as commit `dd9863f` in git history), and ship Batch 6 as Milestone F before re-cutting RC2 / REL2.
>
> **Theme**: Intent baselines + freeze gate + diff report — schema-locked goals/non_goals/acceptance_criteria contract that recommendations, cross-project candidates, agent decisions, and preflight consensus pipelines MUST NOT silently change. The `auto_semantic_judgement` schema-const `"not_performed"` is the schema-layer enforcement of Charter anti-pattern #6.

### EP decision matrix (locked 2026-05-28)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **5-commit ladder** (c1 schemas / c2 scripts+inv / c3 tests / c4 docs+notes+manifest / c5 tag-only) | Mirrors B5/B5B/M-D 5-commit cadence; B6 is a full feature batch (3 schemas + 3 CLIs + 1 invariant + 5 docs), not a doc-only or tag-only patch. |
| Q2 | **Annotated tag `v4.91-M-F`** | Milestone-driven tag policy (M-A / M-B / M-C / M-D / M-E precedent). B6 is M-F's only batch, so batch close = milestone close = tag. |
| Q3 | **inv_012, not inv_009** | inv_008/009/010/011 already taken by Addendum-C / M-D B7 / M-E B8 / M-E B9. inv_012 is the next free slot. |
| Q4 | **`docs/27_intent_governance/`, not `docs/19_intent_governance/`** | docs/19_ already taken by F-T-01 tenancy contract. 27 is the next free slot after 26 (dual-phase). |
| Q5 | **No new fast-gate item** | The intent gate is owner-driven, not auto-runnable. F1-F20 fast gate items remain unchanged; full-gate path covers `tests/intent/` via the standard pytest invocation. (Future revision MAY add F21 `intent-smoke` if the operations rate justifies it.) |
| Q6 | **String-equality cross-project boundary check** | Charter anti-pattern #6 forbids automatic semantic judgement of intent compatibility. v0 uses literal string equality only; semantic similarity scoring is forbidden until v4.92+ explicitly bumps `auto_semantic_judgement` const. |
| Q7 | **No project-side scaffold path declared** | Batch 6 is OS Core-side only. Project-side `<project>/.ai_dev_os/intent/baseline.json` is documented in `INTENT_BASELINE_MODEL.md` §7 but no v4.91-side init script generates it (project owner authors it directly). |
| Q8 | **Preserve `dd9863f` and `cfe6d6b` in git history** | The retracted P10 ceremony commits stay in git history as P10-rehearsal evidence per Charter §6.2 byte-lock evolution rules. The RC2 / REL2 commits will form the new tip; the rehearsal chain is observable but not tagged. |

### Commits (5; c4 = this commit)

```
e9946d3  feat(v4.91 B6 c1): schemas/intent/ + intent_baseline_ledger placeholder (3 NEW + 1 NEW empty)
5a37c06  feat(v4.91 B6 c2): scripts/intent/ x5 + inv_012 + Layer 1 root expansion (10 NEW + 4 MOD)
4a14aec  test(v4.91 B6 c3): tests/intent/ x7 — 111 tests cover schema + workflow + actor gate + ledger envelope + invariant guards (7 NEW)
<c4>     docs(v4.91 B6 c4): docs/27_intent_governance/ x5 + RELEASE_NOTES M-F closure + manifest sync (6 NEW + N MOD)
<c5>     chore(v4.91 B6 c5): annotated tag v4.91-M-F + memory log
```

### Surface added

| Path | Layer | Role |
|---|---|---|
| `schemas/intent/intent_baseline.schema.json` (NEW, 1.0.0) | L1 source | 4-state freeze lifecycle + 6-enum scope + 6-enum owner_role + intent_boundary block |
| `schemas/intent/intent_diff_report.schema.json` (NEW, 1.0.0) | L1 source | 6-array delta + requires_preflight_review hint + auto_semantic_judgement schema-const "not_performed" |
| `schemas/intent/intent_baseline_ledger.schema.json` (NEW, 1.0.0) | L1 source | v4.89 9-field envelope + 6-enum result + ib_XXXXXXXX event_id pattern |
| `runtime/registries/intent_baseline_ledger.jsonl` (NEW, empty) | runtime | append-only canonical mirror |
| `scripts/intent/__init__.py` (NEW) | L1 source | package marker + 3-CLI README |
| `scripts/intent/_intent_common.py` (NEW, 347 LOC) | L1 source | FORBIDDEN_ACTORS + 5 enums + ledger writer + 6 exit codes |
| `scripts/intent/generate_intent_baseline.py` (NEW, 281 LOC) | L1 source | draft → DRAFT_VALIDATED/FROZEN/REOPENED/SUPERSEDED ledger emit |
| `scripts/intent/validate_intent_freeze.py` (NEW, 327 LOC) | L1 source | 8-cell transition matrix + FREEZE_VIOLATION exit 5 |
| `scripts/intent/generate_intent_diff_report.py` (NEW, 235 LOC) | L1 source | 6-array delta + reason_code auto-derive + DIFF_GENERATED ledger |
| `tests/intent/__init__.py` (NEW) | L1 test | package marker |
| `tests/intent/test_intent_baseline_schema.py` (NEW, 28 tests) | L1 test | 3 schemas draft-07 + happy fixtures + 17 invalid variants |
| `tests/intent/test_intent_freeze_workflow.py` (NEW, 11 tests) | L1 test | 8-cell transition matrix subprocess E2E |
| `tests/intent/test_intent_forbidden_actors.py` (NEW, 47 tests) | L1 test | 10-token vocab × 3 CLIs (bare + prefix smuggling) + 6 permitted actors + frozen_by gate |
| `tests/intent/test_intent_diff_report_no_auto_judgement.py` (NEW, 8 tests) | L1 test | const lock + auto-derive + argparse strict |
| `tests/intent/test_intent_no_apply_flag.py` (NEW, 8 tests) | L1 test | inv_012 compile-time guard: 11 forbidden flags + 7 enum locks |
| `tests/intent/test_intent_no_state_mutation.py` (NEW, 5 tests) | L1 test | 15 forbidden imports + truncating-open + append-only ledger writer |
| `tests/intent/test_intent_ledger_envelope.py` (NEW, 4 tests) | L1 test | 9-field envelope schema validate + uniqueness |
| `runtime/protected_contracts/protected_regression_matrix.yaml` (MOD) | L1 source | header invariant count 11 → 12; inv_002 trigger_files +4 paths; inv_002 must_preserve "55 → 59 roots"; NEW inv_012_intent_baseline_freeze_respected (4 trigger / 11 must_preserve / pytest tests/intent/) |
| `scripts/governance/lint_layer_separation.py` (MOD) | L1 source | LAYER_1_ROOTS += [docs/27_intent_governance, schemas/intent, scripts/intent, tests/intent] |
| `tests/contracts/test_protected_invariant_schema.py` (MOD) | L1 test | expected count 11 → 12 |
| `tests/contracts/test_required_regressions_router.py` (MOD) | L1 test | expected count 11 → 12 |
| `docs/27_intent_governance/README.md` (NEW) | L1 source | adoption notes + Charter alignment table + 8-cell workflow diagram + Layer 1/2 boundary |
| `docs/27_intent_governance/INTENT_BASELINE_MODEL.md` (NEW) | L1 source | what a baseline is + scope/owner_role 6-enum + freeze lifecycle |
| `docs/27_intent_governance/INTENT_FREEZE_AND_REOPEN_GATE.md` (NEW) | L1 source | CLI surface + 8-cell transition matrix + ledger envelope shape + reopen / supersede gate detail |
| `docs/27_intent_governance/INTENT_DIFF_REPORT_V0.md` (NEW) | L1 source | schema shape + auto_semantic_judgement enforcement + 7-token reason_codes + requires_preflight_review derivation |
| `docs/27_intent_governance/CROSS_PROJECT_INTENT_BOUNDARY.md` (NEW) | L1 source | intent_boundary block + B5 cross-project candidate adoption flow + Charter #10 enforcement |

### Charter alignment (5 anti-patterns enforced post-M-F)

Anti-patterns enforced post-Batch 6 (15 total, all green):

| # | Anti-pattern | M-F enforcement layer |
|---|---|---|
| 2 | project names in Core | All M-F fixtures use `project_alpha` / `project_beta` + `intent_alpha` / `intent_beta` opaque tokens; `lint_layer_separation` extends to 4 new roots and stays clean |
| 6 | evidence-threshold auto-promote | `intent_diff_report.auto_semantic_judgement` schema-const `"not_performed"`; `validate_intent_freeze` never mutates baselines; cross-project boundary check uses string-equality only (no semantic NLP) |
| 11 | preflight as gate-pass | `requires_preflight_review` is REQUEST flag; `FREEZE_VIOLATION` ledger entry records rejection without authorising anything; consensus / human review remain independent gates |
| 13 | host_profile auto multi-agent default | 10-token forbidden_actors vocabulary refused at runtime by all 3 intent CLIs (bare AND prefix-smuggled); `freeze.frozen_by` validator enforces same vocabulary |
| 7 | `--allow-extra` / escape hatches | inv_012 compile-time guard: `scripts/intent/` MUST NOT define `--apply` / `--execute` / `--auto-confirm` / `--force` / `--skip-confirm` / `--bypass` / `--allow-extra` / `--override-freeze` / `--run` / `--do-apply` flags |

The M-F anti-pattern total stays at 15 (not 16); no new anti-pattern is added — Charter #6 / #11 / #13 / #7 already existed and B6 implements their schema/runtime enforcement layer for intent governance.

### Maintainer evidence record (laptop, 2026-05-28)

| Run | Result |
|---|---|
| `pytest tests/intent/ -q` | **111/111 PASS** in 3.28s |
| `pytest tests/contracts/test_protected_invariant_schema.py tests/contracts/test_required_regressions_router.py tests/governance/test_schema_self_validation.py tests/test_schema_version_const.py -q` | 36/36 PASS |
| `pytest tests/ -q --ignore=tests/contracts/test_consistency_aggregate.py --ignore=tests/test_rebuild_release_manifest.py --ignore=tests/test_rc_release_integrity.py` | **1496 passed / 2 skipped** in 67.53s (was 1398 before c3; net +98) |
| `python3 scripts/governance/lint_layer_separation.py` | clean — 59 roots / 0 violations + runtime tree clean |
| 3 known pre-existing failures (excluded above; managed-python rpds env) | tests/contracts/test_consistency_aggregate × 2 — unchanged from before B6 |
| Expected-drift failures resolved by c4 manifest sync | tests/test_rebuild_release_manifest::test_live_repo_check_is_clean + tests/test_rc_release_integrity::test_release_manifest_round_trip |

### Retraction note: `v4.91-release` tag (commit `dd9863f`)

The original `v4.91-release` annotated tag (created 2026-05-26, commit `dd9863f`) was deleted via `git tag -d` on 2026-05-28 as part of the freeze reopen. The two commits forming that ceremony — `dd9863f` (P10 REL ceremony, cut Release/ + zip) and `cfe6d6b` (P10 memory log, MEMORY.md v4.91 終態) — remain in git history as P10-rehearsal evidence. The retracted Release tree (`AI_Game_Dev_OS_v4.91_Release/` + zip) was deleted from the working tree (zip is gitignored; tree deletion was committed in `ba9a888`).

The new RC2 + REL2 ceremony (P9' + P10') will create new commits on top of the M-F chain. The 15 prior tags (M-A, M-B*, M-C, M-D, M-E*, Addendum-A/B/C, RC1) were preserved in place; only `v4.91-release` was removed.

### Next phase

M-F closes here. After M-F closure the freeze roadmap originally pointed at P9' RC2 → P10' REL. EP subsequently authorised additional feature batches (M-G, M-H) before re-cutting the release. The current absolute roadmap is recorded in §"v4.91 freeze roadmap (current absolute view)" near the end of this document — refer to it as the single source of truth; this per-milestone "Next phase" entry is preserved as historical context only.


---

## v4.91 Milestone G — Creative Cluster Activation + 2D Character Animation Pack (Batch 7, CLOSED 2026-05-28)

> **Status**: CLOSED 2026-05-28 — c0 `0871d23` (capability_promotion proposal evo_2026_002), c1 `e3a3420` (creative_cluster activation + ap_2026_006 ledger + validator exemption gate), c2 `faa762d` (8 SKILL.md migrated to skills/ tree), c3 `3089012` (resources → docs/28 + schemas/animation + scripts/animation; chiren sanitised), c4 `774f221` (inv_013 + Layer 1 roots +4 + tests/animation × 7 / 101 tests), c5 (this commit, RELEASE_NOTES + CHANGELOG + MANIFEST_HISTORY + manifest sync), c6 (tag-only). Annotated tag `v4.91-M-G` will be applied at the c5 release commit.
>
> **Trigger**: A second adopting project (independent from the v4.91 baseline-fork project) ran a 2D character animation pipeline through the AI Game Dev OS framework. The pipeline distilled into 8 generic skills + supporting references / templates / examples / contracts / schemas / scripts. EP review on 2026-05-28 (immediately following M-F closure) recognised the pipeline as a generic cross-project pattern (`card_battle_2d_actor_pipeline`) and authorised promotion into OS Core. The first creative_cluster pack thus landed; the v4.90-deferred `creative_cluster` (`PACK_CLUSTER_TAXONOMY.md` § 6) is now ACTIVE.
>
> **Theme**: 2D character animation pipeline — gated production from a full-body actor image through layer split, rigging prep, combat timing spec, Godot implementation plan, and animation QA. The pack does NOT promise auto-rigging from one image; it turns a fragile one-shot AI task into a 7-gate human-in-the-loop pipeline. Charter anti-patterns #2 / #6 / #7 / #11 enforced jointly via inv_013.

### EP decision matrix (locked 2026-05-28)

| Q | Decision | Rationale |
|---|---|---|
| Q5 | **Full migration into OS-grade locations** (skills/_generic_core/animation × 6 + skills/_generic_core/qa/animation-qa-auditor + skills/_engine_specific/godot/godot-2d-animation-implementer + docs/28 + schemas/animation + scripts/animation) | A "drop-in single subtree" approach would have fought the v4.89 SKILL/dir convention; full splay aligns with how the existing 28+3 SKILL.md are organised. |
| Q6 | **Cluster slug `2d_character_animation`** for the docs subtree, but the pack itself uses the v4.90-reserved cluster `creative_cluster` | The v4.90 deferred plan reserved `creative_cluster` for "art / narrative / audio specialists"; the new pack is the first concrete entry. The docs subtree gets a more specific name to leave room for future creative_cluster sub-domains (narrative, audio). |
| Q7 | **NEW `skills/_generic_core/animation/` category** with 6 SKILL.md | Existing categories (art / design / qa / etc.) did not cleanly absorb the 6 skills; introducing a new category was less disruptive than fragmenting them across 3 existing categories. |
| Q8 | **No retroactive cleanup of pre-existing project literals** in `skills/README.md` | A v4.89 history line cites the source project name; touching it would expand scope and risk byte-lock implications. Deferred to v4.92 if it matters. |
| Q9 | **A — activate creative_cluster** rather than invent a new cluster | The 8 skills' functional decomposition fits {design, implementation, validation} role primitives; no new cluster needed beyond the v4.90 deferred placeholder. |
| Q10 | **A — no new role primitive** | Adding `creative` would describe a *who* (specialist) not a *what function*; existing primitives suffice. |
| Q11 | **A — capability_promotion proposal** (evo_2026_002) gates the cross-cluster role aliasing | Per `PACK_CLUSTER_TAXONOMY.md` § Per-cluster invariants third bullet, this is the documented activation path. The proposal's closed-form exemption registry pattern is reusable for tools_cluster activation in v4.92+. |

### Commits (6; c5 = this commit)

```
0871d23  c0  feat(v4.91 M-G c0): capability_promotion proposal evo_2026_002 — creative_cluster activation
e3a3420  c1  feat(v4.91 M-G c1): activate creative_cluster — ap_2026_006 ledger + validator exemption gate
faa762d  c2  feat(v4.91 M-G c2): 8 SKILL.md migrated into _generic_core/animation + qa + _engine_specific/godot
3089012  c3  feat(v4.91 M-G c3): pack resources → docs/28 + schemas/animation + scripts/animation; chiren sanitised
774f221  c4  feat(v4.91 M-G c4): inv_013 + Layer 1 roots +4 + tests/animation × 7 (101 tests)
<c5>     c5  docs(v4.91 M-G c5): RELEASE_NOTES + CHANGELOG + MANIFEST_HISTORY + manifest sync (this commit)
<c6>     c6  chore(v4.91 M-G c6): annotated tag v4.91-M-G + memory log
```

### Surface added

| Path | Layer | Role |
|---|---|---|
| `proposals/evo_2026_002_creative_cluster_role_aliasing.md` (NEW) | L1 source | Capability promotion authorising creative_cluster activation via cross-cluster role aliasing |
| `agent_packs/ap_2026_006_creative_cluster.md` (NEW) | L1 source | First creative_cluster seed pack; references[] cites evo_2026_002 (mandatory exemption marker) |
| `scripts/agent_library/validate_agent_pack.py` (MOD) | L1 source | NEW `_CLUSTER_ALIASING_EXEMPTIONS` closed-form registry; honours creative_cluster ↔ evo_2026_002 gate |
| `agent_packs/README.md` (MOD) | L1 source | Cluster taxonomy: 5 active → 6 active; inventory: + ap_2026_006 row |
| `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` (MOD) | L1 source | § 6 creative_cluster: DEFERRED → ACTIVE; activation gate explanation; coverage matrix +ap_2026_006 row |
| `skills/_generic_core/animation/{2d-character-motion-designer,sprite-sheet-planner,character-layer-splitter,rigging-prep-handoff,combat-animation-spec,asset-prompt-animation-helper}/SKILL.md` (NEW × 6) | L1 source | NEW `animation` category under _generic_core/ |
| `skills/_generic_core/qa/animation-qa-auditor/SKILL.md` (NEW) | L1 source | Added under existing qa/ category |
| `skills/_engine_specific/godot/godot-2d-animation-implementer/SKILL.md` (NEW) | L1 source | Added under existing godot/ category |
| `skills/README.md` (MOD) | L1 source | + animation row; godot/ count 3 → 4; Scale 28 → 35 SKILL.md |
| `docs/28_2d_character_animation/{README,AGENT_PACK_OVERVIEW,AI_LIMITATIONS_AND_HUMAN_GATE,CROSS_PROJECT_PROMOTION_LESSONS}.md` (NEW × 4) | L1 source | Pack metadata + 7-gate enumeration + 5-stage L2→L1 abstraction methodology |
| `docs/28_2d_character_animation/provenance.yaml` (NEW) | L1 source | Provenance metadata; project name kept in workspace MEMORY.md |
| `docs/28_2d_character_animation/{references/×8, templates/×7, examples/×2, contracts/×4}` (NEW × 21) | L1 source | Pack reference / template / example / governance contract docs |
| `docs/28_2d_character_animation/GENERATED_INDEX.md` (auto-generated) | L1 source | Read-only output from scripts/animation/make_animation_manifest.py |
| `schemas/animation/{layer_split,combat_animation_spec,qa_report}.schema.json` (NEW × 3) | L1 source | Hardened: schema_version 1.0.0 const + ap=false + draft-07 + canonical $id host + closed enums (4/4/6/3/10) + patterns |
| `scripts/animation/{__init__,validate_skill_pack,make_animation_manifest}.py` (NEW × 3) | L1 source | Read-only validator (8 skills + ledger + provenance + gate-section requirement) + manifest generator (13-section index) |
| `tests/animation/{test_pack_schemas,test_skill_files_present,test_pack_ledger_consistency,test_no_auto_rig_promise,test_no_project_literals,test_inv_013_invariant,test_validate_skill_pack_script}.py` (NEW × 7) | L1 test | 101 tests verifying schema shape / 8-skill structure / pack ledger consistency / inv_013 compile-time guards / Charter #2 no-literal / inv_013 invariant + validator script smoke |
| `runtime/protected_contracts/protected_regression_matrix.yaml` (MOD) | L1 source | Header invariant count: 12 → 13; inv_002 trigger_files +9 paths; inv_002 must_preserve "59 → 63 roots"; NEW inv_013_animation_pack_no_auto_rig_promise (9 trigger / 11 must_preserve / 2 required_validation) |
| `scripts/governance/lint_layer_separation.py` (MOD) | L1 source | LAYER_1_ROOTS += [docs/28_2d_character_animation, schemas/animation, scripts/animation, tests/animation] (4 new roots) |
| `tests/contracts/{test_protected_invariant_schema,test_required_regressions_router}.py` (MOD × 2) | L1 test | expected count 12 → 13 |

### Charter alignment (5 anti-patterns enforced post-M-G)

Anti-pattern total stays at 15 (no new pattern added; M-G adds an enforcement layer for existing patterns).

| # | Anti-pattern | M-G enforcement layer |
|---|---|---|
| 2 | project names in Core | All canonical surfaces clean (lint 63 roots / 0 violations); 3 documented meta-reference exceptions use runtime-assembly per evo_2026_001 §Authoring discipline (`scripts/animation/validate_skill_pack.py`, `tests/animation/test_pack_ledger_consistency.py`, `tests/animation/test_no_project_literals.py`); pack ledger + provenance.yaml verified literal-free by parametrised tests |
| 6 | evidence-threshold auto-promote | 3 schemas all `schema_version` const "1.0.0" + `additionalProperties: false`; closed enums (qa_report status 4 / severity 4 / layer_split target_method 6 / split_depth 3 / combat_spec phase + event kind); validator + manifest generator NEVER mutate canonical pack assets |
| 7 | escape hatches | inv_013 compile-time guard: 11 forbidden argparse flags refused in `scripts/animation/`; validator's `_CLUSTER_ALIASING_EXEMPTIONS` registry has no `--allow-deferred` / `--skip-exemption` / `--override-cluster` flag |
| 11 | preflight as gate-pass | qa_report.status enum closed at 4 advisory verdicts (pass / pass_with_notes / rework / reject); pack landing != gameplay sign-off; AI_LIMITATIONS_AND_HUMAN_GATE.md enumerates 7 mandatory human gates |
| 13 | host_profile auto multi-agent default | Not applicable at SKILL.md guidance layer; existing inv_002 + inv_012 patterns cover validator-layer enforcement |

### Maintainer evidence record (laptop, 2026-05-28)

| Run | Result |
|---|---|
| `pytest tests/animation/ -q` | **101/101 PASS** in 0.12s |
| `pytest tests/agent_library/ -q` | 51/51 PASS in 1.14s (was 49 + 2 new exemption tests for evo_2026_002) |
| `pytest tests/ -q --ignore=tests/contracts/test_consistency_aggregate.py --ignore=tests/test_rebuild_release_manifest.py --ignore=tests/test_rc_release_integrity.py` | **1599 passed / 2 skipped** in 70.17s (was 1496 before M-G; net +103) |
| `python3 scripts/governance/lint_layer_separation.py` | clean — **63 roots / 0 violations** + runtime tree clean (was 59 before M-G c4) |
| `python3 scripts/animation/validate_skill_pack.py` | [OK] creative_cluster pack structure validated (8 skills + ledger + provenance) |
| `python3 scripts/agent_library/validate_agent_pack.py --dir agent_packs/` | 6/6 packs PASS / 0 violations |
| 3 known pre-existing failures (excluded above; managed-python rpds env) | tests/contracts/test_consistency_aggregate × 2 — unchanged from before M-G |
| Expected-drift failures resolved by c5 manifest sync | tests/test_rebuild_release_manifest::test_live_repo_check_is_clean + tests/test_rc_release_integrity::test_release_manifest_round_trip |

### Provenance

The 8 skills + supporting resources were distilled from a second adopting project (independent from the v4.91 baseline-fork project). Per Charter #2 + the Layer 1 / Layer 2 separation principle (`evo_2026_001`), the source project name appears nowhere in canonical surfaces; the methodology of the L2 → L1 abstraction is captured in `docs/28_2d_character_animation/CROSS_PROJECT_PROMOTION_LESSONS.md` (5-stage extraction process + 4 pitfalls + closed-form exemption template). The specific project name lives in workspace `MEMORY.md` only.

### Next phase

M-G closes here. After M-G closure the freeze roadmap originally pointed at P9' RC2 → P10' REL. EP subsequently authorised an additional feature batch (M-H) before re-cutting the release. The current absolute roadmap is recorded in §"v4.91 freeze roadmap (current absolute view)" near the end of this document — refer to it as the single source of truth; this per-milestone "Next phase" entry is preserved as historical context only.


---

## v4.91 Milestone H — Creative Cluster UI/UX Sub-Domain Extension (Batch 8, CLOSED 2026-05-29)

> **Status**: CLOSED 2026-05-29 — c0 `02f6fd5` (capability_promotion proposal evo_2026_003 + exemption registry widened from single proposal id to tuple), c1 `43d0728` (ap_2026_006 widened skills.required 8→16 + references[] adds evo_2026_003 + PACK_CLUSTER_TAXONOMY § 6 sub-domain table), c2 `a396598` (8 SKILL.md migrated to skills/_generic_core/game_ui + qa + _engine_specific/godot), c3 `63a94b2` (resources → docs/29 + schemas/uiux + scripts/uiux; less_is_more sanitised), c4 `d450158` (inv_014 + Layer 1 roots +4 + tests/uiux × 7 / 120 tests), c5 (this commit, RELEASE_NOTES + CHANGELOG + MANIFEST_HISTORY + manifest sync), c6 (tag-only). Annotated tag `v4.91-M-H` will be applied at the c5 release commit.
>
> **Trigger**: A second sub-domain candidate landed in EP's queue ~16 hours after M-G closure: an 8-skill game UI/UX pack distilled from the same independent adopting project that yielded the M-G animation pipeline. EP review on 2026-05-29 (the morning after M-G) recognised the pack as a generic cross-project pattern (`card_battle_ui_ux_pipeline`) and authorised promotion into the SAME creative_cluster pack — accumulating sub-domains under one ledger rather than fragmenting into ap_2026_007. The M-G open question "if/when a second creative_cluster pack arrives, can it inherit by reference?" is answered: **each new sub-domain emits its own capability_promotion proposal; the validator's exemption registry widens its allow-list; the same single pack accumulates skills.required[] and references[]**.
>
> **Theme**: game UI/UX pipeline — gated production from GDD/combat-loop through wireframe, battle HUD, card prefab, design tokens, Figma handoff, Godot UI implementation plan, and UX audit. The sub-domain does NOT bake runtime text into generated images; it does NOT ship UI specs without acceptance criteria. Charter anti-patterns #2 / #6 / #7 / #11 enforced jointly via inv_014 dual gate (forbid_baked_runtime_text const true + acceptance minItems=1).

### EP decision matrix (locked 2026-05-28T17:49Z)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **B — independent proposal evo_2026_003** (not amend evo_2026_002) | Proposal documents are append-only; conflating two ratification events would break audit-trail granularity. Validator allow-list widening expresses "either id authorises" cleanly. |
| Q2 | **A — NEW `skills/_generic_core/game_ui/` category** | Existing `skills/_generic_core/uiux/` covers abstract software-UI flow primitives (6 skills); game-domain UI primitives (battle HUDs / card prefabs / runtime-safe text zones / mobile safe areas) deserve a parallel category. Co-locating would dilute both. |
| Q3 | **A — canonical $id host on day 1** | Schemas ship with `https://ai-dev-os.local/v4.91/schemas/uiux/<filename>` directly; no follow-up audit-normalisation commit needed (the M-G post-Phase-3 host normalisation paid off). |
| Q4 | **C — dual gate** for inv_014 | First gate: no baked runtime text (forbid_baked_text const true on prompt + card schemas). Second gate: spec-required acceptance (acceptance minItems=1 on screen + card schemas; states minItems=3 for state coverage). Both gates address sub-domain-specific failure modes. |
| Q5 | **B — preserve methodology cross-ref** | CROSS_PROJECT_PROMOTION_LESSONS.md keeps the M-G sibling reference pattern; only the `less_is_more_battle_hud_spec_example.md` filename + body title gets sanitised to `screen_alpha_battle_hud_spec_example.md`. |
| Q6 | **A — godot-ui-implementation-planner joins existing godot/** | `_engine_specific/godot/` grows 4 → 5 SKILL.md alongside M-G's `godot-2d-animation-implementer`; engine swap stays a single-directory operation in v4.92. |
| Q7 | **A — sequencing M-H → P9' RC2 → P10' REL** | Same node as M-G. M-H c6 closes the milestone before the closure gate replay starts. |

### Commits (6; c5 = this commit)

```
02f6fd5  c0  feat(v4.91 M-H c0): proposal evo_2026_003 + exemption registry widened
43d0728  c1  feat(v4.91 M-H c1): activate creative_cluster UI/UX sub-domain in ap_2026_006
a396598  c2  feat(v4.91 M-H c2): migrate 8 game UI/UX SKILL.md to OS-grade locations
63a94b2  c3  feat(v4.91 M-H c3): pack resources for game UI/UX sub-domain (38 NEW)
d450158  c4  feat(v4.91 M-H c4): inv_014 + LAYER_1_ROOTS 63->67 + 120 tests/uiux
<c5>     c5  docs(v4.91 M-H c5): RELEASE_NOTES + CHANGELOG + MANIFEST_HISTORY + manifest sync (this commit)
<c6>     c6  chore(v4.91 M-H c6): annotated tag v4.91-M-H + memory log
```

### Surface added

| Path | Layer | Role |
|---|---|---|
| `proposals/evo_2026_003_creative_cluster_uiux_subdomain.md` (NEW) | L1 source | Capability promotion authorising creative_cluster UI/UX sub-domain extension |
| `agent_packs/ap_2026_006_creative_cluster.md` (MOD) | L1 source | pack_version 0.1.0-beta → **0.2.0-beta**; skills.required 8 → **16**; references[] gains evo_2026_003 + docs/29/README; body rewritten with two-sub-domain structure + 16-row functional decomposition table |
| `scripts/agent_library/validate_agent_pack.py` (MOD, c0) | L1 source | `_CLUSTER_ALIASING_EXEMPTIONS` registry shape: `dict[str, tuple[str, set]]` → `dict[str, tuple[tuple[str, ...], set]]`; activation logic switches from `id in refs` to `any(pid in refs for pid in tuple)`; backward-compatible at the registry-data layer |
| `agent_packs/README.md` (MOD) | L1 source | Cluster taxonomy table cites evo_2026_002 + evo_2026_003 pair; Current inventory table gains Skills column (ap_2026_006 = 16) |
| `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` (MOD) | L1 source | § 6 widened title; NEW sub-domain table (animation/M-G/inv_013 + game UI/UX/M-H/inv_014); Coverage matrix gains sub-domains column; Per-cluster invariants third bullet annotated; Cross-references gains evo_2026_003 |
| `skills/_generic_core/game_ui/{game-ui-wireframe-generator,battle-hud-designer,card-ui-prefab-spec,game-design-system-builder,figma-handoff-spec,ui-asset-prompt-engineer}/SKILL.md` (NEW × 6) | L1 source | NEW `game_ui` category under _generic_core/ |
| `skills/_generic_core/qa/game-ui-ux-auditor/SKILL.md` (NEW) | L1 source | Added under existing qa/ category alongside animation-qa-auditor |
| `skills/_engine_specific/godot/godot-ui-implementation-planner/SKILL.md` (NEW) | L1 source | Added under existing godot/ category; godot/ count 4 → 5 SKILL.md |
| `skills/README.md` (MOD) | L1 source | + game_ui row + godot/ count 4 → 5; Scale 35 → 43 SKILL.md combined; Note paragraph extended with M-H c2 sentence |
| `docs/29_game_ui_ux/{README,AGENT_PACK_OVERVIEW,AI_LIMITATIONS_AND_HUMAN_GATE,CROSS_PROJECT_PROMOTION_LESSONS}.md` (NEW × 4) | L1 source | Pack metadata + 9-gate enumeration + M-H delta-vs-M-G methodology document |
| `docs/29_game_ui_ux/provenance.yaml` (NEW) | L1 source | Provenance metadata; pattern_family `card_battle_ui_ux_pipeline`; sub_domain `game_ui_ux`; cross-ref to M-G sibling |
| `docs/29_game_ui_ux/{references/×8, templates/×8, examples/×4, contracts/×4}` (NEW × 24) | L1 source | Pack reference / template / example / governance contract docs (1 example renamed: less_is_more_battle_hud_spec_example.md → screen_alpha_battle_hud_spec_example.md; body title + protagonist relabel) |
| `docs/29_game_ui_ux/GENERATED_INDEX.md` (auto-generated) | L1 source | Read-only output from scripts/uiux/make_uiux_manifest.py |
| `schemas/uiux/{ui_screen_spec,card_prefab_spec,ui_design_tokens,ui_asset_prompt}.schema.json` (NEW × 4) | L1 source | Hardened: schema_version 1.0.0 const + ap=false + draft-07 + canonical $id host (`ai-dev-os.local/v4.91/schemas/uiux/<filename>`) + closed enums (screen_role 12 / target_platforms 6 / asset_type 12 / background 6 / aspect_ratio 6 / states 11 / rarity_variants 6) + `forbid_baked_text` const true (inv_014 first gate) + acceptance minItems=1 (inv_014 second gate) + states minItems=3 |
| `scripts/uiux/{__init__,validate_uiux_pack,make_uiux_manifest}.py` (NEW × 3) | L1 source | Read-only validator (8 skills + ledger + provenance + multi-form gate-section requirement to match the source pack's varied conventions) + manifest generator (13-section index) |
| `tests/uiux/{test_pack_schemas,test_skill_files_present,test_pack_ledger_consistency,test_no_baked_runtime_text,test_no_project_literals,test_inv_014_invariant,test_validate_uiux_pack_script}.py` (NEW × 7) | L1 test | **120 tests** verifying schema shape (30) / 8-skill structure (40) / pack ledger consistency (10) / inv_014 dual-gate compile-time guards (29) / Charter #2 no-literal (2) / inv_014 invariant + inv_002 expansion (6) / validator script smoke (3) |
| `runtime/protected_contracts/protected_regression_matrix.yaml` (MOD) | L1 source | Header invariant count: 13 → 14; inv_002 trigger_files +9 paths; inv_002 must_preserve "63 → 67 roots"; NEW inv_014_uiux_pack_no_baked_runtime_text_and_required_acceptance (9 trigger / 16 must_preserve / 2 required_validation) |
| `scripts/governance/lint_layer_separation.py` (MOD) | L1 source | LAYER_1_ROOTS += [docs/29_game_ui_ux, schemas/uiux, scripts/uiux, tests/uiux] (4 new roots) |
| `tests/contracts/{test_protected_invariant_schema,test_required_regressions_router}.py` (MOD × 2) | L1 test | expected count 13 → 14 |
| `tests/animation/test_inv_013_invariant.py` (MOD) | L1 test | M-G hardcoded `==13` and `'63 roots'` generalised to `>=13` and `('63 roots' OR '67 roots')` so the M-G test stays green under M-H widening (and future M-I+ widening); pattern reusable for downstream invariant additions |

### Charter alignment (4 anti-patterns enforced post-M-H)

Anti-pattern total stays at 15 (no new pattern added; M-H adds an enforcement layer for existing patterns, parallel to M-G's inv_013).

| # | Anti-pattern | M-H enforcement layer |
|---|---|---|
| 2 | project names in Core | All canonical surfaces clean (lint **67 roots / 0 violations**); 5 documented meta-reference exceptions use runtime-assembly per evo_2026_001 §Authoring discipline (`scripts/uiux/validate_uiux_pack.py`, `tests/uiux/test_pack_ledger_consistency.py`, `tests/uiux/test_no_baked_runtime_text.py`, `tests/uiux/test_no_project_literals.py`, `proposals/evo_2026_003` for the methodology meta-ref of the c3 rename); pack ledger + provenance.yaml verified literal-free by parametrised tests |
| 6 | evidence-threshold auto-promote | 4 schemas all `schema_version` const "1.0.0" + `additionalProperties: false`; **forbid_baked_runtime_text + forbid_baked_text both const true** (inv_014 FIRST GATE — no semantic "mostly text-free" shortcut); closed enums (screen_role 12 / target_platforms 6 / asset_type 12 / background 6 / aspect_ratio 6 / states 11 / rarity 6); validator + manifest generator NEVER mutate canonical pack assets |
| 7 | escape hatches | inv_014 compile-time guard: 13 forbidden argparse flags refused in `scripts/uiux/` (--apply / --auto-design / --bake-text / --auto-prompt / --auto-confirm / --override / --override-freeze / --skip-review / --skip-acceptance / --bypass / --allow-extra / --force / --auto-apply); 10 forbidden destructive runtime calls (shutil.rmtree / os.system / subprocess.* etc.); validator's widened `_CLUSTER_ALIASING_EXEMPTIONS` registry has no `--allow-deferred` / `--skip-exemption` / `--override-cluster` flag |
| 11 | preflight as gate-pass | inv_014 SECOND GATE — **acceptance minItems=1** required at schema layer (Charter #11: a spec without acceptance criteria is a mood board, not a contract); states minItems=3 for state-coverage; `game-ui-ux-auditor` advisory boundary preserved in `ui_review_gate_contract.md` ("audit ≠ ship/no-ship decision"); AI_LIMITATIONS_AND_HUMAN_GATE.md enumerates 9 mandatory human gates |

### Maintainer evidence record (laptop, 2026-05-29)

| Run | Result |
|---|---|
| `pytest tests/uiux/ -q` | **120/120 PASS** in 0.13s |
| `pytest tests/animation/ tests/uiux/ tests/contracts/ -q` | 237 passed + 2 expected pre-existing test_consistency_aggregate failures |
| `pytest tests/ -q --ignore=tests/contracts/test_consistency_aggregate.py --ignore=tests/test_rebuild_release_manifest.py --ignore=tests/test_rc_release_integrity.py` | **1729 passed / 2 skipped** in 71.51s (was 1609 post-M-G c5 baseline; net **+120**) |
| `python3 scripts/governance/lint_layer_separation.py` | clean — **67 roots / 0 violations** + runtime tree clean (was 63 post-M-G) |
| `python3 scripts/uiux/validate_uiux_pack.py` | [OK] creative_cluster game UI/UX sub-domain validated (8 skills + ledger + provenance) |
| `python3 scripts/agent_library/validate_agent_pack.py --dir agent_packs/` | 6/6 packs PASS / 0 violations (ap_2026_006 references both evo_2026_002 and evo_2026_003) |
| `python3 scripts/uiux/make_uiux_manifest.py` | [OK] docs/29_game_ui_ux/GENERATED_INDEX.md written |
| 3 known pre-existing failures (excluded above; managed-python rpds env) | tests/contracts/test_consistency_aggregate × 2 — unchanged from before M-H |
| Expected-drift failures resolved by c5 manifest sync | tests/test_rebuild_release_manifest::test_live_repo_check_is_clean + tests/test_rc_release_integrity::test_release_manifest_round_trip |

### Provenance

The 8 game UI/UX skills + supporting resources were distilled from the same adopting project that yielded the M-G animation sub-domain. Per Charter #2 + the Layer 1 / Layer 2 separation principle (`evo_2026_001`), the source project name appears nowhere in canonical surfaces; the methodology of the L2 → L1 abstraction is captured in `docs/29_game_ui_ux/CROSS_PROJECT_PROMOTION_LESSONS.md` (M-H deltas vs M-G base — 6 lessons covering multi-sub-domain accumulation, schema host normalisation, generic-core vs engine-specific split survival, game_ui vs uiux naming rationale, pack-version semver minor on widening, and Charter inv_013/inv_014 reusable pattern). The specific project name lives in workspace `MEMORY.md` only.

### Next phase

M-H closes here. The freeze roadmap continues with **P9' — D v4.91-RC2 closure gate** (re-run RC criteria evidence record now that B6 + B7 + B8 have landed; tag `v4.91-RC2`). With M-H done the v4.91 tag ladder stands at **18 / 20** absolute (final 20-tag plan = M-A + Addendum-A + 4 M-B sub + M-B + Addendum-B + Addendum-C + M-C + M-D + 2 M-E sub + M-E + RC1 + M-F + M-G + M-H + **RC2** + **release**). See §"v4.91 freeze roadmap (current absolute view)" near the end of this document for the absolute ladder accounting.


---

## v4.91 P9 — D v4.91-RC closure gate (CLOSED 2026-05-26, tag v4.91-RC1 preserved; superseded by P9'/RC2 after M-F + M-G — see retraction notes above)

> **Status**: CLOSED 2026-05-26 — c1 `37208db` (dispatcher v4.91 baseline override + 7 tests), c2 (this commit, manifest sync + RELEASE_NOTES + tag). Annotated tag `v4.91-RC1` applied at the c2 release commit.
>
> **Trigger**: P9 is the v4.91 release-candidate closure gate. Per handoff §3.5, this phase produces the full-gate 13/13 evidence record that gates the v4.91-RC1 tag and unblocks the P10 release ceremony. The v4.90 frozen RC3 gate hardcodes `EXPECTED_PYTEST=953` + `EXPECTED_LAYER1_ROOTS=33` — numbers that v4.91 has legitimately superseded across F-T-01..M-E (now 1401 / 55). P9 lands a **dispatcher-layer baseline override** that wraps RC3 unmodified and lifts C1/C2 fails to PASS when the actual count matches the v4.91 expectation.
>
> **Theme**: RC3 stays frozen as the v4.90 reference (Charter §6.2 + inv_001 byte-lock semantics); the dispatcher (`run_release_closure_gate.py`) gains a purely-additive override layer at the boundary so v4.91 produces 13/13 PASS evidence at its own baseline. The override is structurally narrow: matches ONLY the exact v4.91 expected pair; any other fail flows through unchanged. Charter anti-patterns #4 (extend, don't replace) + #11 (recording != closure-gate pass) jointly enforced.

### EP decision matrix (locked 2026-05-26)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **2-commit ladder** (c1 dispatcher override + tests / c2 manifest sync + tag) | Mirrors P7 doc-only ladder shape (RC closure is similarly minimal: no new schemas / no new fast-gate items / no new invariants — only the override surface). |
| Q2 | **Override at the dispatcher boundary, NOT inside RC3** | Charter §6.2 — RC3 is the frozen v4.90 evidence contract; modifying its EXPECTED_* constants would break the byte-lock invariant. The override is purely additive at the dispatcher boundary. |
| Q3 | **Override applies ONLY to --format=json** (machine evidence path) | Text mode is human-readable only and not used as machine evidence; preserving its verbatim flow keeps the RC3 trace auditable. |
| Q4 | **Override matches ONLY exact v4.91 expected pair** | Drift detection: any non-v4.91 count flows through as fail; the override never silently absorbs a regression. |
| Q5 | **`v4_91_overrides` field added to JSON envelope** | Audit trail — consumers can see which checks were lifted. |
| Q6 | **Annotated tag v4.91-RC1** at c2 | MEMORY contract #12 — release-candidate tag policy. |

### Commits (2; all landed)

```
37208db  feat(v4.91 P9 c1): dispatcher v4.91 baseline override layer (1 NEW + 1 MOD)
<c2>     chore(v4.91 P9 c2): manifest sync + RELEASE_NOTES P9 closure + tag v4.91-RC1
```

### Surface added (so far)

| Path | Layer | Role |
|---|---|---|
| `scripts/governance/run_release_closure_gate.py` MOD | L1 governance | `run_full()` rewritten with override semantics: capture RC3 JSON, regex-match C1/C2 fails against v4.91 expected pair, lift to PASS with "RC3 v4.90 baseline superseded" suffix, recompute overall, emit envelope with `v4_91_overrides` metadata. New constants: `EXPECTED_PYTEST_V4_91=1401`, `EXPECTED_PYTEST_SKIPPED_V4_91=2`, `EXPECTED_LAYER1_ROOTS_V4_91=55`. |
| `tests/governance/test_v4_91_baseline_override.py` | L1 test | 7 tests pinning override semantics: constants reflect v4.91-RC1 baseline; C1 fail with v4.91 count lifts; C2 fail with v4.91 roots lifts; non-v4.91 count flows through; full-match recomputes overall=0; non-overridable fail keeps overall=1; ok=None (skipped) treated as not-failing. |

### Charter alignment

| # | Anti-pattern | Status |
|---|---|---|
| §6.2 | RC3 stays frozen as v4.90 reference | ✅ RC3 file (`run_v490_rc3_closure_gate.py`) unmodified by this batch. Override is purely additive at the dispatcher boundary. |
| 4 | Extend, don't replace | ✅ The override is additive: original RC3 semantics are preserved verbatim for any check outside C1/C2 and for any non-v4.91-expected count. |
| 11 | Recording != closure-gate pass | ✅ Override surfaces baseline drift as PASS only when actual exactly matches the v4.91 expectation; any other fail flows through. The override never silently absorbs a regression. |

### Maintainer evidence record (laptop, 2026-05-26)

| Run | Result |
|---|---|
| `python3 -m pytest tests/governance/test_v4_91_baseline_override.py -q` (after c1) | **7 passed** in 0.02 s |
| `python3 -m pytest tests/ -q` (after c2 manifest sync) | **1401 passed** + 2 skipped in 69.26 s (1394 baseline + 7 override tests) |
| `python3 scripts/governance/run_release_closure_gate.py --profile full --format json` (after c2) | **overall=0**; **PASS=13/13** in ~72 s; **`v4_91_overrides=['C1', 'C2']`** — C1 lifted via `got 1401/2` baseline match, C2 lifted via `got 55 roots / 0 violations` baseline match |
| `python3 scripts/governance/run_release_closure_gate.py --profile fast --format json` (after c2) | **overall=0**; **PASS=23/23** in ~8 s |
| `python3 scripts/governance/lint_layer_separation.py` (after c2) | clean — **55 roots** / 0 violations + runtime tree clean |
| `python3 scripts/rebuild_release_manifest.py --check` (after c2) | **exit 0 — clean ✓ no drift** |
| `python3 scripts/governance/verify_release_clean_tree.py` (after c2) | clean ✓ |

### Manifest sync (c2)

- `manifest_schema_notes`: **35 → 36** (+1 entry: P9 RC closure details with override constants and Charter §6.2 alignment).
- `required_manifest_files`: **1065 → 1066** (+1: `tests/governance/test_v4_91_baseline_override.py` NEW; the dispatcher MOD surfaces as sha refresh, not a new entry).
- `manifest_schema_version` 2.3 preserved verbatim; no shape change.
- Fast-gate item count UNCHANGED (still 23). No F21 added.
- Protected invariant count UNCHANGED (still 11). No inv_012 added.

### Full gate evidence band (MEMORY contract #13)

This is the **first** v4.91 full-gate run that produces 13/13 PASS — the exact evidence band MEMORY contract #13 requires for any "freeze evidence" claim. Prior v4.91 closure runs (M-A through M-E) intentionally avoided full gate: they were sub-batch closes, not RC-grade artefacts.

The `v4_91_overrides` field in the JSON envelope provides the audit trail proving WHICH checks were lifted from RC3's v4.90 baseline. A reviewer reading the JSON can verify:

- `overrides: ['C1', 'C2']` means BOTH baseline-drift checks were lifted at the dispatcher.
- Each lifted check's summary contains "RC3 v4.90 baseline superseded by v4.91 expectation".
- Any check NOT in `v4_91_overrides` was either PASS in RC3 directly (the case for C3..C13 here) or was a non-baseline-drift fail (would surface as overall=1).

### What P9 does NOT include (intentional non-features)

- **No modification of the frozen RC3 gate.** The RC3 file (`run_v490_rc3_closure_gate.py`) keeps its v4.90 baseline constants verbatim. Charter §6.2.
- **No new fast-gate item.** No F21 — the RC closure surface is a one-shot run, not a recurring smoke check.
- **No new protected invariant.** The override behaviour is enforced by the test suite, not by the matrix (the matrix is the wrong layer for "the dispatcher honours the v4.91 baseline").
- **No release-zip work.** Per MEMORY contract #16; only P10 ceremony cuts the release.
- **No non-additive RC3 patch.** Adding override constants to RC3 itself would have re-baselined the v4.90 evidence contract, which is what Charter §6.2 forbids.

### Next phase

P9 closes here.

> **SUPERSEDED 2026-05-28+**: The "P10 — REL ceremony" originally planned to follow P9 / RC1 was rehearsed on 2026-05-26 (commit `dd9863f` + memory log `cfe6d6b`) and tagged `v4.91-release`. EP retracted that tag on 2026-05-28 after authorising further feature batches (M-F → M-G → M-H). The retracted P10 rehearsal section that originally followed this paragraph has been collapsed (see `<!-- SUPERSEDED P10 REHEARSAL -->` block below); rehearsal commits remain in git history as evidence. The current absolute roadmap (RC2 + REL with the new feature surface) is recorded in §"v4.91 freeze roadmap (current absolute view)" near the end of this document.


---

## v4.91 Release — REL Ceremony (REHEARSAL 2026-05-26, tag v4.91-release RETRACTED 2026-05-28)

> **SUPERSEDED**: This section documents the original P10 rehearsal that ran on 2026-05-26 (commits `dd9863f` cut + zip; `cfe6d6b` memory log; tag `v4.91-release` then deleted on 2026-05-28). The retraction was triggered by EP authorising additional feature batches (M-F intent governance → M-G animation pack → M-H game UI/UX sub-domain) before re-cutting the release. **The numbers in this section (1401 pytest, 55 lint roots, 1066 manifest required, schema_notes 37, 16-tag final ladder) reflect the M-E baseline at rehearsal time and DO NOT match the current M-H baseline (1731 / 67 / 1193 / 36 / 18 done of 20 final).** The current absolute roadmap and metrics are recorded in §"v4.91 freeze roadmap (current absolute view)" near the end of this document. Section preserved verbatim below as historical evidence; do NOT cite for current state.

<!-- BEGIN SUPERSEDED P10 REHEARSAL — kept for forensic completeness -->


> **Status**: CLOSED 2026-05-26 — 5-commit ceremony chain on top of P9 c2 (`2b1c7ee`). Annotated tag `v4.91-release` applied at the P10 c5 commit. **The v4.91 release artefact is shipped.**
>
> **Trigger**: P10 is the ONLY phase per MEMORY contract #16 that is permitted to cut a release directory + zip rehearsal. All prior P1-P9 phases used commit + tag only. P10 closes the v4.91 freeze sequence with a self-contained release artefact at `AI_Game_Dev_OS_v4.91_Release/` plus the canonical zip `AI_Game_Dev_OS_v4.91_Release.zip`.
>
> **Theme**: Release artefact identity transition (`AI_Game_Dev_OS_v4.90` → `AI_Game_Dev_OS_v4.91` abstract identity; `AI_Game_Dev_OS_v4.90_Release` → `AI_Game_Dev_OS_v4.91_Release` physical dir; v4.89_Release → v4.90_Release base_from). The frozen RC3 gate file is unmodified across the entire v4.91 arc — the dispatcher's v4.91 override layer (P9 c1) is what produces 13/13 PASS evidence inside the release dir itself.

### EP decision matrix (locked 2026-05-26)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **5-commit ceremony chain** (c1 cut release dir / c2 manifest sync + identity / c3 full gate evidence / c4 zip / c5 rehearsal + RELEASE_NOTES + tag) | Mirrors v4.90 ceremony pattern; each c-step independently auditable. |
| Q2 | **rsync + anchored exclusions** for release dir cut | Exclude transients only; preserve `.gitkeep` + `trial_workspaces/runtime/logs/*.jsonl` fixtures. |
| Q3 | **Identity transition writes** in c1+c2 (NOT in working tree) | working tree stays at v4.90 abstract identity for v4.92 base_from purposes; release dir alone advances. |
| Q4 | **Update `tests/test_release_manifest_consistency.py` in release dir only** | The 3 v4.90-hardcoded assertions are release-dir-local edits; the working tree copy stays at v4.90 expectations until a future rebase. |
| Q5 | **Full gate 13/13 in release dir** (the gate of record for the freeze) | MEMORY contract #13 freeze evidence band; this run satisfies it inside the release artefact, not just the working tree. |
| Q6 | **zip with `-r -X -q` + 7 anchored exclusions** | Strip macOS extended-attrs; quiet output; exclude transients + governance hot-paths. |
| Q7 | **Annotated tag `v4.91-release`** at the c5 commit | The final v4.91 tag; tag ladder advances to 16. |
| Q8 | **No `manifest_schema_version` bump** at release time | The 2.3 schema shape is preserved verbatim from M-E close. |

### Commits (5; all landed)

```
<c1>     chore(v4.91 P10 c1): cut AI_Game_Dev_OS_v4.91_Release/ tree (rsync + identity update)
<c2>     chore(v4.91 P10 c2): release manifest + CHECKSUMS recompute (in release dir)
<c3>     chore(v4.91 P10 c3): full gate 13/13 evidence in release dir (overrides C1+C2)
<c4>     chore(v4.91 P10 c4): cut AI_Game_Dev_OS_v4.91_Release.zip
<c5>     chore(v4.91 P10 c5): rehearsal report + RELEASE_NOTES P10 + tag v4.91-release
```

(c1..c5 collapse into a single commit chain; this RELEASE_NOTES section, the rehearsal report, and the tag itself ride on the final c5 commit.)

### Surface added

| Path | Layer | Role |
|---|---|---|
| `AI_Game_Dev_OS_v4.91_Release/` | release tree | 1219 files / 1066 required + 31 optional + 120 fixtures; v4.91 abstract identity |
| `AI_Game_Dev_OS_v4.91_Release.zip` | release archive | ≈ 2.7 MiB; 1638 entries; sha256 recorded in `v4.91_release_rehearsal_report.md` (intentionally not embedded here to avoid zip↔RELEASE_NOTES sha circular dependency) |
| `v4.91_release_rehearsal_report.md` | workspace doc | full ceremony rehearsal (purpose / method / results / acceptance criteria / non-features / cross-refs) |
| `RELEASE_MANIFEST.json :: manifest_schema_notes[37]` (release dir) | metadata | P10 ceremony note describing the identity transition |
| `tests/test_release_manifest_consistency.py` (release dir only) | release-dir test | 3 assertions updated from v4.90 strings to v4.91 strings |

### Cumulative v4.91 state at v4.91-release

| Metric | Working tree | Release dir |
|---|---|---|
| pytest tests/ | 1401 / 2 skip | 1401 / 2 skip |
| Fast-gate items | 23 | 23 |
| Protected invariants | 11 | 11 |
| Layer 1 lint roots | 55 | 55 |
| Manifest schema_version | 2.3 | 2.3 |
| required_manifest_files | 1066 | 1066 |
| optional_seed_files | 31 | 31 |
| test_fixtures | 120 | 120 |
| manifest_schema_notes | 36 | 37 (+1 P10 ceremony entry) |
| Full gate (--profile full) | 13/13 PASS, overrides=['C1','C2'] | 13/13 PASS, overrides=['C1','C2'] |
| `package_name` | AI_Game_Dev_OS_v4.90 (abstract; preserved for v4.92 base_from) | **AI_Game_Dev_OS_v4.91** ⭐ |
| `package_root_dir` | AI_Game_Dev_OS_v4.90_Release | **AI_Game_Dev_OS_v4.91_Release** ⭐ |
| `base_from` | AI_Game_Dev_OS_v4.89_Release | **AI_Game_Dev_OS_v4.90_Release** ⭐ |
| `VERSION` | 4.91-WIP | **4.91-Release** ⭐ |
| `MANIFEST.json :: package_version` | 4.91-WIP | **4.91-Release** ⭐ |
| Tag ladder | 15 | 16 (this commit) |

### Charter alignment

| Charter | Status |
|---|---|
| §6.2 RC3 stays frozen as v4.90 reference | ✅ `scripts/governance/run_v490_rc3_closure_gate.py` unmodified across the entire v4.91 arc (F-T-01 through P10) |
| #4 Extend, don't replace | ✅ `manifest_schema_version` 2.3 preserved; identity fields advance via additive writes |
| #11 Recording != closure-gate pass | ✅ Rehearsal report is evidence of the run's completion, not a substitute for the gate; the gate ran inside the release dir and produced 13/13 PASS |
| #14 No full release copy by default | ⚠️ Per Charter §6.1 EXCEPTION clause: P10 ceremony is the ONLY phase permitted to cut a release dir + zip; all prior phases (P1-P9) honoured the no-copy default |
| inv_001 byte-lock | ✅ v4.89 reference layer tree SHA `bb48af16…87767` unchanged across the transition (verified by C3 in the release dir's full gate run) |

### Maintainer evidence record (laptop, 2026-05-26)

| Run | Result |
|---|---|
| `rsync ... AI_Game_Dev_OS_v4.91/ AI_Game_Dev_OS_v4.91_Release/` (c1) | 1219 files cut |
| `python3 scripts/rebuild_release_manifest.py --check` (release dir, c2) | exit 0 — clean ✓ no drift |
| `python3 scripts/governance/lint_layer_separation.py` (release dir, c3) | clean — 55 roots / 0 violations + 1 runtime tree / 0 leaks |
| `python3 -m pytest tests/ -q` (release dir, c3) | **1401 passed / 2 skipped** in 67.23 s |
| `python3 scripts/governance/run_release_closure_gate.py --profile full --format json` (release dir, c3) | **overall=0; PASS=13/13** in ~70 s; **`v4_91_overrides=['C1', 'C2']`** |
| `python3 scripts/audit/audit_v4_89_references.py --summary-only` (release dir, c3) | Class A: 231 / Class B: 1340 / Class C: **0** / Class D: 14 |
| `python3 scripts/governance/verify_release_clean_tree.py` (release dir, c3) | clean ✓ |
| `zip -r -X -q AI_Game_Dev_OS_v4.91_Release.zip ...` (c4) | ≈ 2.7 MiB; 1638 entries; 0 transients (sha256 in rehearsal report) |
| `shasum -a 256 AI_Game_Dev_OS_v4.91_Release.zip` (c4) | recorded in `v4.91_release_rehearsal_report.md` (workspace-level doc; not in zip) |

### What P10 does NOT include (intentional non-features)

- **No working-tree identity advance.** The working tree stays at `package_name = AI_Game_Dev_OS_v4.90` (and related v4.90 fields) so it remains a valid v4.92 base_from anchor. Only the release dir advances.
- **No mutation of the frozen RC3 gate.** `scripts/governance/run_v490_rc3_closure_gate.py` is byte-identical to its v4.90 release version, across the entire v4.91 arc.
- **No `config/.core_os_root` bump.** The `v4.90-marker` stays as a backward-compat anchor; v4.91 abstract identity is carried in `MANIFEST.json` + `CHECKSUMS.txt` (the v4.91 B3 Core abstract identity surface).
- **No `manifest_schema_version` bump.** The 2.3 shape is preserved verbatim.
- **No second zip variant** (e.g. with deliverables stripped). One canonical zip per release.
- **No release-blog / external announcement.** The v4.91 freeze produces evidence + tag + zip; external comms are a separate concern outside the v4.91 charter scope.

### v4.91 freeze sequence — final ledger

| Phase | Tag | Status |
|---|---|---|
| P1 | `v4.91-Addendum-B` | ✅ closed |
| P1.5 | `v4.91-Addendum-C` | ✅ closed |
| P2 | (no tag) | ✅ closed |
| P3 | `v4.91-M-C` | ✅ closed |
| P4 | `v4.91-M-D` | ✅ closed |
| P5 | `v4.91-M-E-B8` | ✅ closed |
| P6 | `v4.91-M-E-B9` | ✅ closed |
| P7 | (no tag) | ✅ closed |
| P8 | `v4.91-M-E` | ✅ closed |
| P9 | `v4.91-RC1` | ✅ closed |
| **P10** | **`v4.91-release`** | ✅ **CLOSED — this commit** |

### Next phase

P10 closes here. The v4.91 freeze sequence is complete. The next major version (v4.92, when authorised) will fork from `AI_Game_Dev_OS_v4.91_Release/` per Charter §6.2 byte-lock evolution rules.

<!-- END SUPERSEDED P10 REHEARSAL — see §"v4.91 freeze roadmap (current absolute view)" for current state -->

---

## v4.91 P9' — D v4.91-RC2 closure gate (CLOSED 2026-05-29)

> **Status**: CLOSED 2026-05-29 — c1 (this commit) bumps the dispatcher v4.91 baseline override constants from RC1 (1401/2/55) to RC2 (1735/2/67) reflecting the post M-H + Hygiene-1 baseline + adjusts the override test fixtures + manifest sync + RELEASE_NOTES P9' section. Annotated tag `v4.91-RC2` to follow at the c1 release commit.
>
> **Trigger**: After RC1 (2026-05-26) the freeze surface advanced four times: M-F (intent governance, +inv_012), M-G (animation sub-domain, +inv_013), M-H (game UI/UX sub-domain, +inv_014), Hygiene-1 (RELEASE_NOTES tag-ladder reconciliation + aggregate test dedup, +2 net pytest pass). RC1's baseline constants 1401/2/55 no longer match the live tree (1735/2/67); the dispatcher's C2 override now succeeds but C1 (pytest count) still fails. P9' is the minimal-scope re-baseline that lets the dispatcher emit 13/13 PASS evidence again.
>
> **Theme**: Constant-only override re-baseline; no schema bumps, no new fast-gate items, no new invariants, no new tests, no scope expansion to C7 / C8.

### EP decision matrix (locked 2026-05-29)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **1-commit ladder** (c1 source + tests + manifest in one atomic commit) | RC2 is a constant-bump re-baseline, not a feature batch. P9 RC1 used a 2-commit ladder because it INTRODUCED the override layer; P9' has nothing structurally new. |
| Q2 | **Override scope unchanged at C1 + C2 only** | C7 (invariants 7→14) and C8 (aggregate 6/6) PASS naturally when the dispatcher runs under PATH-resolved system python with working `jsonschema`. Adding C7/C8 overrides would have added subprocess fan-out to the dispatcher that's hard to mock and unnecessary in the standard maintainer evidence procedure. |
| Q3 | **EXPECTED_PYTEST_V4_91 = 1735** (not 1733) | RC3 invokes `python3 -m pytest -q` without an explicit `tests/` arg; rootdir-driven collection yields 1735 vs `pytest tests/` 1733. The override matches what RC3 actually invokes per Charter §6.2 frozen contract. |
| Q4 | **EXPECTED_PYTEST_SKIPPED_V4_91 = 2** (not 4) | Same RC3 invocation path; under PATH-resolved system python with working jsonschema the 2 Hygiene-1 c2 env-skips become real PASS, leaving only the 2 long-standing manifest-fixture skips. |
| Q5 | **Annotated tag v4.91-RC2** at c1 | MEMORY contract #12 — release-candidate tag policy. RC1 preserved as historical evidence (commit `2b1c7ee`). |

### Commits (1; this commit)

```
<c1>     feat(v4.91 P9 prime c1): RC2 baseline override re-baseline
         (constants 1401/2/55 → 1735/2/67 + test fixtures + manifest +
         RELEASE_NOTES P9' + tag v4.91-RC2)
```

### Surface changed (2 MOD, 0 NEW)

| Path | Layer | Role |
|---|---|---|
| `scripts/governance/run_release_closure_gate.py` MOD | L1 governance | 3 constants bumped: `EXPECTED_PYTEST_V4_91` 1401→**1735**, `EXPECTED_PYTEST_SKIPPED_V4_91` 2 (unchanged), `EXPECTED_LAYER1_ROOTS_V4_91` 55→**67**. Comment block updated to document the RC3-invocation-path mismatch (1735 vs 1733). Override semantics (C1/C2 only, JSON-only path, regex-match against actual count) unchanged. |
| `tests/governance/test_v4_91_baseline_override.py` MOD | L1 test | `test_baseline_constants_reflect_m_e_close` renamed to `test_baseline_constants_reflect_rc2`; 6 fixture payloads with hardcoded 1401/55 → 1735/67. All 7 tests preserve their original assertion shape. |

### Charter alignment

| Charter | Status |
|---|---|
| §6.2 RC3 stays frozen as v4.90 reference | ✅ `scripts/governance/run_v490_rc3_closure_gate.py` byte-identical across the entire v4.91 arc (F-T-01 through P9'). |
| #4 Extend, don't replace | ✅ Override layer additive at the dispatcher boundary; original RC3 semantics preserved verbatim for any check outside C1/C2 and any C1/C2 fail not matching the v4.91 expectation. |
| #11 Recording != closure-gate pass | ✅ Override surfaces baseline drift as PASS only when actual exactly matches the v4.91 expectation; any other fail flows through. The override never silently absorbs a regression. |
| inv_001 byte-lock | ✅ v4.89 reference layer tree SHA `bb48af16…87767` unchanged (verified by C3 in this run's full gate). |

### Maintainer evidence record (laptop, 2026-05-29 14:30+)

| Run | Result |
|---|---|
| `python3 -m pytest tests/` (system python) | **1733 passed / 4 skipped** in 74.28 s |
| `python3 -m pytest -q` (system python, RC3 invocation pattern) | **1735 passed / 2 skipped** — matches override expectation |
| `python3 -m pytest tests/governance/test_v4_91_baseline_override.py -v` | **7 passed** in 0.03 s |
| `python3 scripts/governance/run_release_closure_gate.py --profile full --format json` (PATH=system python) | **overall=0; PASS=13/13** in ~70 s; **`v4_91_overrides=['C1', 'C2']`** — C1 lifted via `got 1735/2` baseline match, C2 lifted via `got 67 roots / 0 violations` baseline match |
| `python3 scripts/governance/run_release_closure_gate.py --profile fast` | **overall=0; PASS=23/23** in 8.89 s |
| `python3 scripts/governance/lint_layer_separation.py` | clean — **67 roots** / 0 violations + runtime tree clean |
| `python3 scripts/rebuild_release_manifest.py --check` | **exit 0 — clean ✓ no drift** |
| `python3 scripts/governance/verify_release_clean_tree.py` | **clean ✓** (actual − manifest − exclusions = 0) |

### Manifest sync (c1)

- `manifest_schema_notes`: **37 → 38** (+1 entry: P9' RC2 re-baseline rationale + RC3 invocation pattern note + override scope clarification).
- `required_manifest_files`: **1193 → 1193** (no NEW files; the 2 MOD files surface as sha refresh).
- `manifest_schema_version` 2.3 preserved verbatim.
- Fast-gate item count UNCHANGED (still 23). No F-item added.
- Protected invariant count UNCHANGED (still 14). No new inv added.

### What P9' does NOT include (intentional non-features)

- **No C7 / C8 override** — these PASS naturally under the standard maintainer evidence procedure (PATH-resolved system python with working `jsonschema`). Adding them as override paths would require subprocess fan-out inside the dispatcher (hard to mock in tests) and gain nothing in the well-formed evidence environment.
- **No new fast-gate item** — P9 RC1 introduced no F-item; P9' is a constant-only re-baseline, even simpler.
- **No new invariant** — the override layer is enforced by `tests/governance/test_v4_91_baseline_override.py`, not by the protected regression matrix (the matrix is the wrong layer for "the dispatcher honours the v4.91 baseline").
- **No release-zip work** — Per MEMORY contract #16; only P10' ceremony cuts the release.
- **No non-additive RC3 patch** — Charter §6.2 forbids it.
- **No further surface advance** — P9' closes the M-A → M-H feature arc; the next batch is P10' REL ceremony.

### Next phase

P9' closes here. The freeze roadmap continues with **P10' — REL ceremony** (the ONLY phase that cuts `AI_Game_Dev_OS_v4.91_Release/` + zips it). With M-H + Hygiene-1 + RC2 done, v4.91 tag ladder stands at **19 / 20** absolute. The P10' REL ceremony will re-cut `AI_Game_Dev_OS_v4.91_Release/` + zip + identity transition + apply tag `v4.91-release` to bring the ladder to **20 / 20**.

---

## v4.91 RC2-FC2 — 3rd Review Closure (second-level-script orphan leak) (CLOSED 2026-05-30)

> **Status**: CLOSED 2026-05-30. Tag `v4.91-RC2-FC2` @ `02a2c8d`. **RC2-FC2 (NOT Final)** per the 3rd reviewer, pending external re-verification. The `v4.91-release` "Final" tag from RC2-FC1 (section below) was retracted (`git tag -d`, EP-approved) — the 3rd review rejected it.
>
> **What the 3rd review reproduced**: orphan pytest surviving a fast-gate timeout on the real F6 path. RC2-FC1 fixed only the dispatcher's direct runner; fast items F5/F6 shell out to second-level scripts (`check_consistency_aggregate.py` / `check_required_regressions.py`) that spawn pytest via the LEGACY `run_pg_safe` wrapper, which hard-coded `new_session=True` → inner pytest escaped the outer `killpg`.
>
> **Root-cause fix (P0-1)**: both legacy wrappers (`run_pg_safe` / `run_pg_safe_to_file`) now honour `GATE_IN_SINGLE_ITEM` → `new_session=not nested`; one fix covers F5+F6; env-unset path unchanged (zero regression). **Regression (P0-2)**: `test_dispatcher_kills_legacy_wrapper_inner_process_group` (legacy-wrapper chain via `GATE_TEST_HANG_VIA_LEGACY=1`); fix→green, revert→reproduces orphan.
>
> **Acceptance**: fast 300s ×3 → exit=0, 25/25, 0 stray; 5s negative → RC=1, F6 killed, 0 stray; full pytest **1763** passed / 2 skipped (baseline 1762→1763); full closure gate 13/13 PASS in both trees. Commit ladder: c1 `c82d99b` / c2 `2a1a809` / c3(release dir) `02a2c8d`. Zip sha256 `d5329b730ed85d562cb0bcc80c61f51c10310cb2b1a1fb61bca98544407b0290`.

---

## v4.91 P10'' (RC2-FC1 re-execution, SUPERSEDED by RC2-FC2 above) — REL Ceremony (CLOSED 2026-05-30)

> ⚠️ **SUPERSEDED 2026-05-30 by RC2-FC2**: this ceremony tagged `v4.91-release` as "FIRST VALID Final", but the 3rd external review reproduced the orphan again on the real F6 path — the nested-killpg fix here covered only the dispatcher's direct runner, not the F5/F6 second-level legacy-wrapper path. The `v4.91-release` tag was retracted; commit `143e989` remains in history without a Final tag. The 1762 baseline below is superseded by 1763 (RC2-FC2). Preserved as historical lineage ONLY.
>
> **Status**: (historical) CLOSED 2026-05-30 (RC2-FC1) — claimed FIRST VALID Final at the time. Annotated tag `v4.91-release` applied at the c5 commit.
>
> **Why a third ceremony**: a second external review reproduced a real Batch 0 fast-gate orphan-pytest leak that the 2026-05-30 re-execution below had masked behind a false-positive "13/13". Root cause: nested process-group-safe runners — dispatcher wrapper [group A], F-item helper's pytest in a NEW session [group B]; outer killpg reaped only group A, pytest in group B escaped. `killed_pg=True` and the prior e2e test were both false positives.
>
> **Supersedes**: the "(re-executed)" P10' below (cut `27eba13`, tree+tag retracted `46be0c6`) and all earlier ceremonies.

### Batch 0 fix (RC2-FC P0 c1–c3, c5)
`_process_runner` v2 runners gained `new_session`; the dispatcher sets `GATE_IN_SINGLE_ITEM=1` and `_runner_imports()` hands F-item helpers `new_session=False`, keeping pytest in the wrapper's group so the dispatcher's single outer killpg reaps the whole nested tree. Bidirectionally verified: controlled nesting experiment (orphan before / reaped after) + a regression test that FAILS on revert, PASSES with the fix.

### Acceptance
- Batch 0 fast gate: 3× `--fast-total-timeout 300` → 25 pass / 0 fail / **0 stray**; tiny-budget `--fast-total-timeout 5` → **0 orphan**.
- working tree: full pytest **1762 passed / 2 skipped / 0 failed**; full gate **13/13**.
- release dir: full gate **13/13**, 0 fails, manifest **1216**.

### Ceremony chain
RC2-FC P0 c1 `af3f907` / c2 `3f8b255` / c3 `b2a5bf6` / c5 `dd05fd0` · RC2-FC P1 `46faff2` · P10'' c1 `cdf98f6` / c2+c3 `eae01d7` / c5 (this commit → tag).

### Version labels (dual-track, EP Q1=a)
working tree `4.91-WIP` (v4.92 anchor) · release artifact `4.91-Release`. Both correct; no WIP/release/Release mixing.

### Zip
`AI_Game_Dev_OS_v4.91_Release.zip` · sha256 `0b6f36ce5fd6c9f6a6bc7c22555daee0a186733292710cbd613773deb0b8aeb4` · 3.0 MB · gitignored (sha256 is the canonical pin).

### Next phase
None. The v4.91 freeze sequence is complete at this commit.

---

## v4.91 P10' (re-executed, SUPERSEDED by RC2-FC1) — REL Ceremony (CLOSED 2026-05-30)

> ⚠️ **SUPERSEDED 2026-05-30 (RC2-FC1)**: this re-execution (cut `27eba13`) embedded the Batch 0 fast-gate orphan leak that the round-2 review reproduced; its `_Release/` tree and `v4.91-release` tag were retracted (`46be0c6`). Preserved below as historical lineage ONLY. See the P10'' (RC2-FC1) section above for the valid release.


> **Status**: CLOSED 2026-05-30 — the REAL Final ceremony, executed after the external RC1-review remediation cycle. Annotated tag `v4.91-release` applied at the c5 commit (this commit). **The v4.91 release artefact is shipped at a genuine 13/13-green baseline.**
>
> **Supersedes**: the 2026-05-29 P10' ceremony below (cut at `b6afc3c`), whose `_Release/` tree + `v4.91-release` tag were retracted on 2026-05-30 (`0b46f73` removed the tree; the tag was deleted EP-approved). That ceremony's "13/13" evidence predated the RC1-review remediation (P0 gate-runner killpg, P1-a/b/c hub+preflight, F5/F6 interpreter normalization, P2 evidence, RC2 test alignment) — the exact stale-evidence hazard the review exposed. This re-execution cuts the release dir from `v4.91-RC2` (`7a2f82f`), the first tree whose full closure gate genuinely closes 13/13.
>
> **Trigger**: P10' is the ONLY phase per MEMORY contract #16 permitted to cut a release directory + zip.

### Ceremony chain (4 c-steps, c4 skipped per ladder)
| step | commit | content |
|---|---|---|
| c1 | `82d5a57` | rsync cut `AI_Game_Dev_OS_v4.91_Release/` from the 13/13-green working tree (7 anchored transient excludes) |
| c2 | `7f76870` | identity transition IN RELEASE DIR ONLY (VERSION + 6 fields + V4_91_README rename + banners + test guard); working tree preserved at 4.91-WIP as the v4.92 base_from anchor (EP Q1=a) |
| c3 | `914d568` | V4_90_README RC3-compat stub (EP Q3=a, Charter #4) + release banner v4.89-phrase fix (greedy Class-C regex avoidance); release-dir full gate 13/13 |
| c5 | (this commit) | rehearsal report + this RELEASE_NOTES section + final manifest sync + clean zip → tag `v4.91-release` |

### Identity transition (release dir only; EP Q1=a)
`package_name` v4.90→v4.91 · `base_from` v4.89_Release→v4.90_Release · `package_root_dir` v4.90_Release→v4.91_Release · `VERSION` 4.91-WIP→4.91-Release · `.core_os_root` v4.90→v4.91-marker · `CURRENT_MAJOR_MINOR` v4.90→v4.91. Working tree keeps the v4.90 abstract identity + 4.91-WIP as the v4.92 fork anchor.

### Active baseline (EP Q2: current truth)
- pytest **1762 passed / 2 skipped / 0 failed** (clean tree, PATH python3 with jsonschema+pytest)
- **67** Layer-1 lint roots / 0 violations · **15** protected invariants (through inv_015)
- manifest required: working tree **1215** · release dir **1216** (+V4_90_README compat stub)
- full closure gate **13/13 PASS**, overall_exit=0, overrides=[C1,C2]

### Zip artefact
`AI_Game_Dev_OS_v4.91_Release.zip` (workspace root) · sha256 `b4c423d5cfe646582fae9c78fcaa1e9075d4d408508174a9b83e1671a34795ab` · 3.0 MB · gitignored (sha256 is the canonical pin).

### Charter alignment
§6.2 byte-lock — v4.89 reference tree SHA `bb48af16…87767` unchanged · #4 extend-don't-replace (V4_90_README stub, frozen RC3 untouched) · #2 no project literals.

### What this re-execution does NOT include (non-features)
- working tree VERSION stays `4.91-WIP` (v4.92 base_from anchor, EP Q1=a)
- zip not committed (gitignored; sha256 pin) · rehearsal report not inside zip (circular-sha avoidance)
- the frozen RC3 gate file is unmodified across the entire v4.91 arc

### Next phase
None. The v4.91 freeze sequence is complete at this commit.

---

## v4.91 P10' (original, SUPERSEDED) — REL Ceremony (CLOSED 2026-05-29)

> ⚠️ **SUPERSEDED 2026-05-30**: this ceremony was cut at `b6afc3c` BEFORE the external RC1 review. Its `_Release/` tree and `v4.91-release` tag were retracted (`0b46f73` + EP-approved tag delete) because its "13/13" evidence predated the RC1-review remediation cycle. It is preserved below as historical lineage ONLY. For the current release see the re-executed P10' section above (CLOSED 2026-05-30).


> **Status**: CLOSED 2026-05-29 — 5-commit ceremony chain on top of P9' c1 (`15a1f8c`). Annotated tag `v4.91-release` applied at the c5 commit (this commit). **The v4.91 release artefact is shipped.**
>
> **Trigger**: P10' is the ONLY phase per MEMORY contract #16 that is permitted to cut a release directory + zip. All prior P1-P9' phases used commit + tag only. P10' closes the v4.91 freeze sequence with a self-contained release artefact at `AI_Game_Dev_OS_v4.91_Release/` plus the canonical zip `AI_Game_Dev_OS_v4.91_Release.zip`. P10' is the **second** REL ceremony of the v4.91 freeze — the first (P10, 2026-05-26, commits `dd9863f` + `cfe6d6b`, tag `v4.91-release` retracted 2026-05-28) was rehearsed before EP authorised additional feature batches (M-F → M-G → M-H + Hygiene-1 + RC2). Rehearsal commits remain in git history as P10-rehearsal evidence; the original `v4.91-release` tag was deleted via `git tag -d` on 2026-05-28.
>
> **Theme**: Release artefact identity transition (`AI_Game_Dev_OS_v4.90` → `AI_Game_Dev_OS_v4.91` abstract identity; `AI_Game_Dev_OS_v4.90_Release` → `AI_Game_Dev_OS_v4.91_Release` physical dir; v4.89_Release → v4.90_Release base_from). The frozen RC3 gate file is unmodified across the entire v4.91 arc — the dispatcher's v4.91 override layer (P9 c1, P9' c1) is what produces 13/13 PASS evidence inside the release dir itself.

### EP decision matrix (locked 2026-05-29)

Identical to P10 rehearsal (2026-05-26) except where noted:

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **5-commit ceremony chain** (c1 cut tree / c2 identity transition / c3 evidence + 2 test guards + V4_90_README compat stub / c4 zip / c5 rehearsal report + RELEASE_NOTES P10' + tag) | Mirrors v4.90 ceremony pattern; each c-step independently auditable. P10' c3 absorbs additional repair work that surfaced post-c2: (a) tests/test_readme_status_consistency.py path target advance, (b) V4_90_README.md compat stub for RC3 C11 contract, (c) schema_notes [38] reword for v4.89 audit migration-arrow regex. |
| Q2 | **rsync + anchored exclusions** for release dir cut | Exclude transients only; preserve `.gitkeep` + `trial_workspaces/runtime/logs/*.jsonl` fixtures. |
| Q3 | **Identity transition writes** in c2 (NOT in working tree) | Working tree stays at v4.90 abstract identity for v4.92 base_from purposes; release dir alone advances. |
| Q4 | **Update tests/test_release_manifest_consistency.py + tests/test_readme_status_consistency.py in release dir only** | Hardcoded assertions are release-dir-local edits; the working tree copies stay at v4.90 expectations until a future rebase. |
| Q5 | **Full gate 13/13 in release dir** (the gate of record for the freeze) | MEMORY contract #13 freeze evidence band; this run satisfies it inside the release artefact at the v4.91-RC2 baseline (1735/2/67). |
| Q6 | **zip with `-r -X -q` + 7 anchored exclusions** | Strip macOS extended-attrs; quiet output; exclude transients + governance hot-paths. |
| Q7 | **Annotated tag `v4.91-release`** at the c5 commit | The final v4.91 tag; tag ladder advances 19 → **20** (final). |
| Q8 | **No `manifest_schema_version` bump** at release time | The 2.3 schema shape is preserved verbatim from M-E close. |
| Q9 (NEW) | **`V4_90_README.md` compat stub** | Charter §6.2 forbids modifying frozen RC3 gate which hardcodes a C11 check on `V4_90_README.md`. Per #4 (extend, don't replace) the cleanest fix is a 1.4 KB backward-compat stub at the legacy filename redirecting readers to `V4_91_README.md`. |

### Commits (5; all landed)

```
<c1>     chore(v4.91 P10' c1): cut AI_Game_Dev_OS_v4.91_Release/ tree (rsync from source)
<c2>     chore(v4.91 P10' c2): release dir identity transition + V4_91_README rename + manifest sync
<c3>     chore(v4.91 P10' c3): full gate 13/13 evidence in release dir + 2 test guards advanced + V4_90_README compat stub
<c4>     (no separate commit — zip cut artefact is gitignored; sha256 recorded in c5 rehearsal report and below)
<c5>     chore(v4.91 P10' c5): rehearsal report + RELEASE_NOTES P10' + tag v4.91-release
```

### Surface added

| Path | Layer | Role |
|---|---|---|
| `AI_Game_Dev_OS_v4.91_Release/` | release tree | 1346 files / 1194 required + 31 optional + 120 fixtures + 1 V4_90_README compat stub; v4.91 abstract identity |
| `AI_Game_Dev_OS_v4.91_Release.zip` | release archive | ≈ 3.0 MiB; 1804 entries; sha256 `d68ce94b24365d38b163aa13fea1e3ee222d40ec222922cece94f436119712fd` (intentionally not embedded here to avoid zip↔RELEASE_NOTES sha circular dependency; see workspace-level rehearsal report) |
| `v4.91_release_p10prime_rehearsal_report.md` | workspace doc | full ceremony rehearsal (purpose / method / results / acceptance criteria / non-features / cross-refs) |
| `RELEASE_MANIFEST.json :: manifest_schema_notes[39]` (release dir) | metadata | P10' ceremony note describing the identity transition with migration-arrow context |
| `tests/test_release_manifest_consistency.py` (release dir only) | release-dir test | 3 assertions updated from v4.90 strings to v4.91 strings |
| `tests/test_readme_status_consistency.py` (release dir only) | release-dir test | README_PATH advanced V4_90_README.md → V4_91_README.md |
| `V4_90_README.md` (release dir, NEW compat stub) | release-dir compat shim | 1.4 KB stub redirecting to V4_91_README.md while satisfying RC3 C11 contract |

### Cumulative v4.91 state at v4.91-release

| Metric | Working tree | Release dir |
|---|---|---|
| pytest tests/ | 1733 / 4 skip | 1733 / 4 skip |
| Fast-gate items | 23 | 23 |
| Protected invariants | 14 | 14 |
| Layer 1 lint roots | 67 | 67 |
| Manifest schema_version | 2.3 | 2.3 |
| required_manifest_files | 1193 | 1194 (+1 V4_90_README compat stub) |
| optional_seed_files | 31 | 31 |
| test_fixtures | 120 | 120 |
| manifest_schema_notes | 38 | 39 (+1 P10' c2 entry) |
| Full gate (--profile full) | 13/13 PASS, overrides=['C1','C2'] | 13/13 PASS, overrides=['C1','C2'] |
| `package_name` | AI_Game_Dev_OS_v4.90 (abstract; preserved for v4.92 base_from) | **AI_Game_Dev_OS_v4.91** ⭐ |
| `package_root_dir` | AI_Game_Dev_OS_v4.90_Release | **AI_Game_Dev_OS_v4.91_Release** ⭐ |
| `base_from` | AI_Game_Dev_OS_v4.89_Release | **AI_Game_Dev_OS_v4.90_Release** ⭐ |
| `VERSION` | 4.91-WIP | **4.91-Release** ⭐ |
| `MANIFEST.json :: package_version` | 4.91-WIP | **4.91-Release** ⭐ |
| `config/.core_os_root` | v4.90-marker | **v4.91-marker** ⭐ |
| `scripts/check_core_os_root.py::CURRENT_MAJOR_MINOR` | 'v4.90' | **'v4.91'** ⭐ |
| `V4_91_README.md` (Chinese release-tree README) | absent | present (renamed from V4_90_README.md) |
| `V4_90_README.md` (compat stub) | (legacy WT README, v4.90 era) | 1.4 KB compat stub |
| Tag ladder | 19 | **20** (this commit, final) |

### Charter alignment

| Charter | Status |
|---|---|
| §6.2 RC3 stays frozen as v4.90 reference | ✅ `scripts/governance/run_v490_rc3_closure_gate.py` byte-identical across the entire v4.91 arc (F-T-01 through P10'). The c3 V4_90_README.md compat stub honours C11 contract without source-modifying RC3. |
| #4 Extend, don't replace | ✅ `manifest_schema_version` 2.3 preserved; identity fields advance via additive writes; V4_90_README.md compat stub is purely additive. |
| #11 Recording != closure-gate pass | ✅ Rehearsal report is evidence of the run's completion, not a substitute for the gate; the gate ran inside the release dir and produced 13/13 PASS. |
| #14 No full release copy by default | ⚠️ Per Charter §6.1 EXCEPTION clause: P10' ceremony is the ONLY phase permitted to cut a release dir + zip; all prior phases (P1-P9') honoured the no-copy default. |
| #16 v4.91 release deferral | ✅ P10' is the SECOND REL ceremony for v4.91 — the first (P10) was rehearsed and retracted; this one is the actual release. No intermediate zips between RC2 and P10'. |
| inv_001 byte-lock | ✅ v4.89 reference layer tree SHA `bb48af16…87767` unchanged across the transition (verified by C3 in the release dir's full gate run) |

### Maintainer evidence record (laptop, 2026-05-29 16:00+)

| Run | Result |
|---|---|
| `rsync ... AI_Game_Dev_OS_v4.91/ AI_Game_Dev_OS_v4.91_Release/` (c1) | 1346 files cut |
| `python3 scripts/rebuild_release_manifest.py --check` (release dir, c2-c3) | exit 0 — clean ✓ no drift |
| `python3 scripts/governance/lint_layer_separation.py` (release dir, c3) | clean — 67 roots / 0 violations + 1 runtime tree / 0 leaks |
| `python3 -m pytest tests/ -q` (release dir, c3) | **1733 passed / 4 skipped** in 69.72 s |
| `python3 scripts/governance/run_release_closure_gate.py --profile full --format json` (release dir, c3) | **overall=0; PASS=13/13** in ~70 s; **`v4_91_overrides=['C1', 'C2']`** |
| `python3 scripts/governance/run_release_closure_gate.py --profile fast` (release dir, c3) | **overall=0; PASS=23/23** in ~9 s |
| `python3 scripts/audit/audit_v4_89_references.py --summary-only` (release dir, c3) | Class A: 233 / Class B: 1351 / Class C: **0** / Class D: 14 |
| `python3 scripts/lint/check_v4_89_baseline_integrity.py` (release dir, c3) | ✓ Class C ACTIVE_STALE 0 |
| `python3 scripts/check_core_os_root.py` (release dir, c3) | verdict=PASS, content=v4.91-marker |
| `python3 scripts/governance/verify_release_clean_tree.py` (release dir, c3) | clean ✓ |
| `zip -r -X -q AI_Game_Dev_OS_v4.91_Release.zip ...` (c4) | ≈ 3.0 MiB; 1804 entries; 0 transients; sha256 `d68ce94b24365d38b163aa13fea1e3ee222d40ec222922cece94f436119712fd` |

### What P10' does NOT include (intentional non-features)

- **No working-tree identity advance.** The working tree stays at `package_name = AI_Game_Dev_OS_v4.90` (and related v4.90 fields) so it remains a valid v4.92 base_from anchor. Only the release dir advances.
- **No mutation of the frozen RC3 gate.** `scripts/governance/run_v490_rc3_closure_gate.py` is byte-identical to its v4.90 release version, across the entire v4.91 arc.
- **No `manifest_schema_version` bump.** The 2.3 shape is preserved verbatim.
- **No second zip variant** (e.g. with deliverables stripped). One canonical zip per release.
- **No release-blog / external announcement.** The v4.91 freeze produces evidence + tag + zip; external comms are a separate concern outside the v4.91 charter scope.
- **No Hygiene-2 cleanup** folded into P10'. Any post-release hygiene is deferred to v4.91.1+ if needed.

### v4.91 freeze sequence — final ledger

| Phase | Tag | Status |
|---|---|---|
| F-T-01 | (no tag, batch fold-in) | ✅ closed |
| F-V-01 | (no tag, batch fold-in) | ✅ closed |
| M-A | `v4.91-M-A` | ✅ closed |
| Addendum-A | `v4.91-Addendum-A` | ✅ closed |
| M-B-B4 | `v4.91-M-B-B4` | ✅ closed |
| M-B-B5 | `v4.91-M-B-B5` | ✅ closed |
| M-B-B5B | `v4.91-M-B-B5B` | ✅ closed |
| M-B-B6 | `v4.91-M-B-B6` | ✅ closed |
| M-B | `v4.91-M-B` | ✅ closed |
| Addendum-B | `v4.91-Addendum-B` | ✅ closed |
| Addendum-C | `v4.91-Addendum-C` | ✅ closed |
| M-C | `v4.91-M-C` | ✅ closed |
| M-D | `v4.91-M-D` | ✅ closed |
| M-E-B8 | `v4.91-M-E-B8` | ✅ closed |
| M-E-B9 | `v4.91-M-E-B9` | ✅ closed |
| M-E | `v4.91-M-E` | ✅ closed |
| RC1 | `v4.91-RC1` | ✅ closed (preserved as historical evidence) |
| M-F | `v4.91-M-F` | ✅ closed |
| M-G | `v4.91-M-G` | ✅ closed |
| M-H | `v4.91-M-H` | ✅ closed |
| Hygiene-1 + RC2 | `v4.91-RC2` | ✅ closed |
| **P10'** | **`v4.91-release`** | ✅ **CLOSED — this commit** |

### Next phase

P10' closes here. The v4.91 freeze sequence is complete. The next major version (v4.92, when authorised) will fork from `AI_Game_Dev_OS_v4.91_Release/` per Charter §6.2 byte-lock evolution rules.

---

## v4.91 freeze roadmap (current absolute view, post P10' 2026-05-29 — FINAL)

> **Single source of truth** for v4.91 tag ladder. The per-milestone "Next phase" entries above each describe their roadmap as of their own closure time; this section reconciles them after every super-seding event (M-F → M-G → M-H, plus the P10 rehearsal retraction, plus Hygiene-1 + P9' RC2, plus P10').

### Tags landed (20 of 20 final — FREEZE COMPLETE)

| # | Tag | Date | Closure note |
|---:|---|---|---|
| 1 | `v4.91-M-A` | 2026-05-20 | Core Reliability (B0+B1+B2+B3) |
| 2 | `v4.91-Addendum-A` | 2026-05-20 | External Core Mount by Default |
| 3 | `v4.91-M-B-B4` | 2026-05-21 | Shared LTM v3 Read-Side |
| 4 | `v4.91-M-B-B5` | 2026-05-21 | LTM Write/Promotion Gates |
| 5 | `v4.91-M-B-B5B` | 2026-05-22 | Multi-Agent Preflight Consensus |
| 6 | `v4.91-M-B-B6` | 2026-05-22 | Evolution Capture |
| 7 | `v4.91-M-B` | 2026-05-22 | Controlled Learning integral |
| 8 | `v4.91-Addendum-B` | 2026-05-22 | Link Alias Removal |
| 9 | `v4.91-Addendum-C` | 2026-05-25 | Subagent Routing Gate |
| 10 | `v4.91-M-C` | 2026-05-25 | Optional Automation (B5C) |
| 11 | `v4.91-M-D` | 2026-05-25 | Recovery Schema (inv_009) |
| 12 | `v4.91-M-E-B8` | 2026-05-26 | Memory Sync (inv_010) |
| 13 | `v4.91-M-E-B9` | 2026-05-26 | Static Panel (inv_011) |
| 14 | `v4.91-M-E` | 2026-05-26 | Observability integral |
| 15 | `v4.91-RC1` | 2026-05-26 | (preserved; superseded by RC2 — feature surface advanced after this point) |
| 16 | `v4.91-M-F` | 2026-05-28 | Intent Governance (inv_012) |
| 17 | `v4.91-M-G` | 2026-05-28 | Animation sub-domain (inv_013) |
| 18 | `v4.91-M-H` | 2026-05-29 | Game UI/UX sub-domain (inv_014) |
| 19 | `v4.91-RC2` | 2026-05-29 | Closure gate replay (P9' constant-only re-baseline) |
| 20 | **`v4.91-release`** | **2026-05-29** | **REL ceremony (P10') — v4.91 FREEZE COMPLETE ⭐** |

> Hygiene-1 (2026-05-29 12:01–12:12, between M-H and RC2) ran 4 commits but received no tag per node-pinning policy: it was a non-feature documentation/test-cleanup batch that preserved baseline numbers without adding surface.

### Tags pending

None. **The v4.91 freeze sequence is complete.** The next major version (v4.92, when authorised) will fork from `AI_Game_Dev_OS_v4.91_Release/` per Charter §6.2 byte-lock evolution rules.

### Retracted

The original `v4.91-release` annotated tag (created 2026-05-26, commit `dd9863f`) was deleted via `git tag -d` on 2026-05-28 as part of the freeze reopen. Rehearsal commits remain in git history as P10-rehearsal evidence; no rehearsal zip is retained in working tree (per MEMORY contract #16, no intermediate zips during freeze).

The CURRENT `v4.91-release` tag (P10', 2026-05-29) is the actual final v4.91 release artefact and is NOT retracted.

### Final baseline (post P10', 2026-05-29)

| Metric | Working tree | Release dir |
|---|---|---|
| pytest tests/ | 1733 / 4 skip | 1733 / 4 skip |
| pytest -q (RC3 invocation) | 1735 / 2 skip | 1735 / 2 skip |
| Layer 1 lint roots | 67 / 0 violations | 67 / 0 violations |
| Protected invariants | 14 active | 14 active |
| Manifest required_manifest_files | 1193 | 1194 (+1 V4_90_README compat stub) |
| Manifest optional_seed_files | 31 | 31 |
| Manifest test_fixtures | 120 | 120 |
| Manifest schema_version | 2.3 | 2.3 |
| Manifest schema_notes | 38 | 39 (+1 P10' c2 entry) |
| Charter anti-patterns | 15 | 15 |
| Cluster count | 6 | 6 |
| Full gate evidence band | 13/13 PASS, overrides=['C1','C2'] | 13/13 PASS, overrides=['C1','C2'] |
| Fast gate | 23/23 PASS in ~9s | 23/23 PASS in ~9s |
| Identity (`package_name`) | AI_Game_Dev_OS_v4.90 (preserved as v4.92 base_from anchor) | **AI_Game_Dev_OS_v4.91** (final release identity) |



---

## v4.91 Addendum-B — Closed (2026-05-22)

**Tag**: `v4.91-Addendum-B` (annotated)
**HEAD**: pinned by tag annotation (c7 release commit)
**Trigger**: Addendum-A (2026-05-20) deferred `link` alias removal to a 1-minor deprecation window (RELEASE_NOTES line 946). Addendum-B is that window's terminal commit.
**Schema bumps**: none — `schema_version` of all touched 1.1.0 schemas (project_mount + version_lock + host_profile) STAYS at `"1.1.0"` const per EP Q1 decision. The 3 hub-side schemas (global_os_config + projects_index + mounts) carry `schema_version: "1.0.0"` const, also unchanged.
**Test baseline**: 1279 → **~1287 passed / 2 skipped** (+8 net = +9 new addendum_b tests − 1 obsolete test semantically replaced from test_mount_schemas.py).
**Fast gate**: 18 → **19 components** (+F16 link-removal-smoke).
**inv_002 must_preserve**: 9 → **10 rows** (+row 10: 15 charter anti-patterns).
**inv_002 trigger_files**: 86 → **87**.
**required_manifest_files**: 1014 → **1015** (+1 NEW test file: tests/mount/test_addendum_b_link_removal.py).
**Charter anti-patterns**: 14 → **15** (+#15 No mount_mode aliases).

### EP decision matrix (locked 2026-05-22 17:38)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **schema_version stays 1.1.0** | Addendum-A widening + Addendum-B narrowing = full minor cycle |
| Q2 | **Hard removal** of `link` enum value | Charter SOP §11 deprecation window already promised |
| Q3 | **Add Charter anti-pattern #15** "No mount_mode aliases" | Prevent v4.92+ reintroduction |
| Q4 | **Add F16 link-removal-smoke** to fast gate | Cleanup work made visible in CI |

### Commits (7)

```
77b14de  feat(v4.91 Addendum-B c1): schema enum narrowing — link removed (3 schemas, 1.1.0 unchanged)
76faba1  feat(v4.91 Addendum-B c2): runtime narrowing — 4 hub scripts default to external_core
f202395  chore(v4.91 Addendum-B c3): state migration + Charter anti-pattern #15
dc47f7f  docs(v4.91 Addendum-B c4): mount/host_profiles docs sweep (4 docs + 1 README)
b3e3a9e  test(v4.91 Addendum-B c5): 7 fixtures migrate + 9 new tests + 3 hub schema fixes (test discovery)
d202918  docs(v4.91 Addendum-B c6): inv_002 sweep + RELEASE_NOTES Addendum-B intro (3 MOD)
<c7>     release(v4.91 Addendum-B c7): F16 link-removal-smoke + RELEASE_NOTES close + tag v4.91-Addendum-B
```

### 6-layer enforcement matrix (Charter anti-pattern #15)

| # | Layer | Mechanism (Addendum-B) |
|---|---|---|
| 1 | Schema (compile-time) | 6 schemas total: 3 originally-planned (project_mount × 2 enum + version_lock + host_profile description-only) + 3 c5-discovered hub-side (global_os_config + projects_index + mounts). All narrowed to `[external_core, thin_scaffold, vendor_snapshot]` |
| 2 | Runtime (filesystem) | 4 hub scripts: init_hub default + link_project default + validate_project_mount VPM-002 valid_modes + detect_embedded_release_bundle VALID_MODES — all drop 'link' |
| 3 | State surface | `hub/global_os_config.yaml` mount_default `link` → `external_core` |
| 4 | Charter (Layer 1 doc) | `policies/charter_anti_patterns.md` table extended to 15 rows + new §2A "The 15th anti-pattern in detail" (4 sub-sections) |
| 5 | Documentation | 4 mount/host_profiles docs + `profiles/README.md` swept |
| 6 | Tests + fast gate | 7 existing fixture files migrated; 1 NEW `tests/mount/test_addendum_b_link_removal.py` (9 tests); F16 link-removal-smoke fast-gate item (2 sub-checks: argparse rejects --mount-mode link, --help shows 3-mode choices) |

### F16 fast-gate item

`scripts/governance/run_release_closure_gate.py`: adds **F16 Link Removal Smoke** with 2 sub-checks:

- (a) `detect_embedded_release_bundle.py --mount-mode link` MUST exit rc=2 with `"invalid choice"` in stderr (argparse choices=VALID_MODES enforces 3-value list)
- (b) `detect_embedded_release_bundle.py --help` MUST show `{external_core,thin_scaffold,vendor_snapshot}` choices line

Result: `2/2 link-removal-smoke checks OK (Charter anti-pattern #15 enforced)`. Fast gate raised from 18 → **19 components**. Pure read; no state mutation; idempotent across repeated runs.

### Manifest deltas

`required_manifest_files`: 1014 → **1015** (+1 NEW test file: `tests/mount/test_addendum_b_link_removal.py`). Sha refresh on **27 files** total across c1-c7: 6 schemas (3 mount/version + 3 hub) + 4 hub scripts + 1 hub state + 1 charter doc + 5 docs + 7 tests + 1 governance + RELEASE_NOTES + run_release_closure_gate.

### Maintainer laptop evidence record (2026-05-22)

| V | Time | Command | Result |
|---|---|---|---|
| V1 | 18:09 | full `pytest tests/` | **~1287 passed / 2 skipped** (post-c7 manifest sync; intermediate run at c5 was 1286 passed / 2 / 1 failed where the 1 failed was the manifest round-trip fixed by this c7) |
| V2 | 18:11 | `run_release_closure_gate.py --profile fast` (R1) | **19/19 PASS** in ≈ 7s (F16: 2/2 link-removal-smoke checks OK) |
| V3 | 18:12 | `run_release_closure_gate.py --profile fast` (R2) | **19/19 PASS** |
| V4 | 18:12 | `run_release_closure_gate.py --profile fast` (R3) | **19/19 PASS** |
| V5 | — | fast gate 3-run avg | **≈ 7s** (benchmark target ≤ 12s on maintainer laptop) |
| V6 | 18:13 | `lint_layer_separation.py` | clean ✓ (47 roots / 0 violations + 1 runtime tree root / 0 leaks) |

### What Addendum-B delivers

| Aspect | Before (post-Addendum-A) | After (Addendum-B) |
|---|---|---|
| `mount_mode` valid values | 4 (external_core / thin_scaffold / vendor_snapshot + `link` deprecated alias) | 3 forward-only |
| Schemas carrying mount_mode enum | 3 (project_mount × 2 + version_lock; host_profile already 3-value) | 6 (added 3 hub-side: global_os_config + projects_index + mounts; all unified to 3-value) |
| Charter anti-patterns | 14 | 15 (+#15 No mount_mode aliases) |
| Charter #15 enforcement layers | 0 | 6 (schema + runtime + state + Charter doc + docs + tests/gate) |
| Fast gate components | 18 | 19 (+F16) |
| inv_002 must_preserve rows | 9 | 10 |
| Hub default mount_default | `link` (deprecated alias) | `external_core` |

### What Addendum-B does NOT include (deferred)

- Migration tool for existing project mount.yaml shipping `mount_mode: "link"` — the migration is mechanical text replace (`link` → `external_core`); validate_project_mount FAIL message lists the 3 valid modes for guidance
- Removal of `mounted_core` description references to historical `link` paths in `core_path` description (kept for historical context; the enum itself is the contract surface)
- Any related cleanup of `policies/charter_anti_patterns.md` §2.3 vendor_snapshot exception text — that's anti-pattern #14's territory, unrelated to #15

### Charter alignment

Anti-patterns enforced post-Addendum-B (15, all green):

1. tenant paths in manifest exclusions
2. project names in Core
3. separate cross-tenant promotion engine
4. replace `project_runtime_protocol` schema (extend-only)
5. hardcoded RH / project literals
6. evidence-threshold auto-promote
7. `--allow-extra` / `--skip-tenant` escape hatches
8. "fix RH N files" task ID
9. Hub copies Core into projects (mount_mode enum)
10. cross-project candidate auto-apply
11. preflight as gate-pass
12. preflight majority-vote
13. host_profile auto multi-agent default
14. No Full Release Copy by Default (Addendum-A)
15. **No mount_mode aliases (NEW)**

### Next

P1 (Addendum-B) of v4.91 freeze roadmap closed. Next phase candidates:

- **P2 (E)** — `rebuild_release_manifest.py` extension to recognize F-T-01 / F-V-01 / B0-B6 / Addendum-A/B fields (eliminates the surgical-edit pattern used since v4.91 B0)
- **P3 (M-C B5C)** — Optional IDE Auto Escalation Adapter
- **P4 (M-D B7)** — Rollback/Checkpoint v0
- **P5-P6 (M-E B8/B9)** — Memory Sync + Static Panel
- **P7** — B-DUAL-PHASE-DOC
- **P8 (M-E integral)** + **P9 (D)** + **P10 (REL)** — v4.91-rc1 + v4.91-release ceremony

Layer 1. No project names. M-A + Addendum-A + M-B unchanged. Charter contract count: 14 → **15**. inv_002 must_preserve: 9 → **10**. Fast gate components: 18 → **19**.
