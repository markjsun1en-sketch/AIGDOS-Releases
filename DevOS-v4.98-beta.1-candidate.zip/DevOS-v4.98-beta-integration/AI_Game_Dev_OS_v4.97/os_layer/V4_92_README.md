# AI Game Dev OS v4.92 Release README

> **Status**: `4.92-Release`
> **Package root**: `AI_Game_Dev_OS_v4.92_Release/`
> **Base**: `AI_Game_Dev_OS_v4.91_Release/`
> **Release tag**: `v4.92-release`

## What Changed

v4.92 turns the v4.91 runtime and governance base into a production capability
foundation:

1. capability protocol schemas for packs, agents, skills, validation evidence,
   production handoff, rollback notes, lead capability, and OS verdicts.
2. zero-dependency capability validators and boundary linting.
3. pack adoption runtime and active-pack reporting.
4. Godot 2D engine adapter and data-pipeline vertical slice.
5. B10-B12 agent / skill / evidence migration hardening.
6. B13 release-dir identity transition and v4.92-specific closure deliverable
   overlay.

## Release Identity

- `VERSION`: `4.92-Release`
- `RELEASE_MANIFEST.package_name`: `AI_Game_Dev_OS_v4.92`
- `RELEASE_MANIFEST.package_root_dir`: `AI_Game_Dev_OS_v4.92_Release`
- `RELEASE_MANIFEST.base_from`: `AI_Game_Dev_OS_v4.91_Release`
- `config/.core_os_root`: `v4.92-marker`

## Verification

Run from this directory:

```bash
python3 scripts/governance/run_release_closure_gate.py --profile full --format json
python3 scripts/governance/verify_release_clean_tree.py
python3 scripts/rebuild_release_manifest.py --check
shasum -a 256 -q -c CHECKSUMS.sha
```
