# Static Runtime Panel Export — Adoption Notes

> **Layer 1 (OS Spec) — adoption surface.** v4.91 P6 / Milestone E B9.
>
> **Script**: [`scripts/panel/export_static_panel.py`](../../scripts/panel/export_static_panel.py)
>
> **Templates**: [`templates/panel/*.html.tmpl`](../../templates/panel/) — 6 templates (one per page kind)
>
> **Tests**: [`tests/panel/`](../../tests/panel/) — 11 tests (7 idempotence/lifecycle + 4 inv_011 guards)
>
> **Fast-gate item**: F20 `Panel export smoke (v4.91 M-E B9)`
>
> **Invariant**: [`inv_011_panel_no_runtime_mutation`](../../runtime/protected_contracts/protected_regression_matrix.yaml)
>
> **Sister docs**: [`PAGE_REFERENCE.md`](PAGE_REFERENCE.md)

---

## 1. Why this directory exists

`docs/25_panel_export/` is the Layer 1 adoption companion to the
static runtime panel introduced in v4.91 M-E B9. It documents:

- the **6 page kinds** the exporter emits and what each one shows;
- the **read-only contract** the panel honours with respect to
  runtime state (Charter anti-pattern #6 + #11 + #14);
- the **adoption flow** — when to run the panel, where the output
  lands, who consumes it.

## 2. Plain-English summary

The static panel is a snapshot generator: at any time, an EP /
operator runs `python3 scripts/panel/export_static_panel.py` and
gets a directory of static HTML pages summarising hub state,
project linkages, LTM ledgers, version-lock state, and preflight
governance. The pages are read-only HTML — no JavaScript, no AJAX,
no external assets — and the script that produces them is
**strictly read-only with respect to runtime state**.

Default output: `<repo_root>/exports/panel/`. The `exports/` root
is classified as `generated_runtime_outputs` and is gitignored, so
the panel's HTML is never committed.

## 3. The 6 page kinds

| File | Source | What it shows |
|------|--------|----------------|
| `hub_overview.html` | `hub/hub_state.json` + `hub/projects.index.json` | Hub identity (id, status, linked_project_count, updated_at) + linked-projects table. |
| `project_status_<pid>.html` | `hub/projects.index.json` (per project entry) | Per-project identity (project_id, mount_mode, core_version, linked_at, last_health_check) + adoption rollup placeholder. **Omitted when no projects are linked.** |
| `cross_project_candidates.html` | `ltm/cross_project/{candidates,approved_patterns,rejected,superseded}/` | Lifecycle counts + recent candidates table (file name + size). Charter #6 disclaimer at footer. |
| `memory_health.html` | `ltm/{os,pattern,failures,_quarantine,cross_project/candidates}/` + `ltm/{promote,reject,supersede}_ledger.jsonl` | LTM domain counts + quarantine count + promote/reject/supersede ledger sizes. |
| `version_lock_status.html` | `RELEASE_MANIFEST.json` + `VERSION` + `hub/projects.index.json` | Core abstract identity (VERSION + manifest_schema_version + required/optional/test_fixtures counts) + per-project version_lock state. |
| `preflight_governance.html` | `ltm/preflight/cases/*.json` + `runtime/protected_contracts/protected_regression_matrix.yaml` | Preflight cases by outcome + recent cases table + protected invariant summary (active count + latest id). |

## 4. Charter alignment (where each anti-pattern lands)

| # | Anti-pattern | Where enforced |
|---|---|---|
| 5 | Core does not bind to project narrative | Templates contain only generic placeholders; project_id is read opaquely from `hub/projects.index.json` and sanitised to `[a-zA-Z0-9_-]` before becoming part of an output filename. |
| 6 | No auto-promote into retrieval policy | inv_011 must_preserve item-2 forbids imports of `retrieval_policy` / `promotion_policy` / `promote_*` / `reject_*` / `supersede_*` / `capture_*` / `create_checkpoint` / `generate_rollback_plan` / `verify_rollback` / `sprint_close_hook` / `generate_preflight_summary` / `run_preflight_consensus` / `lock_core_version` / `link_project` / `init_hub` / `rebuild_release_manifest`. The panel reports counts and lifecycle states; it never advances them. |
| 7 | No escape hatches | scripts/panel/ has zero `--apply` / `--execute` / `--auto-confirm` / `--force` / `--skip-confirm` / `--bypass` / `--allow-extra` / `--run` / `--do-apply` flags; the regex sweep in `tests/panel/test_no_runtime_mutation.py` catches drift at build time. |
| 11 | Reporting != closure-gate pass | F20 emits COMPLETION evidence (script ran + N pages); the smoke explicitly does NOT assert that the panel contents are semantically correct or that any decision was authorised. The HTML pages themselves carry "panel never mutates runtime state" notes in their footers. |
| 14 | No full release copy by default | Panel output is HTML pages with embedded counts and pointer references (paths, file names, IDs); the panel never embeds the body of an underlying ledger entry. Output stays under `exports/panel/` (host-side gitignored). |

## 5. Read-only-with-respect-to-runtime-state contract

The panel is allowed to:

- read JSON / YAML / Markdown / JSONL files anywhere in the repo;
- compute counts, sizes, and other derived values;
- write HTML files into the declared `--out-dir` path.

The panel is **NOT** allowed to:

- write to any path outside `--out-dir`;
- import any state-mutating engine (see inv_011 must_preserve);
- use `shutil.rmtree` / `shutil.move` / `shutil.copy` / `os.system` /
  `subprocess.run` / `subprocess.call` / `subprocess.Popen` /
  `os.unlink` / `os.remove`;
- accept `--apply` / `--execute` / `--auto-confirm` / `--force` /
  `--skip-confirm` / `--bypass` / `--allow-extra` / `--run` /
  `--do-apply` flags.

These constraints are doubly enforced: by `inv_011` at the matrix
layer (gate-time) and by `tests/panel/test_no_runtime_mutation.py`
at the build layer (compile-time).

## 6. Adoption flow

A host project / EP / operator typically uses the panel as
follows:

1. Run the gate (or any other state-changing operation) and let
   the resulting state settle.
2. Run `python3 scripts/panel/export_static_panel.py`.
3. Open `exports/panel/hub_overview.html` (or any other page) in
   a browser; navigate by linked filenames.
4. Optionally archive the output directory as part of a release
   evidence bundle (P10 ceremony does this once per Core version,
   never inside an in-progress freeze; see MEMORY contract #16).

The panel's primary consumer is the human operator. There is no
machine consumer that reads the panel HTML — that would create the
exact reporting -> auto-promote feedback the Charter forbids.

## 7. What NOT to do

- **Do NOT** write a parser that reads `hub_overview.html` and
  drives an automation. The HTML is for human review; for
  programmatic access, read the JSON SoT files directly.
- **Do NOT** add a `--cron` / `--watch` / `--daemon` mode to the
  exporter. The panel is a one-shot snapshot generator; if you
  need a poll loop, the host project's outer scheduler handles
  that.
- **Do NOT** embed the body of an LTM entry, a preflight case, or
  a recovery plan into a panel page. The panel cites by path /
  count / id only (Charter #14).
- **Do NOT** treat F20 PASS as evidence that any host decision
  was authorised. F20 confirms the script ran; the page contents
  carry their own "panel never authorises" disclaimer (Charter
  #11).

## 8. Cross-references

- Script: `scripts/panel/export_static_panel.py`
- Templates: `templates/panel/{hub_overview,project_status,cross_project_candidates,memory_health,version_lock_status,preflight_governance}.html.tmpl`
- Tests: `tests/panel/{test_export_idempotent,test_no_runtime_mutation}.py`
- Invariant: `inv_011_panel_no_runtime_mutation`
- Fast-gate item: F20 `Panel export smoke (v4.91 M-E B9)`
- Adjacent invariants: inv_010 (memory sync no-auto-promote),
  inv_009 (recovery no-auto-rollback), inv_002 (Layer 1 separation).
