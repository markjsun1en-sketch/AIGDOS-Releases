# Panel Page Reference

> **Layer 1 (OS Spec).** v4.91 P6 / Milestone E B9.
>
> Sister doc: [`README.md`](README.md)

---

## 1. Page-by-page field reference

### 1.1 `hub_overview.html`

Heading + meta + 2 sections.

| Section | Fields | Source |
|---------|--------|--------|
| Hub identity | hub_id / hub_status / linked_project_count / updated_at | `hub/hub_state.json` |
| Linked projects | project_id / mount_mode / core_version / linked_at | `hub/projects.index.json::projects[]` |

`hub_status` carries a colour class (ok / warn / bad). When the
status is `active` the page renders ok-green; `uninitialised`
renders warn-amber; anything else falls through to warn.

### 1.2 `project_status_<project_id>.html`

One file per linked project. The `<project_id>` portion of the
filename is sanitised to `[a-zA-Z0-9_-]` characters; opaque IDs
that contain other chars are coerced to `unknown`.

| Section | Fields | Source |
|---------|--------|--------|
| Identity | project_id / mount_mode / core_version / linked_at / last_health_check | `hub/projects.index.json::projects[]` (matched by project_id) |
| Adoption summary | (placeholder; populated when adoption rollup data attaches in a future batch) | future |

### 1.3 `cross_project_candidates.html`

| Section | Fields | Source |
|---------|--------|--------|
| Counts by lifecycle | candidates / approved_patterns / rejected / superseded | file counts under `ltm/cross_project/{candidates,approved_patterns,rejected,superseded}/` (`.json` + `.md`) |
| Recent candidates | file name + size | first 20 entries in `ltm/cross_project/candidates/` |

The footer carries the Charter #6 disclaimer: "panel never
mutates retrieval policy".

### 1.4 `memory_health.html`

3 tables.

| Table | Fields | Source |
|-------|--------|--------|
| Ledger counts by domain | os / pattern / failures / cross_project (candidates) | file counts under `ltm/{os,pattern,failures,cross_project/candidates}/` |
| Quarantine | quarantine count | file count under `ltm/_quarantine/` |
| Promotion lifecycle ledgers | promote / reject / supersede | line counts in `ltm/{promote,reject,supersede}_ledger.jsonl` |

### 1.5 `version_lock_status.html`

| Section | Fields | Source |
|---------|--------|--------|
| Core abstract identity | VERSION / manifest_schema_version / required_manifest_count / optional_seed_count / test_fixtures_count | `VERSION` + `RELEASE_MANIFEST.json` |
| Per-project version_lock state | project_id / locked_core_version / mount_mode | `hub/projects.index.json` |

### 1.6 `preflight_governance.html`

| Section | Fields | Source |
|---------|--------|--------|
| Preflight cases by outcome | approved / rejected / deferred counts | walk over `ltm/preflight/cases/*.json` summing `consensus.outcome` |
| Recent cases | case_id / trigger / outcome / decided_by / generated_at (first 20) | same source, columns from each case |
| Protected invariants | active count + latest id | `runtime/protected_contracts/protected_regression_matrix.yaml::invariants[]` |

The footer carries the Charter #11 + #12 disclaimer: "panel never
authorises preflight outcomes".

## 2. Placeholder behaviour

When a SoT file is missing:

- `hub/hub_state.json` missing → page renders with "—" placeholders
  for every hub field.
- `hub/projects.index.json` missing → no project_status pages;
  hub_overview shows "No projects linked".
- `RELEASE_MANIFEST.json` missing → version_lock_status shows "—"
  for the Core abstract identity counts.
- `runtime/protected_contracts/protected_regression_matrix.yaml`
  missing → preflight_governance shows 0 invariants and "—" latest.
- `ltm/<subdir>/` missing → counts read 0.

This best-effort posture is intentional: an uninitialised hub
should still produce a useful (if largely empty) panel rather
than crash the exporter.

## 3. Output filename rules

| File kind | Pattern | Notes |
|-----------|---------|-------|
| Fixed pages | `<page>.html` | 5 fixed pages always emitted: hub_overview, cross_project_candidates, memory_health, version_lock_status, preflight_governance. |
| Project status | `project_status_<safe_pid>.html` | One per entry in `hub/projects.index.json::projects[]`. `<safe_pid>` = the project_id with non-`[a-zA-Z0-9_-]` chars stripped. Empty / fully-stripped IDs become `unknown`. |

## 4. Determinism

The exporter is deterministic modulo the `GENERATED_AT` timestamp:
two consecutive runs against the same SoT state produce
byte-identical output if the timestamp is normalised. The test
suite covers this in
`tests/panel/test_export_idempotent.py::test_idempotent_modulo_timestamp`.

## 5. CSS and layout

All 6 templates carry the same inline `<style>` block (no shared
asset, no external CSS) so each page is self-contained and can be
opened from a file:// URL with no further dependencies. The
visual style is intentionally minimal — system font stack, plain
tables, low-contrast borders, no JavaScript.

## 6. Future page kinds (deferred)

Page kinds explicitly NOT in v4.91 M-E B9:

- `evolution_proposals.html` — would surface
  `proposals/` + `evolution/` lifecycle. Deferred until Self-Evolution
  reaches a stable state model in a later batch.
- `host_profiles.html` — would surface `profiles/*.yaml` adoption
  boundaries. Deferred until host_profile schema reaches v1.1+ with
  per-tool feature matrices.
- `subagent_routing_decisions.html` — would surface
  `runtime/registries/delegation_decision_ledger.jsonl`. Deferred
  until the ledger has enough volume to warrant aggregate views.

Adding a new page kind is a contract change requiring EP +
matrix-owner approval (because inv_011 must_preserve item-5 fixes
the page-kind list at 6).
