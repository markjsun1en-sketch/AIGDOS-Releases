---
title: Minimal Hooks
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: B7
---

# Minimal Hooks — v4.92 (R7 anti-line-break)

> **Layer**: Layer 1 — Capability Protocol Layer (Charter §5.3 / roadmap R7).
> **Status**: active reservation (v4.92 Batch 7). **Stubs**: `capability_protocols/hooks/`.

---

## 1. Why

v4.92 deferred the six original roadmap mainlines (Shared Truth / Architecture
Baseline / DB-RAG / Teamwork / Observability / Pack Registry) to v4.93+. To
prevent a future **interface break** — where v4.93 invents a brand-new surface
that doesn't compose with v4.92 — Batch 7 reserves five minimal hook stubs now.

A stub is an **interface only**: a minimal, forward-compatible schema with no
runtime reader/writer. When v4.93 implements a mainline, it *extends the stub*
rather than starting fresh.

## 2. The five hooks

| Stub | Reserves | v4.93+ mainline |
|---|---|---|
| `truth_map.stub.schema.json` | project fact index (canonical source + owner) | Shared Truth |
| `architecture_scan.stub.schema.json` | module + dependency scan record | Architecture Baseline |
| `event_trace.stub.schema.json` | observed pack/task event entry | Observability |
| `owner_approval.stub.schema.json` | owner + approval marker | Teamwork / Review Queue |
| `pack_evidence_metadata.stub.schema.json` | per-pack registry summary | Pack Registry / DB-RAG |

## 3. Reservation discipline

- every stub is draft-07 valid, `additionalProperties: false`,
  `schema_version: "0.0.1-stub"`, and carries a `_deferred` marker
  (`since: v4.92`, `implement_in: v4.93+`, `mainline: ...`);
- **nothing in v4.92 reads or writes these** — reservation only;
- a stub MUST NOT grow logic in v4.92. If a task seems to need one, the work
  belongs in v4.93, not here (R1 anti-bloat).

## 4. Verification

`tests/capability/test_minimal_hooks.py` asserts all five exist, are draft-07
valid, declare no-sprawl + `_deferred`, and are listed in the hooks README.
