---
title: Boundary Governance
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: B2
---

# Boundary Governance — v4.92

> **Layer**: Layer 1 — Capability Protocol Layer (Implementation Plan §16, §18, §20, §22).
> **Status**: active (v4.92 Batch 2 P0-5). **Tool**: `scripts/capability/run_boundary_linter.py`.

---

## 1. Principle

```
Cognitive boundaries may overlap.
Execution boundaries may not.
```

Two agents may both *advise* on combat readability; only one may *own* the combat runtime file. The boundary linter enforces the execution side across a **set** of contract instances — the relational checks a per-instance schema cannot express.

## 2. Checks (§22.1)

| Rule | Fires when |
|---|---|
| `B1_over_broad_write` | an `allowed_writes`/`can_modify` entry is an over-broad root (`res://**`, `res://src/**`, `**`, `/`, `game/**`, …) — ownership undecidable |
| `B2_dual_owns` | two agents list the same canonical concern in `owns[]` |
| `B4_allow_forbid_overlap` | within one instance, an allowed write glob overlaps a forbidden write glob |
| `B5_shared_path_no_policy` | two instances write the same path and no pack `collision_policy` covers it |
| `B6_writes_core` | an instance can write an OS Core path (forbidden unless `layer == os_governance_agent`) |
| `B6_core_not_forbidden` | a pack/skill does not list any Core path in `forbidden_writes` |
| `B7_dependency_cycle` | the pack `depends_on` graph contains a cycle |

## 3. Ownership resolution (§16.3, §20)

When instances conflict, resolve by:

```
1. Canonical artifact owner wins
2. Write boundary > advice boundary
3. Runtime truth > UI display
4. Schema owner > data consumer
5. Project-local owner > shared pack
6. Human owner decision > automatic routing
```

The linter does not auto-resolve — it **surfaces** the conflict so a human (or the pack's `collision_policy`) decides.

## 4. Shared paths need a policy (§18)

If two units legitimately write the same tree, the owning pack must declare it:

```yaml
collision_policy:
  shared_paths:
    - path: "game/data/cards/**"
      primary_owner: card_data_schema_skill
      shared_with: [card_balance_skill]
      field_level:
        can_modify_fields: [cost, damage]
        must_not_modify_fields: [effect_type, runtime_id]
```

A shared path **without** such an entry is a `B5` violation.

## 5. Conservative glob overlap

The linter uses a deliberately conservative prefix-up-to-`**` overlap test (no full glob algebra in a zero-dep tool). It errs toward flagging — a flagged-but-benign overlap is resolved by narrowing the glob or adding a `collision_policy`, both of which improve the contract.

## 6. Exit codes & zero-dependency

| Exit | Meaning |
|---|---|
| 0 | no boundary violations |
| 1 | violations found |
| 3 | internal error |
| 4 | input missing |

Runs under **bare `python3`** (verified by `tests/capability/test_boundary_linter.py`). Accepts files or directories; auto-classifies each instance as pack/agent/skill by its fields.

## 7. Usage

```bash
python3 scripts/capability/run_boundary_linter.py packs/ agents/ skills/
python3 scripts/capability/run_boundary_linter.py --json pack_a.json agent_b.yaml
```
