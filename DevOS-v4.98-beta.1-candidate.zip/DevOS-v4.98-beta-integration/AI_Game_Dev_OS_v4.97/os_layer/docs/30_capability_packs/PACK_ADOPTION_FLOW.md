---
title: Pack Adoption Flow
version: 1.1
status: active
layer: layer_1_os_spec
since_batch: B3
---

# Pack Adoption Flow — v4.92

> **Layer**: Layer 1 — Capability Protocol Layer (Implementation Plan §9, §25 Phase 4).
> **Status**: active (v4.92 Batch 3 P0-6/7). **Tool**: `scripts/capability/adopt_pack.py`.
> **Schemas**: `schemas/adoption/capability_pack_adoption_state.schema.json` (P0-6) · `schemas/adoption/capability_pack_lock.schema.json` (P0-7).

---

## 1. Two parallel adoption tracks

v4.92 introduces a **capability-pack** adoption track. It is **parallel to and independent of** the existing v4.90 **agent-pack** track. They never mix.

| | agent-pack (v4.90) | capability-pack (v4.92) |
|---|---|---|
| project file | `04_active_packs.yaml` | `capability_active_packs.json` |
| schema | `schemas/adoption/active_packs.schema.json` | `schemas/adoption/capability_pack_adoption_state.schema.json` |
| pack_id form | `ap_YYYY_NNN` | lowercase snake_case (`data_pipeline_pack`) |
| tool | (agent library) | `adopt_pack.py` |

EP decision (2026-05-31, Batch 3 Q1=A): a new track, not an extension of the agent-pack schema. Reuses the v4.91 capability_adoption **pattern** (state machine + zero-dep + project-id guard), not its capability-migration scoring.

## 2. The flow

```
recommend -> adopt -> validate -> lock -> (use)
```

| Step | Action | State transition | Side effect |
|---|---|---|---|
| recommend | check eligibility (read-only) | — | none |
| adopt | activate (if eligible) | `(absent)` → `adopting` | writes `capability_active_packs.json` |
| validate | boundary-lint + record evidence | `adopting` → `adopted` | writes `validation_evidence/<pack>.validation.json` |
| lock | pin version + sha256 + evidence | `adopted` → `verified` | writes `pack_locks/<pack>.lock.json` |

## 3. Adoption state machine

```
(absent) -> recommended -> adopting -> adopted -> verified
any -> blocked        (requires blocked_reason)
any -> disabled
blocked/disabled -> adopting   (re-entry)
```

`adopt_pack.py` enforces transition legality at write time (a project-side schema cannot compare against prior state). `verified` is the terminal "in use" state and **requires** both a `lock_ref` and ≥1 `validation_evidence_refs` (enforced by the schema's `allOf`).

## 4. Eligibility gate

A pack is adoptable only when:

- `lifecycle_status` is **not** `draft` (draft packs are never project-adoptable), and not `deprecated`/`retired`;
- `lifecycle_status` ≥ `adoption.min_lifecycle_for_project_adoption` (default `beta`).

`recommend` and `adopt` both apply this gate.

## 5. Pack lock + evidence (P0-7)

The lock record pins the verified state for audit/reproducibility:

```json
{
  "schema_version": "1.0.0",
  "pack_id": "data_pipeline_pack",
  "locked_version": "0.1.0",
  "locked_at": "...Z",
  "manifest_sha256": "<64 hex>",
  "validation_evidence": ["validation_evidence/data_pipeline_pack.validation.json"]
}
```

`manifest_sha256` is the digest of the pack manifest bytes at lock time — drift means the pack changed under the project's feet. `validation_evidence` is non-empty by schema: a lock without evidence is not a lock.

## 6. Exit codes & zero-dependency

| Exit | Meaning |
|---|---|
| 0 | action succeeded / pack eligible |
| 1 | refused (ineligible / illegal transition / lint fail) |
| 2 | usage error (bad project-id) |
| 3 | internal error |
| 4 | input missing |

Runs under **bare `python3`** (verified by `tests/capability/test_adopt_pack.py`). Reuses the boundary linter (P0-5) at the validate step. `--project-id` rejects project proper-names (Layer 1 protection).

## 7. Usage

```bash
python3 scripts/capability/adopt_pack.py recommend pack_manifest.json \
    --project-dir .ai_dev_os --project-id my_project
python3 scripts/capability/adopt_pack.py adopt    pack_manifest.json --project-dir .ai_dev_os --project-id my_project
python3 scripts/capability/adopt_pack.py validate pack_manifest.json --project-dir .ai_dev_os --project-id my_project
python3 scripts/capability/adopt_pack.py lock     pack_manifest.json --project-dir .ai_dev_os --project-id my_project
```

## 8. Companion tools (§25 Phase 4)

`adopt_pack.py` drives a single pack through its lifecycle. Three companion
tools (Batch 5.5) cover discovery and after-the-fact auditing. All are
zero-dep and reuse `adopt_pack.py`'s helpers, so their views never diverge.

| Tool | Role | Reads | Exit |
|---|---|---|---|
| `list_available_packs.py` | discover every `packs/**/capability_pack.json` and report adoptability (same eligibility gate as `recommend`) | `packs/` | 0 ok / 4 missing dir |
| `validate_active_packs.py` | read-side audit of a project's `capability_active_packs.json` vs shipped packs | project + `packs/` | 0 consistent / 1 issues / 4 missing |
| `export_pack_report.py` | join available + active + consistency into one JSON/Markdown report | project + `packs/` | 0 clean / 1 issues |

`validate_active_packs.py` is the **read-side complement** to `adopt_pack.py`:
the adoption tool enforces transition legality *at write time*, but cannot see
drift that happens afterwards. The validator catches:

- **orphan** — an active entry whose pack no longer ships under `packs/`;
- **version_drift** — active entry version ≠ shipped manifest version;
- **incomplete_verified** — a `verified` entry missing `lock_ref` or
  `validation_evidence_refs`;
- **lock_drift** — the lock's recorded `manifest_sha256` no longer matches the
  current manifest bytes (the pack changed under the project's feet).

```bash
python3 scripts/capability/list_available_packs.py --json
python3 scripts/capability/validate_active_packs.py --project-dir .ai_dev_os
python3 scripts/capability/export_pack_report.py --project-dir .ai_dev_os --markdown
```
