---
title: Data Pipeline Pack
version: 1.1
status: active
layer: layer_1_os_spec
since_batch: B5
---

# Data Pipeline Pack — v4.92 (Vertical Slice)

> **Layer**: Layer 3 — Game System Pack (roadmap §7). This doc is Layer 1 OS spec describing the pack.
> **Status**: active (v4.92 Batch 5 P0-9). **Pack**: `packs/game_system_packs/data_pipeline/`.
> **The v4.92 vertical slice** — first game-system pack; depends on `godot_2d_adapter`; validated against a real target project.

---

## 1. Why this slice

Three independent scouts (v4.91 skill audit / a card-roguelite project / the target Slot+Roguelike project) converged on the same conclusion: **the data pipeline (source tables → runtime data) is the shared pain point of numeric Godot games**, not card battle. So the documented "Card Battle Runtime" slice was replaced (EP ruling) with this **Data Pipeline Pack**.

## 2. Capability

Convert multi-sheet xlsx source tables into runtime JSON with:

- **nested + array-element injection** (`$key` path segments) — the capability a naive `dict.setdefault` walker lacks;
- **schema validation** with id/numeric conflict detection;
- **Monte Carlo gating** — wrap an isolated balance script as a blocking pipeline step.

## 3. Contents

```
packs/game_system_packs/data_pipeline/
  capability_pack.json              # layer=game_system_pack, depends_on godot_2d_adapter
  agents/data_pipeline_engineer.json
  skills/
    xlsx_to_json_skill.json         # the $key array-injection conversion
    schema_validation_skill.json
    pity_integration_skill.json
  reference/
    nested_set.py                   # set_nested_value v2 with $key injection
    schema_check.py                 # zero-dep JSON-vs-schema + id conflicts
    pity_gate.py                    # Monte Carlo -> pipeline gate wrapper
    output_adapter.py               # OutputAdapter interface + AdapterResult
    adapter_contract.py             # check_adapter() — the compliance bar
    json_adapter.py                 # first concrete adapter (dict -> JSON)
```

## 4. The core fix (`$key` array injection)

A path segment `$<field>` means **array-element injection**:

```
["heroes", "$hero_id", "animations"]
```

→ group the incoming rows by `hero_id`, find the `heroes[]` element whose
`hero_id` matches, and write the remaining sub-path (`animations`) into it,
indexed by a row key (`state`). Unmatched keys raise rather than silently
dropping rows. See `reference/nested_set.py`.

## 5. Target validation (acceptance evidence)

Applied to the real target project (independent git repo), Sprint 10's
`set_nested_value` fix:

| Step | Result |
|---|---|
| fix `set_nested_value` to support `$key` | done (target `policy/tools/data/xlsx_to_json.py`) |
| remove `skip_convert` from the `heroes` table | done (target manifest) |
| add a `heroes` post-processor (flat columns → nested `base_stats`/`growth`/`leveling`, `hero_id`→`id`, split `frame_paths`) | done |
| regenerate `heroes.json` from xlsx | done; `id`/`base_stats`/`growth`/`leveling` **equivalent** to the hand-merged file; 9 animation + 9 sfx states |
| wire the pity Monte Carlo into a gate | done; `pity_gate` returns PASS on `ALL TESTS PASSED` sentinel |
| **full chain**: edit one xlsx field → auto-convert → validate → runtime data updated | **PASS** (base_hp 100→150 propagated to `base_stats.hp`) |

Full acceptance log: `V4_92_B5_DATA_PIPELINE_ACCEPTANCE.md`.

## 6. Runtime-contract caution (lesson)

The xlsx exports **flat** columns (`base_hp`); the runtime reads **nested**
(`config.base_stats.hp`). A naive auto-convert would have broken the running
game. The pack's reshape post-processor bridges the source-table shape and the
runtime contract — auto-generation must preserve the runtime contract, not just
produce *some* JSON.

## 7. Output Adapter — the terminal format is a true abstraction (P0-9)

The pipeline's core — `set_nested_value`, the flat→nested reshape, and
`schema_check.validate` — is **already format-agnostic**: it all operates on
plain `dict` payloads, and the only format-bound step is the final
serialization. B5.5 formalizes that step as a contracted, **pluggable**
`OutputAdapter` interface, so the *terminal format* is swappable rather than
hardwired to JSON.

**This is a real abstraction, not a decorative `output_target` enum.** An
adapter is any object exposing:

```python
name: str                 # e.g. "json"
target_extension: str     # e.g. ".json" (leading dot)
def write(payload: dict, out_path, *, meta=None) -> AdapterResult: ...
```

`reference/adapter_contract.py::check_adapter(adapter, payload, reparse)` is
the **single compliance bar** every adapter must clear: it writes a file,
returns a well-formed `AdapterResult` (`ok` / `path` / `bytes_written` /
`verdict == "WRITE_OK"`), matches its declared extension, round-trips back to
an equivalent dict, and is deterministic (two writes → byte-identical). Two
negative tests prove the contract *rejects* a non-compliant adapter — so the
bar has teeth.

`reference/json_adapter.py` is the **first and (until a real target demands
otherwise) only** concrete implementation: it persists the payload as JSON
with the Godot runtime conventions (`indent=2`, `ensure_ascii=False`, trailing
newline, source-order preserved). It does **not** reshape or validate — that is
upstream and format-independent; the adapter only writes the already-correct
payload.

### Adding a new terminal format (e.g. SQLite) — step by step

The hard test for a true abstraction: **adding a format must not touch any
existing pack code.** To add a SQLite output:

1. Create one new file, `reference/sqlite_adapter.py`, with a class exposing
   `name = "sqlite"`, `target_extension = ".db"` (or `.sqlite`), and a
   `write(payload, out_path, *, meta=None) -> AdapterResult` that serializes
   the dict into a SQLite file (returning `WRITE_OK` / `bytes_written`).
2. Provide a `reparse(path)` that reads the SQLite artifact back into the same
   dict shape (round-trip equivalence is format-specific; the *requirement* is
   universal).
3. Add a test that calls
   `adapter_contract.check_adapter(SqliteAdapter(), sample_payload, reparse)`
   and asserts no violations.
4. Done. **Zero changes** to `output_adapter.py`, `json_adapter.py`,
   `nested_set.py`, the reshape, or `schema_check.py`. The caller selects an
   adapter; everything upstream is untouched.

We deliberately **do not** ship an empty SQLite/`.tres` adapter now: an
implementation with no real target to validate against is speculation (YAGNI +
the pack's target-driven discipline). The interface + contract make that future
work a *bounded, verifiable* task rather than a rewrite.

## 8. Validation


```bash
python3 scripts/capability/validate_data_pipeline_pack.py \
    packs/game_system_packs/data_pipeline/capability_pack.json
```

Zero-dep (bare python3). Checks game-system-pack shape, engine-adapter
dependency, skill/agent cross-refs, boundary-linter cleanliness, and that the
reference implementations import cleanly.

## 9. Acceptance (Charter §5.2 P0-9)

| Item | Met |
|---|---|
| xlsx → JSON with nested + array injection | ✓ `nested_set.py`, target heroes regenerated |
| schema validation + conflict detection | ✓ `schema_check.py` |
| fix `set_nested_value` array nesting | ✓ target fix + `test_data_pipeline_pack` heroes-shape unit test |
| pity Monte Carlo into the pipeline | ✓ `pity_gate.py`, target gate PASS |
| full chain edit→convert→validate→update | ✓ acceptance PASS |
| output format not hardwired (B5.5) | ✓ `OutputAdapter` interface + `check_adapter` contract; JSON is the first impl; `.tres`/SQLite = a one-file interface implementation driven by a real target, **not** a pack rewrite |

> **P0-9 deviation note.** The Charter §5.2 text named ".tres + type mapping"
> as an output target. The real target project is a **pure-JSON runtime** (zero
> `.tres`), so producing `.tres` would have violated the pack's target-driven
> discipline and broken nothing real. EP ruling (2026-05-31, 4-round
> convergence): rather than hardwire JSON *or* speculatively build a `.tres`
> adapter, **abstract the output stage** (interface + contract + JSON impl).
> `.tres`/SQLite become future interface implementations gated on a real target
> that uses them — see §7.
