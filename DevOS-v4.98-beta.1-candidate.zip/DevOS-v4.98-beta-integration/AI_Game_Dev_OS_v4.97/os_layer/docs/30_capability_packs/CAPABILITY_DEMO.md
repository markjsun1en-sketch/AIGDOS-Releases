---
title: Capability Foundation Demo
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: B8
---

# Capability Foundation Demo — v4.92 (Batch 8)

> **Layer**: Layer 1 — Capability Protocol Layer.
> **Runner**: `scripts/capability/run_capability_demo.py` (zero-dependency).
> **Test**: `tests/capability/test_capability_demo.py`.
> **Evidence summary**: `V4_92_B8_DEMO_EVIDENCE.md` (tree root).

## Purpose

A single reproducible walkthrough that strings the whole v4.92 capability stack
(Batches 1–6) into one run against the two real packs shipped in this tree. It
exists so a reviewer can verify the foundation works **end to end** with one
command, instead of inspecting each batch in isolation.

## How to run

```bash
cd AI_Game_Dev_OS_v4.92
python3 scripts/capability/run_capability_demo.py          # human-readable
python3 scripts/capability/run_capability_demo.py --json   # machine summary
```

Exit code `0` and a trailing `DEMO_OK` line indicate success; `1` + `DEMO_FAIL`
means a step failed; `3` is an internal error. The demo runs entirely in a
`TemporaryDirectory` and never writes the OS tree.

## The five steps

| Step | Batch | What it proves |
|---|---|---|
| 1. `$key` array injection | B5 | `set_nested_value` v2 groups rows by a field, matches the array element, indexes by `state`, and raises on an unmatched key (never drops rows). |
| 2. boundary linter | B2 | Both packs (godot_2d adapter, data_pipeline) pass cross-instance boundary checks. |
| 2. practicality gate | B2 | The 3 data_pipeline skills clear the content-quality gate. |
| 3. adopt → verified | B3 | `recommend → adopt → validate → lock` drives the pack to `adoption_status=verified` with a lock in a fresh project dir. |
| 4. three-piece evidence | B6 | A rollback note + validation evidence are recorded and `verify` confirms a complete set. |

Because the packs embody B1's three contract schemas, a clean step 2 is also
implicit proof of B1.

## Zero-dependency proof

The runner invokes its sub-tools with `sys.executable` — the same interpreter
that launched it. Running the demo under the managed `python3` (which has no
`jsonschema`) therefore proves the entire chained stack is zero-dependency. The
test asserts both a normal run and a bare-interpreter run reach `DEMO_OK`.

## Sentinel convention

Like the headless-smoke contract (B4), the demo prints `DEMO_OK` / `DEMO_FAIL`
on stdout so an outer harness can gate on a grep'd sentinel rather than relying
solely on the exit code.
