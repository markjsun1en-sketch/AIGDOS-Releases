---
title: Skill Contract Standard
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: B1
---

# Skill Contract Standard — v4.92

> **Layer**: Layer 1 — Capability Protocol Layer (Implementation Plan §12, §13, §15, §21).
> **Status**: active (v4.92 Batch 1 P0-3). **Canonical schema**: `capability_protocols/skill_contract.schema.json`.

---

## 1. A skill must land, not just describe

A skill contract binds a skill to a **real input**, an **allowed write path**, a **forbidden write path**, a **required output**, **execution steps**, **validation**, **failure handling**, **rollback**, a **minimal example**, and a **non-completion counter-example**. This encodes the Practicality Gate minimum (§12.2 / §21) directly as schema `required[]`.

A skill instance missing any of these can only enter `draft` — never `beta`/`stable`.

## 2. Required fields (= Practicality Gate minimum)

`schema_version` · `skill_id` · `pack_id` · `status` · `use_when` · `required_inputs` · `allowed_writes` · `forbidden_writes` · `required_outputs` · `execution_steps` · `validation_commands` · `failure_handling` · `non_completion_conditions` · `example_task`.

| Practicality Gate item | Schema field |
|---|---|
| a real input | `required_inputs` (≥1) |
| an allowed write path | `allowed_writes` (≥1) |
| a forbidden write path | `forbidden_writes` (≥1) |
| a required artifact | `required_outputs` (≥1) |
| a validation command/method | `validation_commands` (≥1) |
| failure handling | `failure_handling` (≥1) |
| a minimal example | `example_task` (input + expected_output) |
| a non-completion counter-example | `non_completion_conditions` (≥1) |
| maps to a project phase | `project_phase` (soft: gate warns if absent) |
| not just a responsibility description | enforced by all of the above |

## 3. Preserve thinking (`open_decision_space`)

To avoid degrading the AI into a script executor (§13.1), the contract carries `open_decision_space` — explicitly preserved reasoning latitude:

```yaml
open_decision_space:
  - implementation strategy (how to map xlsx types to json)
  - tradeoff between strict and lenient schema coercion
  - which conflict-resolution heuristic to recommend
```

**Limit writes, not thinking. Limit completion proof, not solution generation.**

## 4. Execution levels (§15)

| `execution_level` | Level | Writes source? |
|---|---|---|
| `advice_only` | 0 | no (report only) |
| `scaffold` | 1 | scaffold files |
| `implement` | 2 | yes |
| `refactor_optimize` | 3 | yes |

**Conditional rule**: `implement` / `refactor_optimize` skills **must** set `rollback_policy.required = true`.

## 5. Practicality Lint (P0-4, Batch 2)

Vague phrases (`ensure quality`, `collaborate closely`, `optimize experience`, `improve maintainability`, `support production`, `consider edge cases`, `make it robust`) are allowed **only when followed by a concrete action**:

```
make it robust
=> add simulation test for empty deck, full hand, invalid target, insufficient energy
```

This string-content heuristic lives in `run_practicality_gate.py` (P0-4), not in this structural schema.

## 6. Collision & handoff

When a skill shares a write path with another, the owning pack's manifest declares the `collision_policy` (field-level boundary, §18). On a boundary condition, the skill emits a handoff (`handoff_triggers`) rather than editing out of scope (§19).

## 7. Not enforced by schema

vague-phrase lint (→ Practicality Gate P0-4) and `allowed_writes` over-breadth (→ boundary linter P0-5) are content/glob checks delegated to the Batch 2 validators.
