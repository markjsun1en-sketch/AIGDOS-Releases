---
title: Agent Contract Standard
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: B1
---

# Agent Contract Standard — v4.92

> **Layer**: Layer 1 — Capability Protocol Layer (Implementation Plan §11, §13, §16).
> **Status**: active (v4.92 Batch 1 P0-2). **Canonical schema**: `capability_protocols/agent_contract.schema.json`.

---

## 1. From role description to production contract

The root cause of "virtual" agents was defining them as *"what this agent is responsible for"* instead of *"what inputs it takes, what it may modify, what it must produce, what it validates, how it rolls back"*.

An agent contract encodes the second form. Core principle (Implementation Plan §13):

```
Wide:   analysis, tradeoffs, architecture, diagnosis, risk-finding, alternatives.
Narrow: write paths, canonical ownership, completion evidence, gate pass, rollback, Core access.
```

## 2. Required fields

`schema_version` · `agent_id` · `layer` · `discipline` · `status` · `owns` · `can_modify` · `must_not_modify` · `required_inputs` · `required_outputs` · `completion_evidence` · `non_completion_conditions`.

| Field | Purpose |
|---|---|
| `agent_id` | lowercase snake_case; **no project proper-name** (#8) |
| `layer` | `production_agent` / `task_agent` / `os_governance_agent` |
| `discipline` | single primary functional line: `game_design` / `art` / `program` / `qa` / `null` |
| `consults_disciplines` | optional cross-discipline routing list; does not widen ownership |
| `owns` | canonical concerns this agent is the **single** owner of |
| `can_advise_on` | advisory boundary (overlap **allowed**) |
| `can_modify` | glob write paths (must be specific) |
| `must_not_modify` | must include Core boundary unless `os_governance_agent` |
| `required_inputs` | inputs needed before execution (missing → handoff, not guess) |
| `required_outputs` | artifacts the agent must produce |
| `completion_evidence` | concrete, **checkable** "done" signals |
| `non_completion_conditions` | explicit "this does NOT count as done" counter-examples |

## 3. Discipline and consultation boundary

B10 adds the dual-axis discipline field:

```yaml
discipline: game_design
consults_disciplines:
  - art
  - program
  - qa
```

`discipline` is a **single primary ownership/routing field**, not a list of every topic the agent may touch. For example, the UI/UX agent surface lands under `game_design` because it owns information architecture, flows, component behavior, and handoff specs. It consults `art`, `program`, and `qa` when style lock, Godot implementation, or readability acceptance is needed.

Use:
- `discipline` for main responsibility and Lead routing.
- `consults_disciplines` for cross-functional collaboration.
- `can_advise_on` for free-text topic boundaries.

Do not use multi-valued `discipline`; that weakens owner clarity and makes verdict routing ambiguous.

## 4. The anti-virtual firewall

`completion_evidence` and `non_completion_conditions` are **mandatory**. They are the firewall against the L3≈0% problem (roadmap §2):

```yaml
completion_evidence:
  - scene loads without error
  - validation command result attached
non_completion_conditions:
  - only a markdown plan is produced
  - no validation result is provided
```

An agent that can only "produce a plan" fails its own contract.

## 5. Boundary roles (Implementation Plan §16)

```
Primary    = accountable for final deliverable (owns the canonical output)
Consulting = provides constraints / risk / advice (cognitive overlap ok)
Validator  = checks result against standard
```

Ownership is decided by **canonical output** (§16.3): who changes the main file is Primary. Cognitive boundaries may overlap; **execution boundaries may not**.

## 6. Handoff over out-of-bounds editing (§19)

When an agent hits a boundary condition (e.g. a needed schema field is missing), it **must** emit a handoff via `handoff_triggers` / `escalates_to` rather than silently editing out of scope.

## 7. Conditional rule

`production_agent` **must** declare `primary_pack` (resolves to a `capability_pack.schema.json#pack_id`).

## 8. Not enforced by schema

`can_modify` ∩ `must_not_modify` = ∅, two agents claiming the same `owns` entry, and Core-boundary presence are cross-instance/glob checks pushed to the boundary linter (P0-5, Batch 2).
