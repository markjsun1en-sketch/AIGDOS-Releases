---
title: Practicality Gate
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: B2
---

# Practicality Gate — v4.92

> **Layer**: Layer 1 — Capability Protocol Layer (Implementation Plan §21).
> **Status**: active (v4.92 Batch 2 P0-4). **Tool**: `scripts/capability/run_practicality_gate.py`.

---

## 1. Purpose

The Practicality Gate is the firewall against virtual skills (roadmap §2: L3≈0%). A skill that only "produces a plan" must never reach `beta`/`stable`.

Two layers enforce practicality:

| Layer | Enforces | Where |
|---|---|---|
| **structural** | the 8 required fields exist | `skill_contract.schema.json` `required[]` |
| **content** (this gate) | the fields are concrete, not buzzwords | `run_practicality_gate.py` |

draft-07 can require a field to exist; it cannot tell `"ensure quality"` from `"add a simulation test for empty deck / invalid target"`. That judgment lives here.

## 2. Checks

| Rule | Fires when |
|---|---|
| `vague_phrase` | a buzzword (see §3) appears with no concrete action clause (`=>`, `:`, `by <verb>`, `such as`, `e.g.`, `via`) |
| `validation.trivial` | no `validation_commands` entry contains a runner token (`python`/`pytest`/`godot`/`bash`/`make`/`--flag`/a path) — i.e. it's prose, not a command |
| `example_task.placeholder` | `input` or `expected_output` is empty or a placeholder (`TBD`/`...`/`example`) |
| `non_completion.empty` | no concrete `non_completion_conditions` counter-example |
| `project_phase.absent` | **warning only** — `project_phase` not declared |

## 3. Vague-phrase list (§21.2)

`ensure quality` · `collaborate closely` · `optimize experience` · `improve maintainability` · `support production` · `consider edge cases` · `make it robust` · `high quality` · `best practices` · `as needed` · `where appropriate`

These are allowed **only** when followed by a concrete action:

```
make it robust
=> add simulation test for empty deck, full hand, invalid target, insufficient energy
```

## 4. Verdict & exit codes

| Verdict | Meaning |
|---|---|
| `PASS` | no violations (warnings allowed) → skill may be promoted to beta/stable |
| `DRAFT_ONLY` | ≥1 violation → skill confined to `draft` |

| Exit | Meaning |
|---|---|
| 0 | all inspected skills PASS |
| 1 | ≥1 skill DRAFT_ONLY |
| 3 | internal error |
| 4 | input missing |

## 5. Zero-dependency discipline

The gate runs under **bare `python3`** (no `jsonschema`, no `yaml` package) — verified by `tests/capability/test_practicality_gate.py::test_runs_under_bare_interpreter_without_jsonschema`. YAML inputs use the in-repo `scripts/governance/_yaml_subset` loader. This mirrors the v4.91 governance-validator discipline (MEMORY lesson): gate/validator scripts must run on the managed interpreter that lacks third-party packages.

## 6. Usage

```bash
python3 scripts/capability/run_practicality_gate.py path/to/skill.json
python3 scripts/capability/run_practicality_gate.py --json skill_a.yaml skill_b.yaml
```

Run schema validation first (structural), then this gate (content). A skill must pass both to leave draft.
