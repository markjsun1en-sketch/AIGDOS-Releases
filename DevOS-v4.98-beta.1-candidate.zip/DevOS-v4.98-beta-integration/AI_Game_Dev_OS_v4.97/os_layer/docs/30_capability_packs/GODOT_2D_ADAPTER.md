---
title: Godot 2D Adapter Pack
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: B4
---

# Godot 2D Adapter Pack — v4.92

> **Layer**: Layer 2 — Engine Adapter (roadmap §6 / Implementation Plan §6). This doc is Layer 1 OS spec describing the pack.
> **Status**: active scaffold (v4.92 Batch 4 P0-8). **Pack**: `packs/engine_adapters/godot_2d/`.
> **First real capability pack** — exercises the full Batch 1–3 contract stack.

---

## 1. What it is

A `engine_adapter` capability pack for **Godot 4.x (2D / Mobile)**. It carries
**no game-system logic** — game-system packs (e.g. a data pipeline pack) depend
on it for engine conventions. It declares:

- GDScript conventions (`templates/GDSCRIPT_CONVENTIONS.md`)
- `.tscn` / `.tres` write rules, format=3, `project.godot` boundary (`templates/SCENE_RESOURCE_RULES.md`)
- headless smoke-test contract incl. the exit-code trap (`templates/HEADLESS_SMOKE_CONTRACT.md`)
- Control/Container responsive-layout consumer guidance (`templates/GODOT_CONTROL_CONSUMERS.md`)
- a runnable smoke template (`templates/headless_smoke_template.gd`)

## 2. Contents

```
packs/engine_adapters/godot_2d/
  capability_pack.json          # manifest (layer=engine_adapter, engine=godot_2d)
  agents/
    godot_2d_engineer.json      # production agent contract
  skills/
    gdscript_write_skill.json   # implement-level, validation via headless smoke
    scene_resource_write_skill.json
  templates/
    GDSCRIPT_CONVENTIONS.md
    SCENE_RESOURCE_RULES.md
    HEADLESS_SMOKE_CONTRACT.md
    GODOT_CONTROL_CONSUMERS.md
    headless_smoke_template.gd
```

## 3. Write boundaries

| Allowed | Forbidden |
|---|---|
| `res://scripts/**` | `AI_Game_Dev_OS_Core/**`, `capability_protocols/**`, `scripts/governance/**` |
| `res://scenes/**` | `project.godot` (handoff only) |
| `res://data/**` | `res://addons/**` |
| `res://tests/**` | `res://.godot/**` (import cache) |

`project.godot` changes (autoload / input / features) require a **handoff** to
`os_governance_agent` / project owner — never a direct edit (Boundary
Governance §3). The agent and its skills share write paths; the manifest
declares a `collision_policy` (agent = primary_owner, skills = shared_with) so
the boundary linter accepts the overlap.

## 4. Headless smoke contract (the precise bit)

Verification runs without a GPU:

```bash
godot --headless --path <project> --script res://tests/<smoke>.gd
```

**Pass/fail is decided by a `SMOKE_OK` / `SMOKE_FAIL` stdout sentinel, NOT by the
process exit code** — `SceneTree.quit(code)` is ignored under `--script`
(Godot issue #88055). The smoke script `extends SceneTree`, runs the check, prints
the sentinel, then `quit()`s. Outer runner greps stdout.

## 5. Adoption

This pack is `beta` with `min_lifecycle_for_project_adoption: beta`, so a project
can adopt it via the Batch 3 flow:

```bash
python3 scripts/capability/adopt_pack.py recommend \
    packs/engine_adapters/godot_2d/capability_pack.json \
    --project-dir .ai_dev_os --project-id my_project
# then: adopt -> validate -> lock
```

## 6. Self-validation

```bash
python3 scripts/capability/validate_godot_2d_pack.py \
    packs/engine_adapters/godot_2d/capability_pack.json
```

Checks engine-adapter shape, skill/agent cross-references, boundary linter
cleanliness, and template presence. Zero-dep (bare python3).

## 7. Acceptance (Charter §5.1 P0-8)

| Item | Met by |
|---|---|
| declares Godot write boundary | manifest allowed/forbidden + agent/skill contracts |
| declares scene/script/resource rules | GDSCRIPT_CONVENTIONS + SCENE_RESOURCE_RULES |
| provides headless smoke test | HEADLESS_SMOKE_CONTRACT + template (#88055-safe) |
| adoptable via active_packs flow | adopt_pack.py recommend → eligible (Batch 3) |

## 8. Not in scope (deferred)

Concrete game systems (Slot reel / Boss battle / data pipeline) are separate
packs. The **Data Pipeline Pack vertical slice (P0-9, Batch 5)** is the first
game-system pack to depend on this adapter and to touch the target project.
