---
title: Capability Pack Architecture
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: B1
---

# Capability Pack Architecture — v4.92

> **Layer**: Layer 1 — Capability Protocol Layer (roadmap §5 / Implementation Plan §3, §5, §23).
> **Status**: active (v4.92 Batch 1 P0-1). **Canonical schema**: `capability_protocols/capability_pack.schema.json`.

---

## 1. Why packs

v4.91 stabilised the OS as a **governance / producer / PMO** system (Core / Hub / Mount / Gate / Version Lock). It did **not** make AI agents/skills good at *actually building* game features — a skill audit found Layer-3 (executable engineering) capability ≈ 0%: skills stopped at "produce a plan doc".

v4.92 fixes this **without** turning Core into a monorepo. The shape is:

```
Core   = operating system (small, stable governance)
Packs  = applications / plugins (versioned production capability)
Project = adoption config + local state
Task Agents = short-lived executors
```

A **capability pack** is a versioned, lifecycle-governed unit of production capability that a project may adopt. Its manifest is the canonical contract.

## 2. Layers (roadmap §3)

| Layer | Name | Pack `layer` value | Example |
|---|---|---|---|
| 0 | OS Core | — (not a pack) | hub / runtime / governance |
| 1 | Capability Protocol | — (this doc + schemas) | `capability_protocols/` |
| 2 | Engine Adapter | `engine_adapter` | `godot_2d_adapter` |
| 3 | Game System Pack | `game_system_pack` | `data_pipeline_pack` |
| 4 | Genre / Starter Pack | `genre_starter_pack` | `2d_card_roguelite` |
| 5 | Project Local | — (project `.ai_dev_os/`) | `active_packs` |
| 6 | Temporary Task Agent | — (task layer) | per-task agent |

`production_pack` is a cross-cutting Layer-3 variant (UI binding / asset integration) that is not engine-specific.

## 3. Pack manifest — required fields

The manifest (`capability_pack.schema.json`) requires:

`schema_version` · `pack_id` · `version` · `layer` · `lifecycle_status` · `allowed_writes` · `forbidden_writes` · `validation`.

Key boundary rules:

- **`pack_id`** — lowercase snake_case, **no project proper-name** (Layer separation invariant #8). Engine/genre/system names are allowed (`godot_2d_adapter`, `data_pipeline_pack`).
- **`allowed_writes`** — must be specific enough that the boundary linter (P0-5) can assign a unique owner. Broad roots (`res://**`) are flagged.
- **`forbidden_writes`** — must include the OS Core boundary and the engine project file. **No pack may write Core.**
- **`validation`** — at least one `smoke`/`project` command. A pack with no validation cannot advance past `beta`.

## 4. Lifecycle (Implementation Plan §5.3)

```
draft -> beta -> stable -> deprecated -> retired
```

| Status | Meaning |
|---|---|
| `draft` | exploration only; never project-adoptable |
| `beta` | usable in controlled projects |
| `stable` | eligible for starter / project adoption |
| `deprecated` | not recommended for new projects (must declare `deprecation.reason`) |
| `retired` | historical compatibility only |

## 5. Collision policy (Implementation Plan §18)

When two skills/agents share a write path, the manifest **must** declare a `collision_policy.shared_paths` entry with a `primary_owner` and optional field-level boundary. The boundary linter (P0-5) flags any shared path lacking a policy.

## 6. Adoption (P0-6, reuses v4.91 seed)

`adoption.min_lifecycle_for_project_adoption` gates which packs a project may enable. Adoption flows through the v4.91 `capability_adoption_state` seed (`schemas/protocol/capability_adoption_state.schema.json`), extended — not rebuilt.

## 7. What the schema does NOT enforce (pushed to validators)

draft-07 cannot express cross-instance / graph / glob-set checks. These live in the Batch 2 validators:

- dependency-cycle detection (`depends_on` graph) → boundary linter
- `allowed_writes` ∩ `forbidden_writes` overlap → boundary linter
- two packs/agents claiming the same canonical artifact → boundary linter
- vague-phrase practicality lint → Practicality Gate

See `AGENT_CONTRACT_STANDARD.md` and `SKILL_CONTRACT_STANDARD.md` for the agent/skill contracts that packs reference.
