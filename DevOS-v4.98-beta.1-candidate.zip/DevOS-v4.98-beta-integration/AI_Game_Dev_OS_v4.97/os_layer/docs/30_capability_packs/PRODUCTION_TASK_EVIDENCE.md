---
title: Production Task Evidence
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: B6
---

# Production Task Evidence — v4.92

> **Layer**: Layer 1 — Capability Protocol Layer (Implementation Plan §14.2, §19).
> **Status**: active (v4.92 Batch 6 P0-10). **Tool**: `scripts/capability/record_task_evidence.py`.
> **Schemas**: `capability_protocols/{production_handoff,rollback_note,validation_evidence}.schema.json`.

---

## 1. The three-piece set

Every execution-mode production task on a pack produces, as applicable:

| Piece | When | Schema |
|---|---|---|
| **handoff** | the task hits a boundary it can't cross in scope | `production_handoff.schema.json` |
| **rollback note** | the task modified project files (pack `rollback.required=true`) | `rollback_note.schema.json` |
| **validation evidence** | always, to prove completion | `validation_evidence.schema.json` |

This is the concrete backing for an agent contract's `completion_evidence` /
`non_completion_conditions` (the anti-virtual firewall) and the §19 "hand off,
don't edit out of bounds" rule. It is **distinct** from OS-level recovery
rollback (`schemas/recovery/*`), which is for Core updates.

## 2. Records location

```
<project>/.ai_dev_os/local_handoffs/
  handoffs/ho_XXXXXXXX.json
  rollback_notes/rb_XXXXXXXX.json
  evidence/ev_XXXXXXXX.json
```

This is the path each pack manifest's `rollback.output` points into.

## 3. Tool

```bash
# parent flags (--project-dir, --json) come BEFORE the subcommand
record_task_evidence.py --project-dir .ai_dev_os handoff \
    --pack data_pipeline_pack --from data_pipeline_engineer \
    --reason "heroes.xlsx needs a new column" --missing "rarity column" --blocking

record_task_evidence.py --project-dir .ai_dev_os rollback \
    --pack data_pipeline_pack --task t1 \
    --file game/data/heroes.json --revert "restore backup" --backup /tmp/heroes.bak

record_task_evidence.py --project-dir .ai_dev_os evidence \
    --pack data_pipeline_pack --task t1 \
    --cmd "python validate_data.py=pass" --cmd "godot --headless smoke=pass"

record_task_evidence.py --project-dir .ai_dev_os verify --task t1 --require-rollback
```

- `evidence` derives `verdict` (fail if any `--cmd` outcome is `fail`).
- `verify` checks the set for a task: evidence present, verdict↔command
  consistency, and (with `--require-rollback`) that a file-touching task has a
  rollback note.

## 4. Exit codes & zero-dependency

| Exit | Meaning |
|---|---|
| 0 | recorded / verify passed |
| 1 | verify found a violation |
| 2 | usage error |
| 3 | internal error |
| 4 | input missing |

Runs under **bare `python3`** (verified by `tests/capability/test_task_evidence.py`).
Records are JSON; each validates against its schema.

## 5. Verify invariants

- an execution-mode task **must** have validation evidence;
- `verdict==pass` is inconsistent with any failed command (and vice-versa);
- with `--require-rollback`, a file-touching task **must** carry a rollback note.
