# SPRINT_CLOSE_CHECKLIST

## Close sequence
- [ ] validation gate complete
- [ ] mainline state confirmed
- [ ] TAPD final sync complete
- [ ] read-after-write verification complete
- [ ] audit summary generated
- [ ] archive step complete
- [ ] recovery issues documented if any

## Required outputs
- [ ] sprint close note
- [ ] audit summary
- [ ] archived task count
- [ ] merge summary
- [ ] TAPD sync summary
