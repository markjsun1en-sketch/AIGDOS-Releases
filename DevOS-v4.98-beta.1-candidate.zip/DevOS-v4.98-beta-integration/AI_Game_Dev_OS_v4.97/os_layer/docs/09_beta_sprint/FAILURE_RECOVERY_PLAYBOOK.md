# Beta Sprint Failure Recovery Playbook

## Purpose
This playbook is used when a Beta Sprint deviates from the expected Codex + TAPD + Git trial path. It is intentionally operational and focuses on restoring a trustworthy run rather than preserving perfect automation.

## Recovery Goals
1. Preserve internal runtime truth.
2. Prevent invalid TAPD state from becoming accepted fact.
3. Prevent Git integration noise from hiding true progress.
4. Make the recovery itself auditable.

## Incident Classes
### Class A — Runtime bootstrap / init failure
Typical signals:
- root cannot be discovered
- required files missing after init
- runtime profile not selected

Immediate response:
- stop worker execution
- run path validation
- fix root / config
- rerun init in dry-run mode
- capture incident note

### Class B — TAPD verification failure
Typical signals:
- API mutation response OK, verification read not OK
- parent Story remains stale after child completion
- illegal mapped status discovered

Immediate response:
- block further TAPD writeback on affected object group
- run validator manually
- correct mapping or object target
- re-issue writeback
- capture recovery audit event

### Class C — Serial merge flow breaks down
Typical signals:
- multiple isolated changes waiting without clear order
- conflict on state files
- worker applied directly to wrong place

Immediate response:
- freeze further applies
- reorder merge queue
- reconcile state files manually if needed
- restart serial apply sequence

### Class D — Audit trail incomplete
Typical signals:
- TAPD write lacks verification entry
- merge occurred without merge audit
- runtime transition lacks task context

Immediate response:
- reconstruct from available evidence
- append manual recovery audit notes
- mark reconstructed events clearly

## Recovery Ladder
### Level 1 — Local correction
Used when the incident is isolated and system truth is still intact.

### Level 2 — Parent/lead intervention
Used when worker context cannot complete recovery safely.

### Level 3 — Trial pause
Used when runtime state, TAPD state, and integration state no longer align well enough to continue confidently.

## Must-Record Recovery Evidence
Every recovery event should record:
- incident class
- affected tasks / objects
- detected symptom
- chosen recovery action
- owner
- outcome
- follow-up needed

## Sprint-Close Rule
If unresolved recovery items remain at sprint close, the sprint close report must state them explicitly rather than silently archiving around them.
