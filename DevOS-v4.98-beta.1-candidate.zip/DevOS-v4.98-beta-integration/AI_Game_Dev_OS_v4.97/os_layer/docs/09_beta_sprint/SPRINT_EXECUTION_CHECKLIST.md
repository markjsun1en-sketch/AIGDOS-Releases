# SPRINT_EXECUTION_CHECKLIST

## Kickoff
- [ ] create TAPD iteration
- [ ] register sprint tasks
- [ ] assign owners
- [ ] confirm merge owner and writeback owner

## During execution
- [ ] each worker uses isolated execution unit
- [ ] all status transitions are recorded
- [ ] TAPD updates are verified after write
- [ ] all merges into main are serial
- [ ] audit output is appended continuously

## Before close
- [ ] all tasks in expected terminal state
- [ ] parent TAPD objects aggregated correctly
- [ ] no stale worktree/branch remains open without owner note
