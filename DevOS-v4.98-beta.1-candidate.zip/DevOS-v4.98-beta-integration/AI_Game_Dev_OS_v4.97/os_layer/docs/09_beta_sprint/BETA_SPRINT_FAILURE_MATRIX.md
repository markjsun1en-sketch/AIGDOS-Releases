# Beta Sprint Failure Matrix

> **Relationship to `FAILURE_RECOVERY_PLAYBOOK.md`**: this matrix is the **quick-scan index**; the playbook is the **detailed SOP** for each class. When the two disagree, the playbook is authoritative — report the drift as a regression.
>
> Class names in this matrix map to the playbook's 4 incident types as follows: the 7 rows below are finer-grained failure signals, and each row's "Likely layer" column aligns with one of the playbook's 4 incident types (runtime / integration / workflow / audit).

This matrix supplements the failure recovery playbook by making the most common Beta Sprint failure classes quickly scannable.

| Failure class | Typical symptom | Likely layer | Immediate action | Recovery owner | Can sprint continue? |
|---|---|---|---|---|---|
| Runtime init drift | demo data, wrong profile, stale paths | Portable core | stop and re-init | parent / lead | usually yes after reset |
| Profile mismatch | worker behavior contradicts starter | Runtime profile | halt new work, reconcile profile | parent / lead | only after alignment |
| TAPD invalid sync | API accepted value but UI state wrong | Integration | run verifier and correct state | writeback owner | yes after verification |
| Merge ownership breach | worker merged directly or applied out of order | Git workflow | stop merges, rebuild merge queue | parent / lead | maybe |
| Dirty workspace | abandoned worktree, untracked state, stale team state | Runtime-specific | isolate, snapshot, clean | cleanup owner | maybe |
| Missing audit evidence | no usable audit or close record | Audit layer | reconstruct minimal evidence | parent / lead | only if reconstructed fast |
| Starter mismatch | wrong starter overlay or mixed runtime docs | Starter layer | revert to one starter family | project operator | yes after correction |

## Usage

Use this matrix during Sprint 0 or Beta Sprint review to decide whether to continue, pause, or abort the trial.

## Escalation rule

If two or more failures from different layers occur in the same sprint window, convert the trial into a controlled recovery sprint rather than pretending normal execution is still in effect.
