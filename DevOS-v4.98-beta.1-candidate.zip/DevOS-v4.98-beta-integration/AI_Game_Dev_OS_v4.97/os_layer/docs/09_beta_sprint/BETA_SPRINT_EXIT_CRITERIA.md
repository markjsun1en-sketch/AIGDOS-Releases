# Beta Sprint Exit Criteria

This document defines when a 4.88 Beta Sprint can be treated as a valid trial rather than just an activity log.

## Required exit conditions

A Beta Sprint exits cleanly only when **all** of the following are true:

### 1. Initialization integrity

- Runtime environment initialized without demo residue.
- Runtime profile selection is explicit and validated.
- Starter family slice used by the sprint is identifiable.

### 2. Execution integrity

- Worker execution followed the selected runtime profile.
- Isolation rules were respected.
- Merge/apply ownership was respected.
- No unresolved dirty state remains in the active workspace.

### 3. External sync integrity

- TAPD writes were validated before use.
- Read-after-write verification was performed.
- Parent/child aggregation state is not stale at sprint close.

### 4. Evidence integrity

- Audit logs exist and are parseable.
- Task / handoff / validation evidence exists for completed work.
- Recovery events, if any, are documented.

### 5. Close integrity

- Sprint close checklist completed.
- Archive or status transition completed.
- Delta between intended outcome and actual outcome is recorded.

## Acceptable non-ideal outcomes

A Beta Sprint may still count as valid if:

- one or more items are marked conditional pass but clearly logged
- a runtime-specific limitation blocked full automation but the fallback path is documented
- recovery steps were needed but the resulting state is clean and explainable

## Invalid trial signals

A sprint should not be treated as a valid Beta Sprint trial if:

- runtime profile was never actually selected
- workers used mixed execution assumptions
- TAPD state is not trustworthy after close
- merge/apply ownership is unclear
- audit evidence is absent or unreadable
- cleanup left the runtime in a dirty state

## Review summary

At sprint exit, produce a one-page summary answering:

1. What was attempted?
2. What profile was used?
3. What passed?
4. What failed or required recovery?
5. What should change before the next sprint?

## Script binding (REV-3-005 + Phase 4 Step 1, 2026-04-22)

Each of the 5 integrity categories above is bound to the verifier
`scripts/verify_beta_sprint_exit.py`. The script is SCAFFOLD-tier per
`runtime/MATURITY_MATRIX.md`; GUIDED-tier deep assertions are scheduled
for v4.90 Batch 0.5 (the in-line `v4.89-trial-upgrade` markers remain as
references; the `upgrade_tag` string in the verifier output stays
unchanged for audit-consumer backwards-compat).

**Phase 4 Step 1 changes** (vs REV-3-005 skeleton):

- 5 checks all have **shallow real logic** (exists / non-empty /
  JSON-parseable / event-family presence / checklist ticking).
- New CLI flags `--workspace` / `--audit-log` / `--runtime-state` /
  `--sprint-close-checklist` let the same script verify either the
  v4.89 package (self-scan) or an external trial workspace /
  mock scenario.
- **Self-scan tolerance**: when the caller omits a path and the
  default artifact is absent, the finding is `WARN` (CONDITIONAL).
  When the caller explicitly names a path that does not exist, the
  finding is `ERROR` (FAIL) — caller intent was to verify that
  artifact and it is missing.

| Category | Check function | v4.89 status (inheriting from v4.88-stable Phase 4 Step 1) | scheduled for v4.90 Batch 0.5 |
| --- | --- | --- | --- |
| 1 Initialization integrity | `check_init_integrity` | runtime_state.json exists + JSON-parseable + optional `--profile` cross-check | demo_* residue scan; adapter-manifest cross-check |
| 2 Execution integrity | `check_execution_integrity` | at least one `runtime.transition` present; `merge.apply` implies `merge.cleanup` | isolation_unit vs branches touched; dirty-worktree probing |
| 3 External sync integrity | `check_external_sync_integrity` | every `external.tapd.write` has a matching `external.tapd.verify`; all `verification_ok=true` | retry_count thresholds; reconcile cross-reference |
| 4 Evidence integrity | `check_evidence_integrity` | audit log present + non-empty + parseable; at least one evidence-class event family represented | handoff + validation cross-check per task; evidence_refs path existence |
| 5 Close integrity | `check_close_integrity` | sprint_close_checklist items all ticked; terminal event (`runtime.archive` or `trial.check`) present | archive transition recorded to state; delta summary file existence |

Exit codes (per REV-2-011 output contract convention):

- `0` — PASS (all checks pass)
- `1` — CONDITIONAL (WARN-level findings only; matches "Acceptable non-ideal outcomes" above)
- `2` — FAIL (any ERROR-level finding; matches "Invalid trial signals" above)
- `3` — INTERNAL_ERROR

Usage:

```bash
# self-scan (runs against the v4.89 package; typically returns CONDITIONAL
# because default artifact paths inside the package are empty)
python scripts/verify_beta_sprint_exit.py

# verify a trial workspace by overriding each artifact path
python scripts/verify_beta_sprint_exit.py \
    --workspace /path/to/project \
    --audit-log /path/to/mcp_audit.jsonl \
    --runtime-state /path/to/runtime_state.json \
    --sprint-close-checklist /path/to/sprint_close_checklist.md \
    --sprint sprint-1 --profile codex

# limit to specific categories
python scripts/verify_beta_sprint_exit.py --categories evidence,close
```

The verifier prints a JSON report on stdout (including
`maturity_tier: "SCAFFOLD"` and `upgrade_tag: "v4.89-trial-upgrade"` so
CI tooling can parse it directly and flag shallow verdicts.

---

## v4.89 Phase 1 Contract Addendum (2026-05-02)

### Path Contract (C4 + Pre-Z1)

As of v4.89 Phase 1, two workspace-relative assets have **canonical
locations + fallback resolvers**. New workspaces should use the
canonical path; legacy / assembled workspaces continue to work via
the fallback chain.

| Asset | Canonical | Fallback(s) | Resolver |
|---|---|---|---|
| `runtime_state.json` | `<ws>/runtime/state/runtime_state.json` | `<ws>/runtime_state.json` — legacy root shape (pre-C4). Also valid: a **pointer shim** at `<ws>/runtime_state.json` whose body is `{"_moved_to": "runtime/state/runtime_state.json", "canonical": true, "_hint": "v4.89 P0-C C4"}` — `_resolve_state_path` follows it. | `scripts/verify_beta_sprint_exit._resolve_state_path` |
| `sprint_close_checklist.md` | `<ws>/runtime/state/sprint_close_checklist.md` | `<ws>/docs/09_beta_sprint/sprint_close_checklist.md` (assembled-workspace default; matches `run_beta_sprint_check._CHECKLIST_SEARCH_ROOTS`). | `scripts/verify_beta_sprint_exit._resolve_checklist_path` |
| Profile JSON | `<ws>/config/profiles/<profile>.json` | `<ROOT>/config/profiles/<profile>.json` (package reference copy; used when the workspace has not been assembled yet). | `scripts/run_beta_sprint_check.check_profile_validity` 2-step lookup (`source='workspace' | 'package_root'`). |

Both `_resolve_*_path` helpers are **defensive** (never raise); they
fall through to the requested path unchanged when the workspace shape
cannot be inferred. This matches the `_ev_get` envelope-aware reader
pattern from A5.

### Envelope Contract (A1-A5)

All audit events produced by adapter stubs (`integrations/tapd_adapter_stub.py`,
`integrations/git_adapter_stub.py`) MUST flow through
`runtime.observability.runtime_event_collectors.workbuddy_collector.wrap_external_record()`
before reaching `append_audit()`. The helper stamps the canonical
9-field envelope:

| Field | Source | Stamped by |
|---|---|---|
| `event_id` | `uuid.uuid4()` | helper |
| `event_type` | adapter `event` → `event_type` → kwarg override → `"unknown"` | helper |
| `timestamp` | `utcnow(...).strftime("%Y-%m-%dT%H:%M:%SZ")` (callers can override via `ts_override=` for deterministic ordering) | helper |
| `actor` | kwarg, default `"main_session"` | helper |
| `runtime_profile` | kwarg (required non-empty) | caller |
| `result` | kwarg override → adapter `result` / `status` → `"unknown"` | helper |
| `source_layer` | kwarg; allowlist `{tapd, git, workbuddy}` (raises on typos) | caller |
| `audit_status` | kwarg default `pending`; `failed` for silent-failure records | helper |
| `details` | `dict(record)` — original adapter shape, no-loss | helper |

Consumers reading events MUST use
`scripts/verify_beta_sprint_exit._ev_get(event, key, default)` for any
field that may appear at envelope root OR under `details.*`. Root wins
when both are present; falsy root values (`False`, `0`, `""`) are
NEVER masked by the details fallback (this is the reason
`verification_ok=False` reads correctly).

### Required-field Alias (C2)

`profile` and `runtime_profile` are bidirectional aliases at the
runtime state level. Writers (init) MUST populate both; readers MUST
accept either. The `_REQUIRED_STATE_FIELDS` constant in
`verify_beta_sprint_exit.py` is `tuple[tuple[str, ...], ...]` where
each inner tuple is a set of acceptable aliases; an entry is
satisfied when ANY alias is present with a non-empty value.

### Malformed Audit Sink (C1)

Non-strict `append_audit` failures (envelope validation / JSON
encoding / file append) append the rejected record to
`<ws>/runtime/logs/mcp_audit.malformed.jsonl`:

```json
{"reason": "...", "recorded_at": "YYYY-MM-DDTHH:MM:SSZ", "raw_record": <original-or-repr>}
```

This file is **NOT** the main audit log; `_read_audit_stream` reads
`mcp_audit.jsonl` only. `mcp_audit.malformed.jsonl` exists purely for
post-mortem forensics and is safe to discard.

### Known Gaps / Phase 2 Scope

- **LTM** (Long-Term Memory): not in Phase 1.
- **Self-Evolution**: not in Phase 1.
- **Cross-project platformization**: not in Phase 1.
- **5-profile equivalence**: only `workbuddy_private` is hardened in Phase 1.
- **Writer-side envelope purity** (remove driver `top_level=` compat
  bridge): currently soft-deprecated in `run_sprint.py`; Phase 2 will
  remove once all consumers are confirmed `_ev_get`-aware.

---

## v4.89 Phase 2 Stage 1 Addendum (2026-05-03) — LTM MVP

Phase 2 Stage 1 closed with 10 commits on `revise/phase-1-fork`, tag `v4.89-phase-2-m5`. This addendum captures the LTM (Long-Term Memory) layer semantics introduced in that stage; Phase 1 contracts (envelope / path / alias / malformed / subrange-immutable) remain unchanged and fully applicable.

### LTM Corpus Contract

Four domains under `AI_Game_Dev_OS_v4.89/ltm/`:

| Domain | Purpose | Write-time evidence_ref? |
|---|---|---|
| `os/` | OS-level rules & best practices, cross-generation | Not required (but recommended as MEMORY.md anchor) |
| `project/<id>/` | Per-project sprint history & conventions | **Required** (Sprint ID / commit sha / TAPD story) |
| `pattern/` | Cross-project reusable design patterns | **Required** (>= 2 scenarios validated) |
| `failures/` | Bug postmortems with Symptom/RCA/Fix/Lesson | **Required** (trigger commit + fix commit) |
| `_quarantine/` | Gate-rejected captures awaiting human review | N/A — not searchable by `consult()` |

### Read / Write APIs

```python
from runtime.ltm import consult, capture

# Read — keyword search (MVP: literal matching, no vector/embedding)
hits = consult("envelope contract", domain="os", limit=10)

# Write — gated append
result = capture(
    domain="failures",
    title="A4 dry-run fail",
    content="Symptom / RCA / Fix ...",
    evidence_ref="commit 7a72ea6",
)
# result["gate"] ∈ {"passed", "blocked"}
```

CLI: `python -m runtime.ltm <query> [--domain D] [--limit N] [--json]`.

### Gate Rules (MVP)

1. Unknown domain → `raise ValueError`.
2. Non-OS domain without `evidence_ref` → routed to `ltm/_quarantine/`, `gate="blocked"`.
3. OS-domain content mentioning "canonical" / "override" → soft warning in `result["warnings"]`, `gate="passed"` (MVP; Phase 3 Self-Evolution may auto-reject).
4. `requires_approval=True` → unconditional quarantine.

### Policy File

`config/memory_retrieval_policy.yaml` defines:
- `memory_domains: [OS, Project, Pattern_Capability, FailureFix]` — 4 domains (Phase 2 Stage 1 extended from Phase 1's 3)
- `canonical_override_block: true` — experience memory may NOT silently override canonical truth
- `retrieval_priority: [canonical, retrieval, experience]` — search order
- `experience_memory_usage_rules` / `failure_fix_memory_usage_rules` — consumption constraints (may inform proposals; do NOT auto-accept fixes without approval)

### Defensive I/O (Phase 1 Pattern Applied)

- `consult()` / `capture()` never raise on filesystem errors. Unreadable files score 0; OSError on write returns `gate="blocked"` with reason.
- Only exception raised: `ValueError` for unknown domain (programmer bug surfaces loudly).

### Known Gaps / Phase 2 Stage 2+

The MVP intentionally defers:

- **Vector / embedding retrieval** — keyword matching is sufficient for corpus < 500 files.
- **LLM summarisation on capture** — Phase 3 Self-Evolution territory.
- **Automatic capture from audit.jsonl** — Phase 3.
- **True cross-project replay** — Phase 4 platform phase.
- **Auto-reject on canonical_override_block** — currently soft warn.
- **`top_level=` compat bridge removal** — planned for Phase 2 Stage 2 (independent of LTM).

### Phase 2 Stage 2 — 5-profile parity hardening (2026-05-05, complete)

**Status**: DONE.  Tag `v4.89-phase-2-m6`.  9 milestones M6.0 → M6.9.

The "5-profile equivalence hardening" item that was deferred from
Phase 2 Stage 1 is now resolved.  Stage 2 added a per-profile
`init`-category schema cross-check for each of the four
non-baseline profiles (codex / cursor / claude_code_agent_teams /
claude_code_subagents), each witnessed by a deliberately
contract-violating mirror under
`trial_workspaces/rh_sprint_sim_01__<profile>_negative/`.

Granularity:
- Cross-checks fire WARN (not ERROR) — this is divergence
  detection, not contract policing.  The verdict scale defined
  above (PASS / CONDITIONAL / invalid) is unchanged.
- Cross-checks are gated on `runtime_state.profile == "<profile>"`
  AND the contract field being explicitly declared in state, so
  the existing six positive mirrors stay green when run under any
  maturity tier.
- SCAFFOLD on a negative mirror still returns PASS by design
  (maturity floor skips `init` category); cross-checks fire only
  under GUIDED.  Both behaviours are exercised by the M6.8 R1
  regression suite (`tests/test_stage_2_regression_r1.py`).

Acceptance contract for any future Phase 3 collapse: the 16-row
verdict matrix locked by
`tests/test_stage_2_regression_r1.py::_MATRIX` is byte-identical
to the post-M6.7 inventory §5 table; a schema-driven cross-checker
must reproduce every envelope before the per-profile if-tree may
be removed.

### Integration with Phase 1 Exit Criteria

LTM MVP deliberately does not touch:

- `trial_workspaces/rh_sprint_sim_01/` (trial still verdict=PASS post-M5; Stage 2 added 5 sibling positive mirrors + 4 negative mirrors, but the original P1 baseline is byte-stable across M5 → M6.9).
- `AI_Game_Dev_OS_v4.88_Release/` (E7 shasum baseline intact — 539 files, 0 FAILED, also preserved across all M6 commits).
- Phase 1 11 permanent contracts (all preserved; 10 of them were ported into `ltm/os/` as M4.1 corpus seed; Stage 2 added 4 postmortems to `ltm/failures/` without touching the OS corpus).

pytest surface grew from 31 (Phase 1) → 45 (Phase 2 Stage 1) → **161** (Phase 2 Stage 2) = +130 over baseline.
