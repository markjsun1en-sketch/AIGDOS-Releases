# Phase 4 Step 3 — Mock Smoke Report

> **Generated 2026-04-22 by `scripts/run_mock_smoke.sh`** against the
> 4 Phase 4 Step 2 Mock scenarios under `examples/_mock_baselines/trial_scenarios/`.

> ⚠️ **Historical baseline — pre-M7.3 Lift gate.** This report captures the
> Phase 4 Step 3 (2026-04-22) snapshot. The S4_claude_subagents_tapd_git
> scenario shown here as `CONDITIONAL / exit=1` was correctly captured
> for the SCAFFOLD tier in effect at that date. After commit `6414cac`
> (M7.3.3, 2026-05-06) introduced the Lift gate enforcing init's
> canonical contract surface write, the same fixture now correctly
> escalates to `FAIL / 2 ERROR / 2 WARN / exit=2`. The current
> ground-truth contract lives in
> `examples/_mock_baselines/trial_scenarios/S4_claude_subagents_tapd_git/expected_verdict.json`
> (post_m7_3_expected). See also
> `examples/_mock_baselines/trial_scenarios/S4_claude_subagents_tapd_git/README.md`
> for the up-to-date narrative; this report is preserved as evidence of
> the pre-M7.3 baseline only.

## Summary

| Scenario | Expected | Actual | Expected Exit | Actual Exit | Result |
| --- | --- | --- | ---: | ---: | --- |
| S1_codex_tapd_git | PASS | PASS | 0 | 0 | ✅ PASS |
| S3_cursor_tapd_git | PASS | PASS | 0 | 0 | ✅ PASS |
| S4_claude_subagents_tapd_git | CONDITIONAL † | CONDITIONAL | 1 | 1 | ✅ PASS |
| S5_workbuddy_private_tapd_git | FAIL | FAIL | 2 | 2 | ✅ PASS |

† **S4 row is pre-M7.3 baseline** — current contract is `FAIL / 2 ERROR / 2 WARN / exit=2`; see banner above and `examples/_mock_baselines/trial_scenarios/S4_claude_subagents_tapd_git/expected_verdict.json` for the post-M7.3 ground truth.

**All 4 scenario contracts match** — Phase 4 Step 3 verdict matrix is green.

## Per-scenario findings

### S1_codex_tapd_git (PASS, golden sample)

```json
{
  "error_count": 0,
  "warn_count": 0,
  "findings": [],
  "verdict": "PASS"
}
```

No findings across all 5 integrity categories.

### S3_cursor_tapd_git (PASS, profile switch)

```json
{
  "error_count": 0,
  "warn_count": 0,
  "findings": [],
  "verdict": "PASS"
}
```

Same shape as S1 despite different profile — confirms the SCAFFOLD
checks are profile-agnostic at this tier.

### S4_claude_subagents_tapd_git (CONDITIONAL, WARN path) — pre-M7.3 baseline

```json
{
  "error_count": 0,
  "warn_count": 1,
  "findings": [
    {
      "category": "external",
      "severity": "WARN",
      "message": "1 tapd.write event(s) have no matching tapd.verify"
    }
  ],
  "verdict": "CONDITIONAL"
}
```

Single WARN on the omitted `external.tapd.verify` for FT-302. Other
4 categories pass.

### S5_workbuddy_private_tapd_git (FAIL, invalid trial signals)

```json
{
  "error_count": 2,
  "warn_count": 2,
  "findings": [
    {"category": "execution", "severity": "WARN",
     "message": "merge.apply x1 present but no merge.cleanup found"},
    {"category": "external", "severity": "ERROR",
     "message": "1 tapd.verify event(s) reported verification_ok=false"},
    {"category": "close", "severity": "ERROR",
     "message": "10/16 checklist items not ticked"},
    {"category": "close", "severity": "WARN",
     "message": "no terminal event found (runtime.archive or trial.check)"}
  ],
  "verdict": "FAIL"
}
```

Stacked failures:
- `external` ERROR on `verification_ok=false` after 2 retries.
- `close` ERROR on 10 unticked checklist items.
- Plus 2 WARN findings (no cleanup, no terminal event).

## Artifact trail

Each scenario's full verifier JSON output is recorded at:

- `examples/_mock_baselines/trial_scenarios/S1_codex_tapd_git/actual_verdict.json`
- `examples/_mock_baselines/trial_scenarios/S3_cursor_tapd_git/actual_verdict.json`
- `examples/_mock_baselines/trial_scenarios/S4_claude_subagents_tapd_git/actual_verdict.json`
- `examples/_mock_baselines/trial_scenarios/S5_workbuddy_private_tapd_git/actual_verdict.json`

Re-run this harness at any time via:

```bash
bash scripts/run_mock_smoke.sh
```

## What this report is evidence of

1. `scripts/verify_beta_sprint_exit.py` (SCAFFOLD, Phase 4 Step 1)
   successfully verdicts across all three tiers (PASS / CONDITIONAL /
   FAIL).
2. The 4 Mock scenarios under `examples/_mock_baselines/trial_scenarios/` (Phase 4
   Step 2) match their declared `expected_verdict.json` contracts.
3. The regression harness `scripts/run_mock_smoke.sh` is wired end to
   end and returns exit 0 on all-match / exit 1 on any mismatch.

Together these close the **verification Gate** requirement listed in
`docs/09_beta_sprint/BETA_SPRINT_EXIT_CRITERIA.md`.

## v4.90 Batch 0.5 next steps

(Originally tracked as `v4.89-trial-upgrade`; rescheduled to v4.90
Batch 0.5 per EP decision 2026-05-10. The `upgrade_tag` string in the
verifier output is preserved unchanged for audit-consumer backwards-compat.)

- ~~Wire `run_mock_smoke.sh` into CI (currently invoked manually).~~ —
  shell harness was Python-rewritten on 2026-05-10 (commit `530aa5c`):
  `run_mock_smoke.py` is the new in-process structured asserter.
  Remaining: actual CI integration.
- Replace shell harness with structured Python asserter that compares
  full finding structures, not just verdict + exit code. — **partial
  done**: `run_mock_smoke.py` exists; full structural compare deferred.
- Extend check_execution to WARN when cleanup_count < apply_count (not
  just when cleanup_count is zero) — S4 would then yield 2 warnings
  and call for an expected_warn_count bump.
- Add a negative smoke case: a scenario whose `expected_verdict.json`
  declares contract mismatch intentionally, to prove the harness does
  return exit 1 as designed.
