# CODEX_TAPD_GIT_DEFAULT_PROFILE

## Why this is the default Beta Sprint profile
This is the most practical first-trial profile for v4.89 because it keeps the Beta Sprint focused on:
- explicit execution ownership
- worktree-friendly parallelism
- parent-owned external writeback
- controlled merge discipline

## Profile assumptions
- runtime type: `codex`
- coordination model: `parent_subagents`
- isolation unit: `worktree`
- writeback owner: `parent`
- cleanup owner: `parent`
- merge mode: `serial`

## Worker rules
- each worker should operate on an isolated unit
- workers return result summaries, diffs, and validation evidence
- parent session owns final writeback to TAPD and merge to main

## Beta Sprint fit
Choose this profile when you want the cleanest first proof of the v4.89 model before broadening to other runtimes.
