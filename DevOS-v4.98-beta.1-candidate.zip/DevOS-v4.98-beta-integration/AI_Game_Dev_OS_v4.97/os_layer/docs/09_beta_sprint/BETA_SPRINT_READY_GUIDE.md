# Beta Sprint Ready Guide

## Purpose
This guide defines what "ready to run one controlled Beta Sprint" means for v4.89 (inheriting from the v4.88-stable B+ Bridge Hardening line).

## Default trial profile
Unless explicitly changed, the default trial path is:
- runtime: Codex
- external collaboration: TAPD
- version control: Git
- integration style: parent-owned writeback, serial merge, audit capture enabled

## Pre-sprint readiness
Before opening Sprint 0 or Sprint 1, verify:
- execution profile selected,
- starter installed,
- TAPD config validated,
- Git workflow baseline acknowledged,
- audit schema present,
- Beta Sprint checklist available.

Then run the real-initialization step:

```bash
python3 scripts/init_runtime_env.py \
    --project-id <your_sprint_id> \
    --runtime-profile <profile> \
    --output-dir /path/to/project
```

## During sprint
The Beta Sprint should emphasize:
- narrow task packets,
- visible ownership,
- serial integration,
- explicit verification after external writeback,
- rapid recovery when drift is detected.

Periodically (e.g. mid-sprint) run the 5-module health check:

```bash
python3 scripts/run_beta_sprint_check.py --workspace /path/to/project
```

Checks: docs / profile / adapter+collector / agents_guard / checklist.

## Exit evidence
A Beta Sprint should end with:
- task status reconciliation,
- TAPD verification,
- merge audit summary,
- cleanup confirmation,
- lessons captured into notes.

Then run the exit verifier:

```bash
python3 scripts/verify_beta_sprint_exit.py \
    --workspace /path/to/project \
    --sprint sprint-N --profile <profile>
```

The verifier returns one of three verdicts: **PASS** / **CONDITIONAL** / **FAIL**
(see `docs/USAGE_GUIDE.md §6` and `docs/PHASE_4_TRIAL_GUIDE.md §4`).

## See also
- `docs/USAGE_GUIDE.md §6` — authoritative three-step sprint close flow + maturity tier table
- `docs/PHASE_4_TRIAL_GUIDE.md` — 11 event families + S1 walk-through + regression assertions
- `docs/09_beta_sprint/BETA_SPRINT_EXIT_CRITERIA.md` — 5 integrity category definitions
