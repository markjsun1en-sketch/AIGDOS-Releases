# SPRINT0_PRECHECK

Use this checklist before kickoff.

## Core
- [ ] project root is clean
- [ ] `.core_os_root` marker is present (used by bootstrap/root discovery)
- [ ] runtime profile selected
- [ ] no demo data present
- [ ] path validation passes

## TAPD
- [ ] workspace id set
- [ ] current sprint name set
- [ ] valid status mappings reviewed
- [ ] read-after-write verification enabled

## Git
- [ ] repository initialized
- [ ] main branch clean
- [ ] merge owner identified
- [ ] branch/worktree naming convention agreed

## Audit
- [ ] audit schemas present
- [ ] audit output location known — default: `runtime/logs/audit/<YYYY>/<MM>/<event_family>.jsonl` per `AUDIT_LOG_STANDARD.md` §Retention & Storage
- [ ] sprint close audit checklist present
