# Trial Scenario Matrix

## Purpose
This matrix helps the owner select a realistic and inspectable Beta Sprint trial scope.

| Scenario | Runtime | Scope | Recommended Use | Starter reference |
|---|---|---|---|---|
| S1 | Codex + TAPD + Git | One small feature wave | default first trial | `docs/07_starters/codex/Codex_Starter_Guide.md` + `starters/codex/` |
| S2 | Codex + TAPD + Git | One medium feature wave + one recovery drill | confidence-building second trial | `docs/07_starters/codex/Codex_Starter_Guide.md` + `starters/codex/` |
| S3 | Cursor + TAPD + Git | one parallel implementation slice | compare runtime profile behavior | `docs/07_starters/cursor/Cursor_Starter_Guide.md` + `starters/cursor/` |
| S4 | Claude Code subagents + TAPD + Git | one structured execution slice | validate hook gate assumptions | `docs/07_starters/claude_code_subagents/Claude_Subagents_Starter_Guide.md` + `starters/claude_code_subagents/` |
| S5 | Workbuddy private + TAPD + Git | existing project continuity trial | preserve legacy operating mode | `docs/07_starters/workbuddy_private/Workbuddy_Private_Starter_Guide.md` + `starters/workbuddy_private/` |

> Claude Code Agent Teams is intentionally **not** offered as a first-trial scenario above. See `docs/06_runtime_profiles/claude_code_agent_teams/LIMITATIONS.md` (REV-4-015) — the experimental profile should only be trialed after S1-S5 give teams confidence in the Beta Sprint mechanics.

## Minimum Trial Scope
A valid first trial should include:
- one kickoff
- at least three runtime tasks
- at least one TAPD verified state transition
- at least one serial integration
- one sprint close attempt

## Stretch Scope
Only add these after first-trial stability:
- multi-wave parent aggregation
- deliberate recovery simulation
- concurrent worker queue with manual prioritization
- starter-based cold start from fresh project path
