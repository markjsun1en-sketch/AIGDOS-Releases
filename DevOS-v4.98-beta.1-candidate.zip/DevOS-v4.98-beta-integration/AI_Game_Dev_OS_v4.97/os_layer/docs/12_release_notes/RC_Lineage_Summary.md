# RC_LINEAGE_SUMMARY

## Purpose
This document summarizes how the current v4.88 package evolved from the earlier batch sequence.

## Lineage
- Batch 0: master outline and boundary locking
- Batch 1: skeleton and portable core
- Batch 2: TAPD + Git baseline
- Batch 3: audit + runtime profiles
- Batch 4: starter family
- Batch 5: merge and dedup plan
- Batch 6: first merged full pack
- RC: unified release candidate cut

## Current package intent
This package should be treated as a reviewable and trial-ready RC line, not as another batch fragment.
Batch-era notes remain available for traceability, but the default operating surface is:
- `docs/00_entry/`
- `docs/03_runtime_core/`
- `docs/04_integrations/`
- `docs/05_observability/`
- `docs/06_runtime_profiles/`
- `docs/09_beta_sprint/`
