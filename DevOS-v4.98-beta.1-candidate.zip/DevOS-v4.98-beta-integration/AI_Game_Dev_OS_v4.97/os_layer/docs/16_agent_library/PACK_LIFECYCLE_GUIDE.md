# Pack Lifecycle Guide

> **v4.90 Batch 5 Module A**
> Documents the 6-state lifecycle enforced by
> `schemas/agent_library/agent_pack_state.schema.json`.
> Layer 1 (OS Spec). No project names.

## States (6)

```
draft → active → deprecated
              → superseded
draft → withdrawn
active → withdrawn
```

| state | meaning | who can author |
| --- | --- | --- |
| `draft` | Front-matter and body in flux; `_skeleton_notes` allowed | any role |
| `active` | Adopting projects MAY import; `_skeleton_notes` MUST be cleared | requires `executive` sign-off |
| `deprecated` | Soft retire; replacement pack named in `superseded_by[]` | `executive` |
| `superseded` | Hard retire; archive-only, MUST have a replacement pointer | `executive` |
| `withdrawn` | Authoring abandoned before adoption; no replacement required | author |
| (sentinel) `unknown` | Reserved for migration tooling; never an authoring target | n/a |

## Transitions (allowed)

```
draft → active           (sign-off complete; _skeleton_notes cleared)
draft → withdrawn        (abandon)
active → deprecated      (replacement available; soft retire)
active → superseded      (replacement mandatory; hard retire)
active → withdrawn       (rare; emergency rollback)
deprecated → superseded  (replacement landed)
```

Transitions NOT allowed:

- `superseded → *` (terminal).
- `withdrawn → *` (terminal).
- `deprecated → active` (requires a fresh `draft → active` cycle).
- Backwards moves (e.g. `active → draft`) — open a new `draft` pack
  instead.

## 7-step authoring flow (typical)

1. **Open `draft`** — create `agent_packs/ap_YYYY_NNN_<slug>.md` with
   front-matter `lifecycle_state: draft` and `_skeleton_notes` block.
2. **Compose body** — fill cluster identity, roles, responsibilities,
   handoff surface.
3. **Self-validate** — run
   `python3 scripts/agent_library/validate_agent_pack.py
   agent_packs/ap_YYYY_NNN_<slug>.md`.
4. **Layer 1 lint** — run
   `python3 scripts/governance/lint_layer_separation.py` to ensure no
   project-name leakage in body.
5. **Open review** — surface in batch close report (or as a sibling
   proposal if architectural).
6. **Sign-off** — `executive` flips `lifecycle_state` to `active` and
   removes `_skeleton_notes`.
7. **Adoption** — adopting projects import the pack via their own
   adoption layer (Batch 7+ assembler integration; until then,
   manual reference is acceptable).

## Retirement flow

1. Author the replacement pack (new `pack_id`, fresh `draft`).
2. Once replacement is `active`, flip the original to `deprecated`
   and populate `superseded_by[]` with the replacement `pack_id`.
3. After adopting projects migrate (tracked via Layer 2 case study
   if needed), flip to `superseded`.

## Schema enforcement

`agent_pack_state.schema.json` rejects state values outside the
6-enum and rejects `superseded`/`deprecated` entries that lack
`superseded_by[]` or `deprecated_at`. The validator additionally
checks that the file's front-matter `lifecycle_state` matches the
ledger's recorded state when both are present.

## Hooks (deferred)

- **`pack_active_hook`** (v4.91) — auto-emit a Failure-Fix entry when
  an `active` pack is later flipped to `withdrawn` (signals
  unexpected rollback).
- **`pack_supersede_hook`** (v4.91) — cross-check that replacement
  pack covers all roles of the retired pack.

Neither hook ships in v4.90. Today the lifecycle is human-driven.

## Cross-references

- Schema: `schemas/agent_library/agent_pack_state.schema.json`
- Boundary: `PACK_BOUNDARY_SPEC.md`
- Validator: `scripts/agent_library/validate_agent_pack.py`
- LTM hook spec (sibling pattern): `docs/15_ltm_v2/`
