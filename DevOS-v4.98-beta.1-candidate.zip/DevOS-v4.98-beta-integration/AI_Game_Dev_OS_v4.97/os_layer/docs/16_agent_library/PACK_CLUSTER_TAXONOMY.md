# Pack Cluster Taxonomy

> **v4.90 Batch 5 Module A**
> Defines the 7-cluster taxonomy that groups the 8 generic roles into
> compose units. Layer 1 (OS Spec). No project names.

## Why clusters?

Roles are **functional primitives**; clusters are **compose units**.
A cluster groups roles that typically ship and evolve together so
adopting projects can import a small number of packs (one per
needed cluster) instead of orchestrating 8 independent role contracts.

A pack in `agent_packs/` MUST belong to exactly one cluster. The
cluster id is enforced by `agent_pack_entry.schema.json` against the
enum below.

## 7 clusters

### 1. `executive`

**Roles**: `executive`, `orchestrator`.

The decision + dispatch surface. Adopting projects always need at
least one `executive` cluster pack — without it, batch sign-off and
multi-agent dispatch have no anchor.

**Seed pack (v4.90)**: `agent_packs/ap_2026_001_executive_cluster.md`.

### 2. `research_design`

**Roles**: `research`, `design`.

Investigation feeds spec; spec feeds implementation. These two roles
are tightly coupled in practice — research without design is a
report nobody acts on, design without research is hand-wavy.
Co-locating them inside a single cluster mirrors the workflow.

**Seed pack (v4.90)**: `agent_packs/ap_2026_002_research_and_design_cluster.md`.

### 3. `implementation`

**Roles**: `implementation`.

Engineering output gets its own cluster: it has a distinct cadence
(daily commits) and a distinct review surface (code review, paired
with `validation`). Solo cluster intentionally — fan-out by
adopting-project agent count happens at the project layer, not here.

**Seed pack (v4.90)**: `agent_packs/ap_2026_003_implementation_cluster.md`.

### 4. `validation`

**Roles**: `validation`.

Solo cluster, same reason as `implementation`: distinct review
authority, must remain independent of the role it audits to keep
the verifier-vs-implementer separation honest.

**Seed pack (v4.90)**: `agent_packs/ap_2026_004_validation_cluster.md`.

### 5. `support`

**Roles**: `support`, `archivist`.

Toolchain + decision archive ship together because they share the
same "background steady-state" cadence and the same governance
surface (CI rules + LTM ledger maintenance). Both write rarely but
broadly across the repo.

**Seed pack (v4.90)**: `agent_packs/ap_2026_005_support_cluster.md`.

### 6. `creative_cluster` (ACTIVE since v4.91 Milestone G; widened in M-H)

**Roles**: `design`, `implementation`, `validation` — composed via
the `evo_2026_002` / `evo_2026_003` capability_promotion exemption
pair (no new role primitive added; the 8-role catalog stays at 8).

Wraps creative production specialists (motion design, asset prompt
authoring, animation QA, engine-side animation implementation, game
UI/UX wireframes, battle HUDs, card prefabs, design tokens, Figma
handoff, Godot UI implementation planning, UI/UX audit) for adopting
projects.

The cluster is multi-sub-domain by design: each new sub-domain emits
its own capability_promotion proposal, the validator widens its
allow-list, and the single seed pack
(`agent_packs/ap_2026_006_creative_cluster.md`) accumulates
`skills.required[]` and `references[]` entries.

**Sub-domains shipped in v4.91**:

| sub-domain | proposal | skills | invariant | milestone |
|---|---|---|---|---|
| 2D character animation | `evo_2026_002` | 8 (5 design + 2 implementation + 1 validation) | inv_013 | M-G |
| game UI/UX | `evo_2026_003` | 8 (5 design + 2 implementation + 1 validation) | inv_014 | M-H |

**Seed pack (v4.91)**: `agent_packs/ap_2026_006_creative_cluster.md`
(16 skills total post-M-H).

**Activation gate**: every creative_cluster pack MUST list **at
least one** of the registered authorising proposal ids in its
`references[]`:

- `proposals/evo_2026_002_creative_cluster_role_aliasing.md`
- `proposals/evo_2026_003_creative_cluster_uiux_subdomain.md`

The validator (`scripts/agent_library/validate_agent_pack.py`)
enforces the gate in closed-form: cluster equality + presence of
any registered authorising proposal id (M-H c0 widened the registry
from a single proposal id to a tuple of ids).

### 7. `tools_cluster` (DEFERRED → v4.91 / v4.92)

**Roles (planned)**: a thin overlay on top of `support` for projects
that need MCP / external-tool integration agents as first-class roles
(rather than support-side automation). Held back because the
boundary against `support` is not yet sharp enough to justify a
separate cluster. May follow the `creative_cluster` activation
pattern (capability_promotion exemption) when a concrete first pack
lands.

## Per-cluster invariants

- A cluster MUST have at least one `active` pack before adopting
  projects can claim coverage of its roles.
- A pack MUST list ≥1 role in `roles[]`; every role MUST belong to
  the cluster's role set documented above.
- Cross-cluster role aliasing (the same `role_id` appearing in packs
  from different clusters) requires a `capability_promotion`
  proposal; otherwise the validator rejects the second pack. The
  `creative_cluster` activation in v4.91 M-G is the first instance
  of this pattern (`evo_2026_002`); v4.91 M-H widens the same
  cluster's authorising proposal set by adding `evo_2026_003` for
  the game UI/UX sub-domain. At least one registered authorising
  proposal id MUST appear in the pack's `references[]` for the
  validator exemption to apply.

## Coverage matrix (v4.91 M-G + M-H baseline)

| cluster | seed pack | roles covered | sub-domains | status |
| --- | --- | --- | --- | --- |
| `executive` | `ap_2026_001` | executive + orchestrator | — | draft (Batch 5) |
| `research_design` | `ap_2026_002` | research + design | — | draft (Batch 5) |
| `implementation` | `ap_2026_003` | implementation | — | draft (Batch 5) |
| `validation` | `ap_2026_004` | validation | — | draft (Batch 5) |
| `support` | `ap_2026_005` | support + archivist | — | draft (Batch 5) |
| `creative_cluster` | `ap_2026_006` | design + implementation + validation (per evo_2026_002 + evo_2026_003) | animation (M-G) + game UI/UX (M-H) | draft (M-G + M-H) |
| `tools_cluster` | — | — | — | deferred to v4.91 / v4.92 |

All 8 roles in `AGENT_ROLE_CATALOG.md` remain covered. The
creative_cluster pack composes existing roles via capability
promotion rather than introducing a new primitive, and accumulates
sub-domains through additional capability_promotion proposals.

## Cross-references

- Roles: `AGENT_ROLE_CATALOG.md`
- Pack contract: `PACK_BOUNDARY_SPEC.md`
- Lifecycle: `PACK_LIFECYCLE_GUIDE.md`
- Schemas: `schemas/agent_library/`
- Seed packs: `agent_packs/ap_2026_00[1-6]_*.md`
- Capability promotion (animation sub-domain): `proposals/evo_2026_002_creative_cluster_role_aliasing.md`
- Capability promotion (game UI/UX sub-domain): `proposals/evo_2026_003_creative_cluster_uiux_subdomain.md`
