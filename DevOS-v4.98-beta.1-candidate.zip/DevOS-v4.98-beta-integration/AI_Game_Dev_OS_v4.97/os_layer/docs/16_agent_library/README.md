# 16 — Agent Library / Pack Architecture

> **v4.90 Batch 5 — P1-1 Agent Library / Pack Architecture**
> **Status**: docs + schemas + validator + 5 cluster seed packs
> (skeleton). No assembler integration in v4.90 (D6=B); no project-name
> coupling (D8=A). The 5 seed packs are accepted as the per-cluster
> baseline; the remaining 2 clusters (`creative_cluster` /
> `tools_cluster`) are deferred to v4.91.
> **Layering principle**: this directory MUST stay project-name-free
> (Layer 1 OS Spec). The sibling `agent_packs/` directory has a Layer 2
> regex exemption for `ap_\d{4}_\d{3}*.md` so that seed packs can cite
> case studies when needed (mirrors the `proposals/` + `evo_*`
> arrangement from Batch 6).

## Purpose

Carve agent role definitions and reusable agent compositions out of
the runtime adoption surface and into a first-class, schema-validated
library. Every project that adopts v4.90 should be able to **select a
minimal pack** rather than copy-pasting per-agent prompts, and every
OS Core evolution touching agent behaviour should land here before
the `assemble_project_attachment.py` pipeline integrates it (Batch 7+).

## Documents in this directory

| File | Role | Status |
| --- | --- | --- |
| `README.md` (this file) | Module entry point + NOT-in-v4.90 guardrails | skeleton |
| `AGENT_ROLE_CATALOG.md` | 8 generic `role_id` values + scope/writeback | skeleton |
| `PACK_BOUNDARY_SPEC.md` | What is / is not allowed inside a pack file | skeleton |
| `PACK_LIFECYCLE_GUIDE.md` | 6-state pack lifecycle (draft → active → deprecated) | skeleton |
| `PACK_CLUSTER_TAXONOMY.md` | 7-cluster taxonomy + which roles each cluster owns | skeleton |

## Sister artefacts

- `schemas/agent_library/agent_role.schema.json` — per-role contract
  (draft-07, 1.0.0).
- `schemas/agent_library/agent_pack_entry.schema.json` — per-pack
  front-matter contract (draft-07, 1.0.0).
- `schemas/agent_library/agent_pack_state.schema.json` — per-pack
  lifecycle state tracker, mirrors `proposal_state.schema.json`.
- `scripts/agent_library/validate_agent_pack.py` — read-only validator
  (GUIDED tier, Batch 5 Module C).
- `agent_packs/` — the ledger itself (Layer 1 root with `ap_*` regex
  exemption). Contains 5 cluster seed packs in v4.90.

## Two-layer discipline (CRITICAL)

Documents in this module MUST stay **principle-level** and
**project-name-free**. Concrete project agent rosters that illustrate
a pack belong in a future `STATE_SURFACE_MIGRATION_CASE_<PROJECT>.md`
under `docs/14_state_surface_governance/` or in a Batch 5.5 Layer 2
adoption case (e.g. workbuddy_private), NOT inline here.

Seed pack files (`agent_packs/ap_*.md`) may cite Layer 2 case studies
by relative path, but MUST NOT inline project-name content themselves.

## 8 generic role_id values (see AGENT_ROLE_CATALOG.md)

```
executive       — strategic decision, batch sign-off
orchestrator    — task dispatch, multi-agent coordination
research        — domain investigation, evidence collection
design          — architecture & spec design (UI / content / numerics)
implementation  — code & engineering output
validation      — test, QA, fingerprint verification
support         — toolchain, CI, environment
archivist       — memory, doc history, decision archive (LTM hookup)
```

The names are deliberately generic English labels; they are NOT
intended to map 1:1 onto any single adopting project's agent roster
(e.g. multi-agent rosters with distinct titles, or EP-driven rosters
with consolidated authority). Adopting projects compose their own
roster by selecting which packs to import.

## 5 cluster seed packs (Module D, v4.90 baseline)

| File | cluster | role_ids |
| --- | --- | --- |
| `agent_packs/ap_2026_001_executive_cluster.md` | `executive` | executive + orchestrator |
| `agent_packs/ap_2026_002_research_and_design_cluster.md` | `research_design` | research + design |
| `agent_packs/ap_2026_003_implementation_cluster.md` | `implementation` | implementation |
| `agent_packs/ap_2026_004_validation_cluster.md` | `validation` | validation |
| `agent_packs/ap_2026_005_support_cluster.md` | `support` | support + archivist |

Remaining clusters (`creative_cluster`, `tools_cluster`) deferred to
v4.91 — see PACK_CLUSTER_TAXONOMY.md §"Deferred clusters".

## Batch 5 deliverables (target close)

- 5 skeleton docs (this file + 4 siblings)
- 3 schemas in `schemas/agent_library/`
- `scripts/agent_library/validate_agent_pack.py` GUIDED
- `agent_packs/README.md` + 5 cluster seed packs
- 1 capability matrix promotion: rows `09_agent_library` and
  `10_pack_activation` move from `deprecated` to `requires_adapter`,
  driving scored 12→14 / deprecated 2→0 / informational 2→0. See
  V4_90_README §5.9 (Step 5.10) for the full closure checklist.

## What is NOT in v4.90 Batch 5

- **No `assemble_project_attachment.py` integration** (D6=B).
  The assembler is untouched; pack selection is a documentation /
  schema contract only in v4.90.
- **No project-specific case study inlined**. workbuddy_private
  Layer 2 adoption is deferred to a Batch 5.5 follow-up.
- **No agent runtime hookup**. Packs describe roster + responsibility;
  per-agent prompt assembly remains an adopting-project concern.
- **No automatic pack lifecycle transitions**. State changes are still
  human-driven edits guarded by the validator.
- **No `creative_cluster` / `tools_cluster` seeds**. Two of seven
  clusters are deferred to v4.91.
