# Agent Role Catalog

> **v4.90 Batch 5 Module A**
> Enumerates the 8 generic `role_id` values accepted by
> `schemas/agent_library/agent_role.schema.json`.
> Layer 1 (OS Spec). No project names.

## Why a closed enum?

A closed `role_id` enum keeps adoption surfaces auditable: every
imported pack must declare which roles it ships, and every adopting
project can grep for "which packs cover the `validation` role" without
chasing free-form labels. New roles require a meta-proposal
(`proposal_kind: capability_promotion` or `architecture_principle`)
that updates this catalog + the schema enum + the cluster taxonomy.

## Generic-label discipline

Role labels are **deliberately generic** English nouns describing
*function*, not *job title*. They MUST NOT encode any single adopting
project's agent roster:

- ❌ `executive_producer`, `qa_playtest`, `economy_designer` as
  role-axis labels — job titles and project-specific titles do not belong in
  the 8-role axis.
- ✅ `executive`, `validation`, `design` — generic functions an
  adopting project can map onto its own agent names.

`executive_producer` may still appear as an explicit OS control owner where a
schema allows it; it is not a replacement for the generic `executive` role.

The lint script `scripts/governance/lint_layer_separation.py`
PROJECT_NAME_PATTERNS list captures known project-specific titles and
will fail CI if they leak into Layer 1.

## Roles (8)

### 1. `executive`

Strategic decision-making and batch-level sign-off. Owns the
"go/no-go" call on irreversible changes (capability promotion,
schema break, sprint close).

- **Scope**: decision-only.
- **Writeback**: no writeback to canonical files; rationale recorded
  in archivist's history.
- **Typical inputs**: roll-up reports, risk register, exit criteria.
- **Typical outputs**: signed-off decision record (Layer 2 case
  study or proposal `accepted` transition).
- **v4.92 control sheet**: `os_control_plane/leads/executive_producer.capability.json`.
  `producer` and `executive_producer` are governance owner labels mapped to
  this executive role axis; they are not pack production agents.

### 2. `orchestrator`

Task dispatch and multi-agent coordination. Decomposes a batch into
ordered steps, assigns owners, tracks blocking dependencies.

- **Scope**: coordination.
- **Writeback**: via parent (executive) — orchestrator does not edit
  canonical OS files directly.
- **Typical inputs**: batch plan, dependency graph.
- **Typical outputs**: per-step task list, handoff manifests.
- **Boundary**: orchestrator decides how approved work is decomposed and
  routed; it does not make product go/no-go, priority, or milestone closure
  calls.

### 3. `research`

Domain investigation, evidence collection, prior-art survey.
Read-only by definition.

- **Scope**: read-only.
- **Writeback**: research notes (separate directory or PR description);
  never directly into canonical schemas / matrix.
- **Typical inputs**: existing docs, external references, codebase
  greps.
- **Typical outputs**: evidence report (Phase 1 of a Plan workflow).

### 4. `design`

Architecture and specification design covering UI, content, numerics,
data shapes. Produces docs that downstream `implementation` consumes.

- **Scope**: spec.
- **Writeback**: docs (`docs/*/`), schemas (jointly with implementation).
- **Typical inputs**: research evidence, executive constraints.
- **Typical outputs**: spec docs, schema drafts, ADRs.

### 5. `implementation`

Code and engineering output. Translates design into source tree
mutations.

- **Scope**: code.
- **Writeback**: source tree (`scripts/`, runtime modules, test
  fixtures), with paired test additions.
- **Typical inputs**: design specs, schema drafts.
- **Typical outputs**: code commits, refactors.

### 6. `validation`

Testing, QA, fingerprint verification, regression gating. Verifies
that what was built matches what was specified.

- **Scope**: verify-only.
- **Writeback**: reports (`tests/` outputs, validator JSON, lint
  reports); does NOT mutate the artefacts under test.
- **Typical inputs**: validator scripts, fingerprint definitions, test
  fixtures.
- **Typical outputs**: test results, verifier reports, QA findings.

### 7. `support`

Toolchain, CI, environment, repository hygiene. Keeps the development
loop reliable.

- **Scope**: infra.
- **Writeback**: `scripts/`, configs, lint rules, CI definitions.
- **Typical inputs**: failing builds, slow tests, missing tooling.
- **Typical outputs**: CI workflow updates, dependency bumps,
  governance lint extensions.

### 8. `archivist`

Memory curation, doc history, decision archive. Bridge between live
work and Long-Term Memory (`docs/15_ltm_v2/`).

- **Scope**: record-only.
- **Writeback**: `ltm/` ledger, MEMORY.md long-term entries, archived
  daily logs.
- **Typical inputs**: closed sprints, accepted proposals, closed
  Failure-Fix entries.
- **Typical outputs**: LTM ledger appends, summarised daily logs,
  decision archive entries.

## Cross-references

- Schema: `schemas/agent_library/agent_role.schema.json`
- Cluster mapping: `PACK_CLUSTER_TAXONOMY.md`
- Pack contract: `PACK_BOUNDARY_SPEC.md`
- Validator: `scripts/agent_library/validate_agent_pack.py`
