---
title: Pack Lifecycle State Model
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: 14.6
protected_invariants:
  - inv_003_state_machine_doc_schema_aligned
---

# Pack Lifecycle State Model

> **v4.90 Batch 5 Module B → Batch 14 Step 14.6**
> Mirrors the 9-state structure of `docs/13_migration/ADOPTION_STATE_MODEL.md`
> and `docs/17_self_evolution/PROPOSAL_STATE_MODEL.md`, sized down for
> agent-pack lifecycle (5 states / 6 transitions).
> Layer 1 (OS Spec). No project names.

## States (5)

```
draft        — pack manifest being authored, not yet published to the
                catalog; runtime consumers MUST NOT load
active       — pack is published and may be activated by adopting
                projects; canonical operating state
deprecated   — pack still works but a replacement has been signalled;
                grace period before supersession
superseded   — pack has been replaced by another pack (referenced via
                superseded_by); terminal — runtimes MUST switch to
                the replacement
withdrawn    — pack retracted by author; terminal — runtimes MUST
                stop loading; no replacement guarantee
```

## State diagram

```
                   ┌─────────┐
                   │  draft  │
                   └────┬────┘
                        │ publish
              ┌─────────┴────────┐
              │                  │
              ▼                  ▼
      ┌───────────────┐    ┌────────────┐
      │    active     │    │ withdrawn  │   ← pre-publication
      └───────┬───────┘    └────────────┘     retraction
              │
   ┌──────────┼─────────────┐
   │          │             │
   ▼          ▼             ▼
┌──────────┐ ┌────────────┐ ┌────────────┐
│deprecated│ │ superseded │ │ withdrawn  │
└────┬─────┘ └────────────┘ └────────────┘
     │
     ▼  (replacement landed)
┌────────────┐
│ superseded │  ← terminal
└────────────┘
```

**Terminal states**: `superseded`, `withdrawn`. No outgoing
transitions; subsequent change requires a fresh `ap_YYYY_NNN_*`
pack ID.

## Transition table (6 allowed)

| From | To | Allowed | Trigger |
| --- | --- | --- | --- |
| `draft` | `active` | yes | author publishes pack to catalog |
| `draft` | `withdrawn` | yes | author retracts before publication |
| `active` | `deprecated` | yes | replacement signalled; grace period opens |
| `active` | `superseded` | yes | direct replacement landed (no grace period) |
| `active` | `withdrawn` | yes | author retracts an active pack |
| `deprecated` | `superseded` | yes | replacement landed after deprecation grace |

**Forbidden / not modelled**:
- `superseded → *`, `withdrawn → *` (terminal)
- `draft → deprecated|superseded` (cannot be deprecated/superseded
  before active)
- `deprecated → active` (no un-deprecate path; bump version + new
  pack ID instead)
- `deprecated → withdrawn` (deprecated packs ride out grace; if
  retraction is needed, use a fresh pack)

## Schema

`schemas/agent_library/agent_pack_state.schema.json` validates the
per-pack state document. Key constraints:

- `pack_id` matches `^ap_\d{4}_\d{3}_[a-z0-9_]+$`
- `lifecycle_state` is one of the 5 enum values above
- `transition_history[]` entries use an `allOf.anyOf` whitelist of
  the 6 transitions above (matches the
  `capability_adoption_state.schema.json` Batch 2.5 pattern and
  the `proposal_state.schema.json` Batch 6 pattern)

Conditional-required fields (encoded in `agent_pack_entry.schema.json`):
- `lifecycle_state: superseded` → `superseded_by` (pattern
  `^ap_\d{4}_\d{3}_[a-z0-9_]+$`) required
- `lifecycle_state: withdrawn` → `withdrawn_at` required

## Layer Discipline

Layer 1 (OS Spec). No project names. Per-pack adoption evidence
goes into Layer 2 case studies under
`docs/14_state_surface_governance/STATE_SURFACE_MIGRATION_CASE_*.md`
with the regex exemption.

Cross-machine consistency:
- 9 → 9 → 5 state count progression (proposal / cap_adoption /
  pack_lifecycle) reflects scope: proposals are mutable artifacts,
  capabilities go through adoption phases, packs are static
  publication units.
- All three state machines share the same `transition_history`
  schema pattern (`allOf.anyOf` whitelist + `from / to / at /
  actor / trigger` entry shape) so a single validator can iterate
  the family.
- Master index lives at `docs/STATE_MACHINES_INDEX.md`.
- Bidirectional alignment between this doc's transition table
  and the schema's anyOf whitelist is enforced by
  `scripts/governance/check_state_machine_alignment.py`.
