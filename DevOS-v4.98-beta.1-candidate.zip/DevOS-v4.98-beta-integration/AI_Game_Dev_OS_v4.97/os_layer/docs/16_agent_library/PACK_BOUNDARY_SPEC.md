# Pack Boundary Spec

> **v4.90 Batch 5 Module A**
> Defines what an `agent_packs/ap_*.md` file MAY and MUST NOT contain.
> Layer 1 (OS Spec). No project names.

## Purpose

A pack is a **compose unit**: it nominates which roles ship together,
their responsibilities, and how they interact at the orchestration
boundary. A pack is NOT a runtime prompt template, NOT an agent
implementation, and NOT a project roster.

## File-level shape

Every pack file under `agent_packs/` MUST:

1. **Be named** `ap_YYYY_NNN_<cluster_slug>.md`
   (matches lint regex `^ap_\d{4}_\d{3}.*\.md$`).
2. **Open with YAML front-matter** (between `---` fences) conforming
   to `schemas/agent_library/agent_pack_entry.schema.json`.
3. **Carry a Markdown body** that documents:
   - Which roles the pack provides (must be a subset of the 8 in
     `AGENT_ROLE_CATALOG.md`).
   - Cluster identity (must match `PACK_CLUSTER_TAXONOMY.md`).
   - Interaction surface — which other clusters this pack typically
     hands off to / receives from.
   - Lifecycle state (mirrors `agent_pack_state.schema.json`).

## Required front-matter fields (summary)

| Field | Type | Constraint |
| --- | --- | --- |
| `pack_id` | string | Matches filename stem; regex `^ap_\d{4}_\d{3}_[a-z0-9_]+$` |
| `pack_version` | string | Semver, e.g. `0.1.0-beta` |
| `cluster` | enum | One of 7 cluster ids (see taxonomy) |
| `roles` | array<string> | Non-empty; values drawn from 8-role enum |
| `lifecycle_state` | enum | One of 6 states (see lifecycle guide) |
| `created_at` | string | ISO-8601 date or datetime |
| `references` | array<string> | Relative paths to docs / schemas / Layer 2 cases |

The schema enforces these; the validator rejects extra unknown fields
unless they begin with `_skeleton_notes` (mirrors the convention in
adoption + governance schemas).

## What a pack MUST NOT contain

- **Per-agent prompt text**. Prompts belong to the adopting project's
  runtime assembly, not to the canonical OS spec.
- **Project-name strings**. The lint script will fail CI on leakage
  of any project-specific identifier (project names, sprint ids,
  project-specific agent titles); see
  `scripts/governance/lint_layer_separation.py` PROJECT_NAME_PATTERNS
  for the registered set. Layer 2 case studies citing concrete
  projects MUST live in
  `docs/14_state_surface_governance/STATE_SURFACE_MIGRATION_CASE_*.md`
  or in a Batch 5.5 follow-up doc, not inside the pack file.
- **Implementation code**. Packs are spec, not source. Code lives in
  `scripts/agent_library/` and `scripts/<consuming-module>/`.
- **Runtime configuration**. No env vars, no API keys, no per-deploy
  switches. Those are project-side concerns.
- **Cross-cluster role overlap (without proposal)**. A given role may
  appear in **at most one** pack within a single cluster. Cross-pack
  role aliasing requires a `capability_promotion` proposal.

## What a pack MAY contain

- **Responsibility narrative** for each role (≤200 words per role).
- **Handoff diagrams** in fenced code blocks (text or simple ASCII).
- **References to schemas, validator scripts, lifecycle hooks** by
  relative path.
- **Open questions / known limits** in a dedicated section.
- **`_skeleton_notes`** front-matter key for in-progress packs (must
  be cleared before transition to `lifecycle_state: active`).

## Validation contract

A pack passes `validate_agent_pack.py` when:

1. Front-matter parses as YAML and validates against
   `agent_pack_entry.schema.json`.
2. `cluster` matches an entry in `PACK_CLUSTER_TAXONOMY.md`.
3. Every `roles[]` entry matches the 8-role enum.
4. `pack_id` matches filename stem.
5. No project-name pattern is detected in body
   (delegates to the lint module).
6. Lifecycle state is consistent with what
   `agent_pack_state.schema.json` permits for fresh packs (only
   `draft`, `active`, or `superseded`-with-replacement allowed at
   author time).

The validator is **read-only**. It returns exit 0 on pass, 1 on
violation, 4 on missing inputs (matches Batch 4 / 6 conventions).

## Cross-references

- Front-matter contract: `schemas/agent_library/agent_pack_entry.schema.json`
- State tracker: `schemas/agent_library/agent_pack_state.schema.json`
- Cluster registry: `PACK_CLUSTER_TAXONOMY.md`
- Lifecycle: `PACK_LIFECYCLE_GUIDE.md`
- Validator: `scripts/agent_library/validate_agent_pack.py`
