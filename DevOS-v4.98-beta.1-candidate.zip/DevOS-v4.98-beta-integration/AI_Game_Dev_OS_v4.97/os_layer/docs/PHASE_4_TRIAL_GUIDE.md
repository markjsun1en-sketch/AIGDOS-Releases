# v4.89 — Phase 4 Trial Guide (First Beta Sprint Walk-through)

> **Audience**: Project team running their **first Beta Sprint** on
> v4.89. Prerequisite: you have already completed the one-time
> setup in `USAGE_GUIDE.md` (picked a profile, run assemble, bound
> your hooks). This guide walks through the mechanics of a single
> sprint close + verifier run using the S1 Mock scenario as a
> **golden reference**.
>
> **Scope**: In v4.89, "trial" still means running the verifier against
> a sprint's audit trail (the verifier is now MIXED-tier: `init` /
> `evidence` / `close` run at GUIDED inherited from the v4.88-stable
> B+ Bridge Hardening line; `execution` / `external` remain at SCAFFOLD
> and are slated for promotion to GUIDED in v4.90). Real-project
> end-to-end trials with live TAPD and real merges are out of v4.89
> scope — that is v4.90 work. This guide prepares the team so that when
> you do run a real Beta Sprint, the evidence you produce is verifier-
> ready.

## 0. What you will learn

By the end of this walk-through you should be able to:

1. Recognize each of the 11 canonical event types in an audit log.
2. Write a `sprint_close_checklist.md` that the verifier can parse.
3. Run `verify_beta_sprint_exit.py` against your sprint's artifacts
   and read its JSON output.
4. Interpret a PASS / CONDITIONAL / FAIL verdict (including which
   findings block the sprint and which are acceptable).
5. Know what to fix when the verdict is not PASS and which findings
   are v4.89 upgrade-only.

## 1. Pre-sprint checklist (Sprint 0)

Before you start the first Beta Sprint, confirm:

- [ ] Your project has run `scripts/assemble_project_attachment.py`
      successfully (status: ready). See `USAGE_GUIDE.md §3`.
- [ ] Runtime profile chosen; `config/profiles/<profile>.json`
      matches your declared `runtime_state.json` profile field.
- [ ] `policy/adaptation/*.yaml` files exist for every hook you use.
- [ ] Tracker (TAPD / Jira / Linear / …) account + workspace
      configured.
- [ ] Git branch strategy matches your profile's expected
      `isolation_unit`:
      - `worktree` → `agent/<role>/<task>` branches merged serially
      - `branch` → dedicated per-task branches
      - `shared_session` → single session, no per-task branches
      - `project_defined` → whatever the project uses (document it)
- [ ] Sprint entry in your tracker exists (e.g. TAPD iteration).
- [ ] `runtime/state/runtime_state.json` initialized with sprint_id,
      profile, initialized_at timestamp.
- [ ] `runtime/logs/` directory exists and the audit collector can
      write to it.

`docs/09_beta_sprint/SPRINT0_PRECHECK.md` has the authoritative
version of this list.

## 2. During the sprint — emit audit events faithfully

Every sprint must produce an audit log that the verifier can parse.
Formally: `runtime/logs/mcp_audit.jsonl` (one JSON object per line,
UTF-8).

### 2.1 The 11 canonical event families

From `docs/05_observability/AUDIT_LOG_STANDARD.md`:

| Family | When to emit |
| --- | --- |
| `runtime.create` | New task / story created from spec |
| `runtime.transition` | Task state changed (open → in_progress → …) |
| `runtime.handoff` | Role-to-role handoff (engineering → qa etc.) |
| `runtime.validation` | QA validation result recorded |
| `runtime.snapshot` | Sprint snapshot captured |
| `runtime.archive` | Task archived at sprint close |
| `external.tapd.write` | Writeback to tracker (TAPD / Jira / …) |
| `external.tapd.verify` | Read-after-write verification of the tracker |
| `merge.apply` | Candidate branch merged into integration line |
| `merge.cleanup` | Worktree / branch cleaned up after merge |
| `trial.check` | Sprint exit readiness check result |

### 2.2 Minimum common fields

Every event must carry:

```json
{
  "event_type": "runtime.transition",
  "timestamp": "2026-05-04T12:30:00Z",
  "actor": "engineering",
  "source_layer": "runtime_registry",
  "status": "ok",
  "summary": "FT-101 open -> in_progress"
}
```

Optional but strongly recommended: `task_id`, `object_id`,
`runtime_profile`, `sprint_id`, `evidence_refs`.

### 2.3 TAPD silent-failure rule

If an `external.tapd.write` succeeds (`response_ok=true`) but the
paired `external.tapd.verify` fails (`verification_ok=false`), that
is an **ERROR** — not a WARN — because the tracker is silently
out-of-sync with your runtime state.

See `AUDIT_LOG_STANDARD.md §Red Flags` for the other silent-failure
patterns.

## 3. At sprint close — prepare the artifacts

Three files drive the verifier:

1. `runtime/state/runtime_state.json` — profile + task states
2. `runtime/logs/mcp_audit.jsonl` — the audit trail
3. `runtime/state/sprint_close_checklist.md` — human-ticked checklist

### 3.1 Checklist markdown contract

The verifier scans for `- [x]` / `- [X]` (ticked) and `- [ ]`
(unticked) prefixes at the start of trimmed lines. Everything else
is ignored. Example template:

```markdown
# Sprint Close Checklist — sprint-N

## Initialization integrity
- [x] Runtime environment initialized without demo residue
- [x] Runtime profile selection explicit and validated
- [x] Starter family slice identifiable

## Execution integrity
- [x] Worker execution followed declared profile
- [x] Isolation rules respected
- [x] Merge/apply ownership respected
- [x] No unresolved dirty state

## External sync integrity
- [x] Tracker writes validated before use
- [x] Read-after-write verification performed for every write
- [x] Parent/child aggregation not stale at close

## Evidence integrity
- [x] Audit log parseable
- [x] Task / handoff / validation evidence exists
- [x] Recovery events (if any) documented

## Close integrity
- [x] Sprint snapshot generated
- [x] Archive transition recorded
- [x] Delta summary recorded
```

If any `- [ ]` remains, the close check will emit an ERROR finding.

### 3.2 Terminal event requirement

The audit log should end with at least one of:

- `runtime.archive` (tasks archived at close)
- `trial.check` (explicit exit-readiness check)

Missing both → close WARN.

## 4. Run the verifier

From the project root (not the v4.89 package root):

```bash
python3 /path/to/AI_Game_Dev_OS_v4.89_Release/scripts/verify_beta_sprint_exit.py \
    --workspace . \
    --audit-log runtime/logs/mcp_audit.jsonl \
    --runtime-state runtime/state/runtime_state.json \
    --sprint-close-checklist runtime/state/sprint_close_checklist.md \
    --sprint sprint-N --profile codex
```

Output is a JSON report with fields:

| Field | Meaning |
| --- | --- |
| `verdict` | PASS / CONDITIONAL / FAIL |
| `error_count` | number of ERROR-severity findings |
| `warn_count` | number of WARN-severity findings |
| `findings` | list of `{category, severity, message, ...}` |
| `maturity_tier` | `MIXED` in v4.89: `init` / `evidence` / `close` run at **GUIDED**; `execution` / `external` still at **SCAFFOLD** |
| `upgrade_tag` | `v4.89-trial-upgrade` — marks which categories still await a GUIDED upgrade. **v4.90 status**: upgrade work scheduled for Batch 0.5 (parallel with Batch 1 Adoption Core); tag string preserved unchanged for audit-consumer backwards compatibility (per CHANGELOG L37 / RELEASE_NOTES L29 / MATURITY_MATRIX L615) |

Exit codes:

| Exit | Verdict | Meaning |
| --- | --- | --- |
| 0 | PASS | Sprint closed cleanly |
| 1 | CONDITIONAL | Only WARN findings — operator may accept |
| 2 | FAIL | At least one ERROR — sprint is not a valid trial |
| 3 | INTERNAL_ERROR | Script crashed; report to repo maintainer |

## 5. Walk-through: the S1 Codex golden sample

`examples/_mock_baselines/trial_scenarios/S1_codex_tapd_git/` ships with a fully
working sample. Run it now:

```bash
cd /path/to/AI_Game_Dev_OS_v4.89_Release
python3 scripts/verify_beta_sprint_exit.py \
    --audit-log examples/_mock_baselines/trial_scenarios/S1_codex_tapd_git/sample_audit.jsonl \
    --runtime-state examples/_mock_baselines/trial_scenarios/S1_codex_tapd_git/runtime_state.json \
    --sprint-close-checklist examples/_mock_baselines/trial_scenarios/S1_codex_tapd_git/sprint_close_checklist.md \
    --sprint sprint-s1 --profile codex
```

Expected output (verdict `PASS`, `error_count: 0`, `warn_count: 0`):

```json
{
  "sprint": "sprint-s1",
  "profile": "codex",
  "workspace": ".../AI_Game_Dev_OS_v4.89_Release",
  "workspace_explicit": false,
  "categories_checked": ["init", "execution", "external", "evidence", "close"],
  "error_count": 0,
  "warn_count": 0,
  "findings": [],
  "verdict": "PASS",
  "maturity_tier": "MIXED",
  "upgrade_tag": "v4.89-trial-upgrade"
}
```

> **Note (v4.89)**: `MIXED` means the three categories
> `init` / `evidence` / `close` already run the deeper GUIDED checks
> (added by the v4.88-stable B+ Bridge Hardening line and inherited
> by v4.89), while `execution` / `external` are
> still SCAFFOLD-tier and will be upgraded in v4.90. Older Mock
> fixtures may still emit `"maturity_tier": "SCAFFOLD"` — this is
> expected and does not indicate a regression.

Key aspects of the S1 sample to study and mirror:

| Aspect | S1 pattern |
| --- | --- |
| Task count | 3 features (`FT-101` / `FT-102` / `FT-103`) |
| Lifecycle per task | create → transition → handoff → validation → done → tapd.write + verify → merge.apply + cleanup |
| Terminal events | `runtime.snapshot` → `runtime.archive` → `trial.check` |
| Checklist | 17/17 items ticked |
| Profile fields | exactly match `config/profiles/codex.json` |

See `examples/_mock_baselines/trial_scenarios/S1_codex_tapd_git/README.md` for the
full narrative timeline and a breakdown of what each of the 5 checks
evaluated.

## 6. Differential scenarios (S3 / S4 / S5 / S5b)

To understand each verdict tier, also inspect:

| Scenario | Profile | Verdict | Why |
| --- | --- | --- | --- |
| `S3_cursor_tapd_git` | cursor | PASS | Same structure as S1 on a different profile — verifier is profile-agnostic at this tier |
| `S4_claude_subagents_tapd_git` | claude_code_subagents | FAIL | runtime_state.json omits `audit_collector` + `context_loading_method` → 2 ERROR via M7.3 Lift gate (commit 6414cac, 2026-05-06); plus 1 missing `external.tapd.verify` and 1 missing `merge.cleanup` → 2 WARN. Pre-M7.3 expected was CONDITIONAL/exit=1; post-M7.3 the same fixture correctly escalates to FAIL/exit=2. |
| `S5_workbuddy_private_tapd_git` | workbuddy_private | FAIL | `verification_ok=false` verify + 10/16 unticked checklist items → 2 ERROR findings |
| `S5b_workbuddy_private_hardened_pass` | workbuddy_private | PASS | B+ hardening counter-example: same profile as S5 but with hardened codepaths + full checklist → proves workbuddy_private **can** close cleanly |

Run all 5 at once via:

```bash
bash scripts/run_mock_smoke.sh
```

See `docs/09_beta_sprint/PHASE_4_STEP_3_SMOKE_REPORT.md` for the
canonical pass record.

## 7. Interpreting findings

When the verdict is **not** PASS, work through findings in this
order:

### 7.1 Close ERROR — unticked checklist items

Fix by reviewing why each item is unticked:
- Is the underlying work actually incomplete? → do the work
- Is the item unnecessary for this project? → revise the template
- Is the item outside v4.89 scope? → tick it with a
  bracketed note, e.g. `[x] Delta summary recorded (deferred, see v4.90 backlog)`

### 7.2 External ERROR — `verification_ok=false`

Investigate immediately — this is the silent-failure pattern.
Possible causes:
- Tracker API temporarily inconsistent (retry)
- Field-mapping bug (internal_state → mapped_state mismatch)
- Permission / rate-limit issue
- Adapter stub still returning fake data (configuration mistake)

Rerun the write + verify pair after fixing.

### 7.3 Close WARN — no terminal event

Emit either `runtime.archive` (for each archived task) or
`trial.check` at the end of your close procedure.

### 7.4 External WARN — missing `tapd.verify`

Emit the `external.tapd.verify` event after every successful
`external.tapd.write`. This is cheap (one read-after-write call)
and closes the silent-failure window.

### 7.5 Execution WARN — no merge.cleanup

Either actually run cleanup, or document a deferred cleanup in a
follow-up sprint. Cleanup WARN is non-blocking at SCAFFOLD tier
(execution category is still SCAFFOLD in v4.89), but it
will become stricter when v4.90 upgrades
`check_execution_integrity` to GUIDED and cross-checks
`cleanup_count` against `apply_count`.

## 8. What v4.89 ships vs what v4.90 adds

As of v4.89 (inheriting from the v4.88-stable B+ Bridge Hardening line),
the verifier runs GUIDED-tier checks on three of the five integrity
categories:

| Category | v4.89 tier | What runs now |
| --- | --- | --- |
| init | **GUIDED** | demo_* residue scan; adapter-manifest cross-check; profile alias (`profile` / `runtime_profile`) accepted |
| execution | SCAFFOLD | only minimum transition + apply/cleanup pairing |
| external | SCAFFOLD | only write+verify pairing |
| evidence | **GUIDED** | handoff+validation cross-check per task_id; evidence_refs path existence |
| close | **GUIDED** | archive transition recorded; checklist fully ticked + terminal event |

The remaining upgrades (scheduled for v4.90 Batch 0.5; see `00_v4_89_close_report.md` §I and `V4.89_BACKLOG.md`):

| Upgrade item | Status |
| --- | --- |
| Execution: isolation_unit vs branches touched; dirty worktree probing; cleanup_count < apply_count WARN | scheduled for v4.90 Batch 0.5; `upgrade_tag` string preserved for audit-consumer compat |
| External: retry_count thresholds; reconcile cross-reference | scheduled for v4.90 Batch 0.5; same compat note |

The `v4.89-trial-upgrade` tag appears in the verifier's JSON output
`upgrade_tag` field so tooling can distinguish the MIXED v4.89 verdicts
from future fully-GUIDED verdicts. The string itself is preserved
verbatim across the v4.89 → v4.90 cycle for audit-consumer
backwards-compat (the upgrade work moves but the tag string stays).
v4.90 will additionally introduce a `v4.90_status` field (alongside
`upgrade_tag`) so consumers can read upgrade progress without breaking
the original contract.

## 9. First-trial success criteria

You are ready to run a real-project Beta Sprint when:

- [ ] `run_mock_smoke.sh` passes (5/5 matches) in your checkout
- [ ] You can explain what each of the 11 event families means
- [ ] You have a checklist template adapted to your project
- [ ] Your tracker integration emits both write + verify events
- [ ] Your merge flow emits both apply + cleanup events
- [ ] Your profile's `config/profiles/<profile>.json` values match
      the `runtime_state.json` you will produce at runtime

## 10. Regression assertions (B+ Bridge Hardening)

v4.89 inherits four module-level smoke scripts from v4.88-stable that assert the
hardened codepaths behave as documented. Treat them as the quick-check
safety net when modifying runtime logic:

| Script | Asserts |
| --- | --- |
| `scripts/_smoke_workbuddy_collector.py` | `append_audit()` validates envelope shape (event_type / timestamp / actor) and refuses malformed records |
| `scripts/_smoke_init_runtime_env.py` | `init_runtime_env.py` performs real profile bootstrap (not scaffold), seeds `tapd_config_instance`, runs overlay preflight, and respects `--force` |
| `scripts/_smoke_run_beta_sprint_check.py` | `run_beta_sprint_check.py` five modules each return expected status on fresh / degraded workspaces |
| `scripts/_smoke_adapters.py` | `tapd_adapter_stub.py` + `git_adapter_stub.py` provide file-backed stores, normalize shapes, and support read-after-write verify |

Run any smoke directly with `python3 scripts/_smoke_*.py`; the shell
harness `scripts/run_mock_smoke.sh` runs the 5 Mock scenarios end-to-end
and is a superset check.

### 10.1 Under-the-hood: what B+ hardened

| Module | Before B+ | After B+ |
| --- | --- | --- |
| `runtime/observability/runtime_event_collectors/workbuddy_collector.py` | stub `append_audit` — accepted anything | validates envelope, warns on malformed records, writes `mcp_audit.jsonl` |
| `integrations/tapd_adapter_stub.py` | returned fake data, no persistence | file-backed `runtime/state/tapd_local_store.json`; `_live_path` writes + reads real records; `_emit_silent_failure_audit` on mismatch |
| `integrations/git_adapter_stub.py` | no merge events | `merge_apply` + `merge_cleanup` emit paired events with normalized shape |
| `scripts/init_runtime_env.py` | wrote a minimal scaffold state | real initialization; writes both `profile` / `runtime_profile`; overlay preflight; recovery hints |
| `scripts/run_beta_sprint_check.py` | did not exist at this granularity | 5-module check (docs / profile / adapter+collector / agents_guard / checklist) |
| `scripts/verify_beta_sprint_exit.py` | all-SCAFFOLD verdict | MIXED tier: init / evidence / close elevated to GUIDED |

## 11. Cross-references

- `USAGE_GUIDE.md` — companion: one-time setup and profile selection
- `docs/09_beta_sprint/BETA_SPRINT_EXIT_CRITERIA.md` — authoritative
  5 integrity category definitions
- `docs/09_beta_sprint/SPRINT0_PRECHECK.md` — pre-sprint readiness
- `docs/09_beta_sprint/SPRINT_CLOSE_CHECKLIST.md` — portable
  checklist template
- `docs/09_beta_sprint/FAILURE_RECOVERY_PLAYBOOK.md` — what to do
  when the verdict is FAIL
- `docs/09_beta_sprint/PHASE_4_STEP_3_SMOKE_REPORT.md` — current
  verifier pass record
- `examples/_mock_baselines/trial_scenarios/` — 5 Mock scenarios (S1/S3/S4/S5/S5b)
- `scripts/verify_beta_sprint_exit.py` — the verifier
- `scripts/run_mock_smoke.sh` — 5-scenario smoke harness

## 12. v4.89 Phase 1 — new regression surfaces

v4.89 Phase 1 (tag `v4.89-phase-1`) adds a Python-level regression
suite on top of the 4 smoke scripts:

| Path | Count | What it asserts |
| --- | --- | --- |
| `tests/test_wrap_external_record.py` | 8 | canonical audit-envelope contract (source_layer / runtime_profile / event_id / timestamp / audit_status) |
| `tests/test_tapd_envelope_roundtrip.py` | 4 | tapd `_live_path` + envelope-wrap roundtrip |
| `tests/test_git_merge_envelope.py` | 3 | git `merge_apply` / `merge_cleanup` envelope pairing |
| `tests/test_collector_malformed_fallback.py` | 3 | `append_audit(strict=False)` writes to `mcp_audit.malformed.jsonl` instead of silently dropping |
| `tests/test_profile_alias.py` | 3 | init writes both `profile` / `runtime_profile`; verify accepts either |
| `tests/test_runtime_state_path.py` | 4 | `runtime_state.json` canonical location + pointer shim |
| `tests/test_check_fallback.py` | 4 | `run_beta_sprint_check.py` workspace → package_root fallback |
| `tests/test_collector_append_audit.py` | 2 | B+ append_audit regression safety net |

Run them all:

```bash
cd /path/to/AI_Game_Dev_OS_v4.89
python3 -m pytest tests/ -v
```

CI enforces this suite on every push / PR via
`/.github/workflows/v4_89_tests.yml` (server-side) plus
`/.pre-commit-config.yaml` (local pre-commit). See `DEVELOPMENT.md`
for setup.
