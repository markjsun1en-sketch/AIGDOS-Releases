# PROJECT_STATE_ISOLATION_RULES.md — v4.91 Addendum-A

> **Layer 1 (OS Spec).** Every byte of project state lives under `<Project>/.ai_dev_os/`. This document codifies the rules and the migration recipe for projects whose state was accidentally written into a release bundle directory.

---

## 1. The single rule

> All project-side AI Dev OS runtime state — logs, handoffs, registry entries, memory, exports, checkpoints, rollback plans, profiles — MUST live under `<Project>/.ai_dev_os/`. Nothing outside that directory is project-truth-owner.

The Hub MUST honour this rule at every write. `project_mount.yaml :: write_scope[]` is the schema-level allowlist; `cannot_write[]` is the defensive deny list; `validate_project_mount.py` enforces overlap detection.

## 2. The canonical layout

```text
<Project>/.ai_dev_os/
├── project_mount.yaml          # B2 + Addendum-A mount-level superset
├── project_runtime_protocol.yaml  # F-T-01 tenancy contract
├── version_lock.yaml           # B3 + Addendum-A per-project version pin
├── capability_adoption_state.yaml
├── migration_state.yaml
├── project_profile.yaml
├── host_profile.yaml           # OPTIONAL per-project override
├── active_packs.yaml
├── local_registry/
├── local_handoffs/
├── local_logs/
├── local_memory/
├── exports/
├── checkpoints/
├── rollback_plans/
└── tools/                      # ONLY for mount_mode=thin_scaffold
```

## 3. Anti-patterns (forbidden generated paths)

| Forbidden | Why |
|---|---|
| `<Project>/v490_release/` | release bundle inside project root |
| `<Project>/v491_release/` | release bundle inside project root |
| `<Project>/AI_Game_Dev_OS_v*/` | any historic version dir |
| `<Project>/AI_Game_Dev_OS_Core/` | Core copy inside project root |
| `<Project>/vendor/ai_dev_os/**` (when not vendor_snapshot) | Core copy under vendor/ outside vendor_snapshot mode |
| `<Project>/v*release/**/{logs,handoffs,registry,memory}/` | project state written into release bundle |

The first 5 are detected by `detect_embedded_release_bundle.py`. The last (project-state-inside-release-bundle) is caught by the migration audit recipe below.

## 4. Audit recipe — projects whose state leaked into a release bundle

### Step 1 — detect

```bash
python3 scripts/hub/detect_embedded_release_bundle.py \
  --project-root /path/to/project \
  --format json
```

If `status=violation`, list the detected paths.

### Step 2 — audit released-bundle state

For each detected bundle directory, search for runtime state:

```bash
find <Project>/v490_release \
  \( -path "*/logs/*" -o -path "*/handoffs/*" \
     -o -path "*/registry/*" -o -path "*/memory/*" \) \
  -type f
```

Output: `embedded_release_audit_report.md` listing every file that should have been written into `.ai_dev_os/` but landed in the release bundle.

### Step 3 — migrate state back

```text
v490_release/**/logs       → .ai_dev_os/local_logs/
v490_release/**/handoffs   → .ai_dev_os/local_handoffs/
v490_release/**/registry   → .ai_dev_os/local_registry/
v490_release/**/memory     → .ai_dev_os/local_memory/
```

`git mv` preferred. Filenames carry their own provenance via timestamp prefixes and existing handoff naming convention.

### Step 4 — relocate the release bundle

Move the cleaned (state-stripped) release bundle to an external location:

```text
<Project>/v490_release/   →   ../AI_Game_Dev_OS_Releases/v4.90_release/
                          OR  /shared/AI_Game_Dev_OS_Core/v4.90_release/
```

### Step 5 — fix project_mount.yaml

```yaml
schema_version: "1.1.0"
project_id: "<id>"
mount_mode: "external_core"
mounted_core:
  mount_mode: "external_core"
  core_path: "../AI_Game_Dev_OS_Releases/v4.90_release"
  core_version: "4.90-Release"
  writable: false
# ... write_scope, cannot_write, etc.
```

### Step 6 — block re-occurrence via .gitignore

```gitignore
# AI Dev OS release bundles MUST NOT live inside the project root
v490_release/
v491_release/
AI_Game_Dev_OS_v*/
AI_Game_Dev_OS_Core/
vendor/ai_dev_os/        # only when mount_mode != vendor_snapshot
```

If the project legitimately uses `vendor_snapshot`, replace the last line with an explicit comment: `# vendor/ai_dev_os/ tracked under vendor_snapshot manifest lock`.

### Step 7 — re-validate

```bash
python3 scripts/hub/validate_project_mount.py --project-id <id>
python3 scripts/hub/detect_embedded_release_bundle.py --project-root <Project>
python3 scripts/hub/health_all_projects.py
```

Expected results:

- VPM-001..012: all PASS or SKIP (no FAIL)
- detect: status=clean
- health: project healthy

## 5. Cross-project state (Hub side)

Hub-side state — `hub/global_os_config.yaml`, `projects.index.json`, `mounts.yaml`, `hub_state.json` (persistent), plus `versions.lock` (generated at runtime by `lock_core_version.py`, **not** shipped as a release seed — see `core_update_policy.md §3`) — lives in the Core OS package, NOT in any project. The Hub may aggregate facts about projects (see `version_lock.embedded_release_bundle{}`); it never writes per-project content into Core.

## 6. Charter alignment

- **#2** — no project names in Core
- **#5** — no hardcoded RH literals (this document uses generic placeholders)
- **#9** — Hub never copies Core into projects
- **#14** — No Full Release Copy by Default

Layer 1. No project names.
