# MOUNT_CONTRACT — v4.91 Project Mount Boundary Contract

> **Layer 1 (OS Spec).** No project-specific names. v4.91 B2 c3 (relocated to `docs/20_project_mount/` in v4.91 Addendum-A c4).
>
> **Companion doc**: [`../19_tenancy/TENANCY_CONTRACT.md`](../19_tenancy/TENANCY_CONTRACT.md) (v4.91 F-T-01 — runtime_namespace.claims[]).
>
> **Sister docs (Addendum-A)**: [`PROJECT_MOUNT_MODEL.md`](PROJECT_MOUNT_MODEL.md) · [`MOUNT_BOUNDARY_CONTRACT.md`](MOUNT_BOUNDARY_CONTRACT.md) · [`PROJECT_STATE_ISOLATION_RULES.md`](PROJECT_STATE_ISOLATION_RULES.md).
>
> **Schema**: [`schemas/mount/project_mount.schema.json`](../../schemas/mount/project_mount.schema.json) (v4.91 B2 c1, bumped to schema_version 1.1.0 in Addendum-A c1).
>
> **Validator**: [`scripts/hub/validate_project_mount.py`](../../scripts/hub/validate_project_mount.py) (v4.91 B2 c2, integrated 12 VPM-* checks in Addendum-A c2).
>
> **Detection**: [`scripts/hub/detect_embedded_release_bundle.py`](../../scripts/hub/detect_embedded_release_bundle.py) (v4.91 Addendum-A c2).

---

## 1. What this contract declares

The Mount Boundary Contract governs **how a project mounts the v4.91 Central Runtime Hub**. It covers the surface that the Hub MUST honour when writing into the project root, the lifecycle context the project is operating in, and the host-execution profile the project advertises.

It is the **mount-level superset** of the F-T-01 Tenancy Contract:

| Layer | File | Concerns |
|---|---|---|
| F-T-01 Tenancy Contract | `<project>/.ai_dev_os/project_runtime_protocol.yaml` | `runtime_namespace.claims[]` — which `<core>/ltm/project/<id>/**` paths are sovereign to this project |
| **B2 Mount Contract** | `<project>/.ai_dev_os/project_mount.yaml` | `write_scope[]` / `cannot_write[]` / `stage` / `game_dev_phase` / `preflight` / `host_profile` |

The two coexist. F-T-01 stays canonical for tenancy claims; B2 carries the mount-level write-boundary + lifecycle + preflight policy reference.

---

## 2. Required fields

```yaml
schema_version: "1.1.0"        # const-locked (post-Addendum-A widening, Addendum-B narrowing)
project_id: "<lower_snake_case>"  # MUST match the id passed to hub link_project
mount_mode: "external_core"    # 3-enum: external_core (default) / thin_scaffold / vendor_snapshot
                                #   (post-Addendum-B; 'link' removed per Charter #15)

stage: "incubation"            # 7-enum: incubation / alpha / beta /
                               # release_candidate / production /
                               # maintenance / sunset
game_dev_phase: "prototype"    # 7-enum: prototype / mvp / vertical_slice /
                               # alpha_build / beta_build / production /
                               # post_launch
                               # — INDEPENDENT of stage; v4.90.9
                               # schema 1.1.0 split.

write_scope:                   # allowlist; minItems=1; every entry MUST
  - ".ai_dev_os/preflight/**"  # be rooted at .ai_dev_os/ and end with **
  - ".ai_dev_os/audit/**"

cannot_write:                  # explicit deny list; minItems=1
  - "src/**"
  - "assets/**"
  - "project.godot"
```

### Why both `write_scope` and `cannot_write`?

**Defense in depth.** `write_scope` is the positive declaration. `cannot_write` is the safety net — even if a future schema change widens `write_scope`, `cannot_write` continues to deny the source/asset trees.

The validator (B2 c2) rejects any overlap between the two (direct equality OR glob containment in either direction).

---

## 3. Optional fields

```yaml
core_os_package:               # B3 will harden this with version_lock.yaml
  package_name: "AI_Game_Dev_OS_v4.91"
  version: "4.91-Release"

preflight:                     # B5B Multi-Agent Preflight Consensus
  enabled: true
  policy_path: ".ai_dev_os/preflight/preflight_policy.yaml"
                               # MUST point under .ai_dev_os/preflight/

host_profile:                  # B5C Optional IDE Auto Escalation Adapter
  host_tool: "workbuddy"       # codex / cursor / claude_code / workbuddy / other
  supports_subagents: "environment_dependent"
                               # Charter anti-pattern #13: never claim
                               # unconditional auto-multi-agent default.
```

Projects opting out of B5B/B5C simply omit those blocks (or set `preflight.enabled: false`).

---

## 4. Validation policy

The validator (`scripts/hub/validate_project_mount.py --project-id <id>`) implements a **two-tier** acceptance:

| Mount yaml present | Protocol yaml present | Outcome |
|---|---|---|
| ✓ | ✓ or ✗ | **Validate mount.yaml strictly** (schema + cross-field). Protocol still parsed if present (B5+ retrieval). |
| ✗ | ✓ | **F-T-01 fallback**: parse protocol via `_tenancy_reader.load_project_claims`. Print deprecation hint suggesting B2 mount.yaml adoption. Exit 0. |
| ✗ | ✗ | Exit 1. |

Cross-field checks for `project_mount.yaml`:

1. `project_id` MUST match the linked project_id (the one passed via `--project-id`).
2. `write_scope` ∩ `cannot_write` = ∅ (no direct equality, no glob containment in either direction).
3. `stage` and `game_dev_phase` MUST be valid enum values (schema-enforced; re-checked post-parse for clearer error messages).

---

## 5. What the Hub does NOT do

The Hub is **strictly read-mostly** within the project root:

* Never copies any part of `<core>/` into the project root (Charter anti-pattern #9).
* Never writes into `src/` / `assets/` / `project.godot` / `Assets/` / `Packages/` / any source tree.
* Never auto-derives `project_id` or `hub_id` from path or hostname (Charter anti-pattern #2).
* Never silently re-initialises an active Hub (`init_hub.py` exit 2 if `hub_status != 'uninitialised'`).
* Never auto-resolves a tenancy or version-lock conflict — surfaces them via exit codes 1/2 and waits for explicit operator action.

The CLIs that DO mutate state (`init_hub` / `link_project` / `unlink_project` / `validate_project_mount --refresh-fingerprint` / `health_all_projects`) all use the v4.91 B1 c3 `HubTransaction` two-phase commit primitive: `flock` advisory lock + tempfile/`os.replace` per file + byte-level snapshot rollback if any phase-2 write raises.

---

## 6. Anti-patterns explicitly forbidden

The contract forbids these patterns — all enforced at schema or validator level:

| # | Anti-pattern | Where enforced |
|---|---|---|
| 1 | `mount_mode: "copy"` / `mount_mode: "link"` (alias) | schema enum `["external_core", "thin_scaffold", "vendor_snapshot"]` only (post-Addendum-B; Charter anti-patterns #9 + #15) |
| 2 | `auto_subagent_without_explicit_request: true` in any `host_profile` | schema `const: false` |
| 3 | Hard-coded project name in Core schema / non-fixture test | Layer 1 lint (inv_002) |
| 4 | `--allow-extra` / `--skip-validation` flags on validators | compile-time absence (no such flags exist) |
| 5 | Auto-promote a project to `production` without explicit operator step | schema enum + `init_hub.py` requires explicit `--hub-id` |
| 6 | Idempotent `unlink_project` (silent no-op on unknown id) | exit 2 + `'not linked'` |
| 7 | Cross-tenant memory promotion without human approval | B5 `auto_apply_allowed: false` (lands in B5) |
| 8 | Adding `ltm/project/**` to manifest `transient_patterns` to mask leaks | F-V-01 bidirectional contract makes the whitelist unnecessary |

---

## 7. Migration from F-T-01-only to B2

Existing projects that ship only `project_runtime_protocol.yaml` continue to validate (with a deprecation hint). To upgrade, add `project_mount.yaml` alongside. Minimal migration:

```yaml
# .ai_dev_os/project_mount.yaml — minimal B2 mount declaration
schema_version: "1.1.0"
project_id: "<your_id>"
mount_mode: "external_core"
stage: "<your_stage>"           # copy from project_profile.stage
game_dev_phase: "<your_phase>"  # copy from project_profile.game_dev_phase
write_scope:
  - ".ai_dev_os/preflight/**"
  - ".ai_dev_os/audit/**"
cannot_write:
  - "src/**"
  - "assets/**"
```

The protocol yaml stays canonical for `runtime_namespace.claims[]`. B5+ retrieval routing reads both.

---

## 8. References

* [`TENANCY_CONTRACT.md`](TENANCY_CONTRACT.md) — F-T-01 runtime_namespace claim contract
* [`schemas/mount/project_mount.schema.json`](../../schemas/mount/project_mount.schema.json) — authoritative schema
* [`schemas/mount/host_profile.schema.json`](../../schemas/mount/host_profile.schema.json) — host capability matrix schema
* [`schemas/hub/projects_index.schema.json`](../../schemas/hub/projects_index.schema.json) — Hub-side catalogue
* [`schemas/hub/mounts.schema.json`](../../schemas/hub/mounts.schema.json) — Hub-side mount snapshot
* RELEASE_NOTES `## v4.91 Milestone A — B2` — closure notes + commit references
