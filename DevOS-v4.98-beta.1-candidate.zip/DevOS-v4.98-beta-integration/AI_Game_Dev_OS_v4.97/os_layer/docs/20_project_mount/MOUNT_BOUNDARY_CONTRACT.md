# MOUNT_BOUNDARY_CONTRACT.md — v4.91 Addendum-A

> **Layer 1 (OS Spec).** What the Hub MUST NOT do across the mount boundary, and what `validate_project_mount.py` enforces. Companion to `PROJECT_MOUNT_MODEL.md` (architectural model) and `MOUNT_CONTRACT.md` (mount.yaml field contract).

---

## 1. The mount boundary

For every linked project, two hard separations exist:

```text
─── Hub side ───────────────────────────────────────────────
  hub/                    (Hub's own state — persistent:
                           global_os_config, projects.index,
                           mounts, hub_state; generated at
                           runtime: versions.lock, update_plans,
                           reports — see core_update_policy.md §3)
  schemas/, scripts/,
  runtime/, skills/, ltm/  (Core OS — readonly from project's POV)

─── Project side ──────────────────────────────────────────
  <Project>/.ai_dev_os/    (project-truth-owner — Hub MAY write here)
  <Project>/src/, assets/,
  project.godot, etc.      (project source — Hub MUST NOT write)
  <Project>/vendor/        (only under vendor_snapshot, readonly)
```

The Hub crosses the boundary **only** by:

1. Reading project's `.ai_dev_os/project_mount.yaml` (and friends).
2. Writing inside `.ai_dev_os/` per `write_scope[]` allowlist.
3. (vendor_snapshot only) reading `<Project>/vendor/ai_dev_os/<pkg>/` as readonly reference material.

## 2. What the Hub MUST NOT do

| # | Forbidden Hub action | Enforcement point |
|---|---|---|
| 1 | Write outside `.ai_dev_os/` (e.g. modify `src/`, `assets/`, `project.godot`) | `project_mount.yaml :: write_scope[]` schema pattern (`^\.ai_dev_os/.*\*\*$`) + `cannot_write[]` deny list |
| 2 | Copy the full Core release bundle into `<Project>/` by default | Charter anti-pattern #14, host_profile schema `copy_full_release_bundle_by_default: const false` |
| 3 | Treat any `<Project>/v*release/` or `<Project>/AI_Game_Dev_OS_*/` as authoritative | `forbidden_generated_paths[]` + `detect_embedded_release_bundle.py` + VPM-003 |
| 4 | Auto-spawn subagents without explicit task prompt | host_profile schema `auto_subagent_without_explicit_request: const false` |
| 5 | Auto-promote a project to next stage / phase / version | Charter anti-pattern #6 (no evidence-threshold auto-promote) |
| 6 | Mutate Core (`mounted_core.core_path`) from inside a project workflow | `mounted_core.writable: const false` (schema) + VPM-006 |
| 7 | Treat `embedded_release_bundle.detected=true` as approved without explicit `vendor_snapshot_mode=true` | `version_lock.embedded_release_bundle.allowed` cross-field check |
| 8 | Generate project state files inside any release bundle directory | `forbidden_default_actions[].generate_project_state_inside_release_bundle` |

## 3. What `validate_project_mount.py` enforces (VPM-* matrix)

Twelve checks land at runtime. Each returns `PASS` / `FAIL` / `SKIP`. Any `FAIL` exits the validator with status 1.

| Code | Description | Skip condition |
|---|---|---|
| VPM-001 | mount_mode field exists | — |
| VPM-002 | mount_mode is one of [external_core, thin_scaffold, vendor_snapshot] | — (post-Addendum-B; 'link' removed per Charter #15) |
| VPM-003 | no embedded release bundle (or sanctioned vendor_snapshot) | — (always runs; consumes detect_embedded_release_bundle) |
| VPM-004 | `<Project>/.ai_dev_os/` exists | — |
| VPM-005 | `mounted_core.core_path` set | mounted_core block absent (1.1.0 compat window) |
| VPM-006 | `mounted_core.writable: false` | mounted_core block absent |
| VPM-007 | vendor_snapshot mode → `release_bundle_policy.allow_vendor_snapshot=true` | mount_mode != vendor_snapshot |
| VPM-008 | vendor_snapshot → `exclude_vendor_snapshot_from_runtime_scan=true` | mount_mode != vendor_snapshot |
| VPM-009 | vendor_snapshot → `exclude_vendor_snapshot_from_ltm_retrieval=true` | mount_mode != vendor_snapshot |
| VPM-010 | vendor_snapshot → `exclude_vendor_snapshot_from_gate_scope=true` | mount_mode != vendor_snapshot |
| VPM-011 | `write_scope[]` does not include any `forbidden_generated_paths[]` glob | — |
| VPM-012 | `ownership.project_truth_owner = ".ai_dev_os"` when block present | ownership block absent |

## 4. Embedded-release-bundle detection contract

`scripts/hub/detect_embedded_release_bundle.py` scans the project root for:

| Pattern | Match type | Disposition |
|---|---|---|
| `v490_release/` | exact dir | unconditional violation |
| `v491_release/` | exact dir | unconditional violation |
| `AI_Game_Dev_OS_v*/` | glob dir | unconditional violation |
| `AI_Game_Dev_OS_Core/` | exact dir | unconditional violation |
| `vendor/ai_dev_os/` | exact dir | conditional — sanctioned **only** under `mount_mode=vendor_snapshot` |

Verdicts:

- `clean` — no detection; exit 0
- `sanctioned` — vendor_snapshot mode + only conditional path; exit 0
- `violation` — any unconditional detection, OR conditional path under non-vendor_snapshot mode; exit 1

## 5. Per-project version lock contract

`hub/versions.lock :: embedded_release_bundle{}` aggregates the cross-project view at lock time:

```yaml
embedded_release_bundle:
  detected: false   # true iff any linked project has detect=violation
  allowed: false    # true iff every detection is sanctioned vendor_snapshot
  vendor_snapshot_mode: false
  excluded_from_gate_scope: true
  excluded_from_ltm_retrieval: true
```

`lock_core_version.py` refuses to advance when `detected=true ∧ allowed=false` (Charter anti-pattern #14 enforcement at the lock layer).

## 6. Charter alignment

- **#2** — no project names in Core (mount.yaml lives under `.ai_dev_os/`, never in Hub `mounts.yaml`)
- **#9** — Hub never copies Core into projects (mount_mode enum)
- **#11** — preflight is not a gate-pass (orthogonal)
- **#13** — no auto multi-agent (host_profile const guard)
- **#14** — No Full Release Copy by Default (this entire document)

Layer 1. No project names.
