# Rule D — Illegal Dependency Scan

> **Constraint ID**: RULE_D
> **Source**: `AI_Game_Dev_OS_Architecture_v3.md §VI.D` (L219-225)
> **Severity**: HARD (hard constraint)

## v3 source text (verbatim)

> ### D. Illegal Dependency Scan
> The Linter Gate must explicitly check for:
> - Illegal cross-layer `import` / `using` statements.
> - Logic-layer references to UI libraries.
> - Core modules directly depending on engine presentation components.
> - Test-helper code leaking into the production runtime directory.
> - Hard-coded resource paths and uncleared temporary debug switches.

## Formal requirements (five categories of scans)

| Sub-constraint | Content | Typical violation |
| --- | --- | --- |
| **D1** Illegal cross-layer import | domain must not import presentation | `from ui.hud import update` inside domain code |
| **D2** Logic layer references UI library | domain must not import UI-framework namespaces | `import UnityEngine.UI` inside `Domain/` |
| **D3** Core module depends on presentation components | core must not reference engine Node / GameObject types directly | `Sprite2D` used inside combat rules |
| **D4** Test-helper leakage | `test/` / `mock/` files must not appear in runtime directories | `prod/scripts/mock_data.py` |
| **D5** Hard-coded paths & debug switches | absolute paths / `DEBUG_MODE = True` / stray `print()` | `data_path = "/Users/dev/..."` |

## Violation examples (FAIL)

### D1 — cross-layer import

```python
# domain/combat.py — violates D1
from presentation.hud import HUD  # ❌ domain must not reference presentation
```

### D2 — logic layer pulls in a UI library

```csharp
// Domain/CombatSystem.cs — violates D2
using UnityEngine.UI;  // ❌ Domain must not use UI namespaces
using UnityEngine.UIElements;  // ❌
```

### D3 — core depends on engine components

```gdscript
# core/combat_rules.gd — violates D3
extends Sprite2D  # ❌ core rules must not inherit a rendering node
```

### D4 — test code leakage

```
prod/
├── scripts/
│   ├── combat.py
│   └── mock_battle_data.py   # ❌ mock file in prod directory
```

### D5 — hard-coded path + debug switch

```python
# scripts/runtime/registry.py — violates D5
SAVE_PATH = "/Users/macsun/Documents/..."  # ❌ absolute path
DEBUG_PRINT = True                          # ❌ debug switch not cleaned up
if DEBUG_PRINT:
    print("loading:", data)                 # ❌ leaked print
```

## Passing example (PASS)

```python
# domain/combat.py — ✅ only imports from same layer or upstream
from domain.types import Unit, DamageEvent
from application.event_bus import emit

def apply_damage(attacker: Unit, target: Unit) -> None:
    damage = calculate_damage(attacker, target)
    target.hp -= damage
    emit("combat.damage_applied", DamageEvent(target.id, damage))
```

## Layer-dependency rules (AllowList baseline)

```
presentation  →  application  →  domain
     ↓              ↓              ↓
 integration   integration    integration
     ↓
 engine/os (allowed at presentation only)
```

**Allowed** (→ direction):
- presentation → application (UI subscribes to events)
- application → domain (use-case orchestration)
- integration → any layer (external adapters, bidirectional allowed)

**Forbidden**:
- domain → presentation ❌
- domain → integration ❌ (unless explicitly annotated as `@domain_port`)
- core → engine-specific API ❌

## Checklist (materialised when Phase 3 implements this)

### D1 implementation
- [ ] Scan every import/using statement in each source file.
- [ ] Infer the file's layer from its directory (domain / app / presentation / integration).
- [ ] AllowList violation → FAIL with the offending import line number.

### D2 implementation
- [ ] Maintain a UI-library blacklist:
  - Unity: `UnityEngine.UI`, `UnityEngine.UIElements`, `TMPro`.
  - Godot: when inherited as a class, check for `Control`, `Label`, `Button`.
  - Unreal: `UUserWidget`, `SWidget`, `SlateCore`.
- [ ] Verify that domain-directory files do not touch the blacklist.

### D3 implementation
- [ ] Godot: check that classes under the core directory do not `extends` Node-derived types.
- [ ] Unity: check that `Domain/` does not contain `MonoBehaviour`-derived classes (use POCOs).
- [ ] Unreal: check that `Domain/` does not directly inherit from presentation types such as `AActor` / `UObject`.

### D4 implementation
- [ ] Scan prod / release directories for filename patterns: `*mock*`, `*test*`, `*stub*`, `*fake*`, `*_tmp*`, `*debug*`.
- [ ] Match → WARN; a match inside a whitelisted production directory (e.g. `prod/`) → FAIL.

### D5 implementation
- [ ] Absolute-path regex: `/[A-Za-z]/.*` / `[A-Z]:\\.*`.
- [ ] Debug switches: `DEBUG_MODE\s*=\s*True` / `VERBOSE\s*=\s*True`.
- [ ] Orphan `print()`, `console.log()`, `Debug.Log()` in non-test directories.

## Configurable allowlist

`config/linter_policy.yaml`:

```yaml
rule_d:
  allowed_cross_layer_imports:
    - from: integration
      to: [domain, application, presentation]  # adapters may cross layers
  ui_lib_blacklist_unity:
    - UnityEngine.UI
    - UnityEngine.UIElements
    - TMPro
  ui_lib_blacklist_godot:
    - Control
    - Label
  hardcoded_path_patterns:
    - "^/Users/"
    - "^C:\\\\"
  debug_switch_patterns:
    - 'DEBUG_MODE\s*=\s*True'
    - 'VERBOSE\s*=\s*True'
  allowed_print_dirs:
    - tests/
    - scripts/debug/
```

## Relationship to the v4.87 Adapter Contract

The v4.87 `MCP_Adapter_Contract.md` declares the adapter layer to be the **only legal cross-layer bridge**. RULE_D is the enforcement layer of that contract:

- Legitimate adapter stubs (e.g. `git_adapter_stub.py`) present under `integration/` → PASS.
- "Wild" external calls outside `integration/` (e.g. domain code calling `urllib.request` directly) → FAIL.

## Relationship to the RandomHeroes project

Related discipline in RH policy `code_quality_rules.md`:
- Hard-coded paths → use `Config.get_path()`.
- Direct `FileAccess` → use `Config.get_table()`.

RULE_D's D5 sub-constraint is the automated version of that discipline. When Phase 3 tailors the implementation for RH, the RH allowlist can be reused directly.

## Stub implementation

`scripts/linter/rule_d_illegal_dependency_scan.py` — Phase 2 stub (each of the five sub-constraints occupies a placeholder function); Phase 3 delivers the AST scanner.

## References

- v3 source: `AI_Game_Dev_OS_Architecture_v3.md §VI.D`.
- v3 §I.1 Executive Summary item ② also mentions the Architecture Linter.
- Related: RULE_A (one-way events) / RULE_B (data externalisation) / RULE_C (layering).
- v4.87 Adapter Contract as the allowlist basis for integration bridges.
