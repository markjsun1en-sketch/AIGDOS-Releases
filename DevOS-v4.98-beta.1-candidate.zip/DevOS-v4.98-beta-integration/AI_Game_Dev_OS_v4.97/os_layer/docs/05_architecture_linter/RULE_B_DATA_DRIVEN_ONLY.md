# Rule B — Data-Driven Only

> **Constraint ID**: RULE_B
> **Source**: `AI_Game_Dev_OS_Architecture_v3.md §VI.B` (L208-211)
> **Severity**: HARD (hard constraint; failing it means the integration is not healthy)

## v3 source text (verbatim)

> ### B. Data-Driven Only
> - Damage values, enemy stats, drops, resource costs and similar parameters must not be hard-coded into core logic.
> - Every critical numeric value must come from a configuration table, JSON, ScriptableObject, Resource, or an equivalent structured source.
> - AI may only change numbers in the configuration source; writing "temporary constants" inside logic code is forbidden in principle.

## Formal requirements

1. **Single configuration source**: critical numeric values must come from external configuration (Excel→JSON / YAML / ScriptableObject / GDScript Resource / Unreal DataTable).
2. **Zero hard-coding in logic**: domain-layer files (`.py` / `.gd` / `.cs` / `.cpp`) must contain no "magic numbers" (with the exception of structured enum-style boundary constants such as `MAX_PLAYERS = 4`).
3. **AI modification boundary**: an AI agent may only edit configuration, never numeric values inside logic files (project-level agent discipline; the linter enforces the code-side guarantee).

## Violation examples (FAIL)

### Example 1 — Hard-coded damage

```gdscript
# Godot GDScript — violates RULE_B
func _on_fireball_hit(target):
    target.hp -= 50  # ❌ damage 50 hard-coded in logic
    target.burn_duration = 3.0  # ❌ burn duration hard-coded
```

Fix:

```gdscript
# ✅ read from configuration
func _on_fireball_hit(target):
    var spell_data = Config.get_table("spells", "fireball")
    target.hp -= spell_data.damage
    target.burn_duration = spell_data.burn_duration
```

### Example 2 — Enemy stats mixed into code

```csharp
// Unity C# — violates RULE_B
public class GoblinAI : MonoBehaviour {
    void Awake() {
        hp = 30;          // ❌
        damage = 5;       // ❌
        moveSpeed = 2.5f; // ❌
    }
}
```

Fix:

```csharp
// ✅ injected via ScriptableObject
public class GoblinAI : MonoBehaviour {
    [SerializeField] EnemyStatsSO stats;  // configuration source
    void Awake() {
        hp = stats.hp;
        damage = stats.damage;
        moveSpeed = stats.moveSpeed;
    }
}
```

### Example 3 — Hard-coded path (joint violation with RULE_D)

```python
# Python runtime script — violates RULE_B + RULE_D
def load_player_save():
    return open("/Users/dev/project/saves/player.json").read()  # ❌ absolute path
```

Fix:

```python
# ✅ read from config
def load_player_save():
    from runtime_common import resolve_storage_paths
    paths = resolve_storage_paths()
    return (paths['save_dir'] / 'player.json').read_text()
```

## Passing example (PASS)

```
project/
├── data/
│   ├── config_spells.xlsx        # designer-edited
│   ├── config_enemies.xlsx       # designer-edited
│   └── generated/
│       ├── spells.json           # produced by xlsx_to_json.py
│       └── enemies.json          # produced by xlsx_to_json.py
├── game/
│   └── logic/
│       ├── combat.gd             # pure logic, reads data/generated/
│       └── enemy_ai.gd           # pure logic, reads data/generated/
└── tools/
    └── xlsx_to_json.py           # designer pipeline
```

## Checklist (materialised when Phase 3 implements this)

- [ ] Scan `.py` / `.gd` / `.cs` / `.cpp` / `.ts` files under domain/logic and detect numeric literals.
- [ ] Numeric-literal context rules:
  - Inside a function/method → warn (unless the literal is `0 / 1 / -1` or a whitelisted constant).
  - In a module-level `const` declaration → require a config-source reference (`# from config:xxx`).
- [ ] String-literal scan for hard-coded file paths (absolute paths starting with `/` or `C:\`).
- [ ] Usage counters for Godot Resource / Unity ScriptableObject / Unreal DataTable (warn when below threshold).

## Engine/language adaptation notes

| Engine | Recommended configuration source | Numeric boundary |
| --- | --- | --- |
| **Godot 4.x** | Excel→JSON pipeline (`xlsx_to_json.py`) or `Resource` | Only `MAX_XX` / `MIN_XX` boundary constants allowed in code |
| **Unity** | ScriptableObject / Addressables | Same, plus UnityEvent parameters may be hard-coded |
| **Unreal** | DataTable / DataAsset / Primary Data Asset | Same |
| **Python (OS scripts)** | YAML / JSON policy (e.g. v4.87 `config/*.yaml`) | `enum.Enum` constants may be hard-coded |

## Exemptions (allowlist)

The following do not count as violations:
1. Mathematical constants (`PI`, `GOLDEN_RATIO`, `DEG_TO_RAD`).
2. Type boundaries (`INT_MAX`, `MAX_STRING_LENGTH = 256`).
3. Protocol-spec values (HTTP status codes, event type-ID enums).
4. Test code (`test/` directory).
5. Lines explicitly tagged `# linter-ignore: rule_b reason="..."`.

## Stub implementation

`scripts/linter/rule_b_data_driven_only.py` — Phase 2 stub.

## Relationship to the RandomHeroes project

The RH project policy already enforces:
- Hard-coded values → `Config.get()`.
- Chinese text → `GameString.get()`.
- `FileAccess` → `Config.get_table()`.

RULE_B is the **automated guard layer** for that discipline. When Phase 3 tailors a GDScript implementation for the RH project, the RH policy allowlist can be reused directly.

## References

- v3 source: `AI_Game_Dev_OS_Architecture_v3.md §VI.B`.
- RandomHeroes policy: `<UPSTREAM_PROJECT_ROOT>/RandomHeroes/policy/code_quality_rules.md` (project-practice evidence).
- Related constraint: RULE_D (joint detection of hard-coded paths).
