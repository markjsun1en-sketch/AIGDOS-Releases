# Architecture Linter — Four Hard Constraints

> **v4.88_Revise Phase 2 Step 3** REBUILD artifact (preserved in v4.89)
> **Source**: `AI_Game_Dev_OS_Architecture_v3.md §VI Architecture Constraints & Linter Gate` (v3 native chapter)
> **Loss chain**: v4.7 / v4.78 / v4.8.2 / v4.87 / v4.88 RC12 **all missing** (longest loss chain in the workspace, continuously absent since the v3 break)
> **Established**: 2026-04-21

## Core Proposition

v2 already required "separation of logic and visual layers"; v3 **upgraded good architecture from a recommendation to a hard constraint** (v3 §VI L201).

The Architecture Linter Gate is not a code-style check — it is an **architectural health gate**. If it does not pass, even a feature that runs cannot be considered healthy integration (v3 §VI E, L227-229).

## Four Hard Constraints (v3 §VI A-D)

| ID | Constraint | v3 line range | Spec doc | Stub implementation |
| --- | --- | --- | --- | --- |
| **A** | Event-Driven Only | L203-206 | [`RULE_A_EVENT_DRIVEN_ONLY.md`](./RULE_A_EVENT_DRIVEN_ONLY.md) | `scripts/linter/rule_a_event_driven_only.py` |
| **B** | Data-Driven Only | L208-211 | [`RULE_B_DATA_DRIVEN_ONLY.md`](./RULE_B_DATA_DRIVEN_ONLY.md) | `scripts/linter/rule_b_data_driven_only.py` |
| **C** | File-Scale Constraints | L213-217 | [`RULE_C_FILE_SCALE_CONSTRAINTS.md`](./RULE_C_FILE_SCALE_CONSTRAINTS.md) | `scripts/linter/rule_c_file_scale_constraints.py` |
| **D** | Illegal Dependency Scan | L219-225 | [`RULE_D_ILLEGAL_DEPENDENCY_SCAN.md`](./RULE_D_ILLEGAL_DEPENDENCY_SCAN.md) | `scripts/linter/rule_d_illegal_dependency_scan.py` |

## Entry Point

- **Runner**: `scripts/linter/architecture_linter.py` (orchestrates the 4 rules, emits a unified JSON report)
- **Usage**: `python3 scripts/linter/architecture_linter.py --project <path>`
- **Behaviour per rule**: see "Status in v4.89 Release" below. Rule C
  reports real violations; Rule A / B / D return empty stub responses.

## Status in v4.89 Release (current, 2026-05-10 RC3)

| Rule | Spec | Runtime implementation | Maturity tag (runner) | Enforcement in v4.89 |
| --- | --- | --- | --- | --- |
| **A** Event-Driven Only | ✅ [`RULE_A_EVENT_DRIVEN_ONLY.md`](./RULE_A_EVENT_DRIVEN_ONLY.md) | ⚠️ **policy stub** (returns empty violation set) | `STUB` | none |
| **B** Data-Driven Only | ✅ [`RULE_B_DATA_DRIVEN_ONLY.md`](./RULE_B_DATA_DRIVEN_ONLY.md) | ⚠️ **policy stub** (returns empty violation set) | `STUB` | none |
| **C** File-Scale Constraints | ✅ [`RULE_C_FILE_SCALE_CONSTRAINTS.md`](./RULE_C_FILE_SCALE_CONSTRAINTS.md) | ✅ **real, minimal** — line-count / file-size scan with WARN / FAIL thresholds + 3 allowlists (Route A legacy / v4.88 SCAFFOLD / M6.8 trial mirror) | `REAL` | WARN + FAIL reportable |
| **D** Illegal Dependency Scan | ✅ [`RULE_D_ILLEGAL_DEPENDENCY_SCAN.md`](./RULE_D_ILLEGAL_DEPENDENCY_SCAN.md) | ⚠️ **policy stub** (returns empty violation set) | `STUB` | none |

**Reading the linter report (P1-3-A2, 2026-05-10)**: each rule now
declares its `maturity` tag (`REAL` / `STUB`) explicitly, and the runner
reports `status=STUB` for stub rules instead of the previously
misleading `PASS with scanned_files=0`. STUB rules are excluded from
`overall_status` aggregation, so a v4.89 run reports `overall=PASS` /
`WARN` / `FAIL` based only on Rule C (the only REAL rule). When every
active rule is STUB the runner reports `overall=STUB-ONLY` (exit=0).

**Exit-code semantics (consistent with `validate_runtime_paths`,
2026-05-10)**:

- Default: WARNs are advisory; `overall=WARN` returns exit=0.
- `--strict`: WARN escalates to exit=1 (zero-warn gate for CI).
- FAIL always returns exit=2 regardless of --strict.

**Scope of Rule C**: "minimal executable" — it catches the most common
architectural scale defects (oversized single-responsibility files) but
does not yet cover circular import density, god-class heuristics, or
cross-module coupling metrics.

**Honest summary**: the Architecture Linter is **partially operational**
in v4.89. Rule C provides real architectural-scale guardrails; Rule A /
B / D ship as specification + stub so project teams can reference them
but should not rely on automated enforcement until v4.90. The runner's
new `status=STUB` reporting makes that distinction visible at every
invocation.

## Roadmap to v4.90 (full enforcement)

Real implementation of Rule A / B / D is deferred to v4.90. The
deferral is tracked in:

- `V4.89_BACKLOG.md` — entries for Rule A / B / D upgrades
- `RELEASE_NOTES.md` §"Known limitations" — `Architecture Linter rules
  A / B / D real implementations (only rule C is shipped)`

## Phase 2 build origin

Outputs from Phase 2 Step 3 (the rebuild that resurrected this
capability after 7 generations of loss):

- ✅ 4 rule specs (each contains: v3 source excerpt, formal requirements, violation examples, passing examples, checklist, language/engine adaptation notes)
- ✅ 4 rule py stubs (each contains: rule id constant, `check(project_root: Path) -> List[Violation]` interface signature)
- ✅ 1 runner py (`architecture_linter.py`, orchestrates 4 rules and emits JSON report)
- ✅ Rule C graduated from stub to real implementation during Phase 3 onboarding.
- ⏸ Rule A / B / D remain at stub level — see "Status in v4.89 Release" above and the v4.90 roadmap.

## Why this matters

v3 §VI E, verbatim:

> The Architecture Linter Gate is not only a "code style check" — it is an **architectural health gate**.
> If it does not pass, a feature that runs cannot be considered healthy integration.

This is the **structured execution layer** of Evidence-Driven DoD (v3 §II.2) — without the Linter Gate, "evidence passed" degenerates into "it ran". The capability was lost across 7 generations after v4.7 and is one of the core review gaps in v4.88 RC12.

## References

- Source: `AI_Game_Dev_OS_Architecture_v3.md` §VI full chapter
- Plan: `086af2bd06074626ae5a1c88358eb6d2` Phase 2 Step 3
- Phase 0 evidence: historical archive, see CHANGELOG "Phase 1 §C" entry
