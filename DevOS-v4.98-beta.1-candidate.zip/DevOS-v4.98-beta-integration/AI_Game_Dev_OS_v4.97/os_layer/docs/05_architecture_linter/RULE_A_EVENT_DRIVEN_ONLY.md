# Rule A — Event-Driven Only

> **Constraint ID**: RULE_A
> **Source**: `AI_Game_Dev_OS_Architecture_v3.md §VI.A` (L203-206)
> **Severity**: HARD (hard constraint; failing it means the integration is not healthy)

## v3 source text (verbatim)

> ### A. Event-Driven Only
> - Logic-layer state changes may propagate outward only through events, signals, a message bus, or explicitly defined application-layer interfaces.
> - The underlying logic must never call presentation-layer APIs directly.
> - UI, animation, SFX, and VFX may only consume events — they must not reach back into combat rules.

## Formal requirements

1. **Logic-layer outbound channel**: the domain/logic layer communicates outward only by emitting events (emit / signal / pub-sub). It must not import or call the presentation / UI / animation / VFX / audio layers.
2. **Presentation-layer inbound channel**: UI / animation / SFX / VFX may only subscribe to events or query read-only interfaces — they must not call mutator methods on the logic layer.
3. **Boundary protocol**: every event must carry an explicit schema (`event_type` + `payload`); "clever" passing of raw domain objects is forbidden.

## Violation examples (FAIL)

### Example 1 — Logic layer calls UI directly

```csharp
// Unity C# — violates RULE_A
public class CombatSystem {
    void OnAttack(Unit attacker, Unit target) {
        target.HP -= attacker.Damage;
        UIManager.Instance.ShowDamageNumber(target.position, attacker.Damage);  // ❌ logic calls UI directly
    }
}
```

Fix:

```csharp
// ✅ logic emits an event; UI subscribes on its own
public class CombatSystem {
    void OnAttack(Unit attacker, Unit target) {
        target.HP -= attacker.Damage;
        EventBus.Emit("combat.damage_dealt", new DamageEvent(target.id, attacker.Damage));
    }
}
```

### Example 2 — UI writes back into logic state

```gdscript
# Godot GDScript — violates RULE_A
func _on_attack_button_pressed():
    GameState.player.hp = 100  # ❌ UI directly mutates domain state
```

Fix:

```gdscript
# ✅ UI emits an intent event
func _on_attack_button_pressed():
    EventBus.emit("player.action_requested", {"type": "heal", "amount": 100})
```

## Passing example (PASS)

The event bus is the sole bridge:

```
[CombatSystem / AISystem / StateMachine]  (domain)
              ↓ emit("combat.damage_dealt", payload)
        [EventBus]  (application)
              ↓ subscribers
[UIManager / AnimPlayer / VFXSpawner / AudioBus]  (presentation)
```

## Checklist (materialised when Phase 3 implements this)

- [ ] Static scan of domain/logic directories — forbid `import/using` of presentation/UI namespaces.
- [ ] Static scan of presentation directories — forbid `import/using` of domain setter/mutator methods.
- [ ] AST scan of call chains — a direct domain → presentation call counts as a violation.
- [ ] Event naming convention check (`<layer>.<action>` shape).
- [ ] Event payload schema check (must be structured, not loose fields).

## Engine/language adaptation notes

| Engine | Domain recognition | Presentation recognition | Event-bus pattern |
| --- | --- | --- | --- |
| **Godot 4.x (GDScript)** | `logic/` `core/` directories + non-`Node` classes | `ui/` + `Control`-derived + `AnimationPlayer` | Global Autoload `EventBus` + `signal` |
| **Unity (C#)** | `Assets/Scripts/Domain/` + non-`MonoBehaviour` | `Assets/Scripts/UI/` + descendants of `Canvas` | `UnityEvent` / ScriptableObject Event / MessageBus |
| **Unreal (C++/Blueprint)** | `Source/<Project>/Domain/` | `Source/<Project>/UI/` + `UUserWidget` | Delegate + GameplayEvent |

## Exemptions (allowlist)

The following do not count as violations:
1. Debug-only code (wrapped with `#ifdef DEBUG` / `if OS.is_debug_build()`).
2. Unit-test stubs (`test/` or `tests/` directories).
3. Application-layer adapters explicitly tagged `@logic_bridge` (must also be listed in `manifests/pack_definition.json` under `allowed_bridges`).

## Stub implementation

`scripts/linter/rule_a_event_driven_only.py` — Phase 2 stub. Phase 3 replaces it with a real scanner per project language.

## References

- v3 source: `AI_Game_Dev_OS_Architecture_v3.md §VI.A`
- Related constraint: RULE_D Illegal Dependency Scan (cross-layer import check).
- Event-model contract: `docs/04_tooling_and_adapters/AI_Game_Dev_OS_v4.87_Adapter_Contract_Unified_Event_Model.md` (v4.87 event contract — reuse its event-schema convention).
