# Rule C — File-Scale Constraints

> **Constraint ID**: RULE_C
> **Source**: `AI_Game_Dev_OS_Architecture_v3.md §VI.C` (L213-217)
> **Severity**: HARD (hard constraint)

## v3 source text (verbatim)

> ### C. File-Scale Constraints
> To stop AI from cramming everything into one file:
> - When a single file exceeds an agreed threshold (e.g. 300 lines), raise a warning or fail.
> - Input detection, rule computation, feedback dispatch, and UI refresh must not co-habit one God Object.
> - Complex modules must be split into at least two layers such as domain / application / presentation / integration.

## Formal requirements

1. **Line threshold**: hard ceiling of 300 lines by default (per-project override allowed); exceeding it triggers FAIL.
2. **Responsibility isolation**: a single file/class must not combine two or more of {input detection / rule computation / feedback dispatch / UI refresh}.
3. **Minimum layering**: complex modules must split into at least two layers (`domain / application` or `domain / presentation`).

## Violation examples (FAIL)

### Example 1 — God Object

```gdscript
# Godot GDScript — violates RULE_C (481 lines / 4 responsibilities combined)
class_name GameManager extends Node
# ❌ input detection
func _input(event): ...
# ❌ rule computation
func calculate_damage(attacker, target): ...
# ❌ feedback dispatch
func emit_combat_event(data): ...
# ❌ UI refresh
func _process(dt): update_hp_bar(); update_mp_bar(); ...
```

Refactoring:

```
scripts/
├── input/
│   └── player_input_handler.gd       (~80 lines)
├── domain/
│   └── combat_rules.gd               (~120 lines)
├── application/
│   └── combat_event_bus.gd           (~60 lines)
└── presentation/
    └── hud_updater.gd                (~100 lines)
```

### Example 2 — single file over threshold

```python
# 500-line single file — violates RULE_C
# game_logic.py
# class GameLogic:
#     ... 500 lines ...
```

Fix: split into a `game_logic/` package by responsibility.

## Passing example (PASS)

Typical Godot project layering:

```
project/
├── game/
│   ├── input/            # layer 1: input detection
│   │   └── input_map.gd
│   ├── domain/           # layer 2: rule computation
│   │   ├── combat.gd
│   │   ├── inventory.gd
│   │   └── progression.gd
│   ├── application/      # layer 3: event coordination / use-case orchestration
│   │   ├── event_bus.gd
│   │   └── game_flow.gd
│   ├── presentation/     # layer 4: UI / animation / VFX
│   │   ├── hud/
│   │   └── animations/
│   └── integration/      # layer 5 (optional): external-service adapters
│       └── save_adapter.gd
```

Every file under 300 lines, single responsibility.

## Checklist (materialised when Phase 3 implements this)

- [ ] Scan every source file (`.py` `.gd` `.cs` `.cpp` `.ts`) and count lines.
- [ ] Lines ≥ 300 → WARN; ≥ 500 → FAIL.
- [ ] Detect responsibility per file (via function-name keyword matching / function classification):
  - input: `_input`, `on_key_pressed`, `handle_touch`, …
  - logic: `calculate_*`, `apply_*`, `check_*`, …
  - event: `emit_*`, `publish_*`, `broadcast_*`, …
  - ui: `update_ui`, `render_*`, `_process` that touches `Control` nodes, …
- [ ] ≥ 2 responsibilities coexist → WARN.
- [ ] ≥ 3 responsibilities coexist → FAIL.
- [ ] Directory-layering check: a flat `scripts/` with no subdirectories → WARN.

## Configurable thresholds

`config/linter_policy.yaml` (delivered in Phase 3):

```yaml
rule_c:
  max_file_lines_warn: 300
  max_file_lines_fail: 500
  responsibility_mixing_warn_count: 2
  responsibility_mixing_fail_count: 3
  enforce_layer_separation: true
  minimum_layers: 2
  layer_naming_whitelist:
    - domain
    - logic
    - core
    - application
    - presentation
    - integration
    - ui
    - hud
```

## Exemptions (allowlist)

1. Generated code (header marked `# AUTO-GENERATED, DO NOT EDIT`).
2. Test code (`test/` / `tests/` directories, up to 800 lines).
3. Serialization / schema definition files (dataclass collections, up to 500 lines).
4. Enum-table definitions (file contains only `enum` + `const` declarations).

## Engine/language adaptation notes

| Engine | Common God-Object anti-pattern | Recommended layering |
| --- | --- | --- |
| **Godot 4.x** | `GameManager.gd` autoload absorbing all logic | Autoload = pure event bus + pure Config accessor; domain uses plain classes |
| **Unity** | `GameController.cs MonoBehaviour` catch-all script | ECS split: Component = pure data, System = pure logic |
| **Unreal** | `APlayerController` inheritance tree carrying all logic | Split features via GameplayAbilitySystem / GameFeaturePlugin |

## Stub implementation

`scripts/linter/rule_c_file_scale_constraints.py` — Phase 2 stub (framework: line scanner + responsibility matcher); Phase 3 delivers the real detection.

## References

- v3 source: `AI_Game_Dev_OS_Architecture_v3.md §VI.C`.
- v3 §I.1 Executive Summary item ④ also restates the File-Scale constraint.
- Related: v3 §II.3 Logic-Visual Separation (higher-level principle).
