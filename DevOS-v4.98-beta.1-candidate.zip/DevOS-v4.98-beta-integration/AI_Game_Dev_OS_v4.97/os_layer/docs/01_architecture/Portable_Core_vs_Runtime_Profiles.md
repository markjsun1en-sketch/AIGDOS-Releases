# Portable Core vs Runtime Profiles

## Purpose
This document defines which parts of AI_Game_Dev_OS v4.89 belong to the universal baseline and which parts must vary by runtime / IDE environment.

## Portable Core
Portable Core contains the parts of the OS that should remain valid across runtime environments.

This includes:
- path and runtime portability
- root discovery
- no-demo initialization
- migration and validation baselines
- shared governance principles
- TAPD object semantics and verification requirements
- Git high-level merge discipline
- audit schema standards
- shared starter templates

## Runtime Profiles
Runtime Profiles define execution behavior that depends on tool / IDE / runtime capabilities.

This includes:
- rule loading mechanism or entry file
- context loading behavior
- worker / subagent / team launch model
- isolation unit
- writeback owner
- cleanup owner
- runtime event collection strategy
- recovery SOP

## Why the split exists
Different runtimes expose different execution primitives. Universalizing them into one generic “team mode” produces unstable process rules and incorrect assumptions.

## Design rule
When in doubt:
- if the rule is about truth, validation, migration, reconciliation, or baseline governance → Portable Core
- if the rule is about execution model, isolation, launch, cleanup, or tool-native coordination → Runtime Profile

## Anti-pattern to avoid
Do not encode a private tool behavior as if it were a universal OS rule.
