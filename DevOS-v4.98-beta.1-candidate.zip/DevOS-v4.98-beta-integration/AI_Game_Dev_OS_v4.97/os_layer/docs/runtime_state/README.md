# Runtime State Service — PKG-1 SEC-0

This package is the v4.94 canonical Runtime State source. It implements
`RSS-V494@1.0.0` for isolated synthetic qualification fixtures and a bounded,
non-qualifying development mode. Runtime State owns operational object
revisions, commands, idempotency receipts and service fencing. Qualification
also exercises checkpoints, projections and fixture backup metadata. Runtime
State does not own Human approval, Project Truth, Evidence verification, or
LTM lifecycle authority.

The State Service is the sole supported mutation boundary. Clients submit a
`state_command.schema.json` envelope and cannot supply a service instance or
epoch. The service validates the client envelope, injects an internal context,
then opens `BEGIN IMMEDIATE`. Raw SQLite handles and direct writes to legacy
JSON registries are not supported by this package.

Qualification remains separately authorized under
`B2-FIXTURE-LOCAL@1.0.3`, `SEC-0 contract_only`; development execution cannot
be used as qualification evidence. The project-local development entry
supports non-production task work only. It does not claim SEC-1, real-project
adoption, backup/recovery readiness or production support.

Qualification artifacts remain contained in a separately authorized
run-scoped temporary root. Development callers may explicitly select a local
project root; the service then owns only
`<project>/.ai_dev_os/development/runtime_state/`, may resume its development
database, and rejects qualification-only backup, recovery and fault controls.
The package never creates `.ai_dev_os/state`, never resolves `.dev_os_meta`,
and never performs network or provider activity.

## Current truth selection

`truth_resolver.resolve_current_truth()` is a read-only functional starting
point for Temporal Project Truth. Given candidate records, an exact scope and
an explicit effective time, it selects one effective Human-approved candidate
or returns an explicit ambiguity, integrity or scope-mismatch result. Proposed,
superseded, revoked, future and expired candidates cannot win, and timestamps
are never used to choose between two eligible candidates.

This function returns a diagnostic selection result only. It does not write
Runtime State, emit a `truth_resolution_receipt`, propagate invalidation,
establish Human approval or pass a Gate. Receipt generation and the dependency
invalidation engine remain later M5 slices.

`truth_invalidation.preview_truth_replacement_impact()` takes a successful
selection plus a caller-supplied binding set and identifies current project
bindings that still reference explicitly superseded Truth IDs. Mixed
current/superseded bindings require revalidation; already noncurrent bindings
and other projects do not. The preview reports its scanned set and makes no
claim that the caller supplied a complete registry. It does not mutate a
binding or emit an invalidation event.

Callers may pass that resolution and binding set to `get_resume_context()` or
`load_task_readset()`. The adapter reports `revalidation_required` only when an
affected binding names the exact task, is the task artifact itself, or exactly
matches one of the task's explicit input refs. The result is advisory and does
not change the task, its next action or any binding; broader feature/project
scope is not inferred into task impact. When bounded input content is requested,
an exact affected `artifact_id == input_ref` match is skipped before reading;
unrelated inputs still load and the task remains runnable.

The caller may explicitly map an excluded ref to a replacement ref. The
replacement loads only when one current same-project binding connects it to
the selected Truth and its declared SHA-256 matches the bytes actually read.
A missing, ambiguous or drifted replacement remains skipped; this does not
rewrite task inputs or persist a revalidation decision.

The accountable producer may explicitly persist a verified replacement when
the replacement is an exact revision-bound Git input. This performs one CAS
update of the task's input refs and stores a latest task-local rebind marker;
it does not change lifecycle state, resolve an unrelated blocker, mutate the
binding registry or emit a global invalidation receipt. Repeating the same
confirmed rebind is idempotent.

## Development task session

Agents and adapters can use the project-local task API without receiving a
database handle:

```python
from scripts.runtime_state.task_workflow import DevelopmentTaskSession

with DevelopmentTaskSession(
    package_root=package_root,
    project_root=game_project_root,
    project_id="my-game",
    actor_id="gameplay-agent",
) as tasks:
    task = tasks.create_task(title="Prototype movement", feature_id="movement")
    tasks.transition_task(task["object_id"], "READY")
```

Reopening the same project root with the same `project_id` resumes its task
queue. A different `project_id` is rejected rather than creating a second
logical project inside the same database.

The Codex adapter may leave future work in `CREATED` with `queue_task()`, then
execute the existing `prepare_task` and `start_task` resume actions explicitly
across sessions. Both action calls are idempotent once their target state is
reached. `begin_task()` remains the shortcut for work that should start
immediately; no separate scheduler or worker process is introduced.

The Codex adapter can select the task to resume from this queue. It
automatically selects only when exactly one unfinished task exists. Multiple
unfinished tasks require an explicit task ID, an empty queue is reported as
empty, and terminal tasks are not presented as successfully resumed. This is
development task recovery only; it is not a Git/worktree checkpoint,
qualification recovery, or release claim.

Development blockers reuse the existing Runtime State `issue` lifecycle. The
task adapter can create a linked blocker, place the task in `BLOCKED`, resolve
the issue through `RESOLVED`, and return the task to `IN_PROGRESS` after its
last active blocker is resolved. It cannot turn that local resolution into an
Evidence verification or close the issue.

The Codex adapter also exposes an on-demand, read-only Git work-context
inspection. It observes repository root, branch, HEAD and project-local short
status with optional Git locks disabled. Dirty, detached, unborn and non-Git
states are diagnostic results rather than Runtime State admission failures;
the inspection is not called automatically by task resumption.

Project-local development handoffs also reuse the existing Runtime State
object and lifecycle. A sender links the handoff to a task; the named recipient
can discover, accept and complete it across sessions. The handoff carries
coordination state only: it never rewrites the task owner/accountable producer
and does not verify or close the task.

If delegated work cannot proceed, the named recipient can reject a sent
handoff or return accepted/in-progress work with a reason. Both outcomes remove
the handoff from active assignment without claiming completion; no automatic
reassignment or task-state change occurs.

For a fresh session, `get_resume_context()` composes the current task selection,
active blockers, task-linked handoffs and optional Git observation into one
read-only result. It is computed on demand from current state and is not a new
checkpoint, projection file, Evidence record or admission gate.

The resume result also includes a local input inspection. Project-relative
inputs can report presence, and revision-bound Git inputs can report unchanged,
changed or missing against their named commit. External schemes remain opaque.
These are current observations only: no result marks a task stale, performs
invalidation, selects Project Truth, or blocks ordinary development.

An explicit impact preview can scan unfinished tasks and group those with
changed or missing inspectable inputs. Uninspectable references are counted but
do not imply impact. This read does not persist a projection or alter any task.

An active task may persist one latest development progress summary and next
step for a later session. Updating it replaces the prior note and leaves task
state and accountable producer unchanged; no parallel progress-history payload
is added.

An independent development reviewer can return a commit-bound
`CLAIMED_DONE` task to `IN_PROGRESS` with a concise FAIL reason. This is a
local rework route, not a blocker object or qualification verdict; the original
producer remains accountable and a corrected commit requires a fresh review.
The claim is reviewable only when all implementation references carry one Git
commit that exists locally and every named project-relative path is a blob in
that commit. Output-only, missing-path and mixed-commit work remains
`IN_PROGRESS`. This boundary does not require a clean worktree or full content
manifest. PASS and FAIL must match the commit recorded by that claim. If local
PASS is requested, the independent reviewer checks commit/blob availability
once more before storing it; a missing source can still receive FAIL and return
to ordinary rework. If PASS reaches `VERIFIED` but its close call is
interrupted, the same reviewer can resume the close step from the persisted
binding without repeating the Git check.

The review adapter can list current `CLAIMED_DONE` tasks that were produced by
another actor. This discovery read does not reserve, assign, prioritize or lock
work and does not create review evidence.

Development task, issue and handoff lists use `project_id` and `object_type`
filters before the service applies its 100-row bound. If a page is full, the
client continues from its last `object_id` until a shorter page is returned.
The bound therefore remains per request and does not impose a 100-object
project lifetime. These optional filters and cursor are development-only;
qualification `bounded_read` requests retain their prior shape.

Before an independent review accepts the claim, the accountable producer or
latest claimant may withdraw `CLAIMED_DONE` to `IN_PROGRESS` with a reason.
This ordinary development correction preserves work refs and history and does
not require Human disposition; verified, closed or qualifying work is outside
this route.

Obsolete unfinished tasks can use the existing `CANCELLED` terminal state with
an attributable reason. Their records and linked issues are retained, while
resume and impact scans ignore the cancelled task. Only the accountable
producer or latest claimant can cancel. Cancellation is refused if a linked
handoff is still open, preventing delegated work from becoming detached from
its source task.
