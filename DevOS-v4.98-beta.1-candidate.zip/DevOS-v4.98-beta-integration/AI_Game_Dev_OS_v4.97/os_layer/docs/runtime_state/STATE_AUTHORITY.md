# Runtime State Authority

Runtime State is authoritative only for operational coordination facts owned
by `RLC-V494@1.0.2`: object revisions, legal lifecycle transitions, operation
receipts, idempotency, service instance fencing, projections, and recovery
metadata.

The following are references, never Runtime-minted authority:

- Human approval and rejection receipts;
- selected Project Truth and truth invalidation resolutions;
- Evidence verification, quarantine, revocation, or lifecycle decisions;
- LTM admission, retention, tombstone, or deletion authority;
- cross-store coherent snapshot claims.

A guarded transition must carry the exact receipt identity, revision, content
hash, scope, and resolver verdict required by the packaged lifecycle contract.
Schema validity, timestamps, list order, confidence, retrieval rank, or a field
named `authority_owner_id` cannot substitute for a resolved current authority
receipt. Missing, conflicting, superseded, or invalidated bindings block without
state advance.

Runtime State may record a handling receipt and block dependent work after a
truth invalidation. It may not select replacement truth, rewrite source
receipts, change authority ownership, verify its own Evidence, or claim atomic
commit with external Truth/Evidence/LTM stores.
