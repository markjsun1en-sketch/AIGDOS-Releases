# Runtime State Operations and Recovery

Operations are idempotent commands applied by one fenced State Service writer.
The service holds a nonblocking lifetime lock, records a monotonic database
epoch, and injects its `service_instance_id` and `service_epoch` after client
validation and before `BEGIN IMMEDIATE`. A stale or inactive instance cannot
commit.

SQLite policy is fixed by `B2-FIXTURE-LOCAL@1.0.3`: application ID
`0x4149444F`, user version `10000`, 4096-byte pages, WAL, synchronous FULL,
foreign keys enabled, 5000 ms busy timeout, 1000-page autocheckpoint, and a
64 MiB journal-size target. A WAL at or above 256 MiB blocks new mutations
until an authorized checkpoint succeeds and is remeasured.

Every committed command creates an operation receipt containing before/after
revision and commit hashes plus the internally injected service identity.
Projection writes use a temporary sibling, byte hash, fsync, and atomic rename;
projections remain derived and stale projections are rejected.

Backup uses SQLite's backup API, records the exact included revision/commit,
hashes the backup bytes, and verifies a restored fixture before updating the
last-success receipt. Failed or partial backups never advance that receipt.
Restore is fixture-only, containment checked, and does not establish canonical
project rollback. Automated takeover is prohibited; fixture takeover simulation
is non-authoritative and limited to one exact run ID.
