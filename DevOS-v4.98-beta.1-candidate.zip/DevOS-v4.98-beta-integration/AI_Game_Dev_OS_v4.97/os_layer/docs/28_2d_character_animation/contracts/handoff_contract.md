# Handoff Contract

Every animation handoff must include:

## Required fields

```yaml
handoff_id:
character:
source_asset:
target_engine:
target_method:
animations:
required_layers:
known_risks:
human_gates:
acceptance_tests:
owner:
status:
```

## Status values

```text
draft
needs_asset_review
needs_pivot_review
ready_for_rigging
ready_for_engine_import
qa_failed
accepted_for_prototype
accepted_for_vs
accepted_for_production
```

## Risk tags

```text
missing_hidden_fill
pivot_uncertain
draw_order_risk
weapon_grip_risk
hair_noise_risk
cloth_overlap_risk
identity_drift_risk
loop_pop_risk
```
