# Definition of Done — 2D Character Animation

An animation is done only when it passes all applicable gates.

## Required gates

### Asset gate

- [ ] correct character identity
- [ ] no unwanted background pixels
- [ ] correct crop and scale
- [ ] required layers exist
- [ ] naming matches convention

### Rigging gate

- [ ] pivots documented
- [ ] parent hierarchy documented
- [ ] draw order documented
- [ ] hidden fills approved
- [ ] extreme test poses checked

### Animation gate

- [ ] duration matches spec
- [ ] event frames match gameplay
- [ ] hit frame readable
- [ ] no blocker clipping
- [ ] no identity/proportion drift
- [ ] loop or return-to-idle is clean

### Engine gate

- [ ] imports correctly
- [ ] plays from runtime command
- [ ] emits events/signals
- [ ] works in target battle scene
- [ ] readable with UI overlays

## Milestone acceptance

### Prototype

Minor visual defects allowed if gameplay events are correct.

### Vertical slice

No blockers or majors allowed in hero-facing actions.

### Production

No visible clipping, drift, or loop discontinuity at target scale.
