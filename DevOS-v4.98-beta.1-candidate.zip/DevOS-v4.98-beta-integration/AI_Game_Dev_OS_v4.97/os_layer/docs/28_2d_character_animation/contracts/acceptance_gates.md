# Acceptance Gates

## Gate A — Scope Gate

Reject if the output does not specify:

- target engine;
- animation method;
- target motion list;
- expected camera/game screen role.

## Gate B — Layer Gate

Reject if moving parts lack:

- layer name;
- parent;
- pivot;
- draw order;
- hidden fill note.

## Gate C — Rig Gate

Reject if:

- a weapon has no grip pivot;
- head has no neck pivot;
- arms have no shoulder/elbow/wrist logic;
- skirt/leg overlaps are ignored;
- cape/hair motion lacks attachment points.

## Gate D — Timing Gate

Reject if combat animations lack:

- duration;
- anticipation/active/recovery split;
- hit or event frame;
- return-to-idle.

## Gate E — Runtime Gate

Reject if the animation:

- cannot be played in engine;
- does not emit gameplay events;
- breaks at target scale;
- conflicts with battle UI readability.
