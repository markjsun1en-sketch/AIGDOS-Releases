# Skill Invocation Matrix

| User intent | Use skill |
|---|---|
| “What animations does this character need?” | `2d-character-motion-designer` |
| “Plan frames for idle/attack/hurt.” | `sprite-sheet-planner` |
| “How should I cut this character into parts?” | `character-layer-splitter` |
| “How do I prepare this for binding?” | `rigging-prep-handoff` |
| “Review this animation / it looks wrong.” | `animation-qa-auditor` |
| “Implement this in Godot.” | `godot-2d-animation-implementer` |
| “Make a combat animation timing spec.” | `combat-animation-spec` |
| “Write prompts for animation frames or cutout parts.” | `asset-prompt-animation-helper` |

## Multi-skill routes

### Full card-battle actor route

```text
character-layer-splitter
→ rigging-prep-handoff
→ combat-animation-spec
→ godot-2d-animation-implementer
→ animation-qa-auditor
```

### Sprite sheet route

```text
2d-character-motion-designer
→ sprite-sheet-planner
→ asset-prompt-animation-helper
→ animation-qa-auditor
```
