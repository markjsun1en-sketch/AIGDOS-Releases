# Animation QA Report

## 1. Asset Under Review

- Character:
- Animation:
- File / scene:
- Reviewer:
- Date:

## 2. Summary

- Status: Pass / Pass with notes / Rework / Reject
- Main risks:

## 3. Issue Table

| ID | Severity | Frame/Time | Issue | Likely Cause | Fix Recommendation | Owner |
|---|---|---|---|---|---|---|

## 4. Mandatory Checks

| Check | Pass? | Notes |
|---|---:|---|
| Root / foot stability | | |
| Pivot stability | | |
| Proportion consistency | | |
| Weapon attachment | | |
| Hair/cape/skirt continuity | | |
| Draw-order clipping | | |
| Loop continuity | | |
| Hit-frame clarity | | |
| Return-to-idle | | |
| Runtime scale readability | | |

## 5. Required Fixes Before Acceptance

## 6. Re-test Plan
