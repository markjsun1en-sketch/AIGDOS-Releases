# Combat Animation Spec

## 1. Global Assumptions

- Character:
- Game mode:
- Camera:
- Engine:
- Animation method:
- Runtime scale:

## 2. Animation Table

| Animation ID | Duration | Loop | Purpose | Next State |
|---|---:|---|---|---|

## 3. Detailed Timing

### animation_id

- Duration:
- Loop:
- Root motion policy:
- Phase breakdown:

| Phase | Time Range | Description |
|---|---:|---|
| anticipation | | |
| active / impact | | |
| recovery | | |
| return | | |

## 4. Event Frames

| Event | Time | Socket | Gameplay Meaning |
|---|---:|---|---|

## 5. VFX / SFX Hooks

## 6. Transition Rules

## 7. QA Checklist

- [ ] Hit frame readable
- [ ] Weapon remains attached
- [ ] Return to idle clean
- [ ] No major clipping
- [ ] Silhouette readable at target scale
- [ ] Event timing matches gameplay
