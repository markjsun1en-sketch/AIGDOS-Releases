# Godot 2D Animation Implementation Plan

## 1. Target

- Godot version:
- Character:
- Animation method:
- Scene path:

## 2. Scene Tree

```text
Actor2D (Node2D)
```

## 3. Asset Paths

```text
res://actors/<character>/textures/
res://actors/<character>/animations/
res://actors/<character>/scenes/
```

## 4. AnimationPlayer Tracks

| Animation | Node | Property | Keyframes | Notes |
|---|---|---|---|---|

## 5. AnimationTree / State Machine

| State | Animation | Transitions |
|---|---|---|

## 6. Signals / Events

| Event | Emitted By | Consumed By | Purpose |
|---|---|---|---|

## 7. Import Settings

## 8. Test Scene

## 9. Acceptance Checklist

- [ ] all textures load
- [ ] pivots correct
- [ ] animations play from code
- [ ] event frames fire
- [ ] no major clipping
- [ ] return-to-idle works
- [ ] scene can be instanced in battle screen
