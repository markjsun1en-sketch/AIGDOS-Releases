# Character Layer Split Plan

## 1. Input

- Character name:
- Source asset:
- Target engine:
- Target animation method:
- Camera / screen role:
- Required animations:

## 2. Split Depth

- Recommended depth: Minimal / Standard / Advanced
- Reason:

## 3. Layer List

| Layer Name | Purpose | Moves? | Parent | Draw Order | Pivot | Hidden Fill Needed? | Notes |
|---|---|---:|---|---:|---|---:|---|

## 4. Draw Order

Front to back or back to front:

```text

```

## 5. Pivot Notes

## 6. Overlap / Hidden Fill Notes

| Area | Problem | Required Fix | Owner |
|---|---|---|---|

## 7. Do Not Auto-Split

## 8. Export Checklist

- [ ] Transparent PNG or shared canvas confirmed
- [ ] Layer names match convention
- [ ] No chroma spill
- [ ] Pivots documented
- [ ] Hidden-fill areas marked
- [ ] Manual review completed

## 9. Next Handoff

Recommended next skill:
