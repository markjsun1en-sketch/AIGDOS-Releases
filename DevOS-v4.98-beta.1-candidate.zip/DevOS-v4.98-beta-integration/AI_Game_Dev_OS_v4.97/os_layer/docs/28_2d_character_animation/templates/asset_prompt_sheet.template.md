# Animation Asset Prompt Sheet

## 1. Asset Goal

## 2. Character Identity Lock

Include exact identity-preserving details:

- face:
- hair:
- outfit:
- weapon:
- silhouette:
- color accents:

## 3. Pose / Motion Prompt

## 4. Technical Constraints

- canvas:
- crop:
- background:
- transparency:
- anchor:
- scale consistency:

## 5. Negative Constraints

Do not:

- change identity;
- change costume design;
- crop weapon or hair;
- add UI/text/numbers;
- use fake transparency/checkerboard;
- change body proportions;
- change camera angle unless requested.

## 6. Output Prompt

```text

```

## 7. QA Checklist

- [ ] identity preserved
- [ ] pose readable
- [ ] full asset visible
- [ ] background correct
- [ ] no UI/text
- [ ] downstream cutout possible
