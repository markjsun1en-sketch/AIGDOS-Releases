# Sprite Sheet Plan

## 1. Global Settings

- Character:
- Engine:
- FPS:
- Frame size:
- Padding:
- Background:
- Pivot:

## 2. Animation Sheet Table

| Animation | Frames | FPS | Duration | Loop | Row/Column Layout | Events |
|---|---:|---:|---:|---|---|---|

## 3. Per-Frame Notes

| Animation | Frame | Pose / Function | Notes |
|---|---:|---|---|

## 4. Export Naming

```text
character_animation_f000.png
character_animation_f001.png
```

or

```text
character_sheet.png
character_sheet.json
```

## 5. QA Checklist

- [ ] consistent scale
- [ ] consistent foot anchor
- [ ] no identity drift
- [ ] no loop pop
- [ ] hit frame clear
- [ ] no background pixels
