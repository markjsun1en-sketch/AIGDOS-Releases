# Rigging Prep Handoff

## 1. Rig Target

- Character:
- Engine / tool:
- Rig type:
- Animation scope:

## 2. Hierarchy

```text
root
```

## 3. Pivot Table

| Layer | Semantic Pivot | Normalized Pivot | Parent | Notes |
|---|---|---|---|---|

## 4. Draw Order Table

| Order | Layer | Notes |
|---:|---|---|

## 5. Deformation Policy

| Layer | Policy | Notes |
|---|---|---|

Policies:

- rotate_only
- translate_rotate
- mesh_deform
- squash_stretch
- static

## 6. Sockets

| Socket | Parent | Purpose |
|---|---|---|

## 7. Test Poses

| Test Pose | Purpose | Expected Result | Failure Signs |
|---|---|---|---|

## 8. Manual Gates

- [ ] Pivot gate
- [ ] Overlap gate
- [ ] Draw-order gate
- [ ] Extreme-pose gate
- [ ] Engine import gate

## 9. Next Handoff
