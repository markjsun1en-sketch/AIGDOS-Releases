# Agent Pack Overview — Creative Cluster (2D Character Animation)

> **v4.91 Milestone G** — first creative_cluster pack adoption guide.
> **Pack ledger**: `agent_packs/ap_2026_006_creative_cluster.md`

## What this pack is

A coordinated set of 8 skills + 8 references + 7 templates + 2 examples
+ 4 runtime contracts + 3 schemas + 2 scripts that together turn a
fragile one-shot AI task ("here's a full-body image, make it
animated") into a gated production pipeline with explicit human
gates, evidence-driven acceptance, and engine-specific implementation
plans.

## What this pack is NOT

- **NOT an auto-rigger.** No skill in the pack promises to take a
  single rendered image and emit a finished bone rig. The
  `character-layer-splitter` produces a *plan*; humans (or
  downstream tools the project chooses) execute the plan.
- **NOT a closure-gate replacement.** `animation-qa-auditor` produces
  an advisory report. Final gameplay sign-off is a separate human
  decision per Charter anti-pattern #11.
- **NOT a code generator.** `godot-2d-animation-implementer` produces
  scene-tree plans, AnimationPlayer track lists, and import
  checklists — not Godot scripts. The implementation step itself
  remains the project's authority.

## Pack composition

| Skill | Role primitive | Location |
|---|---|---|
| 2d-character-motion-designer | design | `skills/_generic_core/animation/` |
| sprite-sheet-planner | design | `skills/_generic_core/animation/` |
| character-layer-splitter | design | `skills/_generic_core/animation/` |
| rigging-prep-handoff | design | `skills/_generic_core/animation/` |
| combat-animation-spec | design | `skills/_generic_core/animation/` |
| asset-prompt-animation-helper | implementation | `skills/_generic_core/animation/` |
| godot-2d-animation-implementer | implementation | `skills/_engine_specific/godot/` |
| animation-qa-auditor | validation | `skills/_generic_core/qa/` |

Five `design` skills + two `implementation` skills + one
`validation` skill. The cross-cluster role aliasing is authorised by
`proposals/evo_2026_002_creative_cluster_role_aliasing.md`.

## Adoption recipe

### 1. Confirm scope

Ask the producer / EP:

- Which character genres? (card-battle / action / RPG / VN-battle)
- Which engine? (Godot is fully supported; others get planning-only)
- Which animations are MVP? (recommend `battle_idle` + `hurt_light`
  + `attack_light` + `skill_cast` for card-battle MVPs)
- Do you need walk / run / jump / turn? If yes, escalate — this
  pack does not cover full locomotion from a single illustration.

### 2. Read the limits

Read `AI_LIMITATIONS_AND_HUMAN_GATE.md` end-to-end. Every gate listed
there is a real production failure mode if skipped.

### 3. Pick a workflow

See README.md "Workflow map". For card-battle MVPs, start with the
minimal workflow.

### 4. Run the skills sequentially

Do NOT pipe all 8 skills in a single AI request. Each skill produces
a plan that needs human review before the next runs. The pack is
explicitly gated.

### 5. Use the templates

Every skill emits to one of the templates under `templates/`. Diff
the AI output against the template structure to confirm completeness
before proceeding to the next gate.

### 6. Audit before integration

Run `animation-qa-auditor` against the in-engine output (a Godot
preview, sprite-sheet GIF, or animation video). Resolve all
*Blocker* and *Major* issues before merging into the project's
canonical actor scenes.

## Schema-backed surfaces (3)

| Schema | Consumer skill | Purpose |
|---|---|---|
| `schemas/animation/layer_split.schema.json` | character-layer-splitter | Validate layer plan shape |
| `schemas/animation/combat_animation_spec.schema.json` | combat-animation-spec | Validate timing spec shape |
| `schemas/animation/qa_report.schema.json` | animation-qa-auditor | Validate QA report shape |

All schemas are `additionalProperties: false` + `schema_version`
const "1.0.0" + draft-07. Project-side fixtures MUST use opaque
`<character_id>` tokens (Charter #2).

## Cross-references

- `agent_packs/ap_2026_006_creative_cluster.md` — pack ledger entry
- `proposals/evo_2026_002_creative_cluster_role_aliasing.md` — capability promotion
- `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` § 6 — cluster taxonomy
- `docs/16_agent_library/AGENT_ROLE_CATALOG.md` — 8 role primitives
- `docs/28_2d_character_animation/CROSS_PROJECT_PROMOTION_LESSONS.md` — provenance methodology
- `skills/README.md` § 1 — skills tree structure (animation category added v4.91 M-G)
