# AI Limitations and Human Gates

> **v4.91 Milestone G** — Charter alignment record for the creative_cluster pack.
> Mirrors the source pack's `references/ai_limitations_and_human_gate.md` but elevated to the pack's policy surface. inv_013 (M-G c4) requires this file to exist.

## Charter alignment summary

| Anti-pattern | M-G enforcement |
|---|---|
| #6 no auto-promote | No skill in this pack mutates user inputs without explicit human gate. `animation-qa-auditor` issues advisory verdicts only. |
| #7 no escape hatches | Skills do NOT define `--apply` / `--auto-rig` / `--bypass-review` flags. The `validate_skill_pack.py` script under `scripts/animation/` is read-only. |
| #11 not closure-gate | `animation-qa-auditor.status='pass'` does NOT close a sprint. Gameplay sign-off is a separate human decision (the EP / producer). |
| #13 forbidden_actor | Pack body does not declare runtime actors. Adopting projects MUST NOT route this pack into `auto` / `system` / `ci` automation. |

## What AI can help with

- Motion inventory (which animations does the character need).
- Layer split planning (how to decompose the image).
- Prompt creation for image / video generation tools.
- Identifying likely hidden-fill areas the human must paint.
- Drafting rigging handoffs (pivots, hierarchy, draw order).
- Generating rough pose references.
- Writing Godot implementation plans (scene tree, AnimationPlayer
  tracks, signals).
- QA checklists and issue triage with severity classification.

## What AI cannot reliably do alone

- Production-grade full humanoid binding from one image.
- Accurate hidden anatomy reconstruction without review.
- Complex mesh weights.
- Consistent multi-frame character identity across large motion.
- High-quality hair / skirt / cloth deformation.
- Professional cleanup of all joints.

## Required human gates (7)

Adopting projects MUST NOT skip these gates:

1. **Approve layer split depth** — minimal / standard / advanced.
   Over-splitting wastes effort; under-splitting blocks animation.
2. **Approve hidden-fill plan** — every layer flagged
   `hidden_fill_needed: true` requires manual paint-over before rig.
3. **Approve pivots before rigging** — rotate-test every joint at
   ±20° before binding.
4. **Test three extreme poses** — neutral idle / max attack /
   max hurt-back-lean. If any pose breaks the silhouette, return to
   the splitter with documented constraints.
5. **Approve first in-engine loop** — before sprinting to production
   set, gameplay-test the loop in the actual battle scene.
6. **Approve combat hit frame timing** — the gameplay event MUST
   land on a frame that reads at the target screen scale.
7. **Approve final runtime readability** — silhouette + UI overlap
   check at 1x and at the target downscale (e.g. mobile portrait).

## Good fallback

If full rigging fails, downgrade to:

- Static actor + breathing motion only.
- VFX-led attack (the actor barely moves; VFX carries the impact).
- Small recoil hurt animation (4-6 frames).
- Sprite-sheet key poses (no in-between frames).
- Card-portrait animation instead of full-body rig.

## Skill-specific limitation notes

- `character-layer-splitter`: NEVER assumes hidden body parts exist.
  Always marks them as manual paint.
- `rigging-prep-handoff`: produces a *spec*, not a rig.
- `combat-animation-spec`: timings are *advisory templates*; final
  tuning is gameplay's authority.
- `godot-2d-animation-implementer`: produces a scene-tree *plan*,
  not Godot scripts.
- `animation-qa-auditor`: issues are *advisory*; severity tags
  recommend, do not enforce.

## See also

- `references/ai_limitations_and_human_gate.md` — original reference
  doc carried into the pack from the source draft (kept for skill
  consumption).
- `agent_packs/ap_2026_006_creative_cluster.md` § Hard boundary
- `policies/charter_anti_patterns.md` — full Charter list
