# docs/28_2d_character_animation/

> **v4.91 Milestone G — Creative Cluster Pack Documentation**
> **Authority**: pack ledger `agent_packs/ap_2026_006_creative_cluster.md`
> **Activation**: capability_promotion `proposals/evo_2026_002_creative_cluster_role_aliasing.md`
> **Layer 1 (OS Spec)** — content here is generic across projects; specific adopting-project names stay in workspace `MEMORY.md`.

## Role

Provides the documentation surface for the v4.91 first creative_cluster
pack — 8 skills covering 2D character animation production. The pack
ledger (`agent_packs/ap_2026_006_creative_cluster.md`) carries gate
authority; the skills (`skills/_generic_core/animation/` × 6 +
`skills/_generic_core/qa/animation-qa-auditor` +
`skills/_engine_specific/godot/godot-2d-animation-implementer`) carry
actionable content; this directory carries shared references,
templates, examples, contracts, and the cross-project provenance
record.

## Layout

```
docs/28_2d_character_animation/
├── README.md                              # this file
├── AGENT_PACK_OVERVIEW.md                 # pack adoption guide for projects
├── AI_LIMITATIONS_AND_HUMAN_GATE.md       # what AI can / cannot do; mandatory human gates
├── CROSS_PROJECT_PROMOTION_LESSONS.md     # methodology of L2 → L1 abstraction
├── provenance.yaml                        # provenance metadata (Layer 1 generic)
├── references/                            # 8 reference docs (rules + checklists)
│   ├── ai_limitations_and_human_gate.md
│   ├── combat_animation_timing_rules.md
│   ├── godot_import_checklist.md
│   ├── layer_split_rules.md
│   ├── naming_conventions.md
│   ├── pivot_anchor_rules.md
│   ├── qa_failure_patterns.md
│   └── spine_godot_rigging_notes.md
├── templates/                             # 7 output templates
│   ├── animation_qa_report.template.md
│   ├── asset_prompt_sheet.template.md
│   ├── character_layer_split_plan.template.md
│   ├── combat_animation_spec.template.md
│   ├── godot_implementation_plan.template.md
│   ├── rigging_handoff.template.md
│   └── sprite_sheet_plan.template.md
├── examples/                              # 2 worked examples
│   ├── card_battle_idle_attack_example.md
│   └── character_alpha_battle_actor_example.md
└── contracts/                             # 4 runtime governance docs
    ├── acceptance_gates.md
    ├── animation_dod.md
    ├── handoff_contract.md
    └── skill_invocation_matrix.md
```

## Workflow map

### Minimal card-battle workflow (recommended starting point)

```
Input: full-body actor image
  ↓ character-layer-splitter
  ↓ rigging-prep-handoff
  ↓ combat-animation-spec
  ↓ godot-2d-animation-implementer
  ↓ animation-qa-auditor
  ↓ Fix handoff (back to character-layer-splitter or combat-animation-spec)
```

### Sprite-sheet workflow

```
Input: character style + action list
  ↓ 2d-character-motion-designer
  ↓ sprite-sheet-planner
  ↓ asset-prompt-animation-helper
  ↓ animation-qa-auditor
```

### Rigged cutout workflow

```
Input: layered character art or green-screen source
  ↓ character-layer-splitter
  ↓ rigging-prep-handoff
  ↓ combat-animation-spec
  ↓ godot-2d-animation-implementer
  ↓ animation-qa-auditor
```

## When to use this pack

- The user / task asks for 2D character actions, sprite sheets, cutout
  parts, rigging preparation, Spine/Godot skeleton preparation, combat
  animation timing, Godot AnimationPlayer/AnimationTree implementation,
  or animation QA.
- The character art is a full-body illustration, layered art, or
  green-screen actor.
- The target is card-battle, RPG, roguelike, VN/RPG hybrid, or other
  2D combat use case.

## When NOT to use this pack

- The task requires large pose changes (locomotion, turnaround) from
  a single front-facing illustration — escalate to professional
  animator / Spine / Live2D workflow.
- The character is 3D or skeletal-mesh — out of scope.
- The asset needs photoreal cloth / hair physics — out of scope at
  v0; future Live2D-style sub-pack may handle it.

## Hard boundary (Charter alignment)

Do NOT promise fully automatic production-quality character binding
from a single image. Always identify:

- animation scope;
- required layers;
- pivots;
- overlap / hidden-area compensation;
- manual correction gates;
- engine import constraints;
- QA acceptance criteria.

For card-battle characters, prefer a cutout actor with limited
high-readability motion over a full walk/run humanoid rig. See
`AI_LIMITATIONS_AND_HUMAN_GATE.md` for the full list of human gates.

## References

- Pack ledger: `agent_packs/ap_2026_006_creative_cluster.md`
- Capability promotion: `proposals/evo_2026_002_creative_cluster_role_aliasing.md`
- Skill content: `skills/_generic_core/animation/` (6) + `skills/_generic_core/qa/animation-qa-auditor/` + `skills/_engine_specific/godot/godot-2d-animation-implementer/`
- Schemas: `schemas/animation/` — layer_split, combat_animation_spec, qa_report (all 1.0.0)
- Validator scripts: `scripts/animation/`
- Skills tree convention: `skills/README.md` §1
- Cluster taxonomy: `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` § 6 creative_cluster
