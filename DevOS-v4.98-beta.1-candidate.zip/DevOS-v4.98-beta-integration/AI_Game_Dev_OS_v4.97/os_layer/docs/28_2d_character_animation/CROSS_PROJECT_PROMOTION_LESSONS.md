# Cross-Project Promotion Lessons

> **v4.91 Milestone G c3** — methodology record.
> First documented L2 → L1 abstraction in the v4.91 OS Core.
> Layer 1 (OS Spec). No project literals. The specific adopting-project name lives in workspace `MEMORY.md`.

## Why this document exists

The v4.91 creative_cluster pack (`agent_packs/ap_2026_006`) is the
first agent pack in the OS Core that was **distilled from a real
adopting project's pipeline rather than designed top-down**. The
extraction process surfaced several reusable methodology decisions
that future similar promotions will benefit from. This document
records those decisions so the second / third / Nth such promotion
can move faster.

## Triggering signal

The pattern was deemed promotion-ready when ALL of the following
held true:

1. The adopting project's pipeline had survived **two completed
   character-rollouts** end-to-end.
2. The pipeline was **decomposable into ≥6 generic functional
   skills** without any one of them being uniquely tied to the
   project's content domain.
3. The project's executive (EP) signalled "this should be reusable
   beyond our project".
4. **No matching coverage existed in the OS Core's existing 5 seed
   packs** (executive / research_design / implementation /
   validation / support).

If only 2 of these 4 held, the work was kept in the project's
`<project>/.ai_dev_os/skills/` (Layer 2) and not promoted.

## Extraction method (5 stages)

### Stage 1 — Surface inventory

List every skill file, reference document, template, example,
schema, and script the adopting project had assembled. Tag each
with one of:

- **G (generic)** — could apply to any project doing similar work.
- **L (literal)** — contains project-specific names / IDs / asset
  paths that cannot survive Layer 1 lint.
- **C (conditional)** — generic in shape but contains literal
  examples; sanitise then reclassify as G.

### Stage 2 — Functional decomposition

For each candidate skill, ask:

> Which OS Core role primitive (from `AGENT_ROLE_CATALOG.md`'s 8-row
> enum) is this skill enacting?

If the answer is "a new primitive we don't have yet", check whether
the proposed primitive is truly a distinct *function* (not a *job
title*). For the creative_cluster pack, all 8 skills mapped onto
existing `design` / `implementation` / `validation` primitives —
**no new primitive was needed** despite the new cluster.

### Stage 3 — Cluster placement

Use `PACK_CLUSTER_TAXONOMY.md` to find the right cluster. If the
needed cluster is **DEFERRED** (creative_cluster, tools_cluster in
v4.90), the activation pattern depends on whether new role
primitives are introduced:

- **No new primitives needed** → write a `capability_promotion`
  proposal that authorises cross-cluster role aliasing for the
  deferred cluster. The proposal is the activation evidence.
- **New primitives needed** → write a `capability_promotion`
  proposal that bumps the role catalog enum AND
  `agent_role.schema.json` AND `AGENT_ROLE_CATALOG.md` AND the
  cluster taxonomy in lockstep. (No precedent yet in v4.91.)

### Stage 4 — Sanitisation pass

Grep the candidate files for project-specific tokens. Common
sources:

- Character / hero / actor names.
- Project name itself (in module paths, asset roots, scene names).
- Sprint IDs, ticket IDs, in-house terminology.
- Engine asset paths bound to a specific repo (e.g.
  `res://actors/<projectname>/...`).

Replace with opaque tokens consistent across the pack:

- Character names → `<character_id>` / `character_alpha` / `character_beta`.
- Actor IDs → `actor_alpha` / `actor_beta`.
- Project name → never mentioned; stays in workspace `MEMORY.md`.
- Asset paths → `res://actors/<character_id>/...`.

Re-run grep until 0 hits. Re-run `lint_layer_separation.py` to
confirm the new Layer 1 surface is clean.

### Stage 5 — Validator + invariant alignment

Update the OS-side validator (e.g. `validate_agent_pack.py`) to
honour the new pack:

- For the activation case: implement the
  `_CLUSTER_ALIASING_EXEMPTIONS` registry (closed-form whitelist
  pattern shown in v4.91 M-G c1).
- For new schemas: add schema_version const + additionalProperties
  false + draft-07 alignment.
- For new behavior contracts: add an invariant entry to
  `runtime/protected_contracts/protected_regression_matrix.yaml`
  with `must_preserve` clauses that capture the pack's hard rules.

## Pitfalls observed

### Pitfall 1: "L2 only" misclassification

Initial reading classified the source skill pack as L2-only because
of project-specific wording in two reference files. Correct reading
recognised:

- Project literals were **localized** (2 files / 5 occurrences).
- Skill bodies themselves were **0 literals** (verified by grep
  before migration).
- Pattern shape was **clearly cross-project** (any card-battle 2D
  game could use it).

**Lesson**: classify at the *file* level after sanitisation, not at
the *pack* level on first read.

### Pitfall 2: New role primitive temptation

The first instinct was to add a `creative` role primitive to the
8-role catalog. This would have inflated the catalog without
adding a distinct function — the "creative" label describes a
*who* (specialist), not a *what function*.

**Lesson**: when a new cluster's skills decompose into existing role
primitives, prefer cross-cluster aliasing via capability_promotion
over inventing a new primitive.

### Pitfall 3: Treating pack adoption as closure

Initial impulse was to treat the pack landing as a milestone-close
event in itself. Charter anti-pattern #11 caught this: the pack's
own `animation-qa-auditor` is advisory; the pack landing is OS-side
infrastructure, gameplay sign-off remains separate.

**Lesson**: agent pack adoption ≠ closure of any specific project
work that the pack supports. Both are gates, both are independent.

### Pitfall 4: Sanitising too eagerly

Replacing every instance of `chiren` with the same opaque token in
all surfaces would have lost the test-fixture pattern variety.
Different occurrences need different replacements:

- Filenames: `chiren_battle_actor_example.md` → `character_alpha_battle_actor_example.md`
  (one specific fixture).
- Layer name prefixes: `chiren_torso` / `chiren_head` →
  `<character_id>_torso` / `<character_id>_head` (template form).
- Asset paths: `res://actors/chiren/...` → `res://actors/<character_id>/...`
  (template form).
- Scene tree class: `ChirenActor2D` → `CharacterAlpha2D` (one
  specific example).

**Lesson**: choose between angle-bracketed templates (`<character_id>`)
and concrete opaque names (`character_alpha`) based on whether the
context is a template or a worked example.

## Closed-form exemption pattern (reusable template)

The validator-side capability_promotion exemption was implemented as
a single-purpose registry:

```python
_CLUSTER_ALIASING_EXEMPTIONS: dict[str, tuple[str, set[str]]] = {
    "creative_cluster": (
        "proposals/evo_2026_002_creative_cluster_role_aliasing.md",
        {"design", "implementation", "validation"},
    ),
}
```

Two-element gate: `cluster == <key>` AND `<proposal_path> in references[]`.
No `--allow-deferred` / `--skip-exemption` flag. Future cluster
activations follow the same template:

```python
_CLUSTER_ALIASING_EXEMPTIONS["tools_cluster"] = (
    "proposals/evo_2026_NNN_tools_cluster_role_aliasing.md",
    {"support", ...},
)
```

Each entry MUST cite a distinct proposal id; no transitive
inheritance.

## When NOT to follow this method

- The candidate pack contains content that **would inflate the OS
  Core mass without serving a second project**. Pure project
  bookkeeping (sprint logs, retro notes, internal task IDs) is L2
  only and stays L2.
- The candidate is a **runtime configuration artefact** (e.g.
  `policies/<project>/scoring.yaml`). These belong in the project's
  `.ai_dev_os/policies/` and stay project-side; the OS contract for
  policy assembly is enough.
- The pattern has only run **once** — promote after a second
  successful application, not the first.

## Charter alignment

- Charter #2: this document avoids any project name; the source
  project name lives only in workspace `MEMORY.md`.
- Charter #6: no automatic decision is mandated — every promotion
  decision still requires EP sign-off via the proposal lifecycle.
- Charter #7: the validator exemption gate has no escape flag.
- Charter #11: pack adoption is OS-side; project closure is
  separate.

## See also

- `proposals/evo_2026_002_creative_cluster_role_aliasing.md` —
  worked example of this method.
- `proposals/evo_2026_001_layer_separation_principle.md` — Layer 1
  / Layer 2 separation (foundational).
- `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` § 6 — cluster
  activation note.
- `docs/28_2d_character_animation/provenance.yaml` — provenance
  metadata for this pack.
- `scripts/agent_library/validate_agent_pack.py` —
  `_CLUSTER_ALIASING_EXEMPTIONS` registry.

## Future work

- **v4.92 candidate**: formalise this method into `docs/17_self_evolution/CROSS_PROJECT_PROMOTION_PROCESS.md`
  if a second L2 → L1 promotion case lands.
- **v4.92 candidate**: tools_cluster activation following the same
  pattern (when a concrete first pack exists).
- **v4.92 candidate**: extend `validate_agent_pack.py` to support
  inheritance — a second creative_cluster pack (narrative, audio)
  inheriting evo_2026_002 by reference rather than needing its own
  proposal.
