# Example — Card-Battle Heroine Cutout Plan

This example is intentionally conservative. It assumes a full-body anime heroine for a 16:9 card battle screen.

## Target

- Engine: Godot
- Method: Sprite2D layers + AnimationPlayer
- Motions: battle_idle, hurt_light, attack_light, skill_cast
- Not required: walk/run/jump/full-body turn

## Recommended split

| Layer | Purpose | Pivot |
|---|---|---|
| root | placement | bottom-center foot anchor |
| pelvis | body root | hip center |
| torso | breathing / attack lean | lower spine |
| head | subtle head motion | neck base |
| front_hair | face silhouette | scalp/hairline |
| back_hair_main | secondary motion | back scalp |
| scarf_l | cloth motion | neck attachment |
| scarf_r | cloth motion | neck attachment |
| front_upper_arm | attack setup | shoulder |
| front_forearm | weapon motion | elbow |
| front_hand | grip | wrist |
| weapon_main | attack silhouette | grip point |
| back_arm | depth motion | shoulder |
| skirt_front | body overlap | waist |
| front_leg | stability | hip |
| back_leg | stability | hip |
| cape_l/r | secondary motion | shoulder/back attachment |

## First three test animations

### battle_idle

- 1.6s loop
- torso y: -2px to +2px
- head slight counter motion
- scarf/cape/hair delayed by 2–4 frames

### hurt_light

- 0.35s
- torso rotates back 4–7 degrees
- head follows with 2-frame delay
- scarf/hair overshoot then settle

### attack_light

- 0.6s
- anticipation 0.16s
- hit event at 0.28s
- recovery 0.32s
- weapon_tip socket spawns slash VFX

## Human gates

- Check shoulder overlap before attack.
- Check weapon grip during full swing.
- Check skirt/leg hidden fill during body lean.
- Check loop first/last frame.
