# Example — Card Battle Idle + Attack Spec

## battle_idle

- Duration: 1.5s
- Loop: true
- Method: cutout transform animation
- Motion:
  - pelvis stable;
  - torso breathing ±2px;
  - head slight inverse motion;
  - scarf and hair delayed by 0.08–0.12s;
  - weapon remains stable, slight glow only.

Events: none.

QA:

- first/last frame identical or smoothly tangent;
- face remains readable;
- silhouette does not jitter.

## attack_light

- Duration: 0.62s
- Loop: false
- Method: torso lean + front arm + weapon swing + VFX

| Phase | Time | Notes |
|---|---:|---|
| anticipation | 0.00–0.16 | body pulls back, weapon prepares |
| active | 0.16–0.30 | weapon arcs forward |
| impact | 0.28 | `evt_hit_apply`, `weapon_tip` VFX |
| recovery | 0.30–0.62 | return to idle pose |

Events:

| Event | Time | Socket |
|---|---:|---|
| evt_attack_start | 0.00 | actor_root |
| evt_vfx_spawn | 0.24 | weapon_tip |
| evt_hit_apply | 0.28 | weapon_tip |
| evt_return_idle | 0.62 | actor_root |

QA:

- weapon stays attached to hand;
- hit frame is clear;
- no shoulder tearing;
- return to idle is smooth.
