# Layer Split Rules

## Do not split everything

Over-splitting causes more failure than under-splitting. Split only parts that need to move independently.

## Card-battle standard split

Recommended for a full-body character on a 16:9 card-battle screen:

```text
root
pelvis
torso
head
front_hair
back_hair_main
scarf_l
scarf_r
cape_l
cape_r
front_upper_arm
front_forearm
front_hand
back_upper_arm
back_forearm
back_hand
weapon_main
skirt_front
skirt_back
front_leg
back_leg
```

## Hidden fill requirements

Mark these areas before rigging:

- shoulders hidden by hair/cape;
- elbows hidden by sleeves;
- wrist hidden by gloves/weapon;
- hip hidden by skirt;
- thighs hidden by skirt panels;
- neck hidden by hair/scarf;
- back hair hidden by body;
- weapon grip hidden by hand.

## Merge when safe

Keep merged if the part does not need independent motion:

- tiny ornaments;
- micro hair strands;
- small belt trim;
- small gold/silver linework;
- non-gameplay decorative fragments.

## Separate when necessary

Separate if the part affects readability:

- weapon;
- face/head;
- front hair covering face;
- scarf or cape silhouette;
- front hand holding weapon;
- skirt panels that overlap legs;
- VFX sockets.

## Export requirements

Each layer should have:

- transparent PNG;
- no chroma pixels left at edge;
- stable canvas size if using Godot Sprite2D layered assembly;
- or trimmed PNG plus explicit pivot if using Spine-like workflow;
- naming that matches the rigging handoff.
