# AI Limitations and Human Gate

## What AI can help with

- motion inventory;
- layer split planning;
- prompt creation;
- identifying likely hidden-fill areas;
- drafting rigging handoffs;
- generating rough pose references;
- writing Godot implementation plans;
- QA checklists and issue triage.

## What AI cannot reliably do alone

- production-grade full humanoid binding from one image;
- accurate hidden anatomy reconstruction without review;
- complex mesh weights;
- consistent multi-frame character identity across large motion;
- high-quality hair/skirt/cloth deformation;
- professional cleanup of all joints.

## Required human gates

1. Approve layer split depth.
2. Approve hidden-fill plan.
3. Approve pivots before rigging.
4. Test three extreme poses.
5. Approve first in-engine loop.
6. Approve combat hit frame timing.
7. Approve final runtime readability.

## Good fallback

If full rigging fails, downgrade to:

- static actor + breathing motion;
- VFX-led attack;
- small recoil hurt animation;
- sprite-sheet key poses;
- card portrait animation instead of full-body rig.
