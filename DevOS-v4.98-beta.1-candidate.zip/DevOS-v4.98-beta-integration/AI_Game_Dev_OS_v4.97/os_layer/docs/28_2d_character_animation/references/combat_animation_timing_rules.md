# Combat Animation Timing Rules

## Card-battle combat

Card-battle animation should be readable but not slow. Prioritize rhythm over complex physical realism.

| Animation | Duration | Notes |
|---|---:|---|
| battle_idle | 1.2–2.0s loop | breathing, hair/scarf/cape motion |
| hurt_light | 0.25–0.45s | sharp recoil, return quickly |
| attack_light | 0.45–0.75s | clear anticipation and hit frame |
| skill_cast | 0.8–1.6s | can use VFX to carry impact |
| break_down | 0.6–1.2s | readable posture change |
| victory | 1.0–2.0s | optional for MVP |

## Attack phase ratio

```text
anticipation: 20%–30%
active / impact: 10%–20%
recovery: 40%–60%
```

## Hit-stop

Use hit-stop sparingly:

```text
light hit: 0.03–0.06s
heavy hit: 0.06–0.12s
boss / skill hit: 0.10–0.18s
```

## Readability rules

- The hit frame should be visible even at small scale.
- Anticipation should not be mistaken for idle.
- Recovery should return cleanly to idle.
- VFX should not hide the actor's silhouette unless intentionally used for a skill.
- Status and enemy intent UI must remain readable above actors.
