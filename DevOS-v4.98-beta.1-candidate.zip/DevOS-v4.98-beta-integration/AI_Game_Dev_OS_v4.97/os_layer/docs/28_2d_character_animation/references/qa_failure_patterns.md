# QA Failure Patterns

## Common blockers

| Failure | Cause | Fix |
|---|---|---|
| Arm detaches at shoulder | pivot wrong or missing overlap | repaint shoulder overlap, move pivot |
| Weapon floats | weapon pivot not at grip | align grip pivot and hand socket |
| Hair pops during loop | first/last frame mismatch | adjust loop endpoints, add easing |
| Character changes proportions | generated frames inconsistent | lock scale, use rig/cutout, reduce frame regeneration |
| Foot slides | root/pelvis movement not matched to foot anchor | lock foot or add intentional step |
| Skirt reveals missing legs | hidden fill missing | paint hidden thigh/hip zones |
| Head looks detached | neck overlap missing | extend neck/head overlap region |
| Too noisy at runtime scale | too many micro-parts or texture flicker | merge small parts, smooth texture |

## Acceptance rule

If the defect is visible at actual game camera scale, it must be fixed or documented as a milestone tradeoff.
