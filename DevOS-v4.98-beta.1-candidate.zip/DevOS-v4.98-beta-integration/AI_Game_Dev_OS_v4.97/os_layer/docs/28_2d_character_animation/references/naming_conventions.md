# Naming Conventions

## General rule

Use stable, engine-safe, lowercase snake_case names.

Avoid:

- spaces;
- Chinese characters in runtime filenames;
- mixed capitalization;
- ambiguous names like `part1`, `hair2`, `new_layer_copy`.

## Character prefix

Use a character prefix for all actor layers:

```text
<character_id>_torso
<character_id>_head
<character_id>_weapon_main
```

If the project uses unique actor folders, the prefix may be omitted inside the folder.

## Side naming

Use camera-relative naming when the character always faces one direction:

```text
front_arm
back_arm
front_leg
back_leg
```

Use anatomical naming when the character can flip or turn:

```text
left_arm
right_arm
left_leg
right_leg
```

Do not mix both in one rig unless the reason is documented.

## Recommended layer names

```text
root
pelvis
torso
chest
neck
head
face_plate
front_hair
side_hair_l
side_hair_r
back_hair_main
hair_strand_01
hair_strand_02
scarf_l
scarf_r
cape_l
cape_r
upper_arm_front
forearm_front
hand_front
upper_arm_back
forearm_back
hand_back
weapon_main
weapon_fx_socket
skirt_front
skirt_back
thigh_front
shin_front
boot_front
thigh_back
shin_back
boot_back
shadow_contact
```

## Animation IDs

```text
battle_idle
hurt_light
attack_light
skill_cast
break_down
victory
return_idle
```

## Event names

```text
evt_attack_start
evt_hit_apply
evt_vfx_spawn
evt_sfx_play
evt_hitstop_start
evt_return_idle
evt_animation_done
```
