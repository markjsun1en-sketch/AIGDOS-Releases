# Spine / Godot Rigging Notes

## Practical distinction

Spine-style workflows usually expect trimmed parts, bone hierarchy, mesh deformation, and weights. Godot cutout workflows can be simpler: Sprite2D layers animated by AnimationPlayer with pivots and transform tracks.

## Choose Godot Sprite2D + AnimationPlayer when

- the actor only needs idle, hurt, attack, and skill cast;
- the team wants simple debugging;
- large deformations are not needed;
- the source art is not cleanly prepared for mesh weights.

## Choose Skeleton2D/Bone2D when

- the character has clean parts and pivots;
- parent/child bone hierarchy improves workflow;
- the team is comfortable debugging 2D skeleton behavior.

## Choose Spine/Live2D-style tooling when

- the asset needs high-quality mesh deformation;
- hair, cloth, skirt, and face need detailed movement;
- commercial animation polish is required;
- a human animator/technical artist will own the final rig.

## Avoid

- full auto-binding from a single rendered image;
- mesh weighting without clean separated parts;
- expecting large pose changes from a front-facing static illustration;
- relying on AI to invent hidden anatomy without review.
