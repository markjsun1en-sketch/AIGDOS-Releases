# Godot Import Checklist

## Asset placement

Suggested paths:

```text
res://actors/<character_id>/textures/layers/
res://actors/<character_id>/animations/
res://actors/<character_id>/scenes/
res://actors/<character_id>/vfx/
```

## Import settings

For pixel-art projects, use nearest filtering. For high-resolution anime assets, use linear filtering only if it does not blur edges.

Check:

- transparent background preserved;
- no baked checkerboard;
- no chroma spill if source was green/magenta;
- consistent canvas size if using layered Sprite2D;
- correct compression setting for quality target;
- mipmaps off for UI-like actors unless project requires them.

## Scene tree pattern: cutout actor

```text
CharacterAlphaActor2D (Node2D)
  Root (Node2D)
    Pelvis (Node2D)
      Torso (Sprite2D)
      HeadPivot (Node2D)
        Head (Sprite2D)
        FrontHair (Sprite2D)
        BackHair (Sprite2D)
      FrontArmPivot (Node2D)
        FrontUpperArm (Sprite2D)
        FrontForearm (Sprite2D)
        FrontHand (Sprite2D)
        WeaponPivot (Node2D)
          Weapon (Sprite2D)
      BackArmPivot (Node2D)
      ScarfPivot (Node2D)
      CapePivot (Node2D)
  AnimationPlayer
  AnimationTree
  VFXSockets
    weapon_tip
    chest
    head
    feet
```

## Signals / events

Recommended events:

```text
animation_event(event_name: StringName)
hit_frame_reached(attack_id: StringName)
animation_finished_safe(animation_id: StringName)
```

## Test scene

Build a simple test scene with:

- actor centered;
- plain background;
- ground line;
- frame/time display;
- buttons to play each animation;
- optional ghost overlay for first/last loop frame.
