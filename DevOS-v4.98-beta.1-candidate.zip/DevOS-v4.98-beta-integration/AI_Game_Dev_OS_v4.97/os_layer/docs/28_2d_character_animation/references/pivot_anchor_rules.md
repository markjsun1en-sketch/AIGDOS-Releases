# Pivot and Anchor Rules

## Core principle

A pivot should represent the anatomical or mechanical joint, not the center of the PNG.

## Common pivots

| Layer | Pivot |
|---|---|
| pelvis | hip center / root joint |
| torso | lower spine or chest connection |
| head | neck base |
| front_hair | hairline or scalp connection |
| back_hair_main | back scalp / neck root |
| upper_arm | shoulder |
| forearm | elbow |
| hand | wrist |
| weapon | grip point, not image center |
| thigh | hip socket |
| shin | knee |
| boot | ankle or sole anchor depending on animation |
| cape/scarf | cloth attachment point |

## Foot anchor

For full-body battle actors, keep a stable foot/root anchor:

```text
root_anchor_normalized = (0.5, 0.92)
```

This is suitable for runtime placement near bottom-center while leaving transparent padding.

## Weapon pivot

The weapon pivot must be at the grip, not the blade center. Add a socket for:

```text
weapon_tip
weapon_mid
weapon_grip
```

## Normalized pivot notation

Use normalized layer coordinates when exact pixels are unknown:

```text
pivot: (0.50, 0.12)  # x, y from top-left, normalized 0–1
semantic: shoulder_joint
```

## QA checks

- Rotate arm ±20°: does the shoulder tear?
- Rotate forearm ±35°: does the elbow detach?
- Rotate head ±8°: does the neck gap appear?
- Move torso breathing ±4px: do hair and scarf follow correctly?
- Attack pose: does the weapon remain in hand?
