# Project Runtime Protocol

> **v4.90 Batch 3 Step 3 — governance node landed**
> **Status**: shape definition + governance node + root additionalProperties:false locked. capabilities patternProperties enum and adapter_bindings node land in Batch 2 P0-1.
> **Schema**: `schemas/protocol/project_runtime_protocol.schema.json`

## Purpose

Defines the contract between an external project and a mounted OS Core.
The yaml file `.ai_dev_os/project_runtime_protocol.yaml` is the single
artifact every adopting project must produce; it declares:

1. legacy version of the project (where it came from)
2. mounted core version (which OS Core is currently in use)
3. target protocol version (which OS Core is being adopted toward)
4. compatibility mode (`progressive_adoption` | `direct_replacement`)
5. host profile (codex / cursor / claude_code / workbuddy / claude_code_subagents)
6. per-capability adoption status

## Yaml Shape (skeleton)

```yaml
project_id: <required, kebab-case>
project_name: <required, free text>

project_runtime_protocol:
  legacy_project_version: <semver, e.g. "4.82">
  mounted_core_version: <semver, e.g. "4.89">
  target_protocol_version: <semver, e.g. "4.90">
  compatibility_mode: progressive_adoption | direct_replacement
  direct_replacement_allowed: <bool, default false>

host:
  primary_host: codex | cursor | claude_code | workbuddy | claude_code_subagents
  secondary_hosts: [<list of host ids, optional>]

capabilities:
  <capability_id>:
    protocol_version: <semver, optional, defaults to target_protocol_version>
    adoption_status: not_present | detected_legacy | compatible | needs_adapter | adopting | adopted | verified | blocked | disabled
    namespace: <optional, project-scoped namespace for that capability>

# Governance node — landed in Batch 3 Step 3
# See docs/14_state_surface_governance/ for rule/schema/script suite
governance:
  state_surface_governance:
    enabled: true                           # required, project must opt in
    line_count_policy: standard             # lenient | standard | strict (default: standard)
    archive_strategy: by_sprint             # by_date | by_sprint (default: by_sprint)
    cold_start_minimum_contract: enabled    # enabled | disabled (default: enabled)
    project_extensions:
      active_surfaces: []      # extra Tier 1 surface kinds (optional)
      readset_additions: []    # extra cold-start readset paths (optional)
```

## Capability IDs

The canonical list is in `CAPABILITY_COMPATIBILITY_MATRIX.md`. v4.90 Batch 1
declares the following 14 IDs (skeleton; matrix entries land in Batch 2):

```
01_runtime_core
02_project_profile
03_host_profile
04_handoff_registry
05_validation_evidence
06_context_governance
07_ltm_capture_consult
08_failure_fix_memory
09_agent_library
10_pack_activation
11_profile_parity
12_dashboard_exports
13_adapter_bridge
14_self_evolution_proposal
```

## Adoption Status State Machine

See `ADOPTION_STATE_MODEL.md`. The 9 valid statuses follow this transition graph:

```
not_present → detected_legacy → (compatible | needs_adapter)
                                 ↓
                              adopting → adopted → verified
                                 ↓
                              blocked
                                 ↓
                              disabled
```

## Lifecycle Hooks (Batch 2)

The following script bindings operate on this yaml (all `STUB` in Batch 1):

- `scripts/migration/detect_project_protocol.py` — read + validate yaml
- `scripts/migration/scan_legacy_project.py` — populate `capabilities`
- `scripts/migration/adopt_capability.py` — advance one capability's status
- `scripts/migration/validate_capability_adoption.py` — verify status transition

## Related Documents

- [PROGRESSIVE_ADOPTION_GUIDE.md](./PROGRESSIVE_ADOPTION_GUIDE.md)
- [CAPABILITY_COMPATIBILITY_MATRIX.md](./CAPABILITY_COMPATIBILITY_MATRIX.md)
- [ADOPTION_STATE_MODEL.md](./ADOPTION_STATE_MODEL.md)
- [../14_state_surface_governance/README.md](../14_state_surface_governance/README.md) — sister module P0-2 (governance node above)

## Layer Discipline

This document is **Layer 1 (OS Spec)**. No project names. Project-specific
yaml examples belong in case-study files outside this directory tree.
