# 13 — State Surface Governance / Migration / Protocol Compatibility

> **v4.90 Batch 5 — Agent Library / Pack Architecture closed 2026-05-12**
> **Status**: Batch 1 skeleton + Batch 2 Adoption Validation + Batch 2.5
> Mock Legacy Project Harness + Batch 6 Self-Evolution Skeleton +
> Batch 5 Agent Library / Pack Architecture all closed. Scan/validate
> are GUIDED; rows 09_agent_library and 10_pack_activation were
> promoted from `deprecated` to `requires_adapter` in Batch 5 Step 5.6
> (see V4_90_README §5.9 and docs/16_agent_library/); row 14
> `14_self_evolution_proposal` was promoted earlier in Batch 6 Step 6.7
> (see V4_90_README §5.8 and proposal `evo_2026_001`). The deprecated
> set is now empty; `total_scored` is locked at 14, `deprecated_count`
> at 0, and the `informational[]` block in adoption_report is nullable
> optional (D1a=C). Remaining migration scripts stay STUB until
> Batch 5.5. See V4_90_README §5.6-§5.9 for detail.
> **Reference implementation source**: a project-side core projection
> pattern (≈80-line projection replacing ~500-line full Core read);
> the project-specific case study lives in case-study files (P0-2 batch),
> not here.
> **Layering principle**: this directory MUST stay project-name-free
> (Layer 1 OS Spec); project-specific evidence belongs in case-study files
> elsewhere.

## Purpose

Solve the problem v4.89 Phase 0 evidence surfaced:

> "v4.82 → v4.89 cannot be done by direct replacement. Each capability
> must be adopted independently with a per-capability validation gate."

v4.90 P0-1 productizes the manual adoption experience into a formal
protocol + tooling layer.

## Documents in this Directory

| File | Role | Status |
| --- | --- | --- |
| `README.md` (this file) | Module entry point | skeleton |
| `PROJECT_RUNTIME_PROTOCOL.md` | Defines `project_runtime_protocol.yaml` shape and lifecycle | skeleton |
| `PROGRESSIVE_ADOPTION_GUIDE.md` | Step-by-step adoption flow (legacy scan → handshake → queue → adopt → verify → report) | skeleton |
| `V4_82_TO_V4_89_COMPATIBILITY_NOTES.md` | Inventory of breaking changes between v4.82 and v4.89 (informs the matrix) | skeleton |
| `CAPABILITY_COMPATIBILITY_MATRIX.md` | Per-capability compatibility table + fingerprint contract | skeleton |
| `ADOPTION_STATE_MODEL.md` | State machine for `not_present / detected_legacy / compatible / needs_adapter / adopting / adopted / verified / blocked / disabled` | skeleton |
| `MIGRATION_RISK_REGISTER.md` | Catalog of known migration risks + mitigation patterns | skeleton |
| `LEGACY_CONFLICT_RESOLUTION_GUIDE.md` | Playbook for resolving conflicts surfaced by the handshake | skeleton |

## Related Schemas (`schemas/protocol/`)

| Schema | Validates |
| --- | --- |
| `project_runtime_protocol.schema.json` | `.ai_dev_os/project_runtime_protocol.yaml` |
| `capability_adoption_state.schema.json` | `.ai_dev_os/capability_adoption_state.yaml` |
| `compatibility_matrix.schema.json` | `docs/13_migration/CAPABILITY_COMPATIBILITY_MATRIX.md` data block |
| `migration_state.schema.json` | `.ai_dev_os/migration_state.yaml` |
| `legacy_conflict_map.schema.json` | C1-C6 conflict map (filled in by Batch 3+) |
| `legacy_scan_result.schema.json` | **Batch 2** — Output of `scan_legacy_project.py` |

Adoption-side schema (`schemas/adoption/`):

| Schema | Validates |
| --- | --- |
| `adoption_report.schema.json` | **Batch 2** — Output of `validate_adoption.py` (score + findings + nullable optional informational; locked at scored=14 / deprecated=0 after Batch 5) |

## Related Scripts (`scripts/migration/` + `scripts/adoption/`)

| Script | Tier | Purpose |
| --- | --- | --- |
| `migration/detect_project_protocol.py` | STUB | Read `.ai_dev_os/project_runtime_protocol.yaml` if present |
| `migration/scan_legacy_project.py` | **GUIDED (Batch 2)** | Scan a project tree using 14 capability fingerprints; emits `legacy_scan_result.schema.json` |
| `migration/generate_capability_queue.py` | STUB | From scan results, produce per-capability adoption order |
| `migration/validate_protocol_compatibility.py` | STUB | Cross-check protocol declarations against the matrix |
| `migration/adopt_capability.py` | STUB | Drive a single capability through the adoption state machine |
| `migration/validate_capability_adoption.py` | STUB | Run the adoption acceptance checks |
| `migration/generate_migration_report.py` | STUB | Emit a final per-project migration report |
| `adoption/validate_adoption.py` | **GUIDED (Batch 2)** | Compute Required-gate `adoption_score` from a scan result; emit `adoption_report.schema.json` (JSON or YAML) |
| `adoption/run_mock_harness.py` | **GUIDED (Batch 2.5)** | End-to-end harness: clone mock baseline → plant fixture/custom spec → run scan+validate → emit report |

## Skeleton Discipline

Per `V4_90_README.md` §4.1 and the EP "harden, don't expand" principle:

1. **No project names anywhere in this directory** — case studies go in
   separate `STATE_SURFACE_MIGRATION_CASE_*.md` (P0-2) files. CI gate
   in v4.90 Batch 3 will enforce this.
2. **Skeleton files declare contracts only** — every TODO references
   the v4.90 batch that fills it in.
3. **Schemas validate emptiness** — empty input must be schema-valid
   so projects can opt-in incrementally.
4. **Scripts return STUB exit codes** — exit `4` (NOT_IMPLEMENTED)
   until v4.90 Batch 2 fills in real logic.

## v4.90 Roadmap (per plan §8 batch order)

```
Batch 1   This skeleton  (closed 2026-05-10, no real logic)
Batch 2   Adoption Validation  (closed 2026-05-11; scan + validate GUIDED)
Batch 2.5 Mock Legacy Project Harness  (closed 2026-05-11; Track 1 trial, synthetic legacy project)
Batch 3   State Surface Governance Spec  (sister module — see ../14_state_surface_governance/)
Batch 3.5 Migration Case Study  (Layer 2 evidence for both 13_migration and 14_governance)
Batch 6   Self-Evolution Skeleton  (closed 2026-05-11; see ../17_self_evolution/ and proposals/)
Batch 5   Agent Library / Pack Architecture
Batch 5.5 Real Project Adoption Simulation  (Track 2 trial, after pack model lands)
Batch 7   RC Hygiene + full acceptance
```

## Sister Module

P0-2 State Surface Governance lives at [`../14_state_surface_governance/`](../14_state_surface_governance/README.md).
P0-1 (this module) handles **how a project enters v4.90**; P0-2 handles
**how a project keeps its state surface lean** once adopted.
