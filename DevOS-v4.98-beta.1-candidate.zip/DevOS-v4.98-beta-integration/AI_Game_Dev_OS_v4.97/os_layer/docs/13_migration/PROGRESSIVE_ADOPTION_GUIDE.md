# Progressive Adoption Guide

> **Skeleton — v4.90 Batch 1**
> **Status**: flow definition only; per-step playbooks land in Batch 2.

## The 7-Step Adoption Flow

```text
1. Legacy Scan
   ↓
2. Protocol Handshake
   ↓
3. Conflict Map
   ↓
4. Capability Queue
   ↓
5. Per-Capability Adoption
   ↓
6. Per-Capability Verification
   ↓
7. Lock Adoption State + Migration Report
```

## Step Details (skeleton — fills in Batch 2)

### Step 1 — Legacy Scan
- **Tool**: `scripts/migration/scan_legacy_project.py`
- **Input**: project root path
- **Output**: per-capability fingerprint result (one of 9 statuses)
- **Stub behavior**: returns `not_present` for every capability

### Step 2 — Protocol Handshake
- **Tool**: `scripts/migration/detect_project_protocol.py --core <os-core>`
- **Input**: project root + mounted core path
- **Output**: `.ai_dev_os/project_runtime_protocol.yaml` (created if absent)
- **Stub behavior**: writes a minimal yaml with placeholder fields

### Step 3 — Conflict Map
- **Tool**: `scripts/migration/validate_protocol_compatibility.py`
- **Input**: yaml + matrix
- **Output**: `legacy_conflict_map` (validates against `legacy_conflict_map.schema.json`)
- **Stub behavior**: returns empty conflict list

### Step 4 — Capability Queue
- **Tool**: `scripts/migration/generate_capability_queue.py`
- **Input**: scan result + conflict map
- **Output**: ordered list of capabilities to adopt (respecting dependencies)
- **Stub behavior**: returns capabilities in declaration order

### Step 5 — Per-Capability Adoption
- **Tool**: `scripts/migration/adopt_capability.py <capability_id>`
- **Behavior**: advances state machine `detected_legacy → adopting → adopted`
- **Stub behavior**: prints intent only

### Step 6 — Per-Capability Verification
- **Tool**: `scripts/migration/validate_capability_adoption.py <capability_id>`
- **Behavior**: runs the matrix-defined validation checks; advances `adopted → verified`
- **Stub behavior**: returns PASS without checking

### Step 7 — Lock + Report
- **Tool**: `scripts/migration/generate_migration_report.py`
- **Output**: structured report bound to `migration_state.yaml`
- **Stub behavior**: emits empty report skeleton

## Acceptance Criteria

A project is considered "v4.90-adopted" when:
- All required capabilities are at `verified` status
- All optional capabilities are at one of `verified | disabled | not_present`
- `migration_state.yaml` is locked with a non-null `completed_at`
- `generate_migration_report.py` exits 0

## Layer Discipline

Layer 1 (OS Spec). No project names.
