# PROJECT_INIT_GUIDE — Scaffold a `.ai_dev_os/` Runtime Tree (v4.90 Batch 9)

> **Status**: shipped 2026-05-13 (Batch 9 closure).
> **Tools**: `scripts/adoption/init_project_runtime.py` (Step 9.2) +
> `templates/project_runtime/` (Step 9.3) +
> `scripts/adoption/run_mock_harness.py --emit-full-project-runtime`
> (Step 9.4).

---

## 1. Purpose

Give an adopting project a one-command path from "no v4.90 runtime"
to a complete, schema-conformant `.ai_dev_os/` tree containing:

- 6 yaml files describing the project's adoption protocol, profile,
  host, active packs, governance posture, and capability adoption
  snapshot.
- 4 working directories (`ltm/`, `evidence/`, `reports/`, `archive/`)
  with README + `.gitkeep`.

Replaces the v4.89 era of "copy the workbuddy_private starter and
edit by hand". Everything that the templates emit is validated
against the Step 9.1 schemas, so the resulting tree is contract-safe
from day one.

---

## 2. Two flows

| Flow | Driver | When to use |
|---|---|---|
| **Pure init** | `scripts/adoption/init_project_runtime.py` | You already know the project's identity, host, and stage. Fastest path; no fixture / scan required. |
| **Harness emit** | `scripts/adoption/run_mock_harness.py --fixture <id> --emit-full-project-runtime <path>` | You want scan+validate to run against a fixture (mock or real legacy project) first, then scaffold from the same `--project-id`. Useful for adoption rehearsals. |

Both flows call the same `scaffold()` Python API internally, so the
file set and field semantics are identical. The Batch 9 Step 9.5
revalidation (`tests/adoption/test_init_workbuddy_private_e2e.py`)
asserts this equivalence on the `workbuddy_private` fixture.

---

## 3. Pure-init quickstart

```bash
python3 scripts/adoption/init_project_runtime.py \
    --out  <project_root>/.ai_dev_os/ \
    --project-id    acme_demo \
    --project-name  "Acme Demo" \
    --stage         alpha \
    --primary-host  claude_code \
    --legacy-version 4.82 \
    --target-version 4.90
```

Expected: `SCAFFOLDED ... — 10 files written` on stdout, exit 0.

### 3.1 Argument reference

| Flag | Type | Required | Notes |
|---|---|---|---|
| `--out` | path | yes | Destination dir. Typically `<project>/.ai_dev_os/`. |
| `--project-id` | slug | yes | Lowercase kebab/underscore (`^[a-z0-9_-]+$`). Used as ltm namespace key and stable id across the runtime. |
| `--project-name` | string | yes | Human-readable name. Free-form, quoted. |
| `--stage` | enum | yes | Project lifecycle stage. One of: `incubation` / `alpha` / `beta` / `release_candidate` / `production` / `maintenance` / `sunset`. Distinct from `--game-dev-phase` (the game-development workflow term). |
| `--game-dev-phase` | enum | no (auto-derived) | v4.90.9+. Game-development workflow phase, distinct from lifecycle `--stage`. One of: `prototype` / `mvp` / `vertical_slice` / `alpha_build` / `beta_build` / `production` / `post_launch`. If omitted, derived from `--stage`: `incubation→prototype`, `alpha→alpha_build`, `beta→mvp`, `release_candidate→vertical_slice`, `production→production`, `maintenance/sunset→post_launch`. |
| `--primary-host` | enum | yes | One of: `codex` / `cursor` / `claude_code` / `claude_code_subagents` / `workbuddy`. |
| `--legacy-version` | semver | no (default `4.82`) | Source project's pre-adoption OS version. |
| `--target-version` | semver | no (default `4.90`) | Target adoption version. |
| `--dry-run` | flag | no | Print the file list without writing. |
| `--force` | flag | no | Overwrite a non-empty `--out` dir. Required for re-runs. |
| `--format` | enum | no (default `text`) | `text` or `json`. JSON output emits `{status, out_dir, written}`. |

### 3.2 Exit codes

| Code | Meaning |
|---|---|
| 0 | Scaffold complete (or dry-run with no errors). |
| 1 | Refused to overwrite a non-empty `--out` without `--force`. |
| 3 | Internal error. |
| 4 | Usage error (bad flag value — pattern, enum, missing required). |

---

## 4. Harness-emit quickstart

```bash
python3 scripts/adoption/run_mock_harness.py \
    --fixture workbuddy_private \
    --project-id   wb_private_demo \
    --emit-full-project-runtime  <project>/.ai_dev_os/ \
    --emit-primary-host workbuddy \
    --emit-stage alpha \
    --out  reports/adoption_report.json
```

Differences from the pure-init flow:

1. The harness first clones the baseline fixture, plants the
   `--fixture` preset's capability evidence, runs `scan_legacy_project`
   and `validate_capability_adoption`, then writes
   `reports/adoption_report.json`.
2. **Only on success**, it scaffolds the `.ai_dev_os/` tree at
   `--emit-full-project-runtime` with the supplied id / host / stage.
3. Defaults: `--emit-primary-host claude_code`, `--emit-stage alpha`.
4. Re-runs always overwrite (`force=True` is hardcoded in the
   harness integration — fresh fixture = fresh tree).

Omitting `--emit-full-project-runtime` leaves the harness flow
unchanged (no scaffold, no side effects). This is the back-compat
contract verified by `test_omitting_emit_flag_leaves_harness_unchanged`.

---

## 5. What you get

```
<project_root>/.ai_dev_os/
├── 01_project_runtime_protocol.yaml   # legacy_version / target / compatibility_mode
├── 02_project_profile.yaml            # project_id / name / stage  (schema-valid)
├── 03_host_profile.yaml               # primary_host                (schema-valid)
├── 04_active_packs.yaml               # active_packs: []            (schema-valid)
├── 05_governance.yaml                 # state_surface_governance node
├── 06_adoption_state.yaml             # 14-capability adoption snapshot
├── ltm/                               # README + .gitkeep
├── evidence/                          # README + .gitkeep
├── reports/                           # README + .gitkeep
└── archive/                           # README + .gitkeep
```

Each yaml carries `schema_version: "0.1.0-beta"`. Batch 12.2 will
unify-promote those constants to `1.0.0`; the toolkit and template
files will update at the same time.

---

## 6. Template overrides

By default the renderer reads templates from
`templates/project_runtime/<name>.tmpl`. If a template file is
missing, the script falls back to an inline string baked into
`scripts/adoption/init_project_runtime.py`.

To customise scaffolded output for your team, copy the relevant
`.tmpl` file out of the v4.90 install tree, edit the placeholders
you want to change, and set `TEMPLATE_DIR` (via env var or by
running the script from a checkout that has your override on the
import path).

Placeholder vocabulary (full list in
`templates/project_runtime/README.md`):

```
{{PROJECT_ID}}          {{PROJECT_NAME_JSON}}   {{STAGE}}
{{PRIMARY_HOST}}        {{LEGACY_VERSION}}      {{TARGET_VERSION}}
{{SNAPSHOT_DATE}}       {{CAPABILITY_ENTRIES}}
```

Unknown placeholders are left literal. The renderer never errors on
unrecognised tokens — that is forward-compatible-by-design.

---

## 7. Validation after scaffold

The scaffolded tree is contract-safe out of the box, but after any
manual edit you should re-validate:

```bash
# Self-validate the three Step 9.1 schemas
python3 -c "
import json, sys, pathlib
sys.path.insert(0, '.')
from scripts.governance._yaml_subset import parse_yaml_text
import jsonschema

for yaml_name, schema_path in [
    ('02_project_profile.yaml', 'schemas/adoption/project_profile.schema.json'),
    ('03_host_profile.yaml',    'schemas/adoption/host_profile.schema.json'),
    ('04_active_packs.yaml',    'schemas/adoption/active_packs.schema.json'),
]:
    inst = parse_yaml_text(pathlib.Path(f'.ai_dev_os/{yaml_name}').read_text())
    schm = json.loads(pathlib.Path(schema_path).read_text())
    jsonschema.validate(instance=inst, schema=schm)
    print(f'OK  {yaml_name}')
"
```

As of v4.90 Batch 11 the CLI exposes this as `ai-dev-os pack adoption validate`.

---

## 8. Adoption checklist

After a successful scaffold:

1. **Commit the tree to your project repo.** `.ai_dev_os/` is meant
   to live alongside source code.
2. **Update `02_project_profile.yaml`** if `name` / `stage` evolves.
3. **Plant evidence**: drop logs / commits / screenshots referenced
   by `evidence_ref` fields into `evidence/`.
4. **Track adoption progress**: as capabilities move from `not_present`
   to `adopting` / `adopted` / `verified`, update
   `06_adoption_state.yaml` (or let the harness regenerate it).
5. **Activate agent packs**: as the project starts using cluster packs
   from `agent_packs/`, append entries to `04_active_packs.yaml`.

A typical adoption sprint produces a few new entries in `ltm/`,
moves 1-2 capabilities forward in `06_adoption_state.yaml`, and may
sign off the first pack in `04_active_packs.yaml`.

---

## 9. Worked example: workbuddy_private

The Batch 9 Step 9.5 revalidation appendix
(`docs/14_state_surface_governance/STATE_SURFACE_MIGRATION_CASE_WORKBUDDY_PRIVATE.md`
§9) records both flows producing identical `.ai_dev_os/` trees for the
`workbuddy_private` fixture (11/14 capabilities present, host =
`workbuddy`, stage = `alpha`). Refer to that appendix for a concrete
end-to-end log.

---

## 10. References

- `scripts/adoption/init_project_runtime.py`
- `scripts/adoption/run_mock_harness.py`
- `templates/project_runtime/README.md`
- `schemas/adoption/{host_profile,project_profile,active_packs}.schema.json`
- `docs/13_migration/PROJECT_RUNTIME_PROTOCOL.md` (the yaml the
  scaffold targets)
- `docs/14_state_surface_governance/STATE_SURFACE_MIGRATION_CASE_WORKBUDDY_PRIVATE.md`
  §9 (Step 9.5 revalidation appendix)
