# Migration Risk Register

> **Skeleton — v4.90 Batch 1**
> **Status**: risk categories defined; concrete entries land in Batch 2 +
> grow over time as real adoptions surface new risks.

## Risk Categories

| Category | Definition |
| --- | --- |
| **R1 Data Loss** | Risk of losing project state during adoption |
| **R2 Schema Drift** | Risk of yaml/json schema desync between OS Core and project |
| **R3 Verification False-Pass** | Risk that verified status is reached without real check |
| **R4 Cascade Block** | Risk that one blocked capability blocks others |
| **R5 Audit Gap** | Risk that adoption events are not captured in audit log |
| **R6 Rollback Difficulty** | Risk that mid-adoption state cannot be safely rolled back |

## Per-Risk Mitigation Pattern

Every entry in this register declares:

```yaml
risk_id: <R1.001 | R2.001 | ...>
category: <R1 | R2 | R3 | R4 | R5 | R6>
title: <short title>
description: <full text>
likelihood: low | medium | high
impact: low | medium | high
mitigation:
  prevention: [<list of pre-adoption checks>]
  detection: [<list of in-adoption signals>]
  recovery: [<list of rollback steps>]
captured_at: <ISO 8601>
captured_from: <capability_id | scenario | reviewer>
```

## Initial Risks (skeleton — full content in Batch 2)

### R1.001 — Pre-adoption project_runtime_protocol.yaml absent
- **Mitigation**: `detect_project_protocol.py` creates skeleton yaml on first run
- TODO: full mitigation playbook (Batch 2)

### R2.001 — Capability fingerprint regex too permissive
- **Mitigation**: each fingerprint requires unit test in `tests/migration/`
- TODO: fingerprint test harness (Batch 2)

### R3.001 — Verification check returns PASS without running
- **Mitigation**: SCAFFOLD scripts MUST exit 4 (NOT_IMPLEMENTED), never 0
- TODO: SCAFFOLD exit code policy doc (Batch 2)

### R4.001 — Cyclic capability dependencies
- **Mitigation**: `generate_capability_queue.py` topological sort + cycle detection
- TODO: queue generator implementation (Batch 2)

### R5.001 — Adoption events skip audit log
- **Mitigation**: `adopt_capability.py` MUST write `migration.adopt` audit event
- TODO: audit envelope contract (Batch 2)

### R6.001 — Adoption interrupted mid-flight
- **Mitigation**: `migration_state.yaml` checkpoint-on-step-completion
- TODO: checkpoint protocol (Batch 2)

## Layer Discipline

Layer 1 (OS Spec). No project names. Project-discovered risks belong in
case-study files; from there, generic patterns can be promoted into this
register.
