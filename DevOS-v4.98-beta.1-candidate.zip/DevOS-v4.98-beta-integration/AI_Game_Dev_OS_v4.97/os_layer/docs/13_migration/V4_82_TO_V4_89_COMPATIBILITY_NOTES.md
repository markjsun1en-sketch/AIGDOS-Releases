# V4.82 → V4.89 Compatibility Notes

> **v4.90 Batch 1 Step 2** — substantive content landed 2026-05-10
> **Status**: 7 breaking-change sections filled with concrete diff statements
> sourced from v4.89 CHANGELOG and Phase 0 evidence (PATH_MAPPING_TABLE,
> LOST_CAPABILITY_CHECKLIST). Each section is the input for the matching
> CAPABILITY_COMPATIBILITY_MATRIX row's adapter spec.

## Purpose

This note enumerates the breaking changes between v4.82 (project_adaptation
& Workbuddy entry baseline) and v4.89 (Tier2 Beta release). It is the
primary input to `CAPABILITY_COMPATIBILITY_MATRIX.md` row authoring and
adapter implementation.

## How to Read This Note

Each section follows the pattern:

```
What changed (1-2 lines)
What it breaks (concrete failure mode if you direct-copy)
Migration recipe (high-level steps; concrete script in Batch 2)
Capability row → matrix entry that consumes this section
```

---

## 1. Runtime Boundary Changes

**Capability**: `01_runtime_core` (breaking, high risk, requires human approval)

### What changed
- `runtime/` directory restructured between v4.78 Tier1 and v4.89: new `runtime/observability/`, `runtime/integrations/`, `runtime/registries/`, `runtime/ltm/` substructure.
- `runtime/__init__.py` introduced (v4.78 had no package boundary).
- `runtime/MATURITY_MATRIX.md` new (per-script maturity tier registration).
- Source-of-Truth registry path migration: previously scattered → consolidated under `runtime/registries/`.

### What it breaks
- v4.82 projects with their own `runtime/` layout will collide on the `__init__.py` and the registries subtree.
- Code paths that imported `runtime.foo` directly may break if `foo` was relocated under `runtime.observability.foo` or similar.

### Migration recipe
1. Pre-flight: snapshot existing `runtime/` for rollback.
2. Stage v4.89 `runtime/` skeleton alongside legacy under `runtime_legacy/`.
3. For each legacy script, manually decide: (a) keep under legacy/ as deprecated, or (b) port into the new substructure.
4. Update import statements via grep+rewrite.
5. Run `runtime/__init__.py` smoke (does Python import succeed?).

### Adapter
- **Spec**: Batch 2 will land `adapters/runtime_core_v482_to_v490.py` to automate steps 2-4.
- **Manual gate**: yes — `requires_human_approval: true` because import rewrites can silently break business logic.

---

## 2. Handoff / Registry Schema Changes

**Capability**: `04_handoff_registry` (requires_adapter, high risk, requires human approval)

### What changed
- v4.89 P0-A A1 introduced the **canonical 9-field audit envelope**:
  ```
  event_id / event_type / timestamp / actor / source_layer / runtime_profile /
  result / audit_status / details
  ```
- Pre-A1 (and v4.82) records were "flat shape" — all queryable fields at envelope root.
- v4.89 P0-A A5 added envelope-aware read helper `_ev_get` so consumers can read either shape.
- v4.90 Batch 0 Step 2 **removed** the deprecated `top_level=` mirror bridge entirely.

### What it breaks
- v4.82 audit consumers that expect `task_id` at envelope root will not find it (it lives under `details.task_id`).
- v4.82 emit code that did not pass through `wrap_external_record` will produce flat-shape events that some v4.89 consumers (post-Batch 0 Step 2) reject.

### Migration recipe
1. Audit all v4.82 emit sites: any direct `audit.append({"task_id": ...})` is a flat-shape emit.
2. Replace with `emit_wrapped(record, source_layer=..., event_type=..., result=..., ts_override=..., extra={...})`.
3. Drop any `top_level={...}` kwarg invocations (no longer accepted).
4. Audit consumers: replace direct `event["task_id"]` reads with `_ev_get(event, "task_id")`.
5. Validate via `schemas/mcp_audit_log.schema.json` — every event must validate.

### Adapter
- **Spec**: Batch 2 will land `adapters/handoff_envelope_v482_to_v490.py` to walk a legacy audit log and rewrite each entry.
- **Replay validation**: matrix row 04 declares `sample_handoff_replay` as a required check; the adapter must produce envelope-shaped output that the v4.89 verifier accepts.

---

## 3. LTM Namespace Introduction

**Capability**: `07_ltm_capture_consult` (breaking, medium risk)

### What changed
- v4.88 had **no LTM namespace** — all memories lived in a flat `memories/` directory.
- v4.89 M9.5 introduced **Layer A namespace**: `ltm/{os, project, failures, pattern, _quarantine}/`.
- `runtime/ltm/capture.py` and `runtime/ltm/consult.py` enforce per-namespace routing.
- `config/memory_retrieval_policy.yaml` declares retrieval order and quarantine policy.
- 19 legacy + 4 project seed entries delivered in v4.89.

### What it breaks
- v4.82 projects with their own memory store will not be auto-discovered by v4.89 `consult.py`.
- Direct file reads under `memories/` will miss the new namespace structure.

### Migration recipe
1. Create the 5 namespace dirs: `os/ project/ failures/ pattern/ _quarantine/`.
2. Walk legacy memory store; classify each entry into one of the 5 namespaces.
3. Default fallback: unclassified entries → `_quarantine/` for human review.
4. Update consumers to use `runtime.ltm.consult.consult(query, namespace=...)`.
5. Run `tests/test_ltm_*.py` (22 tests in v4.89 baseline) — all should pass against migrated store.

### Adapter
- **Spec**: Batch 2 will land `adapters/ltm_namespace_introduction.py` for one-shot migration with dry-run mode.
- **Grandfathered policy**: legacy entries default to `promotion_status: grandfathered`; only new entries go through the quarantine→approved gate (see Batch 4 LTM v2).

---

## 4. Validation Chain Changes

**Capability**: `05_validation_evidence` (requires_adapter, medium risk)

### What changed
- v4.89 Phase 2 introduced **5-profile parity verification** (Phase 2 M6.1-M6.7, closed at tag `v4.89-phase-2-m6`).
- v4.89 Phase 4 introduced `BETA_SPRINT_EXIT_CRITERIA.md` — 5-category integrity check (init / execution / external / evidence / close).
- `verify_beta_sprint_exit.py` GUIDED for init/evidence/close; SCAFFOLD for execution/external (scheduled v4.90 Batch 0.5).
- `schemas/external_sync_audit.schema.json` + `schemas/mcp_audit_log.schema.json` + `schemas/merge_event.schema.json` introduced.

### What it breaks
- v4.82 projects had no formal validation gate; verifier scripts are entirely new surface.
- Any v4.82 validation script that emitted ad-hoc verdicts will not feed into the new 5-category verifier.

### Migration recipe
1. No deletion required — v4.82 ad-hoc validation can coexist as `legacy_validation/` directory.
2. Add `BETA_SPRINT_EXIT_CRITERIA.md` to project's `docs/09_beta_sprint/` if absent.
3. Wire CI/CD to call `python3 scripts/verify_beta_sprint_exit.py --workspace <project> --sprint <id>`.
4. Verifier exit codes: 0=PASS, 1=CONDITIONAL, 2=FAIL, 3=INTERNAL_ERROR.

### Adapter
- **Spec**: no migration adapter needed (additive change, not breaking).
- **Validation**: matrix row 05 declares `envelope_9field_validation` + `audit_log_jsonl_parseable` as required checks.

---

## 5. Workflow Routing Changes

**Capability**: `06_context_governance` (requires_adapter, low risk)

### What changed
- v4.78 had 12 workflow categories; v4.89 introduced 13 (M-class audio added in Sprint 8).
- `config/context_loading_policy.yaml` introduced in v4.89 — declares context pack selection by stage/profile.
- 5 context pack tiers: `lean_context_pack / standard_context_pack / expanded_context_pack / full_reference_context_pack` + `pack_selection_guide`.
- `config/pack_selection_policy.yaml` introduced.

### What it breaks
- v4.82 projects with their own workflow routing will have to opt in to the new 13-category schema or maintain mapping.
- Context loading: any `read all docs` pattern needs to be replaced with policy-driven readset.

### Migration recipe
1. Map v4.82 workflow categories to the v4.89 13-category set; record gaps in project's `WORKFLOW.md`.
2. Adopt `context_loading_policy.yaml` with `lean_context_pack` as default; tighten as needed.
3. Run `python3 scripts/profile_boot_readset.py --profile <id>` to verify cold-start readset.
4. Validate context_pack yaml shapes (Batch 2 will provide schema).

### Adapter
- **Spec**: no automated adapter (configuration migration).
- **Validation**: matrix row 06 declares `context_pack_yaml_valid` + `readset_minimum_contract` as required checks (Batch 3 P0-2 State Surface Governance defines `readset_minimum_contract`).

---

## 6. Profile Model Changes

**Capability**: `02_project_profile` + `03_host_profile` + `11_profile_parity` (collectively breaking, medium risk)

### What changed
- v4.82 had a single project-level profile (one `.json` config).
- v4.89 introduced **5-profile schema-driven model** with byte-identical envelope guarantee:
  - codex / cursor / claude_code_subagents / claude_code_agent_teams / workbuddy_private
- `schemas/runtime_execution_profile.schema.json` enforces shape.
- `scripts/validate_execution_profile.py` + `scripts/profile_boot_readset.py` + `scripts/render_profile_summary.py` introduced.
- Phase 2 M6.8 R1 regression matrix (16 row × 2 schema flag = 32 calls byte-identical).

### What it breaks
- v4.82 single-profile config does not validate against the new schema.
- Any code reading "the profile" needs to specify which of the 5.

### Migration recipe
1. Rename legacy `profile.json` → `config/profiles/<host>.json`.
2. Fill in the schema-required fields (consult `schemas/runtime_execution_profile.schema.json`).
3. Pick a `primary_host` for the project; declare in `project_runtime_protocol.yaml`.
4. Run `python3 scripts/validate_execution_profile.py --profile <host>`.
5. Optionally: declare `secondary_hosts` for cross-host parity testing.

### Adapter
- **Spec**: Batch 2 will land `adapters/project_profile_single_to_multi.py` — converts a v4.82 single profile into one of the 5 host profile shells.
- **Manual review**: required because field semantics changed (e.g. `coordination_model` is new).

---

## 7. CORE_OS_DIGEST Pattern (project-side reference)

**Capability**: implicit (informs `06_context_governance` and `02_project_profile`)

### What changed
- v4.89 surfaced a project-side reference pattern: ~13 Core OS file reads can be projected into an ≈80-line `CORE_OS_DIGEST.md`, dramatically reducing cold-start cost.
- The pattern is **not yet** an OS Core capability — it's a reference implementation discovered during real adoption (v4.8.2 → v4.89).

### What it implies for migration
- v4.82 projects currently doing "read every Core file at startup" can adopt this projection pattern to cut cold-start tokens.
- The projection must be regenerated whenever Core OS rules change — a CI check is required to detect drift.

### Migration recipe
- Optional in Batch 2; promoted to formal capability in a later batch if real-project evidence warrants.
- If adopted: add `CORE_OS_DIGEST.md` to project root; configure cold-start to load digest first, full Core only on demand.

### Future
- Batch 2 will track this as a **candidate generic capability** (`core_projection`) but will not auto-promote it to the matrix until at least 2 independent projects demonstrate value.
- The concrete project-side instance is documented in the P0-2 case-study file, not here.

---

## Layer Discipline

Layer 1 (OS Spec). No project names. Reference implementation pointers
above are by file-path allusion only (project-specific evidence belongs in
case-study files).
