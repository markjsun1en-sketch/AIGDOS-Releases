# v4.92 REOPEN 进度报告

> **生成时间**: 2026-06-04
> **当前基线**: B10-B12 v4.92 implementation baseline committed on `main`（commit SHA 以 git HEAD 为准）
> **状态**: B0-B11.5 ✅ 完成 · B12 ✅ committed validation baseline · B13 待启动
> **Scope**: REOPEN 全量迁移（49 skills + 4 agents）— Route 1（v4.92 内完成，为 v4.93 提供测试基准）

---

## 一、背景与范围

### 为什么 REOPEN

v4.92 旧封板（tag `v4.92-Capability_Foundation` @ `6fc0248`）后 EP review 发现实质缺口：

- pack 体系**缺装载层** — `_adaptation_hooks` 从 v4.91 cut 来但与新 pack 断开
- 契约全硬编码，无法适配项目
- 架构定论未落地：**控制平面/执行平面分离 + 双轴正交模型**（evo_2026_004, accepted）

EP 决策：**"地基没打完不许盖二楼"** → REOPEN，补 6 项 P0 基建，并扩大 scope 至全量迁移。

### 扩大的 Scope（Route 1）

| 原计划（旧封板） | 扩大后（Route 1） |
|---|---|
| B0-B9 基建 + 封板 | B0-B6 P0 基建 + B7 3 pack 骨架 |
| 不做全量迁移 | **B8-B12 全量迁移 49 skills + 4 agents** |
| v4.93 做迁移 | v4.92 做迁移 + 验证，v4.93 承接成果 |

### 核心架构决策（evo_2026_004）

- **控制平面/执行平面分离**: OS Core = 控制平面（治理/判定，永不生产）/ Packs = 执行平面（生产，永不定方向）
- **双轴正交模型**: agent = (role 8-role 闭集, discipline 正交字段 game_design/art/program/qa)
- **判定权铁律**: 判定权永锁控制平面，pack 不能自判（"运动员兼裁判" guard）
- **4 Lead 架构**: Game Design / Art / Tech / QA
- **术语铁律**: 职能线用 `game_design`，严禁与 8-role 的 `design` 混用

---

## 二、已完成工作（B0-B7）

### B0 — Planning & Scope Freeze ✅ `3731bcd`

**产出**:
- 读取并确认 evo_2026_004 提案（accepted）
- 冻结 REOPEN scope：6 P0 基建 batch
- 归档旧 charter
- 保留旧封板 tag `v4.92-Capability_Foundation` @ `6fc0248`

---

### B1 — Pack Binding / Adaptation Loading Layer ✅ `e0187d6`

**产出**:
- `capability_protocols/pack_binding.schema.json`
- `scripts/capability/load_pack_bindings.py`（zero-dep bare python3）
- `tests/capability/test_pack_binding.py`
- `config/pack_bindings.json`（data_pipeline_pack 首个 adopt 条目）

**关键决策**: 装载层独立于 pack 本体，OS 控制平面负责绑定解析。

---

### B2 — Legacy Agent/Skill Inventory ✅ `4c251cf`

**产出**:
- `docs/13_migration/legacy_skill_inventory.json` — 全量 49 skills 清单
- `docs/13_migration/legacy_agent_inventory.json` — 全量 4 agents 清单
- 分类统计：execution 28 / control 15 / agents 4 / nhr 4 / split 1

---

### B3 — Legacy→v4.92 Migration Mapping ✅ `62c238f`

**产出**:
- `scripts/migration/build_migration_map.py` — 构建迁移地图（zero-dep + merge-on-rebuild）
- `docs/13_migration/legacy_to_v492_migration_map.json` — 迁移地图 ledger
- `tests/migration/test_migration_map.py` — 10/10 PASS
- `schemas/protocol/legacy_migration_map.schema.json`

**关键技术点**:
- **merge-on-rebuild**: 重建时保留 `migrated`/`deprecated`/`notes` 等人工修订字段
- **冲突检测**: map 记录的 plane 与当前 rebuilt 值矛盾 → exit 1 阻止

---

### B4 — Skill Contract Compatibility ✅ `0b0056d`

**产出**:
- `capability_protocols/skill_contract.schema.json` — `execution_level` 重定义为"产出物性质轴"
- 枚举: `production_execution/spec_generation/review_only/validation_execution/advice_only`
- 5 个 fixture skill contracts + `tests/contracts/test_execution_level_compat.py` 13/13 PASS
- 新增 `completion_evidence` 字段（必填）
- `additionalProperties: false`

---

### B5 — One Discipline Slice (data_pipeline) ✅ `cbc4a10`

**产出**:
- `packs/game_system_packs/data_pipeline/skills/rawdata_pipeline_check_skill.json` — **首个真迁移 skill**
- `docs/13_migration/b5_slice_evidence/ev_ec84bd1b.validation.json` — pipeline 健康检查证据
- `rawdata_pipeline_check_review.md` — review skill 首份真输出（捕获 RH 中 5 张漂移表 + 1 个 schema 违规）
- 验证：all green，data_pipeline_pack adopt 全链路跑通

**关键技术点**:
- **Sandbox 边界铁律**: Bash 写 = workspace 根树内；Write/Edit 任意可写
- **Migration Map = Living Ledger**: merge-on-rebuild 防止覆盖进度

---

### B6 — OS-side Verdict Chain + Lead Capability Container ✅ `41a71c2`

**产出**:
- `capability_protocols/os_verdict.schema.json` — `verdict_owner` const = `os_control_plane`
- `capability_protocols/lead_capability.schema.json` — Lead 能力容器 schema
- `os_control_plane/leads/*.capability.json`（5 个文件，program_lead 含首个真 capability）
- `scripts/capability/validate_verdict_chain.py` — 判定链验证（zero-dep + jsonschema 双模）
- `tests/contracts/test_verdict_chain.py` — 8/8 PASS

**关键决策**: 判定权铁律 → 可执行守卫（schema const + validator 双层防线）

---

### B7 — Three Pack Skeletons for Full Migration ✅ `805995e`

**产出**（8 files）:

| Pack | 接收 skills | lifecycle | agents |
|---|---|---|---|
| `design_data` | 15（spec_generation） | draft | `design_spec_author`（占位） |
| `art_asset` | 9（spec_generation） | draft | `art_asset_preparer`（占位） |
| `qa_validation` | 2（validation_execution） | draft | `qa_validation_runner`（占位） |

- agent 契约骨架 `lifecycle_status: draft`；B10 已补齐 `discipline` / `consults_disciplines`
- `agent_contract.schema.json` 已在 B10 扩展单值 `discipline`

---

## 三、已完成工作（B8）

### B8 — Migrate 28 Execution Skills ✅

**目标**: 将 28 个 execution skills 迁移到 4 个 packs。

**Workload / 完成状态**:

| Pack | 接收数 | 状态 |
|---|---|---|
| `design_data` | 15 | ✅ migrated (`spec_generation`) |
| `art_asset` | 9 | ✅ migrated（7 `spec_generation` + 2 `production_execution`） |
| `qa_validation` | 2 | ✅ migrated (`validation_execution`) |
| `godot_2d_adapter` | 2 | ✅ migrated (`spec_generation` planner skills) |

**当前状态**: B8 **28/28 完成**。

**关键修正**:
- 迁移图中 program discipline 的旧占位 `godot_2d_pack` 已修正为实际 shipped pack `godot_2d_adapter`。
- `art_asset` / `qa_validation` / `godot_2d_adapter` pack manifest 已登记新增 skills，并补齐 shared write collision policy。
- `RELEASE_MANIFEST.json` 已重建，`scripts/rebuild_release_manifest.py --check` clean。

**验证**:
- 13 个新增 B8 skill contracts schema-valid。
- `run_practicality_gate.py` 覆盖新增 art / QA / Godot planner skills：PASS。
- `run_boundary_linter.py` 覆盖 art / QA packs：PASS。
- `validate_godot_2d_pack.py` 覆盖 Godot adapter：PASS。
- `pytest tests/migration/test_migration_map.py tests/contracts/test_execution_level_compat.py`：27 passed。
- `pytest tests/capability/test_boundary_linter.py tests/capability/test_practicality_gate.py tests/capability/test_pack_adoption_tools.py`：28 passed。
- `pytest tests/test_rebuild_release_manifest.py tests/test_release_manifest_consistency.py`：12 passed。

**每个 skill 迁移步骤**:
1. 读取旧 skill contract（v4.91 `skills/` 目录）
2. 按新 `skill_contract.schema.json` 重写（更新 `execution_level` 为新枚举）
3. 写入目标 pack 的 `skills/<skill_name>.json`
4. 更新 migration map
5. 运行 contract validation + pack boundary lint
6. commit（atomic per skill 或 per batch）

---

## 四、已完成工作（B9）

### B9 — Control Plane Migration（15 skills + 4 Lead 填 capability）✅

**目标**:
- 迁移 15 个 control-plane skills
- 填充 4 Lead `capability.json`（B9 前仅 program_lead 有 1 个 capability）
- 建立 control skill → Lead capability 的映射关系

**完成状态**:

| Lead | 新增 control capabilities | 总数 |
|---|---:|---:|
| `game_design_lead` | 4 | 4 |
| `art_lead` | 3 | 3 |
| `program_lead` | 2 | 3（含 B5/B6 `rawdata_pipeline_check`） |
| `qa_lead` | 1 | 1 |
| `orchestrator` | 5 | 5 |

**关键决策**:
- control-plane legacy skills 不迁为 pack `skill_contract`，而是迁为 Lead `capabilities[]`。
- 每个 Lead capability 只声明 `judges` / `consumes_evidence` / `emits_verdict=os_verdict` / `handoff_on_fix`。
- 判定权仍锁在 OS control plane；需要修复时只通过 `handoff_on_fix` 指向 execution pack 或 owning Lead。

**验证**:
- `python3 scripts/capability/validate_verdict_chain.py --repo-root . --map docs/13_migration/legacy_to_v492_migration_map.json`：clean，16 个 `migrated_from` provenance claims checked。
- 5 个 Lead capability sheets schema-valid。
- `pytest tests/contracts/test_verdict_chain.py`：10 passed。

---

## 五、已完成工作（B10）

### B10 — Agent Migration Mechanism + Migrate 4 Agents ✅

**目标**:
1. 扩展 `agent_contract.schema.json` 加入 `discipline` 字段（双轴模型落地）
2. 建立 agent 迁移机制：v4.91 agent → pack `agents/` 目录 + `agent_contract.json`
3. 迁移 4 个 agents

**完成状态**:

| legacy agent | v4.92 agent contract | discipline | consults |
|---|---|---|---|
| `Design_Planning_Agent` | `design_spec_author` | `game_design` | `art`, `program`, `qa` |
| `UI_UX_Agent` | `design_spec_author` | `game_design` | `art`, `program`, `qa` |
| `Art_Direction_Agent` | `art_asset_preparer` | `art` | `game_design`, `program`, `qa` |
| `Art_Production_Agent` | `art_asset_preparer` | `art` | `game_design`, `program`, `qa` |

**关键决策**:
- `discipline` 是单值主责字段，不做多值 ownership。
- 跨职能协作用 `consults_disciplines` 表达；主题范围继续由 `can_advise_on` 描述。
- UI/UX 第一版不拆 agent，主责落 `game_design`；视觉风格、Godot 实现、可读性验收通过 handoff/consults 路由到 `art` / `program` / `qa`。
- `migrated_from_agents` 只记录 provenance，不扩大 owner 边界。

**验证**:
- 5 个 shipped agent contracts schema-valid。
- `pytest tests/contracts/test_capability_contracts_schema.py tests/migration/test_agent_b10_migration.py`：26 passed。
- `pytest tests/capability/test_data_pipeline_pack.py tests/capability/test_godot_2d_pack.py tests/capability/test_boundary_linter.py`：30 passed。

---

## 六、已完成工作（B11）

---

### B11 — NHR 4 + Split 1 ✅

**目标**:
- **NHR（Needs Human Review）**: 4 个 skills 需要 EP 人工 review
- **Split**: 1 个 skill 需要拆分为多个更细粒度的 skills

**完成状态**:

| legacy skill | B11 裁决 | v4.92 landing | 备注 |
|---|---|---|---|
| `asset-variation-control` | `art` / `spec_generation` | `art_asset_pack:asset_variation_control_skill` | 变体规则是 art production spec；style verdict 仍归 `art_lead` |
| `battle-hud-designer` | `game_design` / `spec_generation` | `design_data_pack:battle_hud_designer_skill` | HUD 布局/层级/spec；资产和实现走 handoff |
| `game-design-system-builder` | `game_design` / `spec_generation` | `design_data_pack:game_design_system_builder_skill` | 设计系统 token/component 规则；最终视觉方向归 `art_lead` |
| `ui-asset-prompt-engineer` | `art` / `spec_generation` | `art_asset_pack:ui_asset_prompt_engineer_skill` | UI asset prompt 属于可复用视觉资产生产 spec，不扩大 UI/UX owner |
| `game-ui-wireframe-generator` | split completed | `design_data_pack:game_ui_wireframe_spec_skill` + `game_design_lead:game_ui_wireframe_structure_review` | execution 产出 low-fi wireframe spec；control 只判定结构是否可接受 |

**关键决策**:
- B11 的 4 个 NHR 不废弃，全部通过 human review 重分类为 `spec_generation`。
- `ui-asset-prompt-engineer` 主责落 `art`，因为它生产 UI 资产 prompt spec；布局/UX 仍由 `game_design` owning agent 负责。
- `game-ui-wireframe-generator` 不再保持 `split_required` 状态：实际落地为一个 execution skill + 一个 control review capability。
- `legacy_skill_inventory.json` 增加 B11 分类 override，避免后续重建又回到 NHR/Split。
- `legacy_to_v492_migration_map.json` 当前为 49/49 `migrated`。

**验证**:
- `pytest tests/migration/test_legacy_inventory.py`：9 passed。
- `python3 scripts/migration/build_migration_map.py --out docs/13_migration/legacy_to_v492_migration_map.json`：无 conflict，保留 B11 progress。
- `pytest tests/migration/test_legacy_inventory.py tests/migration/test_migration_map.py tests/migration/test_b11_skill_migration.py`：26 passed。
- `pytest tests/contracts/test_execution_level_compat.py tests/contracts/test_verdict_chain.py tests/contracts/test_capability_contracts_schema.py`：46 passed。
- `pytest tests/capability/test_data_pipeline_pack.py tests/capability/test_godot_2d_pack.py tests/capability/test_boundary_linter.py tests/capability/test_pack_adoption_tools.py`：43 passed。
- `run_boundary_linter.py` direct checks：design_data 20 instances PASS；art_asset 13 instances PASS；qa_validation 4 instances PASS。
- `run_practicality_gate.py` direct checks：design_data + art_asset 29 skills PASS。
- `python3 scripts/rebuild_release_manifest.py --check`：clean；manifest tests 12 passed。

---

## 七、已完成工作（B11.5）

---

### B11.5 — Executive Producer OS-layer First Version ✅

**目标**:
- 将 `producer` / `Executive Producer` 从文档语义落到 OS control plane。
- 明确它与 `orchestrator` 的边界：EP 负责 go/no-go、范围、优先级、风险接受；orchestrator 负责拆解、路由、依赖和 handoff。

**完成状态**:
- 新增 `os_control_plane/leads/executive_producer.capability.json`。
- 新增 native control capabilities：
  - `product_scope_priority_gate`
  - `milestone_go_no_go_gate`
- 扩展 `lead_capability.schema.json` 的 `lead_id` 闭集，加入 `executive_producer`。
- 扩展 `validate_verdict_chain.py`，将 `executive_producer` 作为 discipline=null 的 control owner。
- 更新 `os_verdict.schema.json` 的 `reviewed_by` 描述，允许 `executive_producer` 作为 control-plane reviewer。
- 更新 `AGENT_ROLE_CATALOG.md`，明确 `producer` / `executive_producer` 是 governance owner labels，不是 pack production agents。

**关键决策**:
- 第一版不新增 `producer_agent`，也不放入 pack agents。
- `executive_producer` 是 native OS control capability sheet，不来自 legacy skill migration，所以不增加 `migrated_from` 计数。
- `producer` 与 `executive_producer` 暂不拆成两个 sheet；第一版以 `executive_producer` 承载 product/governance sign-off，后续可在 v4.93 根据项目压力拆出 project-level `producer`。

---

## 八、B12-B13 状态

---

### B12 — Full Validation + Deprecate Old Skills ✅（committed validation baseline）

**目标**:
1. 全量 49 skills 迁移完成后跑联合回归（目标: 0 failures）
2. Layer Lint 验证 layer-1 根分离
3. `RELEASE_MANIFEST.json` 全量重建验证（byte-stable）
4. Gate C1-C8 pre-tag 验证
5. 标记 v4.91 `skills/` legacy tree 为 `deprecated-read-only`

**完成状态**:
- `proposals/evo_2026_004_blueprint.md` 已补 proposal front matter；`validate_proposal.py --dir proposals` 当前 5 files / 0 violations / 0 warnings。
- `os_verdict.reviewed_by` 已由 `validate_verdict_chain.py` 强化为可解析控制面 reviewer：Lead sheet id、Lead capability id 或 allowlisted OS validator id；未知 reviewer 会失败。
- 旧 `skills/` tree 不把 49 个 migrated entries 标为 `deprecated`，因为 migration map 已经 49/49 migrated；策略是将 legacy tree 标为 `deprecated-read-only`，只保留 provenance / compatibility reference / byte-stable migration evidence，不再作为 active v4.92 dispatch surface。
- `RELEASE_MANIFEST.json` 已重建并通过 check，当前 `required_manifest_files=1371`。

**B12 当前验证**:
- `python3 -B -m pytest -p no:cacheprovider tests/`：1946 passed, 2 skipped, 3 warnings。
- `python3 -B scripts/rebuild_release_manifest.py --check`：clean，无 drift。
- `python3 -B scripts/governance/lint_layer_separation.py`：72 roots scanned，0 violations，runtime tree pass clean。
- `python3 -B scripts/capability/validate_verdict_chain.py --repo-root . --map docs/13_migration/legacy_to_v492_migration_map.json`：6 Lead sheets，17 provenance claims checked，clean。
- `python3 -B scripts/capability/run_boundary_linter.py ...`：5 instances inspected，PASS。
- `python3 -B scripts/capability/run_practicality_gate.py ...`：39 skills，PASS。
- `python3 -B scripts/governance/run_release_closure_gate.py --profile fast --fast-total-timeout 900 --fast-aggregate-wall-timeout 900 --format json`：overall 0。
- `python3 -B scripts/governance/run_release_closure_gate.py --profile full --skip-deliverables --pytest-timeout 600 --aggregate-timeout 900 --format json`：overall 0，C1-C8 pass；C9-C13 skipped as pre-tag deliverables。

**证据位置**:
- `.dev_os_meta/governance/EVIDENCE_LOG.md`：E-010 / E-011。

**限制**:
- v4.92 implementation baseline 已提交，meta evidence 已在 `.dev_os_meta/governance/EVIDENCE_LOG.md` 绑定到 baseline commit。
- B13 不应直接 closure；必须先完成 whole-version pre-closure audit（命名、逻辑、引用、manifest、临时文件、release-dir 身份切换）。
- B13 release notes、tag、go/no-go 仍未完成。

---

### B13 — Closure + Re-tag

**目标 / 未完成项**:
1. Whole-version pre-closure audit：扫描命名、逻辑、引用、manifest、entry docs、临时文件、运行日志和 release-dir 切片规则。
2. 修复或明确所有 audit blockers，尤其是 source-tree fork-anchor identity 与 release-dir final identity 的边界。
3. 单独切 `AI_Game_Dev_OS_v4.92_Release/` 干净目录，排除 pycache / pytest cache / closure logs / exports runtime output 等临时内容。
4. 在 release 目录内完成 v4.92 final identity transition（manifest、VERSION、core marker、entry docs、release notes、tag target）。
5. 给 closure gate 增加 v4.92 deliverable overlay；C9-C13 不能继续只检查 v4.90 RC3 release notes / tag / daily-log 语义。
6. Final Gate 全绿，且不能使用 `--skip-deliverables`。
7. 撰写 v4.92 Final release notes。
8. 打新 tag 取代旧 `v4.92-Capability_Foundation`。
9. 准备 v4.93 分支。
10. 向 v4.93 移交全量迁移成果。

---

## 九、49 Skills 迁移状态总览

> 来源: `docs/13_migration/legacy_to_v492_migration_map.json`

| 状态 | 数量 | 占比 | 说明 |
|---|---|---|---|
| ✅ migrated | 49 | 100% | B5 1 个 + B8 28 个 execution skills + B9 15 个 control skills + B11 5 个 resolved skills |
| 🔄 pending | 0 | 0% | 无 |
| 👀 nhr | 0 | 0% | B11 已清零 |
| ✂️ split | 0 | 0% | B11 已清零 |

---

## 十、关键技术决策记录

### 架构决策

| 决策 | 内容 | 来源 |
|---|---|---|
| 控制/执行平面分离 | OS Core = 控制 / Packs = 执行 | evo_2026_004 |
| 双轴正交模型 | agent = (role 闭集, discipline 正交) | evo_2026_004 |
| 判定权铁律 | pack 不能自判，必须由 OS Lead 判定 | B6 schema const |
| 单轴重定义 | execution_level 从"写文件能力"改为"产出物性质" | B4 |
| Living Ledger | migration map merge-on-rebuild 保留人工修订 | B5-c4 |
| Agent 主责纪律 | `discipline` 单值主责，`consults_disciplines` 表达跨职能协作 | B10 |
| B11 NHR/Split 收束 | 4 NHR 全部重分类为 `spec_generation`，1 split 落为 execution skill + Lead verdict capability | B11 |
| EP / Orchestrator 边界 | EP 判定做不做/优先级/go-no-go；orchestrator 只拆解、路由、跟依赖 | B11.5 |

### 操作纪律

| 纪律 | 内容 |
|---|---|
| Manifest 顺序 | 改 tracked → rebuild_release_manifest → gate |
| Sandbox 边界 | Bash 写 = workspace 内；Write/Edit = 任意 |
| Byte-lock #9 | 不动 v4.91/v4.89_Release |
| Layer 分离 | OS 不含项目名；lint 拦 |
| 零依赖脚本 | scripts/*.py bare python3 可跑 |

---

## 十一、已知问题与风险

### 高优先级

| # | 问题 | 影响 |
|---|---|---|
| 1 | control capability id 目前记录在 Lead sheet，migration map 仅有 `os_lead_capability` 粗粒度字段 | schema 未提供 control capability id 字段，后续若需要机器 join，应扩展 map schema |
| 2 | 当前 source tree 仍保留 fork-anchor identity（`package_name=AI_Game_Dev_OS_v4.90`、`.core_os_root=v4.90-marker`、README/USER_GUIDE 多处 v4.90/v4.91 入口叙述） | 按历史规则 source tree 可保留 anchor，但 v4.92 release dir 必须执行 final identity transition；否则不能 closure |
| 3 | full closure gate 的 deliverable 段仍绑定 v4.90 RC3（C9-C13） | v4.92 B13 需要 release-dir identity、v4.92 final notes、new tag、clean-tree proof、zip/evidence report 等 v4.92 deliverable overlay |
| 4 | hub defaults 仍有 v4.91 identity，`capability_protocols/README.md` 仍称 scaffold | release dir active entry / protocol docs / hub identity 必须同步，否则入口语义不一致 |

### 中优先级

| # | 问题 | 影响 |
|---|---|---|
| 5 | draft pack 不 adoption-eligible | 需 B13 closure 或 EP exception 后再提升 lifecycle |
| 6 | 429 token quota | 长会话可能中断 |

---

## 十二、下一步行动

### 立即（本次会话）

1. **Pre-closure audit**: 先整体扫描 v4.92 source tree，确认命名、逻辑、引用、manifest、entry docs、临时文件、运行日志和 release-dir 切片规则。
2. **Audit fixes**: 修复或显式豁免 audit blockers；不能把 `--skip-deliverables` 的 B12 gate 当作 closure。
3. **Release dir plan**: 准备单独切 `AI_Game_Dev_OS_v4.92_Release/`，并在 release dir 内做 final identity transition。

### 短期（B13 完成前）

4. **B13 完成标准**: pre-closure audit blockers 关闭，clean release dir 已切出，final release notes 完成，full gate 不跳过 deliverables，EP 明确 go/no-go。

### 长期（B13 + v4.93 交接）

4. **B13**: Closure + re-tag
5. **v4.93 交接**: 全量迁移成果作为 v4.93 baseline

---

## 十三、附录

### A. Commit History（B0-B7）

```
805995e (HEAD) v4.92 REOPEN B7: three pack skeletons for full migration
41a71c2 v4.92 REOPEN B6: OS-side Verdict Chain + Lead capability container
cbc4a10 v4.92 REOPEN B5: One Discipline Slice — data line migrated + verified
0b0056d v4.92 REOPEN B4: Skill Contract Compatibility
62c238f v4.92 REOPEN B3: Legacy->v4.92 Migration Mapping
4c251cf v4.92 REOPEN B2: Legacy Agent/Skill Inventory
e0187d6 v4.92 REOPEN B1: Pack Binding/Adaptation loading layer
3731bcd v4.92 REOPEN B0: scope freeze + archive evo_2026_004
```

### B. 关键文件索引

| 文件 | 用途 |
|---|---|
| `docs/13_migration/legacy_skill_inventory.json` | 49 skills 全量清单 |
| `docs/13_migration/legacy_agent_inventory.json` | 4 agents 全量清单 |
| `docs/13_migration/legacy_to_v492_migration_map.json` | 迁移地图 ledger |
| `capability_protocols/skill_contract.schema.json` | Skill 契约 schema |
| `capability_protocols/os_verdict.schema.json` | OS 判定契约 schema |
| `capability_protocols/lead_capability.schema.json` | Lead 能力容器 schema |
| `os_control_plane/leads/*.capability.json` | 6 control capability sheets（4 Leads + orchestrator + executive_producer） |
| `packs/game_system_packs/*/capability_pack.json` | 4 packs 骨架 |

---

*本报告由 Kai 自动生成，基于 MEMORY.md + conversation summary + git log。*
