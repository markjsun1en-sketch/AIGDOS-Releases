# Legacy Conflict Resolution Guide

> **Skeleton — v4.90 Batch 1**
> **Status**: conflict taxonomy defined; per-conflict playbooks land in Batch 2.

## Conflict Taxonomy

The handshake (`scripts/migration/scan_legacy_project.py`) produces a
`legacy_conflict_map` artifact. Each conflict entry has one of these types:

| Type | Description |
| --- | --- |
| **C1 path_collision** | Legacy file path conflicts with target path |
| **C2 schema_mismatch** | Legacy schema version incompatible with target |
| **C3 namespace_clash** | Legacy global namespace collides with new scoped namespace |
| **C4 contract_break** | Legacy API contract broken in target version |
| **C5 dependency_cycle** | Capability dependency graph contains a cycle |
| **C6 fingerprint_ambiguous** | Multiple capabilities match same fingerprint |

## Resolution Patterns (skeleton — playbooks in Batch 2)

### C1 path_collision
- **Default action**: rename legacy path with `_legacy` suffix; new path takes over
- **Override**: `legacy_conflict_resolution.yaml` per-collision rule
- **Rollback**: rename `_legacy` back, remove new path

### C2 schema_mismatch
- **Default action**: invoke matrix-defined adapter (if any); else block
- **Override**: human approval required if `requires_human_approval: true`
- **Rollback**: restore original yaml from `migration_state.yaml.backup`

### C3 namespace_clash
- **Default action**: scope legacy entries under `legacy/` namespace
- **Override**: per-namespace mapping in conflict resolution yaml
- **Rollback**: flatten back to global namespace

### C4 contract_break
- **Default action**: block adoption; require explicit unblock via human gate
- **Override**: none (this is the safety floor)
- **Rollback**: not applicable (block prevents progress)

### C5 dependency_cycle
- **Default action**: refuse to generate adoption queue
- **Override**: explicit cycle break via `--break-cycle <capability_id>` flag
- **Rollback**: not applicable

### C6 fingerprint_ambiguous
- **Default action**: log all matches; require fingerprint refinement
- **Override**: `--prefer <capability_id>` flag
- **Rollback**: not applicable (read-only scan)

## Schema

`schemas/protocol/legacy_conflict_map.schema.json` validates the output of
the scan step. Skeleton in Batch 1; full enum + per-type required fields
in Batch 2.

## Human Approval Gate

For conflicts where `requires_human_approval: true` (set by matrix row):

- `adopt_capability.py` exits 5 (HUMAN_APPROVAL_REQUIRED)
- A human must explicitly invoke `--approve <conflict_id>` to proceed
- Approval event written to audit log as `migration.approve`

## Layer Discipline

Layer 1 (OS Spec). No project names. Project-side conflict instances
belong in case-study files.
