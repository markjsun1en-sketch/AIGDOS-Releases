# Capability Compatibility Matrix

> **v4.90 Batch 1 Step 2** — fingerprints landed 2026-05-10
> **Status**: 14 capability rows with concrete fingerprints. Adopted versions
> reflect v4.89 RC3 baseline; v4.82 source paths are the legacy mapping target.
> **Schema**: `schemas/protocol/compatibility_matrix.schema.json`
> **Consumers**: `scripts/migration/scan_legacy_project.py` reads this file
> to populate the capability detection step.

## Matrix Structure

Each capability row carries:

```yaml
capability_id: <01_runtime_core | ... | 14_self_evolution_proposal>
schema_version: "1.0.0"
source_version: <semver>
target_version: <semver>
compatibility_status: direct_compatible | requires_adapter | breaking | deprecated
risk_level: low | medium | high
direct_copy_allowed: <bool>
requires_human_approval: <bool>
dependencies: [<list of capability_id this one requires>]
adapter:
  name: <adapter id, optional>
fingerprint:
  required_paths: [<list of file/dir paths>]
  required_schemas: [<list of schema paths>]
  detect_command: <bash command, optional>
  expected_signals: [<list of regex/string assertions>]
validation:
  required_checks: [<list of check ids>]
```

## 14 Capabilities — Summary Index

| ID | Name | v4.82 → v4.90 | Risk | Adapter Needed | Notes |
| --- | --- | --- | --- | --- | --- |
| 01 | runtime_core | breaking | high | yes | Boundary restructure, audit envelope |
| 02 | project_profile | requires_adapter | medium | yes | Single-profile → 5-profile model |
| 03 | host_profile | breaking | medium | yes | New host categorisation introduced |
| 04 | handoff_registry | requires_adapter | high | yes | Envelope 9-field contract |
| 05 | validation_evidence | requires_adapter | medium | yes | Audit log envelope shape |
| 06 | context_governance | requires_adapter | low | no | Profile manifests + readset |
| 07 | ltm_capture_consult | breaking | medium | yes | Namespace introduced (Layer A) |
| 08 | failure_fix_memory | breaking | low | no | Seed memory + promotion gate |
| 09 | agent_library | requires_adapter | low | yes | Batch 5 P1-1: docs/16_agent_library/ + agent_packs/ + schemas/agent_library/ |
| 10 | pack_activation | requires_adapter | low | yes | Batch 5 P1-1: pack_selection_policy.yaml + game_type_packs/ + context_packs/ |
| 11 | profile_parity | breaking | medium | yes | 5-profile schema-driven parity |
| 12 | dashboard_exports | direct_compatible | low | no | exports/ artifact contract |
| 13 | adapter_bridge | requires_adapter | medium | yes | tapd / git stub bindings |
| 14 | self_evolution_proposal | requires_adapter | medium | yes | Batch 6 P1-2: proposals/ ledger + schemas/self_evolution/ |

## Fingerprint Contract (per EP plan §3 補充 4)

Each capability MUST declare a fingerprint that:

1. Identifies the capability's presence by **file paths + schema refs**
   (not by version number alone).
2. Provides a deterministic detect command (`scripts/migration/scan_legacy_project.py`
   in Batch 2 will run these via subprocess).
3. Declares expected signals (regex / string assertions on detected files).

If a capability is `deprecated` in this matrix, fingerprint detection still
runs to enable scan reports, but adoption is auto-set to `disabled`.

> **Note (Batch 5 Step 5.6)**: the deprecated set is now empty.
> Rows 09_agent_library and 10_pack_activation were promoted to
> `requires_adapter` (Batch 5 P1-1); row 14_self_evolution_proposal
> was promoted in Batch 6 (`evo_2026_001`). All 14 capability rows
> are scored. `schemas/adoption/adoption_report.schema.json` locks
> `total_scored=14 / deprecated_count=0`; the
> `informational[]` block is nullable optional (D1a=C) and emitted
> only when a future deprecation reintroduces an entry. See
> V4_90_README §5.8 / §5.9.

## 14 Fingerprint Rows

### 01_runtime_core

```yaml
capability_id: 01_runtime_core
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: breaking
risk_level: high
direct_copy_allowed: false
requires_human_approval: true
dependencies: []
adapter:
  name: runtime_core_v482_to_v490
  spec_ref: "docs/13_migration/V4_82_TO_V4_89_COMPATIBILITY_NOTES.md#1-runtime-boundary-changes"
fingerprint:
  required_paths:
    - "runtime/"
    - "config/"
  required_schemas:
    - "schemas/runtime_execution_profile.schema.json"
  detect_command: 'test -d runtime && test -f config/runtime_storage_policy.yaml'
  expected_signals:
    - "runtime/__init__.py exists"
    - "config/runtime_storage_policy.yaml present"
validation:
  required_checks:
    - schema_validation_runtime_state
    - smoke_runtime_init_exit_zero
```

### 02_project_profile

```yaml
capability_id: 02_project_profile
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: requires_adapter
risk_level: medium
direct_copy_allowed: false
requires_human_approval: false
dependencies: ["01_runtime_core"]
adapter:
  name: project_profile_single_to_multi
  spec_ref: "docs/13_migration/V4_82_TO_V4_89_COMPATIBILITY_NOTES.md#6-profile-model-changes"
fingerprint:
  required_paths:
    - "config/profiles/"
  required_schemas:
    - "schemas/runtime_execution_profile.schema.json"
  detect_command: 'ls config/profiles/*.json 2>/dev/null | wc -l | grep -q "[1-9]"'
  expected_signals:
    - "config/profiles/*.json count >= 1"
validation:
  required_checks:
    - schema_validation_each_profile
    - profile_id_uniqueness
```

### 03_host_profile

```yaml
capability_id: 03_host_profile
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: breaking
risk_level: medium
direct_copy_allowed: false
requires_human_approval: false
dependencies: ["02_project_profile"]
adapter:
  name: host_profile_introduction
  spec_ref: "docs/13_migration/PROJECT_RUNTIME_PROTOCOL.md#yaml-shape-skeleton"
fingerprint:
  required_paths:
    - "config/profiles/codex.json"
    - "config/profiles/cursor.json"
    - "config/profiles/claude_code_subagents.json"
    - "config/profiles/claude_code_agent_teams.json"
    - "config/profiles/workbuddy_private.json"
  required_schemas:
    - "schemas/runtime_execution_profile.schema.json"
  detect_command: '[ -f config/profiles/codex.json ] && [ -f config/profiles/cursor.json ]'
  expected_signals:
    - "5 host profiles present in config/profiles/"
validation:
  required_checks:
    - host_profile_5way_parity
```

### 04_handoff_registry

```yaml
capability_id: 04_handoff_registry
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: requires_adapter
risk_level: high
direct_copy_allowed: false
requires_human_approval: true
dependencies: ["01_runtime_core"]
adapter:
  name: handoff_envelope_v482_to_v490
  spec_ref: "docs/13_migration/V4_82_TO_V4_89_COMPATIBILITY_NOTES.md#2-handoff-registry-schema-changes"
fingerprint:
  required_paths:
    - "runtime/registries/handoff_queue.json"
    - "runtime/registries/task_registry.json"
  required_schemas:
    - "schemas/mcp_audit_log.schema.json"
  detect_command: 'test -f runtime/registries/handoff_queue.json'
  expected_signals:
    - "runtime/registries/handoff_queue.json exists"
    - "runtime/registries/task_registry.json exists"
validation:
  required_checks:
    - handoff_envelope_9field_contract
    - sample_handoff_replay
    - registry_consistency_check
```

### 05_validation_evidence

```yaml
capability_id: 05_validation_evidence
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: requires_adapter
risk_level: medium
direct_copy_allowed: false
requires_human_approval: false
dependencies: ["04_handoff_registry"]
adapter:
  name: audit_envelope_v482_to_v490
  spec_ref: "docs/13_migration/V4_82_TO_V4_89_COMPATIBILITY_NOTES.md#4-validation-chain-changes"
fingerprint:
  required_paths:
    - "runtime/observability/runtime_event_collectors/"
  required_schemas:
    - "schemas/mcp_audit_log.schema.json"
    - "schemas/external_sync_audit.schema.json"
  detect_command: 'test -d runtime/observability/runtime_event_collectors'
  expected_signals:
    - "audit log envelope schema present"
validation:
  required_checks:
    - envelope_9field_validation
    - audit_log_jsonl_parseable
```

### 06_context_governance

```yaml
capability_id: 06_context_governance
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: requires_adapter
risk_level: low
direct_copy_allowed: false
requires_human_approval: false
dependencies: ["02_project_profile"]
adapter:
  name: context_loading_policy_introduction
  spec_ref: "docs/13_migration/V4_82_TO_V4_89_COMPATIBILITY_NOTES.md#5-workflow-routing-changes"
fingerprint:
  required_paths:
    - "config/context_loading_policy.yaml"
    - "context_packs/"
  required_schemas: []
  detect_command: 'test -f config/context_loading_policy.yaml && test -d context_packs'
  expected_signals:
    - "context_loading_policy.yaml present"
    - "context_packs/ directory present"
validation:
  required_checks:
    - context_pack_yaml_valid
    - readset_minimum_contract
```

### 07_ltm_capture_consult

```yaml
capability_id: 07_ltm_capture_consult
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: breaking
risk_level: medium
direct_copy_allowed: false
requires_human_approval: false
dependencies: ["01_runtime_core"]
adapter:
  name: ltm_namespace_introduction
  spec_ref: "docs/13_migration/V4_82_TO_V4_89_COMPATIBILITY_NOTES.md#3-ltm-namespace-introduction"
fingerprint:
  required_paths:
    - "ltm/"
    - "runtime/ltm/capture.py"
    - "runtime/ltm/consult.py"
    - "config/memory_retrieval_policy.yaml"
  required_schemas: []
  detect_command: 'test -f runtime/ltm/capture.py && test -f runtime/ltm/consult.py'
  expected_signals:
    - "ltm/ contains namespace dirs (os/ project/ failures/ pattern/)"
    - "runtime/ltm/capture.py + consult.py present"
    - "config/memory_retrieval_policy.yaml present"
validation:
  required_checks:
    - ltm_namespace_layout
    - memory_retrieval_policy_schema
    - capture_consult_smoke
```

### 08_failure_fix_memory

```yaml
capability_id: 08_failure_fix_memory
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: breaking
risk_level: low
direct_copy_allowed: false
requires_human_approval: false
dependencies: ["07_ltm_capture_consult"]
adapter:
  name: failure_fix_memory_seed_promotion
  spec_ref: "docs/13_migration/PROJECT_RUNTIME_PROTOCOL.md"
fingerprint:
  required_paths:
    - "ltm/failures/"
    - "ltm/_quarantine/"
  required_schemas: []
  detect_command: 'test -d ltm/failures'
  expected_signals:
    - "ltm/failures/ contains at least one .md entry"
    - "ltm/_quarantine/ namespace exists"
validation:
  required_checks:
    - failure_entry_evidence_ref
    - quarantine_promotion_gate
```

### 09_agent_library

```yaml
capability_id: 09_agent_library
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: requires_adapter
risk_level: low
direct_copy_allowed: false
requires_human_approval: false
dependencies: ["10_pack_activation"]
adapter:
  name: agent_library_v490_directory
  spec_ref: "Batch 5 P1-1 Agent Library / Pack Architecture"
fingerprint:
  required_paths:
    - "docs/16_agent_library/"
    - "agent_packs/"
    - "schemas/agent_library/agent_role.schema.json"
  required_schemas:
    - "schemas/agent_library/agent_pack_entry.schema.json"
  detect_command: 'test -d docs/16_agent_library && test -d agent_packs'
  expected_signals:
    - "docs/16_agent_library/ Layer 1 module spec present"
    - "agent_packs/ ledger with ap_YYYY_NNN_*.md seed packs"
    - "schemas/agent_library/agent_role.schema.json defines the 8-role enum"
validation:
  required_checks:
    - agent_library_spec_present
    - agent_packs_ledger_present
    - agent_role_schema_valid
```

### 10_pack_activation

```yaml
capability_id: 10_pack_activation
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: requires_adapter
risk_level: low
direct_copy_allowed: false
requires_human_approval: false
dependencies: []
adapter:
  name: pack_activation_v490_directory
  spec_ref: "Batch 5 P1-1 Agent Library / Pack Architecture"
fingerprint:
  required_paths:
    - "config/pack_selection_policy.yaml"
    - "game_type_packs/"
    - "context_packs/"
  required_schemas: []
  detect_command: 'test -f config/pack_selection_policy.yaml'
  expected_signals:
    - "pack_selection_policy.yaml present"
    - "game_type_packs/ and/or context_packs/ present"
validation:
  required_checks:
    - pack_selection_policy_valid
    - pack_selection_manifest_integrity
```

### 11_profile_parity

```yaml
capability_id: 11_profile_parity
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: breaking
risk_level: medium
direct_copy_allowed: false
requires_human_approval: false
dependencies: ["03_host_profile"]
adapter:
  name: profile_parity_schema_driven
  spec_ref: "Phase 2 M6.1-M6.7 (closed v4.89)"
fingerprint:
  required_paths:
    - "scripts/validate_execution_profile.py"
    - "scripts/render_profile_summary.py"
    - "scripts/profile_boot_readset.py"
  required_schemas:
    - "schemas/runtime_execution_profile.schema.json"
  detect_command: 'test -f scripts/validate_execution_profile.py'
  expected_signals:
    - "profile_parity validation scripts present"
validation:
  required_checks:
    - profile_5way_byte_identical_envelope
    - schema_driven_cross_check
```

### 12_dashboard_exports

```yaml
capability_id: 12_dashboard_exports
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: direct_compatible
risk_level: low
direct_copy_allowed: true
requires_human_approval: false
dependencies: ["05_validation_evidence"]
adapter:
  name: null
  spec_ref: "Direct compatible — exports/ artifact contract unchanged"
fingerprint:
  required_paths:
    - "exports/"
  required_schemas: []
  detect_command: 'test -d exports'
  expected_signals:
    - "exports/ directory present (smoke / latest / etc.)"
validation:
  required_checks:
    - exports_dir_writable
```

### 13_adapter_bridge

```yaml
capability_id: 13_adapter_bridge
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: requires_adapter
risk_level: medium
direct_copy_allowed: false
requires_human_approval: false
dependencies: ["05_validation_evidence"]
adapter:
  name: adapter_bridge_stub_to_real
  spec_ref: "v4.92 deferral — stub bindings only in v4.90"
fingerprint:
  required_paths:
    - "runtime/integrations/"
    - "runtime/integrations/git/"
    - "runtime/integrations/tapd/"
  required_schemas:
    - "schemas/external_sync_audit.schema.json"
    - "schemas/merge_event.schema.json"
  detect_command: 'test -d runtime/integrations/git && test -d runtime/integrations/tapd'
  expected_signals:
    - "runtime/integrations/git/ + tapd/ present (stub-tier in v4.90)"
validation:
  required_checks:
    - adapter_event_normalisation_smoke
```

### 14_self_evolution_proposal

```yaml
capability_id: 14_self_evolution_proposal
schema_version: "1.0.0"
source_version: "4.82"
target_version: "4.90"
compatibility_status: requires_adapter
risk_level: medium
direct_copy_allowed: false
requires_human_approval: true
dependencies: ["07_ltm_capture_consult"]
adapter:
  name: self_evolution_proposal_directory_v490
  spec_ref: "docs/17_self_evolution/PROPOSAL_LIFECYCLE_GUIDE.md"
fingerprint:
  required_paths:
    - "proposals/"
  required_schemas:
    - "schemas/self_evolution/proposal_entry.schema.json"
  detect_command: 'test -d proposals'
  expected_signals:
    - "proposals/ directory with evo_NNNN_NNN_*.md entries"
    - "schemas/self_evolution/proposal_entry.schema.json present"
validation:
  required_checks:
    - schema_validation_proposal_entry
    - lint_layer_separation_clean
```

## Auto-Disabled Capabilities

Empty after Batch 5 promotion; rows 09_agent_library and
10_pack_activation are now `requires_adapter` (active) per Batch 5
P1-1 Agent Library / Pack Architecture. Row 14 was promoted earlier
in Batch 6 (`evo_2026_001`). All 14 capability rows are now scored;
`deprecated_count` is locked at 0 in
`schemas/adoption/adoption_report.schema.json`.

| ID | Auto-disabled because |
| --- | --- |
| _(none after Batch 5)_ | All capability rows are scored or requires_adapter. |

`scan_legacy_project.py` (Batch 2) no longer auto-snaps any
capability to `disabled`. Note: `14_self_evolution_proposal` used to
live here as `deprecated` before Batch 6 promoted it; Batch 5 then
promoted rows 09 and 10 the same way — see V4_90_README §5.8 / §5.9
and proposal `evo_2026_001`.

## Layer Discipline

Layer 1 (OS Spec). No project names. Project-specific fingerprint deviations
belong in case-study files.
