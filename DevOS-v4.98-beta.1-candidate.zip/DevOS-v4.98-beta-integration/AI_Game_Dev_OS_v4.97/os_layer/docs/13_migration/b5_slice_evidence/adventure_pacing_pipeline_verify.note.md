# adventure_pacing pipeline verify note (B5-c3)

Slice run artifact for `ev_ec84bd1b.validation.json`.

- **convert_cmd** (resolved binding): `python3 policy/tools/data/xlsx_to_json.py --all`
- Ran over the adopted target's source tables; output to an OS-side verify dir (live runtime JSON not mutated — decision 2=B).
- `adventure_pacing.json`: regenerated == live (idempotent), pacing_constants = 25 rows, schema-valid.
- verify sha256: `c6f19f84b7039df6...`

This note exists so the validation_evidence record points at a tracked artifact in the OS tree. The verify output itself was a throwaway in a temp dir (not committed); the reproducible fact is the command + outcome recorded in the evidence JSON.
