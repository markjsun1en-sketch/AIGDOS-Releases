# RawData Pipeline Check — Migration Slice Review Report

> **Skill exercised**: `rawdata_pipeline_check_skill` (review_only, migrated from v4.91 in B5-c1)
> **Pack**: data_pipeline_pack ｜ **Batch**: v4.92 reopen B5-c3 ｜ **Date**: 2026-06-02
> **Target**: the adopted Slot+Roguelike project (project_id `slot_roguelike_target`); project name redacted per Layer-1 discipline.
> **Nature**: this is a REVIEW artifact — it describes mismatches and names handoff targets. It does NOT fix anything (review_only contract). Fixes are the target project's responsibility, not the OS migration framework's.

## What this proves

The review capability migrated in B5-c1 was run against a real adopted project's data pipeline (16 source tables -> runtime JSON, via the bound `convert_cmd`). It produced a categorized mismatch report on the first real use — demonstrating the migrated control-plane review skill is functional, not a paper contract.

## Pipeline health (the slice passes)

The `source xlsx -> importer -> runtime JSON` chain is sound for tables whose source is populated:

| output | rows | idempotent (regen == live) | schema |
|---|---|---|---|
| adventure_pacing | 25 | yes | PASS |
| failure_attribution | 11 | yes | PASS |
| boss_config | 9 | yes | (see finding F2) |
| sortie_variants | 3 | yes | (see finding F3) |

End-to-end regeneration is byte-identical to the live runtime JSON for the healthy tables — the migrated pack's bound pipeline genuinely drives the data.

## Findings (categorized; each names a handoff target)

### Category A — source-table / runtime drift (source is an empty placeholder; runtime is hand-authored)
The source xlsx exists but its data sheet has only a header (0 data rows), while the live runtime JSON is populated and hand-maintained. The pipeline cannot regenerate these tables.

| finding | output | regen rows | live rows | classification |
|---|---|---|---|---|
| F-A1 | slot_pity | 0 | 3 | drift: hand-authored, source is a stale empty shell with a different field schema (live keys on `scope`; xlsx defines `pity_name`) |
| F-A2 | chapters | 0 | 1 | drift: empty source sheet |
| F-A3 | gamestring | 469 | 483 | drift: 14 live entries not present in source |
| F-A4 | spin_postpone | 0 | 5 | drift: empty source sheet |
| F-A5 | mini_boss_pity | 0 | 1 | drift: empty source sheet |

**Handoff target**: the target project's data owner. Narrowest fix per table = either (a) declare the table hand-authored and exempt it from the pipeline's coverage list, or (b) backfill the source xlsx to match the live schema. This is a target-project data decision, out of scope for the OS migration framework.

### Category B — data/schema contract violation
| finding | output | detail | classification |
|---|---|---|---|
| F-B1 | boss_config | `boss_ready_rules[7].param_value = false` (boolean), but the schema requires `number` (the field doc says "bool uses 1/0") | contract violation: a boolean leaked where a number is required |

**Handoff target**: the target project's numeric/data owner. Narrowest fix = encode the boolean as 1/0 per the schema's own convention.

## Verdict

- **Pipeline mechanism**: healthy (proven by the idempotent + schema-valid tables).
- **Review capability**: functional (this report is its first real output).
- **Target-project data debt**: 5 drift tables + 1 contract violation — recorded here, routed to the target project's owners. NOT fixed here; NOT part of the B5 migration scope.
