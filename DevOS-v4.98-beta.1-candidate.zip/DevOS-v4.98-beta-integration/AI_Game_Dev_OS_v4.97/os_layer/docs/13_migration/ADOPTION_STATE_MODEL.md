---
title: Adoption State Model
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: 14.6
protected_invariants:
  - inv_003_state_machine_doc_schema_aligned
---

# Adoption State Model

> **Skeleton — v4.90 Batch 1**
> **Status**: state machine definition only; transition validators land in Batch 2.

## 9 Valid States

```
not_present       — capability fingerprint failed to match anything in the project
detected_legacy   — fingerprint matched a v4.82-style implementation
compatible        — legacy implementation is direct-compatible with target version
needs_adapter     — legacy implementation requires an adapter (matrix row says so)
adopting          — adoption is in progress (script invoked, not yet verified)
adopted           — adoption mechanically complete (yaml updated)
verified          — verification checks pass (matrix-defined required_checks)
blocked           — adoption blocked (human intervention required)
disabled          — explicitly opted out of adoption
```

## Transition Graph

```
                        ┌──────────────┐
                        │ not_present  │
                        └──────┬───────┘
                               │ scan
                               ↓
                  ┌─────────────────────┐
                  │  detected_legacy    │
                  └─────┬───────────────┘
                        │ matrix lookup
                        ├─────────────────────────┐
                        ↓                         ↓
              ┌────────────────┐         ┌─────────────────┐
              │  compatible    │         │  needs_adapter  │
              └────────┬───────┘         └────────┬────────┘
                       │                          │
                       └─────────┬────────────────┘
                                 ↓
                          ┌────────────┐
                          │  adopting  │
                          └─────┬──────┘
                                │ adopt_capability.py
                                ├──────────────────┐
                                ↓                  ↓
                          ┌────────────┐    ┌──────────┐
                          │  adopted   │    │ blocked  │
                          └─────┬──────┘    └──────────┘
                                │ verify_capability_adoption.py
                                ↓
                          ┌────────────┐
                          │  verified  │
                          └────────────┘

       ┌─────────────┐
       │  disabled   │  (opt-out from any state above except `verified`)
       └─────────────┘
```

## Transition Rules (skeleton — validators land in Batch 2)

| From | To | Allowed | Trigger |
| --- | --- | --- | --- |
| `not_present` | `detected_legacy` | yes | scan finds fingerprint |
| `detected_legacy` | `compatible` | yes | matrix says direct-compatible |
| `detected_legacy` | `needs_adapter` | yes | matrix says requires_adapter |
| `compatible` | `adopting` | yes | adopt_capability.py invoked |
| `needs_adapter` | `adopting` | yes | adopt_capability.py with adapter ref |
| `adopting` | `adopted` | yes | adoption script exits 0 |
| `adopting` | `blocked` | yes | adoption script returns ERROR |
| `adopted` | `verified` | yes | validate_capability_adoption.py passes |
| `*` | `disabled` | yes (except from `verified`) | explicit opt-out |
| `verified` | `*` | no | verified state is terminal |

## Schema

`schemas/protocol/capability_adoption_state.schema.json` validates per-capability
state declarations. Skeleton in Batch 1; full enum + transition guard in Batch 2.

## Layer Discipline

Layer 1 (OS Spec). No project names.
