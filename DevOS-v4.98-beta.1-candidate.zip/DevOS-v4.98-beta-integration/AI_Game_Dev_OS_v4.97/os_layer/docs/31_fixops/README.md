# FixOps Foundation

## Status

v4.93 docs-only foundation.

FixOps captures important development problems, verified fixes, repeated
patterns, self-evolution candidates, and memory-routing decisions so future
work can continue with evidence instead of stale narrative.

## What FixOps Is

FixOps is an evidence and review loop:

1. capture a concrete problem;
2. record the fix and validation;
3. distill repeated patterns only when evidence supports reuse;
4. hold self-evolution ideas as candidates only;
5. route validated knowledge to the smallest useful memory destination;
6. use the promotion pipeline before any versioned package change.

## What FixOps Is Not

FixOps does not:

- decide product scope or release go/no-go;
- bypass human owner, Executive Producer, Dev OS Architect, Evidence & Gate
  Lead, or affected pack owner approval;
- promote raw intake into package content automatically;
- create DB/RAG memory infrastructure;
- auto-merge self-evolution candidates;
- change Core, pack contracts, schemas, gates, or release behavior by itself.

## Package Boundary

This directory contains package-level operating docs and templates. It does not
include the `.dev_os_meta/` working cards, route decisions, proposals,
handoffs, or evidence ledgers.

Those meta records remain workspace maintenance evidence. Package changes still
require promotion review and validation.

## Contents

| File | Purpose |
|---|---|
| `fixops_card_workflow.md` | Problem/Fix/Pattern/Self-Evo card loop. |
| `fixops_steward.md` | FixOps Steward responsibility and non-authority boundary. |
| `memory_routing_policy.md` | Memory destination policy without DB/RAG implementation. |
| `intake_promotion_boundary.md` | Raw skill/agent intake classification and promotion boundary. |
| `coflow_gdd_game_design_absorption_plan.md` | Game-design agent/workflow intake absorption plan for CoFlow-style GDD flow. |
| `coflow_gdd_case_evidence.md` | Layer 2 case evidence behind CoFlow-style GDD workflow absorption. |
| `art_asset_pack_absorption_plan.md` | Art-agent/workflow absorption plan for the art asset pack. |
| `lessismore_art_case_evidence.md` | Layer 2 case evidence behind art direction / production workflow absorption. |
| `v4_93_capability_pre_closure_report.md` | v4.93 source-tree capability pre-closure scope, evidence, and deferred final-closure gates. |
| `v4_93_scoring_standard.md` | Shared scoring rubrics for OS framework quality, project adoption readiness, and autonomous production readiness. |
| `program_implementation_future_intake.md` | Deferred coding-discipline intake for future bounded source-edit pilot and beta-promotion review. |
| `templates/` | Package-ready card templates. |

## Operating Rule

Repository facts, tests, package files, schemas, and release evidence override
FixOps cards when they conflict. A card is evidence for review, not authority to
change the package.
