# CoFlow GDD Game Design Absorption Plan

## Status

Implemented absorption plan for v4.93.

This document records how the current AI Game Dev OS game-design pack absorbs
the useful parts of the CoFlow-style GDD workflow without creating a second,
conflicting agent ownership model.

The project-specific evidence behind this generic plan is isolated in
`coflow_gdd_case_evidence.md` as a Layer 2 case study. Do not copy project
names from that evidence file into pack contracts or Layer 1 capability tests.

DevPack exports, DevPack assignment manifests, and generated DevPack routing
artifacts are explicitly out of scope. They are treated as failed or stale
modules unless a human owner later promotes a specific artifact as current
source of truth.

Lifecycle decision: the absorbed design-data workflow is `beta`, not `draft`,
because it now has controlled-project evidence, a pack validator, boundary
lint coverage, practicality-gate coverage, and regression tests. It is not
`stable` because the workflow still needs more project-adoption runs before it
can be treated as broadly starter-ready.

## Current OS State

The current OS already has agent positioning.

The design side is represented by one production agent:

- `design_spec_author`
- primary pack: `design_data_pack`
- discipline: `game_design`
- current write boundary: `docs/specs/**`
- current ownership: game-design specification documents under `docs/specs`

The design pack currently provides spec-generation skills for:

- rough feature brief structuring;
- gameplay loop and flow;
- rules and constraints;
- acceptance criteria;
- combat rollout planning;
- GDD-to-spec delta conversion;
- idea-to-modular-GDD pipeline;
- design-agent role mapping;
- GDD contract consistency audit;
- UI information architecture, flow, screen structure, component specs,
  wireframes, HUD specs, card UI prefab specs, Figma handoff specs, and
  design-system rules;
- numeric id planning and data-config layering.

The important structural fact is that OS production agents own artifacts and
write boundaries. CoFlow roles are narrower professional viewpoints inside a
workflow. They should not be copied directly into `packs/**/agents/*.json`
unless they have stable ownership, write scope, validation responsibility,
handoff triggers, and completion evidence.

## CoFlow Source Capabilities

The source workflow exposes three useful capability groups.

### 1. Whole-GDD Generation Flow

The main flow generates and refines a staged GDD:

| Stage | Source role | Source artifact | Absorption target |
| --- | --- | --- | --- |
| optional reference analysis | Expert Benchmark Analyst | `0_Reference_Game_Analysis.md` | reference analysis section in modular GDD pipeline |
| optional gameplay extraction | Chief Gameplay Synthesizer | `0_5_Gameplay_Extraction.md` | gameplay extraction / fit-nonfit decision section |
| optional user persona | User Research Strategist | `0_User_Persona.md` | user analysis section |
| design contract | Design Contract Architect | `0_Design_Contract.md` | design contract source-of-truth section |
| concept | Senior Concept Designer | `1_Concept.md` | concept module |
| world/theme | Senior Narrative Director | `2_World.md` | world/theme module |
| mechanics | Senior Systems Designer | `3_Mechanics.md` | mechanics / systems module |
| game mode | Senior Game Mode Designer | `4_Game_Mode.md` | game mode module |
| numeric design | Senior Numeric Designer | `5_Numeric_Design.md` | numeric / balance module |
| UI layout | Senior UI/UX Designer | `6_UI_Layout.md` | UI layout / IA / flow module |
| text asset spec | Senior Art Production Manager | `7_Text_Assets.md` | art-facing text asset handoff section |
| GDD review | Design Director + Executive Producer | `7_5_GDD_Review.md` or accepted-baseline provenance | conditional GDD review gate, accepted-baseline record, and downstream rewrite plan |

The source also generates brief documents after major steps through
Documentation Distiller. This is useful as an interface-summary pattern:
long GDD sections should emit concise downstream interface summaries, not just
full prose.

In project-internal usage, a standalone `7_5_GDD_Review.md` may be intentionally
absent when the modular GDD files are already accepted reviewed baselines. In
that case the OS workflow should record review provenance and downstream
readiness instead of fabricating a new final review artifact.

### 2. Review and Gate Flow

The source review step uses two viewpoints when a new or unapproved GDD package
needs a gate:

- Design Director checks design consistency, logic chain, and player fit.
- Executive Producer checks production feasibility, scope risk, delivery gate,
  blocker count, and Go / Conditional Go / No-Go conclusion.

This should be absorbed as a conditional review workflow inside
`design_data_pack`, not as two new production agents yet. The OS equivalent
should produce a review report for new or unapproved packages, or an
accepted-baseline summary for already reviewed project-internal packages.

For a new or unapproved package, the output should include:

- severity-ordered findings;
- blocker count;
- file/module-level rewrite recommendations;
- gate conclusion;
- downstream handoff notes.

For an accepted project-internal baseline, the output should include:

- accepted-baseline provenance;
- which GDD modules are treated as reviewed sources;
- known review assumptions;
- intentional omissions such as a removed final review artifact;
- downstream handoff notes.

The current `gdd_contract_consistency_audit_skill` covers contract drift. The
dual-viewpoint review gate is absorbed as `gdd_review_gate_skill`, with support
for either a new `gdd_review_gate` report or accepted-baseline provenance.

### 3. Intent-Driven Targeted Refinement

The source refine chain uses:

- Intent Alignment Analyst: locate sections that must or should change.
- Targeted Refine Editor: rewrite only selected sections.
- Intent QA Reviewer: verify whether the revised document satisfies the user
  intent and list missing requirements.

This is absorbed as a standalone design-data skill because it solves a real GDD
drift problem: whole-document rewrites can erase constraints. The OS version
produces a spec delta / refine report instead of silently mutating unbounded
documents.

Skill:

- `gdd_targeted_refine_skill`

Expected artifact:

- `docs/specs/<topic>_gdd_refine_delta.md`

Required sections:

- source document and target section ids;
- user intent;
- must-change / should-change / keep classification;
- acceptance checks;
- proposed rewrites or rewrite instructions;
- validation result;
- remaining missing requirements.

## Absorption Principles

### Principle 1: Production Agent Ownership Stays OS-Native

Keep `design_spec_author` as the sole design production agent for v4.93 unless
future evidence proves a finer split is needed.

Reason: splitting now would create overlapping ownership over `docs/specs/**`.
The current agent contract model treats duplicate canonical ownership as a
boundary problem.

### Principle 2: CoFlow Agents Become Source Roles First

CoFlow professional roles should be absorbed into a source role inventory and
mapped into capability roles:

- source role name;
- source goal;
- source artifact;
- normalized capability role;
- authority boundary;
- required inputs;
- required outputs;
- handoff triggers;
- source-role lineage.

This is already aligned with `design_agent_role_mapping_skill`.

### Principle 3: Workflow Becomes Skill Execution, Not Runtime Routing

The source runtime route labels (`coflow-workflow`, `dev-agent`,
`planner-agent`) are not OS production agents.

They are useful only as evidence that:

- mechanics and numeric stages are higher-risk design/system stages;
- review and asset-list gates need stronger planning/governance;
- later stages should depend on earlier artifacts.

They should not be imported as agent ids.

### Principle 4: Design Contract Is the Source of Truth

The design contract should sit before concept expansion and should be reused by
every downstream module. Later module text that contradicts the contract is
drift, not an implicit contract update.

This is already represented by `gdd_contract_consistency_audit_skill`, but the
modular pipeline should also require every module to cite the contract
constraints it depends on.

### Principle 5: Art, Program, and QA Stay Separate

The text asset stage can describe art-facing needs, but production of final art
assets belongs to `art_asset_pack`.

Engine implementation belongs to a program or engine adapter pack.

Validation execution belongs to `qa_validation_pack`.

Design can specify and hand off; it should not implement out of bounds.

## Recommended Target Workflow

The OS-side workflow should be:

1. `idea_intake`
   - Input: rough idea, constraints, target platform, project phase.
   - Output: confirmed facts, assumptions, missing decisions.

2. `source_role_inventory`
   - Input: concrete source workflow roles if available.
   - Output: source concrete role inventory.
   - Skill: `design_agent_role_mapping_skill`.

3. `user_and_reference_analysis`
   - Input: idea, optional references, optional persona hints.
   - Output: user analysis, reference analysis, gameplay extraction.
   - Skill: `idea_to_modular_gdd_pipeline_skill`.

4. `design_contract`
   - Input: idea, user analysis, reference analysis, confirmed constraints.
   - Output: design contract with pillars, core loop, business model,
     platform, exclusions, style boundaries, numeric red lines, and success
     criteria.

5. `module_map_and_role_map`
   - Input: design contract.
   - Output: module map and role map with source-role lineage.
   - Skill: `design_agent_role_mapping_skill`.

6. `modular_gdd_authoring`
   - Output modules: concept, world/theme, mechanics, game modes, numeric
     design, UI layout, text asset handoff.
   - Every module records confirmed facts, assumptions, open decisions,
     downstream consumers, and contract dependencies.

7. `brief_distillation`
   - Output: interface summaries for each major module.
   - Skill: `gdd_brief_distillation_skill`.

8. `gdd_review_gate`
   - Output: review report with severity, blocker count, gate conclusion,
     rewrite plan, and handoff notes, or accepted-baseline summary when the
     source GDD has already been reviewed.
   - Skill: `gdd_review_gate_skill`.

9. `contract_consistency_audit`
   - Output: confirmed facts, drift findings, open decisions, spec deltas.
   - Skill: `gdd_contract_consistency_audit_skill`.

10. `gdd_to_spec_delta`
    - Input: reviewed GDD module, accepted-baseline module, or audit result.
    - Output: implementation-facing spec delta.
    - Skill: `gdd_to_spec_skill`.

11. `gdd_to_art_manifest_handoff`
    - Input: reviewed or accepted-baseline GDD modules with art-facing
      requirements.
    - Output: minimal art-facing manifest with asset type, name, visual tags,
      source GDD section, and acceptance notes.
    - Skill: `gdd_to_art_manifest_handoff_skill`.

12. `targeted_refine`
    - Input: user refine intent and selected GDD/spec docs.
    - Output: targeted refine delta and acceptance result.
    - Skill: `gdd_targeted_refine_skill`.

Every workflow completion report should preserve progress evidence fields:
step, status, risk, artifact files, artifact score, artifact issues, and
completed snapshot. These fields are completion evidence for pack-layer
workflow, not runtime routing agents.

## Agent Promotion Recommendation

Do not immediately add production agents for every CoFlow role.

Recommended state for v4.93:

| CoFlow role family | OS representation now | Future promotion condition |
| --- | --- | --- |
| concept / contract / user research / reference analysis | workflow roles inside design_data skills | promote only if distinct artifact ownership is needed |
| systems / game modes / numeric / UI | workflow roles plus existing design_data skills | promote only after `docs/specs/**` ownership can be narrowed |
| art production manager | design handoff role only | do not promote inside design; hand off to art pack |
| design director / executive producer review | conditional review workflow role | promote to validator only if review reports or accepted-baseline evidence get a separate path/owner |
| documentation distiller | `gdd_brief_distillation_skill` workflow role | promote only if brief ownership gains a separate path and validator |
| intent refine analyst/editor/QA | `gdd_targeted_refine_skill` workflow roles | promote only if refine gains a separate path, validator, and handoff contract |

If future promotion is needed, the first safe split is not by job title. It is
by artifact boundary:

- `gdd_pipeline_author`: owns modular GDD packages under a narrowed path.
- `design_review_validator`: owns GDD review/audit reports under a narrowed
  path.
- `design_spec_author`: keeps implementation-facing specs.

That split requires changing current ownership from broad `docs/specs/**` to
more specific subpaths first. Until then, new production agents would overlap.

## Conflict Rules

1. `agent_contract` and `capability_pack` ownership overrides source workflow
   roles.
2. Skill contracts override imported source role wording.
3. CoFlow concrete agents are evidence and lineage, not authority.
4. DevPack material is excluded unless explicitly promoted.
5. A source role that crosses design/art/program/QA must be split into design
   specification plus handoff, not executed inside design_data.
6. A GDD module without a primary owner is reported as unassigned instead of
   guessed.
7. Assumptions must remain assumptions until approved by a human or lead role.
8. GDD review findings and accepted-baseline assumptions become rewrite
   requests, provenance notes, or spec deltas; they do not silently rewrite the
   design contract.

## File-Level Absorption Plan

Aligned in v4.93:

- `packs/game_system_packs/design_data/skills/idea_to_modular_gdd_pipeline_skill.json`
- `packs/game_system_packs/design_data/skills/design_agent_role_mapping_skill.json`
- `packs/game_system_packs/design_data/skills/gdd_review_gate_skill.json`
- `packs/game_system_packs/design_data/skills/gdd_brief_distillation_skill.json`
- `packs/game_system_packs/design_data/skills/gdd_targeted_refine_skill.json`
- `packs/game_system_packs/design_data/skills/gdd_to_art_manifest_handoff_skill.json`
- `packs/game_system_packs/design_data/skills/gdd_contract_consistency_audit_skill.json`
- `packs/game_system_packs/design_data/agents/design_spec_author.json`
- `tests/capability/test_design_data_pack.py`

Additional follow-up candidate:

1. Optionally add a template reference for modular GDD packages.
   - Keep it engine-agnostic.
   - Include required sections for confirmed facts, assumptions, open
     decisions, contract dependencies, downstream consumers, and validation
     notes.

## Validation Plan

For changed contracts:

1. Validate new skill JSON with `python3 -m json.tool`.
2. Run practicality gate for each new skill.
3. Run boundary linter on design_data manifest, agent, and new skills.
4. Keep `tests/capability/test_design_data_pack.py` asserting every absorbed
   skill is listed, practical, and preserves the intended boundary.
5. Run:
   - `python3 -m pytest tests/capability/test_design_data_pack.py`
   - `python3 -m pytest tests/capability/test_godot_2d_pack.py tests/capability/test_pack_adoption_tools.py`
   - `python3 scripts/governance/lint_layer_separation.py`

Release manifest and checksums should remain a separate packaging step.

## Decision

Absorb CoFlow game-design capability as pack-layer workflow and skill
contracts first.

Do not copy CoFlow agents as production agents now.

Do not use DevPack as evidence.

The current v4.93 direction is coherent with the absorbed workflow skills:
conditional GDD review / accepted-baseline gate, brief distillation, targeted
refine, and GDD-to-art manifest handoff.
