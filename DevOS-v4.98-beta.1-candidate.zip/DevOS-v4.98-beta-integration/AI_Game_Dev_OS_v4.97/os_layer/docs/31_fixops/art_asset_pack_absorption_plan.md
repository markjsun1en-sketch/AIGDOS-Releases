# Art Asset Pack Absorption Plan

## Status

Draft absorption plan for v4.93.

This document records how the current AI Game Dev OS art pack should absorb the
useful art-agent, skill, and workflow patterns found in the inspected project
art pipeline. Project-specific evidence stays in
`lessismore_art_case_evidence.md` as Layer 2 case evidence. Layer 1 pack
contracts, tests, validators, and schemas must not contain concrete project
names.

The current `art_asset_pack` is still `draft`. The absorption target is a
controlled `beta` pack only after the contracts, validator, boundary checks, and
tests are implemented.

## Current OS State

The current OS art side has one production agent:

- `art_asset_preparer`
- primary pack: `art_asset_pack`
- discipline: `art`
- status: `draft`
- current write boundary: `docs/art_specs/**`, `assets/staging/**`

The current pack already lists useful art skills, including concept prompts,
asset batch planning, variation control, breakdown, cleanup, and export
packaging. The gap is not naming. The gap is that the pack does not yet encode
the mature direction-to-production workflow, source-review boundaries, evidence
schemas, or the two stable art role boundaries proven by project evidence.

## Absorption Thesis

Unlike the GDD/design absorption, the art evidence supports splitting the art
pack into two pack-layer production agents once implementation starts.

The split is not by job title. It is by artifact boundary:

| Boundary | Production agent target | Stable owned artifacts |
| --- | --- | --- |
| visual direction, style lock, source-review, art consistency review | `art_direction_author` | direction packs, style locks, source-review reports, review findings under `docs/art_specs/direction/**` and `docs/art_specs/reviews/**` |
| technical asset preparation, cleanup, packaging, runtime-candidate manifesting | `art_asset_preparer` | production package specs, cleanup reports, manifests, staged assets under `docs/art_specs/production/**` and `assets/staging/**` |

Final aesthetic signoff remains a human / lead review authority. A production
agent may produce a review report and provisional verdict, but it must not claim
final human acceptance.

## Why This Can Split Now

A CoFlow or project role should become a pack-layer production agent only when
it has a stable write boundary, stable artifact ownership, validation
responsibility, and handoff conditions.

The art evidence satisfies that threshold for two boundaries:

1. Direction boundary:
   - writes direction packs, source-review briefs, style drift review, visual
     acceptance notes;
   - validates style alignment, readability, stage fit, and production
     feasibility;
   - hands off accepted direction to production, or escalates to human / lead
     review.

2. Production boundary:
   - writes cleaned runtime candidates, manifests, cleanup reports, preview or
     contact sheets, and package notes;
   - validates dimensions, alpha, bbox, padding, hashes, import readiness, and
     manifest completeness;
   - hands off to engine adapter / program pack for runtime binding and to QA
     for screenshot or smoke evidence.

Keeping both inside a single broad `art_asset_preparer` hides useful gate
conditions and makes it too easy for a production step to proceed before visual
direction is accepted.

## Target Agent Roster

Recommended v4.93 implementation state:

| Agent | Layer | Status target | Writes | Must not do |
| --- | --- | --- | --- | --- |
| `art_direction_author` | production_agent | beta | `docs/art_specs/direction/**`, `docs/art_specs/reviews/**` | final human signoff, cleanup/export packaging, engine binding |
| `art_asset_preparer` | production_agent | beta | `docs/art_specs/production/**`, `assets/staging/**` | visual direction authority, final art signoff, engine binding |

`art_lead` remains an escalation / approval authority, not a new pack-owned
execution agent unless a separate control-plane contract exists.

## Workflow To Absorb

The target workflow is:

1. `art_intake`
   - Input: design brief, GDD-to-art manifest handoff, UI component brief, or
     gameplay art need.
   - Output: confirmed facts, asset purpose, target runtime slot, phase, and
     missing decisions.

2. `art_readiness_gate`
   - Checks whether current accepted placeholders, manifests, runtime bindings,
     and known gaps are sufficient for the next batch.
   - Output: readiness report with current source of truth, gap list, warnings,
     and next gate.

3. `visual_direction_pack`
   - Defines semantic role, style lock, visual priority, forbidden drift,
     size/source targets, state needs, z-order/layering intent, failure
     conditions, and minimum production batch.
   - Owner: `art_direction_author`.

4. `source_review_generation`
   - Produces or curates source-review images only.
   - Source-review outputs must not be bound directly into runtime.
   - Owner: `art_direction_author` for creative direction; `art_asset_preparer`
     may assist only after a production-safe source route is approved.

5. `art_consistency_review`
   - Verdict: `pass`, `conditional_pass`, `revise`, or `reject`.
   - Checks style drift, readability, stage fit, production feasibility, and
     downstream risk.
   - Final human acceptance is still outside this skill.

6. `asset_batch_planning`
   - Splits work into reviewable batches with dependencies, objectives,
     review checkpoints, and packaging expectations.

7. `asset_production_cleanup`
   - Runs deterministic cleanup or cutout when possible.
   - Records dimensions, alpha bbox, trim, residue counts, preview paths, and
     cleanup method.

8. `runtime_candidate_packaging`
   - Produces staged package outputs, manifest, cleanup report, preview/contact
     sheets, and rollback note.
   - Maintains source-review vs runtime-candidate separation.

9. `engine_binding_handoff`
   - Hands off manifest and runtime candidates to the engine adapter or program
     pack.
   - The art pack does not edit engine resources, import presets, scenes, or
     runtime code.

10. `qa_visual_capture_gate`
    - QA or engine adapter captures runtime evidence.
    - Art Direction reviews screenshots for visual correctness, while QA owns
      validation execution.

11. `human_or_lead_acceptance`
    - Human / lead accepts, rejects, or requests bounded refine.
    - Production agent records provenance but does not self-sign final art.

## Skills To Add Or Extend

### Direction and Review Skills

Add:

- `art_direction_pack_skill`
  - outputs direction pack, asset-slot list, failure conditions, and review
    screenshot requirements.
- `art_readiness_gate_skill`
  - outputs current source of truth, placeholder/candidate status, gap list,
    and next gate.
- `art_source_review_skill`
  - enforces source-review-only boundaries, prompt constraints, rejection
    reasons, and no direct runtime binding.
- `art_consistency_review_skill`
  - imports the existing review structure: style alignment, batch consistency,
    readability, stage fit, production feasibility, severity-ranked revision
    guidance.

Extend:

- `art_concept_from_design_brief_skill`
  - require source-review state and explicit acceptance owner when concept
    generation produces images.
- `asset_batch_planning_skill`
  - require review checkpoints and packaging gates.
- `asset_variation_control_skill`
  - require locked dimensions, allowed variation axes, forbidden drift areas,
    and review checks.

### Production Skills

Add:

- `art_asset_state_registry_skill`
  - normalizes states such as `SPEC_ONLY`, `SOURCE_REVIEW`, `REVIEW_NEEDED`,
    `CLEANED_READY`, `RUNTIME_CANDIDATE`, `ACCEPTED_PLACEHOLDER`,
    `TEMP_RUNTIME_BOUND_REVIEW_NEEDED`, `PROD_DONE`, `REJECTED`, and
    `BLOCKED`.
- `art_manifest_evidence_skill`
  - standardizes manifest evidence fields.
- `image2_actor_runtime_asset_pipeline_skill`
  - source-review actor generation, green-screen fallback, alpha cleanup,
    alpha bleed/despill, trim-to-alpha-bbox, preview QA, and report.
- `battle_scene_plate_generation_skill`
  - no-UI 16:9 scene plate source-review workflow.
- `battle_scene_plate_runtime_prep_skill`
  - accepted scene plate upscaling / resize / runtime-candidate reporting.
- `ui_component_source_package_skill`
  - component-specific source targets, 9-slice margins, content-safe rects,
    state variants, and runtime-owned-content notes.

Extend:

- `image_cleanup_pipeline_skill`
  - require backup checkpoints, alpha-only local touchups, trim report, and
    residue stats for character/actor assets.
- `engine_export_packaging_skill`
  - require manifest, rollback note, hash/dimension evidence, and explicit
    handoff to engine adapter.
- `asset_breakdown_for_engine_skill`
  - require runtime slot, expected dimensions, alpha requirement, pivot/anchor
    or full-rect rules, and downstream owner.

## Generic Evidence Contracts

### Direction Pack Minimum Fields

- purpose and scope;
- upstream source of truth;
- direction boundary;
- semantic role;
- visual priority;
- style lock or style seed;
- allowed and forbidden drift;
- source dimensions and runtime target dimensions;
- state variants;
- layering / z-order intent;
- minimum production batch;
- QA / human review points;
- failure conditions;
- residual decisions.

### Manifest Minimum Fields

- package or batch id;
- status;
- owner;
- created date;
- source direction pack;
- source-review boundary;
- human / lead acceptance provenance when present;
- prototype / MVP / production boundary;
- output root;
- asset entries with:
  - asset id;
  - role or type;
  - source-review path when applicable;
  - runtime-candidate path;
  - intended engine path or downstream owner;
  - expected and actual dimensions;
  - alpha requirement and alpha validation;
  - bbox and padding validation;
  - pivot / anchor when relevant;
  - runtime target;
  - z-index or layer intent when relevant;
  - hash;
  - validation state;
  - notes and residual risks.

### Cleanup Report Minimum Fields

- input path;
- output path;
- method / script used;
- source dimensions;
- output dimensions;
- alpha bbox;
- trim applied;
- transparent RGB residue stats when relevant;
- semi-transparent edge residue stats when relevant;
- preview paths;
- rollback or backup path;
- residual risks.

### Review Report Minimum Fields

- target and stage expectation;
- source brief / direction pack reference;
- representative outputs or screenshots;
- verdict;
- style drift findings;
- readability findings;
- stage-fit findings;
- production feasibility findings;
- severity-ranked revision guidance;
- downstream recommendation;
- final human / lead acceptance state.

## Promotion Plan

Recommended file-level implementation:

1. Add `art_direction_author.json`.
2. Narrow `art_asset_preparer.json` write boundary to production package and
   staging paths.
3. Update `art_asset_pack/capability_pack.json`:
   - lifecycle remains `draft` until all checks pass;
   - after implementation and validation, promote to `beta`;
   - add both production agents;
   - add new skills;
   - update collision policy with non-overlapping paths.
4. Add `scripts/capability/validate_art_asset_pack.py`.
5. Add `tests/capability/test_art_asset_pack.py`.
6. Add Layer 2 evidence doc and keep project names out of pack/test/validator
   files.

## Validation Plan

For implementation:

1. Validate all agent, skill, and manifest JSON with existing schemas.
2. Run practicality gate on all new or changed art skills.
3. Run boundary linter on the art pack manifest, agents, and skills.
4. Add validator checks:
   - art pack lifecycle target is `beta` after absorption;
   - two production agents exist with non-overlapping write paths;
   - final human signoff is not claimed by production agents;
   - source-review outputs cannot be runtime-bound directly;
   - manifest evidence fields exist;
   - cleanup report and rollback evidence are required for packaging skills;
   - engine binding is a handoff, not an art-pack write.
5. Run layer separation lint to ensure project names do not leak into Layer 1.
6. Extend adoption tests so `art_asset_pack` becomes eligible only after beta
   promotion.

## Case Evidence To Use

Positive evidence:

- accepted placeholder package with manifest and review artifacts;
- readiness gate before production batch;
- human-accepted direction pack with asset slots and failure conditions;
- candidate asset batch with deterministic generator, manifest, cleanup report,
  import evidence, and QA smoke;
- actor runtime candidate batches with cutout reports, preview review, residue
  stats, rejection evidence, and source-route correction;
- UI component packages with content-safe, 9-slice, and state-variant manifest
  needs.

Negative evidence:

- source-review images generated through an unapproved route were rejected even
  when technical cutout passed;
- simplified drawing / icon-sketch outputs passed some runtime plumbing but
  failed human visual acceptance;
- stale source dimensions blocked production despite otherwise mature briefs;
- broad folder scans and stale files are risky; active manifests must define
  authority.

## Decision

Absorb the project art pipeline as a two-boundary art pack:

- `art_direction_author` for visual direction and review artifacts;
- `art_asset_preparer` for technical production, staging, manifest, and
  cleanup artifacts.

Promote `art_asset_pack` to `beta` only after the above contracts and tests are
implemented. Do not treat any current or future production agent as final human
art signoff authority.
