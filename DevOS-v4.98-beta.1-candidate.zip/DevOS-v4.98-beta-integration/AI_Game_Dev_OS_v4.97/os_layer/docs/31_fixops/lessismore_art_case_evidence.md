---
title: Lessismore Art Case Evidence
version: 1.0
status: active
layer: layer_2_case_study
since_batch: B11
---

# Lessismore Art Case Evidence

> **Layer 2 case study.** This file may name the concrete project and source
> directories. It is evidence behind the generic art pack absorption plan, not
> a Layer 1 contract. Any reusable rule must be re-expressed in project-name-free
> form before it enters `packs/**`, `tests/capability/**`, or validators.

## Scope

Evidence roots inspected:

- `/Users/macsun/lessismore/AGENTS.md`
- `/Users/macsun/lessismore/skills`
- `/Users/macsun/lessismore/art`
- `/Users/macsun/lessismore/Docs/Tasks`
- `/Users/macsun/lessismore/logs`
- `/Users/macsun/lessismore/tools/art`

`__pycache__` content was intentionally ignored.

## Reproduction Commands

```bash
sed -n '619,829p' /Users/macsun/lessismore/AGENTS.md
```

```bash
find /Users/macsun/lessismore/skills -maxdepth 3 -type f \
  \( -name 'SKILL.md' -o -name '*.md' \) | sort
```

```bash
find /Users/macsun/lessismore/art -maxdepth 4 -type f \
  \( -name '*.md' -o -name '*.json' -o -name '*.png' \
     -o -name '*.jpg' -o -name '*.jpeg' -o -name '*.webp' \) \
  | sort
```

```bash
find /Users/macsun/lessismore/logs/handoffs -maxdepth 2 -type f \
  \( -iname '*art*' -o -iname '*visual*' -o -iname '*style*' \
     -o -iname '*asset*' -o -iname '*sp119*' \) | sort
```

## Agent Boundary Evidence

`AGENTS.md` defines two mature art boundaries:

| Project role | Observed boundary | Generic absorption |
| --- | --- | --- |
| Art Direction Agent | Defines style lock, Visual Direction Pack, visual source images, source-review, style drift review, and human review material. It does not own cleanup, cropping, batch packaging, runtime naming, or engine mapping. | Promote to `art_direction_author` production agent for direction/review artifacts, not final human signoff. |
| Art Production Agent | Receives Art Direction outputs, runs asset breakdown, image cleanup, engine export packaging, manifest generation, and delivery handoff. It does not define visual direction, final style verdict, runtime binding, or engine import preset wiring. | Keep / narrow `art_asset_preparer` as technical production agent. |

This supports splitting the current single OS art agent once the pack is
implemented.

## Skill Evidence

Observed reusable project skills:

- `art_concept_from_design_brief`
- `art_consistency_review`
- `asset_batch_planning`
- `asset_variation_control`
- `asset_breakdown_for_engine`
- `image_cleanup_pipeline`
- `engine_export_packaging`
- `image2_actor_runtime_asset_pipeline`
- `image2_battle_scene_plate_generation`
- `battle_scene_plate_upscayl_runtime_prep`

Reusable rules:

- source-review images are not runtime assets;
- scene plates, actors, icons, shadows, and UI components need different
  cleanup and sizing rules;
- deterministic cleanup / export scripts are preferred for production evidence;
- Human / Art Direction acceptance is separate from technical packaging pass.

## Asset Requirement Evidence

`art/asset_requirements.md` records a useful art asset planning model:

- status taxonomy: `SPEC_ONLY`, `TEMP_REF`, `CLEANED_READY`, `PROD_DONE`,
  `BLOCKED`, plus accepted placeholder variants;
- style anchor tiers;
- prompt and generation anti-patterns;
- asset dimensions, runtime purpose, target path, and current status;
- batch sequencing;
- manifest references;
- explicit rule that accepted placeholder does not equal final art lock.

Generic absorption:

- add an art asset state registry skill;
- require source of truth, status, path, dimensions, style anchor, and next
  gate in art package planning.

## Readiness Gate Evidence

`SP-113-FB-08 Art Polish Readiness Report` shows a readiness gate before
starting final asset production.

Observed fields:

- current accepted placeholder package;
- manifest and engine-facing assets;
- runtime data binding;
- current code-drawn placeholders;
- QA tool and summary JSON;
- validated asset counts, dimensions, import files, and binding mismatches;
- final asset gaps;
- direction boundary;
- evidence commands and warnings.

Generic absorption:

- add `art_readiness_gate_skill`;
- require source-of-truth, manifest readiness, gap list, warnings, and next
  direction gate.

## Direction Pack Evidence

`SP-113-FB-08B Final Art Direction Pack` turns readiness gaps into production
brief material.

Observed fields:

- purpose and upstream inputs;
- direction boundary;
- visual priority;
- semantic role;
- visual scheme;
- z-order / layering intent;
- runtime size recommendation;
- state needs;
- replacement asset slots;
- QA / human review points;
- failure conditions;
- residual decisions.

Generic absorption:

- add `art_direction_pack_skill`;
- require direction packs before production batches when visual direction is
  not already accepted.

## Candidate Batch Evidence

`SP-113-FB-08C Candidate Asset Batch Report` and its manifest prove a
production package pattern:

- direction pack and human acceptance provenance;
- deterministic generator;
- candidate PNG assets;
- manifest;
- cleanup report;
- Godot import evidence;
- QA smoke;
- residual review-needed state.

Manifest fields observed:

- manifest schema;
- batch id;
- status;
- owner;
- created date;
- world / runtime code;
- output root;
- source direction pack;
- human acceptance handoff;
- prototype boundary;
- asset entries with asset id, role, file, source file, width, height,
  alpha, hash, notes.

Generic absorption:

- add `art_manifest_evidence_skill`;
- require manifest, cleanup report, hash/dimensions, and handoff evidence for
  production packaging.

## Actor Runtime Candidate Evidence

SP-119 actor batches show a stricter actor-specific pipeline:

- source-review images are saved separately;
- runtime candidates are retained only after cutout;
- reports record size, alpha bbox, trim applied, transparent greenish RGB
  pixels, and semi-transparent greenish pixels;
- preview sheets are inspected on checker, gray, and dark backgrounds;
- rejected batches stay as technical evidence and failure references.

Negative evidence:

- a technically clean cutout batch was rejected because the source route,
  pose lock, facing, and normal-enemy detail density failed the art brief.

Generic absorption:

- add `image2_actor_runtime_asset_pipeline_skill`;
- do not let technical cleanup success bypass source-route or art-direction
  review gates.

## Scene Plate Evidence

The battle scene plate skills distinguish source-review background generation
from runtime preparation:

- no UI, text, characters, enemies, cards, labels, or props in scene plates;
- source-review outputs are not runtime-bound directly;
- accepted scene plates may be upscaled to 3840x2160;
- forced 3840x2160 is scene-plate-only and should not be applied to actors,
  shadows, icons, or cards.

Generic absorption:

- add `battle_scene_plate_generation_skill`;
- add `battle_scene_plate_runtime_prep_skill`;
- require acceptance provenance before scene-plate runtime prep.

## UI Component Evidence

SP-119 UI component work shows an additional packaging need:

- component-specific source targets;
- state variants;
- suggested 9-slice margins;
- content-safe rects;
- runtime-owned content notes;
- contact sheets and runtime review candidates;
- repeated warnings not to crop or atlas foundation sheets directly.

Generic absorption:

- add `ui_component_source_package_skill`;
- require component-specific manifests for UI surfaces.

## Implementation Cross-Check

The evidence supports these future v4.93 changes:

- add `art_direction_author`;
- keep and narrow `art_asset_preparer`;
- add or extend art direction, source review, consistency review, state
  registry, manifest evidence, scene plate, actor pipeline, and UI component
  source package skills;
- add `validate_art_asset_pack.py`;
- promote `art_asset_pack` from `draft` to `beta` only after validation and
  tests pass.

It also supports these negative decisions:

- do not let Art Production self-sign final art acceptance;
- do not runtime-bind `source_review/` images;
- do not treat technical cutout success as art acceptance;
- do not include project names in Layer 1 art pack contracts.
