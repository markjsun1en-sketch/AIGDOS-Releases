# Program Implementation Future Intake

## Status

Deferred future-version intake for `program_implementation_pack`.

This note records candidate guidance for a future pilot or beta-promotion
review. It does not change the current v4.93 pre-closure scope and does not
promote `program_implementation_pack` out of `draft`.

## Candidate Source

Raw intake source:

`/Users/macsun/Documents/githubaiproject/andrej-karpathy-skills`

Relevant content:

- `skills/karpathy-guidelines/SKILL.md`
- `README.md`
- `EXAMPLES.md`

Do not copy the Claude/Cursor/plugin packaging into the OS package. The useful
candidate is the coding discipline, not the external plugin wrapper.

## Absorption Direction

The candidate should be reviewed as implementation discipline for bounded
source edits:

1. surface assumptions before writing code;
2. prefer the minimum implementation that satisfies the accepted plan;
3. keep changes surgical and traceable to the task;
4. define success criteria and validate with tests or explicit commands.

Potential targets:

- `program_architecture_pack` implementation-plan skill inputs;
- `program_implementation_pack` bounded source patch discipline;
- `program_implementation_pack` validator negative cases;
- QA handoff evidence requirements for source edits.

## Non-Goals

This intake must not:

- create a new production agent;
- bypass `program_architecture_pack` accepted-plan requirements;
- bypass project-resolved `source_write_root` and `test_write_root`;
- make `program_implementation_pack` project-adoptable by itself;
- serve as beta evidence without real project source-edit tasks;
- copy external install instructions or tool-specific wrapper files into
  Layer 1 capability contracts.

## Future Beta-Promotion Use

When `program_implementation_pack` enters a project pilot, evaluate whether to
turn this discipline into a concrete skill or validator rule such as
`bounded_source_patch_discipline`.

The pilot evidence still needs real project artifacts:

- accepted implementation plan;
- changed source/test files inside resolved write roots;
- implementation delta;
- validation command and result;
- rollback note;
- QA handoff closure;
- FixOps capture for failures or repeated patterns.

Only after repeated bounded source-edit evidence should this intake be used to
support beta promotion.
