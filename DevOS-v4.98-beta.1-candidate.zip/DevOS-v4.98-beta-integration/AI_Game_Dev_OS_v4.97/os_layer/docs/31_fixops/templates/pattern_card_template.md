# Pattern Card: <Title>

## Card Metadata

- `pattern_id`: `PAT-YYYY-MM-DD-NNN`
- `source_problem_ids`:
- `source_fix_ids`:
- `pattern_type`: failure mode, anti-pattern, recurring workflow gap,
  evidence gap, authority gap, tool gap, pack boundary gap, or intake
  absorption gap
- `confidence`: low, medium, or high
- `status`: observed, confirmed, mitigated, solved, deprecated, or rejected

## Pattern

<What repeats, or what high-blast-radius lesson should be preserved?>

## Trigger Conditions

- <When this pattern appears.>

## Distilled Lesson

<Reusable lesson, separated from local details.>

## Recommended Response

<What should be checked or done next time?>

## Applicability Scope

- project
- OS
- pack
- tool
- workflow
- release
- governance

## Counterexamples

<When this pattern should not be applied.>

## Required Next Evidence

<What would raise confidence or disprove this pattern?>

## Promotion Candidate

- docs
- schema
- gate
- skill
- tool
- memory
- pack contract
- none
