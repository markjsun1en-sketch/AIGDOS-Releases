# Fix Card: <Title>

## Card Metadata

- `fix_id`: `F-YYYY-MM-DD-NNN`
- `problem_id`: `P-YYYY-MM-DD-NNN`
- `owner`: <single responsible role>
- `status`: proposed, implemented, validated, reverted, deferred, or rejected
- `memory_routing`: Project LTM, OS LTM, Pack Memory, Tool Memory,
  Self-Evo Queue, no_memory, or needs_memory_review
- `review_routing`: os_layer, pack_layer, reference_only, reject_archive, or
  deferred_future_version, if applicable

## Change Summary

<What changed or what response is proposed?>

## Changed Artifacts

- `<path or artifact>`

## Validation

Validation method:

- `<command, test, manual review, artifact comparison, or gate>`

Validation result:

- `verified`, `partially_verified`, `unverified`, or `rejected`

Unverified areas:

- `<what was not checked>`

## Evidence After

- `<after-evidence>`

## Side Effects

<Known side effects, tradeoffs, or follow-up risks.>

## Rollback Or Deferral Path

<How to revert, defer, or contain the change.>

## Lead Or Gate Verdict

- Dev OS Architect:
- Evidence & Gate Lead:
- Affected pack owner:
- Human owner:

## Follow-Up Candidates

- Pattern Card:
- Self-Evo Candidate:
- Promotion proposal:
