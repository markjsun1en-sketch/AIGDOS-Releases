# Self-Evo Candidate Card: <Title>

## Card Metadata

- `candidate_id`: `SEVO-YYYY-MM-DD-NNN`
- `source_problem_ids`:
- `source_fix_ids`:
- `source_pattern_ids`:
- `candidate_type`: rule, gate, schema, workflow, skill, tool, memory policy,
  agent capability, pack contract, checklist, or prompt/template
- `status`: candidate, sandboxing, approved_for_proposal, rejected, or deferred

## Proposed Change

<What future OS behavior or artifact may change?>

## Intended Benefit

<What recurring cost, failure, or risk this would reduce.>

## Authority Impact

- none
- execution-plane
- control-plane
- release
- governance
- human approval required

## Scope

<Project-only, pack-specific, OS-wide, tool-specific, workflow-specific, or
future-version.>

## Evidence Threshold

<What evidence is required before this can become a proposal?>

## Sandbox Plan

<How to test without changing Core or production behavior.>

## Rollback Or Deferral Path

<How to reject, defer, or revert.>

## Approval Required

- Evolution Distiller:
- Evidence & Gate Lead:
- Dev OS Architect:
- Executive Producer:
- Human owner:

## Non-Auto-Merge Statement

This candidate is not a merge instruction. Any versioned package change must
go through the promotion pipeline, evidence review, and required approval.
