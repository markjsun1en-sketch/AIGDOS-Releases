# Problem Card: <Title>

## Card Metadata

- `problem_id`: `P-YYYY-MM-DD-NNN`
- `date_opened`: YYYY-MM-DD
- `source`: command, review, user report, test failure, release gate, handoff,
  repo observation, or intake review
- `scope`: project, OS, pack, tool, workflow, release, governance, or intake
- `severity`: low, medium, high, blocker
- `status`: open, triaged, fixing, fixed, validated, deferred, or rejected
- `owner`: <single responsible role>
- `routing_candidate`: Project LTM, OS LTM, Pack Memory, Tool Memory,
  Self-Evo Queue, no_memory, needs_memory_review, os_layer, pack_layer,
  reference_only, reject_archive, or deferred_future_version

## Problem

<What is wrong, missing, risky, or unresolved?>

## Observed Behavior

<Facts only. Include exact paths, commands, outputs, or review findings when
available.>

## Expected Behavior

<What should happen instead?>

## Impact

<Why this matters. Include affected version, pack, workflow, evidence chain, or
authority boundary.>

## Affected Artifacts

- `<path or artifact>`

## Evidence Before

- `<source evidence>`

## Suspected Cause

<Hypothesis only unless verified. State unknowns explicitly.>

## Non-Goals

- <What this card must not decide or change.>

## Links

- Fix Card:
- Pattern Card:
- Self-Evo Candidate:
- Decision:
- Evidence:
- Risk:
