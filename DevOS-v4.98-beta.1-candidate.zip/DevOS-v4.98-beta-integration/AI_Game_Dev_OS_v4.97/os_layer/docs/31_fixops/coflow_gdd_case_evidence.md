---
title: CoFlow GDD Case Evidence
version: 1.0
status: active
layer: layer_2_case_study
since_batch: B11
---

# CoFlow GDD Case Evidence

> **Layer 2 case study.** This file is allowed to name concrete projects and
> source directories. It is evidence behind the generic design-data skill
> contracts, not a Layer 1 rule. Any reusable rule must be re-expressed in
> project-name-free form before it enters `packs/**`, `tests/capability/**`, or
> other Layer 1 capability surfaces.

## Scope

This case records the evidence used to absorb CoFlow-style GDD capability into
`design_data_pack`.

Evidence roots inspected:

- `/Users/macsun/lessismore/Docs`
- `/Users/macsun/Documents/KS2`
- `/Users/macsun/Documents/KSLike`
- `/Users/macsun/Documents/MacVTest`

`__pycache__` content was intentionally ignored. DevPack outputs were inspected
only as negative evidence, not as positive capability source material.

## Reproduction Commands

These commands reproduce the evidence scan without writing to the source
projects:

```bash
rg --files /Users/macsun/Documents/KS2 /Users/macsun/Documents/KSLike /Users/macsun/Documents/MacVTest \
  -g '*Brief.md' -g '*GDD_Review.md' -g '*Project_Progress.md' -g '*art_assets*.json' \
  -g '!**/__pycache__/**'
```

```bash
rg -n --glob '*GDD_Review.md' --glob '*Project_Progress.md' --glob '*art_assets*.json' \
  --glob '!**/__pycache__/**' \
  'Blocker|Conditional Go|No-Go|artifact_files|artifact_score|artifact_issues|completed_steps_snapshot|"type"|"name"|"visual_tags"' \
  /Users/macsun/Documents/KS2 /Users/macsun/Documents/KSLike /Users/macsun/Documents/MacVTest
```

```bash
find /Users/macsun/lessismore/Docs -maxdepth 1 -type f \
  \( -name '*GDD_Review.md' -o -name '0_Design_Contract.md' -o -name '1_Concept.md' \
     -o -name '2_World.md' -o -name '3_Mechanics.md' -o -name '4_Game_Mode.md' \
     -o -name '5_Numeric_Design.md' -o -name '6_UI_Layout.md' -o -name '7_Text_Assets.md' \) \
  | sort
```

```bash
wc -l /Users/macsun/lessismore/Docs/0_Design_Contract.md \
  /Users/macsun/lessismore/Docs/1_Concept.md \
  /Users/macsun/lessismore/Docs/2_World.md \
  /Users/macsun/lessismore/Docs/3_Mechanics.md \
  /Users/macsun/lessismore/Docs/4_Game_Mode.md \
  /Users/macsun/lessismore/Docs/5_Numeric_Design.md \
  /Users/macsun/lessismore/Docs/6_UI_Layout.md \
  /Users/macsun/lessismore/Docs/7_Text_Assets.md
```

```bash
rg -n 'Docs/[0-7]_|0_Design_Contract|1_Concept|2_World|3_Mechanics|4_Game_Mode|5_Numeric_Design|6_UI_Layout|7_Text_Assets' \
  /Users/macsun/lessismore/AGENTS.md /Users/macsun/lessismore/logs \
  /Users/macsun/lessismore/art/asset_requirements.md -g '*.md' \
  -g '!**/__pycache__/**'
```

## Case Findings

| Case | Observed fact | Absorbed generic rule |
| --- | --- | --- |
| `lessismore` | The top-level docs contain the accepted modular GDD baseline: `0_Design_Contract.md`, `1_Concept.md`, `2_World.md`, `3_Mechanics.md`, `4_Game_Mode.md`, `5_Numeric_Design.md`, `6_UI_Layout.md`, and `7_Text_Assets.md`; no top-level `7_5_GDD_Review.md` was present. These eight files total 1,935 lines. Local AGENTS and handoff logs consume these files as design inputs across game design, content/numeric, UI/UX, art direction, and implementation handoff flows. | A project-internal GDD may be already reviewed even when the final review artifact is absent. The OS workflow must support accepted-baseline provenance instead of fabricating a new review. A complete accepted modular baseline can promote the generic pack from exploration to controlled beta when the generic validator and tests pass. |
| `KSLike` | `7_5_GDD_Review.md` reports `Conditional Go` with `Blocker` count 1. `Project_Progress.md` records review step status, risk, route reason, permission reason, completed snapshot, artifact status, artifact score, artifact files, and artifact issues. | New or unapproved GDD packages need a review gate with severity, Blocker count, Go / Conditional Go / No-Go, step gate, rewrite requests, and workflow evidence. |
| `MacVTest` | `FinalOutput/7_5_GDD_Review.md` reports `Conditional Go` with `Blocker` count 0. `FinalOutput/art_assets_*.json` files contain asset objects with `type`, `name`, and `visual_tags`. | GDD-to-art extraction is useful, but the OS handoff must add source GDD section and acceptance notes before handing work to `art_asset_pack`. |
| `KS2` | `FinalOutput/7_5_GDD_Review.md` reports `Conditional Go` with Blocker count 2. `Project_Progress.md` shows repeated step 9 resource JSON blocked/failed entries, followed by `Dev Pack Manual Export` with `issues=82` and manual override metadata. | DevPack is negative evidence for this absorption. It should not become a production pack capability source, agent source of truth, or positive GDD-to-art proof. |

## Beta Promotion Evidence

`lessismore` supplies the accepted-baseline branch of the workflow:

- complete modular GDD surface under `Docs/0_Design_Contract.md` through
  `Docs/7_Text_Assets.md`;
- 1,935 total lines across those eight GDD files;
- no top-level final review artifact, matching the accepted-baseline
  provenance case;
- local agent definitions and handoff logs that consume the GDD modules as
  downstream inputs.

Together with the review-gate and GDD-to-art evidence from the other inspected
cases, this supports `design_data_pack` as a controlled-project `beta` pack.
It does not support `stable` yet, because the v4.93 pack still needs repeated
project-adoption runs through the new generic contracts.

## Workflow Evidence Fields

`Project_Progress.md` across the inspected cases consistently exposes a useful
workflow completion evidence shape:

- `step`
- `status`
- `risk`
- `route_reason`
- `permission_reason`
- `completed_steps_snapshot`
- `artifact_status`
- `artifact_score`
- `artifact_files`
- `artifact_issues`

The absorbed OS form intentionally narrows this to completion evidence for
pack-layer workflow reports:

- step
- status
- risk
- artifact files
- artifact score
- artifact issues
- completed snapshot

Route labels and permission fields stay runtime context. They do not become
OS production agents.

## Brief Distillation Evidence

`KS2`, `KSLike`, and `MacVTest` all contain `_Brief.md` files for major GDD
sections. These briefs repeatedly expose downstream interface sections such as
step number, inherited constraints, dependency inputs, and unresolved questions.

Absorbed generic rule:

- Long GDD modules should emit compact downstream interface summaries.
- A brief is not complete unless it separates confirmed facts, assumptions,
  open decisions, contract dependencies, downstream consumers, and acceptance
  notes.

Implemented skill:

- `gdd_brief_distillation_skill`

## Review Gate Evidence

The review reports in `KS2`, `KSLike`, and `MacVTest` share the same useful
shape:

- final gate conclusion: `Conditional Go` in the inspected samples;
- explicit Blocker count;
- severity grouping;
- file-level correction requests;
- step gate before art/resource generation;
- downstream interface notes.

Absorbed generic rule:

- New or unapproved modular GDD packages must pass a review gate before
  downstream production handoff.
- Already reviewed project-internal baselines record accepted-baseline
  provenance instead of creating a fake review artifact.

Implemented skill:

- `gdd_review_gate_skill`

## Targeted Refine Evidence

`KS2` progress history includes repeated `Refine` steps around GDD modules,
while review reports identify file-level corrections. That supports a bounded
refine workflow instead of silent whole-document rewrite.

Absorbed generic rule:

- Refine work must name target sections.
- It must classify must-change / should-change / keep.
- It must produce a rewrite delta and an intent QA result.
- It must not silently rewrite the full GDD.

Implemented skill:

- `gdd_targeted_refine_skill`

## GDD-to-Art Manifest Evidence

`MacVTest` proves a successful art-manifest extraction pattern: generated JSON
asset lists use simple fields such as `type`, `name`, and `visual_tags`.

The OS handoff deliberately tightens this:

- asset type
- name
- visual tags
- source GDD section
- acceptance notes

This keeps design responsible for art-facing extraction and handoff only.
Final art planning, concept tasks, asset batches, cleanup, and engine export
stay in `art_asset_pack`.

Implemented skill:

- `gdd_to_art_manifest_handoff_skill`

## Agent Boundary Evidence

The inspected `agent_audit.jsonl` files contain runtime route labels such as:

- `coflow-workflow`
- `dev-agent`
- `planner-agent`

These labels are not stable production agent contracts. They lack independent
write boundaries, artifact ownership, validation responsibility, and handoff
conditions in the OS contract sense.

Absorbed generic rule:

- CoFlow roles and route labels enter source-role inventory and workflow
  mapping first.
- `design_spec_author` remains the sole game-design production agent until a
  future role proves a stable write boundary, artifact ownership, validation
  responsibility, and handoff conditions.

Implemented skill:

- `design_agent_role_mapping_skill`

## Implementation Cross-Check

The evidence above maps to the v4.93 design-data contracts:

- `idea_to_modular_gdd_pipeline_skill`
- `design_agent_role_mapping_skill`
- `gdd_review_gate_skill`
- `gdd_brief_distillation_skill`
- `gdd_targeted_refine_skill`
- `gdd_to_art_manifest_handoff_skill`
- `gdd_contract_consistency_audit_skill`

It also supports this negative decision:

- Do not absorb DevPack as positive capability evidence.
- Do not add CoFlow role titles as production agents in v4.93.
