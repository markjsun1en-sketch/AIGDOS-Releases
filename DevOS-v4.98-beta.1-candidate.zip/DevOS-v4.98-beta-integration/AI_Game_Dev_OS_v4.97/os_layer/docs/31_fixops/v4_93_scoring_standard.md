# v4.93 Scoring Standard

## Purpose

This standard keeps future AI Game Dev OS scores comparable across threads.

The score must always name its rubric. A score for OS architecture maturity is
not interchangeable with a score for autonomous project execution.

## Source Alignment

Recent discussion uses AI Game Dev OS as a production control plane rather than
a prompt-to-game maker. The OS value is the controlled combination of:

- project memory;
- production rules;
- pack and agent boundaries;
- evidence gates;
- failure/fix memory;
- human creative authority;
- adapter access to external AI tools.

Under that framing, v4.93 should be scored mainly as an OS-side capability
framework unless the question explicitly asks about live project execution.

## Rubric A: OS-Side Capability Framework

Use this rubric for version-to-version comparison such as v4.92 vs v4.93.

| Dimension | Weight | What earns points |
|---|---:|---|
| Governance, identity, and layer separation | 15 | clean working/release identity, manifest/checksum consistency, Layer 1/Layer 2 separation, clear non-claims |
| Pack/agent/skill contract maturity | 15 | schema-valid packs, production-agent boundaries, lifecycle alignment, practical skill outputs |
| Production workflow capability | 18 | design/art/program/QA workflows that produce concrete artifacts with handoff and acceptance fields |
| Routing, adoption, and lifecycle gates | 12 | task-boundary dispatch, adoption evidence, human approval gates, draft-pack blocking |
| Validation and evidence coverage | 12 | targeted tests, validators, lint, checksum, manifest checks, negative cases |
| FixOps, memory, and self-evolution inputs | 10 | problem/fix capture, evidence routing, reusable pattern intake, self-evolution candidate quality |
| Integration and adapter readiness | 8 | engine adapters, data pipeline, external tool handoff boundaries |
| Project adoption readiness | 5 | enough adoption contract surface to run a controlled project adoption |
| Closure clarity | 5 | explicit pre-closure/final-closure boundaries and no release-claim ambiguity |

Score bands:

| Score | Meaning |
|---:|---|
| 9.0-9.5 | Strong OS framework with coherent production-control semantics; remaining gaps require real project evidence or long-run maturity. |
| 8.5-8.9 | Strong working-package capability layer; a few surfaces are still pre-closure, beta, or project-unproven. |
| 7.5-8.4 | Useful capability framework, but important lifecycle, routing, validation, or evidence gaps remain. |
| 6.0-7.4 | Partial framework; relies heavily on manual interpretation or non-hardened docs. |
| below 6.0 | Conceptual or fragmented; not yet a reliable OS-side production surface. |

Current v4.93 pre-closure estimate under Rubric A: 8.8-9.0.

## Rubric B: Project Adoption And Execution Readiness

Use this rubric when asking whether a project can adopt the current OS version
and run real work through it.

| Dimension | Weight | What earns points |
|---|---:|---|
| Project adoption lock and evidence | 15 | project-side adoption state, human approval, resolved pack bindings |
| Design/art/QA workflow execution | 20 | real project artifacts produced and validated through the packs |
| Program architecture execution | 12 | accepted implementation plans, risk and boundary reports, QA handoff |
| Program implementation execution | 15 | bounded source edits, tests, rollback, QA evidence |
| Regression and QA closure | 12 | focused regression, visual evidence, handoff closure, known skipped checks |
| Sprint-close integration | 10 | current sprint evidence captured and linked to OS adoption decisions |
| Tool and engine adapter reliability | 10 | adapter commands run successfully in project context |
| Issue recovery and FixOps capture | 6 | discovered problems become fix cards, memory candidates, or deferred gates |

Score bands:

| Score | Meaning |
|---:|---|
| 8.5-9.5 | Real project can repeatedly run core workflows with evidence and bounded recovery. |
| 7.0-8.4 | Adoption-ready or partially proven; some workflows still need project evidence. |
| 5.5-6.9 | Useful but not yet proven end-to-end in the current project. |
| below 5.5 | Mostly theoretical or blocked by missing adoption/runtime evidence. |

Current v4.93 pre-adoption estimate under Rubric B: 7.2-7.6. This should not
be compared directly with Rubric A scores.

## Rubric C: Autonomous Game Production Readiness

Use this rubric only when asking how close the system is to automatically
producing or maintaining a game with limited human intervention.

This score must be conservative. It is capped when source implementation,
engine execution, QA, or human acceptance is not project-proven.

Current v4.93 estimate under Rubric C: 6.2-6.8.

Caps:

- If generic source implementation is draft-blocked, cap at 7.0.
- If no current project adoption evidence exists, cap at 7.2.
- If final QA cannot run in project context, cap at 7.5.
- If final human/lead acceptance is missing, cap at 8.0.

## Required Answer Format

Future score answers should use this shape:

```text
Rubric: <A/B/C name>
Score: <number or range>
Reason: <one sentence>
Not included in this score: <explicit exclusions>
```

If a user asks only "how many points", default to Rubric A for version quality
and also show Rubric B/C if project execution maturity is relevant.

## Current v4.93 Baseline

For the pre-closed v4.93 working package:

| Rubric | Score | Interpretation |
|---|---:|---|
| A. OS-side capability framework | 8.8-9.0 | Comparable to v4.92/v4.93 version-quality discussions. |
| B. Project adoption and execution readiness | 7.2-7.6 | Requires downstream project adoption evidence. |
| C. Autonomous game production readiness | 6.2-6.8 | Capped by draft-blocked generic implementation and missing project adoption. |

After project adoption validation and final capability closure, Rubric A can
reasonably move to 9.0-9.2 if no major defects are found. Rubric B can move to
8.0+ only after design, art, QA, and program-architecture workflows produce
accepted project evidence. Rubric C should not exceed 7.0 until bounded source
implementation is project-proven.
