# Intake Promotion Boundary

## Purpose

Raw skill, agent, workflow, schema, and pack-related intake can inform future
package changes, but it is not package content until promoted.

## Raw Intake Rule

Material captured outside the package remains raw until reviewed by concrete
content and routed through the promotion pipeline.

Raw intake must not be copied directly into package files because it may mix:

- useful reference material;
- stale or duplicated content;
- OS-layer authority changes;
- Pack-layer implementation details;
- future-version candidates;
- project-specific assumptions.

## Destination Classes

Each candidate should be classified as one of:

- `os_layer`: cross-cutting OS capability, workflow, governance, schema, memory,
  evidence, or self-evolution behavior.
- `pack_layer`: pack-specific skill, contract, workflow, reference, evidence
  note, or validation support.
- `reference_only`: useful for review but not package content.
- `reject_archive`: stale, duplicated, unsafe, over-specific, or incompatible.
- `deferred_future_version`: plausible but outside current scope or lacking
  evidence.

## Promotion Requirements

Before any intake item becomes package content, record:

- source path;
- owner;
- target package or version;
- target OS layer or Pack layer;
- non-goals;
- affected authority boundary;
- affected files;
- validation path;
- rollback or deferral path;
- approval status.

## Scope Split Rule

Do not treat an intake collection as one merge unit.

When a collection contains multiple artifacts, split it into the smallest
reviewable candidates. A single additive reference can be promoted or deferred
separately from broader skill, validation, or authority changes in the same
source collection.

## Approval Boundary

Approval for comparison evidence is not approval for package implementation.
Approval for one candidate is not approval for sibling files in the same raw
collection.
