---
title: Lessismore QA Case Evidence
version: 1.0
status: active
layer: layer_2_case_study
since_batch: B12
---

# Lessismore QA Case Evidence

> **Layer 2 case study.** This file may name the concrete project and source
> directories. It is evidence behind generic QA validation pack contracts, not a
> Layer 1 rule. Any reusable rule must be re-expressed in project-name-free form
> before it enters `packs/**`, `tests/capability/**`, validators, or Layer 1
> pack documentation.

## Scope

Evidence roots inspected:

- `/Users/macsun/lessismore/GATES.md`
- `/Users/macsun/lessismore/AGENTS.md`
- `/Users/macsun/lessismore/skills/qa_regression/SKILL.md`
- `/Users/macsun/lessismore/Docs/QA/Battle`
- `/Users/macsun/lessismore/tools`
- `/Users/macsun/lessismore/logs/agents/qa_playtest_agent.md`
- `/Users/macsun/lessismore/logs/handoffs`
- `/Users/macsun/lessismore/runtime/registries`
- `/Users/macsun/lessismore/.github/workflows/runtime_smoke.yml`
- `/Users/macsun/lessismore/tools/runtime/run_runtime_smoke_local.sh`

`__pycache__` content was intentionally ignored.

## Reproduction Commands

```bash
sed -n '1,230p' /Users/macsun/lessismore/GATES.md
```

```bash
sed -n '652,677p' /Users/macsun/lessismore/AGENTS.md
```

```bash
find /Users/macsun/lessismore/tools -maxdepth 1 -type f -name 'qa_*.gd' | wc -l
```

```bash
find /Users/macsun/lessismore/Docs/QA /Users/macsun/lessismore/playtest_reports \
  /Users/macsun/lessismore/gate_reports /Users/macsun/lessismore/review_outputs \
  /Users/macsun/lessismore/ui_reviews -maxdepth 2 -type f -print | sort
```

```bash
sed -n '1,260p' /Users/macsun/lessismore/Docs/QA/Battle/12_QA_Run_Report_Round_01.md
```

```bash
sed -n '1,260p' /Users/macsun/lessismore/logs/agents/qa_playtest_agent.md
```

## Gate Evidence

`GATES.md` defines seven gates:

- Spec Gate
- Contract Gate
- Runtime Gate
- Architecture Linter Gate
- Regression Gate
- Visual / Spatial Gate
- Playtest Gate

For Prototype / MVP mode, the minimum QA-relevant baseline is:

- Runtime Gate evidence;
- minimal Playtest evidence;
- minimal Contract evidence when a task crosses module boundaries.

Reusable rule:

- QA validation should scale by project phase.
- MVP tasks need focused runtime and playtest evidence, not full production
  regression for every change.
- A task cannot claim completion when Runtime Gate fails, cross-module contract
  evidence is missing, core regression breaks, or human review rejects the
  experience / visual result.

## QA Role Boundary Evidence

`AGENTS.md` defines `QA & Playtest Agent` with a narrow execution boundary:

- run regression;
- record defects and evidence;
- output playtest observation;
- escalate blockers.

It explicitly does not:

- edit implementation to make tests pass;
- replace design or program specification decisions.

Generic absorption:

- keep `qa_validation_runner` as the single QA production agent;
- do not add a new QA production agent yet;
- encode richer QA behavior as pack-layer skills.

## Probe Execution Evidence

The project contains 161 top-level `tools/qa_*.gd` scripts.

Observed probe pattern:

- each probe extends `SceneTree`;
- probes run through Godot command lines;
- probes print `QA_RESULT: PASS` or `QA_RESULT: FAIL`;
- probes exit `0` on pass and `1` on fail;
- failures are emitted through error lines;
- focused probes cover gameplay rules, data path, responsive layout,
  resource binding, visual capture, and UI geometry.

Generic absorption:

- add `godot_qa_probe_execution_skill`;
- require command, exit code, `QA_RESULT`, failure lines, evidence refs, and
  owning execution pack handoff for failures.

## Focused Regression Evidence

The live QA log repeatedly uses focused regression sets instead of full-suite
execution. Examples include:

- data validate-only;
- Godot import / startup;
- battle visual asset smoke;
- design-space smoke;
- enemy formation smoke;
- responsive-scale smoke;
- drag-card-to-target smoke;
- non-headless visual capture;
- `git diff --check`.

Generic absorption:

- add `focused_regression_set_skill`;
- require changed surfaces, risk tags, selected probes, required gates,
  skipped probes with reason, and next validation pass;
- keep full regression optional unless release risk or governance requires it.

## Visual Capture Evidence

Visual QA uses capture scripts for viewport matrices such as:

- `1920x1080`;
- `2560x1440`;
- `1440x900`.

Observed caveat:

- headless execution can validate geometry and runtime wiring;
- screenshot production may require non-headless Godot;
- capture evidence supports review but does not sign final visual acceptance.

Generic absorption:

- add `visual_capture_evidence_skill`;
- require capture paths, viewport matrix, headless / non-headless caveat,
  review target, and manual review handoff;
- assert that QA cannot self-sign visual or playtest acceptance.

## Handoff Closure Evidence

Handoff records contain useful QA closure fields:

- consumed handoff;
- delegation decision;
- allowed write set;
- required evidence;
- command list;
- passed / failed probe list;
- known caveats;
- current status;
- remaining work;
- next owner.

Generic absorption:

- add `qa_handoff_closure_skill`;
- write a QA closure report under `docs/validation/**`;
- do not write project runtime handoff logs from the generic QA pack;
- keep runtime queue / handoff registry writes outside the pack boundary.

## CI Evidence

The project has a runtime smoke workflow:

- `.github/workflows/runtime_smoke.yml`;
- `tools/runtime/run_runtime_smoke_local.sh`;
- optional `.githooks/pre-push`.

This checks runtime objects, schemas, alias dry-run, upstream bridge checks,
and readiness scripts.

Generic absorption:

- QA pack may record runtime smoke evidence and command output;
- QA pack should not treat runtime smoke as gameplay or visual acceptance by
  itself.

## Negative Boundary Evidence

Observed hard boundaries:

- QA can report failures but should not repair source code in order to pass.
- QA technical pass does not equal Human / UI / Art visual acceptance.
- Source-review images and runtime captures are evidence, not final art lock.
- Headless screenshot limitations must be written down rather than hidden.

These boundaries support extending `qa_validation_pack` through skills while
keeping the single `qa_validation_runner` production agent.
