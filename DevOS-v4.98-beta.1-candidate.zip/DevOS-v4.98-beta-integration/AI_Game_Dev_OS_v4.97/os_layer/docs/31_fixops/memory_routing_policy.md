# FixOps Memory Routing Policy

## Purpose

Route validated FixOps knowledge to the smallest useful destination while
preventing stale memory, overgeneralized rules, and raw intake promotion.

This policy does not create DB/RAG infrastructure.

## Destinations

| Destination | Route When | Must Not Contain |
|---|---|---|
| Project LTM | Problem/fix is specific to one project, repository setup, asset, build, or workflow instance. | General OS rules inferred from one local event. |
| OS LTM | Item affects OS architecture, governance, release process, authority boundaries, roadmap, or cross-version maintenance. | Stale plans that override current repository evidence. |
| Pack Memory | Item is tied to a specific pack, pack contract, pack owner verdict, or pack lifecycle rule. | Cross-pack rules without multi-pack evidence. |
| Tool Memory | Item concerns scripts, validators, gates, CLI commands, or repeatable tool usage. | Manual preference with no repeatable command evidence. |
| Self-Evo Queue | Item suggests a future rule, gate, schema, workflow, skill, tool, memory policy, agent capability, or pack contract. | Auto-merge instructions or authority changes without approval. |
| `needs_memory_review` | Route is plausible but evidence, owner, scope, conflict status, or expiry is unclear. | Final memory text. |
| `no_memory` | Issue is one-off, local, already represented, or not worth durable routing. | Hidden assumptions that should have been recorded elsewhere. |

## Required Metadata

Every route decision should include:

- source Problem Card and Fix Card IDs;
- source path, command, review note, or human instruction;
- destination;
- owner;
- scope;
- confidence;
- evidence link;
- conflict status;
- expiry or review trigger;
- approval status if authority, governance, release, or self-evolution behavior
  may change.

## Rules

1. Repository facts override memory.
2. Facts, decisions, preferences, assumptions, risks, and open questions remain
   labeled.
3. Raw skill and agent intake must first receive destination classification.
4. Memory routing is not package promotion approval.
5. Self-evolution routing cannot change behavior without promotion review.
6. If a route affects Core, OS control-plane authority, pack contracts, or
   release gates, create a proposal instead of durable memory directly.
