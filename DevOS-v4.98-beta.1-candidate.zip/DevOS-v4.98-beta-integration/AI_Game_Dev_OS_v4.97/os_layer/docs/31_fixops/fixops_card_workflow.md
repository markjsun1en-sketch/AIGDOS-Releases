# FixOps Card Workflow

## Purpose

Use this workflow to capture development problems, fixes, repeated patterns,
and self-evolution candidates without granting automatic authority to change
package content.

## Trigger

Use FixOps when any of these occur:

- build, test, export, smoke, validation, or release-gate failure;
- repeated prompt, tool, agent, workflow, or handoff failure;
- high-risk package promotion or intake absorption;
- a user asks to record, distill, remember, or avoid repeating an issue;
- a fix needs validation evidence, rollback, or owner verdict tracking.

## Card Types

| Card | Purpose | Minimum Evidence |
|---|---|---|
| Problem Card | Preserve the failure context before it is lost. | Source evidence, owner, severity, scope, affected artifacts when known, and non-goals. |
| Fix Card | Bind a response to validation and rollback. | Changed artifacts, validation status, after-evidence, unverified areas, and rollback or deferral path. |
| Pattern Card | Distill repeated or high-blast-radius lessons. | Normally at least two verified Fix Cards, or one high-blast-radius issue marked low confidence. |
| Self-Evo Candidate Card | Hold possible OS improvements without auto-merge. | Authority impact, evidence threshold, sandbox plan, rollback or deferral path, and required approvals. |

## Workflow

1. Confirm source evidence.
2. Create or update a Problem Card.
3. Create or update a linked Fix Card.
4. Validate the fix as `verified`, `partially_verified`, `unverified`, or
   `rejected`.
5. Route knowledge to `no_memory`, `needs_memory_review`, Project LTM, OS LTM,
   Pack Memory, Tool Memory, or Self-Evo Queue.
6. Distill Pattern Cards only when evidence supports reuse.
7. Create Self-Evo Candidate Cards only as proposal candidates.
8. Use the promotion pipeline before any package change.

## Validation States

- `verified`: evidence supports the claimed fix.
- `partially_verified`: some evidence exists, but gaps remain.
- `unverified`: proposed or implemented but not validated.
- `rejected`: evidence disproves the fix or route.

## No-Close Rule

High-severity or blocker fixes cannot close without validation evidence or
explicit risk acceptance from the proper authority.

## Package Boundary

FixOps cards do not modify package content. A package change requires a
promotion proposal, approval, implementation diff, validation evidence, and
rollback or deferral path.
