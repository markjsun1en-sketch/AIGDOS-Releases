# 18 — CLI Wrapper (`ai-dev-os`)

> **v4.90 Batch 11 Unified CLI Wrapper, extended in v4.96** (the
> inherited four namespaces remain dispatch-compatible; v4.96 adds one
> read-only Team Memory status leaf and a package-local shim).
> **Status**: GUIDED wrapper / **23 leaves wired / 0 STUB** (`ltm consult`
> remains fully wired via
> `runtime.ltm.__main__`; `ltm quarantine` and `evolve propose` also
> remain available from the inherited line). Routing-policy advanced
> enforcement for `ltm consult` still deferred to v4.91+
> (`docs/15_ltm_v2/RETRIEVAL_ROUTING_v2.md §6`).
> Steps 11.1 (skeleton) → 11.2 (migration) → 11.3 (ltm) → 11.4 (pack) →
> 11.5 (evolve) → 11.6 (closure) all landed; Batch 13.1/13.4.b extended
> the leaf set; Batch 11's "1 STUB" status from v4.90.0 is now fully
> retired.
> **Discipline**: dispatch-only. Every leaf forwards into an existing
> `scripts/<ns>/<module>.py` `main(argv) -> int` entry point with no
> argument re-translation.
> **Layer**: Layer 1 (OS Spec). No project names anywhere in this
> module.

## Purpose

Replace 17 scattered `python3 scripts/<ns>/<script>.py …` invocations
with a single top-level `ai-dev-os <ns> <command> …` interface that:

1. Renders a self-describing `--help` tree without importing any
   business logic (< 100 ms target).
2. Forwards exit codes from underlying scripts unchanged
   (`0` / `1` / `3` / `4`); reserves `2` for "unknown subcommand /
   malformed top-level parse".
3. Surfaces five namespaces: the inherited `migration` / `ltm` / `pack` /
   `evolve` set plus v4.96 `team-memory`. The `pack` namespace
   houses both `pack agent-library` and `pack adoption` sub-groups.
4. Resolves the doc forward-refs accumulated across Batch 8/9/10
   (`ai-dev-os ltm consult`, `ai-dev-os adoption validate` →
   `ai-dev-os pack adoption validate`, `ai-dev-os evolve validate`,
   etc.).

## Documents in this directory

| File | Role | Status |
| --- | --- | --- |
| `README.md` (this file) | Module entry point + namespace map | GUIDED wrapper |
| `CLI_USAGE_GUIDE.md` | Adopter quickstart + per-namespace command reference | GUIDED wrapper (full namespace ref) |

## Sister artefacts

- `scripts/cli/ai_dev_os.py` — top-level dispatcher (Layer 1).
- `tests/cli/test_cli_*.py` — dispatch + help-tree regression suite.
- `scripts/governance/lint_layer_separation.py` — `LAYER_1_ROOTS`
  extended to include `docs/18_cli`, `scripts/cli`, `tests/cli`
  (Step 11.1).

## Invocation

```bash
# From AI_Game_Dev_OS_v4.97/os_layer:
python3 -m scripts.cli.ai_dev_os --help
python3 -m scripts.cli.ai_dev_os <namespace> <command> [args...]

# From the AI_Game_Dev_OS_v4.97 package root:
bin/ai-dev-os <namespace> <command> [args...]
```

The inherited module invocation remains supported. v4.96 also supplies the
package-local `bin/ai-dev-os` shim, which initializes both package and OS-layer
import paths without installing a global shell command.

### Invocation forms (v4.96)

| Form | v4.96 status |
| --- | --- |
| `python3 -m scripts.cli.ai_dev_os <ns> <cmd> ...` from `os_layer/` | ✅ supported inherited form |
| `AI_Game_Dev_OS_v4.97/bin/ai-dev-os <ns> <cmd> ...` | ✅ supported package-local shim |
| `ai-dev-os <ns> <cmd> ...` (global PATH binary) | ❌ not installed; use the package-local shim |

## Namespace map (target shape, fully wired by Step 11.6)

```
ai-dev-os
├── migration        # Step 11.2 — 7 leaves (scan/detect-protocol/adopt/generate-queue/generate-report/validate-capability/validate-protocol)
├── ltm              # Step 11.3 + Batch 13.1 + 13.4.b — 7 leaves (capture/extract/promote/quality/validate-ff/consult/quarantine)
├── pack
│   ├── agent-library  # Batch 13 — 3 leaves (validate/list/activate)
│   │   ├── validate # wraps scripts/agent_library/validate_agent_pack.py
│   │   ├── list     # wraps scripts/agent_library/list_packs.py
│   │   └── activate # wraps scripts/agent_library/activate_pack.py
│   └── adoption     # Step 11.4 — 3 leaves (init/harness/validate)
│       ├── init     # wraps scripts/adoption/init_project_runtime.py
│       ├── harness  # wraps scripts/adoption/run_mock_harness.py
│       └── validate # wraps scripts/adoption/validate_adoption.py
├── evolve           # Step 11.5 + Batch 13 — 2 leaves (validate/propose)
    ├── validate     # wraps scripts/self_evolution/validate_proposal.py
    └── propose      # wraps scripts/self_evolution/propose_skeleton.py
└── team-memory      # v4.96 — 1 read-only leaf
    └── status       # Provider state + current-actor policy projection
```

**Total**: **23 leaves wired / 0 STUB**
(migration 7 + ltm 7 + pack 6 + evolve 2 + team-memory 1; alias forms
`migration handshake / plan / verify / report` are not counted).

## v4.96 Team Memory status boundary

`team-memory status` reads only Provider capabilities, activation status,
health, and the selected actor's exact deny-by-default permission policy. It
does not call `get` or `search`, enumerate record IDs/content/counts, enable or
disable the Provider, promote Memory, or grant protected authority. Its actor
context is caller-supplied local context and is reported as
`policy_projection_only`; the CLI is not an authentication service.

The leaf supports a human table (`--format table`, default) and stable
machine-readable JSON (`--format json`). Omitting `--coordinator-root` reports
the valid `not_installed` state while preserving ordinary core-project
availability.

## Exit codes

| Code | Meaning | Source |
| --- | --- | --- |
| `0` | OK | underlying script |
| `1` | VIOLATION | underlying script |
| `2` | USAGE | this wrapper (unknown subcommand / bad top-level parse) |
| `3` | INTERNAL | underlying script |
| `4` | INPUT_MISSING | underlying script |

The wrapper itself only ever returns `0` (--help), `2` (bad top-level
parse / unknown namespace / no namespace), or `3` (placeholder
namespace before its leaves are wired). All other codes are forwarded
verbatim from the underlying script.

## Layer 1 discipline

This module's source code MUST stay project-name-free. The dispatcher
does not embed any project taxonomy strings; the underlying scripts
already follow the same rule (enforced by
`scripts/governance/lint_layer_separation.py`).

## Not in scope (v4.90 Batch 11)

- Global `console_scripts` / PATH installation; v4.96 provides only the
  package-local `bin/ai-dev-os` shim.
- ~~Real `ltm consult` implementation — STUB returns exit 3 with a
  pointer to `docs/15_ltm_v2/RETRIEVAL_ROUTING_v2.md §6`.~~
  **Update (Batch 13.1, post v4.90.2)**: `ltm consult` is fully wired
  via `runtime.ltm.__main__` (substring + FTS5 retrieval; exit 0/1/3/4
  per plan §9). Routing-policy advanced enforcement is the only piece
  still deferred to v4.91+ (see `docs/15_ltm_v2/RETRIEVAL_ROUTING_v2.md
  §6`).
- Shell completion (bash/zsh) — defer to v4.91+.
- Plugin system / third-party subcommand registration — defer to v4.92+.
- Unified JSON output schema across all leaves — Batch 11 lets each
  leaf keep its own `--format` flag.
