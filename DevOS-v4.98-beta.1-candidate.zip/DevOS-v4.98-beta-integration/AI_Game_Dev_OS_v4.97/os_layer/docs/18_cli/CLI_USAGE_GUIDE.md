# CLI Usage Guide

> **v4.90 Batch 11 wrapper, extended in v4.96**
> **Status**: GUIDED wrapper / **23 leaves wired / 0 STUB**. Sections 4-7
> retain the inherited namespace contract; section 8 defines the v4.96
> read-only Team Memory status projection.
> **Layer**: Layer 1 (OS Spec). All examples use generic command shapes.

---

## 1. Quick Start

```bash
# From the current v4.97 package root (the shim was introduced in v4.96):
cd AI_Game_Dev_OS_v4.97

# Print the top-level help tree (< 100 ms; no business logic loaded).
bin/ai-dev-os --help

# Inspect a namespace.
bin/ai-dev-os migration --help     # Step 11.2+
bin/ai-dev-os ltm --help           # Step 11.3+
bin/ai-dev-os pack --help          # Step 11.4+
bin/ai-dev-os evolve --help        # Step 11.5+
bin/ai-dev-os team-memory --help   # v4.96

# Invoke a leaf.
bin/ai-dev-os <ns> <cmd> [args...]

# The inherited module form remains supported when cwd is os_layer/:
(cd os_layer && python3 -m scripts.cli.ai_dev_os <ns> <cmd> [args...])
```

The package-local shim is supported but not installed globally. A bare
`ai-dev-os` command is therefore not promised on `PATH`.

---

## 2. Top-level Structure

| Namespace | Purpose | Wired in |
| --- | --- | --- |
| `migration` | Legacy project migration toolkit | Step 11.2 |
| `ltm` | Long-term memory v2 toolkit | Step 11.3 |
| `pack` | Agent library + project adoption packs | Step 11.4 |
| `evolve` | Self-evolution proposal toolkit | Step 11.5 |
| `team-memory` | Optional Provider state + current-actor permission projection | v4.96 |

Before its leaves are wired, a namespace returns `exit 3` with a
"namespace not yet wired" diagnostic. After wiring, the namespace
transparently forwards to the underlying script.

---

## 3. Exit Code Contract

| Code | Origin | Meaning |
| --- | --- | --- |
| `0` | underlying script | OK |
| `1` | underlying script | VIOLATION (validation rule failure) |
| `2` | this wrapper | USAGE (bad top-level parse / unknown namespace / no namespace given) |
| `3` | underlying script | INTERNAL (parser crash; previously also `ltm consult` STUB before Batch 13.1 wired it) |
| `4` | underlying script | INPUT_MISSING (`--file` / `--dir` target missing) |

The wrapper itself never returns `1` or `4` — those are reserved for
real validation outcomes inside the underlying scripts.

---

## 4. `migration` Namespace

> **Status**: GUIDED — 7 leaves wired (Batch 11.2 closure).
> **Underlying scripts**: `scripts/migration/*.py` (7 entry points).

Current leaf shape (post Batch 11.2 closure):

```
# Base leaves (7)
ai-dev-os migration scan                   # scan_legacy_project.py
ai-dev-os migration detect-protocol        # detect_project_protocol.py
ai-dev-os migration adopt                  # adopt_capability.py
ai-dev-os migration generate-queue         # generate_capability_queue.py
ai-dev-os migration generate-report        # generate_migration_report.py
ai-dev-os migration validate-capability    # validate_capability_adoption.py
ai-dev-os migration validate-protocol      # validate_protocol_compatibility.py

# Alias leaves (4; same dispatch, friendlier name; not counted in the
# 23-leaves total since aliases reuse the underlying entry points)
ai-dev-os migration handshake              # alias: detect-protocol → validate-protocol
ai-dev-os migration plan                   # alias: generate-queue --format=markdown
ai-dev-os migration verify                 # alias: 1:1 of validate-capability
ai-dev-os migration report                 # alias: 1:1 of generate-report
```

Detailed flag reference per leaf is available via `--help` on each
sub-command (e.g. `ai-dev-os migration scan --help`).

---

## 5. `ltm` Namespace

> **Status**: GUIDED — 7 leaves wired (Batch 11.3 closure + Batch 13.1
> consult retrieval engine + Batch 13.4.b quarantine wrapper).
> **Underlying scripts**: `scripts/ltm/*.py` (6 entry points) +
> `runtime/ltm/__main__.py` (consult retrieval engine, Batch 13.1
> wired) + `scripts/ltm/quarantine_entry.py` (Batch 13.4.b).

Current leaf shape (post Batch 11.3 + 13.1 + 13.4.b):

```
ai-dev-os ltm capture          # capture_sprint_close.py
ai-dev-os ltm extract          # extract_failure_candidates.py
ai-dev-os ltm promote          # promote_memory_candidate.py
ai-dev-os ltm quality          # validate_memory_quality.py
ai-dev-os ltm validate-ff      # validate_failure_fix_entry.py
ai-dev-os ltm consult          # [GUIDED] keyword/FTS5 retrieval; exit 0/1/3/4 (Batch 13.1 wired via runtime.ltm.__main__)
ai-dev-os ltm quarantine       # [GUIDED] reverse-of-extract (Batch 13.4.b; plan §9 字面)
```

`ltm consult` is **fully wired** as of v4.90 Batch 13.1. It searches
the LTM corpus by keyword (substring match in v4.90; FTS5 retrieval
when the optional sqlite-fts5 extension is present) and exits 0/1/3/4
per the plan §9 multi-tier exit code policy. Routing-policy advanced
enforcement (see `docs/15_ltm_v2/RETRIEVAL_ROUTING_v2.md §6`) is the
only piece still deferred to v4.91+.

---

## 6. `pack` Namespace

> **Status**: GUIDED — 6 leaves wired (Batch 11.4 closure + Batch 13
> agent-library list + activate).
> **Underlying scripts**: `scripts/agent_library/*.py` (3 entry points:
> validate / list / activate) + `scripts/adoption/*.py` (3 entry
> points: init / harness / validate).

Current leaf shape (nested; post Batch 11.4 + Batch 13):

```
# pack agent-library — 3 leaves
ai-dev-os pack agent-library validate  # validate_agent_pack.py
ai-dev-os pack agent-library list      # list_packs.py (Batch 13)
ai-dev-os pack agent-library activate  # activate_pack.py (Batch 13)

# pack adoption — 3 leaves
ai-dev-os pack adoption init           # init_project_runtime.py
ai-dev-os pack adoption harness        # run_mock_harness.py
ai-dev-os pack adoption validate       # validate_adoption.py
```

The `pack adoption` sub-group is the canonical home for the four
forward-refs that earlier Batch 8/9/10 docs abbreviated as
`ai-dev-os adoption …`. Step 11.6 updates those forward-refs to match.

---

## 7. `evolve` Namespace

> **Status**: GUIDED — 2 leaves wired (Batch 11.5 closure + Batch 13
> propose generator).
> **Underlying scripts**: `scripts/self_evolution/validate_proposal.py`
> + `scripts/self_evolution/propose_skeleton.py`.

Current leaf shape (post Batch 11.5 + Batch 13):

```
ai-dev-os evolve validate [--file <path>] [--dir proposals/] [--format text|json]
ai-dev-os evolve propose <slug> [--summary <text>] [--year YYYY]   # propose_skeleton.py (Batch 13)
```

Validates the YAML front-matter of `proposals/evo_*.md` self-evolution
proposal entries. Wraps `scripts/self_evolution/validate_proposal.py`
with no behavioural change. See
`docs/17_self_evolution/PROPOSAL_VALIDATION_PLAN.md` for the
state-conditional enforcement matrix.

---

## 8. `team-memory` Namespace

> **Status**: GUIDED — 1 read-only leaf added in v4.96.

```bash
bin/ai-dev-os team-memory status \
  --project-root /absolute/path/to/project \
  --project-id example-project \
  --team-id example-team \
  --policy-file /absolute/path/to/project_permission_policy.json \
  --actor-context-file /absolute/path/to/actor_context.json \
  --format table
```

Add `--coordinator-root /absolute/path/to/coordinator` only when observing an
installed same-host reference Provider. Omitting it intentionally reports
`not_installed`. Add `--team-memory-required` to project whether the selected
task's explicit requirement is ready or blocked; a block never blocks
unrelated tasks.

The policy file must be the canonical `project_permission_policy` JSON shape.
The actor file is an exact object with `principal_id`, `principal_kind`,
`project_id`, `team_id`, and `role_claims`. These inputs must match the CLI's
exact project/team scope. The actor file is caller-supplied local context;
Human approval remains external and this CLI does not authenticate an OS
account.

Start from the generic examples at
`adapters/codex/examples/team_memory_status_policy.example.json` and
`adapters/codex/examples/team_memory_status_actor_context.example.json`, then
replace the project/team/principal IDs and grant only the capabilities intended
for that actor. The example intentionally grants read/propose only; all other
Team Memory actions remain denied.

Security and authority boundary:

- The command calls only Provider capabilities/activation status/health and
  policy evaluation. It does not call Memory `get` or `search`.
- Output contains no Memory record IDs, content, result counts, or project
  filesystem path.
- It never enables/disables Team Memory or writes Provider state.
- `allowed` means only that the exact local policy has a matching grant. It
  does not authorize qualification, Gate transitions, Production Pack
  promotion, release, push/tag, or production/live contact.
- `--format json` emits a schema-valid `team_memory_status_snapshot` with a
  deterministic content hash over the observation body; table is the human
  default.

## 9. Internals

The wrapper is intentionally thin. Its source
(`scripts/cli/ai_dev_os.py`) does three things:

1. Builds an `argparse` tree with one `add_subparsers` call per
   namespace.
2. Each leaf's `set_defaults(_dispatch=…)` binds a thin function that
   imports the underlying script's `main(argv)` lazily and forwards
   `remaining_argv`.
3. Exit codes are returned directly from the dispatched function;
   only the top-level parser ever generates exit `2`.

There is no plugin system, no dynamic subcommand discovery, no global
state. Adding a new leaf is a 4-line change inside `_build_parser()`
plus a unit test in `tests/cli/`.

---

## 10. Adding a Leaf (contributor reference)

1. Confirm the underlying script exposes
   `def main(argv: list[str] | None = None) -> int` and uses the
   shared exit-code enum (`0/1/3/4`).
2. Inside the relevant namespace's subparser block, add:
   ```python
   p_<leaf> = ns_subparsers.add_parser("<leaf-name>", help="...")
   p_<leaf>.set_defaults(_dispatch=_dispatch_leaf("<ns>.<module>"))
   ```
3. The shared `_dispatch_leaf(target)` helper resolves `target` lazily
   to `scripts.<ns>.<module>.main` at call time (NOT at import time).
4. Add a dispatch test in `tests/cli/test_cli_<ns>.py` that calls
   `ai_dev_os.main(["<ns>", "<leaf>", "--help"])` and asserts exit 0.
5. Ensure the wider regression baseline still passes:
   ```bash
   python3 -m pytest tests/cli/ -q
   python3 scripts/governance/lint_layer_separation.py
   ```

---

## 11. References

- `docs/18_cli/README.md` — module entry.
- `scripts/cli/ai_dev_os.py` — dispatcher source.
- `V4_90_README.md §5.14` — Batch 11 closure recap (after Step 11.6).
- `V4_90_BATCH_11_HANDOFF.md` (workspace root) — full handoff document.
