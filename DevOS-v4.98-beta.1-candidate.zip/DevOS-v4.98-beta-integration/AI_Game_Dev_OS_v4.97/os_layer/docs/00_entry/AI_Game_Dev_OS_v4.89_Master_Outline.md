# AI_Game_Dev_OS v4.89 Master Outline

## 1. Version Positioning

### v4.87
Stabilization baseline focused on consolidation, de-duplication, compression, and mainline hardening.

### v4.88 RC12
**Tier2 Beta documentation pack** rebuilt from real project evidence. New abstractions (Portable Core + Runtime Profiles + TAPD/Git/Audit baselines) specified in docs but runtime implementation deferred.

### v4.89
**Beta Sprint Exit hardening release.** Carries v4.88 RC12 abstraction from "documentation pack" to "runtime-capable pack" by landing 11 permanent contracts, an LTM MVP runtime, 5-profile parity, schema-driven cross-check, lift gate, skills library, sprint+agent cold-start governance, and Layer A cross-project LTM namespace.

v4.89 inherits **all** v4.88 RC12 abstractions verbatim. The v4.88 RC12 byte-lock (`AI_Game_Dev_OS_v4.88_Release/`, SHA `58346b3`, 539 files) is preserved unchanged.

## 2. Core Principles

### 2.1 Portable Core + Runtime Profiles (inherited from v4.88)
v4.89 keeps the v4.88 split:
- **Portable Core**: shared rules, schemas, runtime guardrails, common scripts
- **Runtime Profiles**: codex / cursor / claude_code_subagents / claude_code_agent_teams / workbuddy_private

v4.89 **proves** the split holds via 5-profile schema-driven cross-check parity (R1 16-row matrix byte-identical pre/post collapse).

### 2.2 TAPD + Git fixed for this round (inherited from v4.88)
This round still assumes external collaboration = TAPD, version control = Git. Live adapter wiring is **deferred to v4.90**; v4.89 ships normalize stubs.

### 2.3 Contracts before features (v4.89-new)
v4.89 priority order:
1. Lock 11 permanent contracts (envelope / `_ev_get` / source layers / writeback / quarantine / canonical fields).
2. Wire LTM MVP + Layer A namespace.
3. Achieve 5-profile parity + schema-driven cross-check.
4. Land lift gate + cold-start governance + skills library.

This supersedes v4.88's "guardrails before productization" — v4.89 codifies *which* guardrails as immutable contracts.

## 3. Overall Structure

### A. Portable Core
- runtime portability + dynamic root discovery + no-demo init + path validator + official digest
- 11 permanent contracts (`ltm/os/*.md` 10 OS-domain entries + envelope/source-layer canonical definitions)
- LTM MVP runtime (`runtime/ltm/` engine + `ltm/` corpus)
- Schema-driven cross-check (`runtime/schema_driven_check.py`)
- Sprint+agent cold-start governance (`runtime/registries/` + manifest + boot wrapper + cold-start pack generator)
- Skills library (`skills/_generic_core/` + `skills/_engine_specific/godot/` + `skills/_adaptation_hooks/`)

### B. Runtime Profiles
- codex / cursor / claude_code_subagents / claude_code_agent_teams / workbuddy_private
- Each profile JSON declares 8 contract-surface fields cross-check verifies
- `_base.py` collector + 5 runtime-specific collector implementations
- 3 cold-start profiles per profile family: `SPRINT_GOVERNED` / `SPRINT_DEEP` / `ARCHIVE_LOOKUP`

### C. Cross-project LTM Layer A (v4.89-new)
- Optional `project_id` YAML front-matter
- `consult(project_id=...)` + CLI `--project`
- Gate rule 5 (project domain requires project_id)
- `ltm/project/<id>/` per-project path partition
- "Missing ≡ global" — untagged entries flow automatically to every project-scoped consult

## 4. Phase 1–4 Chapters

### Phase 1 — Beta Sprint Hardening
**Tag**: `v4.89-phase-1`
**Goal**: lock the contracts every Beta Sprint Exit needs.

Deliveries:
- 11 permanent contracts re-derived from `workbuddy_private` E1-E7 sprint
- Envelope 9-field shape + 2 optional fields
- `_ev_get(event, key, default)` envelope-aware read helper
- `_ALLOWED_SOURCE_LAYERS` canonical tuple
- `top_level=` deprecated bridge (real removal scheduled v4.90)
- `_resolve_state_path` defensive filesystem reads
- Helper-scope boundary (helpers fail loudly on missing context)
- Malformed-audit fallback (writes never lose events silently)
- Canonical-override block (warn-only in v4.89, tighten in Phase 3)
- Evidence-required quarantine for non-OS domains
- Driver writes canonical fields (now unconditional after M7.3 lift gate)
- Pointer shim contract

### Phase 2 — LTM MVP + 5-profile Parity

**Stage 1 (M5)** — `tag v4.89-phase-2-m5`. LTM MVP. `runtime/ltm/` engine + `ltm/` corpus. Two-call API `consult / capture` + CLI. 4 domains (`os / project / pattern / failures`) + quarantine. 5 Gate rules. 19 seed entries (10 OS + 6 failures + 2 patterns + 1 recent). 14 pytest.

**Stage 2 (B1)** — `tag v4.89-phase-2-stage-2-b1`. 5-profile parity. `_base.py` + per-profile collectors. 8 Stage 2 combos. 20 parametrized parity tests + R1 regression matrix.

### Phase 3 — Schema-driven Collapse
**Tags**: `v4.89-phase-3-audit` → `v4.89-phase-3-collapse`.

4 per-profile `verify_*_cross_check.py` blocks (110 LoC near-duplicate) collapsed into `runtime/schema_driven_check.py` driven by profile JSON. R1 regression matrix (16 rows) byte-identical pre/post.

### Phase 4 — Hardening + Release

**Step 1 — M7.3 Lift Gate** (`tag v4.89-phase-4-lift`):
Cross-check no longer relies on "field exists in state". `_stub_init` now writes full contract surface canonically every init; cross-check requires `field exists AND matches`. Eliminates silent-PASS on stale state. 25 pytest.

**Step 2 — M8.0 Skills Import** (`tag v4.89-phase-4-skills`):
- `skills/_generic_core/` — 28 SKILL.md across 9 role dirs (art / design / engineering / qa / orchestrator / numeric / content-design / game-design / uiux) + 15 contract/ops triads.
- `skills/_engine_specific/godot/` — 3 SKILL.md (2D responsive layout + rawdata pipeline).
- `skills/_adaptation_hooks/` — 12 hooks for project-specific customization.
- Lexicon scrub: 9 forbidden terms (`lessismore` / `Card Roguelike` / `卡牌` / `爆衣` / `限界共鸣` / `七宗罪` / `SP-` / `relic` / `gourd`) grep 0.

**Step 3 — M9.0 Cold-start Governance** (`tag v4.89-phase-4-coldstart`):
5 registries (`runtime/registries/`) + 1 manifest (`runtime/config/context_profiles_manifest.json`) + 6 per-profile `sprint_cold_start` declarations + rollup + boot wrapper + cold-start pack generator + mirror regen. 3 cold-start profiles. 16-key `cold_start_pack.v1` JSON. 48 pytest.

**Step 3.5 — M9.5 Cross-project LTM Layer A** (`tag v4.89-phase-4-cross-ltm`):
Optional `project_id` YAML + `consult(project_id=...)` + `--project` CLI + Gate rule 5 + `ltm/project/<id>/` path routing + 4 synthesized RH seed entries + 8 namespace pytest + lexicon scrub guardrail.

**Step 4 — M10.0 Release** (`tag v4.89-release-rc1` → `rc2` reflow):
RC1 freeze 5/7. RC2 reflow 5/8 — entry-doc rename + content rewrite + 7 reference points + CHECKSUMS regen.

## 5. Pytest Baseline

**259 passed** on both `AI_Game_Dev_OS_v4.89/` and `AI_Game_Dev_OS_v4.89_Release/`.

| Suite | Count | Origin |
|---|---:|---|
| Phase 1 hardening | 12 | resolve_state_path / tapd_envelope / wrap_external_record / git_source_layer |
| Phase 2 Stage 1 LTM | 14 | ltm_consult / ltm_capture / ltm_integration |
| Phase 2 Stage 2 parity | 20 | per-profile collector + R1 regression matrix |
| Phase 3 collapse | 5 | schema_driven_equivalence |
| Phase 4 M7.3 lift gate | 25 | init_writes_contract_surface |
| Phase 4 M9.0 cold-start | 48 | sprint_context_rollup / mirror_trial_workspace / boot |
| Phase 4 M9.5 namespace | 8 | ltm_namespace |
| Earlier hardening / aliasing / adapters | ~127 | supporting suites |

## 6. Tooling Surface

### LTM CLI
```bash
python -m runtime.ltm "envelope contract"                      # all domains
python -m runtime.ltm "handoff" --project rh                   # M9.5 namespace filter
python -m runtime.ltm "writeback owner" --domain os --limit 5
```

### LTM API
```python
from runtime.ltm import consult, capture
hits = consult("envelope contract")
capture(domain="project", title="Sprint retro", content="...",
        evidence_ref="commit abc1234", project_id="rh")
```

### Schema-driven cross-check
```bash
pytest tests/test_verify_*_cross_check.py tests/test_schema_driven_equivalence.py
```

### Lexicon scrub guardrail
```bash
grep -riE 'lessismore|Card Roguelike|卡牌|爆衣|限界共鸣|七宗罪|SP-|relic|gourd' \
  ltm/project/ skills/_generic_core/ skills/_engine_specific/
```

### Cold-start boot
```python
from runtime.boot import boot_agent_thread
pack = boot_agent_thread(profile="codex", thread_id="t1")  # → cold_start_pack.v1 JSON (16 keys)
```

## 7. Directory Layering Principle

v4.89 inherits v4.88's three-layer rule:
- universal guidance does NOT bury inside runtime profiles
- workbuddy-specific mechanisms do NOT re-enter portable defaults
- starter is a family, not a single universal pack

v4.89 adds:
- LTM corpus partitions cleanly: `ltm/os/` (cross-project) / `ltm/pattern/` / `ltm/project/<id>/` (per-project) / `ltm/quarantine/` (gated rejects)
- Skills follow the same partition: `skills/_generic_core/` / `skills/_engine_specific/<engine>/` / `skills/_adaptation_hooks/`
- Cold-start registries live under `runtime/registries/` (5 files, schema-typed)

## 8. Out of Scope for v4.89

Explicitly **not** in this release (routed to v4.90+):

- **Layer B** — SQLite FTS5 / `sqlite-vec` vector retrieval upgrade.
- **Layer C** — `replay()` / auto-promotion of cross-project patterns (Evolution Roadmap ②).
- **Cross-project platform step** — Evolution Roadmap ④.
- **TAPD / Git live adapters** — normalize stubs only.
- **Architecture Linter rules A / B / D** — only rule C ships.
- **Exit Verifier GUIDED tier** — currently SCAFFOLD.
- **`top_level=` bridge true removal** — kept as deprecated dual-write.
- **Self-evolution / autonomous self-improvement.**
- **Heavy fully-automated team orchestration.**

See `docs/V4.89_BACKLOG.md` for the full deferral list.

## 9. Lineage to v4.88_Release

v4.88 RC12 byte-lock invariants preserved by v4.89:

- `AI_Game_Dev_OS_v4.88_Release/` SHA `58346b3` (539 files) — **unchanged**.
- All v4.88 RC12 abstractions (Portable Core / Runtime Profiles / TAPD-Git baselines / Truth model) — preserved verbatim.
- Tier2 Beta vocabulary — preserved as continuity (may retire in v4.90+).
- v4.88 RC12 entry docs (`v4.88_Overview.md` / `v4.88_Master_Outline.md`) — remain in `v4.88_Release/docs/00_entry/` as canonical historical archive. v4.89 ships **its own** `v4.89_Overview.md` / `v4.89_Master_Outline.md` (this file) at `v4.89_Release/docs/00_entry/`.

## 10. Reading Order

For new readers entering through `v4.89_Release/`:

1. `docs/00_entry/START_HERE.md`
2. `docs/00_entry/AI_Game_Dev_OS_v4.89_Overview.md`
3. `docs/00_entry/AI_Game_Dev_OS_v4.89_Master_Outline.md` (this file)
4. `RELEASE_NOTES.md` — RC1/RC2 narrative + 8 headline features + verification checklist
5. `USER_GUIDE.md` — EP onboarding (5 + 15 min)
6. `ASSEMBLY_GUIDE.md` — loading order + stage policy
7. `runtime/MATURITY_MATRIX.md §3.x` — per-phase maturity ledger
8. `docs/06_runtime_profiles/PHASE_4_*.md` — audit docs (M7.3 / M8.0 / M9.0 / M9.5)
9. `CHANGELOG.md` — commit-level Phase 1 → Phase 4 narrative
10. `docs/V4.89_BACKLOG.md` — outstanding items routed to v4.90
