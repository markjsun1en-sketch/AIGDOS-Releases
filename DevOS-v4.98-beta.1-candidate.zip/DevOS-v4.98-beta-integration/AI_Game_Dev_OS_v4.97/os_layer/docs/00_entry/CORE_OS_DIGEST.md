# Core OS Digest

> **Single entry point is `START_HERE.md`.** The readset below is the shortest safe path, not a replacement for `START_HERE.md`'s Run path.

This file is the official short-form digest for v4.89. It exists so that new projects and new runtime sessions do **not** have to load the full document tree before they can operate safely.

## What This OS Is

AI_Game_Dev_OS is a project runtime baseline composed of:

- runtime objects
- governance rules
- external integration baselines
- observability and audit
- project adaptation assets

## Core Runtime Objects

The minimum runtime object set is:

- Task
- Handoff
- Validation / QA Gate
- Snapshot
- Registry Entry
- External Sync Record
- Audit Event

## Non-Negotiable Principles

1. Portability comes before convenience assumptions.
2. **Code is truth** for implementation, interfaces, and runtime behavior.
3. **Evidence is truth** for validation and completion claims.
4. **Registry is the internal truth layer** for operational state and reconciliation state derived from code, evidence, and controlled writebacks.
5. TAPD is the external collaboration layer for the current baseline.
6. Parallel execution is allowed; merge/apply must remain serial.
7. External writeback must be verified after execution.
8. Cleanup belongs to the parent / lead / main control owner.
9. Agent boundary enforcement is mandatory.
10. Execution profile must be selected explicitly.

## Minimum Readset

> For the full Run path, see `START_HERE.md`. This section lists only the shortest safe entry sequence when full onboarding is not needed.

Before working, read in this order:

1. `START_HERE.md`
2. `EXECUTION_PROFILE_SELECTION.md`
3. `EXECUTION_PROFILE_QUICKSTART.md`
4. the selected runtime profile overview under `docs/06_runtime_profiles/`
5. `docs/04_integrations/TAPD_Integration_Baseline.md`
6. `docs/04_integrations/Git_Agent_Workflow_Baseline.md`

## What This Digest Is Not

This digest is not a complete replacement for the architecture or governance docs. It is the shortest safe entry path.
