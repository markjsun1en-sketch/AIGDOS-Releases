# DOCUMENT_PRIORITY_MAP

> **Single entry point is `START_HERE.md`.** This map does not re-list a "read first" order — it only groups documents by role once you are already on the Run path defined in `START_HERE.md`.

This map reduces navigation noise inside the v4.89 release line.

## Core baseline documents
- `docs/01_architecture/Portable_Core_vs_Runtime_Profiles.md`
- `docs/02_governance/PORTABLE_AGENT_BOUNDARIES.md`
- `docs/02_governance/PORTABLE_RECOVERY_PRINCIPLES.md`
- `docs/03_runtime_core/*`
- `docs/04_integrations/*`
- `docs/05_observability/*`

## Runtime-specific overlays
- `docs/06_runtime_profiles/codex/*`
- `docs/06_runtime_profiles/cursor/*`
- `docs/06_runtime_profiles/claude_code_subagents/*`
- `docs/06_runtime_profiles/claude_code_agent_teams/*`
- `docs/06_runtime_profiles/workbuddy_private/*`

## Trial-focused entry
Use `docs/09_beta_sprint/` when the immediate goal is to run one controlled Beta Sprint.

## Traceability / archive layer
Batch-era planning and merge notes were retained during RC lineage for provenance; they have been retired in the Release cleanup. Lineage summary remains at `docs/12_release_notes/RC_Lineage_Summary.md`.
They are useful for provenance and review, but they are not the primary operating surface.
