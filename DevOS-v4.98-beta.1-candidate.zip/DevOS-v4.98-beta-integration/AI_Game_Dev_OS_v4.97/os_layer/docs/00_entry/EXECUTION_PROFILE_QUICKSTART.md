# Execution Profile Quickstart

> **Terminology note (v4.89)**: the canonical term is **Runtime Profile** (see `EXECUTION_PROFILE_SELECTION.md` header note). This filename still uses the older `EXECUTION_PROFILE_*` prefix; a package-wide RENAME to `RUNTIME_PROFILE_*` was completed during the v4.88_Revise → v4.89 Phase 3 Step 3.

This document is the shortest path from an empty project to a runnable v4.89 profile selection.

## Goal

Pick one runtime profile, copy the right starter family slice, initialize runtime state without demo residue, and verify that the selected execution model matches the actual tool/IDE environment.

## Four-step path

### Step 1 — Confirm the actual runtime

Decide which environment will execute the work rather than which environment you *like* conceptually.

- Use **Codex** when the project will be orchestrated around AGENTS.md, explicit subagent delegation, and worktree-based isolation.
- Use **Cursor** when the project will rely on rules, multiple agent panes or cloud/remote agent execution, and worktree-first isolated changes.
- Use **Claude Code Subagents** when the project needs deterministic hooks and isolated worktree-oriented subagents, but not a persistent team session.
- Use **Claude Code Agent Teams** only when lead/teammate coordination is materially useful and the overhead is justified.
- Use **Workbuddy Private** only when the project already depends on the existing private Team Mode / proxy sync / dirty-state recovery assumptions.

### Step 2 — Apply the profile config

Copy one file from `config/profiles/` into the active runtime config or reference it through your project bootstrap.

Required questions before activation:

1. What is the coordination model?
2. What is the isolation unit?
3. Who owns external writeback?
4. Who owns cleanup and merge?
5. What collector captures audit evidence?

### Step 3 — Copy the matching starter slice

Use the matching runtime starter from `starters/` and combine it with `starters/shared/`.

Do not mix starter families across runtimes. The shared templates are portable, but the boot instructions and rule-loading entry points are not.

### Step 4 — Run baseline checks

Run these checks before sprint work starts:

- `python scripts/init_runtime_env.py --project-id <id> --runtime-profile <profile>`
- `python scripts/validate_execution_profile.py`
- `python scripts/validate_runtime_paths.py`
- `python scripts/verify_required_content.py`
- `python scripts/run_beta_sprint_check.py`

## Quick selection matrix

| Situation | Recommended profile | Why |
|---|---|---|
| Need explicit delegated workers and worktrees | Codex | Lightest high-control default path |
| Need many agents, remote/cloud options, or editor-centered workflow | Cursor | Best fit for multi-agent editor execution |
| Need strict hooks and subagent lifecycle gates | Claude Code Subagents | Most direct deterministic gate model |
| Need teammates talking to each other | Claude Code Agent Teams | Lead/teammate coordination model |
| Already using private Team Mode semantics | Workbuddy Private | Compatibility layer only |

## Anti-patterns

- Do not call a project “Codex” if execution will really happen in Cursor.
- Do not keep Workbuddy assumptions in the portable core.
- Do not let starter selection happen before profile selection.
- Do not allow external writeback ownership to remain implicit.

## Exit condition

A project passes quickstart setup only when the selected runtime profile, starter family, config, and checklist all point to the same execution model.
