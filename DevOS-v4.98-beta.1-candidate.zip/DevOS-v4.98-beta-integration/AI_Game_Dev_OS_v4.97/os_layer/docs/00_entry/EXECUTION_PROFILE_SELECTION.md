# Execution Profile Selection

> **Terminology note (v4.89)**: the canonical term across v4.89 is **Runtime Profile** (matches `runtime_type` schema field, `docs/06_runtime_profiles/` directory, and `Runtime_Profile_Comparison.md`). This document's filename uses the older `EXECUTION_PROFILE_*` prefix, which remains for now to avoid breaking inbound links; a package-wide RENAME to `RUNTIME_PROFILE_*` was completed during the v4.88_Revise → v4.89 Phase 3 Step 3. Treat the two terms as synonyms in this document.

## Why profiles exist

v4.89 does not assume that one runtime's collaboration semantics can be generalized safely to all others.
Execution must therefore be selected through an explicit **runtime profile**.

## Shared selection fields

Every profile should make the following clear:

- `runtime_type`
- `coordination_model`
- `isolation_unit`
- `writeback_owner`
- `cleanup_owner`
- `merge_mode`
- `rule_loading_entry`
- `context_loading_method`
- `audit_collector`
- `known_limitations`
- `recovery_sop`

## Current profile set

### Codex
Use when explicit subagent delegation, worktree-style isolation, and parent-owned control flow are the preferred model.

### Cursor
Use when parallel agent/worktree execution and reviewed application/merge flow are the preferred model.

### Claude Code Subagents
Use when subagent/worktree isolation plus deterministic hook gates are the preferred model.

### Claude Code Agent Teams
Use only when a lead + teammate coordination model is intentionally required. This path is more coordination-heavy.

### Workbuddy Private
Use only when the project intentionally preserves Workbuddy-derived coordination semantics.
This profile is private and project-proven, not a portable default. It should be reviewed as a complete private profile, not treated as the generic baseline.

## Selection rule

- default to a public runtime profile unless there is a deliberate reason to preserve a private one
- do not project private Workbuddy behavior onto the portable core
- choose the runtime profile **before** choosing the runtime-specific starter
