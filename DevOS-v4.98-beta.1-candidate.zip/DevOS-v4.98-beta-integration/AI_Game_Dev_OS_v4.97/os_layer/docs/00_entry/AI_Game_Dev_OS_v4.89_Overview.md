# AI_Game_Dev_OS v4.89 Overview

## Version Positioning

**v4.87** is the stabilization baseline (consolidation, de-duplication, mainline hardening).

**v4.88 RC12** is the **Tier2 Beta documentation pack** rebuilt from real project evidence. Its strength is the new abstraction (Portable Core + Runtime Profiles + TAPD/Git/Audit baselines); its limit is that the abstraction was specified in docs but not yet wired as runtime.

**v4.89 is the Beta Sprint Exit hardening release** — it carries v4.88 RC12 from "documentation pack" to "runtime-capable pack". v4.89 does not invent new architecture; it lands the missing runtime, contracts, and governance so a Beta Sprint can actually exit clean.

### What v4.89 changes vs v4.88 RC12

| Dimension | v4.88 RC12 | v4.89 |
|---|---|---|
| Permanent contracts | None formalized | **11 contracts** locked across envelope / `_ev_get` / source layers / writeback / quarantine |
| LTM runtime | None | **MVP shipped** — 4 domains / 5 Gate rules / 19 + 4 seed entries / `consult+capture` two-call API |
| Runtime profiles | 5 declared, parity unverified | **5-profile parity** with schema-driven cross-check (110-line if-tree collapsed) |
| Cross-check gate | "field must exist in state" | **"field must exist AND must match"** — init writes full contract surface, eliminates silent-PASS |
| Skills library | Empty | **31 generic-core SKILLs + 12 adaptation hooks** (lexicon-scrubbed) |
| Cold-start | Implicit, project-specific | **Sprint+Agent governance** — 5 registries / manifest / 3 cold-start profiles / 16-key cold_start_pack.v1 |
| Cross-project memory | Single-project | **Layer A namespace** — optional `project_id` YAML + `consult(project_id=...)` + per-project path partition |
| pytest | Documentation only | **259 passed**, self-contained on Release tree |

## Why v4.89 Exists

v4.88 RC12 documented *what* Beta Sprint needs, but a real Beta Sprint Exit kept failing on three classes of issue that docs alone cannot fix:

1. **Contract drift** — envelope shape, `_ev_get` semantics, source-layer enums silently diverged across collectors.
2. **Cross-check loopholes** — `if field in state` short-circuits hid contract-surface gaps; profile swaps left stale state un-caught.
3. **Cross-project knowledge silos** — every project re-derived OS-level pitfalls because there was no LTM lane to write them down or query them from another project.

v4.89 closes all three: 11 contracts (1) + lift gate (2) + LTM runtime + Layer A namespace (3).

## What v4.89 Includes (8 headline deliveries)

1. **11 permanent contracts** — envelope 9-field / `_ev_get` / `_ALLOWED_SOURCE_LAYERS` / `top_level=` bridge / `_resolve_state_path` / helper scope / malformed-audit fallback / canonical-override block / evidence-required quarantine / driver canonical writes / pointer shim.
2. **LTM MVP runtime** — `runtime/ltm/` engine + `ltm/` corpus + 14 pytest. Two-call API `consult / capture` + CLI `python -m runtime.ltm`.
3. **5 runtime profiles at parity** — codex / cursor / claude_teams / claude_subagents / workbuddy_private; identical schema-driven cross-check.
4. **Schema-driven cross-checker** — per-profile if-tree (~110 lines) collapsed to one engine. R1 16-row regression byte-identical pre/post.
5. **Lift gate (M7.3)** — `_stub_init` writes full contract surface canonically; cross-check requires `exist AND match`.
6. **Skills library (M8.0)** — 28 generic + 3 godot + 12 adaptation hooks. RandomHeroes + lessismore source corpus, project lexicon scrubbed (9 forbidden terms grep 0).
7. **Sprint+Agent cold-start governance (M9.0)** — 5 registries + 1 manifest + 3 cold-start profiles + boot wrapper + cold-start pack generator + 48 pytest.
8. **Cross-project LTM Layer A (M9.5)** — optional `project_id` YAML + `consult(project_id=...)` + Gate rule 5 + `ltm/project/<id>/` partition + cross-ingest skeleton + 8 namespace pytest.

## What v4.89 Does Not Include (deferred to v4.90+)

Explicitly **not** in scope:

- **Layer B retrieval upgrade** — SQLite FTS5 / `sqlite-vec` vector search.
- **Layer C self-evolution** — `replay()` / auto-promotion of cross-project patterns / Evolution Roadmap ②.
- **Cross-project platform step** — Evolution Roadmap ④.
- **TAPD / Git live adapters** — currently normalize stubs.
- **Architecture Linter A / B / D rules** — only rule C ships.
- **Exit Verifier GUIDED tier** — currently SCAFFOLD.
- **`top_level=` bridge true removal** — kept as deprecated dual-write through v4.89.

See `docs/V4.89_BACKLOG.md` for the full v4.90 routing list.

## How v4.89 Inherits v4.88

v4.89 inherits all v4.88 RC12 abstractions verbatim and adds runtime underneath:

- **Portable Core + Runtime Profiles** (v4.88 §1) — preserved; v4.89 adds the parity check that proves the split actually holds.
- **TAPD + Git fixed for this round** (v4.88 §2.2) — preserved; v4.89 keeps adapters as normalize stubs (live wiring in v4.90).
- **Truth model** (code > evidence > registry for correctness; registry > evidence > code for operational state) — preserved; v4.89 LTM runtime sits on top of evidence layer, never overrides it.
- **Tier2 Beta validation standard** (v4.88 §8) — preserved as orientation; v4.89 supersedes it with **Beta Sprint Exit gate** (E1-E7 green on `workbuddy_private` reference, schema-driven cross-check pass on all 5 profiles, pytest 259, lexicon scrub clean).

The v4.88 RC12 byte-lock (`AI_Game_Dev_OS_v4.88_Release/`, SHA `58346b3`, 539 files) remains unchanged. The Tier vocabulary itself may be retired in v4.90+; v4.89 keeps the label only as continuity with v4.88's Phase 4 plan.

## Validation Standard (v4.89)

For v4.89, document completeness alone is not enough. The release acceptance gate is:

- **pytest 259 green** on both dev tree (`AI_Game_Dev_OS_v4.89/`) and release tree (`AI_Game_Dev_OS_v4.89_Release/`)
- **`shasum -c CHECKSUMS.sha`** clean on the Release tree
- **5-profile schema-driven cross-check** all green (`test_verify_*_cross_check.py` + `test_schema_driven_equivalence.py`)
- **Lexicon scrub** zero matches across `ltm/project/`, `skills/_generic_core/`, `skills/_engine_specific/`
- **Beta Sprint Exit E1-E7** green on `workbuddy_private` reference profile
- **Real-corpus consult spot check** — at least 1 hit for representative cross-project queries

## Run Path Pointers

For onboarding (read in order):

1. `docs/00_entry/START_HERE.md` — 5-minute entry.
2. `docs/00_entry/AI_Game_Dev_OS_v4.89_Overview.md` — this file.
3. `docs/00_entry/AI_Game_Dev_OS_v4.89_Master_Outline.md` — full chapter map.
4. `RELEASE_NOTES.md` — RC1 narrative + 8 headline features + verification checklist.
5. `USER_GUIDE.md` — EP onboarding (5 + 15 min).
6. `ASSEMBLY_GUIDE.md` — loading order + stage policy.
7. `runtime/MATURITY_MATRIX.md §3.x` — per-phase maturity ledger.
8. `docs/06_runtime_profiles/PHASE_4_*.md` — audit docs for M7.3 / M8.0 / M9.0 / M9.5.
