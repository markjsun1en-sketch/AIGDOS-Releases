# RETRIEVAL_POLICY — Layer 1 retrieval policy reference

> **Layer 1 (OS Spec).** No project-specific names. v4.91 B4 c4.
>
> **Schema**: [`schemas/ltm/retrieval_policy.schema.json`](../../schemas/ltm/retrieval_policy.schema.json) (1.0.0).
>
> **Default instance**: [`ltm/retrieval_policy.yaml`](../../ltm/retrieval_policy.yaml) (v4.91 B4 c2).
>
> **Sister docs**: [`SHARED_LTM_V3_OVERVIEW.md`](SHARED_LTM_V3_OVERVIEW.md) · [`ROUTING_REPORT.md`](ROUTING_REPORT.md).

---

## 1. Purpose

A retrieval_policy declares which scope categories the v3 read pipeline
**includes** in default retrieval and which it **excludes**. It also
controls scope-level scoring boosts and the maximum result count. It
is **not** a per-query knob — projects MAY override the policy file
path via `--policy` but MAY NOT override the policy semantics.

Per Charter anti-pattern #7, the policy file CANNOT carry override
fields for cross-project private inclusion. The schema enforces this
at compile time:

- `tenancy_enforcement.mode` is enum-locked to a single value (`strict`)
- No `override_*` / `allow_*_for_project` / `bypass_*` field exists
- `default_include[]` and `default_exclude[]` enums explicitly do
  NOT contain `other_project_private` (it is hard-excluded by the
  router before policy is consulted)

---

## 2. Required fields

| Field | Type | Notes |
|---|---|---|
| `schema_version` | string const `"1.0.0"` | Bumped only when contract shape changes |
| `version` | string | Free-form policy revision tag (e.g. `"1.0.0"`, `"2026-05-20-rc1"`); appears in `routing_report.policy_version` for audit |
| `default_include` | array of scope tokens | Subset of {current_project, os, approved_cross_project, pattern, failures} |
| `default_exclude` | array of scope tokens | Subset of {other_project_private, quarantine, rejected, unapproved_candidates, superseded} |

`default_include` and `default_exclude` MUST NOT overlap. The router
treats unknown scopes as `unknown` — they are excluded by default.

---

## 3. Optional fields

### 3.1 `ranking`

| Field | Type | Default | Effect |
|---|---|---|---|
| `boost_current_project` | number ≥ 0 | 1.5 | Multiplier on raw match count for `current_project` matches |
| `boost_os` | number ≥ 0 | 1.0 | Multiplier for `os` |
| `boost_approved_cross_project` | number ≥ 0 | 0.8 | Multiplier for `approved_cross_project` (intentionally < 1.0 to avoid drowning project context) |
| `max_results` | integer ≥ 1 | 20 | Truncates ranked list |

Boosts only re-rank — they never promote content into a new scope
(Charter anti-pattern #6).

### 3.2 `tenancy_enforcement`

| Field | Type | Notes |
|---|---|---|
| `mode` | enum `["strict"]` | Schema-locked single value. `lenient` deliberately absent (Charter anti-pattern #7) |

Future versions MAY add audit modes (e.g. `strict_with_warn`) by
bumping `schema_version` and updating `inv_002` evidence; they MUST
NOT add `lenient`.

---

## 4. Default policy

`ltm/retrieval_policy.yaml` ships with:

```yaml
schema_version: "1.0.0"
version: "1.0.0"

default_include:
  - current_project
  - os
  - approved_cross_project
  - pattern
  - failures

default_exclude:
  - other_project_private
  - quarantine
  - rejected
  - unapproved_candidates
  - superseded

ranking:
  boost_current_project: 1.5
  boost_os: 1.0
  boost_approved_cross_project: 0.8
  max_results: 20

tenancy_enforcement:
  mode: "strict"
```

This is the policy projects get unless they pass `--policy <path>`
to `retrieve_with_routing.py`. The shipped values are calibrated so
that:

- A project's own past learnings win over generalisations (1.5 vs 0.8)
- OS-level guidance is neutral (1.0)
- Quarantine + unapproved candidates never appear in default reads
- Audit-only scopes (rejected, superseded) never re-surface

---

## 5. Override discipline

What a project MAY do:

- Ship its own `<project>/.ai_dev_os/retrieval_policy.yaml` and pass it
  via `--policy`
- Tighten exclusions (e.g. add `pattern` to `default_exclude` if its
  pattern dir contains experimental noise)
- Lower boosts (e.g. `boost_current_project: 1.0` for projects with
  weak local memory)

What a project MAY NOT do:

- Add `other_project_private` to `default_include`
  (schema enum rejects this)
- Set `tenancy_enforcement.mode` to anything other than `strict`
  (schema enum rejects this)
- Add an `override_*` or `allow_other_project_*` field
  (schema additionalProperties=false rejects this)

If a future workflow legitimately needs cross-project private read
access, the path is: **promote** the relevant entry through
`promote_memory_candidate.py --to cross_project` (v4.90 Batch 8) so
it lands in `cross_project/approved_patterns/`. There is no shortcut.

---

## 6. Versioning

`schema_version` (the contract version) is independent of `version`
(the policy revision tag).

- Bump `schema_version` only when the contract shape changes
  (new required field, removed field, or enum value removal). Add
  an `inv_002` evidence row whenever this happens.
- Bump `version` whenever you change the policy values (different
  boosts, different exclusions). The router records this in every
  `routing_report.policy_version` so audits can trace which policy
  produced which routing decision.

---

## 7. Charter alignment

- **#2** Scope categories never embed project literals
- **#6** No promotion field; boosts only re-rank
- **#7** No override flags for cross-project private inclusion
- **#11** Policy never references preflight cases as evidence
- **#12** No vote / consensus surface in policy
