# SHARED_LTM_V3_OVERVIEW — Shared LTM v3 Read-Side Pipeline

> **Layer 1 (OS Spec).** No project-specific names. v4.91 B4 c4.
>
> **Schemas**: `schemas/ltm/{retrieval_policy,routing_report,preflight_case,preflight_metric}.schema.json` (all 1.0.0).
>
> **CLIs**: `scripts/ltm/{retrieve_with_routing,generate_routing_report}.py` (v4.91 B4 c2).
>
> **Default policy**: `ltm/retrieval_policy.yaml` (v4.91 B4 c2).
>
> **Sister docs**: [`RETRIEVAL_POLICY.md`](RETRIEVAL_POLICY.md) · [`ROUTING_REPORT.md`](ROUTING_REPORT.md).
>
> **Predecessor**: v4.90 Batch 8 LTM v2 (`docs/15_ltm_v2/`) — domain-level priority routing. v3 adds **scope-level** routing as a sibling, not a replacement.

---

## 1. Why v3

LTM v2 routes by **domain priority** (failures first, then patterns,
then OS, then project-specific) — works well when callers know which
domain to ask. But it does not enforce tenancy boundaries, and it
assumes a single project. v4.91 introduces multi-project hub semantics
(B1) and tenancy contracts (F-T-01) that demand a stricter
**scope-level** read pipeline:

- Each retrieval has an explicit `calling_project_id` POV
- Cross-project private content (`other_project_private`) is **always**
  excluded — no override flag, no override env var
- Routing decisions are auditable (`routing_report.skipped_paths[]`
  carries denied paths with reason codes)

v3 leaves v2 untouched: `config/memory_retrieval_routing_v2.yaml`
remains the domain-priority surface; `ltm/retrieval_policy.yaml` is
the new scope surface. The two routes are **orthogonal**, not
substitutive.

---

## 2. Scope vocabulary (9 categories)

The router classifies each `*.md` under `<ltm_root>/` into one
of nine scope categories:

| Scope | Source path pattern | Default route |
|---|---|---|
| `current_project` | `project/<calling_project_id>/**` | include + boost 1.5x |
| `os` | `os/**` | include + boost 1.0x |
| `approved_cross_project` | `cross_project/**` (top-level or `approved_patterns/`) | include + boost 0.8x |
| `pattern` | `pattern/**` | include |
| `failures` | `failures/**` | include |
| `other_project_private` | `project/<other_id>/**` | **always exclude** (hard isolation) |
| `quarantine` | `_quarantine/**` | exclude |
| `unapproved_candidates` | `cross_project/candidates/**` | exclude |
| `rejected` | `cross_project/rejected/**` | exclude |
| `superseded` | `cross_project/superseded/**` | exclude |

The `default_include[]` and `default_exclude[]` arrays in
`retrieval_policy.yaml` reference these scope tokens. `other_project_private`
is **not** an enum value users can flip into `default_include` — the
router hard-excludes it before consulting the include list.

---

## 3. Read flow

```
caller invokes:
  scripts/ltm/retrieve_with_routing.py
    --query "<text>"
    --project-id <calling>
    [--policy ltm/retrieval_policy.yaml]
    [--ltm-root ltm/]

  ┌──────────────────────────────────────┐
  │ load policy → validate include/exclude
  │ enums against the 9-scope vocabulary │
  └──────────────┬───────────────────────┘
                 ▼
  ┌──────────────────────────────────────┐
  │ walk ltm/**/*.md                     │
  │ for each path:                       │
  │   scope = _classify_path(rel,        │
  │              calling_project_id)     │
  │   if scope == other_project_private: │
  │     skipped(tenancy_reconciliation_  │
  │             failed)                  │
  │   elif scope in default_exclude:     │
  │     skipped(scope_excluded)          │
  │   elif scope not in default_include: │
  │     skipped(scope_excluded)          │
  │   else:                              │
  │     score = match_count × boost      │
  │     candidates.append((path, score)) │
  └──────────────┬───────────────────────┘
                 ▼
  ┌──────────────────────────────────────┐
  │ sort by score desc; truncate at      │
  │ ranking.max_results (default 20)     │
  └──────────────┬───────────────────────┘
                 ▼
  ┌──────────────────────────────────────┐
  │ build routing_report:                │
  │   schema_version, report_id, query,  │
  │   calling_project_id, generated_at,  │
  │   policy_version, scopes_*[],        │
  │   results[], skipped_paths[]         │
  │ validate against routing_report      │
  │   schema (best-effort jsonschema)    │
  └──────────────┬───────────────────────┘
                 ▼
  stdout JSON: {routing_report, ranked_results}
```

`generate_routing_report.py` runs steps 1+5 only — useful for policy
debugging and B5B preflight pre-warm without paying retrieval cost.

---

## 4. Charter alignment

| # | Anti-pattern | v3 enforcement point |
|---|---|---|
|  2 | Project names in Core | Scope vocabulary uses category tokens, never project literals |
|  6 | Evidence-threshold auto-promote | Scoring boosts ranking position; never moves content across scopes |
|  7 | --allow-extra / --skip-tenant escape hatches | No `--include-other-project` / `--allow-cross-project` / `--bypass-isolation` flags exist; `tenancy_enforcement.mode` schema enum is single-valued (`strict`) |
| 11 | Preflight as gate-pass | `preflight/**` is NOT a retrieval scope; it is operational data, not learning material |
| 12 | Preflight majority-vote | `preflight_case.consensus.decided_by` is a single string (no `votes[]`); `preflight_metric` has no promotion field |

The router is **read-only**: it never mutates `ltm/`, `hub/`, or any
state file. Cross-project promotion still goes through
`scripts/ltm/promote_memory_candidate.py` (v4.90 Batch 8), which
remains the only legitimate write path into `cross_project/approved_patterns/`.

---

## 5. Forward-compat hooks

The 4 schemas land at 1.0.0 in B4 c1; the 2 preflight schemas
(`preflight_case`, `preflight_metric`) are forward-compat for M-C
B5B. M-B can extend them without revisiting B4:

- `consensus.decided_by`: stays a single string
- `votes[]`: never appears
- `promotion_*`: never appears on `preflight_metric`

If B5B needs a richer outcome surface, it bumps the schema version
**and** adds an `inv_002 must_preserve` row to record the new contract.

---

## 6. Where to look next

- [`RETRIEVAL_POLICY.md`](RETRIEVAL_POLICY.md) — reference for the
  policy file shape + override discipline
- [`ROUTING_REPORT.md`](ROUTING_REPORT.md) — output shape + audit
  obligations
- `policies/charter_anti_patterns.md §#7` — the boundary contract
  v3 enforces
- `docs/19_tenancy/TENANCY_CONTRACT.md` — F-T-01 path-level boundary
  (v3 honours this when classifying `project/<id>/**` paths)
- `docs/15_ltm_v2/MEMORY_DOMAINS_v2.md` — sibling v2 domain model
