# PROMOTION_LIFECYCLE — Memory candidate write-side state machine

> **Layer 1 (OS Spec).** No project-specific names. v4.91 B5 c4.
>
> **Schemas**: [`schemas/ltm/promotion_policy.schema.json`](../../schemas/ltm/promotion_policy.schema.json) · [`promotion_ledger.schema.json`](../../schemas/ltm/promotion_ledger.schema.json) · [`reject_ledger.schema.json`](../../schemas/ltm/reject_ledger.schema.json) · [`supersede_ledger.schema.json`](../../schemas/ltm/supersede_ledger.schema.json) (all 1.0.0).
>
> **CLIs**: [`promote_memory_candidate.py`](../../scripts/ltm/promote_memory_candidate.py) · [`reject_memory_candidate.py`](../../scripts/ltm/reject_memory_candidate.py) · [`supersede_memory_candidate.py`](../../scripts/ltm/supersede_memory_candidate.py).
>
> **Default policy**: [`ltm/promotion_policy.yaml`](../../ltm/promotion_policy.yaml).
>
> **Sister docs**: [`SHARED_LTM_V3_OVERVIEW.md`](SHARED_LTM_V3_OVERVIEW.md) · [`RETRIEVAL_POLICY.md`](RETRIEVAL_POLICY.md) · [`ROUTING_REPORT.md`](ROUTING_REPORT.md).
>
> **Predecessors**: v4.90 Batch 8 promote_memory_candidate.py (G1-G5 gate); v4.91 B4 (Shared LTM v3 read pipeline).

---

## 1. State machine

A memory candidate has **exactly one** terminal state per lifecycle. A
canonical entry, once promoted, may later be **superseded** by a
newer canonical entry. Reject and supersede are not the same — see §6.

```
        sprint_close /
        extract_failure_candidates / sprint_handoff
                  │
                  ▼
        ┌──────────────────────┐
        │  ltm/_quarantine/    │
        │  <candidate_id>.json │  (memory_candidate envelope, schema 1.0.0)
        └─────────┬────────────┘
                  │
        promote_memory_candidate.py
        (gate: G1-G5 + forbidden_approvers + threshold + policy)
                  │
       ┌──────────┴──────────┐
       │                     │
       ▼                     ▼
  ┌─────────┐         ┌─────────────────────────────┐
  │ promoted│         │ rejected (reject CLI)       │
  └────┬────┘         │  -> ltm/cross_project/      │
       │              │     rejected/<id>.json      │
       │              │  + .rejected.json ledger    │
       │              │  (default-excluded by       │
       │              │   retrieval policy;         │
       │              │   audit retention only)     │
       │              └─────────────────────────────┘
       ▼
  ┌──────────────────────────────────────────────┐
  │ canonical entry under one of:                │
  │   ltm/failures/<date>_<id>.md                │
  │   ltm/pattern/<date>_<id>.md                 │
  │   ltm/os/<date>_<id>.md                      │
  │   ltm/cross_project/approved_patterns/...    │  (v4.91 v3)
  │   ltm/cross_project/<id>.md (top-level)      │  (v4.90 backward compat)
  │   ltm/project/<project_id>/<date>_<id>.md    │
  │ + sibling .promoted.json ledger              │
  └────┬─────────────────────────────────────────┘
       │
       │  newer canonical entry promoted later
       │  (a different candidate with its own ledger)
       │
       ▼
  ┌─────────────────────────────────────────────┐
  │ supersede_memory_candidate.py               │
  │  (audit chain: replacing_entry_ledger_ref   │
  │   pattern '^promote_*' + runtime check)     │
  │   -> ltm/cross_project/superseded/<file>.md │
  │   + .superseded.json ledger sidecar         │
  │   (default-excluded by retrieval policy;    │
  │    audit retention only)                    │
  └─────────────────────────────────────────────┘
```

**Three terminal states** (per candidate or canonical entry):

| State | Anchor | Retrieval default |
|---|---|---|
| **Promoted** | sibling `.promoted.json` ledger | included (boost depends on scope) |
| **Rejected** | sibling `.rejected.json` ledger | excluded |
| **Superseded** | sibling `.superseded.json` ledger | excluded |

A single candidate cannot occupy two terminal states simultaneously.
Idempotency is enforced at the CLI level via the candidate envelope's
`approver` / `rejected_by` field (promote / reject) or via the
target-path + ledger-sidecar coexistence (supersede).

---

## 2. Gates (the five enforced rules)

| # | Rule | Where enforced |
|---|---|---|
| **G1** | `--approver` (promote) / `--rejected-by` / `--superseded-by` non-empty AND not in `policy.approval.forbidden_approvers` | runtime CLI + schema enum-lock on `policy.approval.mode='strict'` |
| **G2** | `evidence_ref` non-empty list (promote only) | runtime CLI |
| **G3** | `cross_project` promotion: `len(set(evidence_ref)) >= policy.thresholds.cross_project_min_evidence_refs` (default 2; bounded 2..16) | runtime CLI; schema int 2..16 |
| **G4** | `proposed_entry` validates against the target domain's schema (today only `failures/` has a strict schema) | runtime CLI |
| **G5** | `failures/` promotion: `proposed_body` contains all 4 H2 sections (`## Symptom`, `## Root Cause`, `## Fix`, `## Lesson`) | runtime CLI |

A sixth implicit rule for supersede:

| **G6** | `--replacing-entry-ledger` MUST exist, parse, have `event_type='promoted'`, AND `ledger_id` MUST match `^promote_[a-z0-9_]*$` | runtime CLI + supersede_ledger schema cross-ref |

The G3 threshold is a Layer 1 policy field, NOT a CLI flag. There is
**no** `--threshold-override` (Charter anti-pattern #6).

---

## 3. Charter alignment

| # | Anti-pattern | Lifecycle enforcement |
|---|---|---|
|  6 | Evidence-threshold auto-promote | G3 threshold sourced from policy; schema integer-bounded 2..16 (no MAX_INT bypass); no `auto_promote` field exists in any schema |
|  7 | `--allow-extra` / `--skip-tenant` escape hatches | All 3 CLIs lack `--bypass-policy` / `--skip-forbidden` / `--allow-extra`; `policy.approval.mode` enum-locked to single value `strict`; `additionalProperties: false` on all 4 schemas |
| 11 | Preflight as gate-pass | promotion_ledger.event_type, reject_ledger.event_type, supersede_ledger.event_type are each const-disjoint (`promoted` / `rejected` / `superseded`); no schema entry maps preflight to gate-pass |
| 12 | Preflight majority-vote | All 3 ledger schemas have a SINGLE-string approver field (`promoted_by` / `rejected_by` / `superseded_by_user`); no `votes[]` field exists in any schema |
| Audit chain | (lifecycle-specific) | supersede_ledger.replacing_entry_ledger_ref pattern `^promote_[a-z0-9_]*$` + runtime double-check ensures every supersede traces to a real promotion |

---

## 4. Ledger conventions

### 4.1 Ledger ID format

Each lifecycle event produces a ledger with a type-disjoint id prefix:

- promote → `promote_<candidate_id_slug>_<yyyymmdd>_<hhmmss>`
- reject → `reject_<candidate_id_slug>_<yyyymmdd>_<hhmmss>`
- supersede → `supersede_<superseded_candidate_id_slug>_<yyyymmdd>_<hhmmss>`

The disjoint prefixes let postmortem `grep -E '^"ledger_id":' ledgers/`
tell the three histories apart in one pass.

### 4.2 Ledger sidecar location

| CLI | Source path | Sidecar path |
|---|---|---|
| promote | `_quarantine/<id>.json` | `_quarantine/<id>.promoted.json` |
| reject | `_quarantine/<id>.json` | `_quarantine/<id>.rejected.json` |
| supersede | `<canonical_path>.md` | `<superseded_to_path>.superseded.json` |

The candidate envelope itself is also stamped:

- promote → `candidate.approver = <approver>`
- reject → `candidate.rejected_by = <rejector>`
- supersede → (no field on the canonical entry; the sidecar at the
  superseded location is the truth)

### 4.3 Ledger schema-version policy

All 3 ledger schemas are at 1.0.0. Bump triggers:

- Add a required field → 2.0.0 + must_preserve evidence row update
- Remove an enum value → 2.0.0 + must_preserve evidence row update
- Add an optional field → still 1.0.0 (forward-compat)

When a bump happens, each lifecycle CLI also bumps the
`schema_version` it writes; the sibling test suite asserts schema
version round-trip.

---

## 5. CLI matrix

| CLI | Required flags | Idempotency anchor | Exit codes |
|---|---|---|---|
| `promote_memory_candidate.py` | `--candidate` `--to {failures,pattern,os,cross_project,project}` `--approver` | `candidate.approver != null` | 0 OK / 1 gate / 2 dir / 3 internal / 4 input |
| `reject_memory_candidate.py` | `--candidate` `--reason {7-enum}` `--rejected-by` | `candidate.rejected_by != null` | 0 OK / 1 gate / 2 dir / 3 internal / 4 input |
| `supersede_memory_candidate.py` | `--superseded-entry` `--replacing-entry-ledger` `--superseded-by` | target moved + ledger sidecar both present | 0 OK / 1 gate / 2 path / 3 internal / 4 ledger invalid |

All 3 accept `--ltm-root <path>` (default `<repo>/ltm`) and
`--format {text,json}` (default `text`). All 3 read
`<ltm-root>/promotion_policy.yaml` for thresholds + forbidden_approvers
+ supersede.must_reference_replacing_entry; defaults are used when the
file is missing.

All 3 have `--rationale` as optional free-form context; mandatory in
practice for `low_quality` / `policy_violation` rejections and for
every supersede event.

---

## 6. Reject vs supersede — when to use which

A common confusion: both move content to a default-excluded
sub-directory. The distinction:

- **Reject** = "this candidate should not become a canonical entry."
  The source candidate stays in `_quarantine/` (so re-running reject is
  idempotent), but a copy lands in `cross_project/rejected/` for
  audit retention. The candidate is **never** promoted to any
  inclusion scope.

- **Supersede** = "this candidate WAS promoted, but a newer entry
  replaces it." The original canonical entry is moved out of its
  inclusion scope into `cross_project/superseded/`. There MUST be a
  replacing canonical entry (with its own promotion_ledger) — supersede
  is the **continuation** of a promotion lifecycle, not a do-over.

| Question | Reject | Supersede |
|---|---|---|
| Does the source candidate have a promotion_ledger? | NO (reject blocks promotion) | YES (supersede happens after promotion) |
| Is there a replacing entry? | n/a | REQUIRED (audit chain lock) |
| Is the source candidate retained in _quarantine? | YES (idempotency anchor) | n/a (no candidate, only canonical entry) |

If you find yourself wanting "reject this canonical entry":

1. Run `supersede_memory_candidate.py` against it
2. Without a replacing entry, the gate refuses (G6) — that is the
   intended behaviour. To remove a canonical entry without a
   replacement, you SHOULD generate a "minor cleanup" candidate +
   promote it + then supersede the old one.

---

## 7. Audit recipe

To answer "what's the full history of candidate `mc_<id>`?":

```bash
# 1. Promote / reject sidecar in _quarantine/
cat ltm/_quarantine/mc_<id>.json
cat ltm/_quarantine/mc_<id>.promoted.json   # if promoted
cat ltm/_quarantine/mc_<id>.rejected.json   # if rejected

# 2. Find the canonical entry (if promoted)
ledger_path=$(jq -r '.promoted_to_path' ltm/_quarantine/mc_<id>.promoted.json)
ls -l "$ledger_path"

# 3. Was the canonical entry ever superseded?
find ltm/cross_project/superseded/ -name '*.superseded.json' \
  -exec jq -r '
    select(.replacing_entry_ledger_ref ==
           "promote_<id>_<ts>")
    | "superseded_at: \(.superseded_at) by \(.superseded_by_user)"
  ' {} \;

# 4. Cross-grep the 3 ledger families
grep -rE '"ledger_id": "(promote|reject|supersede)_<id_slug>' ltm/
```

The 3-prefix `^(promote|reject|supersede)_` ledger_id pattern is the
single grep that surfaces the entire lifecycle.

---

## 8. Where to look next

- [`SHARED_LTM_V3_OVERVIEW.md`](SHARED_LTM_V3_OVERVIEW.md) — the read-side companion (B4)
- [`RETRIEVAL_POLICY.md`](RETRIEVAL_POLICY.md) — `default_include`/`exclude` enums that govern which scopes promotions land in
- [`ROUTING_REPORT.md`](ROUTING_REPORT.md) — how a promotion's destination scope influences future retrievals
- `policies/charter_anti_patterns.md` §6 §7 §11 §12 — the contracts B5 enforces
- `docs/15_ltm_v2/PROMOTION_WORKFLOW.md` — v4.90 Batch 8 predecessor (still authoritative for the G1-G5 baseline)
