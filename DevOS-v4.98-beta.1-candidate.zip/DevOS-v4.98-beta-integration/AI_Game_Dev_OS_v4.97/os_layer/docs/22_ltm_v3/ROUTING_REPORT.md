# ROUTING_REPORT — v3 routing report contract reference

> **Layer 1 (OS Spec).** No project-specific names. v4.91 B4 c4.
>
> **Schema**: [`schemas/ltm/routing_report.schema.json`](../../schemas/ltm/routing_report.schema.json) (1.0.0).
>
> **Producers**: [`scripts/ltm/retrieve_with_routing.py`](../../scripts/ltm/retrieve_with_routing.py) (full retrieval) · [`scripts/ltm/generate_routing_report.py`](../../scripts/ltm/generate_routing_report.py) (routing-only dry-run).
>
> **Sister docs**: [`SHARED_LTM_V3_OVERVIEW.md`](SHARED_LTM_V3_OVERVIEW.md) · [`RETRIEVAL_POLICY.md`](RETRIEVAL_POLICY.md).

---

## 1. Purpose

Every v3 retrieval emits a `routing_report` — the auditable record of
which policy was applied, which scopes were considered, which paths
matched, and **which paths were rejected and why**. The skipped paths
audit trail is the cornerstone of Charter anti-pattern #7 enforcement:
denied cross-project reads are never silently dropped.

---

## 2. Required fields

| Field | Type | Notes |
|---|---|---|
| `schema_version` | string const `"1.0.0"` | Contract version |
| `report_id` | string | Pattern `^routing_[a-z0-9_]{3,120}$`; producers slugify the project_id + query + timestamp into this |
| `query` | string | Verbatim caller query (1..1024 chars) |
| `calling_project_id` | string | Lower-snake-case project ID; pattern `^[a-z][a-z0-9_]*$`, length 2..64 |
| `generated_at` | string ISO-8601 UTC | `YYYY-MM-DDThh:mm:ssZ` |
| `policy_version` | string | Mirrors `retrieval_policy.yaml :: version`; lets audits trace which policy produced this report |
| `scopes_included` | array of scope tokens | Snapshot of `policy.default_include` at report time |
| `scopes_excluded` | array of scope tokens | Snapshot of `policy.default_exclude` at report time |
| `results` | array | Final ranked output; MAY be empty (auditable no-match) |
| `skipped_paths` | array | Paths that were considered but rejected — see §4 |

---

## 3. results[] item shape

| Field | Type | Notes |
|---|---|---|
| `path` | string | Path relative to `<ltm_root>/` |
| `score` | number ≥ 0 | Boosted match count; higher is better |
| `scope` | string | One of the 9 scope tokens (see SHARED_LTM_V3_OVERVIEW §2) |

`results` is sorted by `score` desc then `path` asc, then truncated
at `policy.ranking.max_results`.

---

## 4. skipped_paths[] item shape (audit trail)

| Field | Type | Notes |
|---|---|---|
| `path` | string | Path relative to `<ltm_root>/` |
| `scope` | string (optional) | The scope category that triggered the skip (audit aid; not part of the strict reason enum) |
| `reason` | enum | Why the path was rejected — see table below |
| `detail` | string (optional) | Free-form context (e.g. exception message for `schema_invalid`) |

### Reason enum

| Reason | Meaning | Typical scope |
|---|---|---|
| `tenancy_reconciliation_failed` | Path resolved to a different project's private tree | `other_project_private` |
| `scope_excluded` | Scope is in `default_exclude` (or not in `default_include`) | quarantine, rejected, superseded, unapproved_candidates |
| `schema_invalid` | Path's content did not validate against its expected envelope | (B5+ only) |
| `missing_evidence_ref` | Path lacked an `evidence_ref` field that the router required | (B5+ only) |

`tenancy_reconciliation_failed` is the **mandatory** category for
cross-project private denials. The router emits this even when the
caller did not ask for the path explicitly — every walk-step that
encounters `project/<other_id>/**` MUST be recorded here, never
silently dropped.

---

## 5. Validation

The default producer (`retrieve_with_routing.py`) best-effort imports
`jsonschema` and runs `jsonschema.validate(report, routing_report_schema)`
before printing. If `jsonschema` is unavailable in the runtime, the
report is still emitted (router never fails closed on a missing
optional dep), but consumers SHOULD validate at their boundary.

A `routing_report` that fails schema validation is a producer bug,
not a runtime data error.

---

## 6. Audit obligations

When a future incident postmortem asks "did the system leak project
A's content into project B's read?", the answer lives in:

1. The `routing_report.skipped_paths` array of the relevant retrieval
2. Greppable for `reason: tenancy_reconciliation_failed`

If `skipped_paths` is empty AND `results` contains paths under
`project/<other_id>/**`, that is a Charter anti-pattern #7 violation
and the router has a bug. Tests in `tests/ltm/` (B4 c5) lock this
contract end-to-end.

---

## 7. Backward compat

`schema_version 1.0.0` requires `path` + `reason` in skipped_paths
items; `scope` and `detail` are optional. Producers MAY add new
optional fields; consumers MUST ignore unknown fields per the
schema's `additionalProperties` policy on the item.

`results[]` items follow the same forward-compat pattern.

The schema bumps to 2.0.0 only when:

- A required field is removed
- A reason enum value is removed
- The `additionalProperties` policy tightens

Each bump triggers an `inv_002 must_preserve` row update.

---

## 8. Charter alignment

- **#2** Scope tokens (not project literals) appear in `scopes_*[]`
- **#6** No promotion side-effect; report is read-only
- **#7** Mandatory `skipped_paths` audit for cross-project denials
- **#11** No preflight verdict surface in routing_report
- **#12** No vote tally in routing_report
