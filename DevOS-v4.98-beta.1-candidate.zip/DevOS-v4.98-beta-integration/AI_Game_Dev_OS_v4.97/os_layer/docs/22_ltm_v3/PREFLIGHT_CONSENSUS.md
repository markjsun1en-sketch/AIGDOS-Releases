# PREFLIGHT_CONSENSUS — Multi-Agent preflight gate state machine

> Layer 1 (OS Spec). v4.91 Milestone B, Batch 5B (B5B). Sibling to
> `PROMOTION_LIFECYCLE.md` (B5 write-side LTM gate). This document
> describes how the v4.91 Hub refuses to advance `bound_version`
> through `lock_core_version` until each major-class `update_plan`
> has earned a recorded **EP-decided** consensus outcome of
> `approved`.
>
> The schemas backing this lifecycle:
>
> * `schemas/ltm/preflight_case.schema.json` (1.0.0, B4 c1) —
>   **case envelope** — captures one preflight invocation: the
>   trigger that fired, the consulting roles, the consensus outcome.
> * `schemas/ltm/preflight_metric.schema.json` (1.0.0, B4 c1) —
>   **metric envelope** — operational characteristics of one case
>   (elapsed seconds, role count, mirrored outcome).
> * `schemas/ltm/preflight_policy.schema.json` (1.0.0, B5B c1) —
>   **policy envelope** — Layer 1 declaration of the 10
>   forbidden-decider tokens, the locked `allowed_outcomes` triple,
>   and the `lock_gate.block_lock_when_outcome_not_approved` const
>   guard.
> * `schemas/ltm/preflight_consensus_event_ledger.schema.json`
>   (1.0.0, B5B c1) — **event ledger envelope** — const-disjoint
>   peer to `promotion_ledger` / `reject_ledger` / `supersede_ledger`.
>
> All four schemas are forward-compat-frozen at 1.0.0; any future
> revision MUST go through a separate Addendum-style 1.x bump
> (per Charter anti-pattern #4: extend, don't replace).

---

## 1. State machine

A preflight case lives in **three** observable states. The wire-level
shape is always `preflight_case.schema.json`-valid; the state is
encoded by the `consensus.outcome` and `consensus.decided_by` fields.

```
                                                  +-------------+
                                                  |   missing   |  <- no case file
                                                  +------+------+
                                                         |
                                                  init-stub
                                                         |
                                                         v
                       +------- finalize -------- +-------------+
                       |  outcome=approved        |   stubbed   |  consensus.outcome="deferred"
                       |  decided_by=<EP id>      |   (open)    |  consensus.decided_by="pending"
                       v                          +------+------+
            +---------------------+                      |
            |     finalized       |                      | finalize
            |     (closed)        |                      |  outcome=rejected | deferred
            +---------------------+                      |  decided_by=<EP id>
            consensus.outcome ∈                          |  + rationale
                {approved,                               v
                 rejected,                  +-----------------------+
                 deferred}                  |   finalized (closed)  |
            decided_by != "pending"         |   blocks the lock     |
                                            +-----------------------+
```

The single binding constraint enforced by `lock_core_version`
(B5B c3): a case is **lock-passing** **iff**

* `consensus.outcome == "approved"` **AND**
* `consensus.decided_by != "pending"`.

Any other shape — `outcome=="rejected"`, `outcome=="deferred"`,
missing case file, or the corrupt `outcome="approved" + decided_by="pending"`
combination — refuses the lock with `EXIT_PREFLIGHT_NOT_APPROVED (5)`.

## 2. Gates (the four enforced rules)

The preflight runtime CLI (`scripts/ltm/run_preflight_consensus.py
finalize`) refuses any input that fails **all four** rules below.

### G1 — `decided_by` shape

```
^[a-z][a-z0-9_]*$  (length 2..40)
```

The same two-stage `pattern + minLength + maxLength` form used by
the B5 ledger family — sidesteps the `{n,m}` quantifier trap noted
in MEMORY (B4 c5 lesson). A bare `e` is rejected; `ep` is accepted.

### G2 — `decided_by` not in `forbidden_deciders`

The default 10-token vocabulary, declared in
`ltm/preflight_policy.yaml::approval.forbidden_deciders`:

```
auto, system, agent, automation, robot, ci,        ← inherited from
                                                     promotion_policy (B5 c1)
majority, consensus, vote, tally                   ← B5B-specific:
                                                     blocks multi-agent
                                                     voting attack surface
```

Charter anti-pattern #11 / #12: there is no `--allow-extra` /
`--decided-by-list` / `--votes` flag. The runtime CLI lower-cases
the input before set-membership testing.

### G3 — `outcome` is one of the three locked enum values

```
approved | rejected | deferred
```

`schemas/ltm/preflight_policy.schema.json::approval.allowed_outcomes`
is `minItems=3, maxItems=3, uniqueItems=true` — adding a fourth
outcome (e.g. `auto_approved`) requires an explicit schema bump
and a Charter waiver.

### G4 — `rationale` required for `rejected` / `deferred`

`approval.rationale_required_for` defaults to `["rejected","deferred"]`.
`approved` MAY omit `rationale` (default-allow fast path); the
other two outcomes refuse the finalize otherwise.

## 3. Charter alignment

| # | Anti-pattern | Where enforced in B5B |
|---|---|---|
| #6 | Evidence-threshold auto-promotion | `preflight_policy.yaml` carries NO `threshold` / `boost` / `auto_*` field. `preflight_metric` is read-only; never feeds back into retrieval policy. |
| #7 | Verifier escape hatches | No `--skip-preflight` / `--bypass-preflight` / `--force` flag exists on either `run_preflight_consensus.py` or `lock_core_version.py`. |
| #11 | Preflight as a gate-pass | `lock_gate.block_lock_when_outcome_not_approved` is **schema-const true** (`schemas/ltm/preflight_policy.schema.json`). `lock_core_version` re-evaluates `update_plan.preflight_required` AND `outcome=="approved"` independently — finalize alone is not enough. |
| #12 | Preflight majority-vote / auto-implementation | `consensus.decided_by` is a **single string** at the schema level. `approval.forbidden_deciders` includes 4 voting-specific tokens. The ledger writes a single decider, not an `agreed_by[]` list. |

The four rules above are tested at three layers:

1. **Schema** — `additionalProperties:false` + `pattern` + `enum`.
2. **Runtime CLI** — `_check_finalize_gate` in
   `scripts/ltm/run_preflight_consensus.py`.
3. **Lock-time gate** — `_check_preflight_gate` in
   `scripts/hub/lock_core_version.py`.

## 4. Ledger conventions

### 4.1 Ledger ID format

| Ledger | `ledger_id` pattern | length |
|---|---|---|
| `promotion_ledger` | `^promote_[a-z0-9_]*$` | 10..128 |
| `reject_ledger` | `^reject_[a-z0-9_]*$` | 10..128 |
| `supersede_ledger` | `^supersede_[a-z0-9_]*$` | 10..128 |
| **`preflight_consensus_event_ledger`** | **`^preflight_consensus_[a-z0-9_]*$`** | **22..160** |

The four families are **prefix-disjoint**. A naive
`grep -h '^"ledger_id":' ledger.json` against any audit aggregate
yields the family-of-origin without ambiguity.

### 4.2 Ledger sidecar location

```
ltm/preflight/cases/
    pf_case_<plan_id>.json              ← preflight_case envelope
    pf_case_<plan_id>.consensus.json    ← preflight_consensus_event_ledger
ltm/preflight/metrics/
    pf_metric_<case_id>_<ts>.json       ← preflight_metric envelope
```

The `.consensus.json` sidecar lives **next to** its case (same
directory) so audit greps stay local. The metric file goes into
`metrics/` because it is queried in aggregate (e.g. "p95 finalize
latency").

### 4.3 Ledger schema-version policy

All four schemas are pinned at `1.0.0` for the entire v4.91
release. Any field addition goes through an Addendum-X-style
1.1.0 bump with byte-locked compatibility (the Addendum-A
precedent: schemas widen, not replace; consumers stay 1.0.0
forward-compat by ignoring new optional fields).

## 5. CLI matrix

| Command | What it writes | Charter alignment |
|---|---|---|
| `python3 scripts/hub/generate_upgrade_plan.py --project-id ... --to-version ...` | `hub/update_plans/<plan_id>.yaml` (with `preflight_required` flag) **AND** auto-invokes `init-stub` for major-class plans (best-effort) | #11 — plan + stub are not gate-passes |
| `python3 scripts/ltm/run_preflight_consensus.py init-stub --plan <plan>.yaml` | `ltm/preflight/cases/pf_case_<plan_id>.json` (deferred / pending) | #11 — stub blocks the lock until finalized |
| `python3 scripts/ltm/run_preflight_consensus.py finalize --case <case>.json --decided-by <id> --outcome <ENUM> [--rationale ...] [--elapsed-seconds N]` | finalized case + sibling metric + consensus event ledger (3 atomic artifacts) | #6 / #7 / #11 / #12 |
| `python3 scripts/hub/lock_core_version.py [--dry-run]` | `hub/versions.lock` — refuses with `EXIT_PREFLIGHT_NOT_APPROVED (5)` if any required preflight is unfinalized or non-approved | #11 — independent re-evaluation |

All four CLIs are idempotent on their write target: re-running on
an already-stubbed / already-finalized / already-locked state is a
no-op exit 0 (with a `status=already_*` JSON payload when
`--format=json`).

## 6. End-to-end recipe

A canonical major-version upgrade walk, from EP perspective, looks
like this:

```bash
# 1) Hub side: generate the plan (auto-emits the deferred stub).
python3 scripts/hub/generate_upgrade_plan.py \
    --project-id <pid> --to-version 5.0.0
#  -> hub/update_plans/plan_<pid>_<from>_to_500.yaml
#  -> ltm/preflight/cases/pf_case_<plan_id>.json (deferred / pending)

# 2) lock_core_version refuses immediately.
python3 scripts/hub/lock_core_version.py
# error: preflight gate refused lock — 1 update_plan(s) lack approved
#         consensus (Charter anti-pattern #11 enforcement; v4.91 B5B c3):
#   - plan_<pid>_<from>_to_500.yaml: outcome='deferred' (must be 'approved')
# hint: run scripts/ltm/run_preflight_consensus.py finalize ...
# (rc=5)

# 3) EP reviews the impact + finalizes.
python3 scripts/ltm/run_preflight_consensus.py finalize \
    --case ltm/preflight/cases/pf_case_<plan_id>.json \
    --decided-by ep --outcome approved \
    --rationale "Reviewed protected_invariant diff; safe."
# FINALIZED <case_id> outcome=approved decided_by=ep -> ...consensus.json
# (rc=0)

# 4) Re-run lock; gate now passes.
python3 scripts/hub/lock_core_version.py
# preflight gate: 1 plan(s) cleared (approved by: ep)
# versions.lock written: ...
# (rc=0)
```

**Reject** path: same recipe, replace step 3 with
`--outcome rejected --rationale "<reason>"`. The plan stays in
`hub/update_plans/`; remove it manually if you want
`lock_core_version` to ignore it. (We do **not** auto-delete
rejected plans — Charter #6 / audit retention.)

**Deferred** path: same as reject but the door stays open. To
recover, finalize again with `--outcome approved` (idempotency
guard refuses overwrite if the existing decided_by is already a
real EP id; you must first clear the stub via manual edit + audit
trail in the daily log).

## 7. Audit recipe

```bash
# 1) Find every preflight case (open or closed)
ls -la ltm/preflight/cases/pf_case_*.json

# 2) Show all consensus outcomes
jq -r '"\(.case_id)\t\(.consensus.outcome)\t\(.consensus.decided_by)"' \
   ltm/preflight/cases/pf_case_*.json

# 3) Cross-check ledger family disjointness (should yield 0)
grep -hr '"ledger_id":' ltm/ | grep -E 'preflight_consensus_.*promote_' | wc -l
grep -hr '"ledger_id":' ltm/ | grep -E 'promote_.*preflight_consensus_' | wc -l

# 4) Audit chain double-check: every finalized case has a ledger
for c in ltm/preflight/cases/pf_case_*.json; do
    base=$(basename "$c" .json)
    test -f "ltm/preflight/cases/${base}.consensus.json" || echo "MISSING: $base"
done

# 5) Aggregate operational metrics (B5B c2 metric files)
jq -s 'map(.elapsed_seconds) | add / length' ltm/preflight/metrics/pf_metric_*.json
```

## 8. Where to look next

* `policies/charter_anti_patterns.md` §#11 §#12 — the canonical
  English-language statement of the anti-patterns this lifecycle
  enforces.
* `policies/core_update_policy.md` §`require_preflight_for[]` —
  the 5 triggers that **fire** preflight (`major_version_bump`,
  `cross_project_memory_policy_change`,
  `intent_boundary_policy_change`,
  `protected_invariant_change`,
  `tenancy_contract_change`).
* `docs/22_ltm_v3/PROMOTION_LIFECYCLE.md` — sibling write-side
  lifecycle for the LTM `_quarantine/` → canonical-domain path
  (B5 c4). The two lifecycles share Charter shape locks and DRY
  helpers (`_slug_for_ledger_id` family) but are otherwise
  independent.
* `runtime/protected_contracts/protected_regression_matrix.yaml`
  inv_002 — the eighth `must_preserve` row pins this lifecycle's
  charter contract surface (added in B5B c6).

---

*Layer 1. No project names. Forward-compat schemas stay 1.0.0.*
