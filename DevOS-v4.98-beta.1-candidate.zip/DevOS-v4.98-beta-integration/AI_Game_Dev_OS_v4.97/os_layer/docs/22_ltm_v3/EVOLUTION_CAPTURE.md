# EVOLUTION_CAPTURE — Capture pipeline -> _quarantine -> promote

> Layer 1 (OS Spec). v4.91 Milestone B, Batch 6 (B6). Sibling to
> `PROMOTION_LIFECYCLE.md` (B5 — `_quarantine` → canonical-domain) and
> `PREFLIGHT_CONSENSUS.md` (B5B — major-bump preflight gate).
>
> This document describes how four distinct capture pipelines feed
> the LTM `_quarantine/` surface, each tagged with a `capture_source`
> 5-enum value so audit greps and aggregate queries can attribute
> every candidate to its origin without ambiguity.
>
> The schemas backing this pipeline:
>
> * `schemas/ltm/memory_candidate.schema.json` (1.0.0, v4.90 Batch 8) —
>   **envelope** — the `_quarantine/mc_*.json` shape. v4.91 B6 c1
>   added the OPTIONAL `capture_source` 5-enum field (no
>   schema_version bump; Charter anti-pattern #4 extend-don't-replace).
> * `schemas/ltm/sprint_close_capture_input.schema.json` (1.0.0) —
>   sprint-close projection input.
> * `schemas/ltm/failure_fix_memory.schema.json` (1.0.0) —
>   ff entry shape (consumed by promote at promotion time).
> * `schemas/self_evolution/proposal_state.schema.json` (1.0.0) —
>   forward-compat for B6 c2's `--proposal-id` rail.

---

## 1. Capture pipelines (4 producers, 1 retraction)

```
                      ┌──────────────────────────────────────────────────────┐
                      │          ltm/_quarantine/mc_YYYY_NNN.json            │
                      │   (memory_candidate envelope, B6 c1 capture_source)  │
                      └────────────────────────▲─────────────────────────────┘
                                               │
        ┌──────────────────────┬───────────────┼───────────────┬─────────────────────────────┐
        │                      │               │               │                             │
   ┌────┴─────┐         ┌──────┴───────┐ ┌─────┴───────┐ ┌─────┴─────────┐         ┌─────────┴────────┐
   │capture_  │         │extract_      │ │extract_     │ │capture_       │         │quarantine_       │
   │sprint_   │         │failure_      │ │failure_     │ │evolution_     │         │entry             │
   │close     │         │candidates    │ │candidates   │ │proposal       │         │ (B6 c3 forward-  │
   │ B6 c3    │         │ default      │ │ --source    │ │ B6 c2 dual    │         │  compat)         │
   │ gate=    │         │              │ │ working_note│ │  rail         │         │  retraction      │
   │ blocked  │         │              │ │             │ │               │         │                  │
   └──────────┘         └──────────────┘ └─────────────┘ └───────────────┘         └──────────────────┘
   capture_source:      capture_source:  capture_source:  capture_source:           capture_source:
   sprint_close_        extract_failure_ working_note      evolution_proposal       quarantine_
   failure              candidates                                                  retraction
```

The `_quarantine/` directory is a **single mixed pool** by design (Q
not posed — implicit Plan §1 decision): the 5 sources land in the
same flat namespace and are distinguished by the `capture_source`
field. Sub-directories (`_quarantine/evolution/`, etc.) were
explicitly **rejected** to keep promote_memory_candidate.py's input
contract uniform — promote scans one directory and picks up
candidates regardless of source.

## 2. The 5 enum values (capture_source vocabulary)

| Value | Producer CLI | Trigger condition | Default `target_domain` |
|---|---|---|---|
| `sprint_close_failure` | `capture_sprint_close.py` (B6 c3) | `runtime.ltm.capture()` returns `gate=blocked` (e.g. missing `evidence_index` / `closure_report_path`) | `project` |
| `extract_failure_candidates` | `extract_failure_candidates.py` (default) | `--source` flag omitted; sweeping `ltm/working/*.md` for ad-hoc failure-fix candidates | `failures` |
| `working_note` | `extract_failure_candidates.py --source working_note` (B6 c2) | hand-written prose notes that aren't yet failure-fix shaped | `failures` |
| `evolution_proposal` | `capture_evolution_proposal.py` (B6 c2) | EP wants to promote a self_evolution proposal into a learnable LTM pattern | `pattern` |
| `quarantine_retraction` | `quarantine_entry.py` (B6 c3 forward-compat) | A canonical entry was retracted; the candidate envelope retains the original `target_domain` | _depends on retracted entry's domain_ |

The 5 values are locked at the schema layer — adding a 6th value
requires an Addendum-style schema bump (Charter anti-pattern #4
extend-don't-replace).

## 3. Charter alignment

| # | Anti-pattern | B6 enforcement |
|---|---|---|
| #4 | Replace, not extend | `capture_source` is OPTIONAL; `schema_version` stays 1.0.0 const. v4.90-era envelopes (no `capture_source`) remain schema-valid. |
| #6 | Evidence-threshold auto-promote | None of the 4 capture CLIs branches on `capture_source` for gate decisions. `promote_memory_candidate.py` (B5 c2) treats v4.90-style envelopes (no `capture_source`) and B6-style envelopes identically. |
| #7 | Verifier escape hatches | No `--force` / `--skip-validation` / `--no-auto-emit` flag exists. `capture_sprint_close.py` auto-emit on gate-blocked is unconditional; `capture_evolution_proposal.py` requires exactly one of `--proposal` / `--proposal-id` via argparse mutex. |
| #11 | Capture as gate-pass | Emitting a candidate does NOT mark anything as approved. Downstream `promote_memory_candidate.py` (B5 c2) + lock_core_version preflight gate (B5B c3) still apply independently. The original `capture_sprint_close` `EXIT_GATE_BLOCKED` rc is preserved when auto-emit succeeds. |

## 4. Pipeline-by-pipeline detail

### 4.1 `capture_sprint_close.py` (B6 c3)

The hook fires only on `gate=blocked` paths. Successful captures
(`gate=passed`) skip the auto-emit entirely — the canonical entry at
`ltm/project/<project_id>/sprint-<sprint_id>-closure.md` is the
authoritative record and no candidate is needed.

Idempotency anchor: `source_path == "sprint_close:<project_id>:<sprint_id>"`.
Re-running the same blocked sprint is a no-op.

The original `EXIT_GATE_BLOCKED` (2) is **always** preserved, even
when emit fails internally (schema-invalid envelope, write error,
etc.) — capture's primary contract is the projection layer, not the
candidate emission.

### 4.2 `extract_failure_candidates.py` (v4.90 + B6 c2 `--source`)

Sweeps `ltm/working/*.md` (excludes `README.md`). Per EP Q1=A, the
CLI is authoritative for **2 of the 5** enum values:
`extract_failure_candidates` (default) and `working_note` (via
`--source working_note`). The other 3 values belong to sibling CLIs;
attempting to pass them triggers an argparse error.

### 4.3 `capture_evolution_proposal.py` (B6 c2 — Q3=D dual-rail)

Per EP Q3=D: argparse `add_mutually_exclusive_group(required=True)`
over two rails:

* `--proposal <path>`: direct read of a proposal markdown
  (front-matter parse + body discard). Works today against all
  proposals in `proposals/*.md`.
* `--proposal-id <evo_id>`: indirect lookup via
  `proposals/<evo_id>/state.json`. Forward-compat — v4.91 ships
  proposals as flat `*.md` without `state/` subdirectories. The
  rail emits `EXIT_INPUT_MISSING (4)` with a remediation hint
  pointing at `--proposal`.

Both rails produce the same envelope shape. `--target-domain`
defaults to `pattern` (architecture / principle proposals naturally
map there); `--target-domain {failures,pattern,os,cross_project,project}`
overrides for unusual cases. The promote step (B5) re-validates
against the chosen domain's schema.

### 4.4 `quarantine_entry.py` (v4.90 + B6 c3 forward-compat)

The retraction CLI is unchanged in B6 c3 — it still moves a
canonical entry to `ltm/_quarantine/<timestamp>_<domain>_<slug>.quarantined.md`.
The forward-compat reservation is that B6 c2's `capture_source` enum
includes `quarantine_retraction` so future maintainers can extend
`quarantine_entry.py` to also emit a `memory_candidate` envelope
when retraction needs to be reviewed for re-promotion. **B6 ships
the schema slot but not the runtime emission** — adding emission
requires explicit EP signal, since not all retractions deserve
re-promotion review.

## 5. CLI matrix

| Command | Writes | Charter alignment |
|---|---|---|
| `python3 scripts/ltm/capture_sprint_close.py --input <closure>.json` | (gate=passed) → `ltm/project/<id>/sprint-<sid>-closure.md`; (gate=blocked) → `_quarantine/*.quarantined.md` AND `_quarantine/mc_<id>.json` (B6 c3 NEW) | #11 — auto-emit is a label, not a gate-pass |
| `python3 scripts/ltm/extract_failure_candidates.py --from <dir> --out <dir> [--source {extract_failure_candidates,working_note}]` | `_quarantine/mc_<id>.json` per `*.md` source file | #6 — no auto-promote; capture_source is descriptive |
| `python3 scripts/ltm/capture_evolution_proposal.py --proposal <path> | --proposal-id <evo_id>` | `_quarantine/mc_<id>.json` (capture_source='evolution_proposal') | #7 — argparse mutex enforces exactly one rail |
| `python3 scripts/ltm/quarantine_entry.py <memory_path> --reason TEXT` | Moves canonical entry to `_quarantine/*.quarantined.md` (B6 c3 forward-compat: future extension may also emit candidate envelope) | #11 — retraction is not a re-promotion |

All four CLIs are idempotent on their write target.

## 6. End-to-end recipe

A typical EP workflow that exercises 3 of the 4 pipelines in one
sprint cycle:

```bash
# 1) Sprint runs; the closure flow has no evidence_index yet.
python3 scripts/ltm/capture_sprint_close.py --input closure.json
# rc=2 (EXIT_GATE_BLOCKED)
# stderr: AUTO-EMIT: candidate mc_2026_007 -> ltm/_quarantine/mc_2026_007.json

# 2) EP jots a working/ note about a related lesson.
echo "front-matter + body" > ltm/working/2026-05-22_lesson.md
python3 scripts/ltm/extract_failure_candidates.py \
    --from ltm/working/ --out ltm/_quarantine/ --source working_note
# wrote mc_2026_008 <- ltm/working/2026-05-22_lesson.md
#       (capture_source=working_note)

# 3) An accepted self_evolution proposal becomes a learnable pattern.
python3 scripts/ltm/capture_evolution_proposal.py \
    --proposal proposals/evo_2026_001_layer_separation_principle.md
# wrote mc_2026_009 <- proposals/evo_2026_001_layer_separation_principle.md
#       (capture_source=evolution_proposal, target_domain=pattern)

# 4) EP reviews each candidate via the standard B5 promote pipeline.
python3 scripts/ltm/promote_memory_candidate.py \
    --candidate ltm/_quarantine/mc_2026_007.json \
    --to project --approver ep --ltm-root ltm/

# 5) (Optional) reject candidates that aren't worth keeping.
python3 scripts/ltm/reject_memory_candidate.py \
    --candidate ltm/_quarantine/mc_2026_008.json \
    --reason low_quality --rejected-by ep
```

The promote / reject / supersede CLIs (B5 c1-c3) are **unchanged** in
B6. They consume the new `capture_source`-tagged envelopes
identically to v4.90-style envelopes.

## 7. Audit recipe

```bash
# 1) Distribution of capture_source across current quarantine
jq -r '.capture_source // "<v4.90-no-source>"' ltm/_quarantine/mc_*.json | sort | uniq -c

# 2) Find every evolution-proposal candidate
jq 'select(.capture_source == "evolution_proposal")' ltm/_quarantine/mc_*.json

# 3) Verify schema validity of every candidate (B6 c1 5-enum)
for f in ltm/_quarantine/mc_*.json; do
    python3 -c "
import json, jsonschema, sys
schema = json.load(open('schemas/ltm/memory_candidate.schema.json'))
cand = json.load(open('$f'))
jsonschema.validate(cand, schema)
print('$f', 'OK')
"
done

# 4) Cross-link sprint-close auto-emits to original blocked captures
jq -r 'select(.capture_source == "sprint_close_failure") | .source_path' \
   ltm/_quarantine/mc_*.json | grep -E '^sprint_close:'
```

## 8. Where to look next

* `policies/charter_anti_patterns.md` §#4 §#6 §#7 §#11 — the
  canonical English-language statement of the anti-patterns this
  pipeline enforces.
* `docs/22_ltm_v3/PROMOTION_LIFECYCLE.md` — the B5 lifecycle that
  consumes B6's `_quarantine/` output. Capture and promote are
  separate concerns: capture creates candidates; promote evaluates
  + writes canonical entries.
* `docs/22_ltm_v3/PREFLIGHT_CONSENSUS.md` — the B5B gate that may
  apply between candidate creation and lock_core_version when the
  promotion implies a major-impact change.
* `runtime/protected_contracts/protected_regression_matrix.yaml`
  inv_002 — the ninth `must_preserve` row pins this pipeline's
  Charter contract surface (added in B6 c6).
* `proposals/README.md` — the self_evolution proposal lifecycle that
  feeds `capture_evolution_proposal.py`.

---

*Layer 1. No project names. capture_source 5-enum locked.*
