# Intent Baseline Model

> **Layer 1 (OS Spec).** v4.91 Batch 6 / Milestone F.
> Schema source: [`schemas/intent/intent_baseline.schema.json`](../../schemas/intent/intent_baseline.schema.json) (1.0.0).

---

## 1. What an intent baseline is

An **intent baseline** is a project-scoped, owner-approved declaration of:

- **goals** — what the work IS trying to achieve
- **non_goals** — what the work is explicitly NOT trying to do
- **acceptance_criteria** — testable conditions that prove the work is done
- a **scope** that locates the baseline in the project's domain taxonomy
- an **owner** who must approve any change
- a **freeze status** that controls whether the baseline can be mutated

The baseline is the protected contract that recommendations, cross-project candidates, agent decisions, and preflight consensus pipelines must NOT silently change. When a proposed change touches the baseline, the change MUST be processed through `validate_intent_freeze.py` (which enforces the freeze gate) and/or `generate_intent_diff_report.py` (which produces a structured diff for owner review).

---

## 2. Required fields

```json
{
  "schema_version": "1.0.0",          // const-locked
  "intent_id":      "intent_alpha_combat_loop",  // ^intent_[a-z0-9_]+$
  "project_id":     "project_alpha",  // ^[a-z0-9_]+$
  "scope":          "feature",        // 6-enum
  "owner": {
    "role":                            "producer",  // 6-enum
    "approval_required_for_change":    true         // const-locked
  },
  "intent_summary":       "Build a 3-turn combat loop for MVP validation.",  // minLength 16
  "goals":                ["..."],     // minItems 1, unique
  "non_goals":            ["..."],     // minItems 1, unique  ← Charter #11 demands explicit non-goals
  "acceptance_criteria":  ["..."],     // minItems 1, unique
  "freeze": {
    "status": "draft"                  // 4-enum
  }
}
```

Optional fields:

- `feature_id` — sub-scope identifier when `scope == "feature"` or `"runtime_contract"`
- `intent_boundary` — cross-project consent surface (see [`CROSS_PROJECT_INTENT_BOUNDARY.md`](CROSS_PROJECT_INTENT_BOUNDARY.md))
- `freeze.frozen_at` / `freeze.frozen_by` — REQUIRED at validator level when `freeze.status == "frozen"`
- `freeze.reopened_at` — REQUIRED at validator level when `freeze.status == "reopened"`
- `freeze.supersedes` — REQUIRED at validator level when `freeze.status == "superseded"`
- `rationale` — top-level free-text rationale; advisory at draft, REQUIRED for `reopened`/`superseded` transitions (validator enforces)

---

## 3. Scope enum (6-locked)

| Value | When to use |
|---|---|
| `feature` | A specific feature in a project (e.g. combat loop, perk system) |
| `sprint` | Sprint-level intent (multiple features but bounded by a sprint) |
| `milestone` | Milestone-level intent (multi-sprint, intersects with `game_dev_phase`) |
| `runtime_contract` | A runtime contract or schema that downstream code depends on |
| `visual_standard` | A visual / aesthetic direction that downstream artists / UI agents must respect |
| `asset_standard` | A reusable asset standard (e.g. tile size, naming convention, palette) |

Adding a new scope value would change the schema_version (1.0.0 → 1.1.0+). The 6-enum is locked because it intersects with the `concern_domains` taxonomy in `preflight_policy.yaml` — every scope that warrants a preflight ALSO warrants a baseline.

---

## 4. Owner role enum (6-locked)

| Value | Typical responsibility |
|---|---|
| `producer` | Cross-discipline product owner |
| `tech_lead` | Runtime contract, architecture, schema evolution |
| `design_lead` | Gameplay semantics, mechanics, balance |
| `art_lead` | Visual standard, aesthetic direction, asset language |
| `qa_lead` | Acceptance criteria, validation plan, regression contract |
| `executive_producer` | Cross-project escalation, policy override, milestone gate |

Owner role is DECLARED, not auto-derived. Charter anti-pattern #13 forbids host adapters or runtime tokens from claiming an owner role implicitly. The `forbidden_actors` token list (auto/system/agent/automation/robot/ci/majority/consensus/vote/tally) is rejected at the actor gate of all 3 intent CLIs AND at the `freeze.frozen_by` field.

---

## 5. Freeze lifecycle

```
   draft ──────┐
     │         │
     │ owner   │
     │ freezes │
     ▼         │
   frozen ◄────┘   (frozen baseline can be re-validated with status='draft' for revalidation only;
     │                content cannot be mutated in place)
     │
     ├── owner reopens (with rationale) ──► reopened ──► owner re-freezes ──► frozen
     │
     └── owner supersedes (with rationale + new intent_id + freeze.supersedes link) ──► superseded
                                                                                            │
                                                                                            ▼
                                                                                     terminal state
```

Allowed transitions:

| From | To | Witness required |
|---|---|---|
| `draft` | `frozen` | none |
| `draft` | `draft` | none (revalidation no-op) |
| `frozen` | `frozen` | content delta MUST be empty |
| `frozen` | `reopened` | top-level `rationale` REQUIRED via CLI `--rationale` |
| `reopened` | `frozen` | none (re-freeze is owner action) |
| `reopened` | `draft` | none (logged as `DRAFT_VALIDATED`) |
| `frozen` | `superseded` | NEW `intent_id` AND `freeze.supersedes` link AND `--rationale` |

Forbidden transitions (always emit `FREEZE_VIOLATION`):

- `frozen` → `frozen` with content delta — Charter anti-pattern #6 (no silent mutation)
- `frozen` → `draft` — Charter anti-pattern #6 (no silent rollback to draft)
- `frozen` → `reopened` without rationale — audit-trail violation
- `frozen` → `superseded` without rationale or link — incomplete supersede chain
- `superseded` → anything — superseded is terminal

The validator emits a ledger entry with `result: "FREEZE_VIOLATION"` for each forbidden attempt, then exits with code 5. The rejection itself is auditable.

---

## 6. Validator behavior

The 3 CLIs that consume baselines:

1. **`generate_intent_baseline.py`** — validates a draft / freezing transition and emits a ledger entry. It NEVER mutates the input file. If `freeze.status == "frozen"` is supplied without `frozen_at` / `frozen_by`, the validator rejects with `EXIT_VIOLATION=1`.

2. **`validate_intent_freeze.py`** — compares an existing baseline against a proposed revision and decides whether the transition is permitted. It NEVER writes back to the inputs. The decision matrix is enforced via the 8-cell table above.

3. **`generate_intent_diff_report.py`** — produces a structured diff report (see [`INTENT_DIFF_REPORT_V0.md`](INTENT_DIFF_REPORT_V0.md)). It NEVER performs semantic-drift judgement; `auto_semantic_judgement` is schema-const `"not_performed"`.

All three CLIs append entries to `runtime/registries/intent_baseline_ledger.jsonl`. Schema validation is performed via the in-tree `_intent_common.py` shape checks; full draft-07 validation runs in `tests/intent/test_intent_baseline_schema.py` and `tests/intent/test_intent_ledger_envelope.py`.

---

## 7. Project-side adoption

A project workspace adopts intent governance by placing a baseline file at:

```
<project>/.ai_dev_os/intent/baseline.json
```

The project owner runs:

```bash
python3 scripts/intent/generate_intent_baseline.py \
    --input  /path/to/project/.ai_dev_os/intent/baseline.json \
    --actor  producer:<owner_name>
```

The validation event is recorded in the OS Core's `runtime/registries/intent_baseline_ledger.jsonl`. Cross-project tooling reads only `details.intent_id` / `details.project_id` / `details.scope` (Layer 1 surface); narrative content stays project-side.

---

## 8. What this document does NOT cover

- The freeze gate decision matrix in detail (transitions + rejection paths) — see [`INTENT_FREEZE_AND_REOPEN_GATE.md`](INTENT_FREEZE_AND_REOPEN_GATE.md).
- The diff report shape (delta arrays, reason codes, preflight hint flag) — see [`INTENT_DIFF_REPORT_V0.md`](INTENT_DIFF_REPORT_V0.md).
- The cross-project consent surface (`intent_boundary.applicable_when` etc.) — see [`CROSS_PROJECT_INTENT_BOUNDARY.md`](CROSS_PROJECT_INTENT_BOUNDARY.md).
