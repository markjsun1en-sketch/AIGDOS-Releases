# Intent Diff Report v0

> **Layer 1 (OS Spec).** v4.91 Batch 6 / Milestone F.
> Schema: [`schemas/intent/intent_diff_report.schema.json`](../../schemas/intent/intent_diff_report.schema.json) (1.0.0).
> Generator: [`scripts/intent/generate_intent_diff_report.py`](../../scripts/intent/generate_intent_diff_report.py).

---

## 1. Purpose

The intent diff report is a structured comparison between an existing baseline and a proposed revision. It is consumed by:

- the **owner / human reviewer** as input to a re-freeze / re-open / supersede decision
- the **B5B preflight consensus pipeline** as a `requires_preflight_review` HINT (not an approval)
- the **B5 cross-project candidate** flow as evidence of cross-project intent compatibility
- the **B7 checkpoint flow** (when `before_capability_adoption` checkpoints reference an intent baseline that the adopting capability touches)

The report is generated mechanically by a stdlib script. It does **not** perform semantic-drift judgement.

---

## 2. Schema shape

```json
{
  "schema_version": "1.0.0",                    // const
  "report_id":      "idr_a1b2c3d4",             // ^idr_[a-z0-9_]+$
  "intent_id":      "intent_alpha_combat_loop",
  "project_id":     "project_alpha",
  "generated_at":   "2026-05-28T03:00:00Z",
  "generated_by":   "scripts/intent/generate_intent_diff_report.py",
  "changed_references": ["docs/world.md"],      // minItems 1
  "delta": {
    "goals_added":                  ["..."],
    "goals_removed":                ["..."],
    "non_goals_added":              ["..."],
    "non_goals_removed":            ["..."],
    "acceptance_criteria_added":    ["..."],
    "acceptance_criteria_removed":  ["..."]
  },
  "requires_human_review":     true,
  "requires_preflight_review": false,
  "reason_codes":              ["..."],         // 7-enum, optional
  "auto_semantic_judgement":   "not_performed"  // const-locked
}
```

All 6 delta arrays are REQUIRED (may be empty). Generators MUST emit a complete delta surface — partial diffs are rejected by the schema.

---

## 3. The `auto_semantic_judgement` schema-const

The `auto_semantic_judgement` field is schema-const `"not_performed"`. This is **not a default value** — it's a hard constraint. Any other value rejects validation.

This is the schema-layer enforcement of Charter anti-pattern #6 ("no auto-promote based on evidence threshold"). It means:

- v4.91 v0 generators MUST emit `"not_performed"`
- A future v4.92+ generator that adds NLP / embedding similarity / LLM-driven semantic comparison would have to bump `schema_version` (1.0.0 → 1.1.0+) AND change the const value to a new vocabulary like `"computed_advisory"` AND get the change reviewed under the Charter anti-pattern process

Even if a future generator computes a semantic score internally, it MUST NOT mark `auto_semantic_judgement` as anything other than `"not_performed"` at v0. The Charter rule is:

> **Recommendation can be presented; promotion is human-only.**

---

## 4. Reason code vocabulary (7-locked)

| Code | When to use | Auto-derived? |
|---|---|---|
| `player_facing_visual_semantics` | Diff touches visual identity, mood, or player-facing aesthetic semantics | caller-supplied via `--reason-code` |
| `runtime_contract_sensitive` | Diff touches runtime architecture, schema, or downstream code consumers | caller-supplied via `--reason-code` |
| `reusable_asset_standard` | Diff touches a reusable asset standard (palette, tile size, naming convention) | caller-supplied via `--reason-code` |
| `non_goal_relaxation` | At least one entry in `non_goals_removed` (non-goals are being loosened) | **auto-derived** by `generate_intent_diff_report.py` |
| `acceptance_criteria_removal` | At least one entry in `acceptance_criteria_removed` (AC is being weakened) | **auto-derived** |
| `cross_project_inheritance` | Diff is generated as part of a B5 cross-project candidate adoption flow | caller-supplied |
| `owner_initiated_reopen` | Diff is being computed against a baseline the owner is reopening | caller-supplied |

The 7-enum is closed at v0. Adding new codes would change the schema_version. Caller-supplied codes are validated by argparse `--reason-code` choices (rejected with non-zero exit if unknown).

---

## 5. `requires_preflight_review` derivation

The `requires_preflight_review` flag is set TRUE if and only if `reason_codes` is non-empty. The flag is a HINT to the B5B preflight consensus pipeline:

- **TRUE**: the diff has at least one reason that suggests preflight should be run; the B5B pipeline MAY consume the diff as a trigger source
- **FALSE**: no preflight reason was identified (or the caller did not supply one)

The flag is **not** an approval. Even with `requires_preflight_review: true`, the B5B pipeline runs its own enforcement (`run_preflight_consensus.py` with `preflight_policy.lock_gate.block_lock_when_outcome_not_approved` schema-const true). A diff report alone NEVER advances any gate.

Charter anti-pattern #11 is enforced here: recording a reason ≠ approving an action.

---

## 6. `requires_human_review` derivation

By default, every diff requires human review. The flag is set FALSE only when:

- `goals_removed`, `non_goals_added`, `non_goals_removed`, `acceptance_criteria_added`, `acceptance_criteria_removed` are all empty
- only `goals_added` is non-empty (purely additive goals diff)

This narrow exception lets owners ship "we discovered a new positive goal" diffs without the full review cycle. Any change that REMOVES content or TIGHTENS scope (adds non-goals) defaults to `requires_human_review: true`.

---

## 7. Caller-supplied reason codes

The CLI accepts repeatable `--reason-code` arguments:

```bash
python3 scripts/intent/generate_intent_diff_report.py \
    --baseline    /path/to/old.json \
    --proposed    /path/to/new.json \
    --actor       producer:alice \
    --changed-references docs/world.md \
    --reason-code player_facing_visual_semantics \
    --reason-code reusable_asset_standard \
    --output      /path/to/idr_2026_001.json
```

Caller-supplied codes are merged with auto-derived codes (`non_goal_relaxation`, `acceptance_criteria_removal`); the result preserves uniqueness and order (caller codes first, then auto-derived).

If the caller passes an unknown reason_code, argparse rejects with:

```
argument --reason-code: invalid choice: 'garbage_reason' (choose from 'acceptance_criteria_removal', ...)
```

This is the strict validation surface — adding a new reason_code at the runtime is impossible without changing the schema.

---

## 8. Ledger emission

Every successful diff report generation appends a `DIFF_GENERATED` ledger entry to `runtime/registries/intent_baseline_ledger.jsonl`:

```json
{
  "schema_version": "1.0.0",
  "event_id": "ib_a1b2c3d4",
  "event_type": "intent_baseline_event",
  "timestamp": "2026-05-28T03:00:00Z",
  "actor": "producer:alice",
  "runtime_profile": "default",
  "result": "DIFF_GENERATED",
  "source_layer": "L1",
  "audit_status": "recorded",
  "details": {
    "intent_id": "intent_alpha_combat_loop",
    "project_id": "project_alpha",
    "scope": "feature",
    "freeze_status": "frozen",
    "diff_report_id": "idr_a1b2c3d4"
  }
}
```

The `details.diff_report_id` field links the ledger entry to the report file. The two share the same hex prefix (allocator seeded by intent_id) but the prefixes differ (`ib_` vs `idr_`) so they're disjoint identifier spaces.

---

## 9. Output file vs stdout

By default, the report is written to stdout:

```bash
python3 scripts/intent/generate_intent_diff_report.py ... --output -
```

Or to a file:

```bash
python3 scripts/intent/generate_intent_diff_report.py ... --output /path/to/idr_2026_001.json
```

Either way, the ledger entry is appended (the ledger is the canonical record of the GENERATION event, while the report file is the consumable surface).

---

## 10. What this report does NOT do

- It does not enforce the freeze gate (that's `validate_intent_freeze.py`'s job)
- It does not invoke the B5B preflight pipeline (it only emits a HINT flag)
- It does not promote anything to cross-project memory
- It does not perform semantic-drift judgement (Charter #6 hard constraint)
- It does not modify the baseline / proposed input files

---

## 11. Test coverage

`tests/intent/test_intent_diff_report_no_auto_judgement.py` (8 tests) covers:

- `auto_semantic_judgement` const preservation through varied delta types
- `non_goal_relaxation` auto-derivation
- `acceptance_criteria_removal` auto-derivation
- `requires_human_review` FALSE only on purely-additive goals diffs
- `requires_preflight_review` derivation from `reason_codes`
- argparse `--reason-code` 7-enum strict validation
- `report_id` matches `^idr_` pattern
- `DIFF_GENERATED` ledger entry emitted

`tests/intent/test_intent_no_apply_flag.py` covers the schema-const guards on `auto_semantic_judgement` and the `reason_codes` 7-enum.
