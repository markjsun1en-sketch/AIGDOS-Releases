# Intent Freeze & Reopen Gate

> **Layer 1 (OS Spec).** v4.91 Batch 6 / Milestone F.
> Source: [`scripts/intent/validate_intent_freeze.py`](../../scripts/intent/validate_intent_freeze.py).
> Companion: [`INTENT_BASELINE_MODEL.md`](INTENT_BASELINE_MODEL.md), [`INTENT_DIFF_REPORT_V0.md`](INTENT_DIFF_REPORT_V0.md).

---

## 1. Purpose

The freeze gate is the runtime guard that prevents silent mutation of frozen intent baselines. It enforces the lifecycle invariants declared in [`INTENT_BASELINE_MODEL.md`](INTENT_BASELINE_MODEL.md) §5 and emits an auditable ledger entry for every transition attempt — permitted or rejected.

The gate is implemented by `scripts/intent/validate_intent_freeze.py` and protected by invariant `inv_012_intent_baseline_freeze_respected` in `runtime/protected_contracts/protected_regression_matrix.yaml`.

---

## 2. CLI surface

```bash
python3 scripts/intent/validate_intent_freeze.py \
    --baseline    /path/to/existing.json \
    --proposed    /path/to/proposed.json \
    --actor       producer:alice \
    [--rationale  "Owner re-opens to expand non-goals"] \
    [--ledger     /path/to/intent_baseline_ledger.jsonl] \
    [--runtime-profile default] \
    [--seed       deterministic_seed_for_test_fixtures] \
    [--json]
```

Required:
- `--baseline` — path to the EXISTING baseline (presumably frozen)
- `--proposed` — path to the PROPOSED revised baseline
- `--actor` — owner-role identifier; rejected if it matches the 10-token forbidden_actors vocabulary or starts with one of those tokens

Optional:
- `--rationale` — free-text rationale; REQUIRED for `frozen → reopened` and `frozen → superseded` transitions
- `--ledger` — override default ledger path (defaults to `runtime/registries/intent_baseline_ledger.jsonl`)
- `--json` — emit JSON status on stdout instead of human-readable line

Exit codes:

```
0  permitted; ledger entry appended
1  schema / shape violations
2  forbidden actor token (Charter anti-pattern #13)
3  internal error (could not parse input)
4  --baseline or --proposed file missing
5  FREEZE_VIOLATION (transition not permitted by the matrix)
```

---

## 3. The 8-cell transition matrix

Let `S₀` = baseline's `freeze.status`, `S₁` = proposed's `freeze.status`, `Δ` = whether `goals` / `non_goals` / `acceptance_criteria` differ.

| `S₀` | `S₁` | `Δ` | Witness | Result | Exit |
|---|---|---|---|---|---|
| `draft` | `draft` | any | — | `DRAFT_VALIDATED` | 0 |
| `draft` | `frozen` | any | — | `FROZEN` | 0 |
| `draft` | `reopened` | any | — | `DRAFT_VALIDATED` | 0 |
| `draft` | `superseded` | any | `--rationale` | `SUPERSEDED` | 0 |
| `draft` | `superseded` | any | (no rationale) | `FREEZE_VIOLATION` | 5 |
| `reopened` | `draft` | any | — | `DRAFT_VALIDATED` | 0 |
| `reopened` | `frozen` | any | — | `FROZEN` | 0 |
| `reopened` | `reopened` | any | — | `DRAFT_VALIDATED` | 0 |
| `reopened` | `superseded` | any | `--rationale` | `SUPERSEDED` | 0 |
| `frozen` | `frozen` | none | — | `DRAFT_VALIDATED` (no-op revalidate) | 0 |
| `frozen` | `frozen` | yes | — | `FREEZE_VIOLATION` | 5 |
| `frozen` | `reopened` | any | `--rationale` | `REOPENED` | 0 |
| `frozen` | `reopened` | any | (no rationale) | `FREEZE_VIOLATION` | 5 |
| `frozen` | `draft` | any | — | `FREEZE_VIOLATION` (Charter #6) | 5 |
| `frozen` | `superseded` | any | NEW `intent_id` + `freeze.supersedes == old intent_id` + `--rationale` | `SUPERSEDED` | 0 |
| `frozen` | `superseded` | any | missing any of the 3 | `FREEZE_VIOLATION` | 5 |
| `superseded` | * | any | — | `FREEZE_VIOLATION` (terminal) | 5 |

Every row produces a ledger entry, including the `FREEZE_VIOLATION` rejections. This is a deliberate design choice: silent rejection would violate the audit-trail contract.

---

## 4. Ledger entry shape

A successful transition entry:

```json
{
  "schema_version": "1.0.0",
  "event_id": "ib_a1b2c3d4",
  "event_type": "intent_baseline_event",
  "timestamp": "2026-05-28T03:00:00Z",
  "actor": "producer:alice",
  "runtime_profile": "default",
  "result": "REOPENED",
  "source_layer": "L1",
  "audit_status": "recorded",
  "details": {
    "intent_id": "intent_alpha_combat_loop",
    "project_id": "project_alpha",
    "scope": "feature",
    "freeze_status": "reopened",
    "owner_role": "producer",
    "rationale": "Owner reopens to expand non-goals"
  }
}
```

A `FREEZE_VIOLATION` entry uses the same envelope; only `result` and `details.freeze_status` differ. The `details.rationale` field, if present, captures whatever rationale the caller supplied (the rejection records both the WHY of the attempt and the WHY of the failure).

The 9-field audit envelope matches the v4.89 contract (Permanent Contract #5: shared envelope shape across `mcp_audit_log`, `delegation_decision_ledger`, `preflight_consensus_event_ledger`, and now `intent_baseline_ledger`).

---

## 5. Reopen gate

The `frozen → reopened` transition requires:

1. `--actor` not in the forbidden_actors vocabulary
2. `--rationale` non-empty
3. `proposed.freeze.status == "reopened"`
4. `proposed.intent_id == baseline.intent_id` (same baseline being reopened, not a new one)

If `--rationale` is missing, the gate rejects with:

```
ERROR: frozen -> reopened transition requires --rationale (audit trail).
```

The `details.rationale` field is propagated into the ledger entry so future audits can reconstruct the "why".

After the transition, the baseline file's `freeze.status` is `"reopened"` and `freeze.reopened_at` should be set. Owner subsequently makes the desired changes to `goals` / `non_goals` / `acceptance_criteria` and re-runs `validate_intent_freeze.py` with `proposed.freeze.status == "frozen"` to re-freeze (which goes through the `reopened → frozen` row of the matrix and emits a `FROZEN` ledger entry).

---

## 6. Supersede gate

The `frozen → superseded` transition requires:

1. `--actor` not in forbidden_actors
2. `--rationale` non-empty
3. `proposed.intent_id != baseline.intent_id` (a NEW baseline replaces the old)
4. `proposed.freeze.supersedes == baseline.intent_id` (the supersedes link points back to the old)

The successor baseline's `freeze.status` is typically `"frozen"` (an immediately-frozen replacement); it MAY be `"superseded"` for chained supersedes (rare).

The ledger entry uses `intent_id == proposed.intent_id` (the successor) and carries `details.supersedes == baseline.intent_id` so audits can follow the chain.

The OLD baseline's `freeze.status` should be updated to `"superseded"` and its `freeze.supersedes` left empty (the supersedes link lives on the SUCCESSOR side). This bidirectional convention is the same as `ltm/cross_project/superseded/` patterns.

---

## 7. Why the rejection itself is logged

A naïve gate would simply exit non-zero on a forbidden transition without writing to the ledger. v4.91's intent gate writes BOTH:

- a `FREEZE_VIOLATION` ledger entry (the rejection event)
- a non-zero exit code (signalling to the caller that no transition occurred)

This dual posture lets future audits answer: "Has anyone EVER tried to silently mutate this frozen baseline?" Without ledger logging, the answer would be unknowable.

The ledger entry is APPENDED before the validator exits, so an interrupted run that crashes after the schema check still leaves a partial trace.

---

## 8. What the gate does NOT do

- It does not perform semantic-drift judgement (no NLP, no diffing semantics; only set-difference on goals / non_goals / acceptance_criteria arrays)
- It does not call into the B5B preflight pipeline (the diff report carries `requires_preflight_review` as a HINT, not a gate trigger)
- It does not auto-promote anything to `ltm/cross_project/approved_patterns/` (Charter anti-pattern #6)
- It does not modify the input baseline files (Charter anti-pattern #6 / #11)
- It does not enforce that `freeze.frozen_by` is the same identity as `--actor` (the two fields serve different audit purposes — the first locks the baseline content, the second records who initiated this validation)

---

## 9. Test coverage

The 8-cell transition matrix is fully covered by `tests/intent/test_intent_freeze_workflow.py` (11 subprocess E2E tests). The forbidden-actor token list × 3 CLIs is covered by `tests/intent/test_intent_forbidden_actors.py` (47 parametrized tests). The compile-time guards on the script source are covered by `tests/intent/test_intent_no_apply_flag.py` and `tests/intent/test_intent_no_state_mutation.py`.

Test fixture pattern: each test uses `tmp_path` for ledger isolation and writes synthetic baselines using project-abstract tokens (`project_alpha` / `intent_alpha_combat_loop`) so Layer 1 tests never embed project literals.
