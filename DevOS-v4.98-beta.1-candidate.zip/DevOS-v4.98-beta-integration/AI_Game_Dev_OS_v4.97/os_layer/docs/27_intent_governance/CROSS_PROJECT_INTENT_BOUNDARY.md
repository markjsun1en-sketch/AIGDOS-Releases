# Cross-Project Intent Boundary

> **Layer 1 (OS Spec).** v4.91 Batch 6 / Milestone F.
> Source: `intent_baseline.intent_boundary` block in [`schemas/intent/intent_baseline.schema.json`](../../schemas/intent/intent_baseline.schema.json).
> Companion: [`docs/22_ltm_v3/PROMOTION_LIFECYCLE.md`](../22_ltm_v3/PROMOTION_LIFECYCLE.md), [`docs/22_ltm_v3/SHARED_LTM_V3_OVERVIEW.md`](../22_ltm_v3/SHARED_LTM_V3_OVERVIEW.md).

---

## 1. Why this boundary exists

v4.91 Milestone B (Shared LTM v3) lets a project share lessons learned with other projects via the `ltm/cross_project/candidates/` and `ltm/cross_project/approved_patterns/` ledgers. A candidate that has been promoted is, by default, retrievable by any project (Charter §8.4 default-include surface).

But "default-retrievable" is NOT "default-applicable". A pattern that worked in `project_alpha` may be actively wrong for `project_beta` — for example, a "use progressive adoption for major OS upgrades" pattern is applicable when the target has legacy state, but irrelevant for a greenfield project.

The `intent_baseline.intent_boundary` block is the project's declaration of what cross-project candidates MAY apply to it. It is the **consent surface** for cross-project intent inheritance.

---

## 2. Block shape

```json
{
  "intent_boundary": {
    "affects_project_intent": "yes",   // 3-enum: yes / no / possible
    "applicable_when": [
      "major OS upgrade",
      "legacy handoff/registry schema exists"
    ],
    "not_applicable_when": [
      "greenfield project with no legacy OS state",
      "project owner wants direct replacement experiment"
    ],
    "requires_owner_review": true        // default true
  }
}
```

All four fields are optional at the schema layer; if `intent_boundary` is omitted, the validator treats the baseline as having no opinion on cross-project candidate compatibility (cross-project candidates that target the baseline still go through the standard human approval flow).

When `intent_boundary` IS supplied:

- `affects_project_intent`:
    - `"yes"` — the baseline scope explicitly includes intent semantics; incoming candidates from `cross_project/candidates/` MUST check this baseline before adoption
    - `"no"` — the baseline is purely local; cross-project candidates do not need to consult it
    - `"possible"` — case-by-case (preflight reviewer or owner decides per candidate)

- `applicable_when`: free-form trigger phrases that name conditions under which a cross-project candidate MAY apply. The phrases are NOT regex patterns; they are reviewed by the human owner at adoption time.

- `not_applicable_when`: free-form trigger phrases that NAME conditions under which a candidate MUST NOT apply. This denylist is the strongest signal — the v4.91 promotion CLI rejects (with EXIT_VIOLATION) any candidate whose recorded `applicability` overlaps with the baseline's `not_applicable_when` (string-equality match; semantic matching is not performed at v0).

- `requires_owner_review`: defaults to true; setting false requires explicit EP justification and is logged in `details.rationale` of the adoption ledger entry.

---

## 3. Charter alignment

The intent_boundary block enforces:

| Charter anti-pattern | Enforcement |
|---|---|
| **#10** Cross-project candidate auto-application | `requires_owner_review` defaults to true; the candidate-promotion CLI (`promote_memory_candidate.py`) refuses to mark `target_baseline_consents = true` without owner sign-off |
| **#11** Recommendation ≠ approval | Even when `intent_boundary` lists a matching `applicable_when` trigger, the candidate still goes through the standard B5 human-approval flow |
| **#13** Host adapters cannot auto-decide | The `--actor` gate in B5 promotion CLIs uses the same forbidden_actors token list (auto/system/agent/automation/robot/ci/majority/consensus/vote/tally) |

The block does NOT enforce:

- Semantic similarity matching between candidate scope and baseline scope (no NLP at v0)
- Automatic candidate filtering based on `intent_boundary.not_applicable_when` overlap (the check is string-equality only — semantic phrasing variations are owner's responsibility)
- Reverse-direction inference (the baseline cannot retroactively REJECT an approved cross-project pattern; that requires a separate B5 supersede flow)

---

## 4. Workflow: cross-project candidate adoption

When a B5 cross-project candidate (`ltm/cross_project/candidates/cpi_2026_NNN.yaml`) is proposed for adoption into a target project:

```
candidate.applicability               baseline.intent_boundary
       │                                       │
       │                                       │
       ▼                                       ▼
┌──────────────────────────────────────────────────────────┐
│ Step 1: Layer 1 string-equality check                    │
│   For each phrase in baseline.intent_boundary.            │
│     not_applicable_when:                                 │
│       if phrase == any candidate.applicability.use_when  │
│       OR phrase appears literally in candidate.title:    │
│         REJECT (EXIT_VIOLATION)                          │
└──────────────────────────────────────────────────────────┘
       │
       ▼ (if no overlap)
┌──────────────────────────────────────────────────────────┐
│ Step 2: requires_owner_review check                      │
│   if baseline.intent_boundary.requires_owner_review:     │
│     ADD candidate to                                     │
│     ltm/cross_project/candidates/pending/<candidate_id>  │
│     stage='awaiting_owner_review'                        │
│     emit DIFF_GENERATED ledger entry referencing both    │
│     the candidate and the baseline                       │
└──────────────────────────────────────────────────────────┘
       │
       ▼ (after human approval)
┌──────────────────────────────────────────────────────────┐
│ Step 3: B5 promotion                                     │
│   promote_memory_candidate.py with                       │
│     --target-baseline <intent_id>                        │
│     --actor <owner_role>                                 │
│   appends to ltm/cross_project/approved_patterns/        │
│   appends promotion_ledger entry                         │
└──────────────────────────────────────────────────────────┘
```

The intent governance side touches only step 2 (recording the diff between candidate and baseline + emitting the audit trail). Step 3 is handled by the B5 lifecycle.

---

## 5. Example: applicability

Project A (`project_alpha`) baseline:

```json
{
  "intent_id": "intent_alpha_runtime_contract",
  "scope": "runtime_contract",
  "intent_boundary": {
    "affects_project_intent": "yes",
    "applicable_when": [
      "OS Core minor upgrade",
      "schema_version compatible upgrade path documented"
    ],
    "not_applicable_when": [
      "OS Core major upgrade with breaking schema changes",
      "tenant runtime path schema replaced (vs extended)"
    ],
    "requires_owner_review": true
  }
}
```

Cross-project candidate from project B (`project_beta`):

```yaml
candidate_id: cpi_2026_001
title: "Use progressive adoption for major OS upgrades"
applicability:
  use_when:
    - "major OS upgrade"
    - "legacy handoff/registry schema exists"
```

Step 1 string-equality check:

- `baseline.not_applicable_when[0]` is `"OS Core major upgrade with breaking schema changes"` — does NOT exactly match `candidate.use_when[0]` `"major OS upgrade"`. **No literal overlap. Continue.**

Step 2 owner review:

- `baseline.requires_owner_review = true` → candidate enters pending queue with diff report attached.
- Owner reviews the candidate's narrative against the baseline's `applicable_when` and decides whether the candidate's "major OS upgrade" trigger is compatible with the baseline's "OS Core minor upgrade" applicability.
- Owner either approves (advances to step 3) or rejects (candidate moves to `ltm/cross_project/rejected/` with rejection ledger).

The intent governance layer NEVER decides this question automatically. It only records the question and the owner's answer.

---

## 6. Why string-equality (not semantic matching)

At v0, the cross-project boundary check uses literal string equality (or `phrase in title` substring match). Semantic equivalence — recognizing that "major OS upgrade" and "OS Core major upgrade with breaking schema changes" describe overlapping situations — is the human owner's job.

Three reasons:

1. **Charter anti-pattern #6** — automatic semantic judgement of intent compatibility would silently auto-promote candidates the owner didn't actually consent to.
2. **Auditable** — string equality is deterministic and trivially reproducible across machines / sessions.
3. **Forward-compatible** — a future v0.5 / v1 might add advisory semantic similarity scoring as a HINT (alongside `requires_preflight_review`), but the AUTHORITATIVE decision must remain human.

---

## 7. Owner override: `requires_owner_review = false`

A baseline owner MAY set `requires_owner_review: false` to fast-track cross-project candidate adoption. This requires:

- explicit EP justification documented in the baseline's top-level `rationale` field
- the `executive_producer` owner role on the baseline (not delegated to lower roles)
- a `LEDGER` entry on the baseline-freeze event recording the override decision

Even with `requires_owner_review: false`, the candidate STILL goes through:

- Layer 1 string-equality check against `not_applicable_when`
- the B5 standard candidate → approved_pattern lifecycle
- the v4.89 9-field audit envelope contract on every step

The override only skips the explicit per-candidate human-review pause; it does not bypass any structural check.

---

## 8. Cross-references with other v4.91 surfaces

| v4.91 surface | Intersection point |
|---|---|
| **B5 cross-project promotion** ([`PROMOTION_LIFECYCLE.md`](../22_ltm_v3/PROMOTION_LIFECYCLE.md)) | `promote_memory_candidate.py --target-baseline <intent_id>` reads `intent_boundary` and respects the consent surface |
| **B5B preflight consensus** ([`PREFLIGHT_CONSENSUS.md`](../22_ltm_v3/PREFLIGHT_CONSENSUS.md)) | `requires_preflight_review` flag on `intent_diff_report` is consumed as a TRIGGER HINT (not approval) |
| **B7 checkpoint flow** | `before_capability_adoption` checkpoints reference `intent_baseline_ref` when the adoption touches a baseline-protected concern |
| **Addendum-A external core mount** | The `policies/charter_anti_patterns.md` #14 ("No Full Release Copy by Default") interacts because cross-project intent inheritance would lose isolation if every project copied the OS Core |

---

## 9. What this document does NOT cover

- The full B5 cross-project candidate lifecycle (creation, classification, similarity scoring) — see [`PROMOTION_LIFECYCLE.md`](../22_ltm_v3/PROMOTION_LIFECYCLE.md).
- The B5B preflight pipeline shape — see [`PREFLIGHT_CONSENSUS.md`](../22_ltm_v3/PREFLIGHT_CONSENSUS.md).
- The checkpoint / rollback flow — see [`docs/27_intent_governance/INTENT_FREEZE_AND_REOPEN_GATE.md`](INTENT_FREEZE_AND_REOPEN_GATE.md) for intent-side audit; [`schemas/recovery/checkpoint_manifest.schema.json`](../../schemas/recovery/checkpoint_manifest.schema.json) for checkpoint shape.
