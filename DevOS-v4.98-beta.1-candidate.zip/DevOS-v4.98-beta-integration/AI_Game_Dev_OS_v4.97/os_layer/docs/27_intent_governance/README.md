# Intent Governance Layer v0 — Adoption Notes

> **Layer 1 (OS Spec) — adoption surface.** v4.91 Batch 6 / Milestone F.
>
> **Schemas**:
> - [`schemas/intent/intent_baseline.schema.json`](../../schemas/intent/intent_baseline.schema.json) (1.0.0)
> - [`schemas/intent/intent_diff_report.schema.json`](../../schemas/intent/intent_diff_report.schema.json) (1.0.0)
> - [`schemas/intent/intent_baseline_ledger.schema.json`](../../schemas/intent/intent_baseline_ledger.schema.json) (1.0.0)
>
> **Scripts**:
> - [`scripts/intent/generate_intent_baseline.py`](../../scripts/intent/generate_intent_baseline.py)
> - [`scripts/intent/validate_intent_freeze.py`](../../scripts/intent/validate_intent_freeze.py)
> - [`scripts/intent/generate_intent_diff_report.py`](../../scripts/intent/generate_intent_diff_report.py)
> - [`scripts/intent/_intent_common.py`](../../scripts/intent/_intent_common.py) (shared helpers)
>
> **Runtime sink**: [`runtime/registries/intent_baseline_ledger.jsonl`](../../runtime/registries/intent_baseline_ledger.jsonl) (append-only)
>
> **Invariant**: [`inv_012_intent_baseline_freeze_respected`](../../runtime/protected_contracts/protected_regression_matrix.yaml)
>
> **Companion docs in this directory**:
> - [`INTENT_BASELINE_MODEL.md`](INTENT_BASELINE_MODEL.md) — what a baseline is, who owns it, how scope/owner-role/freeze.status interact
> - [`INTENT_FREEZE_AND_REOPEN_GATE.md`](INTENT_FREEZE_AND_REOPEN_GATE.md) — the 8-cell transition matrix enforced by `validate_intent_freeze.py`
> - [`INTENT_DIFF_REPORT_V0.md`](INTENT_DIFF_REPORT_V0.md) — what a diff report carries, the 7-token reason_codes vocabulary, how `requires_preflight_review` is derived (and why `auto_semantic_judgement` is schema-const `not_performed`)
> - [`CROSS_PROJECT_INTENT_BOUNDARY.md`](CROSS_PROJECT_INTENT_BOUNDARY.md) — how cross-project candidates from `ltm/cross_project/` interact with `intent_baseline.intent_boundary`

---

## 1. Why this directory exists

`docs/27_intent_governance/` is the Layer 1 adoption companion to the v4.91 Milestone F intent governance toolchain. The schemas describe *what* a baseline / diff / ledger entry looks like; the scripts describe *how* the runtime checks them. The docs in this directory describe:

- the **baseline contract** (goals / non_goals / acceptance_criteria + 4-state freeze lifecycle + 6-enum scope + 6-enum owner_role) — see [`INTENT_BASELINE_MODEL.md`](INTENT_BASELINE_MODEL.md);
- the **freeze gate contract** (8-cell transition matrix, rationale-required transitions, FREEZE_VIOLATION ledger semantics, exit-code surface) — see [`INTENT_FREEZE_AND_REOPEN_GATE.md`](INTENT_FREEZE_AND_REOPEN_GATE.md);
- the **diff report contract** (6-array delta surface, reason_code auto-derivation, `auto_semantic_judgement` schema-const enforcement) — see [`INTENT_DIFF_REPORT_V0.md`](INTENT_DIFF_REPORT_V0.md);
- the **cross-project boundary contract** (`intent_boundary.applicable_when` / `not_applicable_when`, owner-review requirement for cross-project candidate adoption) — see [`CROSS_PROJECT_INTENT_BOUNDARY.md`](CROSS_PROJECT_INTENT_BOUNDARY.md).

Project-specific intent baselines (per-project `intent_id` tokens, real owner identifiers, project-specific goals/non-goals) are **not** specified here. Those remain Layer 2 / project bindings under each project's `.ai_dev_os/intent/` directory (Charter anti-pattern #2 / #5 compliant).

---

## 2. Charter alignment

Intent Governance v0 is structurally narrow on purpose. It enforces:

| Charter anti-pattern | Enforcement layer |
|---|---|
| **#2** No project literals in Core | Layer 1 fixtures use `project_alpha` / `project_beta` and `intent_alpha` / `intent_beta` opaque tokens; lint guards `scripts/intent/` / `schemas/intent/` / `tests/intent/` / `docs/27_intent_governance/` |
| **#6** No evidence-threshold auto-promote | `intent_diff_report.auto_semantic_judgement` is schema-const `"not_performed"` — even a future generator that adds NLP cannot mark a diff `auto_decided` without bumping schema_version |
| **#11** Recording ≠ closure-gate pass | `requires_preflight_review` is a REQUEST flag; `FREEZE_VIOLATION` ledger entries record the rejection but do not authorize anything; consensus / preflight / human review remain independent gates |
| **#13** Host adapters cannot auto-decide | 10-token `forbidden_actors` vocabulary refused at runtime by all 3 CLIs (bare AND prefix-smuggled rejected); `freeze.frozen_by` validator enforces the same vocabulary |

What Intent Governance v0 explicitly does **not** do:

- It does not perform semantic-drift judgement (no NLP, no embedding similarity, no LLM calls)
- It does not auto-mutate any baseline file
- It does not auto-reopen frozen baselines
- It does not auto-approve transitions
- It does not promote project-private intent into cross-project memory

These behaviors are deferred (and many are forbidden by the 14-Charter anti-pattern matrix).

---

## 3. Workflow at a glance

```
                       owner edits baseline.json
                                 │
                                 ▼
        ┌──────────────────────────────────────────┐
        │  generate_intent_baseline.py             │
        │   - validates schema shape               │
        │   - rejects forbidden_actors / pattern   │
        │   - emits DRAFT_VALIDATED / FROZEN /     │
        │     REOPENED / SUPERSEDED ledger entry   │
        └──────────────────────────────────────────┘
                                 │
                                 ▼
            ┌────────────────────┴────────────────────┐
            │                                         │
   proposed change                              cross-project
            │                                  candidate (B5)
            ▼                                         │
  ┌──────────────────────────┐                        │
  │ validate_intent_freeze   │              intent_boundary check
  │  - 8-cell transition     │                        │
  │    matrix                │                        ▼
  │  - rationale required    │              owner-review gate
  │    for reopen/supersede  │                        │
  │  - FREEZE_VIOLATION emit │                        │
  └──────────────────────────┘                        │
            │                                         │
            ▼                                         │
  ┌──────────────────────────┐                        │
  │ generate_intent_diff     │                        │
  │  - 6-array delta surface │                        │
  │  - reason_code auto-     │                        │
  │    derive                │                        │
  │  - requires_preflight    │                        │
  │    flag                  │                        │
  └──────────────────────────┘                        │
            │                                         │
            ▼                                         ▼
   B5B preflight pipeline ◄─── (consume requires_preflight_review)
            │
            ▼
   human review / B5 candidate promotion
```

All three CLIs append to the same append-only ledger:
`runtime/registries/intent_baseline_ledger.jsonl`. Entries are never deleted; corrections use `audit_status: "amended"` referencing the prior `event_id` via `details.amends`.

---

## 4. Layer 1 vs Layer 2 boundary

| Aspect | Layer 1 (this dir) | Layer 2 (project workspace) |
|---|---|---|
| Schemas | `schemas/intent/*.schema.json` | — |
| Scripts | `scripts/intent/*.py` | — |
| Runtime ledger | `runtime/registries/intent_baseline_ledger.jsonl` (append-only canonical mirror) | `<project>/.ai_dev_os/intent/baseline.json`, `<project>/.ai_dev_os/intent/diff_reports/*.json` |
| Tests | `tests/intent/*.py` (Layer 1 contracts) | Project-side fixtures live outside the OS Core |
| Owner identifiers | abstract enum (producer / tech_lead / ...) | concrete identifiers (`producer:alice`, etc.) |
| Project literals | **forbidden** | required (real `project_id`, real intent narrative) |

This separation lets multiple Layer 2 projects share the same OS Core schemas + scripts without polluting Layer 1 with project-specific narrative (Charter §3 / anti-pattern #5).

---

## 5. Cross-references

- v4.91 B5 cross-project inheritance: see [`docs/22_ltm_v3/PROMOTION_LIFECYCLE.md`](../22_ltm_v3/PROMOTION_LIFECYCLE.md) — cross-project candidate that targets a baseline MUST reference `intent_boundary.requires_owner_review`.
- v4.91 B5B preflight consensus: see [`docs/22_ltm_v3/PREFLIGHT_CONSENSUS.md`](../22_ltm_v3/PREFLIGHT_CONSENSUS.md) — the preflight pipeline reads `requires_preflight_review` from `intent_diff_report` as a trigger hint, but never treats the diff report as an approval.
- v4.91 Addendum-C subagent routing gate: see [`docs/23_subagent_routing_gate/`](../23_subagent_routing_gate/) — sister Layer 1 governance skill; both `delegation_decision_ledger` and `intent_baseline_ledger` follow the v4.89 9-field envelope contract.
- v4.91 P7 dual-phase docs: see [`docs/26_dual_phase/`](../26_dual_phase/) — `intent_baseline.scope` enum (`milestone`, `runtime_contract`) intersects with `game_dev_phase`; the boundary is documented in `CROSS_PROJECT_INTENT_BOUNDARY.md`.

---

## 6. Quick reference: exit codes

```
EXIT_OK                = 0   permitted (ledger entry appended)
EXIT_VIOLATION         = 1   schema / shape violations
EXIT_FORBIDDEN_ACTOR   = 2   actor in forbidden_actors token list
EXIT_INTERNAL_ERROR    = 3   could not parse input or schema
EXIT_INPUT_MISSING     = 4   --baseline / --proposed / --input not found
EXIT_FROZEN_MUTATION   = 5   FREEZE_VIOLATION (frozen baseline mutated in place,
                              reopen without rationale, supersede without link, ...)
```

The `FREEZE_VIOLATION` exit (5) emits a ledger entry with
`result: "FREEZE_VIOLATION"` so the rejection itself is auditable. This
is intentional: silent rejection would violate the audit-trail contract.
