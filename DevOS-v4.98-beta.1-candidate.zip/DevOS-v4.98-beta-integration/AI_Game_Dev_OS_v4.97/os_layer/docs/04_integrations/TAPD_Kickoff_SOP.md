# TAPD Kickoff SOP

## Purpose
Standardize Sprint kickoff actions for TAPD-backed operation.

## Inputs
- selected runtime profile
- sprint name / dates
- runtime task plan
- TAPD workspace/project identifiers

## Standard Sequence

1. Create or select iteration.
2. Write back `current_iteration_id` and `current_sprint` to active TAPD config.
3. Create parent Story objects for Sprint workstreams.
4. Create child Story/SubStory/Task objects according to project mapping policy.
5. Run verification reads on all created objects.
6. Emit sync audit records.
7. Confirm that runtime registry and TAPD references are mutually linked.

## Exit Criteria
- iteration exists
- all initial TAPD objects are created
- references are stored back into runtime records
- verification reads succeeded
- kickoff audit summary exists
