# Writeback Request Protocol

> Added 2026-04-22 to close REV-3-007 (Writeback Owner mode listed
> names without defining trigger / queue / retry / escalation).

## Purpose

This document defines the **4-tuple contract** every runtime profile must specify when its `writeback_owner` field is filled: **trigger**, **queue/transport**, **retry**, **escalation**. Without all four, a "writeback owner" is just a label and silent-failure windows open up whenever the owner is unavailable.

## Scope

Applies to any mutation intended to reach an external system of record (TAPD / Jira / Git remote / external audit sink). Does NOT apply to internal runtime state writes (registry / evidence / snapshots), which follow `AI_Game_Dev_OS_v4.87_Registry_Writeback_and_Reconciliation_Contract.md`.

## The 4 required dimensions

### 1. Trigger

Under what condition does a writeback request originate?

| Trigger class | When it fires | Example |
| --- | --- | --- |
| `event` | Immediately when a runtime event of a designated type occurs | `runtime.transition` with `to_state=done` triggers TAPD writeback |
| `batch` | On a schedule (timer / cadence) | Every 15 min Orchestrator flushes queued writebacks |
| `handoff` | At handoff boundary between Agents | Engineering → QA handoff flushes any pending `external.tapd.write` events |
| `manual` | Only on explicit operator action | Private profile fallback: EP runs `python scripts/flush_writebacks.py` |

Profile `writeback_owner_mode` in `config/profiles/<profile>.json` should map to exactly one trigger class. Mixed triggers require explicit justification and an adjudication rule.

### 2. Queue / transport

How does the writeback request reach the owner?

| Option | Characteristics | When appropriate |
| --- | --- | --- |
| `inline` | Same-process function call | Owner is main session (Codex / Cursor); no async needed |
| `file_queue` | Append to `runtime/queue/writeback_pending.jsonl` | Multi-agent profiles where owner reads queue on cadence |
| `mcp_event` | Publish as `writeback_requested` MCP event, adapter subscribes | Runtime profiles with real MCP event bus |
| `external_api` | Direct HTTP call from producer | Only if producer itself has the credentials + authority (rare) |

Queue format (when `file_queue` is used):

```json
{"request_id":"wr-<uuid>","created_at":"<iso8601>","target":"tapd","object_type":"story","object_id":"1234","desired_state":"resolved","internal_state":"done","evidence_refs":["..."],"attempts":0}
```

### 3. Retry policy

When the first attempt fails (API error, owner unavailable, verification mismatch), what happens?

| Dimension | Default | Override location |
| --- | --- | --- |
| Max attempts | 3 | Profile `writeback_retry_max` field |
| Backoff | exponential (1s / 4s / 16s) for transient; immediate for programmable | Profile `writeback_retry_backoff` field |
| Verification gate | After each write attempt, run read-after-write verification (REV-3-013); a "write OK but verify MISMATCH" counts as a failure and consumes an attempt | hardcoded (no override) |
| After max attempts | Move request to `runtime/queue/writeback_failed.jsonl` with the full attempt history | hardcoded (no override) |

### 4. Escalation

If retries exhaust, who handles it?

| Condition | Escalation target | SOP |
| --- | --- | --- |
| Owner unavailable throughout retry window | Orchestrator (acts as fallback producer) | `PORTABLE_RECOVERY_PRINCIPLES.md` §escalation ladder |
| API authentication failure | Control owner (credentials owner) | Emit `runtime.escalation` audit event; block further writeback to that target until resolved |
| Persistent verification mismatch (write succeeds but read shows different state) | EP (human review) | Register in `blocker_registry.json` as a reconcile-required blocker |
| Network partition / external outage | Orchestrator queues + notifies EP | Resume once external service returns |

## Profile declaration requirements

Every `config/profiles/<profile>.json` must supply these fields to be valid (enforced by `scripts/validate_execution_profile.py` at SCAFFOLD; GUIDED validation deferred to v4.89):

```json
{
  "writeback_owner": "...",
  "writeback_trigger": "event | batch | handoff | manual",
  "writeback_queue": "inline | file_queue | mcp_event | external_api",
  "writeback_retry_max": 3,
  "writeback_retry_backoff": "exponential_1_4_16 | immediate | custom",
  "writeback_escalation_target": "orchestrator | control_owner | ep"
}
```

Profiles missing any of these fields should fail validation with an explicit ERROR pointing at this document.

## Cross-references

- `docs/04_integrations/TAPD_Integration_Baseline.md` — calls this protocol for TAPD-specific flows
- `docs/03_runtime_core/AI_Game_Dev_OS_v4.87_Registry_Writeback_and_Reconciliation_Contract.md` — defines reconciliation when writeback is queued or fails
- `docs/02_governance/PORTABLE_RECOVERY_PRINCIPLES.md` — defines escalation ladder invoked by §4 above
- `schemas/runtime_execution_profile.schema.json` — schema binding for the fields above (schema update deferred to Step 3 RENAME batch)
