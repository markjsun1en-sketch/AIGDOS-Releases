# TAPD Integration Baseline

## Purpose
This document defines the **portable baseline** for using TAPD as the external collaboration layer in AI Game Dev OS v4.89. The baseline assumes **runtime → TAPD** as the default write direction, with the internal registry remaining the authoritative runtime truth layer and TAPD serving as the project-facing collaboration surface.

This baseline is intentionally opinionated because the RandomHeroes trial exposed several real failure modes:
- Story / Task / Bug each use different legal status vocabularies.
- TAPD may accept an invalid status value with a success response, so API success is not sufficient evidence of correctness.
- Parent Story state cannot be safely inferred from iteration queries alone.
- Team/worker processes may not all have direct tool access, so writeback ownership must be explicit.

## Baseline Scope
Included in the baseline:
1. TAPD config template structure.
2. Object-type-specific status validation.
3. Read-after-write verification.
4. Parent-child aggregation checks.
5. Sprint kickoff and sprint close operating sequence.
6. Audit event expectations for TAPD writeback.

Excluded from the baseline:
- Jira/TAPD cross-adapter abstraction.
- Workspace-specific field names beyond the template layer.
- Full automation of dependency linking and reporting.

## Core Principles
### 1. Runtime Registry is the Internal Truth Layer
Internal task state, handoffs, validation, and archive state are decided inside the runtime system first. TAPD mirrors and communicates progress; it does not override runtime truth.

### 2. Writeback Must Be Deterministic
Every TAPD mutation must be attributable to a single owner in the current execution profile. The default owner is:
- parent session for Codex
- reviewed apply owner / lead for Cursor-like workflows
- main agent or lead for Claude Code
- main session proxy for Workbuddy private profile

### 3. Verification Is Mandatory
Every TAPD mutation that changes status or hierarchy must be followed by a verification read. API success alone is never treated as proof.

### 4. Parent Aggregation Is Explicit
Parent Story resolution is not inferred from a single iteration query. Parent aggregation is checked separately and, if needed, updated separately.

## TAPD Object Model in v4.89
| Internal object | TAPD object | Notes |
|---|---|---|
| Sprint | Iteration | Must exist before Story / Task writeback |
| Wave / feature group | Parent Story | Used as aggregation surface |
| Runtime task cluster | SubStory or Story | Project may choose the lighter pattern, but must stay consistent |
| Execution task | Task | Usually owned by one agent/worker |
| Defect | Bug | Uses separate priority and state vocabulary |

## Required Config Blocks
A valid TAPD config must define at least:
- workspace / project identity
- field mapping
- status mapping per object type
- valid statuses per object type
- valid priorities per object type
- sync direction
- verification rules
- writeback owner mode (enum values per `schemas/runtime_execution_profile.schema.json` property `writeback_owner`: `parent` | `lead` | `main_session` | `reviewed_apply_owner` | `project_defined`)

## Validator & Verifier Bindings (REV-3-012/013/014, 2026-04-22)

The baseline's contract-level requirements are bound to runtime scripts already migrated in Phase 1/2 (SCAFFOLD tier per `runtime/MATURITY_MATRIX.md`; Phase 4 trial-time work upgrades each to GUIDED).

| Contract requirement | Script binding | Current status | Phase 4 upgrade |
| --- | --- | --- | --- |
| TAPD config validator (REV-3-012) | `runtime/integrations/tapd/status_mapping_validator.py` | SCAFFOLD 55 lines — validates status_mapping bidirectional consistency | add workspace/project identity check + field-mapping completeness + unreachable enum detection |
| Read-after-write verifier (REV-3-013) | `runtime/integrations/tapd/read_after_write_verifier.py` | SCAFFOLD 22 lines — declares `VerificationResult` dataclass shape | implement the API GET-after-PUT cycle with status/priority/owner field compare |
| Parent Aggregation Checker (REV-3-014) | `runtime/integrations/tapd/parent_child_aggregation.py` | SCAFFOLD 20 lines — declares aggregate() interface | fetch parent by id + compute child completion summary + update parent status + post-update verify |

Contracts and scripts are kept as separate artifacts by design: the `.md` file evolves slowly (contract stability) while the `.py` file upgrades independently per trial (implementation).

### Fallback when scripts are still SCAFFOLD

At v4.89 level, the three scripts ship as normalize stubs (live TAPD adapter is deferred to v4.90). Projects adopting v4.89 should either:

- run the checks **manually** using the contract rules above, and log the result as an audit event (`external.tapd.verify` for REV-3-013, `trial.check` with `check_name=config_validator` or `check_name=parent_aggregation` for the others), or
- defer integration-heavy writes until their Phase 4 trial cycle

`scripts/verify_beta_sprint_exit.py` §external integrity category checks whether these scripts emitted any events during the sprint; absence of events when writes occurred is itself a WARN signal.

## Kickoff Baseline Sequence
1. Confirm selected execution profile and writeback owner.
2. Create or confirm Iteration.
3. Persist `current_iteration_id` into runtime config.
4. Create parent Story objects for the sprint structure.
5. Create child Story / Task layer.
6. Verify object creation with a read step.
7. Record audit events.

## Execution Baseline Sequence
During sprint execution:
1. Internal registry state changes first.
2. TAPD writeback is performed by the approved owner.
3. Status validator runs before mutation.
4. Read-after-write verifier runs after mutation.
5. Aggregation check runs when all known child objects reach terminal state.
6. Audit events are appended.

## Close Baseline Sequence
1. Confirm validation gate state in runtime.
2. Confirm archive intent in runtime.
3. Resolve or close remaining child work in TAPD.
4. Re-check parent Story status separately.
5. Write final close comments where required.
6. Run reconciliation report.
7. Archive internal tasks.

## Failure Modes and Recovery
### Failure Mode A: Invalid TAPD status accepted silently
Recovery:
- run verifier immediately
- log failed verification event
- compute suggested legal status
- re-write legal value
- re-run verifier

### Failure Mode B: Parent Story remains stale
Recovery:
- fetch parent directly by id
- compute child completion summary from runtime + TAPD
- update parent explicitly
- verify again

### Failure Mode C: Worker cannot write to TAPD directly
Recovery:
- emit internal completion + evidence
- queue writeback request to owner
- owner performs writeback and verification
- audit request and audit result separately

## Evidence Requirements
Minimum evidence for a completed TAPD writeback:
- object id
- mutation intent
- pre-validation result
- response status
- verification read result
- operator / owner identity
- timestamp

## Portable vs Runtime-Specific Responsibilities
Portable baseline handles:
- config structure
- state legality
- verification discipline
- close sequence
- audit expectations

Runtime profile handles:
- where rules are loaded
- who is permitted to call the tool
- how the writeback request is handed over
- where retry / recovery hooks live

## Exit Criteria
The TAPD baseline is considered active when:
- config template exists
- validator exists
- verifier exists
- kickoff and close SOP exist
- execution profile selects a writeback owner
- at least one trial sprint can produce verified writebacks
