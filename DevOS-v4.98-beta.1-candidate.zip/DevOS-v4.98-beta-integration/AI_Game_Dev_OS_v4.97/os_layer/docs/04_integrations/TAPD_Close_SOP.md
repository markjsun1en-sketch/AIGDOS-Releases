# TAPD Close SOP

## Purpose
Standardize Sprint close actions for TAPD-backed operation.

## Standard Sequence

1. Freeze runtime task set for the Sprint.
2. Run validation / gate review.
3. Archive runtime tasks according to close policy.
4. Update TAPD child objects to final synchronized state.
5. Update parent Stories explicitly.
6. Perform read-after-write verification on all changed TAPD objects.
7. Emit close audit records.
8. Generate close summary for reconciliation.

## Exit Criteria
- all closable runtime tasks archived or explicitly deferred
- all TAPD child objects reflect final close-state mapping
- parent Story states verified
- close audit summary generated
