# Merge Conflict Resolution Protocol

## Purpose
Prevent state corruption when conflicts touch runtime-managed files.

## Conflict Classes

### Class A — Code-only conflicts
Resolve by standard code review and test validation.

### Class B — Runtime metadata conflicts
Resolve field-by-field, then validate runtime semantics.

### Class C — Registry / task-state conflicts
Resolve block-by-block. Do not accept a whole side by default.

**Concrete "block" definition**: a block is one JSON path (per RFC 6901 JSON Pointer) addressing a single schema-validated field or collection. For `task_registry.json`, typical blocks are `/tasks/<task_id>/status`, `/tasks/<task_id>/gate_results`, `/blockers/<id>`. For `runtime_state.json`, `/current_sprint`, `/active_profile`, `/last_snapshot_id`.

**Procedure for Class C**:

1. Identify all conflicted blocks (use `git diff --name-only` to find files; then JSON-level three-way diff for blocks)
2. For each block, inspect both sides + common ancestor
3. Apply semantic validation per block's schema (e.g. status transitions must be legal per `docs/02_governance/GATE_MODEL.md` §7-state Feature Lifecycle)
4. Prefer the side with more recent `updated_at` timestamp when semantics allow; otherwise escalate per `PORTABLE_RECOVERY_PRINCIPLES.md`
5. After block-level resolution, re-validate the whole file against its schema

**Tooling**: the block-level reconciliation is currently manual. `runtime/integrations/git/merge_conflict_checker.py` (SCAFFOLD, 337 bytes) is the planned automation host; Phase 4 trial may require a `scripts/reconcile_registry_merge.py` wrapper to be authored.

## Required Procedure

1. Identify conflict class.
2. Snapshot pre-resolution file contents.
3. Resolve content with semantic review.
4. Re-run state checks.
5. Confirm resulting file is internally consistent.
6. Log merge event.

## Forbidden Shortcuts
- blanket `--theirs` for registry/task-state files
- blanket `--ours` for registry/task-state files
- marking conflicts resolved without state validation
