# TAPD Integration Layout (2026-04-22)

> Added in Phase 3 Step 3.5 to close the "tapd layout ambiguity" item
> deferred from Phase 2. Explains why there are two `tapd/` directories
> in the v4.89 package.

## Two directories, two roles

The v4.89 package inherits v4.87's separation between **integration config** and **integration runtime** (preserved verbatim from the v4.88-stable line):

### `integrations/tapd/` — Integration config layer

```
integrations/
├── __init__.py
├── adapter_common.py           # shared adapter helpers (not tapd-specific)
├── build_adapter_stub.py
├── git_adapter_stub.py
├── jira_adapter_stub.py
├── tapd_adapter_stub.py        # thin adapter stub (sibling to other stubs)
└── tapd/
    ├── __init__.py
    └── tapd_config.template.json   # canonical TAPD config template
```

**Role**: houses the TAPD **configuration template** and the sibling **adapter stub**. This is editor-friendly — a project maintainer looking at "how do I configure TAPD" finds one file. Stays close to the other 4 adapter stubs (`*_adapter_stub.py`) for cross-adapter consistency.

**Not for**: long-running runtime scripts, validators, or verifiers.

### `runtime/integrations/tapd/` — Integration runtime layer

```
runtime/
├── __init__.py
└── integrations/
    ├── __init__.py
    ├── git/
    │   ├── git_branch_cleanup.py
    │   ├── git_daily_inspection.py
    │   ├── merge_conflict_checker.py
    │   └── serial_merge_guard.py
    └── tapd/
        ├── __init__.py
        ├── parent_child_aggregation.py      # parent/child story aggregator (REV-3-014)
        ├── read_after_write_verifier.py     # write verification (REV-3-013)
        ├── status_mapping_validator.py      # config validator (REV-3-012)
        └── tapd_sync_executor.py            # sync loop driver
```

**Role**: houses TAPD **runtime scripts** that execute during sprint operation — validators, verifiers, sync executor, parent/child aggregation. Sits next to Git runtime scripts (`runtime/integrations/git/*`) for symmetric runtime access.

**Not for**: static config templates or one-off schema files.

## Why not flatten?

Folding `runtime/integrations/tapd/*` into `integrations/tapd/` was considered but rejected:

- **v4.87 origin**: v4.87 Optimized_Run_Baseline already used this split (`runtime/integrations/<provider>/` for runtime, `integrations/<provider>/` for config). v4.88-stable adopted this layout per 9-decision #5; v4.89 preserves it verbatim.
- **Cross-provider symmetry**: Git runtime scripts already live at `runtime/integrations/git/`. Putting TAPD runtime scripts alongside (not split) at package root would break Git's pattern.
- **Import resolution**: runtime scripts that call each other use relative path within `runtime/integrations/`; moving TAPD out would require 2 different import idioms for the same kind of runtime work.
- **Editor ergonomics**: project maintainers configuring TAPD touch `integrations/tapd/tapd_config.template.json`; ops engineers running sync scripts touch `runtime/integrations/tapd/*.py`. Different users, different views; keeping them separated helps both.

## When a script needs the config

TAPD runtime scripts read the config template using a path lookup relative to the package root, not via import:

```python
CONFIG_PATH = Path(__file__).resolve().parents[3] / "integrations" / "tapd" / "tapd_config.template.json"
```

(Adjust `parents[3]` as the script depth requires.) This preserves the two-dir split at the filesystem level while still giving runtime code access.

## Cross-references

- `docs/04_integrations/TAPD_Integration_Baseline.md` — TAPD contract (covers both layers)
- `docs/04_integrations/TAPD_Kickoff_SOP.md` — sprint kickoff using config + runtime together
- `runtime/MATURITY_MATRIX.md` — lists runtime TAPD scripts at SCAFFOLD tier (Phase 4 upgrade to GUIDED)
- `runtime/integrations/git/` — sibling symmetric layout for Git
