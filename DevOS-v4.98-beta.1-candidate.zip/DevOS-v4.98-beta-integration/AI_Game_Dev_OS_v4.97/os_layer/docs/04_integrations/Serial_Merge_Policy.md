# Serial Merge Policy

## Policy
All worker outputs may be produced in parallel, but **integration into the shared mainline is always serialized**.

## Why
Serial merge reduces:
- hidden state corruption
- registry overwrite risk
- unresolved ordering ambiguity
- cleanup drift

## Required Steps Per Merge

1. Confirm target branch/worktree is current.
2. Run pre-merge validation.
3. Merge or apply exactly one worker output.
4. Re-check state-bearing files.
5. Record merge audit event.
6. Cleanup merged unit before processing next one.

## Forbidden
- concurrent direct merges to main
- batch-accepting multiple worker diffs without intermediate validation
- skipping state verification after merge
