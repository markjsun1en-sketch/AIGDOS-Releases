# Git Agent Workflow Baseline

## Purpose
This document defines the **portable Git baseline** for AI Game Dev OS v4.89. The aim is to preserve fast parallel execution while preventing merge chaos, registry corruption, and hidden state drift.

The baseline was derived from real project behavior where multiple worker contexts operated in parallel, but stable progress depended on a small set of non-negotiable rules.

## Baseline Principles
### 1. Isolate Before Edit
Any code-writing worker should begin inside an isolated unit before touching project files. The exact isolation primitive depends on runtime profile:
- worktree-first for Codex
- worktree-first for Cursor
- worktree or lead-controlled team discipline for Claude Code
- Workbuddy private model as declared in its profile

### 2. Parallel Execution, Serial Merge
Workers may explore and implement in parallel. Merge or apply into the primary integration line is serialized.

### 3. Runtime State Files Need Special Care
Registry-like files, runtime task state, and audit metadata are not safe to resolve by blindly taking one side of a merge conflict. These files require explicit inspection and reconciliation.

### 4. Cleanup Is Mandatory
Stale branches, stale worktrees, and abandoned trial outputs should not accumulate past the current sprint without an explicit reason.

## Baseline Roles
| Role | Responsibility |
|---|---|
| Worker | produce scoped change in isolation |
| Merge owner | validate and serialize integration |
| Audit owner | ensure merge and trial actions are recorded |
| Runtime owner | ensure registry / state files remain coherent |

## Canonical Workflow
1. Select task and runtime profile.
2. Create isolated execution unit.
3. Apply scoped change only within task boundary.
4. Run local validation.
5. Produce result summary and candidate integration note.
6. Merge owner reviews and applies serially.
7. Resolve registry/state conflicts carefully.
8. Record audit and cleanup the isolated unit.

## Branch / Worktree Naming
Portable expectation:
- include task id
- include worker identity or role
- remain human-readable
- be unique enough for one sprint window

Runtime profile may refine syntax, but it must still carry task traceability.

## Merge Discipline
The merge owner must confirm:
- only one integration is being applied at a time
- working tree is known clean enough for integration
- state files are checked after merge
- audit record is written after merge

## Registry / State Conflict Protocol
When merge conflict involves runtime state files:
1. do not accept a full-side overwrite by default
2. inspect semantic intent of both sides
3. re-build expected post-merge state
4. re-run validation for consistency
5. log manual reconciliation if needed

## Daily Inspection Baseline
At least once per day, inspect:
- stale isolated units
- unmerged worker branches / worktrees
- dirty working tree state
- registry drift indicators
- missing audit entries for completed work

## Stale Branch Policy (REV-3-009, 2026-04-22)

Concrete thresholds and detection rules that make "stale isolated units" and "unmerged worker branches" actionable rather than aspirational. Based on RandomHeroes operational evidence (2026-04 sprints).

### Branch naming convention

- **`agent/<role>/<task_id>`** — agent-owned work branch. `<role>` should match a subsystem in `skills/_generic_core/` (engineering / game-design / qa / sound / art / uiux / ...). Example: `agent/eng/FT-001`, `agent/qa/BUG-123`.
- **`sprint/<sprint_id>`** — sprint coordination branch, owned by Orchestrator.
- **`exp/<topic>`** — experimental branches explicitly outside agent-owned workflow. Subject to stricter stale policy.
- **`main`** — default branch; merge target.

Branches not matching any pattern above should either be renamed or flagged during daily inspection.

### Stale thresholds

| Branch type | Stale threshold | Action on threshold |
| --- | --- | --- |
| `agent/*` unmerged | **3 days** since last commit | WARN: flag in daily inspection; ping owner |
| `agent/*` unmerged | **7 days** since last commit | ERROR: escalate to Orchestrator + EP; consider rebase or abandon |
| `agent/*` merged but not deleted | **1 day** after merge | INFO: auto-cleanup candidate |
| `sprint/*` after sprint close | **1 day** after close transition | INFO: archive (merge or delete per outcome) |
| `exp/*` | **7 days** since last commit | WARN; after 30 days → ERROR |

"Since last commit" is measured by `git log -1 --format=%ct <branch>` against the current UTC timestamp.

### Conflict detection with `main`

For every `agent/*` branch active at daily inspection time, detect whether it would merge cleanly into current `main`:

```bash
# base commit of the branch relative to main
base=$(git merge-base main "$branch")
# simulate a merge without touching worktree
tree=$(git merge-tree "$base" main "$branch")
# look for conflict markers in the synthetic output
echo "$tree" | grep -q '<<<<<<<' && status=CONFLICT || status=CLEAN
```

Conflict branches should be flagged in the daily inspection JSON output (`conflicts: ["agent/eng/FT-001", ...]`) and the conflict-owning Agent should rebase before continuing work.

### Dirty worktree detection

A worktree with uncommitted changes at daily inspection time should emit WARN if older than 1 day, ERROR if older than 3 days (matches `agent/*` unmerged thresholds to avoid two conflicting signals).

### Integration with scripts

The thresholds and detection rules above are the contract; implementation lives in `runtime/integrations/git/git_daily_inspection.py` (currently SCAFFOLD, Phase 4 trial-time upgrade to GUIDED). The script should emit a JSON report matching:

```json
{
  "inspected_at": "<iso8601>",
  "head": "<short_sha>",
  "branches": {"agent/*": <n>, "sprint/*": <n>, "exp/*": <n>, "other": <n>},
  "stale_warn": ["..."],
  "stale_error": ["..."],
  "conflicts_with_main": ["..."],
  "dirty_worktree": {"status": "clean|dirty_warn|dirty_error", "files": ["..."]}
}
```

## Cleanup Baseline
Cleanup should remove or archive:
- merged branches / worktrees
- abandoned trial branches older than policy threshold
- empty or temporary isolation units
- stale merge notes once summarized

## Failure Modes and Recovery
### A. Worker changed the wrong base
Recovery:
- stop integration
- restate intended base
- move or replay change into correct isolated unit
- record the incident if merge prep was already started

### B. Merge passed but registry became inconsistent
Recovery:
- rebuild expected runtime state from audit + last known good snapshot
- patch registry explicitly
- document manual reconciliation

### C. Multiple workers finish simultaneously
Recovery:
- queue integrations
- rank by dependency and risk
- integrate one by one
- do not collapse into a single blind merge step

## Portable vs Runtime-Specific Responsibilities
Portable baseline defines:
- serial merge requirement
- state file handling discipline
- inspection expectation
- cleanup expectation

Runtime profile defines:
- exact isolation primitive
- exact launch path
- exact merge owner
- exact cleanup trigger location

## Exit Criteria
Git baseline is active when:
- serial merge policy exists (`Serial_Merge_Policy.md`)
- conflict protocol exists (`Merge_Conflict_Resolution_Protocol.md`)
- inspection script exists (`runtime/integrations/git/git_daily_inspection.py`, SCAFFOLD — Phase 4 upgrades to GUIDED with stale-branch age threshold + unmerged detection + dirty worktree scan; naming per REV-3-017 canonical binding)
- cleanup script exists (`runtime/integrations/git/git_branch_cleanup.py`, SCAFFOLD — Phase 4 upgrades with merge-status-based deletion; naming per REV-3-017 canonical binding)
- serial merge guard exists (`runtime/integrations/git/serial_merge_guard.py`, SCAFFOLD)
- merge conflict checker exists (`runtime/integrations/git/merge_conflict_checker.py`, SCAFFOLD)
- runtime profile declares isolation and merge ownership
