# v4.89 — Usage Guide

> **Audience**: Executive Producer (EP) or technical lead preparing to
> adopt v4.89 on a new project. Read this before running any
> sprint. For the "first Beta Sprint run" walk-through specifically,
> see the companion doc `PHASE_4_TRIAL_GUIDE.md`.

## 0. Prerequisites

- Python 3 (stdlib only; no pip install needed)
- Git
- A project directory separate from the v4.89 package itself
- (Optional) TAPD account and API credentials if you want external
  writeback automation to be real rather than stubbed

## 1. Workflow Overview

```
┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐
│  1. Choose a     │ →  │  2. Assemble     │ →  │  3. Bind Skills  │
│  runtime profile │    │  project         │    │  and hooks       │
└──────────────────┘    │  attachment      │    └──────────────────┘
                        └──────────────────┘              │
                                                          ▼
                                                ┌──────────────────┐
                                                │  4. Run Beta     │
                                                │  Sprint + verify │
                                                │  exit gate       │
                                                └──────────────────┘
```

Each step below has its own section. Steps 1–3 are one-time setup.
Step 4 repeats every sprint.

## 2. Choose a Runtime Profile

v4.89 supports **5 runtime profiles** that represent real
execution environments:

| Profile | Coordination model | Default isolation | Writeback owner | Best use |
| --- | --- | --- | --- | --- |
| `codex` | parent + subagents | worktree | parent | Default Beta Sprint — lowest overhead |
| `cursor` | coordinator + parallel agents | worktree / isolated env | reviewed coordinator | Parallel experimentation, review-heavy flow |
| `claude_code_subagents` | main agent + subagents | worktree | main agent | Hook-driven bounded execution |
| `claude_code_agent_teams` | lead + teammates | shared session | lead | High-coordination scenarios (higher overhead) |
| `workbuddy_private` | private coordinated | project-defined | main session | Continuation of existing Workbuddy-derived projects |

**Decision tree** (adapted from
`docs/06_runtime_profiles/Runtime_Profile_Comparison.md`):

1. Is the project already running on Codex with parent-owned
   writeback? → choose **`codex`**
2. Does the sprint need parallel workers and review-gated integration?
   → choose **`cursor`**
3. Do you need hook-driven bounded execution? → choose
   **`claude_code_subagents`**
4. Does the sprint need persistent multi-teammate coordination and you
   accept the overhead? → choose **`claude_code_agent_teams`**
5. Are you preserving a legacy Workbuddy runtime? → choose
   **`workbuddy_private`**

> **Anti-pattern**: do not pick the most powerful profile by default;
> pick the one with the **least coordination overhead** that still
> fits the sprint.

Canonical profile definitions live in `config/profiles/*.json`. Each
profile also has a starter directory under `starters/<profile>/` and a
README under `docs/06_runtime_profiles/<profile>/`.

## 3. Assemble a Project Attachment

The assemble command bundles the portable core + selected profile +
context pack + game type pack into a single attachment directory.

```bash
# Example selection JSON
cat > /tmp/my_project.selection.json <<'JSON'
{
  "project_name": "MyProject",
  "stage": "MVP",
  "context_pack": "standard_context_pack",
  "game_pack": "generic_project_starter",
  "profile": "codex"
}
JSON

# Run assemble from the v4.89 package root
python3 scripts/assemble_project_attachment.py \
    --selection /tmp/my_project.selection.json
# → exports to attachment_preview/myproject/
#   with attachment_resolution.json + attachment_resolution.md
```

Expected status on success: `{"status": "ready", ...}`.

**Key outputs**:
- `attachment_preview/<project>/attachment_resolution.json` — machine-
  readable manifest of everything included
- `attachment_preview/<project>/attachment_resolution.md` — human
  summary of the packaged contents

If the status is not `ready`, the error section of the JSON will
tell you which pack / profile reference failed.

## 4. Bind Skills and Hooks

v4.89 ships two Skills layers:

- **`skills/_generic_core/`** (31 skills across 9 role dirs) — cross-project stable
  contracts and workflow ops. Package them directly.
- **`skills/_adaptation_hooks/`** (12 hooks) — project-specific binding
  points. Each hook declares a Required Bindings table; the project
  fills those bindings via yaml files in `policy/adaptation/`.

### 4.1 Pick only the hooks you use

Not every hook is mandatory. Inventory:

| Hook | Purpose | Required binding example |
| --- | --- | --- |
| `art/hook_engine_naming.md` | Engine-specific asset naming | engine=godot |
| `art/hook_engine_export.md` | Engine-specific export format | engine_export_format=.import |
| `art/hook_image_cleanup_tooling.md` | Image cleanup tool chain | image_tool=magick |
| `common/hook_data_pipeline.md` | Spreadsheet → code data flow | pipeline=xlsx_to_json |
| `common/hook_engine_validation.md` | Build / runtime validator | validator_tool=godot --check |
| `common/hook_branch_strategy.md` | Branch naming / merge policy | branch_prefix=feature/ |
| `common/hook_spec_template.md` | Feature spec template | template_path=docs/spec.md |
| `common/hook_sprint_tracker_sync.md` | Tracker integration | tracker=tapd / jira / linear |
| `common/hook_5d_scoring.md` | QA N-dimensional rubric | dimensions=[ui, perf, ...] |
| `common/hook_gate_standards.md` | Gate pass/fail rubric | rubric_path=docs/gate.md |
| `common/hook_audio_naming.md` | Audio asset naming | prefix=sfx_ |
| `common/hook_audiogen_generation.md` | Audiogen tool chain | tool=audiogen-mcp |

### 4.2 Create `policy/adaptation/<hook>.yaml` files

Example for `common/hook_sprint_tracker_sync.md`:

```yaml
# project_root/policy/adaptation/sprint_tracker_sync.yaml
tracker: tapd
api_endpoint: https://api.tapd.cn/v1/
workspace_id: 123456
story_url_template: "https://www.tapd.cn/{ws}/prong/stories/view/{id}"
status_mapping:
  open: new
  in_progress: developing
  validation_pending: reviewing
  done: resolved
```

Unfilled hooks stay empty — the `_generic_core` skill keeps working,
it just shows the hook reference as unbound.

### 4.3 Skills inventory by subsystem

```
skills/_generic_core/
  art/                  (7 skills) — asset breakdown, cleanup, reuse, ...
  design/               (6 skills) — documentation, brief, critique, ...
  uiux/                 (6 skills) — flow, wireframe, handoff, ...
  engineering/          (2 skills) — contract + ops
  ep/                   (1 skill) — contract
  game-design/          (2 skills) — contract + ops
  research/             (2 skills) — contract + ops
  orchestrator/         (2 skills) — contract + ops
  content-design/       (1 skill) — contract
  numeric/              (1 skill) — contract
  qa/                   (2 skills) — contract + ops
  sound-designer/       (2 skills) — contract + ops
```

See `skills/README.md` for the three-piece pattern (Contract / Ops /
Schema) and full origin notes.

## 5. Governance

v4.89 governance is codified in five docs under
`docs/02_governance/`:

| Doc | What it answers |
| --- | --- |
| `GATE_MODEL.md` | When does work pass a quality gate? |
| `SPRINT_OPERATING_MODEL.md` | How does a sprint flow from kickoff to close? |
| `SKILLS_MODEL.md` | How are skills loaded, bound, and audited? |
| `CHANGE_ADMISSION.md` | What changes can enter the main line? |
| `GOVERNANCE_COST_REVIEW.md` | How much governance is enough? |

If your project already has its own governance (e.g. RandomHeroes
`policy/`), you can overlay those docs; the v4.89 versions are the
"portable floor" to fall back on.

## 6. Beta Sprint Close Verification

Each sprint follows a three-step runtime flow (all three scripts live
under `scripts/`):

```bash
# Step 1 — initialize a fresh sprint workspace (B+ C3: real init, not scaffold)
python3 scripts/init_runtime_env.py \
    --project-id my_sprint_01 \
    --runtime-profile codex \
    --output-dir /path/to/project

# Step 2 — during the sprint, after major milestones, run a 5-module check
python3 scripts/run_beta_sprint_check.py \
    --workspace /path/to/project \
    --profile codex
# Covers: docs / profile / adapter+collector / agents_guard / checklist

# Step 3 — at sprint close, run the exit-gate verifier
python3 scripts/verify_beta_sprint_exit.py \
    --workspace /path/to/project \
    --audit-log runtime/logs/mcp_audit.jsonl \
    --runtime-state runtime/state/runtime_state.json \
    --sprint-close-checklist runtime/state/sprint_close_checklist.md \
    --sprint sprint-N --profile codex
```

The verifier returns one of three verdicts:

| Verdict | Exit code | Meaning |
| --- | --- | --- |
| PASS | 0 | All 5 integrity categories clean |
| CONDITIONAL | 1 | Only WARN findings — operator-acceptable gaps |
| FAIL | 2 | One or more ERROR findings — sprint is not a valid trial |

### 6.1 Maturity tiers (inherited from v4.88-stable B+ Bridge Hardening)

In v4.89 the verifier runs GUIDED-tier checks on three of the five integrity
categories (the maturity layout was first established by the v4.88-stable
B+ Bridge Hardening line and is preserved verbatim by v4.89):

| Category | v4.89 tier | What landed in B+ |
| --- | --- | --- |
| init | **GUIDED** | real profile bootstrap + adapter-manifest cross-check + `profile` / `runtime_profile` alias accepted |
| execution | SCAFFOLD | minimum transition + apply/cleanup pairing (v4.90 will raise to GUIDED) |
| external | SCAFFOLD | write+verify pairing (v4.90 will raise to GUIDED) |
| evidence | **GUIDED** | handoff+validation cross-check per task_id + evidence_refs path existence |
| close | **GUIDED** | archive transition recorded + checklist fully ticked + terminal event |

The verifier output field `"maturity_tier": "MIXED"` reflects this split.

The 5 integrity categories (see `docs/09_beta_sprint/BETA_SPRINT_EXIT_CRITERIA.md`):

1. **Initialization integrity** — runtime_state present, profile
   matches
2. **Execution integrity** — at least one transition; merge apply
   paired with cleanup
3. **External sync integrity** — every TAPD write paired with a
   successful verify
4. **Evidence integrity** — audit log non-empty and parseable;
   evidence-class events present
5. **Close integrity** — checklist fully ticked; terminal event
   present

See `examples/_mock_baselines/trial_scenarios/` for five canonical sample outputs
(S1 PASS / S3 PASS / S4 FAIL / S5 FAIL / S5b PASS — S4 FAILs post-M7.3
Lift gate because its runtime_state intentionally omits `audit_collector`
+ `context_loading_method`; S5b is a B+ hardening counter-example proving
a workbuddy_private sprint **can** reach PASS when run correctly). Run
`bash scripts/run_mock_smoke.sh` to exercise all five against a fresh
verifier build (5/5 matches expected).

### 6.2 Real-trial workspaces

In addition to the pre-baked Mock scenarios, v4.89 ships a real-trial
workspace driven by the hardened scripts end-to-end:

- `trial_workspaces/rh_sprint_sim_01/` — a simulated workbuddy_private sprint
  (based on RandomHeroes policy/) that produced the Real Trial v1 report on
  2026-05-02 (during the v4.88-stable era). Expected verdict: **CONDITIONAL**
  (0 error / 2 warn), documenting the 9 findings that drove the v4.89 Phase 1
  scope. See `trial_workspaces/README.md` for the four-step replay recipe.

## 7. FAQ

### Q1. Do I have to use TAPD?

No. `common/hook_sprint_tracker_sync.md` lets you bind any tracker
(Jira / Linear / custom). The audit log only expects
`external.tapd.write` / `external.tapd.verify` event_types by default
— rename them to match your tracker if you want, as long as your
collector and verifier agree.

### Q2. Do I have to use all 5 profiles?

No. Choose one. You can switch profiles for future sprints but do
not switch mid-sprint.

### Q3. Do I need the shipped `skills/_generic_core/` as-is?

Yes and no. Package them as reference, but your project can override
any specific skill by creating a file of the same name under
`policy/skills/<subsystem>/`. Assemble prefers project overrides when
both exist.

### Q4. How is v4.89 different from v4.87 / v4.88 RC12 / v4.88-stable?

- v4.87 had the runtime muscle (Route A scripts, 5 adapter stubs)
  but no portable shape.
- v4.88 RC12 had the portable shape but had lost the v4.87 runtime.
- v4.88-stable re-attached v4.87 runtime onto v4.88 RC12's shape
  (Phase 2), added a Mock verification harness (Phase 4), and
  hardened four of the key runtime modules from SCAFFOLD to GUIDED
  via B+ Bridge Hardening (init / evidence / close / verifier —
  see §6.1). B+ closed with one real-trial workspace
  (`trial_workspaces/rh_sprint_sim_01/`) that exercises the whole
  chain end-to-end.
- v4.89 inherits the v4.88-stable line in full and adds Phase 1
  (11 permanent contracts), Phase 2 Stage 1 (LTM MVP), Phase 2
  Stage 2 (5-profile parity), Phase 3 (schema-driven cross-checker
  collapse), and Phase 4 (lift gate + skills import + sprint+agent
  cold-start governance + cross-project LTM Layer A namespace).

### Q5. What about long-term memory, self-evolution, cross-project platformization?

- **Long-term memory**: shipped in v4.89 (Phase 2 Stage 1 MVP +
  Phase 4 M9.5 Layer A namespace). 4 domains + 5 Gate rules +
  `consult / capture` two-call API + optional `project_id` YAML field.
- **Self-evolution / cross-project platformization**: still out of
  scope. Deferred to v4.90+ (Layer C `replay()` + auto-promotion of
  cross-project patterns / Evolution Roadmap stages 2/3/4).

### Q6. Where is RandomHeroes' special Slot-Roguelike content?

In `game_type_packs/spin_rogue_idle_project_pack/`. Select it via
`game_pack` in your selection JSON when running assemble.

### Q7. Where do I report bugs / file requests?

- Bug: open an issue in the project tracker (TAPD / GitHub / ...)
- v4.90 backlog: see `V4.89_BACKLOG.md` (file name retains the v4.89
  prefix; contents track v4.90 deferrals).

## 7.5. v4.89 Phase 1 Update (inherited from v4.89 freeze)

v4.89 Phase 1 (tag `v4.89-phase-1`, 2026-05-02) hardens three more classes
of drift found during Real Trial v1. The behavior is additive — all
v4.88-stable workflows in §6 continue to work unchanged.

### 7.5.1 Envelope helper (`wrap_external_record`)

Adapter-normalized records (`tapd._live_path`, `git.merge_apply`, …) no
longer need to be hand-wrapped into audit envelopes. The collector now
ships a helper:

```python
from runtime.observability.runtime_event_collectors.workbuddy_collector import (
    append_audit, wrap_external_record,
)

envelope = wrap_external_record(
    record,                            # adapter-normalized dict
    source_layer="tapd",               # "tapd" | "git" | "workbuddy"
    runtime_profile="codex",
    actor="main_session",              # optional
    event_type=None,                   # optional; auto-inferred
)
append_audit(workspace, envelope)
```

`wrap_external_record` auto-fills `event_id` (uuid4), `timestamp`
(ISO UTC), and `audit_status="pending"`. See `tests/test_wrap_external_record.py`
(8 cases) for the canonical contract.

### 7.5.2 Malformed-event fallback

`append_audit(strict=False)` no longer silently drops envelopes that fail
validation. They are now written to
`<workspace>/runtime/logs/mcp_audit.malformed.jsonl` with a reason
annotation, so dropped events can be recovered. See
`tests/test_collector_malformed_fallback.py`.

### 7.5.3 Profile field alias + runtime_state location

- `runtime_state.json` now carries **both** `profile` and `runtime_profile`
  fields (same value). `verify_beta_sprint_exit.py` accepts either
  alias. No code change required for callers that already set `profile`.
- Canonical `runtime_state.json` location is now
  `<workspace>/runtime/state/runtime_state.json`; a 1-line pointer shim
  `{"_moved_to": "runtime/state/runtime_state.json", "canonical": true}`
  is written at the workspace root for back-compat with v4.88-stable
  tooling.

### 7.5.4 pytest regression suite + two-layer CI

v4.89 ships its own `tests/` pytest suite (259 cases covering Phase 1 → Phase 4
contracts: envelope + LTM MVP + 5-profile parity + schema-driven cross-check
+ lift gate + cold-start governance + Layer A namespace) plus a two-layer
CI gate (GitHub Actions + pre-commit). See `DEVELOPMENT.md` for setup and
`tests/` for the suite.

### 7.5.5 What's next (v4.90)

- `execution` / `external` integrity categories raise to GUIDED (still SCAFFOLD
  in v4.89).
- W2 timestamp monotonic enforcement.
- LTM Layer B retrieval upgrade (SQLite FTS5 / `sqlite-vec` vector search).
- LTM Layer C self-evolution (`replay()` + auto-promotion of cross-project patterns).
- TAPD / Git live adapters (currently normalize stubs).
- Architecture Linter rules A / B / D real implementations.

See `docs/V4.89_BACKLOG.md` for the full v4.90 deferral list (file name
retains the v4.89 prefix; contents track v4.90 work).

## 8. Cross-references

- `docs/ASSEMBLY_GUIDE.md` — original v4.87 Assembly Guide (terse)
- `docs/06_runtime_profiles/Runtime_Profile_Comparison.md` — profile
  selection dimensions
- `docs/02_governance/*.md` — 5 governance docs
- `docs/09_beta_sprint/BETA_SPRINT_EXIT_CRITERIA.md` — verifier
  contract
- `skills/README.md` — Skills architecture and origin
- `examples/_mock_baselines/trial_scenarios/README.md` — 4 verification Mock
  scenarios
- `PHASE_4_TRIAL_GUIDE.md` — companion: first Beta Sprint
  walk-through
