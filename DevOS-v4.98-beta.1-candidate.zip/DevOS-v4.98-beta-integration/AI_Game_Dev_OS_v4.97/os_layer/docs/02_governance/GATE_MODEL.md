# Gate Model

> **Scope**: v4.89 minimum gate model. Restores the canonical gate vocabulary that was dropped between v4.8.2 and v4.88 RC12.
> **Origin**: v4.8.2 `GATES.md` 4-gate model + v3 §9/10 Feature Lifecycle (lightweight subset).
> **Not included**: v3's 7-gate scheme and 10-state Feature Lifecycle are intentionally not restored; see REV-2-007 resolution rationale.

## 1. Four Canonical Gates

Every Sprint / feature delivery must pass through these gates in order:

| # | Gate | Purpose | Pass criterion | Owner |
| --- | --- | --- | --- | --- |
| 1 | **readiness** | upstream prerequisites met; scope locked; owner assigned | spec signed; dependencies resolved; readiness checklist filled | Orchestrator + EP |
| 2 | **validation** | implementation meets the spec's observable behavior | engine validation passes (see `_adaptation_hooks/common/hook_engine_validation.md`); evidence captured | Producer + QA |
| 3 | **approval** | reviewer confirms acceptance; owner signs off | Gate Signoff per `_generic_core/ep/EP_DELIVERY_CONTRACT.md`; reason recorded | EP (or delegated review owner) |
| 4 | **closure** | state is reconciled externally; archived; followups tracked | registry updated; external tracker synced; audit record written | Orchestrator |

A gate may return **PASS / CONDITIONAL_PASS / FAIL** per `_adaptation_hooks/common/hook_gate_standards.md`.

## 2. Gate-to-Evidence Binding

Each gate requires evidence of the listed type. "Prose-only" approval is not a pass.

| Gate | Required evidence type | Where written |
| --- | --- | --- |
| readiness | spec file + readiness checklist | project-bound spec dir + task_registry entry |
| validation | engine validation log + QA report (if applicable) | runtime/logs/ + project playtest report dir |
| approval | EP decision record | task_registry `gate_results` + status doc |
| closure | reconciliation report + external writeback confirmation | audit log + tracker record (verified via `read_after_write_verifier.py`) |

Evidence must match schema where schemas exist:
- `schemas/external_sync_audit.schema.json` for tracker writeback
- project-bound `playtest_report.schema.json` for QA validation
- project-bound `ep_decision_record.schema.json` for approval

## 3. Feature Lifecycle (lightweight, 7 states)

A feature moves through these states during its delivery:

```
IDEA → SPEC → IMPLEMENTED → VALIDATED → APPROVED → ARCHIVED
                     ↘ REWORK ↗
```

| State | Entry | Exit |
| --- | --- | --- |
| IDEA | request received | Orchestrator decomposes into Task Brief |
| SPEC | Game Design produces spec | readiness gate PASS |
| IMPLEMENTED | Engineering completes code/art/content | validation gate PASS |
| VALIDATED | QA + engine validation complete | approval gate PASS |
| APPROVED | EP signs off | closure gate PASS |
| ARCHIVED | Sprint close archives | — (terminal) |
| REWORK | any validation/approval FAIL | back to SPEC or IMPLEMENTED per FAIL class |

Only **APPROVED → ARCHIVED** and the REWORK branch back to SPEC/IMPLEMENTED are valid retrograde transitions. All other transitions are forward only.

## 4. Related Files

- `docs/02_governance/PORTABLE_AGENT_BOUNDARIES.md` §Detection table — per-rule gate binding
- `docs/03_runtime_core/AI_Game_Dev_OS_v4.87_Registry_Writeback_and_Reconciliation_Contract.md` — how gate outcomes reconcile with registry / external tracker
- `_adaptation_hooks/common/hook_gate_standards.md` — project-level GATES.md binding
- `docs/09_beta_sprint/BETA_SPRINT_EXIT_CRITERIA.md` — Sprint-level application of gate 4 (closure)

## 5. REV-2-007 Resolution Rationale

v3 defined 7 gates (Spec / Contract / Runtime / Architecture Linter / Regression / Visual-Spatial / Playtest) and a 10-state Feature Lifecycle. v4.88 RC12 dropped both entirely.

v4.89 restores a **4-gate + 7-state** subset rather than the full v3 model because:

- v4.8.2 already consolidated to 4 gates after operational evidence showed 7 had too much overlap
- Architecture Linter gate is separately restored in `docs/05_architecture_linter/` (Phase 2 Step 3, commit `a78bf3c`) — it runs alongside this gate model rather than as a fifth gate
- Regression / Visual-Spatial / Playtest are now sub-evidence under `validation` rather than their own gates
- The 10-state lifecycle proved harder to operate than the 7-state simplification; REWORK branch is preserved

Projects that need the full 10-state machine may extend via `policy/STATE_MACHINE.md` or equivalent at the project layer.
