# Subagent Boundary Spec — v4.76 Execution Model + RandomHeroes Orchestrator Rules

> **v4.88_Revise Phase 2 Step 3** merged artefact (preserved in v4.89)
> **Merge sources**:
> - **v4.76 Subagent Execution Model** (long-lived Agent + short-lived Subagent parent/child execution structure)
> - **RandomHeroes Orchestrator hard rules** (prompt must not contain producing verbs / serial-only constraint / rate-limit protection, and other project-practice learnings)
> **Established**: 2026-04-21

## Why this Spec exists

v4.76 introduced the Subagent Execution Model for the first time ("short-lived Subagent as extension of a long-lived Agent"), but v4.77–v4.88 did not upgrade it into a **hard contract**. RandomHeroes policy distilled Orchestrator hard rules from production, but they live only at the project layer. The two are **complementary but independent**, so we merge them into a single Spec and avoid another conflict pass at Phase 3 review time.

## Core Model

### 1. Long-lived Agent vs. Short-lived Subagent (from v4.76)

| Dimension | Long-lived Agent | Short-lived Subagent |
| --- | --- | --- |
| Lifetime | Whole sprint / phase | Single task, single session |
| State persistence | Writes memory / registry | No persistence; dies on return |
| Responsibility | Coordinate / decide / handoff | Execute / explore / summarise |
| Caller | EP or another Agent | Parent Agent |
| Output form | Decisions + state changes | Report + structured data |

### 2. Parent/Child Execution Contract

**Parent Agent duties**:
- Provide the Subagent with complete context (never rely on knowledge only the parent has).
- Define the structured output schema the Subagent must produce.
- Consume the Subagent's return and make decisions locally — do not forward-and-re-derive.

**Subagent duties**:
- Deliver complete results in one call (one call = one report).
- Keep no state; do not continue across sessions.
- Explicitly declare capability boundaries (read-only / write-allowed / tool list).

## RandomHeroes Hard Rules (production distilled)

### Rule R-01 — Prompts must not contain producing verbs

**Problem**: When the Orchestrator hands work to a Subagent with prompts like "please generate / write / modify …", the Subagent often widens its scope on its own.

**Rule**: Orchestrator → Subagent prompts may contain only:
- **Exploration verbs**: search / scan / read / analyze / compare / verify / report
- **Structured instructions**: return as `<schema>` / output to `<path>`

**Forbidden verbs**: generate / create / write / modify / produce / build. Those are for the parent Agent to do directly; they are not delegated.

### Rule R-02 — Subagents run serially

**Problem**: Concurrently spawning multiple Subagents triggers API rate limits (memory 32993224: Team-Mode concurrency protection).

**Rule**:
- A main Agent **must not spawn Subagents in parallel**.
- Serial only: spawn the next one only after the previous one has returned.
- When "apparent parallelism" is needed, the parent batches the work locally and spawns one Subagent with the batched request.

### Rule R-03 — Team-Mode exception

Team Mode (several long-lived Agents cooperating) may coexist, but:
- Team members communicate asynchronously via `send_message` — those are not concurrent subagents.
- Each member still obeys R-02 internally.
- Total active-agent count within a Team must not exceed the project's policy cap (default 4).

### Rule R-04 — Escalation path

When a Subagent discovers a task outside its scope, it **must not widen it**. It must return a structured marker:

```json
{
  "status": "ESCALATE",
  "reason": "Required to modify files outside scan scope",
  "escalation_to": "parent_agent",
  "suggested_action": "spawn new subagent with write permission OR parent handles directly"
}
```

On receiving `ESCALATE`, the parent Agent **must report to EP**; it must not silently spawn a replacement.

## v4.76 Execution-Model Merge Points

### Subagent lifecycle state machine

```
   [spawn_requested]
         ↓
   [initialized]  ← inherits parent context + independent context window
         ↓
   [executing]    ← performs exploration / compute / summary
         ↓
   ┌────────┬────────┬───────┐
[completed] [failed] [timeout] [escalated]
         ↓          ↓          ↓
   [report_returned] ← parent Agent consumes → [terminated]
```

### Three typical Subagent roles

| Role | Scenario | Output |
| --- | --- | --- |
| **Explorer** | Codebase scan / path mapping / dependency-graph analysis | Structured inventory |
| **Validator** | Spec-conformance check / QA gate | PASS/FAIL + evidence |
| **Summarizer** | Multi-doc review / historical trace | Consolidated report |

## Interaction with Architecture Linter (RULE_D)

RULE_D.D4 ("test helper leaking into runtime directories") also applies to the Subagent scenario:
- Subagent-produced temporary files under `.workbuddy/tmp/` **must not** enter runtime directories.
- `*_mock.json` / `*_test.py` written by a Subagent must live under `tests/` / `examples/`.
- Linter D4 static scan + Subagent Boundary R-04 runtime guard = double line of defence.

## Relation to v4.87 Managed Autonomy Guardrails

- **Managed Autonomy** (already at `docs/02_governance/AI_Game_Dev_OS_v4.87_Managed_Autonomy_Guardrails.md`) defines **when an Agent must consult EP**.
- **Subagent Boundary Spec** (this document) defines **the contract for Agents spawning Subagents**.
- The two are orthogonal: the former governs Agent ↔ EP, the latter governs Agent ↔ Subagent.

## Checkpoints (Phase 3 implementation)

Self-check before the Orchestrator spawns a Subagent:

- [ ] Does the prompt contain any R-01 forbidden verbs?
- [ ] Is there already an active Subagent (R-02)?
- [ ] Is the Subagent context self-contained (no reliance on parent history)?
- [ ] Is the output schema explicit?

## Implementation Notes

### Adjustments for the existing Agent system

| Agent type | Adjustment |
| --- | --- |
| EP / Orchestrator | Adopt R-01–R-04 as SOP |
| Long-lived member | Follow R-03 in Team Mode |
| Builder / Fixer | Obey R-01–R-02 when spawning Subagents |
| Validator | Canonical Subagent-Explorer implementation |

### Plan / Todo system guidance

- If a Plan todo spawns a Subagent, tag the todo content with `[subagent:type]`.
- A Plan's `Agent Extensions / SubAgent` section must list purpose + expected outcome (Plan 086af2bd already demonstrates this).

## References

- v4.76 Subagent Execution Model (source location: `AI_Game_Dev_OS_V4_78_Tier1/docs/subagent_execution_model.md` or the earlier v4.76 package).
- RandomHeroes Orchestrator rules (source: `<UPSTREAM_PROJECT_ROOT>/RandomHeroes/policy/orchestrator_rules.md`).
- Plan 086af2bd Phase 2 Step 3.
- Phase 0 evidence: historical archive, see CHANGELOG "Phase 1 §C" entry.
- Linked: RULE_D (Architecture Linter) / Managed_Autonomy_Guardrails.

## Phase 3 TODO

- [ ] Write `scripts/governance/check_subagent_boundary.py` (prompt pre-check R-01–R-04).
- [ ] Add R-01–R-04 to the Orchestrator Agent SOP document.
- [ ] Add an enforcement layer for R-03 in the Team-Mode orchestrator.
- [ ] Unify numbering with Managed Autonomy Guardrails via cross-reference.
