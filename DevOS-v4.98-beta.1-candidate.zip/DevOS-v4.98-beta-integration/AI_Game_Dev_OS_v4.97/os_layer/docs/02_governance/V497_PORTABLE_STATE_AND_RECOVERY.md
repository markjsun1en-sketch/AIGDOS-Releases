# v4.97 Portable State and Recovery Boundary

This contract defines the package-local Slice 7 baseline for a Portable
Project State Bundle (PPSB), inspect-before-import recovery, workspace SQLite
backup/recovery and Adapter read/recovery conformance. It does not authorize a
project-clone write, external Adapter contact, qualification, promotion,
release or production/live use.

## Portable object boundary

A PPSB is a deterministic, content-addressed export of an explicit selection.
Eligible object classes are assembly locks, quality profiles, efficacy
receipts, Truth, State, Evidence, Project Memory and Team Memory. Every object
binds its source ID/revision/ref, schema, lifecycle state, visibility
classification, dependencies and content digest.

Private state, Human approval, hidden holdout solutions, live credentials and
raw SQLite databases are excluded. Their presence is not disclosed by the
manifest. Only `public` and `project_internal` classifications are portable.
Local absolute paths are rejected recursively. Export permission is checked
before bundle construction, and read permission is checked before an import
inspection can return IDs or counts.

The canonical manifest excludes the export timestamp and sorts selected
classes, Adapter capabilities and objects. The timestamp remains in the
source export receipt. A PPSB imports no Human/lifecycle authority and gives
every Adapter `not_promoted_not_eligible` write status.

## Inspection and recovery

Inspection changes no target state. Envelope or required-object failure blocks
recovery. An invalid optional object is isolated; a required dependency on an
invalid item invalidates the dependent item. Recovery accepts only an exact
same-project scope or a declared isolated scope whose root appears in the
caller's admitted-root set.

Recovered objects live below a recovery-specific directory and are explicitly
an isolated portable view, never current project Truth. Each atomic object
write is followed by a content-bound checkpoint. Restart verifies every prior
file and checkpoint before resuming; divergence fails closed. The final
receipt binds the source manifest, target scope, Adapter profile/executable,
recovered inventory and assembly-lock digests.

## Workspace database recovery

The workspace SQLite database remains service-owned and is never a PPSB
object or an Adapter-facing file contract. The service performs WAL truncate
checkpoints, SQLite online backups, `quick_check`, application/user-version
checks and a logical inventory comparison. Restore accepts only a catalogued
backup whose exact file digest and logical inventory reverify. A backup is
frozen with no active writer fence; restore rejects any snapshot that still
claims an active writer, re-establishes the current service instance/epoch and
then emits a service-instance-bound receipt. This permits a verified backup to
recover after an orderly service restart without reviving the old writer.
Project-local Truth remains authoritative when the workspace database is
unavailable or restored.

## Adapter state

The Codex package-local read/recovery profile binds the exact conformance
implementation bytes and declares no external model call, project-clone write,
production execution or write eligibility. Synthetic tests exercise
capability negotiation, inspection, interruption/restart, isolated recovery,
digest equality and suspension.

WorkBuddy remains only a Human-selected pending binding. Its executable and
profile identities are unset, it has no conformance receipt, and its status is
`not_authorized_not_contacted`. Real WorkBuddy contact requires a later exact
Human authorization naming the executable, sanitized input scope and
non-writing invocation.
