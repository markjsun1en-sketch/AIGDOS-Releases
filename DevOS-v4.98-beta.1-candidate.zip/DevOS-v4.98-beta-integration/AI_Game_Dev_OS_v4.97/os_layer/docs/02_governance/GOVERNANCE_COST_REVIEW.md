# Governance Cost Review

> **Scope**: v4.89 — periodic review of governance volume vs operational benefit.
> **Origin**: v4.87 `docs/00_entry/GOVERNANCE_COST_REVIEW_RULES.md` + `OPERATING_CONSTITUTION.md` §3 "Governance must justify its cost". v4.88 RC12 dropped these; v4.89 (inheriting from v4.88_Revise) restores the periodic review.

## Purpose

Governance that grows without pruning eventually becomes expensive to read, expensive to comply with, and expensive to change. Periodic cost review is the counterweight to Change Admission: admission prevents bad additions; cost review prunes additions that did not deliver value.

## Cost Dimensions

Each governance document carries three costs:

| Cost | How it is measured |
| --- | --- |
| **Read cost** | How long does a new contributor spend reading it before they can work? |
| **Compliance cost** | How many minutes / steps does each sprint spend following this rule? |
| **Maintenance cost** | How often does it need updating? Does it drift behind code? |

## Review Cadence

- **Per-sprint spot check**: during Sprint Close (per `SPRINT_OPERATING_MODEL.md`), flag any governance doc that was cited but caused friction.
- **Per-release review**: at each minor-version bump (e.g. v4.88 → v4.89; next will be v4.89 → v4.90), every doc in `docs/02_governance/` receives a cost review; those failing cost checks are archived or merged.
- **Ad hoc**: if a doc has not been cited in any commit message or review for 6+ months, it is a candidate for archival.

## Review Outputs

For each reviewed doc, produce one of:

- **Keep** — cost is justified by operational value; no change
- **Consolidate** — merge into a related doc to reduce total volume
- **Archive** — move to a dedicated archive location with a forwarding pointer
- **Promote to schema/script** — if the rule is precise enough, replace prose with a schema or a validator

## What this is NOT

- Not a license to delete governance that is currently enforcing something — prove no enforcement first
- Not a bureaucratic audit — the goal is operational simplification, not process theater

## Cost-Benefit Rule

A governance doc is cost-justified when its compliance cost per sprint is less than the cost of one instance of the failure mode it prevents. If the failure mode has never happened in recorded audit history, review the doc's origin rationale and reassess.

## Related Files

- `docs/02_governance/CHANGE_ADMISSION.md` — prevents low-value governance from being admitted
- `docs/02_governance/GATE_MODEL.md` — where approval gates consume governance cost
- `docs/12_release_notes/V4.87_to_V4.88_Upgrade_Notes.md` — Capability Deprecations show the pattern of cost-based deferral
