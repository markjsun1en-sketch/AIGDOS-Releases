# Governance Map

## Purpose

v4.89 governance is intentionally split across multiple layers. This file exists so the governance layer does not appear artificially "smaller" just because part of the old governance body moved into runtime-profile, starter, audit, and beta-sprint docs.

## Governance still centered in `docs/02_governance/`

These files define cross-runtime governance rules:

- `PORTABLE_AGENT_BOUNDARIES.md`
- `PORTABLE_RECOVERY_PRINCIPLES.md`
- `GATE_MODEL.md` — 4-gate canonical model (readiness / validation / approval / closure) + 7-state Feature Lifecycle
- `SPRINT_OPERATING_MODEL.md` — 3-phase Sprint structure + readiness/close essentials (lifts back from `docs/09_beta_sprint/` trial-only home)
- `SKILLS_MODEL.md` — Skill minimum contract + Skill-to-Gate binding pattern (public Skills in `skills/_generic_core/`)
- `CHANGE_ADMISSION.md` — four-question gate on new governance additions
- `GOVERNANCE_COST_REVIEW.md` — periodic pruning rules to counterbalance governance growth
- this governance map

> **Note (2026-04-22, REV-1-012 cleanup)**: earlier drafts of this map also listed `VIRTUAL_AGENT_RULES.md` and `APPROVAL_AND_WRITEBACK_POLICY.md` with a "(when present)" hedge. Those files do not exist in the current release. They were removed from this list to match `REQUIRED_CONTENT_CHECKLIST.md`. If a future release restores them, add them here and add them to the required-content checklist together.

These files answer:
- who may do what,
- which actions require explicit ownership,
- who owns cleanup/recovery,
- which rules apply regardless of runtime.

## Governance moved into other layers

### Runtime governance
Located under `docs/03_runtime_core/`

Examples:
- runtime bootstrap rules
- root discovery
- init/no-demo rules
- migration/path validation
- **Registry Writeback & Reconciliation Contract** (`AI_Game_Dev_OS_v4.87_Registry_Writeback_and_Reconciliation_Contract.md`) — defines the three-layer truth model reconciliation algorithm (code / evidence / registry write authority + conflict resolution)

### Integration governance
Located under `docs/04_integrations/`

Examples:
- TAPD kickoff/close SOP
- serial merge policy
- merge conflict protocol
- external writeback verification

### Observability governance
Located under `docs/05_observability/`

Examples:
- audit log standards
- reconciliation report spec
- sprint-close audit expectations

### Runtime-specific governance
Located under `docs/06_runtime_profiles/`

Examples:
- runtime-specific rule loading
- runtime-specific writeback owner
- runtime-specific recovery SOP
- runtime-specific cleanup ownership

### Starter / onboarding governance
Located under `docs/07_starters/`

Examples:
- boot readset
- starter assembly sequence
- starter review checklist
- runtime-specific starter guides

### Trial governance
Located under `docs/09_beta_sprint/`

Examples:
- beta sprint precheck
- execution checklist
- exit criteria
- failure matrix
- recovery playbook

## Reading rule

When evaluating whether governance is "missing", do **not** inspect `docs/02_governance/` in isolation.
Use this map to follow governance across runtime core, integrations, observability, runtime profiles, starters, and beta sprint docs.

## Practical review question

The correct question is not:

> "Is `docs/02_governance/` as large as older governance packs?"

The correct question is:

> "Are governance responsibilities still covered somewhere in the v4.89 architecture, and are their ownership boundaries clearer than before?"
