# Sprint Operating Model

> **Scope**: v4.89 governance-layer entry for Sprint operation. Restores the `docs/02_governance/` home for Sprint operating concepts that v4.88 RC12 had scattered into `docs/09_beta_sprint/` checklists only.
> **Origin**: v4.87 `docs/02_governance/Sprint_Operating_Model.md` + `Sprint_Opening_Checklist.md` + `Sprint_Execution_Cadence.md` + `Sprint_Close_Checklist.md` + `Sprint_Readiness_and_Close_Rules.md` (14.1KB).

## 1. Why this lives in `02_governance/`

Sprint execution is a governance concern, not a trial-only concern:

- Sprint readiness, execution cadence, and close rules bind EP, Orchestrator, and all producing Agents. Placing them exclusively under `docs/09_beta_sprint/` (trial-focused) falsely signaled they apply only to Beta Sprint trials.
- Gate Model (see `GATE_MODEL.md`) defines the 4 gates; Sprint Operating Model defines how a Sprint moves through those gates over time.

## 2. Three-Phase Structure

Every Sprint has three phases. Each phase has an entry gate, a procedural document set, and an exit gate.

| Phase | Entry gate | Procedural docs | Exit gate |
| --- | --- | --- | --- |
| **Opening** | readiness | `docs/09_beta_sprint/SPRINT0_PRECHECK.md` (trial contexts) + project-bound Sprint Kickoff SOP | opening signed off by EP |
| **Execution** | opening signoff | `docs/09_beta_sprint/SPRINT_EXECUTION_CHECKLIST.md` + `_generic_core/orchestrator/orchestrator_workflow_ops.md` Task Routing section | all in-scope tasks reach VALIDATED |
| **Close** | all tasks VALIDATED | `docs/09_beta_sprint/SPRINT_CLOSE_CHECKLIST.md` + `docs/09_beta_sprint/BETA_SPRINT_EXIT_CRITERIA.md` + Sprint Close Audit Checklist | closure gate PASS + Sprint archived |

## 3. Operating Responsibilities

| Role | Opening | Execution | Close |
| --- | --- | --- | --- |
| EP | approve scope + gate signoffs | respond to escalations; ruling on Scope Changes | approve closure + final signoff |
| Orchestrator | kickoff SOP; create task_registry; Sprint-tracker iteration sync | Task routing; parallel-agent safety rules; tracker proxy sync | state reconciliation scan; archive tasks; update status doc |
| Producing Agents | confirm upstream spec + dependencies | execute per `_generic_core/<subsystem>/*_workflow_ops.md` | deliver per CONTRACT; write completion log |
| QA | review readiness criteria | Playtest sessions; gate validation | sign validation gate; author exit report |

## 4. Readiness & Close Rules

The detailed rules (originally in v4.87 `Sprint_Readiness_and_Close_Rules.md` 14.1KB) are being restored progressively; v4.89 (inheriting from v4.88_Revise) covers the essentials below and defers the full rule set to v4.90:

### Readiness (must all be true before Opening exit)

- [ ] Sprint goal documented in tracker + status doc
- [ ] All in-scope tasks have owners (task_registry)
- [ ] All upstream specs PASS readiness gate (per `GATE_MODEL.md`)
- [ ] Adapter bindings confirmed (Sprint-tracker + Git) per `hook_sprint_tracker_sync.md`
- [ ] Blocker registry reviewed; no P0 blockers outstanding

### Close (must all be true before Close exit)

- [ ] All in-scope tasks reached APPROVED or explicit REWORK/defer state
- [ ] Registry vs external tracker reconciled (see Registry Writeback Contract)
- [ ] Audit log complete and summarizable per `AUDIT_LOG_STANDARD.md`
- [ ] EP signoff recorded per `_generic_core/ep/EP_DELIVERY_CONTRACT.md`
- [ ] Status doc updated; next Sprint's readiness flags set

## 5. Related Files

- `docs/02_governance/GATE_MODEL.md` — the 4 gates this model moves through
- `docs/02_governance/PORTABLE_AGENT_BOUNDARIES.md` — role overreach rules during Sprint execution
- `docs/02_governance/PORTABLE_RECOVERY_PRINCIPLES.md` — when Sprint hits a failure mode
- `docs/09_beta_sprint/*` — trial-specific checklists (these remain where they are; this governance doc is the general home)
- `_generic_core/orchestrator/orchestrator_workflow_ops.md` — the concrete Orchestrator procedure
- v4.87 `Sprint_Readiness_and_Close_Rules.md` — reference archive for the 14.1KB detailed rule set (not yet fully restored)

## 6. Deferred Work

The v4.87 detailed `Sprint_Readiness_and_Close_Rules.md` (14.1KB) is **not fully ported** in v4.89 per 9-decision #5 ('harden, do not expand'). v4.89 restores:

- governance-layer home (this file)
- essentials checklist (§4)
- cross-references to Gate Model, Registry Writeback, and Orchestrator ops

Full rule-set restoration is tracked as REV-2-008-deferred for v4.89.
