# Portable Recovery Principles

## Purpose

These recovery principles apply across all runtime profiles. They exist so that cleanup and state recovery do not depend on one tool's private semantics.

## Core Principles

1. Recovery starts by identifying the **control owner**.
2. External writeback recovery must never guess; it must reconcile against verified external state.
3. Runtime state recovery must prefer explicit ledger repair over silent drift.
4. Cleanup belongs to the parent / lead / main control owner, not to whichever worker failed.
5. Recovery actions must leave an audit trail.
6. If recovery cannot be made safe, downgrade to a controlled manual step rather than auto-healing blindly.

## Recovery ladder

Use the smallest sufficient intervention first:

1. retry a safe read / verification step
2. repair metadata or coordination state
3. isolate the failed worker / branch / worktree / team scope
4. centralize control back to parent/lead
5. perform explicit reconciliation
6. archive or retire the broken path if safe repair is not possible

## Portable vs runtime-specific

These principles are portable.
The concrete mechanics differ by runtime profile:
- Codex may rely on parent + subagent/worktree control,
- Cursor may rely on parallel worktree/apply discipline,
- Claude may use hooks and lead/subagent cleanup,
- Workbuddy may rely more heavily on proxy sync and dirty-state repair.

## Review check

A runtime-specific recovery SOP is acceptable only if it stays consistent with these principles.
