# Portable Agent Boundaries

## Purpose

This document defines agent-boundary rules that apply regardless of runtime environment.
Its job is to prevent structural role overreach, especially in environments where delegation is easy and the control agent can be tempted to "just do the work directly."

## Core Rules

1. A worker may execute scoped task work, but may not redefine OS-level governance.
2. A worker may not claim final external writeback ownership unless the selected execution profile explicitly allows it.
3. Merge/apply authority does not automatically belong to the worker that produced the change.
4. Cleanup authority belongs to the control owner declared by the execution profile.
5. Cross-role output ownership must be respected even when the runtime makes delegation easy.
6. Orchestration authority is not production authority; routing a task does not make the router the rightful author of the downstream deliverable.
7. Query helpers and subagents may support discovery and analysis, but they must not be used as a loophole to bypass explicit output ownership.

## Detection & Enforcement (per Core Rule)

Each Core Rule above is paired with at least one detection mechanism so violations become observable rather than implicit. Scripts and audit events are marked SCAFFOLD/GUIDED/MANUAL/PRODUCTION per `docs/01_architecture/PACK_MATURITY_MODEL.md`.

| Rule | Owner | Trigger | Detection mechanism | Evidence output |
| --- | --- | --- | --- | --- |
| 1 Governance redefinition | control owner | any PR / snapshot touching `docs/02_governance/` by a non-control agent | audit event `runtime.governance_scope_violation` (SCAFFOLD) + manual review gate | audit_event entry in MCP audit log |
| 2 Unauthorized writeback | profile `writeback_owner` | any external tracker mutation | `runtime/integrations/tapd/read_after_write_verifier.py` confirms owner match; mismatch → audit event `runtime.writeback_ownership_violation` (GUIDED) | audit event + registry flag `writeback_ownership_error` |
| 3 Worker merge overreach | profile `merge_owner` | any `git merge` into default branch | `runtime/integrations/git/serial_merge_guard.py` checks merge author vs merge_owner (SCAFFOLD, full impl Phase 4) | audit event `runtime.merge_authority_violation` |
| 4 Cleanup ownership | profile `cleanup_owner` | Sprint close + branch stale events | `runtime/integrations/git/git_branch_cleanup.py` tags branches by cleanup_owner (SCAFFOLD) | sprint-close audit summary |
| 5 Cross-role output ownership | control owner | review of deliverables against Task Brief | manual review + handoff schema validation (`schemas/external_sync_audit.schema.json`) | handoff record + review gate outcome |
| 6 Orchestrator authorship | control owner | orchestrator-role agents producing deliverables | SUBAGENT_BOUNDARY_SPEC.md (Phase 2 governance addition) defines the prompt-level rule; reviewable via daily log scan (MANUAL) | SUBAGENT_BOUNDARY_SPEC-referenced manual review note |
| 7 Helper/query loophole | control owner | subagent/query path producing durable artifacts | `SUBAGENT_BOUNDARY_SPEC.md` §forbidden-verbs rule catches this at brief-authoring time (GUIDED) | prompt-level rejection; if bypassed, audit event |

Empty cells in future versions should be filled by concrete validator scripts or audit events; the table itself is authoritative — any Core Rule gaining scope must also gain a Detection row.

## Why This Exists

Real project evidence shows that role overreach is structural when boundaries are suggestions instead of enforceable rules.
Typical failure mode: the orchestration layer starts drafting design, UI, or content deliverables directly because it has enough context to do so quickly.

## Control-owner rule

Every runtime profile must make these ownerships explicit:

- `writeback_owner`
- `cleanup_owner`
- `merge_owner`
- `review_owner` (when applicable)

If a profile does not define them, the safe fallback is:
- parent/lead owns writeback,
- parent/lead owns cleanup,
- merge is serial and centrally controlled.

## Review check

When reviewing agent behavior, ask:

- Did the right agent produce the deliverable?
- Did the control agent overstep from orchestration into authorship?
- Did any helper path bypass explicit ownership?
