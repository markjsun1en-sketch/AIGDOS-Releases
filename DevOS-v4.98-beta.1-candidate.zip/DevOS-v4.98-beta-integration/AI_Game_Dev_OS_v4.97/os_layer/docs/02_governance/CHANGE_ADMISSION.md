# Change Admission Checklist

> **Scope**: v4.89 — minimum gate on new governance additions.
> **Origin**: v4.87 `docs/00_entry/CHANGE_ADMISSION_CHECKLIST.md`. v4.88 RC12 dropped this file; v4.89 (inheriting from v4.88_Revise) restores the essentials to prevent unbounded governance growth.

## Purpose

New governance documents, rules, and procedures should not be added unless they pass the four questions below. Without this admission gate, governance tends to grow faster than it is used, which is what produced the v4.87 → v4.88 simplification wave in the first place.

## Four Questions

Before adding a new governance document, rule, or procedure, the author must answer yes to all four:

1. **Does it reduce ambiguity?** Adding prose that does not change what gets enforced = noise.
2. **Is there a canonical contract behind it?** If the rule cannot point to a schema, a validator script, or a measurable outcome, it is a preference, not governance.
3. **Would a new contributor need to read the archive to understand current rules without it?** If not, it is an extension rather than a core addition; consider placing it in project adaptation rather than governance.
4. **Does it reduce total governance volume at net?** If adding a 500-line doc replaces 200 lines of scattered rules with one clear statement, admit it. If it only adds, scrutinize.

If any answer is no or unclear, the default is to **not admit**. Restate the problem as a Detection/Enforcement entry in an existing document or as a project-layer convention.

## What this is NOT

- Not a review gate (that is EP's role per `GATE_MODEL.md`)
- Not a style guide (formatting lives in contributor docs)
- Not about deprecating existing content (that is `GOVERNANCE_COST_REVIEW.md`)

## Audit Trail

When a governance change is admitted, record the answers to the four questions in the commit message or PR description. The review gate (`GATE_MODEL.md` approval gate) must verify this audit trail exists before signing off the change.

## Related Files

- `docs/02_governance/GOVERNANCE_COST_REVIEW.md` — periodic pruning of accumulated governance
- `docs/02_governance/GATE_MODEL.md` — where admitted changes get their final signoff
