# Skills Model

> **Scope**: v4.89 governance-layer entry for Skills. Defines the minimum contract every Skill must satisfy + how Skills bind to Gates.
> **Status**: concept restoration. Public-profile Skills content is now populated under `skills/_generic_core/` (34 skills, see `skills/README.md`).

## 1. Why Skills exist

A **Skill** is a named, reusable executable / procedural capability that an Agent can invoke. Skills are the execution backbone that prevents Gates from degrading into descriptive rules: a Gate binds to one or more Skills that produce the Gate's required evidence.

v4.6/v4.7 made Skills a first-class layer. v4.88 RC12 lost the governance-layer Skills concept (retained only in `workbuddy_private/SKILLS.md.template` private form). v4.89 (inheriting from v4.88_Revise) re-seeds the public vocabulary.

## 2. Minimum Skill Contract

Every Skill in `skills/_generic_core/` must include these sections:

| Section | Purpose |
| --- | --- |
| **Purpose** | one-paragraph statement of what the Skill does |
| **Inputs** | required inputs (may include references to adaptation hooks) |
| **Output** | structured output expected; schema reference if available |
| **Trigger** | when the Skill should be invoked (may be a Gate, a Sprint phase, or an explicit task directive) |
| **Minimum Validation** | how to know the Skill output is acceptable |
| **Failure Notes** | common failure modes + recovery hint |
| **Non-Responsibilities** | what the Skill explicitly does NOT do |

Skills in `skills/_adaptation_hooks/` follow a different template (Required Bindings + Project Adaptation Examples) since they are variable-binding placeholders, not execution capabilities.

## 3. Skill-to-Gate Binding

Gate Model (`GATE_MODEL.md`) defines 4 gates. Each gate is satisfied by one or more Skills:

| Gate | Typical Skills satisfying it |
| --- | --- |
| **readiness** | `feature-brief-structuring`, `content-scope-breakdown`, `cross-function-handoff-prep`, `rules-and-constraints-specification` |
| **validation** | `art-consistency-review`, `ui-review-and-iteration`, engine-validation (via `hook_engine_validation.md`), QA Skills (project-bound Playtest) |
| **approval** | EP decision record authoring (`_generic_core/ep/EP_DELIVERY_CONTRACT.md`) — EP signoff itself is not a Skill, but preparing the signoff package is |
| **closure** | Sprint close Skills (to be authored per project), tracker sync (per `hook_sprint_tracker_sync.md`), reconciliation per Registry Writeback Contract |

Concrete binding is project-specific (projects declare which Skills satisfy which Gate in their `policy/` layer); this doc only lists the canonical mapping pattern.

## 4. Public vs Private Skills

**Public Skills** live in `skills/_generic_core/`:
- Portable across all runtime profiles
- Authored in English
- Follow the 7-section contract above
- Current count: 34 (v4.8.2 19 + RH U-class 6 + RH P-class 9 skeleton, per `skills/README.md`)

**Private Skills** live in `docs/07_starters/workbuddy_private/SKILLS.md.template`:
- Bound to workbuddy_private profile only
- Must NOT be adopted by public profiles (see Workbuddy template warning banner added by REV-1-006 fix)

## 5. Skill vs Hook vs Tool

Vocabulary clarification:

| Artifact | Nature | Location | Example |
| --- | --- | --- | --- |
| **Skill** | executable/procedural capability; produces evidence | `skills/_generic_core/<subsys>/SKILL.md` | `art-consistency-review` |
| **Hook** | project-level variable binding for a Skill | `skills/_adaptation_hooks/common/hook_*.md` | `hook_engine_validation.md` |
| **Tool** | concrete script/binary a Skill may invoke | `scripts/`, `runtime/integrations/` | `serial_merge_guard.py` |

A Skill may reference multiple Hooks and call multiple Tools; Hooks and Tools alone are not Skills.

## 6. REV-2-009 Resolution Rationale

REV-2-009 flagged that Skills execution backbone was missing from public profiles. v4.89 closes this via two parallel efforts:

- **Phase 3 Step 1** (commits `cbe3a34` through `a1f2ace`, 10 commits): populated `skills/_generic_core/` with 34 Skills from v4.8.2 + RH two-source integration
- **This commit**: defines the governance-layer Skill contract + Skill-to-Gate binding pattern that `skills/README.md` references

Projects adopting v4.89 now have a real Skills layer to bind their Gates to, not just the private workbuddy SKILLS template.

## 7. Related Files

- `skills/README.md` — Skills layer navigation (two-segment structure)
- `docs/02_governance/GATE_MODEL.md` — the 4 gates that Skills bind to
- `docs/02_governance/PORTABLE_AGENT_BOUNDARIES.md` — boundary rules enforced at Skill execution time
- `docs/07_starters/workbuddy_private/SKILLS.md.template` — private Skills template (non-portable)
