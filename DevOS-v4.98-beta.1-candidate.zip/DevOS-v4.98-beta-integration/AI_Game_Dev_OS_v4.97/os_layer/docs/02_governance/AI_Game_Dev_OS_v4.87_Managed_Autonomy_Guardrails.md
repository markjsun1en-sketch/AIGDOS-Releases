# AI Game Dev OS v4.87 Managed Autonomy Guardrails

## Role
This document keeps the useful part of managed autonomy while rejecting over-idealized autonomy promises.

## Allowed baseline stance
- low-risk derived actions may be automated
- medium-risk changes require review before apply
- high-risk baseline truth changes require human approval

## Forbidden stance
No autonomy path may silently redefine baseline truth boundaries, acceptance rules, or pack override boundaries.
