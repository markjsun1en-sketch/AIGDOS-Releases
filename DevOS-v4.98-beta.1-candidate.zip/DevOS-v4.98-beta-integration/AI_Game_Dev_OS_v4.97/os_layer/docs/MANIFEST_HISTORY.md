---
title: MANIFEST_HISTORY
version: 1.0
status: active
layer: root_meta
since_batch: 14.7
protected_invariants:
  - inv_007_schema_version_const_locked
---

# MANIFEST_HISTORY.md — RELEASE_MANIFEST.json schema evolution

> Canonical changelog for the `manifest_schema_version` field of
> `AI_Game_Dev_OS_v4.90/RELEASE_MANIFEST.json`. Cross-referenced from
> the `manifest_schema_notes` array in the manifest itself; whenever
> a new entry is appended there, append the matching section here.
>
> **Layer**: root-level documentation (NOT under any `docs/<NN>_*`
> Layer 1 governance directory). Free to mention concrete tooling
> and counts.

---

## 1. Mandate

The manifest is consumed by RC integrity checks, smoke runners, and
trial-workspace fixtures. Every time the manifest's schema **shape**
changes (new top-level field, new file-tier, new const value), the
change must be recorded in two places:

1. `RELEASE_MANIFEST.json::manifest_schema_notes` — terse one-line
   blurb embedded with the data, so any reader who opens the JSON
   gets immediate context.
2. This file (`docs/MANIFEST_HISTORY.md`) — long-form rationale,
   batch attribution, and forward-compatibility notes.

The two are kept in lockstep by
`tests/test_manifest_schema_notes_consistency.py`.

---

## 2. Schema-promote waves (batch-attributed)

### v2.0 — Three-tier file taxonomy (pre-v4.90)

Introduced the original three-tier file taxonomy:
- `required_manifest_files` (canonical OS-distribution files)
- `optional_seed_files`     (per-project starter content)
- `required_dirs`           (directories that must exist)

This was the schema baseline at the start of v4.90 and underpins
every later wave.

### v2.1 (P1-5, 2026-05-09) — Test fixtures tier

Added the `test_fixtures` tier so manifest readers can distinguish
runtime content from test plumbing under `trial_workspaces/` while
still carrying sha256 invariants for both. The tier exists because
test inputs are not redistributable canonical files but their
integrity is still a release-defect guard.

### v4.90 Batch 12.1a — Schema promote wave 1

Eight governance + ltm schemas were hardened:
- `additionalProperties: false`
- conditional `required[]` based on context
- explicit type narrowing for free-form `string` fields

Affected schema roots: `schemas/governance/`, `schemas/ltm/`.

### v4.90 Batch 12.1b — Schema promote wave 2

Six protocol + self_evolution + agent_library schemas joined the
hardened set: `schemas/protocol/`, `schemas/self_evolution/`,
`schemas/agent_library/`. Bringing the promoted-schema count to 14.

### v4.90 Batch 14.3 — schema_version const lock

All 14 promoted schemas declare a top-level `schema_version`
property with `const: "1.0.0"` and include it in `required[]`.
The `mcp_audit_log` schema is exempt because it represents an
event-stream record rather than a versioned document.

This is the contract that lets `tests/governance/test_schema_self_validation.py`
and the new `inv_007_schema_version_const_locked` Protected
Behavior Invariant reason about schema-version drift uniformly.

### v4.90 Batch 14.8 — Protected behavior contracts

Two new schemas joined `schemas/contracts/`:
- `protected_invariant.schema.json`
- `protected_regression_matrix.schema.json`

Both pinned at `schema_version: "1.0.0"`. `LAYER_1_ROOTS` was
extended **31 → 33** to add `schemas/contracts/` and
`tests/contracts/` (the runtime-data root
`runtime/protected_contracts/` stays out of LAYER_1_ROOTS by
design; it carries data, not OS Spec).

### v4.90 Batch 14.9 — Portable byte-lock invariant (v4.90.2 patch)

The pre-patch `inv_001_v4_89_byte_lock_immutable` validation command
embedded a hardcoded local git path
(`git -C /Users/.../AI_DEV_OS_Evolve ls-tree HEAD ...`), which made
the invariant pass in the maintainer's working tree but FAIL in any
externally-distributed release zip — a release-artifact portability
gap reported during external sandbox replay.

Batch 14.9 closes the gap with three changes:

1. A new top-level manifest field `byte_lock` records the locked v4.89
   tree SHA (`bb48af16…87767`), the verification mode catalog
   (`source_tree | release_package | skipped`), and the path of the
   release-package fingerprint proof
   (`tests/contracts/v4_89_byte_lock_fingerprint.txt`). Manifest
   schema bumped **2.1 → 2.2**.
2. A portable checker
   `scripts/governance/check_v4_89_byte_lock.py` auto-detects the
   deployment shape: when an outer git working tree is reachable it
   compares the v4.89 sibling tree SHA via `git ls-tree`; when the
   release pack ships its v4.89 sibling alongside it rehashes the
   sibling and matches it against the fingerprint; when neither is
   available it returns `SKIPPED_PACKAGE_MODE` (exit 0; closure gate
   accepts as PASS).
3. The fingerprint generator
   `scripts/governance/gen_v4_89_byte_lock_fingerprint.py` emits a
   stable text file (sorted per-file sha256 + aggregate sha256 + tree
   SHA + file count) from `AI_Game_Dev_OS_v4.89_Release/`. The proof
   file is shipped under `tests/contracts/` so it lives inside
   `LAYER_1_ROOTS` and is preserved by the v4.90 release packager.

`runtime/protected_contracts/protected_regression_matrix.yaml` —
inv_001 `required_validation` was rewritten from the `kind: shell`
hardcoded git command to `kind: python` invoking the new checker. No
other invariants were touched.

`LAYER_1_ROOTS` is unchanged at 33 roots. Manifest required-file
count rises by 6 (4 new `.py` + 2 new `.txt`/`.py` test fixtures).

### v4.90 Batch 14.10 — Final polish (v4.90.3 patch)

No manifest schema-shape change; this batch is a hygiene + drift
sweep that closes 5 polish items spotted in external review of
v4.90.2:

1. README.md / USER_GUIDE.md residual `911 passed / 2 skipped` from
   the v4.90.2 c3 commit (a placeholder that c7 was supposed to lift
   to the final number) corrected to **920 passed / 2 skipped**.
2. RELEASE_NOTES.md frontmatter advanced from v4.90.1 narrative to
   v4.90.3, verification block updated to 920 passed, and a new
   §Patch History block at the end carrying v4.90.1 / v4.90.2 /
   v4.90.3 summaries.
3. `docs/18_cli/README.md` + `CLI_USAGE_GUIDE.md` `ltm consult`
   STUB-label sweep: status `17 leaves wired + 1 STUB` →
   **22 leaves wired / 0 STUB**. The leaf has been fully wired since
   Batch 13.1 via `runtime.ltm.__main__`; `ltm quarantine`
   (Batch 13.4.b) and `evolve propose` (Batch 13) are also counted
   in the new total.
4. New helper `scripts/governance/clean_transients.py` shipped to
   restore the clean-tree contract after users run pytest or any
   CLI command inside an extracted release pack. Idempotent;
   targets `__pycache__/` / `.pytest_cache/` / `*.pyc` /
   `.DS_Store` / `._*` and `exports/*` (preserving
   `exports/.gitignore`). README.md §Verification documents the new
   flow.
5. `scripts/governance/run_v490_rc3_closure_gate.py` gains a
   `--pytest-timeout` flag (default 240s; raise to 1800+ for slow
   CI / external regression machines). Fast vs full closure-gate
   split deferred to v4.91 (B-CG backlog item).

Test count: 915 → 920 passed (+2 cli metadata extension; +2
clean_transients fixture-based; +1 closure gate timeout flag).

`LAYER_1_ROOTS` unchanged at 33. No manifest schema change; only
`manifest_schema_notes` appended.

### v4.90 Batch 14.11 — Doc polish (v4.90.4 patch)

Pure doc-polish patch; zero source / schema / test changes beyond
manifest+CHECKSUMS regen. Closes four post-v4.90.3 doc residues:

1. `docs/18_cli/CLI_USAGE_GUIDE.md` was missed by the v4.90.3 c3
   STUB sweep (which only touched README.md). Header `Status: Step
   11.1 skeleton. Sections 4-7 are placeholders` → `Status: GUIDED
   wrapper / 22 leaves wired / 0 STUB`. Each of §4 migration / §5
   ltm / §6 pack / §7 evolve had its `Status: placeholder until Step
   11.x` line replaced with `Status: GUIDED — N leaves wired (Batch
   11.x closure ...)` citing the actual closure batch.
2. `RELEASE_NOTES.md` §4 heading `Verification baseline (v4.90.1
   final)` → `Verification baseline (v4.90.3 final)`. Body had
   already been advanced to 920 passed in v4.90.3 c2.
3. `2026-05-1X` placeholder dates and `（待打）` (tag-pending)
   labels swept across `USER_GUIDE.md` / `CHANGELOG.md` /
   `V4_90_README.md` to `2026-05-16` + `（annotated，已打）`. Both
   v4.90.2-release and v4.90.3-release tags have been annotated and
   pushed; documents now match repo state. USER_GUIDE.md v4.90.2
   test-count `906 → 911` corrected to `906 → 915` to match the
   v4.90.2 baseline.
4. `README.md` §Verification gains a quote-block flagging
   `--pytest-timeout 1800` for slow CI / external regression
   machines (the closure gate flag was added in v4.90.3 c5 but
   never advertised in onboarding docs).

Test count: **920 → 920** (no test change; pure doc).
`LAYER_1_ROOTS` unchanged at 33. Manifest schema 2.2 unchanged.

### v4.90 Batch 14.12 — Doc precision (v4.90.5 patch)

Pure doc-precision patch; zero source / schema / test changes beyond
manifest+CHECKSUMS regen. Closes three doc-precision residues found
in external review of v4.90.4:

1. `docs/18_cli/README.md` + `CLI_USAGE_GUIDE.md` carried two wrong
   wrap-script names. The CLI dispatcher imports the right modules,
   but the doc annotations pointed at non-existent files:
   - `pack agent-library list` annotation
     `scripts/agent_library/list_agent_packs.py` →
     `scripts/agent_library/list_packs.py` (the actual filename).
   - `evolve propose` annotation
     `scripts/self_evolution/propose_evolution.py` →
     `scripts/self_evolution/propose_skeleton.py` (the actual
     filename). Copy-paste readers were hitting FileNotFoundError.
2. `docs/18_cli/CLI_USAGE_GUIDE.md` §4 / §5 / §6 / §7 each retained a
   `Planned leaf shape` block plus `Detailed flag reference will land
   in Step 11.x` — both v4.90.0 freeze residues. By v4.90.5 every
   namespace is fully wired (Batch 11.2 / 11.3 + 13.1 + 13.4.b /
   11.4 + 13 / 11.5 + 13). Blocks renamed `Current leaf shape` and
   updated to show: migration's 4 alias leaves (handshake / plan /
   verify / report); pack agent-library's list + activate; evolve's
   propose `<slug>` + `--summary` + `--year`.
3. `RELEASE_NOTES.md` carried four factual errors that survived
   v4.90.4: (a) frontmatter still labelled `v4.90.3 patched state`;
   (b) §1 + §2.6 listed a fictitious `governance` CLI namespace
   (governance scripts are invoked directly, not via `ai-dev-os`);
   (c) §2.1 described `scripts/migration/` as `mix of GUIDED + STUB`
   even though all 7 entry points are GUIDED; (d) §2.1 listed
   `scan_legacy_project.py` under `scripts/adoption/`, but that file
   has always lived under `scripts/migration/`. All four corrected;
   §Patch History gained a v4.90.4 sub-section (was missing because
   v4.90.4 didn't touch RELEASE_NOTES.md) plus a new v4.90.5 entry.

Test count: **920 → 920** (no test change; pure doc precision).
`LAYER_1_ROOTS` unchanged at 33. Manifest schema 2.2 unchanged.

### v4.90 Batch 14.13 — Active-state label sweep (v4.90.6 patch)

Micro doc patch; 0 source / schema / test change beyond
manifest+CHECKSUMS regen. Closes two label-drift residues found in a
sandbox completeness audit after v4.90.5:

1. README.md L69 + USER_GUIDE.md L21 carried `(post v4.90.3)` even
   though v4.90.4 / v4.90.5 / V4_90_README / CHANGELOG / closure
   gate had all advanced. Lifted to `(post v4.90.5)` — the qualifier
   identifies which patch last established the 920-test baseline,
   not the latest patch in the chain. (v4.90.4 / v4.90.5 / v4.90.6
   are all pure-doc patches that did not touch the test suite.)
2. V4_90_README.md plan-files reference line ended at v4.90.4 inline
   plan; appended v4.90.5 (3 commits) + v4.90.6 (2 commits) inline
   plan citations.

Test count: **920 → 920** (no test change; pure label sweep).
`LAYER_1_ROOTS` unchanged at 33. Manifest schema 2.2 unchanged.

### v4.90 Batch 14.14 — Aggregate stability + §4 sync (v4.90.7 patch)

External-reproducibility hardening patch. Closes a real C8
regression (consistency aggregate could deadlock under workspace-
wide pytest plugins) plus a v4.90.5/6-era P2 doc polish that the
v4.90.5/6 micro-patches missed.

Source/test changes:

1. `scripts/governance/check_consistency_aggregate.py` reordered:
   `schema_self_validation` now sits at index 4 (before
   `required_regressions` at index 5). External sandbox replays
   showed the previous order could deadlock when workspace-wide
   pytest plugins (coverage trackers, distributed runners,
   third-party hooks) auto-loaded into the schema-self-validation
   sub-suite while the regressions router held its own
   plugin-load cache.
2. `check_consistency_aggregate.py` gains a `--timeout SECS`
   flag (default 180; raise to 600+ on slow CI) so closure-gate
   consumers can lift the per-check budget without source-patches.
3. `check_consistency_aggregate.py` introduces an
   `ISOLATED_PYTEST_NAMES` marker set; for any sub-check whose
   name appears in the set, the new `_build_env()` helper injects
   `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1` so external pytest plugins
   cannot hook the subprocess. Only the schema-self-validation
   sub-check is currently isolated; the other 5 inherit the parent
   environment unchanged.
4. `scripts/governance/run_v490_rc3_closure_gate.py` C8 invocation
   now passes `--timeout AGGREGATE_TIMEOUT` (module-level default
   600). New top-level `--aggregate-timeout SECS` CLI flag
   independent of `--pytest-timeout`. C8 row label now exposes the
   per-check budget; aggregate-failure rows now name the failing
   sub-check.

Doc changes:

5. RELEASE_NOTES.md §4 heading `Verification baseline (v4.90.5
   final)` → `(v4.90.7 final)`. Body number `920 passed (post
   v4.90.5)` → `923 passed (post v4.90.7)`. New quote-block at the
   end of §4 documents the slow-CI invocation pattern
   (`--pytest-timeout 1800 --aggregate-timeout 1800`).
6. README.md L69 + USER_GUIDE.md L21 number 920 → 923; qualifier
   `(post v4.90.5)` → `(post v4.90.7)`.

Test count: **920 → 923** (+3 in
`tests/governance/test_consistency_aggregate_stability.py`):
`test_check_order_schema_before_regressions`,
`test_aggregate_advertises_timeout_flag`, and
`test_isolated_pytest_names_includes_schema_self_validation`. The
existing
`tests/contracts/test_consistency_aggregate.py::test_json_format_returns_six_results`
was reordered to assert the new sequence (no count change for that
file).

`LAYER_1_ROOTS` unchanged at 33. Manifest schema 2.2 unchanged;
`manifest_schema_notes` appended Batch 14.14 entry.

### v4.90 Batch 14.15 — Closure gate hardening (v4.90.8 patch)

**Date**: 2026-05-17
**Trigger**: external sandbox replay of v4.90.7 final state
revealed that the closure gate's full pytest run could appear to
succeed at the pytest level (e.g. an adoption-harness suite prints
`5 passed in 28.17s`) while the parent process never reached its
exit summary because a grandchild kept stdout/stderr pipes open.
The pre-v4.90.8 `_run()` used `subprocess.run(..., timeout=...)`,
which only signals the direct child; on `TimeoutExpired`,
`communicate()` could deadlock on the grandchild's pipe. C8 was
already hardened (v4.90.7); this batch applies the equivalent
hardening to C1 / `_run()` itself so external machines can reproduce
13/13 PASS without orchestrator-level kill.

**Changes (5 atomic commits)**:

1. `scripts/governance/run_v490_rc3_closure_gate.py` `_run()` rewritten:
   `subprocess.Popen(..., start_new_session=True)` so the child
   becomes a process-group leader; on `TimeoutExpired`,
   `os.killpg(SIGTERM)` with a 10s grace, escalating to `SIGKILL`
   + 5s drain if the group is still alive. Same `(rc, stdout, stderr)`
   contract; 124 on timeout, 126 on `OSError`, otherwise the child's
   exit code. New `extra_env` parameter merges into `os.environ` for
   selective env injection.
2. New optional flag `--pytest-disable-plugin-autoload` on
   `run_v490_rc3_closure_gate.py` (C1 only). Sets
   `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1` in the C1 full pytest env via
   `_run`'s `extra_env` — the same isolation primitive C8's aggregate
   runner uses for `schema_self_validation` (v4.90.7). Default OFF.
3. `EXPECTED_PYTEST` 923 → 926; C1 row label `pytest 923/2 skipped`
   → `pytest 926/2 skipped` to absorb the +3 governance tests added
   in this batch.
4. New test file
   `tests/governance/test_closure_gate_timeout_hardening.py` (3
   tests):
   `test_run_kills_grandchild_process_group_on_timeout` (rc=124
   within 25s + grandchild PID reaped),
   `test_run_forwards_extra_env_to_child` (extra_env round-trip),
   `test_help_advertises_plugin_autoload_flag` (--help marker check).
5. Doc sync: README.md §Verification slow-CI quote-block heading
   `(v4.90.3+)` → `(v4.90.8+)`; invocation upgraded to
   `--pytest-timeout 1800 --aggregate-timeout 1800` plus a follow-on
   note for `--pytest-disable-plugin-autoload` and a one-line summary
   of the Popen + killpg hardening. README L69 expect line 923 → 926.
   USER_GUIDE.md baseline summary 923 → 926. RELEASE_NOTES.md §4
   heading `(v4.90.7 final)` → `(v4.90.8 final)`; §4 body 923 → 926;
   §4 slow-CI quote-block extended with
   `--pytest-disable-plugin-autoload`. RELEASE_NOTES.md frontmatter
   v4.90.7 → v4.90.8; §Patch History v4.90.8 entry added. CHANGELOG
   v4.90.8 entry added. V4_90_README.md §v4.90.8 mini summary added.

Test count: **923 → 926** (+3 in
`tests/governance/test_closure_gate_timeout_hardening.py`).

`LAYER_1_ROOTS` unchanged at 33. Manifest schema 2.2 unchanged;
`manifest_schema_notes` appended Batch 14.15 entry.

---

### v4.90 Batch 14.16 — Fast/full closure gate split + PG-safe runner extraction + game-dev phase split (v4.90.9 patch)

**Date**: 2026-05-17
**Trigger**: post-v4.90.8 EP review identified four remaining gaps:
(1) `check_required_regressions.execute()` and
`check_consistency_aggregate._run()` were still using plain
`subprocess.run(..., timeout=...)` — the v4.90.8 closure-gate
hardening had to be portable across all governance subprocess
sites; (2) the closure gate was still a single full-pytest gate,
giving external reviewers no fast circuit to separate "non-pytest
health" from "pytest baseline drift"; (3) the closure-gate filename
(`run_v490_rc3_closure_gate.py`) was confusing for external readers
unaware of the v4.90.1..v4.90.8 patch chain; (4) `pack adoption
init --stage` accepted only the 7-value lifecycle enum
(incubation/alpha/beta/release_candidate/production/maintenance/sunset)
but game-dev users naturally reach for `mvp / vertical_slice /
production` — the two vocabularies needed to be both supported and
architecturally separated.

**Changes (4 atomic commits)**:

1. **PG-safe runner extraction.** New module
   `scripts/governance/_process_runner.py` exposes
   `run_pg_safe(cmd, *, cwd, timeout, extra_env=None, shell=False)
   -> (rc, stdout, stderr)`. Body is the v4.90.8 `_run()` body
   verbatim — `Popen(start_new_session=True)` + `os.killpg(SIGTERM)`
   10s grace + `SIGKILL` 5s drain on `TimeoutExpired`; rc=124 on
   timeout / 126 on `OSError` / otherwise child exit. Three callers
   migrate: `run_v490_rc3_closure_gate._run()` (one-line adapter,
   full backward compatibility), `check_required_regressions.execute()`
   (preserves the protected_invariant shell-string contract via
   `shell=True`), `check_consistency_aggregate._run()` (each of the
   6 sub-checks now PG-safe).

2. **Fast/full dispatcher.** New script
   `scripts/governance/run_release_closure_gate.py` (recommended
   v4.90.9+ entry). `--profile fast` runs 7 minimal checks
   (collect-only floor / clean-tree post-clean / v4.89 audit /
   Layer 1 / aggregate / protected regressions / curated targeted-
   pytest subset) ≈ 6.5s on laptop; `--profile full` (default)
   imports and forwards every passthrough flag to the existing RC3
   13-check gate so the contract is unchanged. Both profiles print
   a banner showing the `v4.90.1..v4.90.9` patch chain and the RC3
   contract file path. F2 clean-tree is ordered last and pre-cleans
   transients itself so prior pytest steps cannot create false-positive
   drift. F7's targeted subset is curated to omit
   `test_closure_gate_*` / `test_release_closure_gate_dispatcher` /
   `test_consistency_aggregate_*` to avoid recursion when the
   dispatcher's e2e test invokes the dispatcher.

3. **Project profile schema 1.0.0 → 1.1.0 + game_dev_phase split.**
   `schemas/adoption/project_profile.schema.json` introduces a new
   required field `game_dev_phase` enum-bound to
   `prototype / mvp / vertical_slice / alpha_build / beta_build /
   production / post_launch`. The package ships zero pre-existing
   `02_project_profile.yaml` instances, so the required-field bump
   needs no on-disk backfill.
   `scripts/adoption/init_project_runtime.py` adds `--game-dev-phase`
   (optional) plus a `DEFAULT_PHASE_FOR_STAGE` derivation table
   (incubation→prototype, alpha→alpha_build, beta→mvp,
   release_candidate→vertical_slice, production→production,
   maintenance/sunset→post_launch) so every pre-v4.90.9 call site
   keeps working transparently. Template
   `templates/project_runtime/02_project_profile.yaml.tmpl` and
   harness `scripts/adoption/run_mock_harness.py
   --emit-game-dev-phase` wired through.
   `tests/test_schema_promote_wave_2_final.py` updates project_profile
   from 1.0.0 to 1.1.0; `tests/adoption/test_project_profile_schema.py`
   gains 3 sentinel cases (game_dev_phase required / enum-bound /
   schema_version const="1.1.0").

4. **Doc + EXPECTED_PYTEST sync.** `EXPECTED_PYTEST` 926 → **946**;
   C1 row label `pytest 926/2 skipped` → `pytest 946/2 skipped`.
   README.md §Verification gains a `--profile fast` one-liner with
   a sub-quote explaining the dispatcher relationship to the RC3
   contract; §Verification slow-CI block extended to mention the
   v4.90.9 PG-safe extraction. USER_GUIDE.md baseline summary 926
   → 946; (post v4.90.8) → (post v4.90.9). V4_90_README.md gains a
   v4.90.9 patch summary and updates the v4.91 backlog (B-CG removed;
   B-DUAL-PHASE-DOC added). RELEASE_NOTES.md §4 heading
   `(v4.90.8 final)` → `(v4.90.9 final)`; §Patch History v4.90.9
   entry added. RELEASE_NOTES_v4.90-rc3.md gains §8 Patch History
   table covering the entire v4.90.1..v4.90.9 chain. CHANGELOG
   v4.90.9 entry added. docs/13_migration/PROJECT_INIT_GUIDE.md
   documents `--game-dev-phase` and the auto-derivation rule.
   `RELEASE_MANIFEST.json` rebuilt: required_manifest_files 896 →
   **903** (+5 new files plus modified-file checksum drift).

Test count: **926 → 946** (+20):
- `tests/governance/test_process_runner.py` (+4)
- `tests/governance/test_release_closure_gate_dispatcher.py` (+5)
- `tests/adoption/test_init_stage_aliases.py` (+8; 3 parametrised)
- `tests/adoption/test_project_profile_schema.py` (+3 new sentinels
  on the existing test file)

`LAYER_1_ROOTS` unchanged at 33. Manifest schema 2.2 unchanged;
`manifest_schema_notes` not extended (no new top-level fields, file
tiers, or const values were added — the schema_version bump for
project_profile is captured by the existing schema-promote tests
rather than as a manifest schema note).

---

### v4.90 Batch 14.17 — Optional polish: gate timing language + dual-gate semantics + v4.90.9 evidence record (v4.90.10 patch)

**Date**: 2026-05-17
**Trigger**: post-v4.90.9 review identified four polish-level gaps:
(1) hard `≤ 10s on laptop` / `≤ 180s on slow CI` claims read as
guarantees rather than benchmark targets — external reviewers
running 12s on a battery-saving laptop would (incorrectly) interpret
it as a fail; (2) README / RELEASE_NOTES did not state explicitly
when to use fast vs. full or whether fast could replace full at
release time; (3) v4.90.9 final state was claimed in numbers but
no maintainer-laptop evidence record (timestamp + duration) was
preserved; (4) the dispatcher's own module docstring + `--help`
text used the same hard timing language, contradicting the docs.

**Changes (5 atomic commits, pure documentation + comment polish)**:

1. `scripts/governance/run_release_closure_gate.py` source polish.
   Module docstring rewritten to describe two gates explicitly
   (fast = reviewer smoke gate; full = final release evidence
   gate; "fast is NOT a substitute for full at release time").
   `--profile` help text and ArgumentParser description rewritten
   to match. Timing language switched to "benchmark target" +
   "typical range" with explicit no-hard-upper-bound note.

2. `tests/governance/test_release_closure_gate_dispatcher.py`
   docstring update: 180s timeout documented as a CI safeguard,
   not a benchmark; user-facing benchmark restated. No assertion
   change.

3. `README.md` §Verification softening: command comments adopt
   "benchmark target under 10s on a 2024-class laptop"; new
   full quote-block explains the two-gate model with reviewer-
   smoke / final-release-evidence labels and a "NOT a substitute"
   guidance line. The v4.90.10 measured numbers (6.2-6.5s fast
   / ~32s full skip-deliv / ~60-90s full + deliv) appear inline.

4. `RELEASE_NOTES.md` §4 Verification baseline + frontmatter +
   §Patch History v4.90.10 entry. Frontmatter "v4.90.9 patched
   state" -> "v4.90.10 patched state". §4 commands synced to
   soft language; new "Two layered gates" prose. §Patch History
   v4.90.10 entry includes the maintainer evidence record.

5. `V4_90_README.md` v4.90.10 patch summary section + plan-files
   ref appended; `RELEASE_NOTES_v4.90-rc3.md` §8 patch table
   v4.90.10 row appended; `CHANGELOG.md` v4.90.10 entry;
   `docs/MANIFEST_HISTORY.md` Batch 14.17 (this section);
   `USER_GUIDE.md` baseline summary line gains dual-gate semantic
   labels. RELEASE_MANIFEST.json + CHECKSUMS.sha regenerated
   (required_manifest_files unchanged at 903; only hash drift
   from doc/comment edits).

**Maintainer laptop evidence record (2026-05-17 17:05+)**:
- `pytest tests/`: 946 passed / 2 skipped in 29.46s
- `--profile full --skip-deliverables`: 8/8 PASS in 31.74s
- `--profile fast` 3-run sample: 6.22 / 6.50 / 6.32s (avg 6.35s)

Test count: **946 unchanged** (no new tests, no removed tests).

`LAYER_1_ROOTS` unchanged at 33. Manifest schema 2.2 unchanged;
`manifest_schema_notes` not extended. `required_manifest_files`
unchanged at 903.

---

### v4.90 Batch 14.18 — Fast gate F5/F7 pipe-deadlock hardening + 13/13 evidence + doc alignment (v4.90.11 patch)

**Date**: 2026-05-17
**Trigger**: post-v4.90.10 EP review observed a fast-gate hang on
``--profile fast --aggregate-timeout 1800
--pytest-disable-plugin-autoload`` in a sandbox environment.
Standalone runs of ``check_consistency_aggregate.py`` were 6/6
PASS; nested through the dispatcher hung indefinitely. Diagnosis:
``_process_runner.run_pg_safe`` captures via ``subprocess.PIPE``,
whose OS buffer (~64 KB on Linux/macOS) overflows when the 6
aggregate sub-checks emit cumulatively more output than the buffer
can hold; the writing grandchild blocks on ``write()`` while the
parent blocks on ``communicate()`` waiting for EOF — classic pipe
deadlock that ``os.killpg`` cannot resolve (no timeout fires; the
parent is reading, not waiting). EP also flagged two P2 doc gaps:
(A) RELEASE_NOTES §4 still titled ``(v4.90.9 final)`` despite
frontmatter declaring ``v4.90.10 patched state``; (B) the v4.90.10
evidence record covered ``--skip-deliverables`` (8/8) but not the
full release ceremony (13/13).

**Changes (5 atomic commits)**:

1. New helper ``scripts/governance/_process_runner.run_pg_safe_to_file``
   — drop-in replacement for ``run_pg_safe`` whose output goes to
   two files instead of two pipes. File writes are not pipe-
   buffered, so the back-pressure path simply does not exist.
   Preserves the v4.90.8 PG-safe contract verbatim:
   ``Popen(start_new_session=True)`` + ``os.killpg(SIGTERM)`` 10s
   grace + escalate ``SIGKILL`` 5s drain on ``TimeoutExpired``;
   rc=124 on timeout / 126 on OSError / otherwise child exit. New
   tests in ``tests/governance/test_process_runner_to_file.py``
   (+5).

2. ``scripts/governance/run_release_closure_gate.py`` F5
   (consistency aggregate) and F7 (curated targeted-pytest subset)
   migrated from ``run_pg_safe`` to ``run_pg_safe_to_file``. F1
   (collect-only floor) intentionally stays on ``run_pg_safe``
   because its output is bounded. New CLI flag
   ``--fast-aggregate-wall-timeout SECS`` (default 300, fast-
   profile-only) decouples F5 wall-clock cap from
   ``--aggregate-timeout`` (per-sub-check). v4.90.10's
   ``aggregate_timeout * 6 + 60`` formula made fast-gate wall-time
   unpredictable when reviewers raised ``--aggregate-timeout``
   (e.g. 1800 → ~3 hour ceiling that masked real hangs). New
   tests in ``test_release_closure_gate_dispatcher.py`` (+2).

3. Doc sync to all 7 release-level documents (README + USER_GUIDE
   + V4_90_README + RELEASE_NOTES + RELEASE_NOTES_v4.90-rc3 +
   CHANGELOG + this MANIFEST_HISTORY). Resolves EP's two P2 doc
   gaps: §4 title alignment + 8/8 vs 13/13 evidence-band quote-
   block.

4. ``scripts/governance/run_v490_rc3_closure_gate.py``
   ``EXPECTED_PYTEST`` 946 → **953**; C1 row label
   ``pytest 946/2 skipped`` → ``pytest 953/2 skipped``. Required
   to make C1 pass at the new baseline.

5. ``RELEASE_MANIFEST.json`` rebuilt: ``required_manifest_files``
   903 → **904** (+1 new file ``test_process_runner_to_file.py``;
   modified files contribute hash drift only). ``CHECKSUMS.sha``
   regenerated (0 FAILED). Memory log appended. ``MEMORY.md §5``
   NEW item 14 (permanent project convention): pipe-deadlock
   prevention — any nested governance subprocess that fan-outs
   children must use ``run_pg_safe_to_file``, not ``run_pg_safe``.
   Diagnostic signature: standalone run PASSes, nested run hangs.

**Maintainer laptop evidence record (2026-05-17 19:50+)**:
- ``pytest tests/``: 953 passed / 2 skipped in 33.67s
- ``--profile fast``: 7/7 PASS in ~8.5s
- ``--profile fast --aggregate-timeout 1800
  --pytest-disable-plugin-autoload`` (the v4.90.10 reproducer that
  was hanging): **7/7 PASS in ~8.4s** ✓ (fix verified)
- ``--profile full --pytest-timeout 1800 --aggregate-timeout 1800
  --pytest-disable-plugin-autoload`` (full release ceremony with
  deliverables): **13/13 PASS in ~36s**

Test count: **946 → 953** (+7: 5 to_file + 2 dispatcher new flag).

``LAYER_1_ROOTS`` unchanged at 33. Manifest schema 2.2 unchanged;
``manifest_schema_notes`` not extended (no new top-level fields,
file tiers, or const values were added). ``required_manifest_files``
**903 → 904** (+1 new file plus hash-drift from modified files).

---

### v4.91 F-T-01 — Tenancy Boundary Schema (manifest schema 2.2 → 2.3)

The first v4.91 manifest-shape change: classification_rules gains a
fifth key (`tenant_runtime`) and a top-level `tenant_runtime_entries`
array is introduced. Adopting projects must claim a concrete
instantiation of each declared path template (containing the literal
token `<project_id>`) in their `.ai_dev_os/project_runtime_protocol.yaml::runtime_namespace`
block. `verify_release_clean_tree.py` enforces the bidirectional
contract: a tenant_runtime path is "extra" unless both the manifest
declares the template AND the adopting project claims it.

Layer 1 invariant preserved: the manifest contains zero specific
project ids; project ids are runtime values supplied by the
adopting project at audit time. `schemas/tenancy/tenancy_boundary.schema.json`
carries the formal contract; `schemas/protocol/project_runtime_protocol.schema.json`
gains the optional runtime_namespace block (schema_version
unchanged at 1.0.0 per inv_007 lock + extend-don't-replace
charter).

### v4.91 F-V-01 — Tenancy-aware verifier + lint

No manifest schema-shape change. `lint_layer_separation.py` gains a
runtime-tree pass; `verify_release_clean_tree.py` enforces the F-T-01
bidirectional tenancy contract. F-T-01 path templates only get
accepted as `tenant_runtime` when an adopting project claims them
concretely; otherwise they surface as `extra`.

### v4.91 B0–B3 — Milestone A foundation (closure → tag v4.91-M-A)

| Sub-batch | Surface added | Schema impact |
|---|---|---|
| B0 | gate_report 5-state status (PASS/FAIL/SKIP/TIMEOUT/ERROR); RELEASE_NOTES + 14-pattern Charter doc updates | none |
| B1 | 8 hub CLIs + flock+2PC + 5 hub schemas (global_os_config + projects_index + mounts + locks + audit_log) + F9 hub-smoke | none — hub schemas are 1.0.0 const |
| B2 | 2 mount schemas + validate_project_mount two-tier acceptance + docs/20_project_mount/MOUNT_CONTRACT.md + 26 mount tests | none — project_mount.schema.json 1.0.0 |
| B3 | 4 version schemas + 3 hub CLIs (lock_core_version + check_core_update_impact + generate_upgrade_plan) + Core abstract identity surface (top-level MANIFEST.json + CHECKSUMS.txt as Core-only checksum companion, separate from RELEASE_MANIFEST.json) + policies/core_update_policy.md + F10 version-lock-smoke | none — version schemas 1.0.0 |

`exclusions.transient_patterns` extended +5 (B1 hub artefacts:
`hub/.hub.lock` + `hub/{logs,reports,update_plans}/` + `hub/versions.lock`).
M-A clean baseline closes with tag `v4.91-M-A`.

### v4.91 Addendum-A — External Core Mount by Default Rule

Schema bump: `project_mount.schema.json` 1.0.0 → **1.1.0** widening
mount_mode enum from `["link"]` to 4 values (`link` deprecated alias
of `external_core` for one minor cycle). `host_profile.schema.json`
1.0.0 → 1.1.0. F11 detect-bundle-smoke fast-gate item added; 4 host
profile YAMLs (workbuddy / codex / cursor / claude_code);
`policies/charter_anti_patterns.md` formalises 14-pattern SSoT
(Charter anti-pattern #14 *No Full Release Copy by Default*). Tag
`v4.91-Addendum-A`.

### v4.91 B4–B6 — Milestone B (Shared LTM v3 + capture pipeline; tag v4.91-M-B)

| Sub-batch | Surface added | Schema impact |
|---|---|---|
| B4 | 4 v3 schemas (retrieval_policy + routing_report + preflight_case + preflight_metric) + 2 read-only CLIs + ltm/retrieval_policy.yaml + docs/22_ltm_v3 + F12 ltm-v3-smoke | none — v3 schemas 1.0.0 const |
| B5 | 4 ledger/policy schemas (promotion_policy + promotion_ledger + reject_ledger + supersede_ledger) + promote_memory_candidate v3 extension + reject_memory_candidate + supersede_memory_candidate + ltm/promotion_policy.yaml + PROMOTION_LIFECYCLE.md + F13 ltm-lifecycle-smoke | none — ledger schemas 1.0.0 const |
| B5B | 2 schemas (preflight_policy + preflight_consensus_event_ledger) + run_preflight_consensus.py + lock_core_version preflight gate (EXIT_PREFLIGHT_NOT_APPROVED=5) + F14 preflight-consensus-smoke | none — preflight schemas 1.0.0 const |
| B6 | memory_candidate +OPTIONAL `capture_source` 5-enum (schema_version 1.0.0 const per Charter anti-pattern #4 extend-don't-replace) + capture_evolution_proposal NEW (dual-rail mutex) + capture_sprint_close auto-emit on gate=blocked + extract_failure_candidates --source 2-enum + EVOLUTION_CAPTURE.md + F15 capture-pipeline-smoke | none — extension only |

Milestone B integral close with tag `v4.91-M-B`. `exclusions.transient_patterns`
unchanged.

### v4.91 Addendum-B — Link Alias Removal

Schema enum narrowed across **6 schemas** from 4 values
`[link, external_core, thin_scaffold, vendor_snapshot]` to 3
forward-only values `[external_core, thin_scaffold, vendor_snapshot]`.
Touched schemas: `project_mount.schema.json` (× 2 enum sites) +
`version_lock.schema.json` + `host_profile.schema.json` (description-
only) + 3 hub schemas (`global_os_config` + `projects_index` +
`mounts`). `init_hub` default + `link_project` default +
`validate_project_mount` VPM-002 valid_modes +
`detect_embedded_release_bundle` VALID_MODES all drop `link`.
`hub/global_os_config.yaml` `mount_default` migrated to
`external_core`. F16 link-removal-smoke fast-gate item added (fast
18 → 19 components). `schema_version` stays 1.1.0 (Addendum-A
widening + Addendum-B narrowing = full minor cycle). Charter anti-
pattern #15 *No mount_mode aliases* formalised. Tag
`v4.91-Addendum-B`.

### v4.91 Addendum-C — Subagent Routing Gate

No manifest schema-shape change. Adds Layer 1 OS Core skill
`skills/_generic_core/orchestrator/subagent-routing-gate/` (SKILL.md
+ REFERENCES.md) + `schemas/governance/delegation_decision.schema.json`
(1.0.0 const) + `scripts/governance/validate_delegation_decisions.py`
+ `runtime/registries/delegation_decision_ledger.jsonl` (canonical
empty mirror). `runtime/protected_contracts/protected_regression_matrix.yaml`
gains `inv_008_delegation_gate_recorded` (invariants 7 → 8);
`agent_packs/ap_2026_001_executive_cluster.md` requires the new
skill. F17 delegation-decisions-smoke fast-gate item added (fast 19
→ 20 components). 11 governance tests pin envelope shape + LOCAL
5-enum + cross-line uniqueness + amends referential integrity.
3 docs in `docs/23_subagent_routing_gate/`. Charter anti-pattern
#11 reaffirmed (a recorded decision is NOT a closure-gate pass —
validator enforces decision-record SHAPE only). Tag
`v4.91-Addendum-C`.

### v4.91 P2 — Rebuilder tooling refactor (this batch)

No manifest schema-shape change. Rewrites
`scripts/rebuild_release_manifest.py` to PRESERVE metadata fields
(`manifest_schema_version` + `manifest_schema_notes` + `byte_lock` +
`exclusions` + `classification_rules.tenant_runtime` +
`tenant_runtime_entries`) from the on-disk manifest instead of
hardcoding them in source. New `--check` / `--out` / `--root`
flags; JSON serialisation switched to `ensure_ascii=False` for
lossless UTF-8 round-trip. 9 new tests in
`tests/test_rebuild_release_manifest.py` pin the preservation
contract + drift detection (`--check` exit 1) + transient refusal
(exit 2) + idempotency.

Side effect: 7 `.gitkeep` files mis-classified into
`required_manifest_files` by earlier surgical edits move to
`optional_seed_files` where the `OPTIONAL_SEED_SUFFIXES` rule
always intended them. Net counts: required 1024 → 1018 (with the
new test file), optional_seed 24 → 31; total tracked count
unchanged. After P2, the canonical sync path is `python3
scripts/rebuild_release_manifest.py` followed by `--check` —
future batch close no longer needs the surgical-edit pattern.

This MANIFEST_HISTORY.md catch-up adds sections for v4.90.9 / 10 /
11 (already had Batch 14.16/17/18 sections), F-T-01 (re-grouped
under v4.91), F-V-01, B0–B3, Addendum-A, B4–B6, Addendum-B,
Addendum-C, and P2 itself. Total `manifest_schema_notes` array
size: 13 → **29** (+16 entries: 14.16/17/18 + 13 v4.91 entries
including this one).

---

## 3. LAYER_1_ROOTS evolution

Each schema-promote wave usually arrives alongside a Layer 1 root
extension because the new schemas live under a new directory.

| Stage | Roots | Delta | Trigger |
|---|---:|---|---|
| Pre-Batch-3 | 24 | baseline | Initial governance + migration + ltm + protocol stubs |
| Post-Batch-5 (P1-1) | 26 | +2 | `schemas/agent_library`, `tests/agent_library` |
| Post-Batch-10.2 | 28 | +2 | `evolution/candidates`, `evolution/sandbox` |
| Post-Batch-11.1 | 31 | +3 | `docs/18_cli`, `scripts/cli`, `tests/cli` |
| Post-Batch-14.8 (RC3) | 33 | +2 | `schemas/contracts`, `tests/contracts` |
| Post v4.91 B1 | 36 | +3 | `schemas/hub`, `scripts/hub`, `tests/hub` |
| Post v4.91 B2 | 38 | +2 | `schemas/mount`, `tests/mount` |
| Post v4.91 B3 | 40 | +2 | `schemas/version`, `tests/version` |
| Post v4.91 F-T-01 | 41 | +1 | `schemas/tenancy` (`docs/19_tenancy` is a doc dir, not a code root) |
| Post v4.91 B4 | 43 | +2 | `docs/22_ltm_v3`, `ltm/cross_project` (under existing roots; lint root tally re-counts) |
| Post v4.91 Addendum-A | **47** | +4 | `docs/20_project_mount`, `docs/21_host_profiles`, `policies` (incl. charter_anti_patterns), `profiles` |
| Post v4.91 Addendum-C | 47 | unchanged | `docs/23_subagent_routing_gate/` matched the existing `docs/**` glob root rather than introducing a new lint root |
| Post v4.91 M-E B8 / B9 | 55 | +8 | `docs/22_ltm_v3` extension, `docs/24_memory_sync`, `schemas/memory`, `scripts/memory`, `tests/memory`, `scripts/panel`, `tests/panel`, `docs/25_panel_export`, `docs/26_dual_phase` (P7 doc-only) |
| Post v4.91 M-F Batch 6 | **59** | +4 | `docs/27_intent_governance`, `schemas/intent`, `scripts/intent`, `tests/intent` |
| Post v4.91 M-G Batch 7 | **63** | +4 | `docs/28_2d_character_animation`, `schemas/animation`, `scripts/animation`, `tests/animation` (creative_cluster pack ap_2026_006 — first cross-project promotion via evo_2026_002 capability_promotion) |
| **Post v4.91 M-H Batch 8** | **67** | **+4** | `docs/29_game_ui_ux`, `schemas/uiux`, `scripts/uiux`, `tests/uiux` (creative_cluster pack ap_2026_006 game UI/UX sub-domain — second cross-project promotion via evo_2026_003 capability_promotion; same single pack accumulates sub-domains via M-H c0 widened exemption registry) |

`scripts/governance/lint_layer_separation.py::LAYER_1_ROOTS` is
the single source of truth for this list.

---

## 4. Cross-references

- **Authoritative array**:
  `RELEASE_MANIFEST.json::manifest_schema_notes`
  — 29 entries as of v4.91 P2, ordered chronologically (v2.0/v2.1
  history → v4.90 Batch 12.1a → 12.1b → 14.3 → 14.8 → 14.9 → 14.10
  → 14.11 → 14.12 → 14.13 → 14.14 → 14.15 → 14.16 → 14.17 → 14.18 →
  v4.91 F-T-01 → F-V-01 → B0 → B1 → B2 → B3 → Addendum-A → B4 → B5
  → B5B → B6 → Addendum-B → Addendum-C → P2).
- **Linter**:
  `scripts/governance/lint_layer_separation.py::LAYER_1_ROOTS`
- **Generator** (v4.91 P2 onwards):
  `scripts/rebuild_release_manifest.py` PRESERVES the array from
  the on-disk manifest. Source code no longer hardcodes the array
  payload; appending an entry is a deliberate hand-edit to
  `RELEASE_MANIFEST.json` (see §5 below).
- **Consistency test**:
  `tests/test_manifest_schema_notes_consistency.py`
- **Preservation test**:
  `tests/test_rebuild_release_manifest.py` (v4.91 P2)

---

## 5. How to append a new entry

When a future batch adds a new top-level field, file tier, const
value, or any other manifest-shape change to RELEASE_MANIFEST.json:

1. Hand-edit `RELEASE_MANIFEST.json::manifest_schema_notes` and
   append a one-line blurb citing the batch ID. (As of v4.91 P2 the
   rebuilder no longer carries the array payload in source; the
   manifest is the single source of truth.)
2. Run `python3 scripts/rebuild_release_manifest.py --check` to
   verify the rest of the manifest is in sync (file inventories +
   sha256s). Run without `--check` to refresh the file inventories
   if needed.
3. Append a `### v4.NN <batch tag> — short title` section to §2
   above with rationale, affected paths, and forward-compatibility
   notes. Use a `Batch X.Y` token if you want the keyword
   consistency test to enforce the cross-reference; otherwise the
   v4.91-style `<batch tag>` form (e.g. `Addendum-D`, `F-T-NN`) is
   accepted by the test as informational-only.
4. If `LAYER_1_ROOTS` changed, append a row to §3.
5. Run `python3 -m pytest tests/test_manifest_schema_notes_consistency.py
   tests/test_rebuild_release_manifest.py -q` to confirm the cross-
   reference is intact and the rebuilder preservation contract still
   holds.
