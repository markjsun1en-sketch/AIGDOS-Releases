# Audit Log Standard

## Purpose
This document defines the audit standard for AI Game Dev OS v4.89. The goal is not to log everything, but to make the most important state transitions, external writebacks, merge actions, and sprint-close checks reconstructable.

## Audit Layers
### 1. Runtime Audit
Captures internal task creation, state transition, handoff, validation, snapshot generation, and archive events.

### 2. External Sync Audit
Captures TAPD writeback intent, validation result, mutation response, verification read result, and recovery attempts.

### 3. Merge Audit
Captures isolated-unit merge/apply events, conflict handling, cleanup, and integration ownership.

## Required Event Families
A complete trial-ready pack should support these families:
- `runtime.transition`
- `runtime.create`
- `runtime.archive`
- `runtime.handoff`
- `runtime.validation`
- `runtime.snapshot`
- `external.tapd.write`
- `external.tapd.verify`
- `merge.apply`
- `merge.cleanup`
- `trial.check`

## Minimum Common Fields
Every audit entry should include:
- `event_type`
- `timestamp`
- `actor`
- `source_layer`
- `status`
- `summary`

Where relevant, include:
- `task_id`
- `object_id`
- `runtime_profile`
- `sprint_id`
- `evidence_refs`

## Runtime Audit Expectations
Runtime transitions should be reconstructable enough to answer:
- what changed
- who changed it
- from which state to which state
- under which sprint / task context
- whether evidence existed

## External Sync Audit Expectations
External sync audit must make silent-failure scenarios visible. For TAPD-like flows, a successful HTTP response without a successful verification read must still be considered a failed audit outcome.

Recommended fields:
- `object_type`
- `object_id`
- `internal_state`
- `mapped_state`
- `validation_ok`
- `response_ok`
- `verification_ok`
- `retry_count`

## Merge Audit Expectations
Merge/apply audit should answer:
- what isolated unit produced the candidate change
- who approved integration
- whether state files were touched
- whether conflicts occurred
- whether cleanup completed

## Retention and Summaries
Raw logs can stay verbose. Human review should prefer summaries:
- daily summary
- sprint execution summary
- sprint close summary
- reconciliation summary

### Retention & Storage

Concrete retention / storage rules (added to resolve REV-2-013):

| Aspect | Rule |
| --- | --- |
| Storage location (raw logs) | `runtime/logs/audit/<YYYY>/<MM>/<event_family>.jsonl` (append-only, one JSON event per line) |
| Storage location (summaries) | `runtime/logs/audit/summaries/<kind>_<YYYY-MM-DD>.md` (where kind ∈ daily / sprint_execution / sprint_close / reconciliation) |
| Retention (raw logs) | **90 days** rolling retention by default; projects may override in `policy/adaptation/audit_retention.yaml`. Older raw logs compress to `.jsonl.gz` archived under `runtime/logs/audit/archive/<YYYY>/` |
| Retention (summaries) | **indefinite** by default (markdown summaries are small and carry lineage value); may be pruned at release boundary per project policy |
| Summary trigger (daily) | End-of-day timer in CI or manual invocation of `runtime/observability/audit_summary_cli.py --kind daily` |
| Summary trigger (sprint_execution) | Orchestrator at each standup / midpoint cadence |
| Summary trigger (sprint_close) | Sprint close hook (`SPRINT_OPERATING_MODEL.md` phase 3 close gate) |
| Summary trigger (reconciliation) | Any reconcile event per `Registry_Writeback_and_Reconciliation_Contract.md` |
| Owner | `audit_collector` per runtime profile declares who creates the raw logs; Orchestrator owns summary production; EP owns summary review |
| Privacy | Raw logs may contain PII (user identifiers, paths) and must not be committed to public repositories; summaries should redact per `docs/02_governance/PORTABLE_AGENT_BOUNDARIES.md` privacy expectations |

## Red Flags the Standard Must Surface
The standard should make these cases obvious:
- status write succeeded but verification failed
- task was archived without validation evidence
- merge landed but state files were not reconciled
- cleanup expected but not executed
- runtime profile mismatch between task execution and writeback

## Collector Responsibility
Portable schema is shared. Collector logic is runtime-specific. This is why v4.89 separates:
- shared audit schemas
- runtime collectors
- human-readable summary CLIs

## Trial Use During Beta Sprint
During a trial sprint, the audit layer must be good enough for the owner to answer, after the fact:
1. what work happened
2. what wrote to TAPD
3. what merged into the integration line
4. where recovery was required
5. whether sprint close can be trusted
