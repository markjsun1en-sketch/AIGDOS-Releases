# Runtime Summary Export Spec

> Added 2026-04-22 to close REV-3-011 (v4.87 minimum 8-field runtime
> summary spec was not preserved; v4.88 Overview required "clean Sprint
> close and reconciliation" with no summary field standard).

## Purpose

Define the **minimum machine-readable summary** produced at each Sprint close (and optionally at mid-sprint checkpoints). The summary is the single artifact EP / Orchestrator / Dashboard tooling consume when they need "how is the sprint doing" without reading every audit event.

This is the output contract for `scripts/export_runtime_summary.py` (migrated from v4.87 in Phase 2, 4.57 KB).

## Minimum fields (v4.87 origin, preserved)

The 8 fields below must always appear in the summary, even if empty:

| Field | Type | Meaning |
| --- | --- | --- |
| `active_sprint_id` | string / null | The sprint currently open; null if no sprint is active |
| `active_features_count` | integer | Number of features in states open / in_progress / validation_pending |
| `blocked_objects_count` | integer | Entries in `blocker_registry.json` with status != resolved |
| `pending_reconcile_count` | integer | Entries in the pending_reconcile queue per Registry Writeback Contract |
| `stale_handoff_count` | integer | Handoffs unclaimed for more than the profile-defined threshold |
| `missing_evidence_count` | integer | Completed tasks without matching evidence_refs |
| `sprint_close_readiness_result` | enum: ready / conditional / not_ready | Output of `sprint_close_readiness_checker.py` |
| `latest_snapshot_identifier` | string / null | Most recent snapshot id attached to the active sprint |

## Extended fields (v4.89 additions)

Non-breaking additions that consumers may read if present:

| Field | Type | Meaning |
| --- | --- | --- |
| `runtime_profile` | string | Active runtime profile when the summary was produced |
| `generated_at` | ISO 8601 | Wall-clock time of summary generation |
| `schema_version` | string | "v4.88-revise-1" — bump on breaking field changes |
| `writeback_queue_depth` | integer | Queued items in `runtime/queue/writeback_pending.jsonl` (see REV-3-007) |
| `dirty_worktree` | boolean | Whether the Git worktree had uncommitted changes at generation time |

## Example output

```json
{
  "schema_version": "v4.88-revise-1",
  "generated_at": "2026-04-22T18:00:00Z",
  "runtime_profile": "codex",
  "active_sprint_id": "sprint-1",
  "active_features_count": 3,
  "blocked_objects_count": 0,
  "pending_reconcile_count": 0,
  "stale_handoff_count": 0,
  "missing_evidence_count": 0,
  "sprint_close_readiness_result": "ready",
  "latest_snapshot_identifier": "snap-sprint-1-20260422T170000Z",
  "writeback_queue_depth": 0,
  "dirty_worktree": false
}
```

## Generation contract

- **Producer**: `scripts/export_runtime_summary.py` (Phase 2 migrated, v4.87 origin)
- **Output location**: `runtime/logs/runtime_summary_<YYYY-MM-DD>_<sprint_id>.json` by default; overridable via `--output`
- **Trigger**: invoked by Orchestrator at mid-sprint checkpoint and at sprint close gate (`SPRINT_OPERATING_MODEL.md` phase 3)
- **Exit codes**: per REV-2-011 convention (0 pass, 1 WARN, 2 ERROR, 3 INTERNAL_ERROR)

## Consumer contract

Any tool consuming `runtime_summary*.json` must:

1. Read `schema_version` first; bail out with ERROR if the major version doesn't match expectation (avoids silent misinterpretation after a schema bump)
2. Treat missing extended fields as `null`/`false`/`0` (forward compatibility)
3. Never mutate the summary file — it's append-only at the directory level

## Machine-readable schema

Full JSON schema lives at `schemas/runtime_summary.schema.json` (deferred to v4.89 or Phase 4 trial — see REV-3-011-deferred). Until that schema is authored, this document is the canonical source.

## Cross-references

- `scripts/export_runtime_summary.py` — producer
- `AI_Game_Dev_OS_v4.87_Registry_Writeback_and_Reconciliation_Contract.md` — defines `pending_reconcile_count` semantics
- `Writeback_Request_Protocol.md` (REV-3-007) — defines `writeback_queue_depth` semantics
- `GATE_MODEL.md` (REV-2-007) — defines readiness verdict values consumed as `sprint_close_readiness_result`
