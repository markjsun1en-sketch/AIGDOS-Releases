# Pilot Evaluation Checks

> Added 2026-04-22 to close REV-3-010 (v4.87 Pilot_Evaluation_Checks.md
> absent from v4.89; no self-reflective 'did this actually help the
> project' questions surfaced to Beta Sprint exit).

## Purpose

Beta Sprint exit verification (see `BETA_SPRINT_EXIT_CRITERIA.md`) confirms the **mechanism** worked — init clean, audit parseable, close valid. Pilot Evaluation asks a different question: did the mechanism **actually help the project**, or did it add observability that no one used?

Without this check, observability + governance assets can grow indefinitely without trial projects ever reporting back whether they found the assets useful.

## When to run

- **Sprint exit** — after `scripts/verify_beta_sprint_exit.py` passes, before declaring the trial sprint "complete"
- **Quarterly** — aggregate across 3+ Beta Sprints to detect whether assets are getting more or less useful over time
- **Version upgrade** — before promoting to a new v4.x version, to confirm current assets still justify their maintenance cost

## The 6 Pilot Questions

Answer each on a 4-point scale: **Yes / Mostly / Partially / No**. Any answer below "Mostly" must include a one-sentence explanation.

### 1. Did this setup reduce rework?

Rework = any case where an agent or EP redid work because prior outputs were unclear, incomplete, or miscommunicated. Compare against the most recent non-v4.89 sprint of the same project if possible.

### 2. Did it reduce ambiguity?

Ambiguity = the number of handoffs that required clarification rounds, or decisions where EP had to intervene because roles weren't clear from the runtime profile alone.

### 3. Did it improve blocker visibility?

Blocker visibility = the time between a blocker arising and EP / Orchestrator becoming aware. Blocker_registry entries + `issue_escalated` audit events are the quantitative signals.

### 4. Did it improve sprint close trustworthiness?

Sprint close trustworthiness = whether the sprint's "done" label matches what actually shipped, i.e. registry state, TAPD state, and repository state all agree at close.

### 5. Did it make external state (TAPD / Git) easier or harder to trust?

Ease of trust = whether agents and EP act on TAPD/Git state as truth, or have to "check the runtime too" because they don't trust the external system after automation.

### 6. Did observability cost more than it returned?

Cost = time spent maintaining audit pipelines + reviewing logs + fixing collector bugs. Return = incidents prevented + blockers caught + rework avoided. If cost exceeds return for two sprints in a row, observability needs pruning (see `GOVERNANCE_COST_REVIEW.md`).

## Output format

Produce a `pilot_evaluation.md` at sprint close, one page:

```markdown
# Pilot Evaluation — Sprint <id>

| # | Question | Answer | Note |
|---|---|---|---|
| 1 | Reduce rework | Yes / Mostly / Partially / No | ... |
| 2 | Reduce ambiguity | ... | ... |
| 3 | Blocker visibility | ... | ... |
| 4 | Close trustworthiness | ... | ... |
| 5 | External trust | ... | ... |
| 6 | Observability cost vs return | ... | ... |

## Summary
One paragraph capturing the biggest win + the biggest friction.

## Changes requested for next sprint
- ...
```

## Integration with Beta Sprint exit

`BETA_SPRINT_EXIT_CRITERIA.md` §Review summary already asks 5 reflective questions. Pilot Evaluation extends that with the 6 quantifiable questions above. The full exit package is:

1. `scripts/verify_beta_sprint_exit.py` — mechanism-level verification (PASS / CONDITIONAL / FAIL)
2. `pilot_evaluation.md` — usefulness-level self-report
3. Sprint close summary (`docs/09_beta_sprint/SPRINT_CLOSE_CHECKLIST.md`) — operational summary

All three should be filed before the sprint is marked complete.

## v4.87 ancestry

This document ports v4.87's `AI_Game_Dev_OS_v4.87_Pilot_Evaluation_Checks.md` (under `docs/07_dashboard_and_observability/` in the v4.87 pack). The 6 questions preserved verbatim; output format adapted to v4.89's sprint structure (inherited from v4.88_Revise).
