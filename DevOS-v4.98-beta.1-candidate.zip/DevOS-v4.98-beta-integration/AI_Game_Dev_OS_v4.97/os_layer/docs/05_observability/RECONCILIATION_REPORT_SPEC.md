# Reconciliation Report Spec

## Purpose
Summarize whether runtime state, TAPD state, and Git / merge state are aligned at a checkpoint.

## Report sections
1. Scope
2. Runtime profile used
3. Runtime state summary
4. External sync verification summary
5. Merge / branch hygiene summary
6. Exceptions / anomalies
7. Required follow-up actions

## Minimum outputs
- counts by status
- writeback attempts vs verified writes
- parent / child aggregation mismatches
- stale branch or dirty worktree summary
- unresolved exceptions

## Usage points
- Sprint close
- Mid-sprint audit
- Migration validation

## Trigger Conditions

Reconciliation reports are produced when:

- Sprint close (mandatory, per `SPRINT_OPERATING_MODEL.md` phase 3)
- Mid-sprint checkpoint (Orchestrator-owned cadence per project)
- Any critical adapter event indicating state mismatch (per `Registry_Writeback_and_Reconciliation_Contract.md`)
- Migration validation (when `scripts/validate_runtime_paths.py --apply` is invoked for a future version bump)

## Example Report Skeleton

```markdown
# Reconciliation Report — Sprint <N>
_generated <ISO8601> by <collector_owner>_

## 1. Scope
Sprint: <sprint_id>
Profile: <runtime_profile>
Window: <ISO8601 from> to <ISO8601 to>

## 2. Runtime Profile Used
<profile_identifier> (see config/profiles/<profile>.json)

## 3. Runtime State Summary
- tasks in state OPEN: N
- tasks in state IN_PROGRESS: N
- tasks in state VALIDATION_PENDING: N
- tasks in state DONE: N
- tasks in state ARCHIVED: N

## 4. External Sync Verification
- writeback attempts: N
- writeback verified: M
- writeback unverified: K (requires attention)
- parent/child aggregation mismatches: L

## 5. Merge / Branch Hygiene
- active branches: N
- stale branches (> threshold days): M
- dirty worktrees: K
- merge events: L

## 6. Exceptions / Anomalies
<list>

## 7. Required Follow-up
<actionable items with owners>
```

## Schema Reference

A machine-readable counterpart is planned at `schemas/reconciliation_report.schema.json`. Until it is authored, reports remain markdown per the skeleton above. REV-2-016 deferred to v4.89 for schema work.
