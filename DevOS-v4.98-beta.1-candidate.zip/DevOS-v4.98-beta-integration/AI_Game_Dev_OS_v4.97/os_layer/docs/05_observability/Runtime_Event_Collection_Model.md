# Runtime Event Collection Model

## Split of responsibility
- Portable core defines schemas and report expectations.
- Runtime profiles define where events come from.
- Collectors normalize runtime-native signals into shared schemas.

## Collector design goals
- low-friction append-only logging
- explicit runtime profile tagging
- tolerant of partial capability differences
- no assumption that all runtimes expose hooks equally

## Collector outputs
- raw normalized event rows
- summarized audit snapshots
- reconciliation input bundles

## Collector Protocol

Every collector implementation must satisfy this interface:

```python
class RuntimeEventCollector(Protocol):
    """Collector normalizes runtime-native signals into shared event schemas."""

    def collect(self, source) -> list[dict]:
        """Read from `source` and emit a list of events.

        Args:
            source: runtime-specific input (file path, subprocess output,
                    MCP event stream, etc.) — see per-profile binding.

        Returns:
            List of event dicts conforming to `mcp_audit_log.schema.json`
            or `external_sync_audit.schema.json` (collector declares which).
            Empty list is valid (no events in window).

        Raises:
            CollectorReadError: source unreachable or malformed.
            CollectorSchemaError: could not produce schema-conformant events.
        """
        ...

    def schema_id(self) -> str:
        """Return the schema identifier this collector produces."""
        ...

    def profile_tag(self) -> str:
        """Return the runtime profile tag for events from this collector."""
        ...
```

Error handling:
- `CollectorReadError` → caller logs to `runtime/logs/audit/collector_errors.log` and proceeds with empty result
- `CollectorSchemaError` → caller logs AND raises; do not silently drop potentially important events

## Implementation Status

Per `runtime/MATURITY_MATRIX.md`, the 5 collectors under `runtime/observability/runtime_event_collectors/` are currently SCAFFOLD (~485 bytes each). Phase 4 trial scope requires they reach at least GUIDED for the profile being trialed.
