# Runtime Init No-Demo Spec

## Goal

Initialization must be safe for real projects by default.

## Rules

- do not inject demo tasks unless explicitly requested
- do not retain example project IDs
- require explicit execution profile selection
- create empty but valid runtime state structures

## Output Contract

`scripts/init_runtime_env.py` must produce the following outputs:

| Situation | stdout / stderr | Exit code |
| --- | --- | --- |
| Init complete (empty state) | stdout: `init: project=<id> profile=<profile> state_written=runtime/state/runtime_state.json` | 0 |
| Profile not specified | stderr: `init: ERROR runtime-profile argument required (see EXECUTION_PROFILE_SELECTION.md)` | 2 |
| Profile unknown | stderr: `init: ERROR unknown profile '<profile>' (valid: codex,cursor,claude_code_subagents,claude_code_agent_teams,workbuddy_private)` | 2 |
| Demo residue detected | stderr: `init: ERROR demo residue detected at <path>; remove before re-running init` | 2 |
| Existing state would be overwritten | stderr: `init: WARN existing runtime_state.json detected; re-run with --force to overwrite` | 1 |
| Internal tool error | stderr: `init: INTERNAL_ERROR <exception message>` | 3 |

Demo residue definition: any file matching `*demo*`, `*example*`, `tasks/demo_*`, or containing `demo_project_id` / `example_project_id` in `runtime_state.json`.

Log location: `runtime/logs/init.log` (append, one JSON-line per run with full argv + timestamp + exit code).
