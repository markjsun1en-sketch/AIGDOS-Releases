# AI_Game_Dev_OS v4.87 Registry Writeback and Reconciliation Contract

## 1. Purpose

This document defines, within the AI Game Dev OS v4.87 Run Baseline, the Registry's responsibility boundary, object persistence rules, external-state writeback mechanism, and reconciliation workflow. It acts as the unified contract for:

- Structured persistence of Runtime Objects
- Ingestion of external events (Jira / TAPD / Git / Build / Test, …)
- Derived writeback into the Registry
- State-inconsistency detection and governance closure
- Snapshot generation and thread recovery

The core goal is not to turn the Registry into a manually maintained ledger, but to define it as:

**An operational ledger derived from Runtime Objects, external collaboration state, and engineering evidence.**

---

## 2. Scope

This document covers:

1. The Registry's positioning and responsibility boundary
2. Its minimal data model
3. Persistence rules for Runtime Objects
4. Principles for external-state writeback
5. The reconciliation mechanism
6. Rules for auto-writeback vs. pending-reconcile vs. escalation
7. Snapshot and Registry relationships
8. Minimal governance gates

It does not cover:

- Detailed object-model definitions (owned by the Runtime Object Model Spec)
- Detailed state-transition diagrams (owned by the Core State Machine Spec)
- Concrete script implementation details (owned by the Tooling / Runtime Script Blueprint)
- The full long-term memory system (owned by the Context / Memory documents)

---

## 3. Design Positioning

In v4.87 the Registry is not:

- A chat-summary store
- A human-maintained master table
- A mirror copy of external Jira/TAPD
- A full-history document warehouse

In v4.87 the Registry is positioned as:

### 3.1 Runtime Source of Operational Truth
It expresses the system's current understanding of:

- Which objects are active
- Their current state
- How they relate to each other
- Which risks remain open
- Which evidence supports the current state
- The operational view of the current sprint and snapshot

### 3.2 Derived Truth Layer
The Registry is not maintained item-by-item by humans; instead it is derived, as much as possible, from:

- Runtime Objects
- External collaboration state (Jira / TAPD …)
- Git / PR / branch / commit
- Build / Test / Validation results
- The snapshot generator

### 3.3 Reconciliation-Friendly Layer
The Registry must natively support:

- Difference detection
- State-conflict localisation
- Writeback confidence grading
- Escalation handling
- Repair actions

---

## 4. Core Principles

## 4.1 Registry records "current structured operational facts"
The Registry stores only the structured information the current run needs to consume; it is not a full narrative history.

## 4.2 The Registry is not equal to any external system
Jira/TAPD, Git, CI, and Dashboards are Specialized Truth Layers; the Registry is the runtime ledger derived from all of them.

## 4.3 External Done does not equal Internal Accepted
External "Done / Resolved / Closed" can only be treated as an input signal — it must never push internal objects straight into a final acceptance state.

## 4.4 The Registry must be recoverable
When a thread restarts, an agent swaps, or a sprint closes, the Registry must remain the upstream source for the Snapshot and for the recovery entry point.

## 4.5 The Registry must be minimal-maintenance
Anything that can be auto-derived must not require human re-maintenance.

---

## 5. Registry Responsibilities

In v4.87 the Registry takes on:

### 5.1 Active Object Ledger
Records the currently active:

- features
- tasks
- issues
- handoffs
- escalations
- sprint

### 5.2 Object State Ledger
Records, per object:

- current state
- owner
- priority / severity
- last-updated timestamp
- key refs

### 5.3 Relationship Ledger
Records key object relationships:

- feature ↔ task
- feature ↔ issue
- object ↔ handoff
- object ↔ validation_evidence
- sprint ↔ active objects
- snapshot ↔ active objects

### 5.4 Governance Intake Layer
Receives state-change input from external systems and validation results.

### 5.5 Reconciliation Substrate
Provides the reconciliation basis for mismatch detection, governance classification, escalation, and repair.

---

## 6. Minimal Registry Data Model

v4.87 Registry is recommended to adopt the following minimal structure:

```yaml
registry:
  meta:
    registry_version:
    generated_at:
    active_sprint_id:
    source_priority_profile:

  active_index:
    feature_ids: []
    task_ids: []
    issue_ids: []
    handoff_ids: []
    escalation_ids: []
    snapshot_ids: []

  objects:
    features: {}
    tasks: {}
    issues: {}
    handoffs: {}
    decisions: {}
    validations: {}
    escalations: {}
    sprints: {}
    snapshots: {}

  relations:
    feature_to_tasks: {}
    feature_to_issues: {}
    object_to_handoffs: {}
    object_to_validations: {}
    sprint_to_objects: {}
    snapshot_to_objects: {}

  governance:
    pending_reconcile: []
    blockers: []
    escalations: []
    stale_handoffs: []
    readiness_flags: []
```

---

## 7. Object Persistence Rules

## 7.1 Objects That Must Be Persisted
The following must enter the Registry:

- feature
- task
- issue
- handoff
- snapshot

## 7.2 Objects That Should Be Persisted
The following should enter the Registry:

- decision
- validation_evidence
- sprint

## 7.3 Objects That May Start Lightweight
In the v4.87 Alpha phase the following may be persisted lightly:

- escalation

---

## 8. Per-Object Registry Entry Requirements

# 8.1 Feature Entry

A feature entry must carry at least:

- `feature_id`
- `title`
- `owner`
- `state`
- `priority`
- `stage`
- `acceptance_criteria_ref`
- `task_refs`
- `issue_refs`
- `validation_refs`
- `last_updated_at`

# 8.2 Task Entry

A task entry must carry at least:

- `task_id`
- `feature_id`
- `title`
- `owner`
- `state`
- `task_type`
- `dependencies`
- `implementation_refs`
- `handoff_refs`
- `last_updated_at`

# 8.3 Issue Entry

An issue entry must carry at least:

- `issue_id`
- `title`
- `issue_type`
- `severity`
- `owner`
- `state`
- `affected_feature_refs`
- `affected_task_refs`
- `evidence_refs`
- `linked_fix_task_refs`
- `last_updated_at`

# 8.4 Handoff Entry

A handoff entry must carry at least:

- `handoff_id`
- `from_owner`
- `to_owner`
- `handoff_type`
- `state`
- `source_object_refs`
- `required_action`
- `expected_outputs`
- `acceptance_condition`
- `due_at`
- `last_updated_at`

# 8.5 Snapshot Entry

A snapshot entry must carry at least:

- `snapshot_id`
- `snapshot_type`
- `scope`
- `active_feature_refs`
- `active_task_refs`
- `active_issue_refs`
- `risk_refs`
- `next_actions`
- `created_at`

---

## 9. Source Priority Rules

To avoid multi-source conflicts, v4.87 Registry writeback must follow a fixed priority:

### 9.1 For interface implementation / code landing / test outcomes
Priority:

`Git / PR / Build / Test / Validation Evidence > document narrative > chat notes`

### 9.2 For design boundaries / acceptance boundaries / scope statements
Priority:

`Decision > Approved Feature Definition > general descriptive docs > chat notes`

### 9.3 For collaboration-workflow state
Priority:

`Jira / TAPD External Workflow State` is treated as a collaboration input signal.

However:

**External state must not overreach and define internal acceptance state.**

### 9.4 For runtime-ledger state
Priority:

`Registry Derived State > single-point self-report > single chat conclusion`

---

## 10. External Input Sources

v4.87 supports the following external input sources participating in Registry writeback:

### 10.1 Work Tracking Sources
- Jira
- TAPD
- Other comparable work-item systems

### 10.2 Code Sources
- Git branch
- commit
- PR / MR
- merge status
- changed files

### 10.3 Build / Validation Sources
- build result
- test result
- validation scripts
- logs
- screenshots
- playtest notes

### 10.4 Internal Runtime Sources
- Runtime Objects themselves
- Snapshot generator
- Governance routines

---

## 11. Writeback Model

The v4.87 Registry writeback must not adopt a "external state writes the final state directly" pattern. It must adopt:

# Event Trigger -> Evidence Pull -> Candidate State -> Confidence Check -> Registry Update

---

## 12. Writeback Steps

## 12.1 Step 1: Event Trigger

Trigger sources may include:

- Jira/TAPD issue updated
- Jira/TAPD transitioned
- PR created / merged
- build finished
- test finished
- validation recorded
- handoff accepted / completed
- sprint close requested

## 12.2 Step 2: Pull Context

The sync logic must pull:

- Current external object state
- Associated runtime object id / mapping
- Latest Git / PR / build / test evidence
- Current Registry state
- Related blocker / handoff / decision

## 12.3 Step 3: Compute Candidate State

Compute a candidate state by the rules — do not overwrite directly.

## 12.4 Step 4: Confidence Evaluation

The candidate state is graded as:

- High confidence
- Medium confidence
- Low confidence

## 12.5 Step 5: Registry Action

Based on confidence, execute:

- Auto-writeback
- Write to `pending_reconcile`
- Create an escalation

---

## 13. Mapping Rules from External Workflow to Runtime Objects

## 13.1 External Task / Subtask

Recommended mapping:

- External To Do / Open -> runtime task `CREATED` / `READY`
- External In Progress -> runtime task `IN_PROGRESS`
- External Done -> runtime task `CLAIMED_DONE`
- External Closed -> runtime task `CLAIMED_DONE` or candidate for `VERIFIED`

Strict rule:

**External Task Done does not map directly to runtime task CLOSED.**

## 13.2 External Story / Feature / Requirement

Recommended mapping:

- External Open -> runtime feature `PROPOSED` / `APPROVED`
- External In Progress -> runtime feature `IN_IMPLEMENTATION`
- External Done -> candidate for runtime feature `IN_VALIDATION`
- External Closed -> candidate for runtime feature `PLAYTEST` / `ACCEPTED`, subject to extra gates

Strict rule:

**External Feature Done / Closed does not map directly to runtime feature ACCEPTED.**

## 13.3 External Bug / Defect

Recommended mapping:

- External Open -> runtime issue `OPEN`
- External Triaged -> runtime issue `TRIAGED`
- External In Fix -> runtime issue `IN_FIX`
- External Resolved -> runtime issue `RESOLVED`
- External Closed -> candidate for runtime issue `VERIFIED` / `CLOSED`

Strict rule:

**External Bug Resolved does not equal runtime issue VERIFIED.**

---

## 14. Evidence-Gated Writeback Rules

## 14.1 Feature Writeback Gate

When a candidate state would promote a feature to the following, evidence must be validated:

### Promote to `IN_VALIDATION`
Must have at least:

- implementation refs
- task(s) entering `CLAIMED_DONE` / `VERIFIED`
- No unresolved blocker

### Promote to `PLAYTEST`
Must have at least:

- basic validation evidence
- a playable entry point
- defined playtest scope

### Promote to `ACCEPTED`
Must have:

- acceptance criteria met
- validation evidence on file
- blocker issue(s) closed or explicitly exempted
- key handoff(s) closed
- explicit owner acceptance

## 14.2 Task Writeback Gate

Promoting a task to `CLAIMED_DONE` requires at least:

- implementation_refs or output_refs
- a clear outcome statement

Promoting a task to `VERIFIED` requires at least:

- a reviewer / validator result
- or an auto-validation result

## 14.3 Issue Writeback Gate

Promoting an issue to `RESOLVED` requires at least:

- a repair-action description
- linked_fix_task_refs
- a reference to the repair evidence

Promoting an issue to `VERIFIED` requires at least:

- the reproduction has disappeared or verification has passed

---

## 15. Confidence Levels

## 15.1 High Confidence

The following conditions make auto-writeback into the Registry safe:

- source mapping is explicit
- candidate state is unique
- required evidence is present
- no conflict with current blocker / handoff / decision

## 15.2 Medium Confidence

The following cases must not auto-write; they enter `pending_reconcile`:

- external state is clear but some evidence is missing
- Git/Build state exists but is incomplete
- handoff is not closed but the impact is uncertain
- multiple signals support different transition paths

## 15.3 Low Confidence

The following cases must create an escalation or governance item:

- multi-source states conflict with each other
- mapping is unclear
- a key blocker is unknown
- acceptance-state promotion lacks evidence
- external state diverges significantly from the internal definition

---

## 16. Reconciliation Model

Reconciliation performs a consistency check across three layers of truth:

1. Runtime Object state
2. External workflow state
3. Engineering / validation evidence

---

## 17. Reconciliation Categories

### 17.1 Soft Mismatch
Examples:

- external state was updated; the Registry has not caught up
- a task is missing non-critical refs
- a handoff description is incomplete

Handling:

- auto-fill
- mark as pending completion

### 17.2 Workflow Drift
Examples:

- External Done but no implementation evidence
- Feature is a candidate for ACCEPTED but lacks validation
- A handoff has been open too long

Handling:

- write to `pending_reconcile`
- create a governance item

### 17.3 Critical Blocker
Examples:

- build fail, yet sprint close is being pushed
- a blocker issue is still open when ACCEPTED is attempted
- approval handoff is incomplete but a final state is being entered

Handling:

- block the writeback
- create an escalation

### 17.4 Registry Corruption Risk
Examples:

- the same object carries mutually exclusive states
- object mapping is broken
- snapshot and active registry diverge significantly

Handling:

- enter repair mode
- require human intervention or a higher-priority governance script

---

## 18. Pending Reconcile Contract

A `pending_reconcile` item must record at least:

- `reconcile_id`
- `source_object_ref`
- `source_signal`
- `current_registry_state`
- `candidate_state`
- `missing_evidence`
- `conflict_reason`
- `recommended_action`
- `created_at`

Its purpose is to:

- hold a candidate state that was not auto-persisted
- feed the governance closure loop
- ground human or AI review

---

## 19. Snapshot Relationship Rules

## 19.1 Snapshot Source Rule
A snapshot must be derived from the current active state of the Registry, not reassembled from chat history.

## 19.2 Snapshot Freeze Rule
When a snapshot is produced, freeze:

- active features
- active tasks
- active issues
- active handoffs
- pending blockers
- key decisions
- next actions

## 19.3 Snapshot Recovery Rule
On thread restart, load in this order:

1. latest relevant snapshot
2. current active registry subset
3. pending reconcile items
4. key decisions / blockers

---

## 20. Minimal Guardrails

## 20.1 No External Final Override
External systems must not push internal objects into a final acceptance state directly.

## 20.2 No Acceptance Without Evidence
Without evidence, a feature must not be written as ACCEPTED.

## 20.3 No Sprint Close with Unresolved Blocker
A sprint must not pass close-readiness while a blocker issue or a critical pending-reconcile item exists.

## 20.4 No Responsibility Assumption Without Handoff Closure
Do not assume that responsibility has landed while a key handoff is still open.

## 20.5 No Silent Conflict Merge
When multi-source states conflict, silent overwrite of the Registry is forbidden.

---

## 21. Minimal Runtime Script Expectations

v4.87 must at least provide the following scripts to enact this contract:

- `registry_manager.py`
- `snapshot_generator.py`
- `reconcile_external_state.py`
- `state_transition_engine.py`
- `sprint_close_readiness_checker.py`

These scripts do not replace the contract; they execute it.

---

## 22. Adoption Notes

v4.87 Alpha should prioritise:

1. Landing the minimal Registry structure
2. Persisting feature / task / issue / handoff objects
3. External Done -> `CLAIMED_DONE` / candidate-for-`IN_VALIDATION` mapping
4. A basic `pending_reconcile` mechanism
5. Snapshot generation and recovery entry point

v4.87 Beta then strengthens:

- automated blocker detection
- escalation router
- repair executor
- more complete external mapping
- starter / project-level integration

---

## 23. Acceptance Criteria

This document is adoptable if and only if:

1. The Registry is clearly defined as a derived ledger, not a parallel human-maintained system.
2. Minimal persistence rules for Runtime Objects are explicit.
3. External writeback uses a "candidate-state + confidence + reconciliation" model, not direct overwrite.
4. The boundary between `pending_reconcile` and escalation is clear.
5. The relationship between Snapshot and Registry is explicit.
6. It is a stable upstream for Governance Closure and Context Governance.

---

## 24. Final Positioning

`AI_Game_Dev_OS_v4.87_Registry_Writeback_and_Reconciliation_Contract` is the third core specification of the v4.87 Run Baseline.

It answers:

- What the Registry actually is
- How Runtime Objects get persisted
- How external state enters the system
- When to auto-write, when to pend for reconciliation, and when to escalate

On that basis, the next wave should continue to solidify:

- Governance Reconciliation Spec
- Governance Exception Model
- Escalation and Repair Rules

so that "writeback and reconciliation" closes into a full "governance capability".
