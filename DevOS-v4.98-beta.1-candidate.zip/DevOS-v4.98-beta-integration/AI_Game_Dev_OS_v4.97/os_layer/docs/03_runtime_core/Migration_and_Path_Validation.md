# Migration and Path Validation

## Goal

Upgrades must detect broken references before they corrupt runtime use.

## Validation Targets

Each target is backed by a detection mode. v4.89 (inheriting from v4.88_Revise) implements only **stale version naming** at the script level; the other four targets have their contract defined here but detection is deferred to v4.90 script work.

| # | Target | v4.89 script coverage | Deferred work |
| --- | --- | --- | --- |
| 1 | markdown references | (doc contract only) | markdown-link-check style broken-link walker |
| 2 | python imports and path strings | (doc contract only) | AST-walker confirming every `import X` resolves; `Path(...)` literals referencing existing paths |
| 3 | shell script path usage | (doc contract only) | bash line-scan for heredoc / literal paths that must exist |
| 4 | json/yaml config references | (doc contract only) | schema-based validation confirming referenced paths / keys exist |
| 5 | stale version naming | `scripts/validate_runtime_paths.py` regex `r"v4\.87\|V4\.87\|4\.87"` emits WARN | — |

Deferred items are tracked as `REV-2-006 deferred` in the v4.89 task backlog; their absence is a documented gap, not a silent regression.

## Output Classes

- ERROR: broken path or required reference missing
- WARN: stale version reference or probably outdated path
- INFO: suggested rewrite or migration note

## Output Examples

Each class has a canonical line format so downstream audit tools can parse output reliably:

```
ERROR: broken python import: module 'runtime.ghost' referenced by scripts/init_runtime_env.py:42 (file not found)
WARN:  stale version reference: 'v4.87' in docs/00_entry/START_HERE.md:21 (expected: current release identifier)
INFO:  suggested rewrite: docs/07_starters/shared/LOADSET_MODEL.md refers to an archived template path; prefer docs/07_starters/shared/
```

Exit codes:

- `0` — all validations passed, no ERROR or WARN
- `1` — WARN raised but no ERROR (non-blocking)
- `2` — any ERROR raised (migration must be blocked)
- `3` — internal tool failure (file read error, malformed JSON, etc.)

## Run Modes

- `--dry-run` (default): report findings; make no changes
- `--apply`: only for targets that support automatic rewrite (currently none at v4.89 level — all rewrites are manual). Reserved keyword for future v4.90+ script expansion.
