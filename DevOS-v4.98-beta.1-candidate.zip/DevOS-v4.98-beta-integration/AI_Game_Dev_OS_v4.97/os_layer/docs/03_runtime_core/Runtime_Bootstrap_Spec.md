# Runtime Bootstrap Spec

## Purpose

Runtime bootstrap standardizes startup so scripts do not depend on a fragile working-directory assumption.

## Bootstrap responsibilities

- establish a usable import/search path
- discover the package root
- expose root information to downstream runtime utilities
- fail loudly when the runtime context is invalid

## Root marker

Bootstrap expects `.core_os_root` to be available as the canonical root marker in the RC line.
If the marker is missing, bootstrap should surface a clear error rather than silently guessing.

## Safe rule

A runtime script is not considered portable if it only works from one specific current-working-directory layout.

## Output Contract

Bootstrap utilities must produce deterministic, parseable output on both success and failure:

| Situation | stdout / stderr | Exit code |
| --- | --- | --- |
| Root discovered | stdout: single line `bootstrap: root=<absolute_path>` | 0 |
| Marker missing | stderr: `bootstrap: ERROR marker '.core_os_root' not found (searched from <cwd> upward to <stop>)` | 2 |
| Marker present but content malformed | stderr: `bootstrap: ERROR marker '.core_os_root' content invalid (expected /^v\d+\.\d+/, got '<actual>')` | 2 |
| Environment override path does not exist | stderr: `bootstrap: ERROR env override CORE_OS_ROOT=<path> does not exist` | 2 |
| Internal tool error | stderr: `bootstrap: INTERNAL_ERROR <exception message>` | 3 |

Exit code conventions are shared across all runtime core specs: 0 = pass, 2 = domain ERROR (must block), 3 = tool failure. Code 1 is reserved for WARN-only scenarios (none at bootstrap level currently).

Log location: bootstrap writes a one-line entry to `runtime/logs/bootstrap.log` per invocation (append mode). Format: `<ISO8601> <status> <cwd> <resolved_root>`.
