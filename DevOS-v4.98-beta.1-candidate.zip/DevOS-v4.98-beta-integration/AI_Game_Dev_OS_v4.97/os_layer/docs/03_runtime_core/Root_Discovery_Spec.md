# Root Discovery Spec

## Purpose

The runtime must be able to discover the package/project root without assuming a fixed directory depth.

## Marker file

`.core_os_root` is the canonical marker file for root discovery in the v4.89 release line.
It is a lightweight marker used by runtime bootstrap and validation scripts to identify the intended root.

## Discovery order

1. explicit environment override (when supported)
2. upward search for `.core_os_root`
3. fallback structural validation against required directories/files

## Why a marker file exists

Earlier project evidence showed that hard-coded parent-depth assumptions break as soon as policy/tools/runtime files move into a different directory layout.
A marker file is a safer, more portable baseline than `parents[n]` assumptions.

## Ownership

The marker file is created as part of the package/config baseline. Users normally do not edit it directly.

## `.core_os_root` Canonical Specification

> Added 2026-04-22 to address REV-1-013 (previous coverage was scattered across START_HERE L21, this spec L9/L15, Runtime_Bootstrap_Spec L16, and SPRINT0_PRECHECK L7 without a single authoritative definition).

### File location

- **Canonical path**: `config/.core_os_root` (relative to the package/project root)
- **Rationale for `config/` placement**: keeps discovery markers co-located with other runtime configuration; avoids cluttering the package root with bootstrap-only metadata.

### Content format

Single-line UTF-8 text file. Content is a version marker string matching the regex `^v\d+\.\d+(-[A-Za-z0-9_]+)?$`.

- v4.88 RC12 content: `v4.88-marker` (13 bytes, no trailing newline; preserved verbatim in `AI_Game_Dev_OS_v4.88_Release/` byte-locked archive)
- v4.88-stable / v4.88_Revise content: `v4.88-marker` (kept identical to RC12 to preserve `diff -rq` zero-delta vs RC12 source during the v4.88_Revise phase)
- v4.89 (this line): updated to `v4.89-marker` to align with the v4.89 release identity (RC3 reflow, 2026-05-08); the regex above still validates because `(-[A-Za-z0-9_]+)?` accepts the `-marker` suffix unchanged.

### Upgrade policy

- On major version bump, the marker content is updated in the same commit that updates `VERSION` and `RELEASE_MANIFEST.json` so discovery stays consistent.
- Never edit the marker manually during normal operation; bootstrap / validation scripts treat it as read-only.

### Multi-version coexistence

When multiple v4.x packages coexist on the same filesystem (e.g. reference archive + active package), discovery scripts:

1. First honor the environment override (see Discovery order §2 below)
2. Then upward-search starting from the script's current working directory
3. Match the first `.core_os_root` encountered — do **not** attempt content-based version matching at discovery time; content validation happens after root is chosen

## Output Contract

Discovery utilities must produce the same deterministic output format as `Runtime_Bootstrap_Spec.md` (which calls into discovery). See that spec's Output Contract table for the canonical format.

Additional discovery-specific outputs:

| Situation | stdout / stderr | Exit code |
| --- | --- | --- |
| Multiple markers found (version collision) | stderr: `discovery: WARN multiple '.core_os_root' markers on search path; picking closest: <path>; other candidates: <list>` | 1 |
| Marker found but path traversal blocked | stderr: `discovery: ERROR marker at '<path>' but current directory not inside resolved root` | 2 |
