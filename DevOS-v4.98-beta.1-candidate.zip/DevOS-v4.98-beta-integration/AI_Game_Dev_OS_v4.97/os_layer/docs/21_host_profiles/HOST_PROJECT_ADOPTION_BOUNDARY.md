# HOST_PROJECT_ADOPTION_BOUNDARY.md — v4.91 Addendum-A

> **Layer 1 (OS Spec).** The contract every host tool (Workbuddy / Codex / Cursor / Claude Code / future hosts) MUST honour when adopting a new project into the v4.91 Hub. Companion to the schema-level enforcement in `schemas/mount/host_profile.schema.json` (1.1.0) and the host-tool YAMLs in `profiles/<host>/host_profile.yaml`.

---

## 1. The boundary

When a host tool helps a user adopt a project into the v4.91 AI Dev OS Hub, it stands at the boundary between **two truth-owners**:

| Owner | Path | Writable by host? |
|---|---|---|
| **Core OS** | `<external>/AI_Game_Dev_OS_Core/` | NO — readonly reference |
| **Project state** | `<Project>/.ai_dev_os/` | YES — but only inside this directory |
| **Project source** | `<Project>/src/`, `assets/`, `project.godot`, etc. | NO — never, ever |

The single architectural rule:

> Adoption tools generate **only** `.ai_dev_os/` scaffold + a reference to external Core. They do NOT copy the Core release bundle into the project root by default.

## 2. Default mount mode

Every host profile MUST declare `project_adoption.default_mount_mode: external_core`. The schema enum permits 3 forward-only values. Post-Addendum-B, `link` no longer exists in any layer (Charter anti-pattern #15: No mount_mode aliases) — this is now identical to the project_mount enum, not a tighter forward-only subset.

| Allowed | Forbidden |
|---|---|
| `external_core` | `link` (removed in Addendum-B per Charter #15) |
| `thin_scaffold` | `copy` (Charter anti-pattern #9) |
| `vendor_snapshot` | any value not in the 3-enum |

## 3. The 7 forbidden default actions

Every host profile MUST declare these 7 actions in `forbidden_default_actions[]`. They are the **schema-vocabulary** anti-pattern #14 enforces.

| # | Action | Rationale |
|---|---|---|
| 1 | `copy_full_release_to_project_root` | The headline anti-pattern. Triggers Source-of-Truth ambiguity. |
| 2 | `treat_release_bundle_as_project_truth` | Even reading-but-not-writing as project truth causes drift. |
| 3 | `patch_embedded_release_bundle` | Modifying a copied release bundle desynchronises the Hub's version_lock. |
| 4 | `include_release_bundle_in_runtime_scan` | Inflates IDE/agent context with OS docs. |
| 5 | `include_release_bundle_in_ltm_retrieval` | Pollutes LTM v3 retrieval with OS-internal documents. |
| 6 | `include_release_bundle_in_gate_scope` | Closure gate would scan release internals as project content. |
| 7 | `generate_project_state_inside_release_bundle` | Writes project logs/handoffs/registry into the wrong tree. |

A host that omits any of these 7 from its profile **violates the v4.91 adoption contract** even if its YAML is otherwise schema-valid (the schema's `enum` constrains the values; the contract requires all 7 to be present).

## 4. The 9 allowed default actions

Every host MAY declare these in `allowed_actions[]`. All 9 target paths under `.ai_dev_os/`.

```yaml
allowed_actions:
  - generate_ai_dev_os_scaffold      # create .ai_dev_os/ skeleton
  - write_project_mount_yaml         # .ai_dev_os/project_mount.yaml
  - write_project_runtime_protocol   # .ai_dev_os/project_runtime_protocol.yaml
  - write_version_lock               # .ai_dev_os/version_lock.yaml
  - write_local_logs                 # .ai_dev_os/local_logs/
  - write_local_registry             # .ai_dev_os/local_registry/
  - write_local_handoffs             # .ai_dev_os/local_handoffs/
  - write_local_memory               # .ai_dev_os/local_memory/
  - write_exports                    # .ai_dev_os/exports/
```

## 5. Capability matrix discipline

`schemas/mount/host_profile.schema.json :: capabilities` carries 4 capability flags + 1 const-locked guard:

| Field | Permitted values | Const lock |
|---|---|---|
| `supports_project_instructions` | bool | — |
| `supports_skills` | bool / `conditional` / `environment_dependent` | — |
| `supports_subagents` | bool / `conditional` / `environment_dependent` / `profile_dependent` | — |
| `supports_team_mode` | bool / `conditional` / `environment_dependent` / `profile_dependent` | — |
| `auto_subagent_without_explicit_request` | — | **`const false`** (Charter anti-pattern #13) |

The const false lock at the schema level means **no host profile, on any host tool, can declare default automatic multi-agent execution** — even hosts with native subagent support (e.g. Claude Code) MUST set this to `false` and gate real subagent dispatch on explicit task prompts.

## 6. Profiles shipped in v4.91 Addendum-A

| Host | recommended_mode | Notes |
|---|---|---|
| `workbuddy` | `project_rules_plus_explicit_task_prompt` | The trigger of this addendum — was copying full release into project root in v4.90. |
| `codex` | `explicit_preflight_request_or_skill` | Subagent support is profile-dependent. |
| `cursor` | `project_rules_plus_explicit_task_prompt` | Honours `.cursorrules`. |
| `claude_code` | `slash_command_or_explicit_subagent_task` | Native subagent support, but anti-pattern #13 still applies. |

A 5th `recommended_mode` enum value, `team_mode_mapping_with_fallback`, is reserved for future hosts. The 6th, `manual_notes_only`, is the safe fallback when no automation is available.

## 7. Per-project host_profile override

A project MAY ship `<Project>/.ai_dev_os/host_profile.yaml` to override the Core-side `profiles/<host>/host_profile.yaml`. The override:

- MUST validate against the same schema (1.1.0)
- MUST NOT loosen any `const`-locked guard (`auto_subagent_without_explicit_request`, `copy_full_release_bundle_by_default`, `scaffold_target`)
- MAY tighten capability declarations (e.g. set `supports_subagents` from `conditional` to `false` for a project that has explicitly tested it)
- MAY override `recommended_mode`

`validate_project_mount.py` uses the project-side override when present; otherwise falls back to the Core-side default.

## 8. Charter alignment

- **#2** — no project names in Core (host profiles use generic host_tool enums)
- **#9** — mount_mode enum locked
- **#13** — `auto_subagent_without_explicit_request: const false`
- **#14** — `copy_full_release_bundle_by_default: const false`

Layer 1. No project names.
