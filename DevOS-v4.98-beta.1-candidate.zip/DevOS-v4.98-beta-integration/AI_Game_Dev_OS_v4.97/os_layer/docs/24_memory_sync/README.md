# Memory Sync / Periodic Uplink — Adoption Notes

> **Layer 1 (OS Spec) — adoption surface.** v4.91 P5 / Milestone E B8.
>
> **Schemas**:
> - [`schemas/memory/project_summary.schema.json`](../../schemas/memory/project_summary.schema.json) (1.0.0)
> - [`schemas/memory/preflight_summary.schema.json`](../../schemas/memory/preflight_summary.schema.json) (1.0.0)
> - [`schemas/memory/uplink_record.schema.json`](../../schemas/memory/uplink_record.schema.json) (1.0.0)
>
> **Scripts**:
> - [`scripts/memory/sprint_close_hook.py`](../../scripts/memory/sprint_close_hook.py)
> - [`scripts/memory/generate_preflight_summary.py`](../../scripts/memory/generate_preflight_summary.py)
>
> **Tests**: [`tests/memory/`](../../tests/memory/) — 39 tests (schemas + 2 lifecycle modules + no-auto-uplink guard)
>
> **Fast-gate item**: F19 `Memory uplink smoke (v4.91 M-E B8)`
>
> **Invariant**: [`inv_010_no_auto_level_2_3_promotion`](../../runtime/protected_contracts/protected_regression_matrix.yaml)
>
> **Sister docs**: [`UPLINK_LEVEL_LADDER.md`](UPLINK_LEVEL_LADDER.md) · [`PROJECTION_CONTRACT.md`](PROJECTION_CONTRACT.md)

---

## 1. Why this directory exists

`docs/24_memory_sync/` is the Layer 1 adoption companion to the
memory sync / periodic uplink toolchain introduced in v4.91 M-E B8.
It documents:

- the **projection contract** (sprint-close envelope and finalized
  preflight case → JSON summary projections; pointer-only; what the
  scripts do NOT do) — see [`PROJECTION_CONTRACT.md`](PROJECTION_CONTRACT.md);
- the **uplink-level ladder** (level 1 routine / level 2 consequential /
  level 3 high-impact, with structural human-confirmation gates at the
  schema layer) — see [`UPLINK_LEVEL_LADDER.md`](UPLINK_LEVEL_LADDER.md).

The skill side (if and when added) lives under
`skills/_generic_core/orchestrator/`. Today only the OS-side
projection layer is shipped; the consumer that batches summaries
into uplink_record ledger entries is the responsibility of the
adopting host project.

## 2. Plain-English summary

When an adopting host project closes a sprint or finalises a
multi-agent preflight consensus, two things happen:

1. The host calls `scripts/memory/sprint_close_hook.py` (or
   `generate_preflight_summary.py`) with a JSON envelope describing
   the event.
2. The script projects the envelope into a schema-conformant
   `project_summary.json` (or `preflight_summary.json`) entry that
   lives under `.ai_dev_os/exports/summaries/` (or
   `.ai_dev_os/exports/preflight_summaries/`).

These summary files are **pointer records**: they reference closure
reports, evidence indexes, preflight cases by path, but they NEVER
embed the body. They are stamped with `source_layer: "L2"` (host
adoption tree) and an `audit_status` of `draft` by default.

A separate consumer (responsibility of the host project, not Core)
batches one or more summaries into a single `uplink_record.json`
ledger entry. The uplink_record schema enforces a 3-tier
human-confirmation ladder structurally:

- **Level 1** routine summary — auto-uplink permitted; no human
  confirmation required.
- **Level 2** consequential — requires `confirmed_by` +
  `confirmed_at` (schema-level allOf branch).
- **Level 3** high-impact — additionally requires non-empty
  `rationale` ≤ 1000 chars (schema-level allOf branch).

The Core toolchain refuses to ship escape hatches: there is no
`--apply` / `--auto-confirm` / `--force` / `--bypass` /
`--allow-extra` flag, anywhere. Drift toward such a flag is caught
at gate time by `inv_010_no_auto_level_2_3_promotion` and at
build time by `tests/memory/test_no_auto_uplink.py`.

## 3. Charter alignment (where each anti-pattern lands)

| # | Anti-pattern | Where enforced |
|---|---|---|
| 5 | Core does not bind to project narrative | `source_layer "L2"` const-locked on every memory schema; `project_id` opaque; sprint_id / case_id free-form. |
| 6 | No auto-promote into retrieval policy | Inv_010 must_preserve item-6 forbids any import of `retrieval_policy` / `promotion_policy` / `promote_memory_candidate` / `reject_memory_candidate` from `scripts/memory/`. |
| 7 | No escape hatches | No `--apply` / `--auto-confirm` / `--force` / `--skip-confirm` / `--bypass` / `--allow-extra` flags anywhere; the inv_010 trigger sweeps `scripts/memory/**` so any drift fires immediately. |
| 11 | Recording != closure-gate pass | F19 emits SHAPE evidence only; the synthetic envelope round-trip is the entire fast-gate assertion — no claim that an uplink completed. |
| 14 | No full release copy by default | `closure_report_ref` / `preflight_case_ref` / `event_ledger_ref` are POINTERS; `lessons[]` capped at 10×200 chars; `evidence_index[]` capped at 32 entries; `summary_refs[]` capped at 64 pointers — bodies never embed. |

## 4. Adoption checklist for a host project

A host project adopting the periodic-uplink stream should:

1. Pick an opaque `project_id` matching `^[a-z0-9_-]+$` and use it
   consistently across all summary entries.
2. Decide WHICH sprint outcomes / preflight events warrant which
   `uplink_level`:
   - Routine sprint closure with no cross-project impact → level 1.
   - Sprint closure or preflight outcome that affects shared
     contracts / cross-project memory → level 2 (named human
     reviewer required).
   - High-impact decision (architectural, security, EP-only) →
     level 3 (named reviewer + rationale).
3. Wire `sprint_close_hook.py` into the project's sprint closure
   workflow as a projection step. The script writes
   `.ai_dev_os/exports/summaries/<summary_id>.json` by default.
4. (Optional) Wire `generate_preflight_summary.py` into the
   project's preflight finalisation workflow. The script writes
   `.ai_dev_os/exports/preflight_summaries/<summary_id>.json`.
5. Build (or adopt, when one ships) an uplink consumer that batches
   summaries into `uplink_record.json` ledger entries. The
   schema-level allOf gate ensures level 2/3 entries CANNOT be
   minted without `confirmed_by` + `confirmed_at` (and rationale
   for level 3).
6. Treat `audit_status` lifecycle as append-only: `draft` →
   `recorded`; corrections via `withdrawn` (with `amends` pointing
   at the superseded summary). Never edit a recorded entry in place.

## 5. What NOT to do

- **Do NOT** put the `--auto-confirm` ergonomic on top of an
  uplink consumer. The schema's allOf branches and inv_010 will
  block it; the lint will catch it; the gate will refuse it.
- **Do NOT** embed the closure-report body or preflight-case body
  inside the summary. Summaries are pointers (Charter #14).
- **Do NOT** treat F19 PASS as evidence that an uplink succeeded.
  F19 is shape-only (Charter #11).
- **Do NOT** auto-promote summary signals back into the retrieval
  policy. The retrieval-policy / promotion-policy engines stay in
  `scripts/ltm/`; `scripts/memory/` is a one-way projection layer
  (Charter #6).

## 6. Operational cookbook

### 6.1 Project sprint close → project_summary

```bash
cat > /tmp/close.json <<'EOF'
{
  "sprint_id": "sprint-12",
  "project_id": "host-a",
  "outcome": "PASS",
  "captured_at": "2026-05-26T10:00:00Z",
  "uplink_level": 1,
  "headline": "Sprint 12 closed cleanly.",
  "lessons": ["respect the manifest sync canonical path"],
  "evidence_index": ["abc1234", "docs/sprint12.md"],
  "closure_report_ref": "docs/sprint12.md"
}
EOF

python3 scripts/memory/sprint_close_hook.py \
  --input /tmp/close.json \
  --out-dir .ai_dev_os/exports/summaries

# stdout: ps_<8hex>; file: .ai_dev_os/exports/summaries/ps_<8hex>.json
```

### 6.2 Preflight finalisation → preflight_summary

```bash
python3 scripts/memory/generate_preflight_summary.py \
  --case ltm/preflight/cases/pf_case_<id>.json \
  --metric ltm/preflight/metrics/pf_metric_<id>.json \
  --project-id host-a \
  --uplink-level 2 \
  --out-dir .ai_dev_os/exports/preflight_summaries

# stdout: pfs_<8hex>; file: .ai_dev_os/exports/preflight_summaries/pfs_<8hex>.json
```

### 6.3 Smoke from the gate

```bash
python3 scripts/governance/run_release_closure_gate.py --profile fast
# F19 -> '2/2 memory uplink smoke checks OK (3 schemas self-validate +
#         level-2 human-confirmation gate round-trip)'
# F6  -> '10/10 invariants enforced PASS'
```

## 7. Where to look next

- The Charter SSoT (`policies/charter_anti_patterns.md`) lists the
  full 15-pattern catalogue.
- Sister B8 docs:
  - [`UPLINK_LEVEL_LADDER.md`](UPLINK_LEVEL_LADDER.md)
  - [`PROJECTION_CONTRACT.md`](PROJECTION_CONTRACT.md)
- Adjacent invariants:
  - `inv_002_layer_1_no_project_names` — pins the 50-root lint.
  - `inv_009_no_auto_rollback_execution` — sister anti-escape-hatch
    contract for the recovery toolchain.
