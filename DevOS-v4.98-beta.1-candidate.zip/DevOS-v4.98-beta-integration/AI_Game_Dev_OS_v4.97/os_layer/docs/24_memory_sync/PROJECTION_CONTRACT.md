# Projection Contract — Memory Sync Scripts

> **Layer 1 (OS Spec).** v4.91 P5 / Milestone E B8.
>
> Sister docs: [`README.md`](README.md) · [`UPLINK_LEVEL_LADDER.md`](UPLINK_LEVEL_LADDER.md)

---

## 1. What the scripts ARE

`scripts/memory/sprint_close_hook.py` and
`scripts/memory/generate_preflight_summary.py` are **projection
layers**. Each one reads a host-side input (sprint-close envelope
or finalised preflight case), validates it, allocates a fresh
opaque `summary_id`, projects the input into the target
`schemas/memory/*.schema.json` shape, validates the OUTPUT, and
writes the JSON to a per-host adoption directory.

Both scripts are pure read-emit. They do not call any LTM engine,
they do not mutate retrieval policy, they do not append to
shared ledgers, they do not authorise rollbacks, they do not
perform host-side IO outside the explicit `--out` / `--out-dir`
target.

## 2. What the scripts ARE NOT

- They are NOT a memory engine. The capture API
  (`runtime.ltm.capture`) is unaffected by B8.
- They are NOT a consensus engine. Outcome / decided_by /
  rationale are READ-ONLY mirrored from the input case (Charter
  anti-pattern #12).
- They are NOT a gate. F19 emits SHAPE evidence only (Charter
  anti-pattern #11).
- They are NOT an uplink ledger writer. Batching summaries into
  `uplink_record` ledger entries is a separate consumer that the
  host project is responsible for.

## 3. Input contract — `sprint_close_hook.py`

The hook accepts a JSON envelope on `--input <path>` or `stdin`.
Required fields:

```
sprint_id    string, ≥1 char (opaque)
project_id   string, matches ^[a-z0-9_-]+$
outcome      string, one of: PASS / PASS_WITH_NOTE / FAIL /
                     DEFERRED / CANCELLED
captured_at  ISO-8601 UTC with trailing Z
```

Optional fields (when present, projected into the summary):

```
uplink_level         integer 1..3 (default 1)
headline             string ≤ 280 chars
lessons              array of strings, ≤ 10 entries, each ≤ 200 chars
evidence_index       array of pointers, ≤ 32 entries
closure_report_ref   string pointer or null
preflight_summary_ref string pointer or null
```

Output: `<out-dir>/ps_<8hex>.json`, conforming to
`project_summary.schema.json`. `summary_id` is printed to stdout.

`audit_status` defaults to `"draft"`; pass `--recorded` to promote
to `"recorded"`.

## 4. Input contract — `generate_preflight_summary.py`

The script accepts:

```
--case <path>        REQUIRED — path to a finalised preflight_case.json
                     (must validate against
                     schemas/ltm/preflight_case.schema.json)
--metric <path>      OPTIONAL — preflight_metric.json sibling
--project-id <id>    REQUIRED — opaque project namespace tag
--uplink-level N     OPTIONAL — 1, 2, or 3 (default 1)
--captured-at TS     OPTIONAL — ISO-8601 UTC; default = utcnow()
--recorded           OPTIONAL — emit audit_status="recorded"
--out <path>         OPTIONAL — output file
--out-dir <path>     OPTIONAL — output directory
```

Output: `<out-dir>/pfs_<8hex>.json`, conforming to
`preflight_summary.schema.json`. `summary_id` printed to stdout.

`outcome` / `decided_by` / `rationale` are READ-ONLY mirrored from
`case.consensus.{outcome,decided_by,rationale}`.
`consulted_role_count` / `elapsed_seconds` are READ-ONLY mirrored
from `metric.{consulted_role_count,elapsed_seconds}` when
`--metric` is supplied; otherwise they are `null`.

## 5. Exit code matrix (uniform for both scripts)

| Code | Meaning |
|------|---------|
| 0 | Success — summary written, `summary_id` on stdout. |
| 1 | Schema violation — output failed validation against the target schema. (Should not happen in practice; indicates an internal projection bug.) |
| 2 | Output write failed — permission / IO error reaching the target file. |
| 3 | Invalid input — missing required field, bad enum value, malformed `captured_at`, bad `project_id` regex, etc. |
| 4 | Input file missing / unreadable, or `--case` failed `preflight_case` schema validation. |

Adopting projects can rely on this matrix to wire CI / release
flows. The numeric semantics are stable; new failure modes will
take a fresh code, not reuse an existing one.

## 6. Forbidden flags

The following CLI flags MUST NEVER appear under
`scripts/memory/*.py`. The compile-time guard test
`tests/memory/test_no_auto_uplink.py::test_no_forbidden_flag_in_memory_scripts`
sweeps the source with a regex; the inv_010 must_preserve item-1
re-states the contract at the matrix layer.

```
--apply / --execute / --auto-apply
--auto-confirm / --skip-confirm
--force / --bypass / --allow-extra
```

## 7. Forbidden imports

The compile-time guard test
`tests/memory/test_no_auto_uplink.py::test_memory_scripts_do_not_import_policy_engines`
ensures no script under `scripts/memory/` imports any of:

- `retrieval_policy`
- `promotion_policy`
- `promote_memory_candidate`
- `reject_memory_candidate`

This is the structural enforcement of Charter anti-pattern #6 (no
auto-promote feedback into retrieval-policy boost / threshold
tunables).

## 8. Adoption note — pointer discipline

Every reference field in the three memory schemas is a POINTER:

- `closure_report_ref` (project_summary)
- `preflight_summary_ref` (project_summary)
- `preflight_case_ref` (preflight_summary; REQUIRED)
- `event_ledger_ref` (preflight_summary)
- `summary_refs[].ref` (uplink_record)

Adopting projects MUST treat these as references — relative paths
or opaque IDs that resolve at the host side — and MUST NOT embed
the referenced body. The schemas enforce this implicitly via:

- `lessons[]` capped at 10×200 chars (encourages summary, not
  transcript).
- `evidence_index[]` capped at 32 entries (encourages pointer
  list, not full evidence dump).
- `summary_refs[]` capped at 64 entries (encourages batched
  pointer, not unbounded archival).

## 9. Cross-references

- Schemas: `schemas/memory/{project_summary,preflight_summary,uplink_record}.schema.json`
- Scripts: `scripts/memory/{sprint_close_hook,generate_preflight_summary}.py`
- Tests: `tests/memory/{test_schemas,test_sprint_close_hook,test_generate_preflight_summary,test_no_auto_uplink}.py`
- Invariant: `inv_010_no_auto_level_2_3_promotion`
- Fast-gate item: F19 `Memory uplink smoke (v4.91 M-E B8)`
