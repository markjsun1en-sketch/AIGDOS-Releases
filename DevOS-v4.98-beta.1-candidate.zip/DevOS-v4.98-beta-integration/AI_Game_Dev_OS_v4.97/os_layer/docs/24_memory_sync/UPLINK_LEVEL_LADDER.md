# Uplink Level Ladder — Contract Reference

> **Layer 1 (OS Spec).** v4.91 P5 / Milestone E B8.
>
> Sister docs: [`README.md`](README.md) · [`PROJECTION_CONTRACT.md`](PROJECTION_CONTRACT.md)

---

## 1. The 3-tier ladder

`uplink_record.uplink_level` and `project_summary.uplink_level` /
`preflight_summary.uplink_level` are integers in the closed range
`1..3`. The schema enforces `minimum: 1`, `maximum: 3` — there is
no level 0 (placeholder) and no level 4 (escalation tier). Adding
a level is a contract change requiring EP + matrix-owner approval.

| Level | Name | When to use | Required by schema (allOf) |
|-------|------|-------------|----------------------------|
| 1 | routine summary | Sprint closures with project-local impact only; preflight outcomes that touch only project-local contracts. | (no extra fields) |
| 2 | consequential | Decisions or outcomes that affect cross-project shared contracts (LTM, mount semantics, version lock policy). | `confirmed_by` + `confirmed_at` |
| 3 | high-impact | EP-tier decisions; security-sensitive changes; architectural pivots; anything that becomes part of the v4.91 charter or supersedes a permanent contract. | `confirmed_by` + `confirmed_at` + non-empty `rationale` ≤ 1000 chars |

## 2. Schema-level enforcement

The `uplink_record.schema.json` `allOf` branches make the
human-confirmation contract STRUCTURAL — there is no path through
the schema that admits an unconfirmed level-2 or unrationalised
level-3 entry. The smoke item F19 round-trips both branches at
gate time:

- (positive) level-2 envelope WITH `confirmed_by` + `confirmed_at`
  MUST validate.
- (negative) level-2 envelope WITHOUT them MUST be rejected by the
  schema. If the gate ever reports the negative branch as
  validating, that is the inv_010 escape-hatch detector firing.

## 3. Decision rubric — which level to pick

When a host project drafts a summary, ask:

1. Does the outcome change anything outside the project's own
   adoption tree?
   - **No** → level 1.
   - **Yes** → continue.
2. Could another project legitimately rely on this outcome to make
   its own decision?
   - **No** → level 1 may still be appropriate.
   - **Yes** → level 2 minimum.
3. Does the outcome touch a permanent contract (charter
   anti-pattern, byte-lock invariant, schema_version const,
   mount-mode enum, etc.)?
   - **No** → level 2.
   - **Yes** → level 3.

Erring high is permitted — level 3 is more expensive (rationale
required) but never wrong. Erring low is what the gate is designed
to catch: an under-classified decision that turns out to be
load-bearing for cross-project consumers.

## 4. Anti-pattern reminders

- **No auto-confirm.** Charter #7. There is no `--auto-confirm`
  flag and no `--skip-confirm` flag in `scripts/memory/`; adding
  one trips inv_010 and the F19 round-trip at the next gate run.
- **No threshold tunable.** Charter #6. The level is set by the
  human author of the summary; it is NEVER computed from a
  numerical threshold or evidence count — that would create the
  exact auto-promote feedback the charter forbids.
- **No retroactive demotion.** Once a summary is `recorded` at
  level 3, demoting it to level 1 requires going through the
  `withdrawn` lifecycle and minting a fresh summary at the new
  level (with `amends` pointing back). This keeps the audit trail
  monotonic.

## 5. Ledger semantics

The `uplink_record` schema's `audit_status` is a 3-enum closed at
`recorded` / `withdrawn` / `superseded`. The `amends` field is
required iff `audit_status` is in `{withdrawn, superseded}` and
forbidden when `audit_status == "recorded"`. This mirrors the
recovery `checkpoint_manifest.audit_status` semantics from M-D for
consistency.

## 6. Cross-references

- Schema source: `schemas/memory/uplink_record.schema.json`
- Invariant: `runtime/protected_contracts/protected_regression_matrix.yaml` → `inv_010_no_auto_level_2_3_promotion`
- Fast-gate item: F19 (in `scripts/governance/run_release_closure_gate.py::_f19_memory_uplink_smoke`)
- Compile-time guard tests: `tests/memory/test_no_auto_uplink.py`
