# AI_Game_Dev_OS v4.87 MCP Adapter Contract

## 1. Purpose

This document defines, for the Tier2 Run Baseline of AI Game Dev OS v4.87, the MCP / Adapter interface contract. It is the unified boundary layer between Runtime Core, Governance Closure, Context Governance, and external systems.

The goal is not to cover every possible MCP or external integration in one pass; it is to establish an adapter layer for v4.87 that is:

- extensible
- replaceable
- governable
- writeback-capable
- non-polluting to Runtime Core

---

## 2. Scope

This document covers:

- Positioning of the MCP / Adapter Layer
- External-system integration boundary
- Unified input/output contract
- Event intake and action dispatch
- Adapter responsibilities and non-responsibilities
- How writeback, reconciliation, and exception escalation connect
- Adapter-category recommendations

This document does not cover:

- Any specific Jira / TAPD / Git / Unity / Godot connector implementation
- Concrete SDK / API code
- Enterprise-grade permission models in detail
- Full UI-productisation design

---

## 3. Design Positioning

In v4.87 the MCP / Adapter Layer is positioned as:

**Safely and controllably mapping external-system events, states, artifacts, and capabilities onto the AI Game Dev OS Runtime Object Model and Governance Closure.**

It is not:

- A replacement for Runtime Core
- A replacement for Registry
- A mirror layer of Jira/TAPD/Git
- A "universal chat agent" layer

It serves as:

**The boundary layer between external capability intake and the internal runtime.**

---

## 4. Core Goals

### 4.1 Decouple the runtime from external systems
The Runtime Object Model must not be reverse-shaped by any specific platform.

### 4.2 Standardise event input
Webhook / API / MCP-tool outputs from different platforms must first be normalised before entering Registry / Reconciliation.

### 4.3 Standardise action output
Internally initiated writebacks, sync calls, state updates, build triggers, evidence pulls, etc. must go out through the unified adapter contract.

### 4.4 Auditable
Every critical writeback, auto-repair, and external-state sync must be traceable to source and result.

### 4.5 Replaceable
No Adapter may be coupled to the internal object model so tightly that it becomes irreplaceable.

---

## 5. Layer Placement

Recommended stack:

1. **Runtime Core**
   - object model
   - state machine
   - registry / snapshot

2. **Governance Layer**
   - reconciliation
   - exception model
   - escalation / repair

3. **MCP / Adapter Layer**
   - external event intake
   - external action dispatch
   - platform-specific mapping

4. **External Systems**
   - Jira / TAPD
   - Git / PR / Repo
   - Build / Test
   - Engine / Editor
   - Dashboard / Docs / Storage

The MCP / Adapter Layer sits between the internal governance layer and external systems. It must not bubble up and contaminate Runtime Core.

---

## 6. Adapter Categories

v4.87 suggests organising adapters into these categories:

### 6.1 Work Tracking Adapters
For Jira / TAPD / task-system integration.

Typical responsibilities:
- Pull issue / story / task state
- Receive webhook events
- Write back state / comments / labels / related links

### 6.2 Code & SCM Adapters
For Git / PR / branch / commit / merge state.

Typical responsibilities:
- Pull branches, commits, and PR/MR state
- Fetch associated artifacts
- Write links back into the task system or the Registry ref layer

### 6.3 Build & Validation Adapters
For CI / build / test / artifact / logs.

Typical responsibilities:
- Fetch build / test results
- Pull reports, logs, artifacts
- Produce validation_evidence inputs

### 6.4 Engine / Editor Adapters
For Unity / Godot / UE / tool-editor environments.

Typical responsibilities:
- Execute controlled editor actions
- Read project state
- Provide scene / prefab / resource / node-level artifact references

### 6.5 Storage / Knowledge Adapters
For docs, archives, filesystem, knowledge bases, RAG sources.

Typical responsibilities:
- Pull document or archive content
- Write snapshot / archive / memory artifacts

### 6.6 Reporting / Dashboard Adapters
For exporting governance views such as readiness, reconciliation, sprint summary.

---

## 7. Adapter Core Responsibilities

Every Adapter carries at least these responsibilities:

### 7.1 Intake
Convert external events or query results into normalised input consumable internally.

### 7.2 Mapping
Align external objects with internal Runtime Objects / refs.

### 7.3 Validation
Basic legality checks on the input data.

### 7.4 Dispatch
Execute external actions requested internally.

### 7.5 Traceability
Record action source, object, timestamp, and result.

---

## 8. Adapter Non-Responsibilities

Adapters must not:

- Directly decide whether a feature is ACCEPTED
- Bypass the Runtime State Machine and overwrite registry truth
- Replace governance exception classification
- Produce long-form natural-language summaries as the sole output
- Perform large-scale external bulk modifications without guardrails

These belong to Runtime Core / Governance / Approval Rules.

---

## 9. Standard Input Contract

Every input originating from external systems should first be converted into a unified `adapter_input_event` structure.

Recommended minimum fields:

- `event_id`
- `adapter_type`
- `adapter_name`
- `event_type`
- `source_system`
- `source_object_type`
- `source_object_id`
- `source_timestamp`
- `payload`
- `related_refs`
- `ingested_at`

Notes:

- `event_type`: e.g. `issue.updated`, `pr.merged`, `build.failed`
- `payload`: preserves required original fields after normalisation
- `related_refs`: may carry some already-known internal references upfront

---

## 10. Standard Output Contract

Actions dispatched from inside to outside should be unified into an `adapter_action_request` structure.

Recommended minimum fields:

- `action_id`
- `adapter_type`
- `adapter_name`
- `action_type`
- `target_system`
- `target_object_type`
- `target_object_id`
- `request_payload`
- `requested_by`
- `requested_from_object_refs`
- `requested_at`
- `approval_context`

Notes:

- `action_type`: e.g. `update_status`, `post_comment`, `create_link`, `trigger_build`
- `approval_context`: marks whether the action was auto-permitted, governance-permitted, or human-approved

---

## 11. Mapping Rules

Every Adapter must obey these mapping principles:

### 11.1 External objects do not equal internal objects
For example:
- A Jira Story is not automatically a feature
- A Jira Task is not automatically a task
- A Git PR is not automatically feature completion
- Build Success is not automatically acceptance

### 11.2 Mapping must pass through the rules layer
Incoming external objects must first go through:
- adapter mapping
- reconciliation
- state-transition guardrails

### 11.3 Support one-to-many and many-to-one
Examples:
- A feature may correspond to several external tasks
- One external epic may map to several features
- One issue may impact several tasks

Therefore the mapping layer should use refs — do not assume strict one-to-one mapping.

---

## 12. Event Intake Rules

### 12.1 Event-driven first
Prefer webhook / event / MCP action-result as the primary trigger path.

### 12.2 Query-pull as backup
Where webhooks are unreliable or cannot provide full context, fill in with pull/query.

### 12.3 Events do not rewrite the Registry on arrival
On arrival an event must:
1. be normalised
2. be mapped to internal refs
3. undergo reconciliation
4. be classified as an exception or produce a candidate state
5. pass the rules layer before any writeback

---

## 13. Action Dispatch Rules

### 13.1 Every internal action must have a source
Every outbound action must be traceable to:
- A runtime object
- A governance rule
- A human approval
- An auto-repair event

### 13.2 High-risk actions require approval context
The following must not be auto-executed without guardrails:
- Large-scale state bulk modifications
- Object deletion / archival
- Creation of many external tickets
- Modification of key fields in external systems
- Writes that may shift responsibility attribution

### 13.3 Failures must be reportable upstream
On failure, the adapter should produce:
- An adapter result
- Optionally an issue / exception
- Optionally an escalation

---

## 14. Adapter Result Contract

After handling an event or executing an action, every Adapter should emit a uniform `adapter_result`:

Minimum fields:

- `result_id`
- `adapter_name`
- `source_event_or_action_id`
- `result_type`
- `status`
- `affected_refs`
- `notes`
- `raw_refs`
- `created_at`

Where:
- `status` may be `success / partial / failed / blocked`
- `affected_refs` links to objects such as issue, task, validation_evidence, escalation

---

## 15. Governance Integration

The Adapter Layer must cooperate with the governance closure — not evolve in parallel to it.

### 15.1 Cooperate with Reconciliation
Once an external state change arrives, it must first feed `Governance Reconciliation`.

### 15.2 Cooperate with the Exception Model
When external input conflicts with internal state, the Adapter must not decide the outcome — the `Exception Model` classifies it.

### 15.3 Cooperate with Escalation / Repair
High-risk conflicts or mapping failures must be able to trigger an escalation or a repair candidate.

---

## 16. Registry Integration

Adapters are not the Registry.

The correct flow is:

**External Event / Query -> Adapter Input Event -> Reconciliation / Governance -> State Candidate / Validation Evidence / Exception -> Registry Update**

Therefore:

- An Adapter may supply a candidate state
- An Adapter may supply evidence references
- An Adapter may supply mapping information
- An Adapter must not act as a truth-writer without going through the governance step

---

## 17. Context Governance Integration

Adapter output must not flow raw and whole into the active context.

Recommended approach:

- Raw payload → archive / trace log
- Refined structured result → registry / evidence / issue / snapshot
- Only high-value summaries → active context pack

This prevents:
- External-system noise polluting the context
- Webhook / build / PR details hogging the token budget

---

## 18. Suggested Adapter Interface Skeleton

Each Adapter is recommended to implement at least these logical methods:

- `normalize_input(event_or_payload)`
- `map_to_internal_refs(normalized_input)`
- `validate_input(normalized_input)`
- `produce_candidates(normalized_input)`
- `dispatch_action(action_request)`
- `format_result(result)`

This is not a hard signature, but it is recommended as the unified interface idea for v4.87 script scaffolds.

---

## 19. Initial v4.87 Priority Adapters

v4.87 suggests reserving or implementing these four categories first:

### P0
- Work Tracking Adapter (Jira / TAPD)
- Code & SCM Adapter (Git / PR / Repo)

### P1
- Build & Validation Adapter
- Storage / Archive Adapter

### P2
- Engine / Editor Adapter
- Reporting / Dashboard Adapter

---

## 20. Minimal File / Module Layout Suggestion

The following layout is recommended for v4.87:

```text
adapters/
  common/
    adapter_contract.py
    adapter_types.py
    adapter_result.py
  work_tracking/
    jira_adapter.py
    tapd_adapter.py
  scm/
    git_adapter.py
  build/
    ci_adapter.py
  storage/
    archive_adapter.py
  engine/
    unity_adapter.py
    godot_adapter.py
```

Even if not every file is implemented yet, the directory layout and the contract-doc placeholder should be reserved up front.

---

## 21. Non-Goals for v4.87

v4.87 does not try to:

- Deliver a complete MCP platform
- Cover every external system in one pass
- Enable fully automated external writeback without rules or audit
- Let the Adapter layer become a new super-orchestrator

The position of v4.87 is:

**Nail the boundary and unified contract of the Adapter Layer, so that later MCP / Integration / Platformisation work has a stable interface to plug into.**

---

## 22. Acceptance Criteria

This document is adoptable if and only if:

1. The MCP / Adapter Layer is clearly positioned and does not blur into Runtime Core duties.
2. How external input enters internal governance is explicit.
3. How internal actions pass through approval context before going out is explicit.
4. Adapters are explicitly forbidden from deciding internal truth directly.
5. At least one unified set of input/output/result contracts is defined.
6. v4.87 priority integration directions and a module scaffold are given.

---

## 23. Final Positioning

`AI_Game_Dev_OS_v4.87_MCP_Adapter_Contract` is the interface-layer specification within v4.87 Batch 4.

It answers:

- How external systems plug into AI Game Dev OS
- Where those integrations should stop on the inside
- What may flow automatically and what must go through governance
- How to leave a stable interface for later MCP and cross-system platformisation

On that basis, the next recommended document is:

**`AI_Game_Dev_OS_v4.87_Starter_and_Adaptation_Rules.md`**

defining:

- How the Run Baseline onboards a new project
- How Starter / Pack / Adaptation plug into v4.87
- Which parts belong to the runtime layer and which belong to the project layer
