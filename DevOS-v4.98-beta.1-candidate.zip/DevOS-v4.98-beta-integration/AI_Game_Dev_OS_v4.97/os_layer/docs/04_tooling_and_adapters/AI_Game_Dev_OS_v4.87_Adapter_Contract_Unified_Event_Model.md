# AI Game Dev OS v4.87 Adapter Contract and Unified Event Model

## Event examples
- task_claimed_done
- issue_escalated
- validation_evidence_added
- snapshot_generated
- sprint_close_blocked
- reconcile_pending

## Boundary rule
External systems emit signals and candidate mappings; they do not directly rewrite accepted internal truth.
