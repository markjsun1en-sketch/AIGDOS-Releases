# RETRIEVAL_ROUTING_v2 — LTM Routing Configuration (v4.90 Batch 8)

> **Status**: shipped 2026-05-13 (Batch 8 closure).
> **Config**: `config/memory_retrieval_routing_v2.yaml`
> **Schema**: `schemas/ltm/memory_retrieval_routing.schema.json` (0.1.0-beta)
> **Predecessor**: `config/memory_retrieval_policy.yaml` (v4.89; **kept, additive**)

---

## 1. What the v2 routing config governs

A single source of truth for three retrieval-time decisions:

1. **Priority**: when `consult()` merges hits across multiple domains, which order should they sort by?
2. **Namespace**: which entries are visible to a project-scoped query (`global` / `per_project` / `per_project_or_global` / `session_local`)?
3. **Default exclusion**: which domains never participate in `consult()` unless the caller explicitly opts in?

The v4.89 `memory_retrieval_policy.yaml` covered consumption rules (e.g. `experience_memory_usage_rules`, `canonical_override_block`). v2 is **strictly additive** — it adds the ordering layer; legacy consumption rules continue to apply on top.

---

## 2. Shipped values (config/memory_retrieval_routing_v2.yaml)

```yaml
schema_version: "0.1.0-beta"
version: "2.0"

priority_matrix:
  - domain: os               # priority 1 — OS Core wins ties
    priority: 1
    namespace: global
  - domain: pattern          # priority 2
    priority: 2
    namespace: global
  - domain: cross_project    # priority 3
    priority: 3
    namespace: global
  - domain: failures         # priority 4
    priority: 4
    namespace: per_project_or_global
  - domain: project          # priority 5 — last canonical layer
    priority: 5
    namespace: per_project
  - domain: working          # priority 6 — opt-in only
    priority: 6
    namespace: session_local
  - domain: _quarantine      # priority 7 — opt-in only
    priority: 7
    namespace: global

default_excluded:
  - working
  - _quarantine
```

Priorities **must be unique** (enforced by Step 8.7 unit test). Lower integer = higher precedence.

---

## 3. Namespace semantics

| Namespace | Meaning |
|---|---|
| `global` | Entry is in scope for every consult() call regardless of `project_id`. |
| `per_project` | Entry is in scope only when `consult(project_id=X)` matches the entry's `project_id` tag. |
| `per_project_or_global` | Entry is in scope when (a) the project_id matches, OR (b) the entry has no `project_id` tag (treated as global; preserves the v4.89 "missing ≡ global" rule). |
| `session_local` | Entry is **not** auto-discovered — caller must pass an explicit `domain="working"` kwarg. |

---

## 4. Default exclusion contract

Domains in `default_excluded` are dropped from any `consult()` call that does not specify `domain=`. This prevents:

- `working/` raw notes from polluting canonical retrieval (they're pre-validation by definition).
- `_quarantine/` candidates from being read as if they were canonical.

Both are still readable; callers just have to opt in:

```python
from runtime.ltm import consult
hits = consult("envelope drift", domain="working")    # explicit opt-in
```

---

## 5. Schema highlights

`schemas/ltm/memory_retrieval_routing.schema.json` enforces:

- `schema_version` const `0.1.0-beta` (Q5 — Batch 12.2 unify-promotes to 1.0.0).
- `version` follows `MAJOR.MINOR[.PATCH]`.
- `priority_matrix.items.domain` is one of the 7 enumerated v4.90 domains.
- `priority_matrix.items.priority` is integer ≥ 1.
- `priority_matrix.items.namespace` is one of the 4 enumerated namespace values.
- `default_excluded` is a uniqueItems array of domain enum values.
- `additionalProperties: false` at the top level.

Self-validation by `tests/ltm/test_memory_retrieval_routing.py` covers schema-validity, yaml-validity, priority uniqueness, 7-domain coverage, default_excluded coverage, documented order, and namespace enum coverage.

---

## 6. Consumer status (intentional non-coupling)

`runtime/ltm/consult.py` (frozen since v4.89) **does not yet** read this config — by design. The Batch 8 deliverable is the contract; the runtime switch happens later:

- **Batch 11 (CLI Wrapper)** registered `ai-dev-os ltm consult` as a STUB (returns `EXIT_INTERNAL_ERROR=3` with a pointer back to this section). The real `--routing-config` enforcement path with v2 routing is deferred to Batch 12 / v4.91.
- After that, future batches may move runtime/ltm to read v2 directly without breaking the v4.89 frozen API.

This staging keeps Batch 8 a pure-additive change for v4.89 consumers.

---

## 7. Migration from v4.89 retrieval_policy

The legacy `config/memory_retrieval_policy.yaml` (v4.89) carries:
- `memory_domains` flat list (4 domains)
- `retrieval_priority` (canonical | retrieval | experience)
- `canonical_override_block: true`
- `experience_memory_usage_rules`
- `failure_fix_memory_usage_rules`

None of those are touched by v2. v2 augments the **ordering** decision; v4.89 governs the **consumption** rules. Both files coexist; future cleanup may merge or fold v4.89 fields into v2's `notes` block, but that is out of Batch 8 scope.

---

## 8. References

- `config/memory_retrieval_routing_v2.yaml`
- `schemas/ltm/memory_retrieval_routing.schema.json`
- `tests/ltm/test_memory_retrieval_routing.py`
- `docs/15_ltm_v2/MEMORY_DOMAINS_v2.md`
- v4.89 legacy: `config/memory_retrieval_policy.yaml`
