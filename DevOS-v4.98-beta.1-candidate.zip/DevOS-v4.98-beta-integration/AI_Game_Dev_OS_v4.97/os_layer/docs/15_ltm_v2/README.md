# 15 — LTM v2 (Long-Term Memory v2)

> **v4.90 Batch 4 — P0-3 LTM v2 + Failure-Fix Memory**
> **Status**: Layer B + Failure-Fix formalisation + sprint_close hook spec
> **Layer 1 (OS Spec)** — no project names

## Purpose

LTM v1 (Layer A) shipped with v4.89 Phase 2 — see `ltm/INDEX.md` for the
five domains, the `consult / capture` API, the 5-rule Gate, and the
`project_id` namespace (M9.5). The runtime engine in
`runtime/ltm/{capture,consult}.py` is **kept as-is** in v4.90; nothing
in this module breaks Layer A bit-compatibility.

LTM v2 adds three things on top of Layer A:

1. **Failure-Fix Memory schema formalisation** — a JSON Schema that
   declares the field shape every Failure-Fix entry should follow (the
   six v4.89-shipped entries already follow this shape de-facto; v4.90
   makes it explicit and lintable).
2. **Layer B retrieval upgrade (FTS5)** — opt-in SQLite FTS5 full-text
   ranking on top of the current substring matcher; falls back
   automatically when FTS5 is unavailable. **API-compatible: zero
   existing tests break.**
3. **`sprint_close → capture` hook spec + GUIDED implementation** —
   interface definition (`SPRINT_CLOSE_CAPTURE_HOOK.md`) plus the
   real Python implementation (`scripts/ltm/capture_sprint_close.py`,
   GUIDED tier as of Batch 5.5 Step 5.5.1) so adopting projects can
   wire their sprint closure flow into LTM Project domain captures
   without re-deriving the contract per project.

## What is NOT in v4.90 Batch 4

- **Layer C (Self-Evolution)** — proposal-only, sits in Batch 6.
- **Vector retrieval** — explicitly not in v4.90 (deferred to v4.91+).
- **Auto-merge across projects** — explicitly out of scope.
- **Modifying `runtime/ltm/capture.py` Gate rules** — Layer A engine is
  frozen; new validation runs offline via `scripts/ltm/validate_*.py`.

## Two-layer discipline (CRITICAL)

```text
┌─────────────────────────────────────────────────────────┐
│ Layer 1 — OS Spec (this directory)                      │
│   - Generic ff schema / Layer B retrieval / hook spec   │
│   - NO project names anywhere                            │
│   - Enforced by scripts/governance/lint_layer_separation │
└─────────────────────────────────────────────────────────┘
                         ↓ instantiated by
┌─────────────────────────────────────────────────────────┐
│ Layer 2 — Project Migration / Failure cases             │
│   - Project names ALLOWED                                │
│   - File pattern: STATE_SURFACE_MIGRATION_CASE_*.md      │
│                   ltm/failures/<date>_<id>_<slug>.md     │
│                   when the entry references a project case │
└─────────────────────────────────────────────────────────┘
```

`ltm/failures/` entries themselves are **Layer 1** (under `ltm/`, not
under one of the 8 governance / migration roots) **but** their
`evidence_ref` may point to a Layer 2 case-study file when the failure
description draws from real-project evidence. The seed entry
`ff_2026_001` is the canonical example:
- entry body uses generic placeholders (`<project>`)
- `evidence_ref: docs/14_state_surface_governance/STATE_SURFACE_MIGRATION_CASE_SP115.md`

## Documents in this directory

| File | Layer | Status |
|---|---|---|
| `README.md` (this file) | 1 | GUIDED |
| `LAYER_B_OVERVIEW.md` | 1 | GUIDED — FTS5 design + opt-in fallback contract |
| `FAILURE_FIX_SCHEMA_RULES.md` | 1 | GUIDED — required vs optional fields, validator usage |
| `SPRINT_CLOSE_CAPTURE_HOOK.md` | 1 | GUIDED — spec + implementation reference |

## Related schemas (`schemas/ltm/`)

| Schema | Validates |
|---|---|
| `failure_fix_memory.schema.json` | Failure-Fix entry front-matter + section presence |
| `sprint_close_capture_input.schema.json` | sprint_close hook input envelope |

## Related scripts (`scripts/ltm/`)

| Script | Tier | Purpose |
|---|---|---|
| `validate_failure_fix_entry.py` | GUIDED | Lint one or more `ltm/failures/*.md` against the schema |
| `capture_sprint_close.py` | GUIDED (Batch 5.5 Step 5.5.1; exit 0/1/2/3/4) | Project-side sprint_close → ltm/project capture; reads schema-validated envelope, calls runtime.ltm.capture(domain='project') |

## Cross-references

- `ltm/INDEX.md` — Layer A INDEX (consult / capture / domains / Gate)
- `runtime/ltm/{capture,consult}.py` — Layer A engine (frozen in v4.90)
- `docs/13_migration/` — Progressive Adoption (sister module)
- `docs/14_state_surface_governance/` — State Surface Governance (sister module)
- `docs/14_state_surface_governance/STATE_SURFACE_MIGRATION_CASE_SP115.md` — first Layer 2 case (referenced by `ff_2026_001`)

## v4.90 roadmap

```
Batch 4 Step 4.1   docs/15_ltm_v2/ skeleton                 ✅ closed (31a94a2)
Batch 4 Step 4.2   ff schema + validate_failure_fix_entry GUIDED  ✅ closed (711d741)
Batch 4 Step 4.3   ff_2026_001 seed entry (consumes Layer 2 case) ✅ closed (0096318)
Batch 4 Step 4.4   sprint_close hook spec + STUB script     ✅ closed (lifted to GUIDED in Batch 5.5 Step 5.5.1)
Batch 4 Step 4.5   Layer B FTS5 retrieval (opt-in fallback) ✅ closed (a290e00 / d7c808f / 609130b)
Batch 4 Step 4.6   Batch 4 closure                          ⏳ in progress
```
