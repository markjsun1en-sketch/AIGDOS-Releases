# PROMOTION_WORKFLOW — LTM v2 Promotion Pipeline (v4.90 Batch 8)

> **Status**: shipped 2026-05-13 (Batch 8 closure).
> **Pipeline scripts**: `scripts/ltm/extract_failure_candidates.py` (Step 8.4) + `scripts/ltm/promote_memory_candidate.py` (Step 8.5).
> **Schemas involved**: `memory_candidate.schema.json` (envelope), `failure_fix_memory.schema.json` (target), `memory_quality_report.schema.json` (post-promote audit).

---

## 1. Overview

```
ltm/working/<note>.md
        │
        │  scripts/ltm/extract_failure_candidates.py
        │      --from ltm/working/  --out ltm/_quarantine/
        ▼
ltm/_quarantine/mc_YYYY_NNN.json   ← memory_candidate envelope, gate-pending
        │
        │  scripts/ltm/promote_memory_candidate.py
        │      --candidate <mc.json>  --to <domain>  --approver <id>
        ▼
ltm/<domain>/<date>_<ff_id_or_slug>.md   ← canonical entry
        │
        │  scripts/ltm/validate_memory_quality.py
        │      --dir ltm/<domain>
        ▼
mqr_YYYY_MM_DD_<domain> report (audit; informational unless CI fails on errors)
```

Each arrow is a separate, idempotent script invocation. Nothing auto-runs.

---

## 2. Stage 1 — Extract (working/ → _quarantine/)

**Script**: `scripts/ltm/extract_failure_candidates.py` (GUIDED, Batch 8 Step 8.4).

**Inputs**:
- `--from <dir>` — typically `ltm/working/`
- `--out <dir>` — typically `ltm/_quarantine/`
- `--dry-run` — no writes
- `--format text|json`

**Behaviour**:
1. Globs `*.md` under `--from` (skips `README.md`).
2. Parses YAML front-matter via the zero-dep `_yaml_subset` parser. Notes without front-matter still produce envelopes (the gate is enforced at promote, not extract).
3. Allocates the next sequential `mc_YYYY_NNN` id (scans existing envelopes in `--out`).
4. Coerces `evidence_ref` (list / string / missing → list with sane fallback).
5. Writes `<out>/<candidate_id>.json` conforming to `memory_candidate.schema.json` with `target_domain="failures"`, `approver=null`.

**Exit codes**: 0 (≥1 envelope), 1 (input shape error), 4 (no .md files / missing dir).

---

## 3. Stage 2 — Promote (_quarantine/ → canonical)

**Script**: `scripts/ltm/promote_memory_candidate.py` (GUIDED, Batch 8 Step 8.5).

**Inputs**:
- `--candidate <mc.json>` — single envelope file
- `--to <failures|pattern|os|cross_project|project>` — target domain
- `--approver <id>` — non-empty approver string
- `--ltm-root <dir>` — defaults to `<v4.90>/ltm/`
- `--format text|json`

### Gate (G1–G5)

| ID | Rule |
|---|---|
| **G1** | `--approver` is non-empty AND candidate's `target_domain` matches `--to`. |
| **G2** | `evidence_ref` is a non-empty list. |
| **G3** | `--to cross_project` requires **≥ 2 unique** `evidence_ref` entries. |
| **G4** | `proposed_entry` validates against the target domain's schema (currently strict only for `failures/`, via the shared `validate_failure_fix_entry.validate_front_matter`). |
| **G5** | `--to failures` requires `proposed_body` (string) containing all four required H2 sections: `## Symptom` / `## Root Cause` / `## Fix` / `## Lesson`. |

### On clear gate

1. Renders `<ltm_root>/<domain>/<date>_<ff_id_or_slug>.md` with stable-ordered YAML front-matter + the supplied body.
2. Stamps `approver` into the candidate envelope on disk (so re-running is a no-op).
3. Writes a sibling `<candidate>.promoted.json` ledger entry: `{candidate_id, promoted_to, promoted_at, approver, canonical_path}`.

### Idempotency

If the candidate's `approver` is already non-null, the script exits 0 with `already promoted` — no canonical re-write, no double-stamp.

### Exit codes
0 (promoted or no-op), 1 (gate violation), 2 (target domain dir missing), 3 (internal), 4 (--candidate missing).

---

## 4. Stage 3 — Quality audit

After promotion, run `validate_memory_quality.py --dir ltm/<domain>` to confirm the new canonical entry passes the shared quality rules (see `MEMORY_QUALITY_GATE.md`). Output is a `memory_quality_report.schema.json`-conforming JSON, suitable for CI aggregation.

---

## 5. Adopting the pipeline

A typical session-end flow looks like:

```bash
# 1. Drop a raw note while working
$EDITOR ltm/working/2026-05-13_envelope_drift.md   # write Symptom/Cause/Fix/Lesson loosely

# 2. Extract into _quarantine
python3 scripts/ltm/extract_failure_candidates.py \
    --from ltm/working/ --out ltm/_quarantine/

# 3. Review the envelope, fill in proposed_body if needed, then promote
python3 scripts/ltm/promote_memory_candidate.py \
    --candidate ltm/_quarantine/mc_2026_004.json \
    --to failures --approver kai

# 4. Audit
python3 scripts/ltm/validate_memory_quality.py --dir ltm/failures --format json
```

As of v4.90 Batch 11 these four steps collapse to `ai-dev-os ltm extract`, `ai-dev-os ltm promote`, and `ai-dev-os ltm quality` (plus the existing `ai-dev-os ltm capture` and `ai-dev-os ltm validate-ff`).

---

## 6. What the pipeline does NOT do

Aligned with the `Self-Evolution proposal-only` discipline (Q4 in COMPLETE_PLAN):

- It does **not** auto-promote on extract. Every promotion needs an approver string.
- It does **not** auto-modify canonical OS Core files. Only ltm/<domain>/ entries are written.
- It does **not** mutate the runtime engine (`runtime/ltm/`). Read/write APIs from v4.89 remain frozen.

---

## 7. References

- `scripts/ltm/extract_failure_candidates.py`
- `scripts/ltm/promote_memory_candidate.py`
- `scripts/ltm/validate_memory_quality.py`
- `schemas/ltm/memory_candidate.schema.json`
- `docs/15_ltm_v2/MEMORY_DOMAINS_v2.md`
- `docs/15_ltm_v2/MEMORY_QUALITY_GATE.md`
