# LTM Layer B — Retrieval Upgrade (FTS5 with Opt-In Fallback)

> **v4.90 Batch 4 Module C**
> **Layer 1 (OS Spec)** — no project names
> **Status**: GUIDED — designed for ZERO test breakage from Layer A

## Background

LTM Layer A retrieval (`runtime/ltm/consult.py`, shipped v4.89 Phase 2)
is a substring matcher over title + body content of every entry under
`ltm/`. It is correct, deterministic, and has 4 passing tests
(`tests/test_ltm_{capture,consult,integration,namespace}.py`).

What Layer A cannot do:
- Rank results by relevance (it returns by file order)
- Tokenize multi-word queries with Boolean / phrase semantics
- Scale beyond ~hundreds of entries without per-query re-scan

Layer B addresses these via SQLite FTS5 — a virtual table extension
that ships with most modern Python distributions (CPython on macOS /
recent Linux / Windows wheels). FTS5 is **not** universally available
(some Linux distro packages, embedded Python builds, Alpine images may
ship sqlite without FTS5).

## Design constraint: zero test regression

The single hardest constraint of Layer B is **API compatibility with
Layer A**. The 4 existing LTM tests are the contract — any change that
flips a `passed` to `failed` is a Layer B design failure, not a test
failure.

To enforce this, the public `consult(...)` signature only **adds** a
keyword-only argument `engine`:

```python
# v4.89 Layer A
def consult(query, domain=None, limit=10, project_id=None) -> list[dict]: ...

# v4.90 Layer B (backward-compatible superset)
def consult(query, domain=None, limit=10, project_id=None,
            *, engine: str = "auto") -> list[dict]: ...
```

`engine` accepted values:

| Value | Behaviour |
|---|---|
| `"auto"` (default) | If FTS5 available → `fts5`; else → `substring`. The default exists so tests written without `engine=` still pass. |
| `"substring"` | Force the v4.89 substring matcher. Always available. |
| `"fts5"` | Force FTS5 ranking. Raises `RuntimeError("FTS5 unavailable")` when probe fails — caller chose, caller fails loud. |

**Default-mode contract**:
> `engine="auto"` MUST return results that pass every Layer A test
> assertion. If a test asserts a set membership (`"X" in [hit.path for hit in results]`),
> FTS5 ranking changes the order but not the set, so the assertion holds.
> If a test asserts an explicit order (`results[0].path == "X"`), Layer B
> design REQUIRES `engine="auto"` to fall through to `substring` even
> when FTS5 is available. Step 4.5.a is the gate that decides which
> default to ship.

## FTS5 capability probe

```python
import sqlite3

_FTS5_AVAILABLE: bool | None = None

def _fts5_available() -> bool:
    global _FTS5_AVAILABLE
    if _FTS5_AVAILABLE is not None:
        return _FTS5_AVAILABLE
    try:
        conn = sqlite3.connect(":memory:")
        try:
            conn.execute("CREATE VIRTUAL TABLE t USING fts5(x)")
            _FTS5_AVAILABLE = True
        finally:
            conn.close()
    except sqlite3.OperationalError:
        _FTS5_AVAILABLE = False
    return _FTS5_AVAILABLE
```

The probe is cached at module level after first call. Tests can override
the cache via the public `_fts5_index._reset_probe_cache()` helper.

## Index file lifecycle

- **Path**: `ltm/.fts_index.sqlite`
- **gitignore**: yes (generated artifact, must not enter manifest /
  CHECKSUMS)
- **Build trigger** (any of):
  - Explicit CLI: `python -m runtime.ltm --rebuild-index`
  - Lazy: file does not exist when first FTS5 query runs
  - Stale: index mtime is older than the newest `ltm/**/*.md` mtime
- **Schema**:
  ```sql
  CREATE VIRTUAL TABLE entries USING fts5(
      path,           -- relative path under ltm/
      domain,         -- os | project | pattern | failures | _quarantine
      title,          -- H1 of the .md file (or filename slug fallback)
      content,        -- body text after front-matter
      project_id,     -- optional namespace tag (M9.5)
      tokenize='unicode61 remove_diacritics 2'
  );
  ```
- **Atomic rebuild**: write to `ltm/.fts_index.sqlite.tmp` then
  `os.replace(...)` — never leaves a half-written index.

## Query flow

```
consult(q, ..., engine="auto")
  ├── if engine == "substring":         → _substring_search(q, ...)   # v4.89 path
  ├── if engine == "fts5":
  │     if _fts5_available():           → _fts5_search(q, ...)
  │     else:                           → raise RuntimeError("FTS5 unavailable")
  └── if engine == "auto":              # ← the default; behaviour decided in Step 4.5.a
        if _AUTO_PREFERS_FTS5 and _fts5_available():
                                        → _fts5_search(q, ...)
        else:                           → _substring_search(q, ...)   # parity-safe default
```

`_AUTO_PREFERS_FTS5` is a module-level constant decided after Step 4.5.a
reading the 4 existing LTM tests:
- All-set-assertion tests → `_AUTO_PREFERS_FTS5 = True`
- Any order-assertion test → `_AUTO_PREFERS_FTS5 = False` (FTS5
  becomes explicit opt-in)

## Performance expectation

- substring: O(N × M) per query (N entries, M average chars)
- FTS5: O(K × log N) where K is the number of matching tokens

For the current ltm/ corpus (~20 entries, ~50 KB), both are
sub-millisecond. FTS5 wins as the corpus grows past ~hundreds.

## Failure modes & graceful degradation

| Failure | Behaviour |
|---|---|
| FTS5 unavailable + `engine="auto"` | Silent fallback to substring (most users won't notice) |
| FTS5 unavailable + `engine="fts5"` | Raise `RuntimeError`; do NOT silently downgrade |
| Index file corrupt | Lazy-detect at query time; auto-rebuild + retry; if rebuild fails → fall back to substring + stderr WARN |
| `ltm/` writable / index path read-only | Fall back to substring; one-time stderr WARN per process |

Substring is therefore the **always-correct fallback**; FTS5 is a pure
performance / ranking layer on top. Layer A users who never opt in get
Layer A semantics indefinitely.

## Test plan (Step 4.5.d)

Six new tests in `tests/test_ltm_fts5_fallback.py`:

1. `test_fts5_probe_returns_bool` — probe is callable, returns bool.
2. `test_engine_auto_fallback_to_substring_when_fts5_unavailable` —
   monkey-patch probe → False, default-engine call returns same hits as
   `engine="substring"`.
3. `test_engine_substring_explicit_bypasses_fts5` — even when FTS5
   available, explicit substring takes the v4.89 path (verified by
   ensuring no index file is created).
4. `test_engine_fts5_explicit_raises_when_unavailable` — explicit FTS5
   on FTS5-unavailable env raises RuntimeError (loud failure).
5. `test_fts5_index_rebuild_idempotent` — rebuild twice in a row;
   second rebuild produces byte-identical index file.
6. `test_fts5_ranking_returns_more_relevant_first` — when FTS5
   available, multi-token query returns entries with more matches first.

Tests 5+6 use `pytest.skipif(not _fts5_available(), reason=...)` to
keep CI green on FTS5-less environments.

## Migration path

| Audience | What to do in v4.90 | What to do in v4.91+ |
|---|---|---|
| Layer A consumers (test code, CLI users) | Nothing. Calls without `engine=` keep working. | Same. Layer A path will not be removed. |
| Performance-sensitive consumers | Call with `engine="fts5"` after running `--rebuild-index` once. | Consider `engine="auto"` if `_AUTO_PREFERS_FTS5` flips. |
| Future Layer C (Self-Evolution) | Use FTS5 ranking to pick top-K candidates for proposal generation. | Rely on Layer B as a stable foundation. |
