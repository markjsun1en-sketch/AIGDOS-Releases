# MEMORY_QUALITY_GATE — LTM Quality Rules (v4.90 Batch 8)

> **Status**: shipped 2026-05-13 (Batch 8 closure).
> **Script**: `scripts/ltm/validate_memory_quality.py` (GUIDED, Step 8.6)
> **Output schema**: `schemas/ltm/memory_quality_report.schema.json` (0.1.0-beta)

---

## 1. Purpose

A per-domain audit pass that produces a `memory_quality_report` JSON listing every entry under a target dir and any issues found. Reusable by:

- humans (post-promote sanity check)
- CI workflows (fail the run if `report.failed > 0`)
- the v4.90 Batch 11 CLI (`ai-dev-os ltm quality`)

Re-uses the helpers from `scripts/ltm/validate_failure_fix_entry.py` (`LIFECYCLE_REQUIREMENTS`, `validate_front_matter`, `_load_schema`) so semantics stay aligned across the LTM v2 toolchain.

---

## 2. Rules

| Rule | Severity | Domains | Trigger |
|---|---|---|---|
| `evidence_ref_missing` | **error** | any | front-matter has no `evidence_ref` or it is empty (`""` / `[]` / `{}`) |
| `lifecycle_invalid` | **error** | any | `lifecycle_state` present but not one of `active` / `superseded` / `deprecated` / `withdrawn` |
| `lifecycle_companion_missing` | **error** | any | `lifecycle_state` declares `superseded` / `deprecated` / `withdrawn` without the matching companion (`superseded_by` / `deprecated_at` / `withdrawn_at`) |
| `schema_invalid` | **error** | `failures/` only | the front-matter fails the ff schema check (re-uses `validate_front_matter` with the v4.89 grandfather) |
| `age_expired` | **warning** | `working/` only | `captured_at` (or file mtime fallback) older than `--working-age-days` (default 30) |
| `evidence_ref_not_found` | error | reserved | declared in schema enum; not yet emitted by 8.6 — reserved for a future enhancement that resolves citations |
| `unknown_field` / `other` | error | reserved | catch-all for future expansion |

`severity == "error"` counts the entry as **failed**. `severity in {"warning", "info"}` does **not** affect `failed`. Exit code is 1 iff `failed > 0`.

---

## 3. Domain detection

`--dir` basename selects the domain-specific rule subset:

- `failures` → adds `schema_invalid` to the universal rules (evidence + lifecycle).
- `working` → adds `age_expired` to the universal rules.
- everything else → universal rules only.

Subdirectories of `project/<id>/` should be passed individually (e.g. `--dir ltm/project/acme_demo`); the script does not recurse into nested project namespaces.

---

## 4. Report format

`memory_quality_report.schema.json` fields:

```json
{
  "report_id": "mqr_2026_05_13_failures",
  "scanned_dir": "ltm/failures",
  "total_entries": 7,
  "passed": 7,
  "failed": 0,
  "issues": [],
  "generated_at": "2026-05-13T03:42:00Z",
  "schema_version": "0.1.0-beta"
}
```

Each issue:

```json
{
  "path": "ltm/failures/2026-05-10_example.md",
  "rule": "evidence_ref_missing",
  "severity": "error",
  "message": "evidence_ref is missing or empty"
}
```

`total_entries == passed + failed` is invariant.

---

## 5. Real-world baseline

As of Batch 8.7 closure, running `validate_memory_quality.py --dir ltm/failures` reports:

```
[mqr_2026_05_13_failures] scanned ltm/failures
  total=7 passed=7 failed=0
```

The 6 v4.89 grandfather entries (2026-05-02 / 2026-05-05 series) pass clean despite missing `schema_version` + `lifecycle_state` because the shared `validate_front_matter` honours the captured_at ≤ 2026-05-09 cutoff and downgrades those misses to warnings.

---

## 6. CI integration outlook

A future workflow step (Batch 12 or later) can add:

```yaml
- name: LTM quality
  run: |
    cd AI_Game_Dev_OS_v4.90
    python3 scripts/ltm/validate_memory_quality.py --dir ltm/failures --format json
    python3 scripts/ltm/validate_memory_quality.py --dir ltm/working   --format json
```

Exit 1 = error issues = job fails. Warnings are surfaced in JSON output but do not block.

---

## 7. References

- `scripts/ltm/validate_memory_quality.py`
- `schemas/ltm/memory_quality_report.schema.json`
- `tests/ltm/test_validate_memory_quality.py`
- `docs/15_ltm_v2/FAILURE_FIX_SCHEMA_RULES.md` — ff schema authoritative reference
- `docs/15_ltm_v2/MEMORY_DOMAINS_v2.md`
- `docs/15_ltm_v2/PROMOTION_WORKFLOW.md`
