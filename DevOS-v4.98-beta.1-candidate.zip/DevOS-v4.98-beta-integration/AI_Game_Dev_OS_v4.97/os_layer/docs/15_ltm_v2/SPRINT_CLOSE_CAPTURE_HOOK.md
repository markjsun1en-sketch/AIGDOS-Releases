# sprint_close → ltm.capture Hook Specification

> **v4.90 Batch 4 Module D — Interface Spec**
> **Layer 1 (OS Spec)** — no project names
> **Reference implementation tier**: STUB (real impl: Batch 5.5)

## Why this hook exists

Adopting projects (long-running multi-sprint projects) typically have an internal
"sprint closure" workflow that produces:

- A closure report markdown
- An outcome verdict (PASS / PASS_WITH_NOTE / FAIL / DEFERRED / CANCELLED)
- A list of evidence pointers (commits, validation reports, gate results)
- A list of human-readable lessons

LTM v1 (v4.89 Phase 2) provides the `runtime.ltm.capture()` API which
can write these into `ltm/project/<id>/<slug>.md`. But the API is
domain-agnostic; each project has historically built its own ad-hoc
adapter from "closure report markdown" to "capture()" arguments.

This hook standardises the contract:
- One **input schema** (`schemas/ltm/sprint_close_capture_input.schema.json`)
  that every adopting project produces from their closure flow.
- One **STUB script** (`scripts/ltm/capture_sprint_close.py`) that adopting
  projects invoke; the script in Batch 5.5+ projects the input into a
  `runtime.ltm.capture()` call with `domain='project'`.

Once this hook is real (Batch 5.5), no adopting project needs to
re-derive the closure-to-capture mapping; they just produce
schema-conformant JSON and pipe it in.

## Input contract

See `schemas/ltm/sprint_close_capture_input.schema.json` for the full
JSON Schema. Required fields:

| Field | Type | Notes |
|---|---|---|
| `sprint_id` | string | Project's own sprint identifier (e.g. `sprint-12`, `release-2026-q3`). Opaque to OS Core. |
| `project_id` | string | `[a-z0-9_-]+` — the adopting project's namespace tag. Required by Gate rule 5 for `domain='project'` captures. |
| `outcome` | enum | `PASS` / `PASS_WITH_NOTE` / `FAIL` / `DEFERRED` / `CANCELLED`. Generic 5-state superset. |
| `captured_at` | ISO-8601 Z | UTC instant the closure was finalised. |

Optional fields (commonly present):
- `actor` — defaults to `"sprint_close_hook"`.
- `closure_report_path` — relative path to the project's closure report.
- `evidence_index` — list of evidence pointer strings (commits / files / event_ids).
- `lessons` — list of one-line lessons.
- `blockers_resolved` — list of blocker ids resolved during the sprint.
- `extra_evidence` — free-form object preserved verbatim into the captured body.

## Output contract

A single LTM Project-domain entry, written via:

```python
runtime.ltm.capture(
    domain="project",
    title=f"Sprint {sprint_id} closure",
    content=<rendered body>,
    evidence_ref=<combined evidence_index + closure_report_path>,
    actor=<actor or "sprint_close_hook">,
    project_id=<project_id>,
)
```

The rendered body MUST contain (when fields present):
- An H2 `## Outcome` line with the verdict.
- An H2 `## Lessons` bullet list (one bullet per `lessons[]`).
- An H2 `## Evidence` bullet list (one bullet per `evidence_index[]`,
  followed by `closure_report_path` if set).
- An H2 `## Blockers Resolved` bullet list (when non-empty).
- An H2 `## Extra` YAML block (when `extra_evidence` non-empty).

Captured at: `ltm/project/<project_id>/sprint-<sprint_id>-closure.md`
(slug formed by `runtime.ltm.capture._slugify`).

## Exit codes (post-implementation)

```
0 — captured successfully (gate=passed)
1 — input failed schema validation (Module A pattern)
2 — capture() returned gate=blocked (quarantined)
3 — internal error
4 — STUB / NOT_IMPLEMENTED   ← current Batch 4 state
```

## What Batch 4 ships

- ✅ Input schema (`schemas/ltm/sprint_close_capture_input.schema.json`)
- ✅ STUB script (`scripts/ltm/capture_sprint_close.py`, exit 4)
- ✅ Interface spec (this document)
- ❌ Real implementation — Batch 5.5
- ❌ Tests — Batch 5.5 (running tests against an exit-4 STUB is empty)
- ✅ CI integration — Batch 7 Step 7.3 (.github/workflows/v4_90_ci.yml)

## Why STUB instead of GUIDED in Batch 4

1. **Layer A capture API is frozen.** No new capture engine work is
   needed in Batch 4 — only the projection layer.
2. **Real input requires a real adopter.** Batch 5.5 (RH Real Adoption
   Simulation) is the first batch that actually has a project-side
   closure flow to produce schema-conformant input. Implementing the
   hook before that would risk locking input-shape decisions to a
   single hypothetical caller.
3. **Specification first prevents thrash.** Locking the JSON Schema
   surface area now lets Batch 5.5 implement under contract, rather
   than discovering shape requirements after writing the projector.

## Validation flow (Batch 5.5)

```
adopting project's sprint_close
        ↓ produces
schema-conformant JSON
        ↓ piped to
capture_sprint_close.py --input <path>
        ↓ validates input vs sprint_close_capture_input.schema.json
        ↓ if OK, projects to capture() arguments
runtime.ltm.capture(domain='project', ..., project_id=<id>)
        ↓ Gate rules 1-5 (Layer A engine, frozen)
ltm/project/<id>/sprint-<sprint_id>-closure.md
```

The script is therefore purely a **projection layer** that translates
between the project-side closure shape and the LTM capture API. It
does NOT extend the engine, NOT modify Gate rules, NOT introduce new
LTM domains.

## Interaction with Failure-Fix Memory

When a sprint closure surfaces a previously-unrecorded failure pattern
(e.g. a pathology that did not match `failure_pattern` of any existing
ff_NNNN entry), the closure flow MAY also write a Failure-Fix entry by
calling the validator + manual write pattern (same as v4.89-shipped
entries). The hook does NOT auto-create Failure-Fix entries — that is
left to humans / Self-Evolution (Batch 6).

## Compatibility

- v4.89 Phase 2 capture API: unchanged.
- v4.89 Phase 4 M9.5 namespace: required (`project_id` is the same
  field that drives `consult(project_id=...)` filtering).
- ff entries written through this hook would NOT match the
  Failure-Fix schema (they live under `ltm/project/`, not
  `ltm/failures/`); validators run against the right schema per
  domain.

## Open questions for Batch 5.5

- Should `--dry-run` output the rendered body to stdout or stderr?
  (Spec says stdout for piping; no decision yet.)
- Should multiple closures for the same `(project_id, sprint_id)` pair
  be allowed (overwrite vs new entry)?
- Should `closure_report_path` existence be checked at capture time?
  (Currently spec'd as not — caller's responsibility.)

These are deliberately open until a real adopter exercises the hook.
