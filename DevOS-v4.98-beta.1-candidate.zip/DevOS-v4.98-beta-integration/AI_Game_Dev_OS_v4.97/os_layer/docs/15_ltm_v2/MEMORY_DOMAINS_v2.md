# MEMORY_DOMAINS_v2 — LTM 7-Domain Taxonomy (v4.90 Batch 8)

> **Status**: shipped 2026-05-13 (Batch 8 closure).
> **Predecessor**: v4.89 Phase 2 4-domain layout (`os/` `project/` `pattern/` `failures/` + `_quarantine/`).
> **Source of truth for the directory layout**: `ltm/INDEX.md` (kept in sync).

---

## 1. The 7 domains

| Domain | Layer | Stores | Written by | Default scope |
|---|---|---|---|---|
| `os/` | OS Core | OS-level rules, pitfalls, best practices that span generations & projects | OS maintainer / phase-close commit | global, priority 1 |
| `pattern/` | OS Core | Reusable design patterns that generalise across projects | whoever discovers, writes it | global, priority 2 |
| `cross_project/` *(v4.90)* | OS Core | Patterns validated on **≥ 2 projects** and explicitly de-projectified | only via `promote_memory_candidate.py --to cross_project` (≥ 2 evidence_ref entries) | global, priority 3 |
| `failures/` | OS Core | Concrete error → root cause → fix pairs | postmortem commit; new entries via promote pipeline | per_project_or_global, priority 4 |
| `project/<id>/` | Project | Per-project sprint history, handoff patterns, technology choices | project EP / sprint close | per_project, priority 5 |
| `working/` *(v4.90)* | Session | Transient, in-session raw notes pre-validation | any agent, freeform | session_local, priority 6 (default-excluded) |
| `_quarantine/` | Pipeline | Gate-pending memory_candidate envelopes | `extract_failure_candidates.py` writes; `promote_memory_candidate.py` consumes | priority 7 (default-excluded) |

**Total**: 7 canonical domains (5 inherited from v4.89 + 2 added by Batch 8 Step 8.1).

---

## 2. Why two new domains in v4.90

### `cross_project/`

Up to v4.89 there was no formal place for "this pattern works on multiple projects" beyond the `pattern/` catch-all. Adopting projects (Batch 5.5 onwards) need a domain that:

1. Carries **multi-project evidence** as a hard requirement (≥ 2 unique `evidence_ref` entries enforced by the promote gate).
2. Stays **de-projectified** (no project-specific IDs / paths).
3. Is **read-default global** so consult() picks it up without any explicit narrowing.

`pattern/` keeps its broad design-pattern scope; `cross_project/` is narrower and evidence-bound.

### `working/`

A first-class place for raw notes before they become canonical — explicitly **session-local**, **default-excluded** from consult(), and consumed by `extract_failure_candidates.py` to feed the promotion pipeline. Replaces the implicit "I'll just leave a stub in `failures/`" pattern that v4.89 lacked guard-rails for.

---

## 3. Pipeline summary

```
working/  ──extract_failure_candidates.py──▶  _quarantine/
                                                 │
                                                 │ promote_memory_candidate.py
                                                 │   + approver
                                                 │   + evidence_ref ≥ 1 (≥ 2 for cross_project)
                                                 │   + target-domain schema valid
                                                 ▼
                            failures/ | pattern/ | os/ | cross_project/ | project/<id>/
```

See `PROMOTION_WORKFLOW.md` for the full step-by-step.

---

## 4. Quality gate

Run `scripts/ltm/validate_memory_quality.py --dir ltm/<domain>` to produce a `memory_quality_report` (schema: `schemas/ltm/memory_quality_report.schema.json`). See `MEMORY_QUALITY_GATE.md` for rule semantics.

---

## 5. Routing

`config/memory_retrieval_routing_v2.yaml` (schema: `memory_retrieval_routing.schema.json`) declares the priority + namespace + default-excluded policy enforced by future consult() callers. See `RETRIEVAL_ROUTING_v2.md` for the runtime contract.

---

## 6. Compatibility with v4.89

- **Read path**: `runtime/ltm/consult.py` (frozen) still works against the inherited 5 domains; entries under `cross_project/` and `working/` are simply additional dirs the existing globber will see.
- **Write path**: v4.89 `capture()` still accepts `domain="os|project|pattern|failures"` exactly as before; `cross_project` is gated through the promote pipeline (intentionally not a `capture()` domain).
- **No breaking changes** for any v4.89-era consumer.

---

## 7. References

- `ltm/INDEX.md` — runtime directory map
- `ltm/cross_project/README.md` — domain-specific README
- `ltm/working/README.md` — domain-specific README
- `docs/15_ltm_v2/PROMOTION_WORKFLOW.md` — pipeline detail
- `docs/15_ltm_v2/RETRIEVAL_ROUTING_v2.md` — routing config detail
- `docs/15_ltm_v2/MEMORY_QUALITY_GATE.md` — quality rules
- `docs/15_ltm_v2/FAILURE_FIX_SCHEMA_RULES.md` — ff schema (extended Step 8.2)
