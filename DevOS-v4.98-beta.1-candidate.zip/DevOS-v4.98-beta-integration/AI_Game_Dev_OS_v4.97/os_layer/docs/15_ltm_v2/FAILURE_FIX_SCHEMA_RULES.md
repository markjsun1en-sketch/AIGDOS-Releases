# Failure-Fix Memory Schema Rules

> **v4.90 Batch 4 Module A**
> **Layer 1 (OS Spec)** — no project names
> **Schema**: `schemas/ltm/failure_fix_memory.schema.json`
> **Validator**: `scripts/ltm/validate_failure_fix_entry.py`

## Purpose

`ltm/failures/` shipped six entries with v4.89 Phase 2. They share an
implicit shape (front-matter + Symptom / Root Cause / Fix / Lesson /
Commit Refs / Similar situations sections) but the shape was never
formally declared, so:
- Authors of new entries had to imitate existing entries by reading
- A typo in front-matter (`evidence-ref` vs `evidence_ref`) would not
  be caught
- Required sections could be silently dropped

v4.90 Module A formalises the shape as a JSON Schema and provides an
offline validator. **The runtime engine `runtime/ltm/capture.py` is NOT
modified** — capture continues to write whatever the caller passes; the
schema is enforced at lint / CI time, not at write time.

This separation is intentional:
- **Layer A engine** (capture.py / consult.py) stays minimal and stable
- **Layer B / v2 conventions** are enforced offline so they can evolve
  without breaking capture call sites

## Required front-matter fields

```yaml
---
captured_at: <ISO-8601 with Z>          # MUST match runtime/ltm/capture.py format
actor: <string>                         # who captured (kai / orchestrator / postmortem-bot)
gate: passed                            # MUST be the literal "passed" — quarantined entries belong elsewhere
evidence_ref: <commit-sha | path | event-id>   # MUST be non-empty
project_id: <slug | null>               # null for cross-project failures; slug for project-scoped
ff_id: ff_YYYY_NNN                      # NEW in v4.90 — opaque stable identifier
failure_pattern: <kebab-slug | null>    # NEW in v4.90 — high-level failure category
fix_pattern: <kebab-slug | null>        # NEW in v4.90 — high-level fix shape
---
```

The first four fields (`captured_at` / `actor` / `gate` / `evidence_ref`)
are exactly what the v4.89 capture.py engine writes. The next four are
v4.90 additions:

- `project_id` was introduced as a Layer A capture-time tag in M9.5;
  Module A makes it explicit in the schema. `null` is allowed (and is
  the default for cross-project OS-level failures like `ff_2026_001`).
- `ff_id` is a stable opaque identifier of the form `ff_YYYY_NNN`.
  Allocated sequentially. Once allocated, never reused or renumbered.
- `failure_pattern` and `fix_pattern` are high-level slugs that allow
  Layer B FTS5 / future Layer C self-evolution to group related
  failures without re-parsing prose. Both can be null for one-off
  incidents that don't fit a recurring shape.

## Required body sections

A Failure-Fix entry MUST contain (case-sensitive, H2 / `## ` heading):

1. `## Symptom` — observable behaviour at the point of failure
2. `## Root Cause` — single-sentence-extractable cause (parser does not
   currently extract; this is for the human reader)
3. `## Fix` — what was actually done; if the fix lives in another
   commit / file, include the reference here
4. `## Lesson` — one-sentence generalisation (this is the field that
   gets indexed by Layer B as the high-value retrieval target)

## Optional body sections

- `## Validation` — how the fix was tested
- `## Two-shape validation` — used when a contract has both old and new
  shapes during a transition (`a4_dry_run_verify_fail.md` is the
  canonical example)
- `## Commit Refs` — recommended; lists the introducing + fixing
  commits as `<short-sha> <subject>`
- `## Similar situations` — recommended; checklist for future authors
  encountering the same shape
- `## Additional refs` — pointers to related entries / OS contracts /
  pattern entries

The validator checks **presence of required H2 headings** but does NOT
check the prose content of those sections.

## Example (skeleton)

```markdown
---
captured_at: 2026-05-10T22:30:00Z
actor: kai
gate: passed
evidence_ref: docs/14_state_surface_governance/STATE_SURFACE_MIGRATION_CASE_SP115.md
project_id: null
ff_id: ff_2026_001
failure_pattern: state-surface-bloat-cold-start-balloon
fix_pattern: three-tier-model-with-sync-guard-and-index-first-cold-start
---
# <one-line title>

## Symptom
...

## Root Cause
...

## Fix
...

## Lesson
...

## Commit Refs
- `<sha>` <subject>

## Similar situations
1. ...
2. ...
```

## Validator usage

```bash
# Single file
python3 scripts/ltm/validate_failure_fix_entry.py \
    --file ltm/failures/2026-05-10_ff_2026_001_v489_to_v490_direct_replace.md

# Whole directory
python3 scripts/ltm/validate_failure_fix_entry.py \
    --dir ltm/failures/

# JSON output for CI
python3 scripts/ltm/validate_failure_fix_entry.py \
    --dir ltm/failures/ --format json
```

Exit codes (uniform with governance scripts):
- `0` = OK (all entries valid)
- `1` = one or more entries violate the schema
- `3` = internal error
- `4` = input missing (file/dir not found)

## Backwards compatibility with v4.89-shipped entries

The 6 v4.89-shipped entries (`2026-05-02_a4_*` etc.) **predate** the
v4.90 schema. They have the v4.89 4-field front-matter (no `ff_id` /
`failure_pattern` / `fix_pattern`). The validator handles this by:

- Treating missing `ff_id` / `failure_pattern` / `fix_pattern` as a
  WARNING, not a violation, when the entry's `captured_at` is on or
  before `2026-05-09T00:00:00Z`.
- New entries (v4.90 Batch 4 onward) — schema enforced strictly.

This matches the same "honesty pass" pattern used in v4.89 RC3 — old
artefacts stay as-is with a clear cutover date, new artefacts follow
the new contract.

## Lint integration (Batch 4 Step 4.6)

`scripts/ltm/validate_failure_fix_entry.py --dir ltm/failures/` should
become part of the v4.90 governance lint chain alongside
`scripts/governance/lint_layer_separation.py`. CI integration completed
in Batch 7 Step 7.3 via `.github/workflows/v4_90_ci.yml`.

## What this schema does NOT enforce

- Prose quality / completeness (humans review)
- Cross-references resolve (validator does not follow links)
- `evidence_ref` actually exists on disk (left to a future audit script)
- `commit_refs` are real git commits (out of scope)
- Sections appear in any specific order (only presence of required H2s)

These are intentional gaps — schema enforces shape, humans enforce
content. The validator is a guardrail, not a quality gate.
