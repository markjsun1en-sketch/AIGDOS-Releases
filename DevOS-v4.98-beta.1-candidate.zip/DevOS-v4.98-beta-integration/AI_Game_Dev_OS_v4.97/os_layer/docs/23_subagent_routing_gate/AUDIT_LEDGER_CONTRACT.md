# AUDIT_LEDGER_CONTRACT — Delegation decision ledger envelope + lifecycle

> **Layer 1 (OS Spec).** v4.91 Addendum-C / P1.5.
>
> Companion to [`README.md`](README.md) (adoption surface) and
> [`DECISION_RULES.md`](DECISION_RULES.md) (when to pick which result).
>
> **Schema** (canonical SSoT):
> [`schemas/governance/delegation_decision.schema.json`](../../schemas/governance/delegation_decision.schema.json)
> (1.0.0 const).
>
> **Ledger**:
> [`runtime/registries/delegation_decision_ledger.jsonl`](../../runtime/registries/delegation_decision_ledger.jsonl)
> (append-only, JSONL, one envelope per non-empty line).
>
> **Validator**:
> [`scripts/governance/validate_delegation_decisions.py`](../../scripts/governance/validate_delegation_decisions.py).

---

## 1. Why a runtime mirror exists

This contract applies when a selected runtime/adoption/delivery workflow
explicitly invokes the structured gate. It does not require a record for every
local action or every host-side delegation; see the
[skill](../../skills/_generic_core/orchestrator/subagent-routing-gate/SKILL.md).

A structured decision has a **runtime mirror line** (audit floor) and a target
in an existing task/coordination record for human consumption. That target may
reference the structured decision and result; a second manually copied field
block, per-agent log and handoff are not required. The runtime mirror stays at
its canonical OS-level path so audit/lint/CI tooling can read the same format.
No schema, validator, historical entry or required machine field is changed.

The mirror is **append-only**. Existing lines are never edited.
Amendments and withdrawals are appended as fresh lines that
reference the prior `event_id` via `details.amends`.

## 2. Envelope — 9 required top-level fields

Every line is a v4.89 9-field envelope plus a delegation-specific
`details` payload. `additionalProperties: false` at the top level —
no extra fields are permitted.

| Field | Type | Constraint |
|---|---|---|
| `schema_version` | string const | `"1.0.0"` |
| `event_id` | string | `^dd_[0-9a-f]{8}$` (8 lowercase hex) |
| `event_type` | string const | `"delegation_decision"` |
| `timestamp` | string | ISO-8601 UTC ending in `Z` (matches v4.89 envelope) |
| `actor` | string | non-empty; opaque parent-agent / orchestrator id |
| `runtime_profile` | string | non-empty; matches Permanent Contract #5 alias |
| `result` | string enum | `SPAWN_SUBAGENT` \| `LOCAL` \| `ESCALATE` |
| `source_layer` | string const | `"L1"` |
| `audit_status` | string enum | `recorded` \| `amended` \| `withdrawn` |
| `details` | object | 7 required fields + 4 optional, see §3 |

`event_id` uniqueness is enforced **across the entire ledger** for
`audit_status == "recorded"`. Amendments and withdrawals must
allocate a fresh `event_id` even though they reference an earlier one
via `details.amends`.

## 3. `details` — required + optional

### Required (7)

| Key | Type | Notes |
|---|---|---|
| `parent` | string | Parent agent / thread identifier. |
| `owner` | string | Formal owner agent (may equal `parent` for `LOCAL_OWNER_SELF`). |
| `subtask` | string | One-sentence next-work statement. |
| `allowed_write_set` | array of strings | Files / directories the executor may modify. **Empty list means read-only**, not "everywhere". |
| `expected_output` | string | What the executor returns (patch / report / evidence bundle / etc.). |
| `required_evidence` | array of strings | Evidence kinds (test runs, lint output, screenshot path, human-review record). Empty allowed only when `result == ESCALATE`. |
| `writeback_target` | string | Narrative surface where the executor's results will land. Required for **every** decision, including LOCAL. |

### Optional (4)

| Key | Type | Notes |
|---|---|---|
| `stop_or_escalate_if` | string | Kill-switch condition that flips the executor's run back to ESCALATE. |
| `reason_code` | string enum | Required iff `result == LOCAL`; one of `LOCAL_TINY` / `LOCAL_BLOCKED` / `LOCAL_OWNER_SELF` / `LOCAL_TOOLING` / `LOCAL_PREP`. Forbidden for non-LOCAL results. |
| `reason_note` | string | Free-text supplement to `reason_code`, ≤ 200 chars. Caps narrative drift into the runtime mirror. |
| `amends` | string | `^dd_[0-9a-f]{8}$`. Required iff `audit_status` ∈ {`amended`, `withdrawn`}; forbidden when `audit_status == "recorded"`. Must reference an earlier line in the same ledger. |

## 4. Lifecycle — recorded / amended / withdrawn

### `recorded` (default)

The first line for any decision. Carries no `amends`. Counts toward
event_id uniqueness. The most common status by far.

### `amended`

A second (or later) entry that **rewrites** the same logical decision
because new information arrived (e.g. owner clarified, write set
narrowed). The prior line stays in the ledger — it is the audit
trail. The amendment carries:

- a fresh `event_id` (e.g. prior `dd_a1b2c3d4` → new `dd_b2c3d4e5`);
- `audit_status: amended`;
- `details.amends: "dd_a1b2c3d4"` referencing the prior line.

### `withdrawn`

The original routing was never executed (parent abandoned it,
escalation arrived first, etc.). Append a fresh line with:

- a fresh `event_id`;
- `audit_status: withdrawn`;
- `details.amends: <prior_event_id>`.

Do **not** delete the original line. Do **not** mutate it. The
ledger is append-only.

## 5. Validator behaviour

`scripts/governance/validate_delegation_decisions.py` reads the
ledger (default `runtime/registries/delegation_decision_ledger.jsonl`,
override via `--ledger`) and emits one of three outcomes.

| Exit code | Meaning |
|---|---|
| 0 (`EXIT_OK`) | All lines valid, or ledger empty / missing (unless `--require-exists`). |
| 1 (`EXIT_VIOLATION`) | One or more violations; per-line rule + detail in stdout. |
| 3 (`EXIT_INTERNAL_ERROR`) | Validator crashed (cannot read schema, etc.). |
| 4 (`EXIT_INPUT_MISSING`) | `--require-exists` was set and the ledger file is absent. |

Use `--json` for machine-readable output. Violations are reported as
`{line, rule, detail}` triples; the rule names below are the same
rule strings emitted by the validator and asserted in
`tests/governance/test_delegation_gate.py`.

### Selected rule names

| Rule | Trigger |
|---|---|
| `envelope.missing_field` | One of the 9 top-level fields is absent. |
| `envelope.unknown_field` | An unexpected top-level key was added. |
| `event_id.pattern` | `event_id` does not match `^dd_[0-9a-f]{8}$`. |
| `event_id.unique` | A `recorded` line reuses an `event_id` seen earlier. |
| `timestamp.format` | Not ISO-8601 UTC + `Z`. |
| `result.enum` | Not in {SPAWN_SUBAGENT, LOCAL, ESCALATE}. |
| `audit_status.enum` | Not in {recorded, amended, withdrawn}. |
| `details.missing_field` | One of the 7 required `details` fields is absent. |
| `details.required_evidence.empty` | Empty list with `result != ESCALATE`. |
| `details.reason_code.required_for_LOCAL` | `result == LOCAL` without `reason_code`. |
| `details.reason_code.enum` | `reason_code` is not in the 5-element LOCAL enum. |
| `details.reason_code.only_for_LOCAL` | Non-LOCAL result carries a `reason_code`. |
| `details.reason_note.length` | `reason_note` exceeds 200 characters. |
| `details.amends.required` | `audit_status` ∈ {amended, withdrawn} without `amends`. |
| `details.amends.forbidden` | `audit_status == recorded` carries `amends`. |
| `details.amends.unresolved` | `amends` references an event_id absent from the ledger. |
| `details.amends.order` | `amends` references a line later in the file (must reference an *earlier* line). |

## 6. Empty ledger semantics

An empty (or whitespace-only) ledger is valid by default — the
validator returns `EXIT_OK` with `n_entries == 0`. This matches the
canonical state shipped with the OS source tree (the file exists with
zero lines so the path is stable across host projects).

Pass `--require-exists` if your CI step needs to fail when the ledger
file is missing entirely.

## 7. Closure-gate integration (F17)

`scripts/governance/run_release_closure_gate.py` registers F17
"Delegation decisions smoke" with two sub-checks:

1. The canonical empty ledger validates to `EXIT_OK`.
2. A synthetic LOCAL-without-`reason_code` line validates to
   `EXIT_VIOLATION` with the expected `reason_code.required_for_LOCAL`
   rule name.

F17 is part of the **fast** profile and adds approximately 0.1 s of
wall time. F17 PASS reads as: *the validator is present, executable,
and produces the documented exit codes for canonical inputs*. It is
not a statement about any individual project's delegation discipline.

## 8. Cross-line invariants (recap)

- Every recorded `event_id` is unique across the file.
- `details.amends` (when present) must reference an `event_id` that
  appears on an **earlier** line — order is enforced.
- An amended/withdrawn line does not consume the original
  `event_id`; the original line stays as canonical audit, the new
  line records the change.

## 9. Schema evolution policy

`schema_version` is currently `1.0.0` (const). Field additions to
`details` are minor-bump candidates only if they are **optional** and
do not affect existing line validity. Removing a field, narrowing an
enum, or making an optional field required is a major-bump change
requiring EP + matrix owner.
