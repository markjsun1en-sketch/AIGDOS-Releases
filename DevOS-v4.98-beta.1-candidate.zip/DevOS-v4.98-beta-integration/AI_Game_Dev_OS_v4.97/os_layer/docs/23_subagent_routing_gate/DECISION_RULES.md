# DECISION_RULES — Choosing SPAWN_SUBAGENT / LOCAL / ESCALATE

> **Layer 1 (OS Spec).** v4.91 Addendum-C / P1.5.
>
> Companion to [`README.md`](README.md) (adoption surface) and
> [`AUDIT_LEDGER_CONTRACT.md`](AUDIT_LEDGER_CONTRACT.md) (recording
> contract). Source of canonical phrasing remains
> [`SKILL.md`](../../skills/_generic_core/orchestrator/subagent-routing-gate/SKILL.md);
> this document expands the rule table with rationale and worked
> shapes that would clutter the SKILL surface.

---

## Applicability

Use the [skill](../../skills/_generic_core/orchestrator/subagent-routing-gate/SKILL.md)
for task-level delegation. Ordinary authorized local work needs no gate or
`LOCAL` override. The enums, required fields and examples below apply when a
runtime/adoption/delivery contract explicitly selects the structured gate.
Do not generate these artifacts merely because a task has several steps.

## 1. The three results

A delegation gate run yields **exactly one** of:

| Result | One-line meaning |
|---|---|
| `SPAWN_SUBAGENT` | The next work unit is bounded, clearly owned elsewhere, and the parent thread can usefully proceed in parallel (or should avoid context expansion). |
| `LOCAL` | The parent thread itself will execute this unit, with one of five enumerated `reason_code` values explaining why. |
| `ESCALATE` | A scope, owner, contract or write conflict cannot be resolved within existing authority. |

There is no fourth result. Adding one is a contract change requiring
EP + matrix owner.

## 2. SPAWN_SUBAGENT — preconditions

All of:

1. The subtask is bounded; its **expected output** can be stated in a
   single sentence.
2. The **write set** is clear, or the work is read-only.
3. The subtask falls inside a **formal owner** boundary.
4. The parent thread can do useful non-overlapping work, or should
   avoid context expansion (e.g. heavy code-search work).
5. **Required evidence** can be assigned up front (test runs, lint,
   review record, screenshot, etc.).

If any of (1)-(5) fail, do **not** dispatch a subagent. Continue locally within
existing authority or resolve the blocking boundary. Record the corresponding
LOCAL/ESCALATE artifact only for an explicitly selected structured gate.

## 3. LOCAL — closed enum

`LOCAL` requires `details.reason_code`. The five codes are
intentionally narrow; their names describe the *cause*, not the
*action*.

| Code | When it applies | When it does NOT apply |
|---|---|---|
| `LOCAL_TINY` | Task is genuinely small; write set is one or two files; coordination overhead would dominate. | "I want to do it myself" — that is `LOCAL_OWNER_SELF` if the parent owns it, otherwise probably ESCALATE. |
| `LOCAL_BLOCKED` | The parent thread's *immediate* critical-path step is blocked on this result; spawning a subagent would force the parent to idle anyway. | The parent has *other* work it could do — that is SPAWN_SUBAGENT. |
| `LOCAL_OWNER_SELF` | The parent agent **is** the formal owner of the work; delegation would add coordination cost without adding correctness. | A different agent owns the work but is unavailable — that is ESCALATE, not LOCAL. |
| `LOCAL_TOOLING` | Tooling, permissions, or current runtime context make subagent dispatch unavailable (e.g. no agent-runtime in current profile, sandbox blocks subprocess). | Tooling exists but is inconvenient — pick SPAWN_SUBAGENT. |
| `LOCAL_PREP` | A single parent-owned edit is required to *prepare* a later subagent task (e.g. add a fixture file the subagent will read). | The "prep" is the actual work — that is LOCAL_TINY or LOCAL_OWNER_SELF. |

`reason_note` (≤ 200 chars) is a free-text supplement, not a
substitute. A `LOCAL` decision without a `reason_code` is invalid and
the validator will reject it (`details.reason_code.required_for_LOCAL`).

## 4. ESCALATE — when to stop and ask

Pick `ESCALATE` when **any** of:

1. Scope or contract is not clear enough to delegate.
2. Owner authority is unresolved and no authorized executor can proceed.
3. The task needs human direction, aesthetic approval, gameplay
   signoff, or priority judgment.
4. Overlapping write sets cannot be serialized or narrowed within current authority.
5. The work touches a high-risk formal chain (cross-tenant promotion,
   schema bump, release-tag boundary, byte-locked tree) without a
   clear canonical source.

ESCALATE pauses the affected work pending the required decision. Record it
once in the existing task/coordination entry and reference the structured
event where required; do not also copy it into a parent-agent log. Continue
unrelated authorized work. Routine choices and serializable write conflicts
do not by themselves require escalation.

## 5. Worked shape — `SPAWN_SUBAGENT`

```md
Delegation Decision: SPAWN_SUBAGENT
decision_id: dd_a1b2c3d4
timestamp: 2026-05-25T05:00:00Z
Parent: orchestrator
Owner: agent_engineering
Subtask: re-run pytest tests/governance after schema sync; report deltas.
Allowed Write Set: (read-only)
Expected Output: textual diff of test counts and any new FAIL ids.
Required Evidence: pytest -q stdout, exit code, elapsed time.
Writeback Target: logs/orchestrator_log.md
Stop / Escalate If: pytest exit > 1 (collection error), or new FAIL id
                    that does not map to a recently changed file.
```

## 6. Worked shape — `LOCAL` (reason_code = LOCAL_PREP)

```md
Delegation Decision: LOCAL
decision_id: dd_e5f6a7b8
timestamp: 2026-05-25T05:05:00Z
reason_code: LOCAL_PREP
reason_note: parent must add fixture before agent_qa can run audit smoke
Parent: orchestrator
Owner: orchestrator
Subtask: add tests/fixtures/audit_smoke_min.json (fixture only, ≤ 30 lines).
Allowed Write Set: tests/fixtures/audit_smoke_min.json
Expected Output: 1 new fixture file, no other tree changes.
Required Evidence: file path + checksum recorded in orchestrator log.
Writeback Target: logs/orchestrator_log.md
```

## 7. Worked shape — `ESCALATE`

```md
Delegation Decision: ESCALATE
decision_id: dd_99887766
timestamp: 2026-05-25T05:10:00Z
Parent: orchestrator
Owner: (ambiguous — agent_engineering or agent_governance)
Subtask: rebuild RELEASE_MANIFEST after Addendum-C source-layer commits.
Allowed Write Set: (cannot bound until owner is fixed)
Expected Output: regenerated RELEASE_MANIFEST.json + CHECKSUMS.txt.
Required Evidence: lint_layer_separation pass, fast gate F2 PASS.
Writeback Target: logs/open_issues.md
Stop / Escalate If: (always — already escalated)
```

## 8. Edge cases

- **Read-only subagents are still SPAWN_SUBAGENT.** The skill does
  not require a write set; an empty list (`[]`) is valid.
- **Same-agent re-entry** (parent dispatches another instance of its
  own role to a fresh subtree). Treat as SPAWN_SUBAGENT, not LOCAL —
  the subagent runs in its own context and produces its own evidence.
- **Subagent-of-subagent** follows host authorization. In an explicitly
  selected structured workflow, each actual dispatch records its own decision;
  ordinary local steps still do not create ledger entries.
- **Withdrawal** (`audit_status = withdrawn`): the parent never acted
  on the original routing. Append a fresh ledger line referencing the
  prior `event_id` via `details.amends`. Do **not** delete or rewrite
  the original line; the ledger is append-only.

## 9. Anti-decisions (do not do this)

| Pattern | Why it is wrong |
|---|---|
| Omit required fields/records after explicitly selecting the structured gate | The selected machine contract still applies; ordinary local work does not select it automatically. |
| Invent a new LOCAL reason code at decision time | Adding a code is a contract change. Use `reason_note` for context, never as a code substitute. |
| Use ESCALATE as a placeholder until later | An ESCALATE entry is a real audit event; do not retract it by deleting the line. Amend or withdraw via a fresh entry. |
| Pass project IDs in `subtask` to "make it findable" | `subtask` is human-readable narrative. Project IDs belong in the host project's narrative log, not in the canonical OS-level mirror. |
