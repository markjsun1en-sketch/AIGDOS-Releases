# Workbuddy Private Profile — Dirty State Recovery

## Problem

Workbuddy-style coordination becomes fragile when task/registry state is left half-updated after interruptions, failed team execution, or partial proxy sync.

## Safe response

- stop new fan-out,
- identify the authoritative control owner,
- compare actual work outputs against internal state,
- repair the ledger explicitly,
- resume only through a controlled re-entry path.

## Why explicit repair matters

Dirty state is not merely cosmetic. It can invalidate routing, proxy sync, and sprint close assumptions.
