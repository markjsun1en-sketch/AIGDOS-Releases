# Workbuddy Private Profile — Limitations

## Important note

This profile captures project-proven behavior, but it does not claim a universal public specification.

## Known limitations

- behavior may differ from Codex, Cursor, or Claude-based profiles,
- cleanup and proxy sync expectations are project-derived,
- registry dirty-state handling is more central here than in the public profiles,
- portability to other runtimes should be treated as an adaptation task, not as a given.

## Structural note

Even though this profile is private, it is intentionally documented with a structure parallel to the public profiles:
- rule loading,
- context loading,
- writeback policy,
- recovery SOP,
- plus Workbuddy-specific team/proxy/dirty-state notes.

This keeps private semantics reviewable without elevating them into the portable-core baseline.

## Safe use rule

Use this profile only when the project is intentionally running on Workbuddy-style coordination semantics.

## Large AGENTS.md / SKILLS.md templates (REV-4-010, 2026-04-22)

Workbuddy's starter templates deliberately include large rule files:

- `docs/07_starters/workbuddy_private/AGENTS.md.template` — **~40 KB**
- `docs/07_starters/workbuddy_private/SKILLS.md.template` — **~16 KB**

This **violates** the Codex-aligned principle of "short, explicit, close-to-root rule files" stated in `docs/06_runtime_profiles/codex/RULE_LOADING.md` L24. The violation is intentional and profile-scoped:

### Why the exception

Workbuddy projects historically relied on a single authoritative AGENTS.md as the live execution file during Sprint work. Breaking it into many smaller files would require:

- rewriting every Workbuddy project's bootstrap flow (they read one file, not a directory),
- re-educating existing project EPs on where to find which rule,
- breaking diff-based review workflows that track daily AGENTS.md changes.

For **public profiles (Codex / Cursor / Claude Code Subagents / Claude Code Agent Teams), do NOT follow this pattern.** Use many small files per the Codex principle.

### Future path

When a Workbuddy project migrates to a public profile (or v4.89 introduces a public replacement for Team Mode), the big AGENTS.md should be decomposed into role-scoped files at that time. Until then, the 40 KB template stays as-is.

### Tooling expectations

Any generic tool that traverses `docs/07_starters/*` (e.g. `scripts/assemble_starter_bundle.py`, `scripts/verify_required_content.py`) should:

- not assume small file sizes,
- not apply Codex's "short explicit files" rule uniformly across profiles,
- treat Workbuddy starter files as opaque large blobs.

This exception is tracked as REV-4-010-workbuddy-exception and is not a v4.89 item — it is a permanent architectural accommodation for the private profile.
