# Workbuddy Private Profile — Context Loading

## Purpose

This file defines how the Workbuddy private profile should think about context loading.

## Central observation

The project-proven Workbuddy adaptation relies heavily on a **curated readset / loadset** approach rather than on broad implicit context.
That means context loading should be explicit and staged.

## Recommended loading order

1. portable-core entry docs
2. selected runtime profile docs for `workbuddy_private`
3. project adaptation summary / project baseline
4. `AGENTS.md`
5. `SKILLS.md`
6. `TASK_EXECUTION_RULES.md`
7. `WORKFLOW.md`
8. current-status / re-entry docs when resuming work

## Why this matters

The adaptation material shows that Workbuddy-style usage benefits from a compact digest + curated loadset rather than a broad preload of everything.

## Safe rule

If context must be narrowed, drop non-essential history first, not the current project execution files.
