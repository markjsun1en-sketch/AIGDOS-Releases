# Workbuddy Private Collector Notes

> Added 2026-04-22 to close REV-3-015.
>
> ⚠️ **Private profile — see REV-1-006 warning**: this profile is not portable across public runtime profiles. Collector design below reflects Workbuddy-specific semantics that should NOT be adopted by public profiles (Codex / Cursor / Claude Code Subagents / Claude Code Agent Teams).

## Binding

- **Collector script**: `runtime/observability/runtime_event_collectors/workbuddy_collector.py` (SCAFFOLD)
- **Runtime profile**: `workbuddy_private` (`config/profiles/workbuddy_private.json`)
- **Event schemas emitted**: `mcp_audit_log.schema.json` + `external_sync_audit.schema.json`

## Collection mode

**Main-session proxy with MCP audit feed**. Workbuddy private profile has a first-class MCP audit log (`.workbuddy/memory/` + MCP event hooks). Collector reads from the MCP event stream and normalizes.

- Trigger: MCP event subscription — every tool-call completion fires an MCP event the collector can subscribe to
- Polling: not required; event-driven
- Source path: Workbuddy's internal MCP audit sink (private API, profile-specific)

## Minimum implementation (Phase 4 GUIDED target)

- Subscribe to Workbuddy MCP event stream
- Translate Workbuddy-internal event schema to the shared `mcp_audit_log.schema.json` format (field-name mapping)
- Emit to `runtime/logs/audit/<YYYY>/<MM>/<event_family>.jsonl` per shared standard

## Workbuddy-specific notes

- **Team Mode handoff** events (when main session spawns a teammate) are NOT portable — they should be recorded as `runtime.handoff` audit events, but the underlying "Team Mode spawn Agent" pattern stays private (per REV-1-006 warning)
- Workbuddy has access to **daily log files** (`.workbuddy/memory/YYYY-MM-DD.md`) which can enrich `summary` fields with context not available to other profiles
- **Proxy sync semantics** (main session is the sole writeback owner) means `actor="main_session_proxy"` for all external.tapd.* events regardless of which subagent initiated the work

## Known limitations

- Event stream is tied to Workbuddy MCP; if MCP feed disconnects, collector can miss events until reconnection. Workbuddy's internal state survives disconnect but audit has a gap.
- Phase 4 trial work on public profiles should NOT use this collector as a reference — public profiles need profile-appropriate collection patterns.

## Cross-references

- `docs/07_starters/workbuddy_private/AGENTS.md.template` — private-profile context
- `docs/05_observability/Runtime_Event_Collection_Model.md`
- `docs/05_observability/AUDIT_LOG_STANDARD.md`
- `runtime/MATURITY_MATRIX.md`
