# Workbuddy Private Profile — Writeback Policy

## Default stance

For the Workbuddy private profile, external writeback should default to **main-session / control-owner execution**.
Workers may prepare status, evidence, and proposed updates, but final writeback ownership should remain centralized unless the project explicitly narrows that boundary in a controlled way.

## Why this stance exists

The adaptation evidence indicates that Workbuddy-like coordination is more sensitive to dirty registry state and proxy-sync behavior than the public profiles.
That makes centralized writeback safer.

## Writeback expectations

- worker finishes scoped work
- worker reports evidence / completion summary
- main session or declared control owner performs TAPD/external writeback
- writeback is verified after execution
- registry/internal state is reconciled if needed

## Anti-pattern

Do not treat every worker as if it automatically owns external state mutation rights just because it produced the underlying deliverable.
