# Workbuddy Private Profile — Recovery SOP

## Scope

This SOP describes the first recovery path for Workbuddy-style private coordination.

## Typical failure classes

- registry/task state drift
- team or coordination scope stalls
- proxy sync not executed or executed partially
- external writeback ownership confusion
- re-entry after interrupted execution

## Recovery path

1. stop further uncontrolled fan-out
2. identify main control owner
3. inspect current registry/task status
4. compare against latest known worker outputs
5. perform centralized repair or reconciliation
6. re-enter through the defined re-entry protocol rather than ad-hoc continuation

## Key rule

When dirty state appears, the correct reaction is not to keep pushing work forward blindly. It is to restore the control ledger first.

## Related docs

- `DIRTY_STATE_RECOVERY.md`
- `PROXY_SYNC_POLICY.md`
- starter re-entry guide/checklist
