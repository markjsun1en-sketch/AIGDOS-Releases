# Workbuddy Private Profile — Proxy Sync Policy

## Default rule

Main-session proxy sync is the default safety model for the Workbuddy private profile.

## Why proxy sync exists here

The project adaptation evidence indicates that external coordination and internal registry truth can drift if every worker is treated as an equal external writeback owner.
Proxy sync reduces that risk by centralizing final synchronization.

## Minimum proxy-sync flow

1. worker completes scoped work
2. worker reports completion/evidence
3. control owner performs external sync
4. control owner verifies writeback
5. control owner updates internal ledger if needed
