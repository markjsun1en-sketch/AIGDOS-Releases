# Workbuddy Private Profile — Team Mode Model

> **Filename note (REV-4-013, 2026-04-22)**: the filename `TEAM_MODE_MODEL.md` retains "Team Mode" terminology that v4.88 Overview explicitly abandons as a cross-runtime abstraction. The name is kept in Step 2 under Plan discipline (all file renames deferred to Step 3 RENAME batch per Phase 3 Execution Plan). Step 3 will rename this file to `WORKBUDDY_TEAM_MODEL.md` (or `PRIVATE_COORDINATION_MODEL.md`, EP to pick at RENAME time). The content below is already private-profile scoped and carries the REV-1-006 warning banner, so the filename change is cosmetic + path-alignment only.

## Positioning

This file documents the Workbuddy private coordination model as a **project-proven private runtime profile**, not as a portable universal abstraction.

> ⚠️ **Private profile** — the semantics below are NOT portable to public profiles (Codex / Cursor / Claude Code Subagents / Claude Code Agent Teams). Per REV-1-006 warning banner in `docs/07_starters/workbuddy_private/AGENTS.md.template`, public profiles MUST NOT adopt Team Mode spawn semantics.

## Core model

The adaptation material indicates a coordination style with these characteristics:

- strong project-owned `AGENTS.md` and companion policy files
- a control layer that routes and supervises work
- explicit task execution rules
- proxy sync and re-entry discipline
- higher sensitivity to registry/task-state drift than the public profiles

## Worker classes (REV-4-011, 2026-04-22)

Workbuddy Team Mode operates with three worker classes. This matches the level of detail Codex's `SUBAGENT_WORKTREE_MODEL.md` provides for its subagents; below each class, state its role and boundary.

### 1. Main session (main_session_proxy)
- **Role**: the authoritative session that owns `AGENTS.md`, writeback, merge decisions, and project-proven recovery flows.
- **Boundary**: exclusive owner of external PM writebacks (`external.tapd.*` audit events) and merge-apply actions. Never delegates writeback to team members.
- **Scope**: the entire workspace filesystem unless a sub-scope is explicitly carved out via Team Mode rules.

### 2. Team member (spawned via Team Mode)
- **Role**: short-to-medium-lived parallel worker invoked for a bounded task through Workbuddy's Team Mode spawn.
- **Boundary**: executes scoped work, produces structured handback, emits events to the shared mailbox. MAY NOT perform external writeback, MAY NOT merge to default branch.
- **Scope**: filesystem access per the Team Mode's `cwds` declaration in the automation; logical scope per the brief given.

### 3. Proxy / re-entry process
- **Role**: the dirty-state recovery owner. When Workbuddy's main session was interrupted and re-spawned, this class is the process that reconciles any orphan state.
- **Boundary**: read-first, verify-before-mutate. May modify runtime state only via the flows documented in `DIRTY_STATE_RECOVERY.md`.
- **Scope**: `.workbuddy/` directory + `runtime/state/` reconcile targets.

## Required constraints

- **Serial Team Mode spawns**: per Mac's memory (ID 32993224), team-mode spawns must be serial to avoid API rate limits. Applies to both public Claude Agent Teams and this private profile.
- **No writeback delegation**: team members prepare writeback intents, main session performs the write (see `WRITEBACK_POLICY.md` and `PROXY_SYNC_POLICY.md`).
- **Dirty-state sensitivity**: any mutation made outside the main session's view must be captured by the reconcile pass; this is stricter than public profiles because Workbuddy projects rely on AGENTS.md as live truth.
- **AGENTS.md immutability during Sprint execution**: changes to AGENTS.md during an active Sprint trigger an Sprint-readiness re-check (per `RECOVERY_SOP.md`).

## Recovery rules

When Team Mode coordination breaks:

- **Team member terminated mid-task**: main session marks the task `in_progress -> open` per state-transition rules, captures partial evidence, re-dispatches.
- **Main session crashed with uncommitted state**: next spawn invokes the Proxy / re-entry flow per `DIRTY_STATE_RECOVERY.md` before accepting new work.
- **Mailbox desync (team member state vs main session log)**: main session is authoritative; team member history is reconciled from main-session view, not merged.
- **External writeback failed verification**: follows `Writeback_Request_Protocol.md` (REV-3-007) retry + escalation + reconcile queue handling.

## Acceptance criteria (when is Workbuddy ready for a Beta Sprint?)

Workbuddy is acceptance-ready for a trial sprint when:

- `AGENTS.md` reflects current project state with no uncommitted changes older than 1 day,
- `SKILLS.md` is current,
- registry dirty-state passed Proxy / re-entry reconcile within the last 24 h,
- `runtime/state/runtime_state.json` has no residual demo data,
- Team Mode serial-spawn discipline is acknowledged in the project's working notes (e.g. `.workbuddy/SOUL.md` or equivalent).

Failure of any item blocks the sprint with EP escalation per `PORTABLE_RECOVERY_PRINCIPLES.md`.

## Implication for v4.89

The Workbuddy profile remains private, but it is now structurally complete enough to review alongside the public profiles. The expansion above addresses REV-4-011's semantic-symmetry gap; Workbuddy's file-level symmetry was already complete per Phase 3 Step 1.

## Cross-references

- `config/profiles/workbuddy_private.json` — profile schema binding
- `WRITEBACK_POLICY.md` — writeback discipline for this profile
- `PROXY_SYNC_POLICY.md` — proxy-sync specifics
- `DIRTY_STATE_RECOVERY.md` — sub-topic recovery flow
- `RECOVERY_SOP.md` — main recovery SOP
- `LIMITATIONS.md` — known boundary declarations including REV-4-010 AGENTS.md 40KB exception
- `docs/07_starters/workbuddy_private/AGENTS.md.template` — live execution file format (carries REV-1-006 private-profile warning banner)
