# Workbuddy Private Profile — Rule Loading

## Purpose

This document explains how rule loading should be understood for the Workbuddy private profile.
Unlike the public profiles, this one is derived from project-proven adaptation material rather than a universal public runtime specification.

## Primary rule sources

For the private Workbuddy profile, the effective rule stack is expected to come from project-facing files such as:

- `AGENTS.md`
- `SKILLS.md`
- `TASK_EXECUTION_RULES.md`
- `WORKFLOW.md`
- `RE_ENTRY_PROTOCOL.md`
- project loadset / bootstrap files

## Loading principle

The safe rule is:
- shared portable-core rules are always loaded first,
- Workbuddy-private rules then refine runtime-specific behavior,
- project-specific task rules may narrow behavior further, but must not override portable-core guardrails silently.

## Why this profile is different

Workbuddy practice in the adaptation material shows a stronger dependence on project-owned rule files than the public profiles.
That makes `AGENTS.md` and companion project policy files more central here than in the portable-core layer.

## Review questions

- Is the current project `AGENTS.md` treated as an active runtime input?
- Are task execution rules explicit, not implied?
- Are private Workbuddy rules kept out of the portable-core baseline?
