# TAG NOTE — `v4.89-release-rc2`

> **Purpose**: readiness note for EP's manual tag action finalizing v4.89 Release **rc2 reflow**. This execution thread does not touch git tags; this note documents the rc1→rc2 delta, the exact anchor commit, invariants at tag time, and the verification recipe.

---

## 1. Tag target

- **Tag name**: `v4.89-release-rc2`
- **Commit to anchor**: `5d9db1d` (rc2.8 — chain finale, full MANIFEST + CHECKSUMS internally consistent)
- **Branch**: `revise/phase-1-fork`
- **Predecessor tag**: `v4.89-release-rc1` (kept as historical archive, **not retired**)

## 2. Why rc2 exists

rc1 (M10.0.10, commit `d006eef`) ran a Dim 5 文案一致性 scan that intentionally retained the v4.88-named entry docs `docs/00_entry/AI_Game_Dev_OS_v4.88_{Overview,Master_Outline}.md` as "verbatim historical reference". The decision was correct in pure architecture-reference language but conflicted with the docs' position as **Run path step #1** in `START_HERE.md` (the package's onboarding entry).

When RH started its real v4.89 adoption (Task #2 of 2026-05-08), the v4.88-named entry docs would force every onboarding reader to start with v4.88-viewpoint material instead of v4.89-viewpoint material. Onboarding cost > historical preservation benefit.

**rc2 closes the gap by**:
1. Renaming the 2 entry docs to v4.89-named.
2. Rewriting their content to v4.89 viewpoint (with v4.88 lineage preserved as historical narrative inside the new docs).
3. Updating the 7 reference points across both dev tree and release tree.
4. Regenerating CHECKSUMS.sha (final state: 756 entries).
5. Regenerating RELEASE_MANIFEST.files[] as v4.89 current snapshot (was v4.88 RC12 baseline reference, drifted heavily through Phase 1-4).

**Historical preservation**: the original v4.88-named docs remain inside `AI_Game_Dev_OS_v4.88_Release/docs/00_entry/` (byte-locked SHA `58346b3`, untouched). Anyone needing the verbatim v4.88-viewpoint source has a stable archive there.

## 3. What rc2 changes vs rc1

| Dimension | rc1 (`d006eef`) | rc2 final (`5d9db1d`) |
|---|---|---|
| Run path step #1 doc name | `AI_Game_Dev_OS_v4.88_Overview.md` | **`AI_Game_Dev_OS_v4.89_Overview.md`** |
| Run path doc viewpoint | v4.88 (verbatim from v4.88_Release) | **v4.89 (Phase 1-4 hardening highlights)** |
| Master_Outline doc name | `AI_Game_Dev_OS_v4.88_Master_Outline.md` | **`AI_Game_Dev_OS_v4.89_Master_Outline.md`** |
| Master_Outline viewpoint | v4.88 outline | **v4.89 outline (10 chapters covering Phase 1-4 + tooling + lineage)** |
| Reference points | 7 pointing to v4.88-named files | **7 pointing to v4.89-named files** |
| CHECKSUMS.sha | 754 lines | **756 lines (4 regen cycles, final --check 756/756 OK)** |
| RELEASE_MANIFEST.files[] | 201 entries (v4.88 RC12 baseline; 45 missing / 63 sha drift) | **dev=723 / release=727 entries (v4.89 current snapshot, 0 drift)** |
| RELEASE_NOTES L176 | "still labeled v4.88; conceptual model unchanged" | **"v4.89 conceptual overview, Phase 1-4 hardening highlights"** |

## 4. RC2 commit chain (8 commits on `revise/phase-1-fork`)

| # | Commit | Subject | Files |
|---|---|---|---|
| rc2.1 | `580a1c7` | `chore(rc2): rename + rewrite Overview + Master_Outline to v4.89 (dev + release)` | 4 (2 dev rename+rewrite + 2 release rename+rewrite) |
| rc2.2 | `e1a0595` | `fix(rc2): update 7 reference points to v4.89_Overview / Master_Outline (dev + release)` | 10 (5 dev + 5 release) |
| rc2.3 | `8f411d7` | `fix(rc2): rewrite RELEASE_NOTES L176 reading-order entry to v4.89_Overview` | 1 (release-only) |
| rc2.4 | `8afc286` | `chore(rc2): regenerate CHECKSUMS.sha (755 lines, --check 755/755 OK)` | 1 (release-only) |
| rc2.5 | `106c581` | `docs(rc2): RELEASE_NOTES + CHANGELOG + TAG_NOTE_v4.89-release-rc2 + MATURITY §3.10` | 7 |
| rc2.6 | `1e48127` | `chore(rc2): regenerate CHECKSUMS.sha post rc2.5 (756/756 OK)` — fixup for rc2.4 placement error | 1 (release-only) |
| rc2.7 | `bd7b2dc` | `fix(rc2): post-RC2 consistency audit — MANIFEST sha sync + RELEASE_NOTES Reading order` | 4 |
| **rc2.8** | **`5d9db1d`** | **`fix(rc2): regenerate RELEASE_MANIFEST.files[] as v4.89 current snapshot`** — final consistency closure | **3** |

**Plan template lessons captured (3 cumulative)**:
1. `rc2.4 → rc2.6` — CHECKSUMS regen MUST be the last step in chain; placing it before the docs commit guarantees stale.
2. `rc2.7` — when renaming files in `MANIFEST.files[]`, the `bytes` and `sha256` fields must be refreshed in the same commit; path-only updates leave hybrid stale state.
3. `rc2.8` — when entry docs are renamed, regenerating the entire `MANIFEST.files[]` is cheaper and safer than partial updates (which can also accumulate drift from prior baselines, as v4.88 RC12 → v4.89 fork showed).

## 5. Invariants at rc2 tag time (anchor `5d9db1d`)

- **pytest 259 passed** at every commit, both dev tree and release tree.
- **`AI_Game_Dev_OS_v4.88_Release/` byte-lock SHA `58346b3`** — unchanged across the entire rc2 chain.
- **Dev/release byte-equivalent** — `diff -q` empty for all files except **5** release-only divergence points (was 4 pre-rc2; new addition = `RELEASE_MANIFEST.json` since rc2.8): `pytest.ini` / `RELEASE_NOTES.md` / `CHECKSUMS.sha` / `docs/06_runtime_profiles/TAG_NOTE_v4.89-release-rc1.md` + `rc2.md` (counted as 1 category) / `RELEASE_MANIFEST.json` (dev 723 vs release 727 entries).
- **CHECKSUMS.sha** — **756/756 OK / 0 FAILED** on `shasum -a 256 -c CHECKSUMS.sha`.
- **RELEASE_MANIFEST.json self-consistency** — both trees: `files[]` count == `file_count`; 0 missing on disk; 0 bytes_mismatch; 0 sha_mismatch.
  - dev tree: 723 entries
  - release tree: 727 entries (= dev 723 + 4 release-only paths)
- **Reference scrub** — `grep -rn "v4.88_Overview\|v4.88_Master_Outline"` in v4.89/ + v4.89_Release/ returns 7 matches across 5 files, all expected historical narrative:
  - `v4.89_Master_Outline.md §9` lineage paragraph (×2 trees)
  - `runtime/MATURITY_MATRIX.md §3.10` rename description (×2 trees)
  - `TAG_NOTE_v4.89-release-rc2.md §3` rc1↔rc2 comparison table (release-only)
  - 0 inside CHECKSUMS.sha
  - 0 inside RELEASE_NOTES.md
  - All other matches are inside `AI_Game_Dev_OS_v4.88_Release/` (historical archive).
- **rc1 tag preserved** — `v4.89-release-rc1` is not retired; rc2 is additive.

## 6. EP verification recipe

```bash
cd <UPSTREAM_REPO_ROOT>  # e.g. ~/Documents/AI_DEV_OS_Evolve (the workspace root, not the v4.89 subdir)

# 1. Confirm rc2 chain head
git log --oneline -8 revise/phase-1-fork
# expect: HEAD = 5d9db1d fix(rc2): regenerate RELEASE_MANIFEST.files[]...

# 2. v4.88_Release byte-lock unchanged
git log --oneline -1 -- AI_Game_Dev_OS_v4.88_Release/
# expect: 58346b3 docs(v4.88+v4.89)…

# 3. CHECKSUMS self-check
cd AI_Game_Dev_OS_v4.89_Release
shasum -a 256 -c CHECKSUMS.sha | tail -3
# expect: …last 3 lines all OK; 756/756 OK / 0 FAILED

# 4. pytest both trees
cd ../AI_Game_Dev_OS_v4.89 && python3 -m pytest tests/ -q
cd ../AI_Game_Dev_OS_v4.89_Release && python3 -m pytest tests/ -q
# expect: 259 passed (both)

# 5. Onboarding entry doc check
head -3 AI_Game_Dev_OS_v4.89_Release/docs/00_entry/AI_Game_Dev_OS_v4.89_Overview.md
# expect: # AI_Game_Dev_OS v4.89 Overview / ## Version Positioning

# 6. Reference scrub
grep -rln "v4\.88_Overview\|v4\.88_Master_Outline" \
    AI_Game_Dev_OS_v4.89/ AI_Game_Dev_OS_v4.89_Release/ | grep -v 88_Release/
# expect: 5 files (Master_Outline §9 ×2 trees + MATURITY §3.10 ×2 trees + TAG_NOTE_rc2 release-only)

# 7. MANIFEST self-consistency
python3 -c "
import json, os, hashlib
for tree in ['AI_Game_Dev_OS_v4.89', 'AI_Game_Dev_OS_v4.89_Release']:
    with open(f'{tree}/RELEASE_MANIFEST.json') as f: m = json.load(f)
    miss = mb = ms = 0
    for e in m['files']:
        full = os.path.join(tree, e['path'])
        if not os.path.exists(full): miss += 1; continue
        if os.path.getsize(full) != e['bytes']: mb += 1
        if hashlib.sha256(open(full,'rb').read()).hexdigest() != e['sha256']: ms += 1
    print(f'{tree}: files={len(m[\"files\"])} miss={miss} bytes_mismatch={mb} sha_mismatch={ms}')
"
# expect: dev files=723 0/0/0 ; release files=727 0/0/0
```

## 7. EP manual tag command

```bash
git tag -a v4.89-release-rc2 5d9db1d \
  -m "v4.89 Release rc2 — entry doc rename + content rewrite + reference reflow + CHECKSUMS regen + MANIFEST full regen"
```

Anchor commit = `5d9db1d` (rc2.8 — final consistency closure where MANIFEST + CHECKSUMS + RELEASE_NOTES + entry docs are all internally consistent).

## 8. References

- `~/.workbuddy/plans/swift-cascade-curie.md` — RC2 plan (originally 5 commits, extended to 8 through fixup cycles).
- `AI_Game_Dev_OS_v4.89_Release/RELEASE_NOTES.md` §0 — RC2 narrative block (8-step chain).
- `AI_Game_Dev_OS_v4.89_Release/CHANGELOG.md` — RC2 commit-level entry (8-step chain).
- `AI_Game_Dev_OS_v4.89/runtime/MATURITY_MATRIX.md §3.10` — RC2 milestone ledger (8 rows).
- `V4_89_PHASE_4_PLAN.md §五` — RC2 row added to Step 4 break-down (full hash chain).
- `AI_Game_Dev_OS_v4.89_Release/docs/06_runtime_profiles/TAG_NOTE_v4.89-release-rc1.md` — rc1 readiness note (kept).
