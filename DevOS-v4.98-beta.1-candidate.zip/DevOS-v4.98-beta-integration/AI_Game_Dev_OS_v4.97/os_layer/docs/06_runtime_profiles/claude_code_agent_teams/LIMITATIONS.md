# Claude Code Agent Teams — Limitations

> Added 2026-04-22 to close REV-4-015 (experimental / warning text was
> scattered across JSON `known_limitations`, Starter Guide, and
> CLAUDE.md.template; no single file collected the limitations).

## Important note

The Claude Code Agent Teams profile is currently **experimental**. It provides the highest-coordination multi-agent pattern in v4.89 (lead + parallel teammates), but also the highest overhead. Projects should treat it as a trial profile pending v4.90 validation, not a default production choice.

## Known limitations

- **Experimental feature tag**: `config/profiles/claude_code_agent_teams.json` carries `"known_limitations": ["experimental_feature"]`. Phase 4 trial results determine whether this tag is removed.
- **Serial spawn discipline required**: teammates must be spawned serially, not in parallel (per Mac's memory ID 32993224). Violating this triggers API rate limits that can stall the whole sprint.
- **Shared session isolation**: unlike Codex / Cursor, teammates don't get dedicated worktrees. Filesystem safety relies on serial merge + task partitioning. Projects that need hard filesystem isolation should prefer Codex or Cursor.
- **Higher cognitive overhead**: lead/teammate handbacks + mailbox + task partitioning = more moving parts. Use only when teammate-to-teammate or lead-to-multi-teammate coordination is genuinely valuable.
- **Mailbox fragility**: shared mailbox file (`runtime/queue/claude_teams_audit_inbox.jsonl`) can corrupt on concurrent append. v4.90 trial-time fix should add atomic-append or file locking; v4.89 does not address this.
- **No native event bus**: audit collection relies on the shared mailbox + lead polling. Lost teammate events are unrecoverable without secondary evidence.

## When NOT to use

Prefer a simpler profile when:

- the task is single-lane sequential (use Claude Code Subagents instead)
- filesystem isolation is critical (use Codex or Cursor)
- the project has no strong rationale for persistent teammate roles (use Claude Code Subagents)
- the project is in pre-Beta-Sprint bootstrap (use Codex for simplicity)

## Fallback path

If mid-sprint the Agent Teams profile is blocking progress, fall back to:

1. **Claude Code Subagents** — same Claude ecosystem, no lead/teammate coordination, subagent spawns are independent. Requires editing `config/profiles/*` pointer + re-entering sprint with reduced parallelism.
2. **Codex** — if filesystem-level isolation becomes necessary and the project tolerates a different tool. Requires re-deriving task partitioning.

Document the fallback in the sprint close report so Phase 4 evidence captures the why.

## Cross-references

- `config/profiles/claude_code_agent_teams.json` — canonical `known_limitations` field
- `docs/07_starters/claude_code_agent_teams/Claude_Agent_Teams_Starter_Guide.md` — contains earlier experimental warning
- `starters/claude_code_agent_teams/CLAUDE.md.template` — contains earlier experimental warning
- `LEAD_TEAMMATE_MODEL.md` — includes Isolation model section (REV-4-004 addition)
- `WRITEBACK_POLICY.md` — teammate→lead writeback queue (REV-4-002 addition)
- `RECOVERY_SOP.md` — recovery SOP
- `QUALITY_GATES_AND_CLEANUP.md` — cleanup ownership
