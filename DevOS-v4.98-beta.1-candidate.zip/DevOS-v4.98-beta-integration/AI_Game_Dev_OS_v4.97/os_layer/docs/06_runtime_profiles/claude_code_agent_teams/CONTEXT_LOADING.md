# Claude Code Agent Teams — Context Loading

## Principle
Agent teams require shared intent but not shared overload.

## Team context packet
The lead should carry the broader sprint picture. Teammates should receive:
- their role,
- their task packet,
- expected deliverable,
- when to report back,
- what they may not finalize.

## Avoid
Do not give every teammate the entire project context unless there is a clear need. That increases coordination cost without increasing precision.
