# Claude Code Agent Teams Collector Notes

> Added 2026-04-22 to close REV-3-015.

## Binding

- **Collector script**: `runtime/observability/runtime_event_collectors/claude_teams_collector.py` (SCAFFOLD)
- **Runtime profile**: `claude_code_agent_teams` (`config/profiles/claude_code_agent_teams.json`)
- **Event schemas emitted**: `mcp_audit_log.schema.json` + `external_sync_audit.schema.json`

## Collection mode

**Event-driven async team members**. Unlike subagents, team members are long-lived parallel agents that communicate via a mailbox. Audit events are produced at team-member level and written to a shared queue.

- Trigger: each team member's tool-call completion emits to shared audit queue
- Polling: lead/main session polls queue on cadence (default 30s) to drive flush
- Async queue: `runtime/queue/claude_teams_audit_inbox.jsonl` (append-only)

## Minimum implementation (Phase 4 GUIDED target)

Team member emits:

```python
def emit_from_teammate(event: dict, teammate_name: str) -> None:
    event["actor"] = f"teammate:{teammate_name}"
    with INBOX.open("a") as f:
        f.write(json.dumps(event) + "\n")
```

Lead collects:

```python
def flush_team_audit_inbox() -> list[dict]:
    """Drain inbox into normalized audit log; idempotent per line."""
    ...
```

## Claude Code Agent Teams-specific notes

- **Serial execution discipline**: per Mac's memory (ID 32993224), team mode must spawn team members serially to avoid API rate limits. This applies to audit collection too — lead should not parallel-flush inbox partitions.
- **Teammate communication events** (`send_message` / `broadcast`) should themselves be captured as `runtime.handoff` audit events with `handoff_target` = recipient teammate name
- **Handoff semantics are richer** than Codex/Cursor because teams have persistent roles; `actor="teammate:<role>"` should be preserved across the entire event

## Known limitations

- If the shared mailbox file is corrupted (partial write during concurrent append), one event may be lost. Mitigation: use atomic-append or lockfile. v4.89 does not address this; v4.90 trial-time fix should add atomic-append or file locking.
- Team member `max_turns` limit can cause silent cutoffs — collector should treat a teammate going silent for >10min as a `runtime.escalation` event and surface to EP

## Cross-references

- `docs/05_observability/Runtime_Event_Collection_Model.md`
- `docs/05_observability/AUDIT_LOG_STANDARD.md`
- `docs/06_runtime_profiles/claude_code_subagents/COLLECTOR_NOTES.md` — sister Claude profile
- `runtime/MATURITY_MATRIX.md`
