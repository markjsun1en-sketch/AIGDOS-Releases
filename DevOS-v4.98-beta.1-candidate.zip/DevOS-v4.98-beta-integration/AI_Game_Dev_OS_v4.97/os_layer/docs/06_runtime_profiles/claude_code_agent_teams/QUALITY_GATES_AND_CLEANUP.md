# Claude Code Agent Teams — Quality Gates and Cleanup

## Quality gates
The lead should enforce gates for:
- validation completeness,
- same-file overlap risk,
- external writeback readiness,
- audit evidence completeness.

## Cleanup owner
Cleanup belongs to the lead. Teammates should not silently finalize or destroy team state in isolation.

## Recovery note
If team coordination degrades, the first fallback is to collapse the problem into fewer workers or revert to the Claude subagent model.
