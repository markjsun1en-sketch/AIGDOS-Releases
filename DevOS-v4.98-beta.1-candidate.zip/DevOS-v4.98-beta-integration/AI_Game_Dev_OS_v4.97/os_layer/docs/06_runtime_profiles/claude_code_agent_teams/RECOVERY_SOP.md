# Claude Code Agent Teams — Recovery SOP

## Triggers
Use recovery when:
- teammates duplicate work,
- the lead loses task clarity,
- cleanup happens too early,
- quality gate status is ambiguous.

## Recovery sequence
1. stop new teammate assignments,
2. have the lead restate current truth,
3. classify teammate outputs as accept / revise / discard,
4. verify external state ownership,
5. resume with fewer open threads if necessary.
