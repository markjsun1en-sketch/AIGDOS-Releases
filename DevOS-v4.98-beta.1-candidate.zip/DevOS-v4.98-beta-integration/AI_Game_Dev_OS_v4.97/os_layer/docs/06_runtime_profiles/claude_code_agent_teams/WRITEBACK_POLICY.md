# Claude Code Agent Teams Runtime Profile — Writeback Policy

## Default owner
For the Claude Code Agent Teams profile, **the lead is the writeback owner**. Teammates are long-lived parallel agents but cannot own external PM state — they route writeback intents to the lead.

## Covered writeback targets
This policy applies to:

- TAPD story/task state updates,
- sprint-close transitions,
- archive operations,
- merge-complete status reflections,
- final audit and summary generation.

## Worker rule
Teammates may **prepare writeback intents** and push them to the lead via a queue, but:

- they MUST NOT call external PM APIs directly,
- they MUST NOT commit merges to default branches,
- their writeback intents are **inputs** to the lead, not decisions.

Per Mac's memory (ID 32993224), teammate spawns must be serial to avoid API rate limits; this discipline extends to writeback: the lead processes queued intents serially, not in parallel.

## Teammate → lead writeback queue

Teammates push writeback intents to the shared queue:

```
runtime/queue/writeback_pending.jsonl   (append-only, one JSON per line)
```

Intent format (matches `docs/04_integrations/Writeback_Request_Protocol.md` file_queue variant):

```json
{
  "request_id": "wr-<uuid>",
  "created_at": "<iso8601>",
  "target": "tapd",
  "object_type": "story",
  "object_id": "1234",
  "desired_state": "resolved",
  "internal_state": "done",
  "evidence_refs": ["..."],
  "attempts": 0,
  "requested_by": "teammate:engineering"
}
```

Lead drains the queue on cadence (default 30s) per `COLLECTOR_NOTES.md` polling model, validates each intent, and executes the writeback.

## Required verification chain
Every writeback performed by the lead follows this sequence:

1. validate mapping (against `integrations/tapd/tapd_config.template.json` or equivalent project config),
2. write external state,
3. read after write (via `runtime/integrations/tapd/read_after_write_verifier.py` per REV-3-013 binding),
4. confirm expected final state,
5. capture audit evidence as `external.tapd.write` + `external.tapd.verify` events with `actor="lead"` (not teammate).

## Failure handling
When a writeback fails any step of the verification chain:

- On retriable failures (network / transient 5xx): follow `Writeback_Request_Protocol.md` retry policy (default max 3, exponential backoff). The intent stays in `writeback_pending.jsonl`; attempts counter increments.
- On max-retry exhaustion: lead moves the intent to `runtime/queue/writeback_failed.jsonl` and escalates per Escalation column of the protocol (Orchestrator or EP depending on failure kind).
- On verification mismatch (write succeeded but read shows different state): emit `reconcile_pending` event; the reconciliation loop per `Registry_Writeback_and_Reconciliation_Contract.md` takes over.

## Exceptions
Limited exceptions are allowed only if:

- a task-specific policy explicitly grants writeback to a reviewed teammate process, AND
- the resulting state is still verified by the lead before the teammate's turn ends.

## Why this matters
The Claude Code Agent Teams model runs teammates in parallel; if each teammate wrote directly to TAPD:

- verification chains would race,
- audit events from different teammates could interleave and corrupt ordering,
- retry and escalation would become per-teammate rather than policy-uniform.

Centralizing writeback at the lead matches the profile's `writeback_owner: lead` declaration in `config/profiles/claude_code_agent_teams.json` and the serial-merge / serial-sync discipline that v4.88_Revise Phase 2 established (preserved in v4.89).

## Cross-references

- `config/profiles/claude_code_agent_teams.json` — `writeback_owner` field
- `LEAD_TEAMMATE_MODEL.md` — lead/teammate coordination semantics
- `QUALITY_GATES_AND_CLEANUP.md` — quality gates invoked before writeback
- `RECOVERY_SOP.md` — what to do when writeback verification fails
- `COLLECTOR_NOTES.md` — how writeback events flow into audit
- `docs/04_integrations/Writeback_Request_Protocol.md` (REV-3-007) — portable 4-tuple protocol
- `docs/03_runtime_core/AI_Game_Dev_OS_v4.87_Registry_Writeback_and_Reconciliation_Contract.md` — reconciliation when verify fails
