# Claude Code Agent Teams — Lead / Teammate Model

## Model summary
The lead owns:
- decomposition,
- merge order,
- final writeback,
- final cleanup,
- quality gates.

Teammates own:
- bounded execution,
- local evidence,
- handback notes,
- blocker reporting.

## Why this matters
Without a strong lead model, team-style coordination becomes noisy and hard to audit.

## Isolation model

Claude Code Agent Teams does **not** use Git worktrees as its isolation primitive. Instead, teammates share a single coordinated team session where per-teammate conversation state, mailbox, and persistent history live in `.workbuddy/teams/<team>/members/<member>/`.

- **JSON `isolation_unit` value**: `shared_session` (see `config/profiles/claude_code_agent_teams.json` L4) — this is the canonical machine-readable name.
- **Human-readable description** in `Runtime_Profile_Comparison.md`: `coordinated team session` — same concept, more descriptive.
- Both refer to the same isolation primitive; the JSON name is authoritative for tooling, the prose name is authoritative for docs.

What `shared_session` means concretely:

- No worktree per teammate (unlike Codex / Cursor)
- Filesystem isolation is at the workspace level, not per-teammate
- Conflict prevention relies on **serial merge discipline** (`merge_mode: serial` in the JSON) + **teammate-level task partitioning** (each teammate owns distinct task IDs or file scopes)
- Per-teammate `max_turns` + mailbox inbox prevents runaway parallel writes

Projects using this profile must:

- partition work at task-ID granularity before spawning teammates,
- serialize merges into default branch through the lead,
- treat any simultaneous edits to the same file as a coordination bug to resolve via task repartition, not via Git conflict resolution.

See `RECOVERY_SOP.md` for the handback rules when a teammate's session state becomes inconsistent with the shared workspace.

## Recommended use
Use agent teams only when teammate-to-teammate or lead-to-multi-worker coordination is truly valuable. Otherwise prefer the simpler Claude subagent profile.
