# Claude Code Agent Teams — Rule Loading

## Purpose
This profile is separate from Claude subagents because the coordination model is different: a lead coordinates teammates, shared task lists may exist, and cleanup responsibilities are more centralized.

## Rule priorities
1. portable-core governance,
2. Claude agent-teams profile docs,
3. team boot guide,
4. quality-gate and cleanup policy,
5. per-task instructions.

## Required emphasis
Because agent teams increase coordination complexity, their rules must emphasize:
- lead authority,
- teammate task boundaries,
- cleanup ownership,
- external writeback ownership,
- anti-overlap and anti-thrashing safeguards.
