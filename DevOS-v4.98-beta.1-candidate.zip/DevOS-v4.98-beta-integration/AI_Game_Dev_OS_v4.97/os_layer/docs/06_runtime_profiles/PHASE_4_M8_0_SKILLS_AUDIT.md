# Phase 4 M8.0 Skills Audit — lessismore-16 vs v4.89-19

> **Status**: lock document (decisions Q1-Q4 + per-skill subdir map). Written before any SKILL.md mutation so C2-C4 are mechanical paste/move operations.
> **Base anchor**: HEAD `cb3646a` / tag `v4.89-phase-4-lift` / pytest 192 passed.
> **Source path**: `/Users/macsun/lessismore/skills/` (16 SKILL.md, 33 files total including references and .DS_Store).
> **Destination**: `AI_Game_Dev_OS_v4.89/skills/` (19 SKILL.md + 15 contract/ops + 12 hooks at audit time).
> **Source override vs mother spec V4_89_PHASE_4_PLAN.md §三**: mother spec named `RandomHeroes/skills/` as source. That path does not exist on disk. EP confirmed `lessismore/skills/` as the real source on 2026-05-06.

---

## 1. Mother spec §三 reconciliation

Mother spec §三 estimated 2-3 commits importing 5-6 candidate skills (contract_check / task_breakdown / qa_regression / doc_sync / gdd_to_spec / godot_2d_responsive_layout_general) into an empty `skills/` folder.

Two assumptions were wrong:

1. **`skills/` is not empty**. Phase 3 Step 1 (commits `470cb2a` ... `246d71b` on 2026-04-22) already populated `_generic_core/` with 19 SKILL.md + 15 contract/ops files plus 12 adaptation hooks. README §1 mis-claims "34 skills" because it counts contract/ops/schema files as skills; only 19 are SKILL.md.
2. **`RandomHeroes/skills/` does not exist**. The actual RH skill location is `RandomHeroes/.workbuddy/skills/` containing 15 `rh-*` agent-role SKILL.md, structurally aligned with v4.89 `_generic_core/` rather than with mother spec §三 candidate names.

The real candidate source is `lessismore/skills/` (16 SKILL.md). All 6 candidate names listed by the mother spec hit it exactly.

---

## 2. lessismore inventory (16 skills)

| # | dir name (snake) | frontmatter `name` | lines | references/ subdir |
|---|---|---|---:|---|
| 1 | art_concept_from_design_brief | art-concept-from-design-brief | 279 | no |
| 2 | asset_breakdown_for_engine | asset-breakdown-for-engine | 24 | no |
| 3 | combat_feature_rollout | combat_feature_rollout | 33 | no |
| 4 | contract_check | contract_check | 32 | no |
| 5 | data_config_layering | data_config_layering | 135 | no |
| 6 | doc_sync | doc_sync | 31 | no |
| 7 | engine_export_packaging | engine-export-packaging | 27 | no |
| 8 | gamestring_localization_contract | gamestring_localization_contract | 131 | no |
| 9 | gdd_to_spec | gdd_to_spec | 31 | no |
| 10 | godot_2d_responsive_layout | godot_2d_responsive_layout | 84 | yes (5 ref files incl. lessismore_battle_case.md) |
| 11 | godot_2d_responsive_layout_general | godot_2d_responsive_layout_general | 74 | yes (7 ref files) |
| 12 | image_cleanup_pipeline | image-cleanup-pipeline | 65 | no |
| 13 | numeric_id_planning | numeric_id_planning | 91 | no |
| 14 | qa_regression | qa_regression | 31 | no |
| 15 | rawdata_pipeline_check | rawdata_pipeline_check | 33 | no |
| 16 | task_breakdown | task_breakdown | 31 | no |

Frontmatter convention: 4 already kebab-case (matching v4.89), 12 snake_case (require normalization on import per §6 rule).

---

## 3. v4.89 _generic_core/ inventory (19 SKILL.md, audit-time)

```
art/                                (7 SKILL.md)
  art-concept-from-design-brief/SKILL.md          (25L stub)
  art-consistency-review/SKILL.md
  asset-batch-planning/SKILL.md
  asset-breakdown-for-engine/SKILL.md             (24L)
  asset-variation-control/SKILL.md
  engine-export-packaging/SKILL.md                (25L, with scripts/export_packaging.py — cleaner than lessismore)
  image-cleanup-pipeline/SKILL.md                 (28L stub, with scripts/cleanup_images.py)
design/                             (6 SKILL.md)
uiux/                               (6 SKILL.md)
content-design/                     (0 SKILL.md, contract only)
engineering/                        (0 SKILL.md, contract + ops only)
ep/                                 (0 SKILL.md, contract only)
game-design/                        (0 SKILL.md, contract + ops only)
numeric/                            (0 SKILL.md, contract only)
orchestrator/                       (0 SKILL.md, contract + ops only)
qa/                                 (0 SKILL.md, contract + ops only)
research/                           (0 SKILL.md, contract + ops only)
sound-designer/                     (0 SKILL.md, contract + ops only)
```

19 SKILL.md = art 7 + design 6 + uiux 6, all from v4.8.2 import (Phase 3 Step 1.2a-c). Subsystem subdirs (engineering / qa / orchestrator / etc.) currently have only the three-artifact contract + ops files, no task SKILL.md. M8.0 fills this gap.

---

## 4. Cross-map (16 lessismore -> v4.89 disposition)

| lessismore | classification | v4.89 path action | residue / engine binding |
|---|---|---|---|
| art_concept_from_design_brief | OVERLAP-fatten | replace `_generic_core/art/art-concept-from-design-brief/SKILL.md` body (25L -> 279L) | clean |
| asset_breakdown_for_engine | OVERLAP-skip | byte-equal with existing 24L; no action | clean |
| engine_export_packaging | OVERLAP-skip | v4.89 already cleaner (`scripts/export_packaging.py`, no `config/godot_export_rules.json` residue) | lessismore version has Godot residue line 27 |
| image_cleanup_pipeline | OVERLAP-fatten | replace `_generic_core/art/image-cleanup-pipeline/SKILL.md` body (28L -> 65L) | clean |
| combat_feature_rollout | NEW | add `_generic_core/game-design/combat-feature-rollout/SKILL.md` | clean |
| contract_check | NEW | add `_generic_core/engineering/contract-check/SKILL.md` | clean |
| data_config_layering | NEW | add `_generic_core/numeric/data-config-layering/SKILL.md` | clean (mentions "slot" generically only) |
| doc_sync | NEW | add `_generic_core/orchestrator/doc-sync/SKILL.md` | clean |
| gamestring_localization_contract | NEW | add `_generic_core/content-design/gamestring-localization-contract/SKILL.md` | clean |
| gdd_to_spec | NEW | add `_generic_core/game-design/gdd-to-spec/SKILL.md` | clean |
| numeric_id_planning | NEW | add `_generic_core/numeric/numeric-id-planning/SKILL.md` | clean |
| qa_regression | NEW | add `_generic_core/qa/qa-regression/SKILL.md` | clean |
| task_breakdown | NEW | add `_generic_core/orchestrator/task-breakdown/SKILL.md` | clean |
| rawdata_pipeline_check | GODOT | add `_engine_specific/godot/rawdata-pipeline-check/SKILL.md` | yes — `RawData`, `.tres`, "import tool -> generated resources -> runtime" |
| godot_2d_responsive_layout | GODOT | add `_engine_specific/godot/godot-2d-responsive-layout/SKILL.md` + `references/` (drop `lessismore_battle_case.md`) | yes — Godot, plus project-specific case ref |
| godot_2d_responsive_layout_general | GODOT | add `_engine_specific/godot/godot-2d-responsive-layout-general/SKILL.md` + `references/` (7 files as-is) | yes — Godot (still names Godot in title, workflow step 1, references); `_general` strips project specifics not engine specifics |

**Disposition totals**: 9 NEW into `_generic_core/`, 2 OVERLAP fatten in `_generic_core/art/`, 2 OVERLAP skip, 3 GODOT into new `_engine_specific/godot/`. Net SKILL.md mutations on this milestone = 14 (9 add + 2 modify + 3 add to new namespace).

---

## 5. Locked decisions (Q1-Q4, EP 2026-05-06 11:00 GMT+8)

| Q | Decision | Rationale |
|---|---|---|
| Q1 | **Full absorption** of lessismore 16 (10 NEW after pulling rawdata to GODOT + handle 4 OVERLAP + 3 GODOT) | mother spec §三 "5+ skills" floor met and exceeded with 9 + 2 + 3 = 14 net mutations; one-shot consolidation cheaper than two passes |
| Q2 | **OVERLAP fatten by paste-replace** body; preserve v4.89 kebab `name`; merge `description` only when v4.89's is shorter | empirical scope = 2 (not 4); asset-breakdown byte-equal and engine-export already cleaner in v4.89 |
| Q3 | **New `_engine_specific/godot/` third axis** parallel to `_generic_core/` + `_adaptation_hooks/`; README §1 grows tri-axis row + new §10 namespace contract | hooks layer is for variable binding, not engine-locked logic; `_generic_core/` excludes engine specifics by definition |
| Q4 | **5 commits** (audit / 9 NEW / 2 fatten / 3 GODOT / docs finale) | mother spec §三 estimate 2-3 was based on stale assumption that skills/ was empty; full absorption per Q1 needs proper segmentation for byte review |

---

## 6. Frontmatter normalization rule (C2 + C3 + C4 mandatory)

For every imported SKILL.md, before commit:

1. `name:` field MUST equal directory name.
2. Directory name MUST be kebab-case (`-` separator), matching v4.89 `_generic_core/` convention (e.g., `feature-brief-structuring`).
3. lessismore source mapping table:

| lessismore frontmatter `name` | v4.89 final frontmatter `name` |
|---|---|
| art-concept-from-design-brief | art-concept-from-design-brief (no change) |
| asset-breakdown-for-engine | (skipped) |
| combat_feature_rollout | combat-feature-rollout |
| contract_check | contract-check |
| data_config_layering | data-config-layering |
| doc_sync | doc-sync |
| engine-export-packaging | (skipped) |
| gamestring_localization_contract | gamestring-localization-contract |
| gdd_to_spec | gdd-to-spec |
| godot_2d_responsive_layout | godot-2d-responsive-layout |
| godot_2d_responsive_layout_general | godot-2d-responsive-layout-general |
| image-cleanup-pipeline | image-cleanup-pipeline (no change) |
| numeric_id_planning | numeric-id-planning |
| qa_regression | qa-regression |
| rawdata_pipeline_check | rawdata-pipeline-check |
| task_breakdown | task-breakdown |

4. `description:` field copied verbatim from lessismore unless v4.89 stub has a clearly superior wording (only art-concept-from-design-brief: lessismore description is richer, replace v4.89's).
5. Body text below frontmatter copied verbatim from lessismore (no edits) for NEW imports. For OVERLAP fatten: full body replaced with lessismore body.
6. References subdirectory (Godot 2D layout pair only) copied verbatim except `lessismore_battle_case.md` dropped for the project-specific variant.

---

## 7. Per-commit boundary

| commit | adds | modifies | deletes | risk |
|---|---:|---:|---:|---|
| C1 (this doc) | 1 | 0 | 0 | low (lock doc only) |
| C2 (9 NEW) | 9 | 1 (README §1) | 0 | medium (subdir judgment) |
| C3 (2 fatten) | 0 | 2 | 0 | low-medium (frontmatter merge) |
| C4 (3 GODOT) | 3 SKILL.md + 12 ref files (5 + 7 minus 1 dropped) + 1 dir | 1 (README §1, §10) | 0 | medium (sets _engine_specific precedent) |
| C5 (docs finale) | 1 (TAG_NOTE) | 4 (MATURITY §3.6, CHANGELOG, V4_89_PHASE_4_PLAN §三, README final reconciliation) | 0 | low |

**Net at M8.0 close**: skills/_generic_core/ 19 -> 28 SKILL.md (+9 NEW); skills/_generic_core/art/ 2 fattened; skills/_engine_specific/godot/ 0 -> 3 SKILL.md + 12 ref files; README rewritten.

---

## 8. Cross-commit invariants (carry forward)

- pytest 192 passed at every commit
- `AI_Game_Dev_OS_v4.88_Release/` last-touch commit `58346b3` unchanged throughout
- per-profile mirror sha unchanged (skills/ outside runtime mirror set)
- Phase-1 11 permanent contracts, Stage-2 charter §5.2, existing 7 tags untouched
- English-only (permanent contract §11)
- pre-flight verified `grep -rn "skills/" tests/` returns 0 matches at HEAD `cb3646a`

---

## 9. Reference

- Mother spec: `V4_89_PHASE_4_PLAN.md §三`
- Sibling audit (Phase 4 Step 1): `docs/06_runtime_profiles/PHASE_4_LIFT_GATE_AUDIT.md`
- Plan file (this thread): `~/.workbuddy/plans/stellar-vortex-einstein.md`
- Source: `/Users/macsun/lessismore/skills/`
- Source override note: mother spec §三 candidate path `RandomHeroes/skills/` does not exist; closest RH analog is `RandomHeroes/.workbuddy/skills/` (15 `rh-*` agent-role SKILL.md, structurally distinct from lessismore's task-skill shape, not used as M8.0 source).
