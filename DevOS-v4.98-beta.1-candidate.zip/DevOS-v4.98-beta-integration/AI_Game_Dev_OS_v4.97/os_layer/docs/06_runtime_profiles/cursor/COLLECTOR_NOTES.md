# Cursor Collector Notes

> Added 2026-04-22 to close REV-3-015.

## Binding

- **Collector script**: `runtime/observability/runtime_event_collectors/cursor_collector.py` (SCAFFOLD)
- **Runtime profile**: `cursor` (`config/profiles/cursor.json`)
- **Event schemas emitted**: `mcp_audit_log.schema.json` + `external_sync_audit.schema.json`

## Collection mode

**Inline with lead-teammate relay**. Cursor profile uses a lead agent that coordinates teammates; the lead acts as audit owner and collects teammate events before flushing.

- Trigger: every teammate tool-call completion routes through the lead, which emits the audit event
- Polling: not required; teammates push to lead on completion
- Async queue: optional `runtime/queue/cursor_collector_inbox.jsonl` for bursty teammate completions

## Minimum implementation (Phase 4 GUIDED target)

Collector implements `RuntimeEventCollector` protocol from `Runtime_Event_Collection_Model.md`:

- `collect(source)` where `source` is the lead agent's completion stream
- `schema_id()` returns `mcp_audit_log.schema.json` or `external_sync_audit.schema.json`
- `profile_tag()` returns `"cursor"`

## Cursor-specific notes

- Lead vs teammate distinction in `actor` field: use `actor="lead"` vs `actor="teammate:<role>"`
- Cursor's merge ownership is the lead by default; `merge.apply` events should record `actor="lead"` even if teammate did the code change
- No native MCP event bus in Cursor — collector implements its own queue semantics

## Known limitations

- Teammate crashes between tool-call and event push → lead loses that event. Mitigation: lead periodically re-audits against git log to detect phantom work.
- Teammate mode does not expose tool-call latency → that extended field stays null

## Cross-references

- `docs/05_observability/Runtime_Event_Collection_Model.md`
- `docs/05_observability/AUDIT_LOG_STANDARD.md`
- `docs/06_runtime_profiles/codex/COLLECTOR_NOTES.md` — sibling profile reference
- `runtime/MATURITY_MATRIX.md`
