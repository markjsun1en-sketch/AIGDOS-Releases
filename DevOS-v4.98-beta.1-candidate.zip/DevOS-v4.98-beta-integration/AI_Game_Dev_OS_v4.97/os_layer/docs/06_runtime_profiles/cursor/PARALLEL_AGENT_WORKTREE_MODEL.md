# Cursor Runtime Profile — Parallel Agent & Worktree Model

## Model summary
The Cursor runtime profile assumes:

- many agents may work in parallel,
- worktree-style isolation is preferred,
- integration back into the main line is serialized,
- review and apply remain more centralized than exploration.

## Worker roles
### Coordinator
Owns merge order, review checkpoints, and external writeback.

### Parallel agent
Owns bounded implementation or exploration in an isolated surface.

### Worktree or isolated environment
Owns branch-local or workspace-local mutations.

## Constraints
- no shared unchecked edits across multiple active workers.
- no concurrent final apply to the same target line.
- no silent PM writeback from background worker state.

## Good use cases
- alternate solution exploration,
- parallel bug-fix attempts,
- separate design and implementation passes,
- sprint wave decomposition.

## Bad use cases
- same-file rapid iterative edits by many workers,
- cross-dependent tasks without a coordinator,
- external state transitions before branch review.
