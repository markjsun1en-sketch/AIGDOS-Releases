# Cursor Runtime Profile — Recovery SOP

## Trigger conditions
Use this SOP when:
- multiple agent branches drift,
- parallel work overlaps the same files,
- apply order becomes unclear,
- review evidence is incomplete.

## Recovery sequence
1. stop new apply actions,
2. identify the coordinator-owned truth branch,
3. classify workers as keep / rebase / discard,
4. verify TAPD state before resuming,
5. resume with serialized integration.

## Key principle
In Cursor, the recovery target is not to preserve every attempt; it is to restore a clear integration path.
