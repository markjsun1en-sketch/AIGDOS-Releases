# Cursor Runtime Profile — Context Loading

## Purpose
This document defines how to keep Cursor sessions narrow enough for practical work while still loading the right operational context.

## Loading pattern

Cursor context should be staged in 3 bands mirroring Codex's band structure (REV-4-014, 2026-04-22):

### Band 1 — mandatory startup context
Always load before any agent thread starts:
- `docs/00_entry/START_HERE.md`
- `docs/00_entry/AI_Game_Dev_OS_v4.89_Overview.md`
- `docs/06_runtime_profiles/cursor/RULE_LOADING.md` + `WRITEBACK_POLICY.md`
- `config/profiles/cursor.json`
- selected project starter (`docs/07_starters/cursor/Cursor_Starter_Guide.md` + `starters/cursor/*`)

### Band 2 — sprint execution context
Load when the current sprint work begins:
- current Sprint brief / task list
- affected `skills/_generic_core/<subsystem>/*` for the subsystem(s) in scope
- `docs/04_integrations/Git_Agent_Workflow_Baseline.md` (branch / merge discipline)
- `docs/04_integrations/TAPD_Integration_Baseline.md` (only if TAPD is in use)
- relevant `docs/09_beta_sprint/*` checklists

### Band 3 — deep reference context
Only pull these when needed:
- merge-plan documents
- archived notes
- old RC lineage notes
- historical migration notes unrelated to the current task
- full `docs/03_runtime_core/*` specs (usually only needed during incident / recovery)

## Preferred context shape
Cursor benefits from clear local scope. Use concise rule docs, explicit task briefs, and a limited file set for any one agent thread.

## Worker context handoff
Each agent should receive:

- the task id,
- affected directories,
- validation commands,
- merge/writeback restrictions,
- any sandbox or approval notes.

## Recovery note
When Cursor work becomes noisy, reduce scope before adding more background.
