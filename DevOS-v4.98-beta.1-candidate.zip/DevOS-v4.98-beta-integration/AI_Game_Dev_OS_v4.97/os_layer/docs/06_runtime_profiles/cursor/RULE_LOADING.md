# Cursor Runtime Profile — Rule Loading

## Terminology (REV-4-009, 2026-04-22)

Cursor profile uses the following terminology consistently across its docs and JSON config. Earlier drafts mixed three near-synonyms; this section is the tie-breaker.

| Term | Used in | Meaning |
| --- | --- | --- |
| `coordinator` | Prose docs (PARALLEL_AGENT_WORKTREE_MODEL.md / WRITEBACK_POLICY.md / this file) | The human-readable name for the control role in the Cursor profile. Owns merge order, review checkpoints, external writeback, cleanup. |
| `reviewed_apply_owner` | `config/profiles/cursor.json` field `writeback_owner` | Schema-enum name for the same role, used when the role acts as writeback owner (emphasizes the "reviewed apply" verification step). |
| `parent` | `config/profiles/cursor.json` field `cleanup_owner` | Schema-enum name for the same role, used when the role acts as cleanup owner (inherited from the generic multi-profile cleanup enum). |

All three refer to the **same person / session / agent instance**. The JSON fields use enum names chosen for cross-profile comparability; the prose docs use `coordinator` for readability. When in doubt, the JSON field values are authoritative for tooling and `coordinator` is authoritative for human reading.

## Purpose
This document explains how v4.89 should load operating rules when Cursor is the selected runtime. Cursor should be treated as a profile with its own rule carriers, not as a generic substitute for Codex or Claude Code.

## Primary rule carriers
Cursor projects should prefer these layers:

1. shared portable-core governance documents,
2. Cursor project rules and team rules,
3. repository starter files for the selected project,
4. task-specific brief and Beta Sprint checklists.

## Rule design principle
Cursor rule files should emphasize:

- execution boundaries,
- branch/worktree isolation,
- serial apply or merge discipline,
- sandbox or approval boundaries,
- audit obligations.

## Avoid
- mixing Claude hook language into Cursor rules,
- using team-coordination language (e.g. "lead" / "teammates" / "team mode") that comes from coordination-centric profiles — Cursor is a **parallel-agent-plus-coordinator** model, not a team model; use `coordinator` and `parallel agent` terminology instead (see `PARALLEL_AGENT_WORKTREE_MODEL.md`),
- letting ad hoc prompts replace repository policy.

> **Note (REV-4-005, 2026-04-22)**: earlier drafts of this doc stated "Team Mode terms belong to Workbuddy", implying Team Mode was a Workbuddy-private concept. That was inaccurate — `claude_code_agent_teams` is a public profile that legitimately uses lead/teammate semantics, and Workbuddy's `TEAM_MODE_MODEL.md` is explicitly a private-runtime concept per REV-1-006. The reason Cursor should avoid team-style language is **Cursor's own model is parallel-agent-with-coordinator**, not "team terms are reserved". This rewording removes the false boundary claim while preserving Cursor's terminology discipline.

## Beta Sprint expectation
Cursor can support parallel exploration, but the governing rules should still centralize final merge and writeback decisions.
