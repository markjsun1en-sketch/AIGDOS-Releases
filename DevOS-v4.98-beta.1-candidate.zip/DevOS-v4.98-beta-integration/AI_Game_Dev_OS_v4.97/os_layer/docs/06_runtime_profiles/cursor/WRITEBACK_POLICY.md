# Cursor Runtime Profile — Writeback Policy

## Default policy
Cursor should treat writeback as a **reviewed coordinator action** rather than a background agent privilege.

## Covered targets
- TAPD state updates
- merge-complete reflections
- sprint-close state transitions
- archive operations

## Minimum chain
validate → write → verify → audit.

## Rationale
Cursor supports strong parallel work patterns, so external writeback should remain conservative to avoid drift between multiple ongoing worker branches.
