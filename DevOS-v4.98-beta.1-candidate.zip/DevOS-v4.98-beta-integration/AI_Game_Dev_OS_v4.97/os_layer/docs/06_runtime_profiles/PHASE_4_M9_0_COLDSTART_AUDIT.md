# Phase 4 Step 3 — M9.0 Sprint+Agent Cold-start Audit

> **Status**: Phase 1 audit landed (commit M9.0.1). Code change starts at M9.0.2.
> **Plan file**: `~/.workbuddy/plans/electric-thunder-turing.md`
> **Parent spec**: `V4_89_PHASE_4_PLAN.md` §四
> **Baseline anchor**: HEAD `ec25d58` / tag `v4.89-phase-4-skills` (anchor `66c8024`) / pytest 192 / v4.88_Release byte-lock `58346b3`
> **Source root for backport**: `/Users/macsun/lessismore/`

---

## 1. Re-aligned Proposition (overrides parent spec §四)

Parent spec premise — **"31 SKILL.md cold-start is too costly, M9.0 should promote per-sprint subset of skills into AGENTS.md"** — is rejected after Phase 1 audit. Reasons:

1. SKILL.md aggregate body is ~93 KB across 31 files (28 generic_core + 3 godot). Cold-start cost is not the dominant context bottleneck.
2. The candidate source named in parent spec — lessismore project's three-piece-set under `startup_context_optimization_draft/` — does **not** govern SKILL.md at all. It governs **sprint context** (task / blocker / handoff / archive rollups) and **agent boot** (cold-start pack invocation). There is zero auto-promotion of skill summaries into AGENTS.md in the candidate source.
3. v4.89 OS currently has **zero sprint + agent cold-start governance**. No `runtime/registries/`, no `tasks/sprint_board.md`, no `tools/runtime/` cold-start tooling, no `runtime/config/context_profiles_manifest.json`. The real engineering need is to install this governance baseline so future projects inherit it on day one.

**M9.0 real proposition (locked)**:
> Backport lessismore's sprint + agent cold-start governance — both the live cold-start pack toolchain (`generate_cold_start_pack.py` 749 LoC + `boot_agent_thread.py` 69 LoC) and the draft optimisation three-piece-set (rollup script + 3-profile manifest + AGENTS_MD_ONLY promotion) — into v4.89 OS, scrubbed of project lexicon, rewritten for v4.89 conventions. SKILL.md governance stays untouched (M8.0 final).

---

## 2. EP Locked Decisions (Phase 1 Q&A)

| # | Question | Lock | Rationale |
|---|---|---|---|
| Q1 | M9.0 scope | **B = sprint context only** | Skill governance not the real bottleneck; lessismore source is sprint-centric. |
| Q2 | Cold-start ingest | **B = draft three-piece-set + live cold-start pack** | Rollup-only is incomplete; must include pack to close the loop. |
| Q3 | lessismore artifact treatment | **A = backport registry instances**, scrub project lexicon | v4.89 has no registry; instances ship as scrubbed empty skeletons. |
| Q4 | Profile adaptation | **A = each of v4.89's 6 profiles gets sprint cold-start fields** | Same pattern as M7.3 contract surface: producer ≠ consumer, every profile declares. |
| Q5 | Source-code style for `generate_cold_start_pack.py` | **B = blind rewrite** (~400-500 LoC) | 749 LoC has ~25 hardcoded business items; cp+scrub leaves dirty code, blind rewrite is cleaner. |
| Q6 | Init hook | **B = init writes `sprint_window_state.json`** | Couples M7.3 contract surface logic with sprint window cold-start; mirror regen + R1 16-row re-lock required. |

---

## 3. lessismore Source Map

### 3.1 Draft three-piece-set (`/Users/macsun/lessismore/startup_context_optimization_draft/`)

| File | LoC | Bytes | Role |
|---|---:|---:|---|
| `tools/runtime/generate_sprint_context_rollup.py` | 316 | ~11 KB | Rollup: read `sprint_board.md` + 4 registry JSON + `logs/handoffs/` → emit `sprint_context_rollup.json` + `archive_index.json`. |
| `runtime/config/context_profiles_manifest.json` | 85 | ~2.8 KB | 3 profiles: `SPRINT_GOVERNED` (default) / `SPRINT_DEEP` / `ARCHIVE_LOOKUP`. Fields: `load_width_policy / context_files / dynamic_context / on_demand_files / limits / auto_escalate_to_on_demand`. |
| `AGENTS_MD_ONLY_PROMOTION_GUIDE.md` | 132 | ~4 KB | Manual promote `cp draft/AGENTS.md AGENTS.md`; preserves 16 agents + 9 role fields. |
| `runtime/registries/sprint_context_rollup.json` (generated) | 248 | 22 KB | Output of rollup script. |
| `runtime/registries/archive_index.json` (generated) | 1273 | 44 KB | Lookup index for 364 historical handoff files. |
| `AGENTS.md` (draft, compressed live) | 647 | 26 KB | Adds §1.21 Sprint-Driven Context Window. |

**Status**: `draft_only_not_live`. No pytest. Manual promotion only.

### 3.2 Live cold-start toolchain (`/Users/macsun/lessismore/tools/runtime/`)

| File | LoC | Role |
|---|---:|---|
| `boot_agent_thread.py` | 69 | argparse front (`--agent / --thread / --task-id / --issue-id / --profile`); subprocess-launches `generate_cold_start_pack.py`; emits final pack JSON with `boot_mode / cold_start_performed / boot_source` keys. |
| `generate_cold_start_pack.py` | 749 | 30+ helpers; reads task_registry / blocker_registry / handoff_queue / project_status_snapshot; emits 18-key pack JSON. |
| `_runtime_common.py` | 168 | RuntimeContext + load_json / load_markdown helpers; shared by both scripts. |

### 3.3 Live runtime artifacts (route β backport sources)

| Artifact | Path | LoC / Bytes |
|---|---|---:|
| `tasks/sprint_board.md` | `/Users/macsun/lessismore/tasks/sprint_board.md` | 217 / ~50 KB |
| `runtime/registries/handoff_queue.json` | `/Users/macsun/lessismore/runtime/registries/handoff_queue.json` | 6271 / 248 KB |
| `runtime/registries/project_status_snapshot.json` | `/Users/macsun/lessismore/runtime/registries/project_status_snapshot.json` | 953 / 68 KB |
| `runtime/registries/task_registry.json` | implied (read by generate_cold_start_pack.py) | — |
| `runtime/registries/blocker_registry.json` | implied | — |
| `logs/orchestrator_log.md` | live narrative trace | 99 KB |
| `logs/handoffs/` | 56 active handoff `.md` | — |
| `logs/handoffs/archive/` | 364 archived handoff `.md` | — |
| `AGENTS.md` (live) | project root | 828 LoC |

---

## 4. Hardcoded Business Lexicon Inventory (scrub list, ~25 items)

These items in `generate_cold_start_pack.py` (749 LoC live) must NOT survive backport. Q5=B blind rewrite avoids per-line scrub by simply not transcribing them; the inventory below is the negative checklist for M9.0.5 acceptance.

### 4.1 Task / issue regex (move to `runtime/config/task_id_pattern.json`)
- `TASK_PATTERN = re.compile(r"\bSP-\d+\b")` (L14)
- `ISSUE_PATTERN = re.compile(r"\b(?:QA|NUM|MAP|ENM|ORCH)-\d+\b")` (L15)

### 4.2 Card Roguelike domain hints (drop entirely)
21 hint words used by `signal_has_hint()` for routing context-pack files:
`battle / card / combat / deck / enemy / encounter / event / gamestring / gourd / item / localization / map / numeric / relic / reward / roguelike / shop / status / worldmap / 卡牌 / 战斗`

### 4.3 lessismore Workflow doc numbers (drop)
Hardcoded into `STANDARD_CONTEXT_FILES` (L35-55) and `LEAN_CONTEXT_FILES` (L21-30):
- `Docs/Workflow/79_PROJECT_ADAPTATION_SUMMARY.md`
- `Docs/Workflow/80_WORKFLOW.md`
- `Docs/Workflow/81_VALIDATION_MATRIX.md`
- `Docs/Workflow/82_RE_ENTRY_PROTOCOL.md`
- `Docs/Workflow/125_…135_` (11 numbered v4.8.2 transition docs)
- `Docs/Workflow/138_Workflow_Document_Status_Map.md`

### 4.4 lessismore-specific filenames (drop)
- `CARD_ROGUELIKE_MAPPING_FILE = "Docs/Workflow/139_Card_Roguelike_Starter_Local_Mapping.md"` (L57)
- `CARD_ROGUELIKE_BATCH_POLICY_FILE = "Docs/Workflow/131_Card_Roguelike_Content_Batch_And_Simulation_Policy.md"` (L58)

### 4.5 Pack output keys to drop (lessismore-only)
From the 18-key live pack JSON, drop keys that only make sense for the lessismore game:
- `card_roguelike_*`
- `gourd / relic / deck` references inside `not_in_scope` and `runtime_refs`

### 4.6 v4.89 retains (12-key target pack)
`primary_task / secondary_candidate_tasks / latest_handoff / open_blockers / standard_context_files / contextual_policy_files / task_context_files / must_read_files / runtime_refs / suggested_next_step / not_in_scope / agent_log_current_task / recent_active_entries / boot_mode / cold_start_performed / boot_source / confidence / task_reset_warning`

---

## 5. v4.89 Current State Inventory

### 5.1 Profile JSON (no sprint cold-start fields anywhere)
6 profiles in `AI_Game_Dev_OS_v4.89/config/profiles/`:
- `codex.json`
- `cursor.json`
- `claude_code_agent_teams.json`
- `claude_code_subagents.json`
- `workbuddy_private.json`
- `default_beta_codex_tapd_git.json`

`grep -liE 'skill|cold_start|sprint_window|manifest|rollup' config/profiles/*.json` → 0 matches.

### 5.2 init flow extension point
`AI_Game_Dev_OS_v4.89/scripts/init_runtime_env.py`:
- `_load_profile_ground_truth(profile)` at L395 — current M7.3 helper, returns parsed profile JSON.
- `_stub_init(args, config_data)` at L425 — current M7.3 writer of contract surface fields. Q6=B extends here.
- `_CONTRACT_SURFACE_FIELDS` constant — Q6=B adds `sprint_window_state` field name.

### 5.3 Missing infrastructure (M9.0 creates)
- `AI_Game_Dev_OS_v4.89/runtime/registries/` — does not exist.
- `AI_Game_Dev_OS_v4.89/runtime/config/context_profiles_manifest.json` — does not exist.
- `AI_Game_Dev_OS_v4.89/runtime/config/task_id_pattern.json` — does not exist.
- `AI_Game_Dev_OS_v4.89/tasks/` — does not exist.
- `AI_Game_Dev_OS_v4.89/logs/` — does not exist.
- `AI_Game_Dev_OS_v4.89/tools/runtime/` — does not exist.

### 5.4 Test baseline
- pytest 192 passed (post M8.0).
- `tests/test_init_writes_contract_surface.py` — 14 cases (M7.3 baseline).
- No cold-start / rollup / boot-pack / sprint-window test exists.

### 5.5 AGENTS.md status
- v4.89 OS core does **not** ship a live `AGENTS.md`. Templates exist under `docs/07_starters/workbuddy_private/AGENTS.md.template` and inside `trial_workspaces/*/`.
- Implication: M9.0 does not need to ship a live AGENTS.md. The §1.21 Sprint-Driven Context Window concept will be expressed through `runtime/config/context_profiles_manifest.json` instead.

---

## 6. M9.0 8-commit Chain Outline

| # | Commit subject | Net change |
|---|---|---|
| **M9.0.1** | `docs(v4.89): M9.0 Phase 1 audit — lessismore β-route, 6 locked decisions` | This file. 0 source code change. |
| M9.0.2 | `feat(v4.89): backport sprint runtime registry skeleton from lessismore` | 5 registry JSON + sprint_board.md template + logs/ skeleton + task_id_pattern.json + registries/README.md. |
| M9.0.3 | `feat(v4.89): add context_profiles_manifest.json (3 sprint mode)` | manifest JSON + 6 profile JSON each get `sprint_cold_start` block. |
| M9.0.4 | `feat(v4.89): rewrite generate_sprint_context_rollup.py + boot_agent_thread.py` | `_runtime_common.py` + `generate_sprint_context_rollup.py` + `boot_agent_thread.py` (~500 LoC total). |
| M9.0.5 | `feat(v4.89): rewrite generate_cold_start_pack.py for v4.89 conventions` | `generate_cold_start_pack.py` (~450 LoC) + 1 fixture set. |
| M9.0.6 | `feat(v4.89): init writes sprint_window_state.json (Q6=B hook)` | `init_runtime_env.py` extended; mirror regen for 6 positive + 4 negative trial workspaces; R1 16-row re-locked; +6 init contract tests. |
| M9.0.7 | `test(v4.89): cold-start governor pytest coverage` | 3 test files + fixtures; pytest crosses 210+. |
| M9.0.8 | `docs(v4.89): MATURITY §3.7 + CHANGELOG + parent-spec §四 close + TAG_NOTE` | docs landing; tag deferred to EP manual cut. |

---

## 7. Forbidden Zones (carry from plan §6)

- Phase 1 11 permanent contracts — untouched.
- v4.88_Release byte-lock `58346b3` — every commit verifies.
- Stage 2 charter §5.2 — untouched.
- 8 existing tags — only new tag `v4.89-phase-4-coldstart` cut by EP at M9.0.8 +1.
- M8.0 skills/ tree — read-only; no SKILL.md churn.
- M7.3 contract surface logic — extended (sprint_window_state added) but not rewritten.

---

## 8. Acceptance for M9.0.1

- [x] This audit document landed under `docs/06_runtime_profiles/`.
- [x] 0 source code change.
- [x] pytest 192 passed (unchanged).
- [x] v4.88_Release byte-lock `58346b3` unchanged.
- [x] Parent spec §四 reproposition recorded with EP rationale.

---

## 9. References

- Plan file: `/Users/macsun/.workbuddy/plans/electric-thunder-turing.md`
- Parent spec: `/Users/macsun/Documents/AI_DEV_OS_Evolve/V4_89_PHASE_4_PLAN.md` §四
- M7.3 audit: `docs/06_runtime_profiles/PHASE_4_LIFT_GATE_AUDIT.md`
- M8.0 audit: `docs/06_runtime_profiles/PHASE_4_M8_0_SKILLS_AUDIT.md`
- M8.0 tag note: `docs/06_runtime_profiles/TAG_NOTE_v4.89-phase-4-skills.md`
- lessismore live cold-start pack: `/Users/macsun/lessismore/tools/runtime/generate_cold_start_pack.py`
- lessismore draft three-piece-set: `/Users/macsun/lessismore/startup_context_optimization_draft/`
