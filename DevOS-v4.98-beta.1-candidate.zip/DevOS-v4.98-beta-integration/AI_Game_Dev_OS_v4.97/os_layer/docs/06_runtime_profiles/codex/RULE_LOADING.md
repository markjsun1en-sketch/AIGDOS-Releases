# Codex Runtime Profile — Rule Loading

## Purpose
This document defines how the v4.89 Codex runtime profile loads operating rules, project constraints, and task-specific instructions. The goal is to make Codex predictable during a Beta Sprint by ensuring that rule loading is explicit, layered, and reviewable.

## Rule loading order
Codex should load rules in the following order:

1. **Portable Core** documents that define non-negotiable governance and recovery constraints.
2. **Project-level entry documents** such as `START_HERE.md`, `EXECUTION_PROFILE_SELECTION.md`, and the selected starter guide.
3. **Codex runtime profile** documents in `docs/06_runtime_profiles/codex/`.
4. **Repository-local AGENTS instructions** from the Codex starter.
5. **Task-specific brief** for the current task, sprint wave, or repair action.

The later layer may add detail, but it must not silently override portable-core rules unless the override is documented and approved.

## Expected rule carriers
Codex-specific rule loading should prefer the following carriers:

- `AGENTS.md` and related repository instruction files.
- task brief markdown injected by the current sprint workflow.
- small, deterministic helper files rather than giant narrative docs.

The Beta Sprint assumption is that Codex performs best when rule files are short, explicit, and close to the repository root.

## Required rule classes
Every Codex project should make sure the following rule classes are present:

- **Boundary rules**: what a worker may not do.
- **Writeback rules**: what must be routed through parent review.
- **Merge rules**: serial merge only.
- **Audit rules**: required logging and evidence collection.
- **Recovery rules**: what to do after failed commands, partial edits, or broken worktrees.

## Anti-patterns
Avoid these patterns:

- hiding critical rules only inside long historical documents.
- mixing Codex-specific behavior with Workbuddy or Claude-specific terms.
- letting task prompts implicitly replace repository rules.
- giving workers permission to write external state without a parent check.

## Beta Sprint operating expectation
For the default Codex + TAPD + Git profile, the parent session owns final writeback, merge, and sprint-close transitions. Subagents may draft, validate, or prepare change sets, but they should not be treated as autonomous finalizers.

## Review checklist
Before using the Codex profile, verify that:

- the Codex starter guide exists.
- repository rule files are present.
- the selected execution profile matches `codex`.
- the Beta Sprint guide points at Codex as the default runtime.
