# Codex Runtime Profile — Context Loading

## Purpose
This document describes how context should be loaded for Codex so that workers have enough information to act without flooding the session with unnecessary background material.

## Context loading principle
Codex context should be loaded in three bands:

### Band 1 — mandatory startup context
These files should always be read first:

- `docs/00_entry/START_HERE.md`
- `docs/00_entry/EXECUTION_PROFILE_SELECTION.md`
- `docs/00_entry/CORE_OS_DIGEST.md`
- selected runtime profile documents under `docs/06_runtime_profiles/codex/`
- selected starter guide under `docs/07_starters/codex/`

### Band 2 — current sprint execution context
Load only the documents needed for the active sprint wave:

- current TAPD / Git workflow baseline docs
- current task list or task registry slice
- current audit and checklist files

### Band 3 — deep reference context
Only pull these when needed:

- merge-plan documents
- archived notes
- old RC lineage notes
- historical migration notes unrelated to the current task

## Preferred Codex loading strategy
Codex should prefer **small, referenced entry files** over giant narrative boot prompts. The recommended pattern is:

1. load digest and profile selection,
2. load the selected runtime profile,
3. load the relevant starter,
4. load task-specific materials,
5. only then fetch deep reference docs.

## Subagent context rule
A Codex subagent should receive:

- the selected runtime profile summary,
- a narrow task brief,
- the exact file or directory scope,
- merge and writeback constraints,
- any required validation steps.

A subagent should not inherit the entire project history by default.

## Failure recovery
If Codex shows signs of context drift, the first recovery step is to reduce the scope of loaded files and re-anchor the worker on:

- current task id,
- current execution profile,
- current writeback owner,
- current validation target.

## Review checkpoint
The project is ready for Codex trial use only if the startup readset can be described in under one page and the deep reference set can remain optional for day-one work.
