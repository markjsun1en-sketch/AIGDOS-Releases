# Codex Runtime Profile — Subagent & Worktree Model

## Purpose
This document defines the expected execution model for Codex in v4.89: **parent-driven subagents with isolated worktrees and serial merge discipline**.

## Model summary
- Parent session owns orchestration.
- Subagents own bounded task execution.
- Worktrees are the default isolation unit for code-writing work.
- Merge back to the main branch is serial and parent-owned.

## Why this model
The Beta Sprint baseline assumes that Codex performs best when exploration and implementation are parallelized, while branch integration and external state writeback remain centralized.

## Worker classes
### Parent session
Responsible for:

- selecting the execution profile,
- assigning tasks,
- deciding merge order,
- running final writeback,
- approving sprint-close transitions.

### Subagent worker
Responsible for:

- bounded implementation,
- local validation,
- evidence capture,
- handing back diffs, notes, and unresolved blockers.

### Worktree
Represents an isolated edit surface for code or config changes. One worktree should map to one task or one coherent change group.

## Required constraints
- multiple subagents must not edit the same writable checkout.
- parent must not merge two unresolved worktrees in parallel.
- external PM writeback must not be delegated to anonymous worker state.
- worktrees should be cleaned **by the parent session only** (matches `config/profiles/codex.json` `cleanup_owner: parent`), and only after merge status and audit capture are complete.

## Cleanup ownership (REV-4-008, 2026-04-22)

The parent session owns worktree cleanup. Specifically:

- **Trigger**: after `merge.apply` event is emitted AND `merge.cleanup` event has not yet been emitted for the subagent's worktree
- **Owner**: parent session (not subagent, not external script)
- **Operation**: `git worktree remove <path>` + optional branch delete per `Git_Agent_Workflow_Baseline.md` §Stale Branch Policy (REV-3-009)
- **Evidence**: emit `merge.cleanup` audit event with `actor="parent_session"` and `branch_deleted=<branch>` field

Subagents must NOT attempt cleanup of their own worktree — their process may terminate before cleanup completes, leaving stale worktrees. Delegating cleanup to anyone other than the parent creates gaps in the audit trail (who cleaned, when, was it before or after merge?).

Cleanup failures (permission errors, worktree still checked out elsewhere) follow `RECOVERY_SOP.md` escalation rules.

## Common task shapes
This model is especially suitable for:

- multiple bounded engineering tasks,
- design doc drafting alongside code changes,
- trial implementation + review loops,
- Beta Sprint wave execution.

It is less suitable for tightly coupled same-file simultaneous editing.

## Recovery rules
When a worktree diverges or becomes unclear:

1. capture current status,
2. stop further merge attempts,
3. mark the worktree as blocked,
4. reconcile against the parent branch,
5. only then resume.

## Acceptance criteria
The Codex runtime profile is considered ready when the project can:

- launch at least two isolated workers,
- collect their results independently,
- serially merge them without breaking the task registry,
- preserve audit evidence for each merge.
