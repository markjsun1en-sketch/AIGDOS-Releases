# Codex Runtime Profile — Recovery SOP

## Purpose
This SOP defines how to recover when a Codex session, subagent, or worktree drifts, stalls, or leaves partial state behind.

## Recovery triggers
Use this SOP when any of the following happens:

- a subagent edits the wrong scope,
- a worktree cannot be merged cleanly,
- validation results are incomplete,
- TAPD writeback is uncertain,
- the parent session loses confidence in worker context.

## Recovery sequence
### Step 1 — stop forward motion
Do not continue parallel edits while state is uncertain.

### Step 2 — capture evidence
Record:
- current task id,
- current branch/worktree,
- files changed,
- last successful validation,
- whether external writeback occurred.

### Step 3 — re-anchor
Reload:
- `START_HERE.md`
- execution profile selection
- Codex profile summary
- current task brief

### Step 4 — reconcile branch state
Decide whether to:
- continue in the same worktree,
- discard the worktree,
- recreate the worktree from parent,
- split the task into smaller units.

### Step 5 — verify external state
If TAPD or other external PM state may have been changed, run verification before resuming.

### Step 6 — log the recovery event
Add an audit note so the next review can see what happened.

## Non-goals
Recovery is not the same as silently forging ahead. The purpose is to reduce drift, not to hide it.
