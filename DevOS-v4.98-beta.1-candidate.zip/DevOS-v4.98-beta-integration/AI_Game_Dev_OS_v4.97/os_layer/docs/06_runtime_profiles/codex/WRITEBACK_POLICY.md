# Codex Runtime Profile — Writeback Policy

## Default owner
For the default Codex Beta Sprint profile, **the parent session is the writeback owner**.

## Covered writeback targets
This policy applies to:

- TAPD story/task state updates,
- sprint-close transitions,
- archive operations,
- merge-complete status reflections,
- final audit and summary generation.

## Worker rule
Subagents may prepare writeback recommendations, but they should not be treated as final authorities for external PM state.

## Required verification chain
Every writeback should follow this sequence:

1. validate mapping,
2. write external state,
3. read after write,
4. confirm expected final state,
5. capture audit evidence.

## Exceptions
Limited exceptions are allowed only if a task-specific policy explicitly grants writeback to a reviewed helper process and the resulting state is still verified by the parent.

## Why this matters
The TAPD evidence already showed that silent acceptance of invalid values is possible. Centralizing writeback reduces accidental drift between runtime truth and external collaboration layers.
