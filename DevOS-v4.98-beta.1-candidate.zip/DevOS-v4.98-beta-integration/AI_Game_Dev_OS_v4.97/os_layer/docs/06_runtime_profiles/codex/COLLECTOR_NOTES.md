# Codex Collector Notes

> Added 2026-04-22 to close REV-3-015 (Audit Collector not portable —
> per-profile notes missing).

## Binding

- **Collector script**: `runtime/observability/runtime_event_collectors/codex_collector.py` (SCAFFOLD)
- **Runtime profile**: `codex` (`config/profiles/codex.json`)
- **Event schemas emitted**: `mcp_audit_log.schema.json` + `external_sync_audit.schema.json`

## Collection mode

**Inline / synchronous**. Codex profile runs as a main session with direct process control; collector reads from the main session's in-memory event list at defined hook points and normalizes into the shared event schema.

- Trigger: every `runtime.transition`, `external.tapd.write`, `merge.apply` emits an event record directly from the main session's tool-call completion handler
- No polling needed
- No async queue needed
- Failure domain: if the main session crashes, in-memory events are lost — mitigation is to flush-to-disk every N events (default N=10)

## Minimum implementation (Phase 4 GUIDED target)

```python
from dataclasses import asdict
from pathlib import Path
import json

AUDIT_DIR = Path("runtime/logs/audit")

def emit(event: dict) -> None:
    """Append one event dict to the daily audit file."""
    date = event["timestamp"][:10]  # YYYY-MM-DD
    family = event["event_type"].split(".", 1)[0]
    target = AUDIT_DIR / date[:4] / date[5:7] / f"{family}.jsonl"
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")
```

## Codex-specific notes

- The main session has full access to all tool-call results → the collector can enrich events with tool-call latency + retry count
- Codex does NOT spawn parallel subagents → `actor` field is always the main session or an explicit role label set by the prompt
- Codex is well-suited to **inline validation** of audit format (the main session can see its own events immediately and bail if schema violation appears)

## Known limitations

- If the session is multi-turn and the user interrupts mid-tool-call, an event may be recorded with `status=pending` that never resolves → Phase 4 should define a session-end sweep that reclassifies these as `status=interrupted`
- Codex profile has no notion of "handoff between agents" within a single session → `runtime.handoff` events only appear when the session is explicitly passed between users or across sessions

## Cross-references

- `docs/05_observability/Runtime_Event_Collection_Model.md` — shared Collector Protocol interface
- `docs/05_observability/AUDIT_LOG_STANDARD.md` — event family definitions
- `runtime/MATURITY_MATRIX.md` — current SCAFFOLD status + trial-critical subset
