# Claude Code Subagents — Recovery SOP

## Trigger
Run recovery when a subagent:
- fails a hook gate,
- exits with partial worktree state,
- loses its task boundary,
- leaves ambiguous validation evidence.

## Recovery sequence
1. halt additional tool actions,
2. capture hook context and changed files,
3. decide whether to retry, split, or discard,
4. verify external state,
5. log the recovery path.

## Main principle
Recovery should be explicit and hook-aware, not just a manual guess.
