# Claude Code Subagents — Context Loading

## Principle
Subagents should receive task-scoped context, not the entire project history.

## Minimum subagent packet
Each subagent should receive:
- current task id,
- relevant directories,
- required validations,
- hook constraints,
- merge/writeback restrictions.

## Loading order
1. shared startup docs,
2. Claude subagent profile docs,
3. selected starter,
4. task packet,
5. optional deep reference.

## Recovery rule
If a subagent drifts, reissue a smaller packet instead of broadening context indefinitely.
