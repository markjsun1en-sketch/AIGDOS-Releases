# Claude Code Subagents Collector Notes

> Added 2026-04-22 to close REV-3-015.

## Binding

- **Collector script**: `runtime/observability/runtime_event_collectors/claude_subagents_collector.py` (SCAFFOLD)
- **Runtime profile**: `claude_code_subagents` (`config/profiles/claude_code_subagents.json`)
- **Event schemas emitted**: `mcp_audit_log.schema.json` + `external_sync_audit.schema.json`

## Collection mode

**Parent-subagent event aggregation**. Parent session spawns short-lived subagents; each subagent's final message reports a structured event list which parent aggregates.

- Trigger: subagent completion → parent emits collected events
- Polling: not required (request-response model)
- Subagent may NOT emit events directly — they must route through parent per SUBAGENT_BOUNDARY_SPEC.md §authority-boundary
- Parent is the sole audit owner

## Minimum implementation (Phase 4 GUIDED target)

Parent pattern:

```python
subagent_result = invoke_subagent(task)
for event in subagent_result.get("events", []):
    event.setdefault("actor", f"subagent:{subagent_result['role']}")
    emit(event)  # parent-owned emit
```

Subagent final-message contract:

```json
{
  "events": [
    {"event_type": "...", "timestamp": "...", "summary": "...", ...}
  ],
  "role": "code-explorer"
}
```

## Claude Code Subagents-specific notes

- Subagent context is ephemeral — events not reported in final message are lost. Subagent prompts must explicitly enumerate "what events to report."
- `actor` field carries `subagent:<role>` for subagent-originated events; parent-originated events use `actor="main_session"`
- Parallel subagent spawns (when in one parent turn) must all be aggregated before parent emits the next top-level event for ordering stability

## Known limitations

- Subagents cannot observe other subagents' events → cross-subagent correlation happens only at parent-aggregation time
- If the parent crashes mid-aggregation, subagent final messages may still be recoverable from the client log but structured audit is lost — Phase 4 should define a client-log recovery script

## Cross-references

- `docs/02_governance/SUBAGENT_BOUNDARY_SPEC.md` — authority rules
- `docs/05_observability/Runtime_Event_Collection_Model.md`
- `docs/05_observability/AUDIT_LOG_STANDARD.md`
- `runtime/MATURITY_MATRIX.md`
