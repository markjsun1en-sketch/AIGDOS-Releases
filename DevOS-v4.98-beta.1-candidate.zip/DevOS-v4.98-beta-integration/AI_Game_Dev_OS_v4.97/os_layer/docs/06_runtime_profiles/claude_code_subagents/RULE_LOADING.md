# Claude Code Subagents — Rule Loading

## Purpose
This profile assumes Claude Code is used in the **subagents** mode rather than the agent-teams mode.

## Rule carriers
Use the following layers:

1. portable-core governance,
2. Claude-specific runtime profile docs,
3. starter files for Claude subagents,
4. hook configuration,
5. task brief.

## Why hooks matter
Claude Code exposes deterministic hooks, so rule loading should be written to cooperate with pre-tool and lifecycle gates rather than only relying on prose instructions.

## Required rule classes
- subagent boundaries,
- worktree isolation,
- hook ownership,
- parent-owned writeback,
- recovery after failed task completion.
