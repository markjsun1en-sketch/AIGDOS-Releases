# Claude Code Subagents Runtime Profile — Writeback Policy

## Default owner
For the Claude Code Subagents profile, **the main agent (parent session) is the writeback owner**. Subagents are ephemeral and cannot own external PM state.

## Covered writeback targets
This policy applies to:

- TAPD story/task state updates,
- sprint-close transitions,
- archive operations,
- merge-complete status reflections,
- final audit and summary generation.

## Worker rule
Subagents may **prepare writeback recommendations** via their final structured response, but:

- they MUST NOT call external PM APIs directly,
- they MUST NOT commit merges to default branches,
- their recommendations are **inputs** to the main agent, not decisions.

See `docs/02_governance/SUBAGENT_BOUNDARY_SPEC.md` §authority-boundary for the full rule set.

## Required verification chain
Every writeback performed by the main agent follows this sequence:

1. validate mapping (against `integrations/tapd/tapd_config.template.json` or equivalent project config),
2. write external state,
3. read after write (via `runtime/integrations/tapd/read_after_write_verifier.py` per REV-3-013 binding),
4. confirm expected final state,
5. capture audit evidence as `external.tapd.write` + `external.tapd.verify` events per `AUDIT_LOG_STANDARD.md`.

## Subagent → main agent handoff for writeback
When a subagent's work results in a state change that requires external writeback:

1. Subagent final message includes a `writeback_requests` array (see `docs/06_runtime_profiles/claude_code_subagents/COLLECTOR_NOTES.md` event-reporting contract for shape)
2. Main agent reads the array, validates each request against the verification chain above
3. Main agent emits the writeback events with `actor="main_session"` (not the subagent role), because the main agent is accountable for the side effect

## Exceptions
Limited exceptions are allowed only if:

- a task-specific policy explicitly grants writeback to a reviewed helper process, AND
- the resulting state is still verified by the main agent before the subagent turn ends.

## Why this matters
The Claude Code Subagents model spawns short-lived child contexts that terminate at turn end. If a subagent wrote directly to TAPD:

- no one owns the verification step after the subagent terminates,
- the main agent cannot audit a write it did not perform,
- retries and escalation become stateless.

Centralizing writeback in the main agent matches the profile's `writeback_owner: parent` declaration in `config/profiles/claude_code_subagents.json` and the Subagent Boundary Spec authority rules.

## Cross-references

- `config/profiles/claude_code_subagents.json` — `writeback_owner` field
- `SUBAGENT_WORKTREE_MODEL.md` — isolation context this policy operates inside
- `RECOVERY_SOP.md` — what to do when writeback verification fails
- `COLLECTOR_NOTES.md` — how writeback events flow into audit
- `docs/04_integrations/Writeback_Request_Protocol.md` (REV-3-007) — portable 4-tuple protocol (trigger / queue / retry / escalation)
