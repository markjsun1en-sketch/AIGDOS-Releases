# Claude Code Subagents — Subagent & Worktree Model

## Model summary
This profile assumes:
- one main agent coordinates,
- subagents execute bounded work,
- worktree isolation is preferred for code edits,
- merge and external writeback remain with the main agent.

## Strengths
This model is strong when you want deterministic checkpoints through hooks and clear boundaries between exploration and final integration.

## Constraints
- subagents should not become untracked long-lived owners,
- same-file concurrent edits are discouraged,
- cleanup should follow hook-governed review.

## Best fit
Use this model for most Claude-based Beta Sprint work before considering agent teams.
