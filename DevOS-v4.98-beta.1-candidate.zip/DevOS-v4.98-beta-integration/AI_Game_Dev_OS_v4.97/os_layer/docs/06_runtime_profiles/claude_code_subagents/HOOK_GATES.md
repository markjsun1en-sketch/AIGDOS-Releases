# Claude Code Subagents — Hook Gates

## Purpose
This document defines where hook-based enforcement should be placed for the Claude subagents profile.

## Recommended gates
- before tool use for risky commands,
- before task completion for validation checks,
- before worktree removal for evidence capture,
- after task completion for audit logging.

## Mandatory gate topics
Hooks should be able to enforce:
- no external writeback without parent confirmation,
- no merge-finalization without validations,
- no cleanup before audit capture,
- no hidden bypass of starter rules.

## Why this profile uses hooks heavily
Claude Code exposes richer hook-style lifecycle events than the other default profiles, so v4.89 should take advantage of that strength rather than pretending all runtimes are the same.
