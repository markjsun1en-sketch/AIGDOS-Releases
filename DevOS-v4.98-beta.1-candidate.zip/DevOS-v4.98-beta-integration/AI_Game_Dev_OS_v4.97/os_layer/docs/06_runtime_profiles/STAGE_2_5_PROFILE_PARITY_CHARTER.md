# v4.89 Phase 2 Stage 2 — Charter: 5-Profile Parity Hardening

> **Document type**: charter (not an implementation plan)
> **Author**: Kai · **Date**: 2026-05-03 · **Version**: v4.89 Phase 2 Stage 2
> **Prerequisite tag**: `v4.89-phase-2-m5` @ `951b99c` (Stage 1 LTM MVP complete)
> **Target tag**: `v4.89-phase-2-m6` (to be cut at Stage 2 close)
> **Handoff draft**: `.workbuddy/reviews/v4.89_phase_2/STAGE_2_HANDOFF_DRAFT_5_PROFILE_PARITY.md`

---

## §1 Background

### 1.1 Phase 1 leftover

Phase 1 Beta Sprint Hardening closed on 2026-05-02 with tag `v4.89-phase-1` @ `978a5fd`; the 15-commit chain established 11 permanent contracts. But all of those contracts had their E1-E7 verify signal validated on **only one profile — `workbuddy_private`**.

The `BETA_SPRINT_EXIT_CRITERIA.md` in `v4.88_Release` promises 5-profile parity support. That promise has no empirical coverage from Phase 1.

### 1.2 Phase 2 Stage 1 delivery

Stage 1 = the LTM MVP; it populated the foundation of the "retrievable experience layer" (`runtime/ltm/` + `ltm/` corpus + 14 pytest cases). **LTM and 5-profile parity are orthogonal work**, so Stage 1 did not touch the profile dimension.

### 1.3 Stage 2 positioning

Stage 2 = expand the verify coverage of the Phase 1 contracts from **1 profile** to **5 profiles**, so the Beta Sprint Exit Criteria parity promise has code-level evidence.

---

## §2 5-profile roster (source of truth: `config/profiles/*.json`)

| # | Profile ID | Schema key fields | Current verify coverage |
|---|---|---|---|
| P1 | `workbuddy_private` | runtime_type / coordination_model / isolation_unit / writeback_owner / cleanup_owner / merge_mode / rule_loading / context_loading_method | ✅ Phase 1 E1-E7 all green |
| P2 | `codex` | same schema as P1 | ❓ not yet dry-run |
| P3 | `cursor` | same schema as P1 | ❓ not yet dry-run |
| P4 | `claude_code_agent_teams` | same schema as P1 | ❓ not yet dry-run |
| P5 | `claude_code_subagents` | same schema as P1 | ❓ not yet dry-run |

**Not included**:
- `default_beta_codex_tapd_git.json` — a Beta default combo (schema has an extra `audit_collector`); this is a "usage combo", not a "profile". EP may override this default in handoff draft §7 Q1, expanding Stage 2 to 6 combos.

---

## §3 Parity claim

> **Parity claim**: under any of P2-P5, after the Beta Sprint driver runs both SCAFFOLD and GUIDED maturities over the `rh_sprint_sim_01` trial workspace (or a mirror of it), the contract-level verdict of E1-E7 verify must be **equivalent** to P1.

### 3.1 Definition of equivalence

| Category | Must match | Allowed to differ |
|---|---|---|
| Envelope 9-field completeness | ✅ | ✗ |
| `_ev_get` usage (no raw indexing) | ✅ | ✗ |
| Helper scope not exceeded | ✅ | ✗ |
| State path resolution | ✅ | ✗ |
| Audit sink destination | ✗ | ✅ (file vs collector service) |
| Isolation unit's workspace partitioning granularity | ✗ | ✅ |
| Cleanup owner identity | ✗ | ✅ |

### 3.2 A parity violation is a code bug (not a contract difference)

When a profile triggers a contract violation, Stage 2 fixes **code** (makes the profile obey the contract) rather than **contract** (bending the contract to accommodate the profile). If a divergence genuinely requires a contract change, Stage 2 halts immediately and escalates the issue as a Phase 3 pre-requirement for EP to rule on.

---

## §4 Invariants (must stay green throughout Stage 2)

1. **11 permanent contracts untouched** (MEMORY §7.8.2 / §7.8.3 / §7.9 / §7.11 §§12-15).
2. **v4.88_Release byte-lock**: not a single byte changes in the code subrange; doc-subrange edits must be accompanied by advancing `v4.88-release-stable` (or a later stable tag).
3. **LTM corpus not overwritten**: Stage 1's 12 os/failures entries are read-only; Stage 2 appends new entries rather than modifying existing ones.
4. **R1 regression stays green**: after every commit, `pytest -q` must show 45 (or more, if Stage 2 adds tests) cases all green; no reds.
5. **Local branch only**: continue on `revise/phase-1-fork`, do not open a new branch, do not push remote.

---

## §5 Work matrix (candidate; B2 plan to finalise)

### 5.1 Coverage dimensions

```
dim A: profile     × 4   (P2 P3 P4 P5; P1 already baselined)
dim B: maturity    × 2   (SCAFFOLD, GUIDED — MATURE deferred to Phase 3)
dim C: workspace   × 1   (rh_sprint_sim_01 — shared or mirrored)
---
total combos       = 8 dry-runs
```

> **M6.1 refinement (2026-05-05)**: EP Q1 = B (see §7) expands Dim A to 6 profiles (P1-P6) by admitting `default_beta_codex_tapd_git` as P6, lifting the total to **12 combos**. See `STAGE_2_MATRIX_INVENTORY.md` for the authoritative 12-combo list, gap classification, and driver CLI draft.

### 5.2 Candidate milestones

| MS | Action | Est. commits |
|---|---|---:|
| M6.0 | **this file** (charter) + handoff draft | 1 |
| M6.1 | matrix inventory: gap table over 5 profile × 3 maturity × 3 workspace shape | 1 |
| M6.2 | parameterise `beta_sprint_driver.py`: `--profile` `--maturity` `--shape` (P1 behaviour unchanged by default) | 1-2 |
| M6.3 | trial workspace strategy decision (handoff Q2) — **DONE 2026-05-05**: 5 per-profile mirrors + `scripts/mirror_trial_workspace.py` | 1 |
| M6.4 | P2 codex dry-run + divergence dropped into `ltm/failures/` + code fix — **DONE 2026-05-05**: negative mirror `rh_sprint_sim_01__codex_negative/` + 2 codex schema cross-checks (coordination_model + writeback_owner) + postmortem `2026-05-05_codex_silent_pass_blindness.md` | 1 |
| M6.5 | P3 cursor dry-run + same flow — **DONE 2026-05-05**: negative mirror `rh_sprint_sim_01__cursor_negative/` + 2 cursor schema cross-checks (coordination_model + writeback_owner) + postmortem `2026-05-05_cursor_silent_pass_blindness.md` | 1 |
| M6.6 | P4 claude_code_agent_teams dry-run + same flow — **DONE 2026-05-05**: negative mirror `rh_sprint_sim_01__claude_code_agent_teams_negative/` + 2 claude_teams schema cross-checks (coordination_model + writeback_owner) + postmortem `2026-05-05_claude_teams_silent_pass_blindness.md` | 1 |
| M6.7 | P5 claude_code_subagents dry-run + same flow — **DONE 2026-05-05**: negative mirror `rh_sprint_sim_01__claude_code_subagents_negative/` + 2 claude_subagents schema cross-checks (audit_collector + context_loading_method; dimension pair switched from M6.4-M6.6 to avoid codex contract-collision) + postmortem `2026-05-05_claude_subagents_silent_pass_blindness.md` | 1 |
| M6.8 | 5-profile cross R1 regression (pytest parametrize over profile) — **DONE 2026-05-05**: `tests/test_stage_2_regression_r1.py` with 16-row matrix (6 mirror × 2 maturity + 4 negative × GUIDED) + 1 matrix-size lock; subprocess driver invocation; verifies verdict / error_count / warn_count / contract_field set per row | 1 |
| M6.9 | fill MATURITY §3.3 + CHANGELOG + BETA_SPRINT_EXIT with "Stage 2 DONE" — **DONE 2026-05-05**: `runtime/MATURITY_MATRIX.md` §3.3 added (Stage 2 module inventory + outcome) + `docs/09_beta_sprint/BETA_SPRINT_EXIT_CRITERIA.md` "5-profile equivalence" deferred item resolved + Stage 2 close section appended + CHANGELOG §M6.9 entry | 1 |
| — | tag `v4.89-phase-2-m6` — **CUT 2026-05-05**: lightweight tag at M6.9 close commit | 0 |
| M7.0 | Phase 3 Lock-A — G-b2 P6 schema + `_VALID_PROFILES` enum fix — **DONE 2026-05-05**: `default_beta_codex_tapd_git.json` gained `context_loading_method=project_docs_plus_selected_files` + verify.py `_VALID_PROFILES` extended to include P6; P6 mirror regenerated; R1 matrix expected P6/GUIDED `CONDITIONAL/1W` → `PASS/0/0`; 4 §5 inventory tables synced; 4 postmortem footer notes added; **G-b2 RESOLVED**. Phase 3 Lock-B (schema-driven cross-checker audit) is the next milestone | 1 |
| M7.1 | Phase 3 Lock-B — schema-driven cross-checker audit — **DONE 2026-05-05** (tag `v4.89-phase-3-audit`): `runtime/schema_driven_check.py` prototype + `tests/test_schema_driven_equivalence.py` (16 row × byte-identical + 1 size lock = 17 cases) + audit report `ltm/pattern/2026-05-05_phase_3_schema_driven_audit.md`; **byte-identical on first attempt** thanks to `_finding()` reuse + verbatim message phrasing + per-profile tuple emit ordering. EP Q1=A audit-only kept 4 if-tree blocks byte-stable behind `STAGE_2_USE_SCHEMA_CHECKER=1` env switch | 1 |
| M7.2 | Phase 3 Step 2 — collapse 4 per-profile if-tree into schema-driven default path — **DONE 2026-05-05** (tag `v4.89-phase-3-collapse`): `scripts/verify_beta_sprint_exit.py` -103 net lines (124 removed across L504-628; 21 added for top-level import + call site); `STAGE_2_USE_SCHEMA_CHECKER` env switch removed; `_finding()` inlined into `runtime/schema_driven_check.py` (avoids circular import); 4 per-profile cross-check tests + R1 + equivalence test all byte-stable and pass; 4 postmortems gain M7.2 footer note + audit report gains M7.2 footer | 1 |

**Total**: 10-13 commits across 2-3 working sessions.

---

## §6 Success conditions (Stage 2 exit criteria)

All must hold before `v4.89-phase-2-m6` is cut:

- [x] All **12 combos** (Q1=B promoted P6 in) dry-run green at E1-E7 contract-level equivalent to P1; 4 negative mirrors all CONDITIONAL/2 WARN/0 ERROR by design.
- [x] 6 profile × Phase 1 + Stage 1 pytest cases run green (matrix test = `tests/test_stage_2_regression_r1.py` 16 rows + size lock; pytest 144 → **161**).
- [x] Every divergence observed has a corresponding postmortem in `ltm/failures/` and the code side is fixed (4 postmortems M6.4–M6.7 + 4 cross-check blocks).
- [x] v4.88_Release byte-lock preserved (`shasum -c` 539/539 OK / 0 FAILED across all M6 commits).
- [x] Stage 1's 12 LTM entries not overwritten (4 new postmortems append-only to `ltm/failures/`).
- [x] MATURITY §3.3 / CHANGELOG filled in (M6.9 commit).
- [x] BETA_SPRINT_EXIT_CRITERIA's 5-profile promise moved from "documented claim" to "empirical coverage" — Stage 2 close section added, deferred item removed (M6.9 commit).

**Stage 2 closure verdict: ALL CONDITIONS MET (2026-05-05).** Tag `v4.89-phase-2-m6` cut at M6.9 commit.

---

## §7 Open questions (for EP)

1. **Q1**: include `default_beta_codex_tapd_git.json` as a 6th combo? (default: no) — **RESOLVED (B) 2026-05-05**: admitted as P6; Stage 2 now runs 12 combos (6 profile × 2 maturity × 1 shape). See `STAGE_2_MATRIX_INVENTORY.md`.
2. **Q2**: trial workspace strategy — shared `rh_sprint_sim_01` vs per-profile mirrors for P2-P5? (default: shared) — **RESOLVED (B) 2026-05-05**: per-profile mirrors for P2-P6 (5 mirrors under `trial_workspaces/rh_sprint_sim_01__<profile>/`) + P1 keeps the original `rh_sprint_sim_01/` as baseline. Mirror naming: `rh_sprint_sim_01__<profile_stem>`. Generator: `scripts/mirror_trial_workspace.py` (idempotent, part of M6.8 regression reproducibility contract). Rationale: M6.2 driver smoke (commit `970c317`) empirically showed Option A triggers an init-level WARN (`runtime_state profile mismatch`) on every non-P1 combo, polluting the PASS/FAIL signal M6.4-M6.7 need. See `STAGE_2_MATRIX_INVENTORY.md` §5 (M6.3 refinement).
3. **Q3**: should Stage 2 append new patterns to `ltm/pattern/`? (default: only append to `failures/` when triggered; do not proactively add patterns)
4. **Q4**: after Stage 2 passes, should we cut the top-level `v4.89-phase-2` tag or only m6? (default: only m6; save the top-level tag for Phase 3 close)
5. **Q5**: M6.2 driver implementation — new file `scripts/beta_sprint_driver.py` vs extend `scripts/verify_beta_sprint_exit.py`? — **RESOLVED (A) 2026-05-05**: new file chosen on separation-of-concerns grounds; verify.py stays byte-locked as the single-combo contract checker; driver owns (profile × maturity × shape) resolution and delegates via in-process import. See `STAGE_2_MATRIX_INVENTORY.md` §4.3.

EP can sign or amend answers in §9 below, or deliver them in a separate message.

---

## §8 Out of scope (explicit)

- ❌ `top_level=` compatibility-bridge removal (Phase 3 candidate, its own stage).
- ❌ SCAFFOLD → GUIDED promotion for `check_execution_integrity` / `check_external_sync_integrity` (Phase 3 candidate).
- ❌ MATURE maturity tier verification (Phase 3).
- ❌ Phase 3 LTM `replay()` implementation.
- ❌ Phase 4 cross-project LTM platform.
- ❌ Any content changes inside `v4.88_Release`.

---

## §9 EP sign-off / amendments

_(blank, reserved for EP)_

---

## §10 Appendix: key paths

> Paths below use `<DEV_OS_REPO_ROOT>` as a placeholder for the WorkBuddy-side
> dev tree (e.g. `~/Documents/AI_DEV_OS_Evolve/`). Inside an extracted Release
> package, the equivalent files live under `<RELEASE_ROOT>/` directly.

- **Profile JSONs**: `<DEV_OS_REPO_ROOT>/AI_Game_Dev_OS_v4.89/config/profiles/*.json`
- **Profile docs**: `<DEV_OS_REPO_ROOT>/AI_Game_Dev_OS_v4.89/docs/06_runtime_profiles/{workbuddy_private,codex,cursor,claude_code_agent_teams,claude_code_subagents}/`
- **Beta Sprint driver**: `<DEV_OS_REPO_ROOT>/AI_Game_Dev_OS_v4.89/` — `beta_sprint_driver.py` or `verify_beta_sprint_exit.py`
- **Trial workspace**: `<DEV_OS_REPO_ROOT>/AI_Game_Dev_OS_v4.89/trial_workspaces/rh_sprint_sim_01/`
- **Exit criteria**: `AI_Game_Dev_OS_v4.88_Release/.../BETA_SPRINT_EXIT_CRITERIA.md` (the v4.88 subrange; Stage 2 does not edit it)
- **LTM engine**: `AI_Game_Dev_OS_v4.89/runtime/ltm/`
- **Stage 2 handoff draft**: `.workbuddy/reviews/v4.89_phase_2/STAGE_2_HANDOFF_DRAFT_5_PROFILE_PARITY.md`

---

**— CHARTER END —**
