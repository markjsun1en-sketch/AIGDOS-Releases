# TAG NOTE — `v4.89-release-rc1`

> **Purpose**: readiness note for EP's manual tag action finalizing v4.89 Release. This execution thread does not touch git tags; this note documents the exact anchor commit, invariants at tag time, and the verification recipe.

---

## 1. Tag target

- **Tag name**: `v4.89-release-rc1`
- **Commit to anchor**: the HEAD after M10.0.9 docs commit (this note lands last, HEAD at tag time is the M10.0.9 commit)
- **Branch**: `revise/phase-1-fork`
- **Predecessor tag**: `v4.89-phase-4-cross-ltm` (M9.5, also pending EP manual tag)

## 2. What this tag represents

**v4.89 RC1 — Beta Sprint Exit hardening release, frozen.**

This is the first Release Candidate of v4.89. The Release tree (`AI_Game_Dev_OS_v4.89_Release/`) is the clean, self-contained distribution target; the development tree (`AI_Game_Dev_OS_v4.89/`) stays alive as the historical record of how we got here (frozen development-time artifacts: audit docs, TAG_NOTEs for intermediate phases, etc.).

Phases shipped (with per-phase pending tags for EP's convenience):

| Phase | Scope | Pending tag |
|---|---|---|
| Phase 1 | 11 permanent contracts + E1-E7 green | `v4.89-phase-1` (already tagged) |
| Phase 2 Stage 1 | LTM MVP | `v4.89-phase-2-m5` (already tagged) |
| Phase 2 Stage 2 B1 | 5-profile parity | `v4.89-phase-2-stage-2-b1` (already tagged) |
| Phase 3 | Schema-driven cross-checker + collapse | `v4.89-phase-3-audit`, `v4.89-phase-3-collapse` (already tagged) |
| Phase 4 M7.3 | Lift gate | `v4.89-phase-4-lift` (**EP pending**) |
| Phase 4 M8.0 | Skills import | `v4.89-phase-4-skills` (**EP pending**) |
| Phase 4 M9.0 | Cold-start governance | `v4.89-phase-4-coldstart` (**EP pending**) |
| Phase 4 M9.5 | Cross-project LTM Layer A | `v4.89-phase-4-cross-ltm` (**EP pending**) |
| Phase 4 M10.0 | **v4.89 Release freeze** | **`v4.89-release-rc1` (this tag)** |

## 3. Commit chain anchored by the tag (M10.0 sub-chain only)

| Milestone | Commit | Summary |
|---|---|---|
| M10.0.1 | `3bf6df2` | cp v4.89 → v4.89_Release baseline (751 files; pytest 259; byte-lock unchanged) |
| M10.0.6 | `5200891` | 3 Review findings reflowed v4.89 → v4.89_Release + Release-only pytest.ini |
| M10.0.7 | `8ec7342` | RELEASE_NOTES.md for v4.89-release-rc1 |
| M10.0.8 | (M10.0.8+9 commit below) | CHECKSUMS.sha (754 files locked) |
| M10.0.9 | (M10.0.8+9 commit below) | TAG_NOTE_v4.89-release-rc1 (this file) + CHANGELOG Release entry + MATURITY §3.9 |

## 4. Invariants at tag time

| Contract | Status at tag |
|---|---|
| pytest `AI_Game_Dev_OS_v4.89/` | **259 passed** (development tree) |
| pytest `AI_Game_Dev_OS_v4.89_Release/` | **259 passed** (release tree; self-contained via own pytest.ini) |
| v4.88_Release byte-lock SHA `58346b3` | **539/539 OK · 0 FAILED** — unchanged across the entire M10.0 chain |
| v4.89_Release byte-lock | **`CHECKSUMS.sha` · 754 files · 0 FAILED** (generated M10.0.8) |
| Phase 1 eleven permanent contracts | **untouched** |
| Stage 1 LTM 14 pytest cases | **all passing** |
| Stage 2 parametrised parity tests | **all passing** |
| 5 per-profile cross-check tests | **all passing** |
| M9.5 8 namespace pytest cases | **all passing** |
| 19 pre-M9.5 LTM entries | **not migrated** (stay unscoped / globally visible) |
| 9 scrubbed vocabulary terms | **0 matches** in `ltm/project/rh/*.md` |
| `AI_Game_Dev_OS_v4.89/` and `AI_Game_Dev_OS_v4.89_Release/` parity (post-M10.0.6) | Release-only: `pytest.ini` + `RELEASE_NOTES.md` + `CHECKSUMS.sha` + this TAG_NOTE; all other files byte-identical at tag time |

## 5. Review findings recap (all resolved)

| # | Finding | Severity | Resolution |
|---|---|---|---|
| 1 | ASSEMBLY_GUIDE.md references `docs/GOVERNANCE_MAP.md` (path does not exist; real path is `docs/02_governance/GOVERNANCE_MAP.md`) | doc bug | Fixed in v4.89/ + reflowed to Release (M10.0.6) |
| 2 | ltm/INDEX.md capture signature omits `actor` and `requires_approval` kwargs (2 places) | doc drift | Fixed in v4.89/ + reflowed to Release (M10.0.6) |
| 3 | ltm/INDEX.md Life cycle section claims M9.5 Layer A is deferred when it already shipped | doc drift | Fixed in v4.89/ + reflowed to Release (M10.0.6) |
| 4 | Release tree lacks its own pytest.ini, so `cd Release/ && pytest` climbs up to workspace pytest.ini and runs v4.89/tests by mistake | Release hygiene | Added Release-only `pytest.ini` (M10.0.6); NOT reflowed (dev tree intentionally uses workspace root pytest.ini) |

No core-logic bugs. No code behaviour change. 3 doc drifts resolved in-place plus 1 Release-tree self-containment fix.

## 6. Suggested tag command

```bash
# From the workspace root
cd <UPSTREAM_REPO_ROOT>  # e.g. ~/Documents/AI_DEV_OS_Evolve (the workspace root, not the v4.89 subdir)
git checkout revise/phase-1-fork
git log --oneline -1   # verify HEAD == M10.0.9 commit

git tag -a v4.89-release-rc1 -m "v4.89 Release Candidate 1 — Beta Sprint Exit hardening, frozen."
git tag -n v4.89-release-rc1   # verify the annotated tag landed

# Optional bundle of all pending Phase 4 tags (if EP wants to batch them):
git tag -a v4.89-phase-4-lift        <M7.3 commit> -m "Phase 4 Step 1 — M7.3 Lift gate"
git tag -a v4.89-phase-4-skills      <M8.0 commit> -m "Phase 4 Step 2 — M8.0 Skills"
git tag -a v4.89-phase-4-coldstart   <M9.0 commit> -m "Phase 4 Step 3 — M9.0 Cold-start"
git tag -a v4.89-phase-4-cross-ltm   <M9.5 commit> -m "Phase 4 Step 3.5 — M9.5 Cross-Project LTM Layer A"
```

The tag is local-only (the workspace has no remote). No push step is required.

## 7. Verification recipe for external reviewers

```bash
cd AI_Game_Dev_OS_v4.89_Release

# 1. Self-contained pytest
pytest                                               # expect: 259 passed

# 2. Byte-lock self-check
shasum -a 256 -c CHECKSUMS.sha | tail -3             # expect: last line ending with ': OK'
shasum -a 256 -c CHECKSUMS.sha | grep -v ': OK$' | wc -l
                                                     # expect: 0

# 3. v4.88_Release byte-lock still clean (predecessor invariant)
cd ..
shasum -c /tmp/v488_release_baseline.sha 2>&1 | grep -v ': OK$' | wc -l
                                                     # expect: 0

# 4. Lexicon scrub on RH cross-project corpus
grep -riE 'lessismore|Card Roguelike|卡牌|爆衣|限界共鸣|七宗罪|SP-|relic|gourd' \
  AI_Game_Dev_OS_v4.89_Release/ltm/project/rh/
                                                     # expect: no output

# 5. Real-corpus namespace probe
cd AI_Game_Dev_OS_v4.89_Release
python -m runtime.ltm "writeback owner drift" --project rh
                                                     # expect: at least 1 hit under ltm/project/rh/
```

## 8. After the tag

- `AI_Game_Dev_OS_v4.89_Release/` is the distribution target. External consumers grab this directory.
- `AI_Game_Dev_OS_v4.89/` remains as the dev history tree; v4.90 work (Architecture Linter A/B/D, Layer B retrieval, etc.) will branch from a future checkpoint off this tree.
- Next project-level move: begin v4.90 scoping. EP's call whether to open `v4.90/revise/` branch now or park until v4.89 gets field-validated in a real project.

## 9. References

- `AI_Game_Dev_OS_v4.89_Release/RELEASE_NOTES.md` — the canonical public-facing release narrative.
- `AI_Game_Dev_OS_v4.89_Release/CHANGELOG.md` — per-phase commit-level history.
- `AI_Game_Dev_OS_v4.89_Release/runtime/MATURITY_MATRIX.md` — per-script + per-phase maturity ledger.
- `AI_Game_Dev_OS_v4.89_Release/CHECKSUMS.sha` — Release tree shasum baseline.
- `V4_89_PHASE_4_PLAN.md` — parent spec (Phase 4 main-line plan).
- `V4_89_REMAINING_ROADMAP.md` — scope tracking.
