# TAG NOTE — `v4.89-phase-4-skills`

> **Purpose**: handoff note for EP to cut the M8.0 closure tag.
> **EP-only step**: the chain finale commit (M8.0.5) does not auto-cut a tag; per Phase 1 contract, all `git tag` commands are EP-manual.

---

## When to cut

Cut the tag once M8.0.5 (this commit) lands cleanly on `revise/phase-1-fork`. The tag SHOULD anchor the chain finale commit, NOT a follow-up `chore(memory)` commit.

## Suggested command

```bash
cd <UPSTREAM_REPO_ROOT>  # e.g. ~/Documents/AI_DEV_OS_Evolve (the workspace root, not the v4.89 subdir)
git tag -a v4.89-phase-4-skills <M8.0.5-SHA> -m "v4.89 Phase 4 Step 2 — M8.0 Skills 引入

5-commit chain:
- 3f4e465  M8.0.1 audit doc (lessismore-16 vs v4.89-19, Q1-Q4 lock)
- 4c07e0e  M8.0.2 import 9 NEW into _generic_core/ + 3 reference files
- b30133a  M8.0.3 fatten 2 OVERLAP art SKILLs (art-concept 25->282L, image-cleanup 28->65L)
- 439e20b  M8.0.4 _engine_specific/godot/ third-axis (3 SKILL + 11 references + README §10)
- <M8.0.5> M8.0.5 finale (MATURITY §3.6 / CHANGELOG / parent spec §三 ✅ / README final / TAG_NOTE)

Net: _generic_core/ 19 -> 28 SKILL.md (+9 NEW); _engine_specific/godot/ 0 -> 3 SKILL.md + 11 references; 0 lessismore project-residue (verified by grep)."
```

Replace `<M8.0.5-SHA>` with the actual SHA of the M8.0.5 finale commit (find via `git log --oneline -1` immediately after that commit lands).

## Acceptance grid recap

| ID | Item | Status |
|---|---|---|
| E1 | pytest 192 passed across all 5 commits | ✅ verified at every commit |
| E2 | v4.88_Release `58346b3` last-touch unchanged | ✅ verified at every commit |
| E3 | All new SKILL.md frontmatter `name:` kebab-case + matches dirname | ✅ 12 / 12 (9 NEW + 3 GODOT) |
| E4 | 0 lessismore project-residue (lessismore_battle_case / 爆衣 / 限界共鸣 / 七宗罪 / RandomHeroes) in `skills/_generic_core/` + `skills/_engine_specific/` | ✅ grep returns 0 matches |
| E5 | tag `v4.89-phase-4-skills` cut | ⏳ EP manual (this note) |

## After cutting

1. Update `.workbuddy/memory/2026-05-06.md` with the tag SHA + close M8.0 entry.
2. Append a new tag row to `MEMORY.md §7.x` under the v4.89 timeline.
3. The next thread starts at Step 3 (M9.0 Sprint-window cold-start) per parent spec `V4_89_PHASE_4_PLAN.md §四`.

## Reference

- Parent spec: `V4_89_PHASE_4_PLAN.md §三` (now ✅) and `§九` ChangeLog row 3.
- Sibling tag note (Phase 4 Step 1): tag `v4.89-phase-4-lift` was cut at `5793e63` on 2026-05-06 10:37 (no formal TAG_NOTE existed for that one; this is the pattern going forward).
- Audit doc: `docs/06_runtime_profiles/PHASE_4_M8_0_SKILLS_AUDIT.md`.
- Plan file: `~/.workbuddy/plans/stellar-vortex-einstein.md`.
