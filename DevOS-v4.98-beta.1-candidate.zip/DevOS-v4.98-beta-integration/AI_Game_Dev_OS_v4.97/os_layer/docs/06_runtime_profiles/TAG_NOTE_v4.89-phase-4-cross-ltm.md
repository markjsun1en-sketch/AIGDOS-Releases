# TAG NOTE — `v4.89-phase-4-cross-ltm`

> **Purpose**: readiness note for the EP-side manual tag action. The execution thread is prohibited from touching git tags; this file documents exactly what the tag should anchor to and which contracts hold at that point.

---

## 1. Tag target

- **Tag name**: `v4.89-phase-4-cross-ltm`
- **Commit to anchor**: the M9.5.4 docs commit (the HEAD after this note is committed)
- **Branch**: `revise/phase-1-fork`
- **Predecessor tag**: `v4.89-phase-4-coldstart` (M9.0 collapse, also pending EP manual tag)

## 2. What this tag represents

The completion of v4.89 Phase 4 Step 3.5 — **Cross-Project LTM Layer A** — the namespace + cross-ingest skeleton that positions v4.89 as a multi-project LTM substrate before the M10.0 Release freeze.

Layer A scope per EP decision 2026-05-07:
- `project_id` YAML front-matter field (optional; "missing ≡ global" semantic).
- `consult()` and CLI `--project` filter.
- `capture()` Gate rule 5 (project domain requires project_id).
- Per-project directory partition (`ltm/project/<id>/`).
- 4 synthesized RH seed entries + supporting docs.
- 8 namespace pytest cases + lexicon scrub guardrail.

Explicit non-goals (deferred to v4.90): vector retrieval, embedding dependencies, self-evolution loop, auto-replay, multi-project auto-merge.

## 3. Commit chain anchored by the tag

| Milestone | Commit | Summary |
|---|---|---|
| M9.5.1 | `d706049` | consult() + CLI support project_id filter |
| M9.5.2 | `2bcc4f3` | capture() + Gate rule 5 project_id requirement |
| M9.5.3 | `25fc182` | 4 synthesized RH corpus entries + namespace docs |
| M9.5.4 | (HEAD at tag time) | 8 namespace tests + MATURITY §3.8 + CHANGELOG + audit + TAG_NOTE |

## 4. Invariants at tag time

| Contract | Status at tag |
|---|---|
| pytest baseline | **259 passed** (251 + 8 new; 0 regression) |
| v4.88_Release byte-lock (SHA `58346b3`) | **539/539 OK · 0 FAILED** across all 4 commits |
| Phase 1 eleven permanent contracts | **untouched** |
| Stage 1 LTM 14 pytest cases | **all passing** (project_id defaults to None in every pre-existing call site) |
| 5-profile parity cross-check tests | **unchanged** (no profile JSON touched) |
| 19 pre-M9.5 LTM entries | **not migrated** (remain unscoped / globally visible under "missing ≡ global" rule) |
| 11 scrubbed vocabulary terms in `ltm/project/rh/` | **0 matches** (enforced by `test_lexicon_scrub_rh_corpus`) |

## 5. Suggested tag command

```bash
# From the workspace root, not the v4.89 subdir:
cd <UPSTREAM_REPO_ROOT>  # e.g. ~/Documents/AI_DEV_OS_Evolve (the workspace root, not the v4.89 subdir)
git checkout revise/phase-1-fork
git log --oneline -1   # verify HEAD == M9.5.4 docs commit
git tag -a v4.89-phase-4-cross-ltm -m "v4.89 Phase 4 Step 3.5 — M9.5 Cross-Project LTM Layer A"
# Optional: git tag -n v4.89-phase-4-cross-ltm  (to inspect)
```

The tag is local-only (the workspace has no remote). No push step is required.

## 6. After the tag

The next thread starts **M10.0 v4.89 Release freeze** per the parent spec `V4_89_PHASE_4_PLAN.md` §五. M9.5 does not alter M10.0's scope — it enriches the pre-Release corpus. Suggested first-move for the M10.0 thread:

```bash
cd AI_Game_Dev_OS_v4.89
git log --oneline -5                                  # should show M9.5.4 at top
pytest tests/ -q                                      # expect 259 passed
shasum -c /tmp/v488_release_baseline.sha | tail -3    # expect 539/539 OK
cp -r ../AI_Game_Dev_OS_v4.89 ../AI_Game_Dev_OS_v4.89_Release    # M10.0.1 first move
```

## 7. References

- Plan file: `~/.workbuddy/plans/stellar-forging-curie.md`
- Audit doc: `AI_Game_Dev_OS_v4.89/docs/06_runtime_profiles/PHASE_4_M9_5_CROSS_LTM_AUDIT.md`
- MATURITY: `AI_Game_Dev_OS_v4.89/runtime/MATURITY_MATRIX.md §3.8`
- CHANGELOG: `AI_Game_Dev_OS_v4.89/CHANGELOG.md §[v4.89 Phase 4 Step 3.5 — M9.5]`
- Parent spec: `V4_89_PHASE_4_PLAN.md`
