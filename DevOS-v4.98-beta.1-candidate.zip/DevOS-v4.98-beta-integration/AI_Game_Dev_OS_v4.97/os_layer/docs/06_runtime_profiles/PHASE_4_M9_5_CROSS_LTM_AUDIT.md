# Phase 4 M9.5 — Cross-Project LTM Layer A Audit

> **Milestone**: M9.5 "Cross-Project LTM Namespace & Cross-Ingest Skeleton"
> **Completion date**: 2026-05-07
> **Plan file**: `~/.workbuddy/plans/stellar-forging-curie.md`
> **Parent spec**: `V4_89_PHASE_4_PLAN.md` (inserted between M9.0 ✅ and M10.0 Release)
> **Branch**: `revise/phase-1-fork`
> **Commit chain**: `d706049` → `2bcc4f3` → `25fc182` → M9.5.4 (this commit)

---

## 1. Why M9.5 exists

Phase 4's parent spec §八 originally classified "cross-project replay / vector retrieval / self-evolution" as **platform-phase territory, not in this plan**. The user (EP) however marked cross-project LTM as an expected v4.89 deliverable during the planning handoff on 2026-05-07. The natural insertion point was between M9.0 Cold-start (completed) and M10.0 Release (next), so the parent spec gained a new Step 3.5.

The first impulse — implement the full Evolution Roadmap ② ("Long-Term Memory 跨项目扩展") — was rejected after a three-agent Phase 1 audit surfaced a blocking fact: neither RandomHeroes nor lessismore carries an ingestable LTM corpus.

## 2. Phase 1 audit findings (inputs to the Layer decision)

| Audit target | Finding | Implication |
|---|---|---|
| v4.89 current LTM | `ltm/` 5 subdirs (os / project / pattern / failures / _quarantine); `runtime/ltm/` 3 Python modules; 14 pytest cases; **no** `project_id` field in YAML; `ltm/project/<id>/` directory layout already reserved (empty `rh/`) | Namespace scaffolding is half-done — the directory convention is there, the field is not |
| lessismore LTM | No `ltm/` directory. Single file `memory/global_facts.md` with 16 plain-markdown facts, no YAML front-matter, no schema | Cannot ingest as second corpus without normalization |
| RandomHeroes LTM | No `ltm/` directory. `policy/` locked at v4.8.2 Final_Integrated, zero v4.89 references | Cannot ingest as second corpus |
| Workspace root | `.workbuddy/memory/MEMORY.md` + 10 dated daily logs — session memory, not LTM corpus; no workspace-level cross-project registry | No ready-made second project to prove cross-ingest works |

**Net**: a "complete Roadmap ②" landing would require synthesizing a second corpus from scratch AND building vector retrieval AND designing self-evolution. Budget estimate: 12-18 commits / 3-5 working sessions. That is effectively a v4.90 release disguised as a v4.89 milestone.

## 3. Layer decision tree (EP-locked 2026-05-07 11:42 GMT+8)

Three layers were scoped:

| Layer | Scope | Commits | Sessions | Verdict |
|---|---|---:|---:|---|
| **A** | namespace (`project_id` field + consult filter + capture Gate rule 5) + cross-ingest skeleton (per-project directory + 4 seed entries in `ltm/project/rh/`) | 3-4 | 1 | ✅ **selected** |
| B | Layer A + SQLite FTS5 or `sqlite-vec` full-text / vector retrieval | 6-8 | 2 | ⏭ deferred to v4.90 |
| C | Layers A + B + embedding model + cross-project replay API + self-evolution loop | 12-18 | 3-5 | ⏭ deferred to v4.90 |

**Why Layer A wins**:

1. Preserves M10.0 Release cadence (unblocks it instead of delaying).
2. Installs the namespace primitive every higher layer depends on — Layer B/C build on top without revisiting schema.
3. Zero new Python package dependencies — stays within v4.89's "pure stdlib" invariant.
4. Backward-compatible by construction: "missing ≡ global" semantic means the 19 legacy entries don't migrate.
5. Gives v4.89 a real, testable cross-project surface (not just "planned") — M10.0 RELEASE_NOTES can claim `project_id` namespace as a shipped feature, not a roadmap item.

**Why Layer B/C lose in v4.89**:

1. Introducing a vector DB (even sqlite-vec) is a per-install dependency story v4.89 was never scoped for.
2. Self-evolution is a research-grade problem (closing the audit → failure-fix → OS-contract promotion loop automatically). A best-effort v4.89 implementation risks shipping a weak version that must be rewritten for v4.90.
3. The absence of a real second project corpus means Layer B/C success cannot be demonstrated end-to-end — they would ship as "implemented but not validated".

## 4. What Layer A actually ships

### 4.1 Schema extension

- YAML front-matter: `project_id: <lowercase snake_case string>` (optional).
- Directory partition: `ltm/project/<project_id>/<slug>.md` (auto-routed by `capture()`).
- Missing field ≡ global ≡ visible under every project-scoped query. No migration for the 19 pre-M9.5 entries.

### 4.2 API extension

- `consult(query, *, domain=None, limit=10, project_id=None)` — filter drops entries tagged with a *different* project.
- `capture(domain, title, content, *, evidence_ref=None, actor="...", requires_approval=False, project_id=None)` — Gate rule 5: `domain='project'` without `project_id` → quarantine.
- CLI: `python -m runtime.ltm "query" --project <id>` — no `choices=` enforcement.

### 4.3 Corpus seed — `ltm/project/rh/` (four archetype entries)

| Archetype | File | Captured lesson |
|---|---|---|
| pattern (operational discipline) | `2026-05-07_sprint_close_handoff_pattern.md` | Six-slot handoff data structure for sprint close → next-thread resume |
| failure (helper scope) | `2026-05-07_writeback_owner_drift.md` | Adapter helper silently adopted its own identity for orchestrator events |
| failure (two-layer silent-PASS) | `2026-05-07_profile_switch_audit_gap.md` | Stale state + short-circuit gate produced silent-PASS on profile switch |
| failure (cache staleness) | `2026-05-07_mirror_trial_workspace_cold_start.md` | Cache bridging copy/regenerate semantics caused manifest staleness |

Each entry follows the Stage 1 template (Symptom → Root Cause → Fix → Evidence → Lesson) and carries `project_id: rh` in its YAML front-matter.

### 4.4 Tests — `tests/test_ltm_namespace.py` (8 cases)

1. `test_project_id_filter_includes_unscoped` — rh-tagged + untagged both visible under `--project rh`.
2. `test_project_id_filter_excludes_other_projects` — foo-tagged entries hidden under `--project rh`.
3. `test_missing_project_id_is_global` — 19 legacy-style entries visible under every filter value.
4. `test_cli_project_flag_exits_zero` — CLI integration end-to-end.
5. `test_capture_project_domain_requires_project_id` — Gate rule 5 quarantines project-domain captures without project_id.
6. `test_capture_writes_project_id_frontmatter` — explicit project_id emitted in YAML + routed to per-project dir.
7. `test_rh_seed_corpus_consultable` — real-corpus spot check against the M9.5.3 seed entries.
8. `test_lexicon_scrub_rh_corpus` — regression guardrail against future project-vocabulary leaks.

### 4.5 Documentation

- `runtime/MATURITY_MATRIX.md §3.8` — milestone entry.
- `CHANGELOG.md §[v4.89 Phase 4 Step 3.5 — M9.5]` — full decision + commit + test + invariant record.
- `ltm/INDEX.md` — API reference updated; new "Cross-project namespace (Phase 4 M9.5 Layer A)" section.
- `ltm/project/README.md` — "Cross-project inheritance" section rewritten with Layer A semantics.
- `ltm/project/rh/README.md` — directory inventory + namespace declaration (scoped to rh).
- `docs/06_runtime_profiles/PHASE_4_M9_5_CROSS_LTM_AUDIT.md` — this file.
- `docs/06_runtime_profiles/TAG_NOTE_v4.89-phase-4-cross-ltm.md` — tag readiness note.

## 5. Invariants preserved

- Phase 1's 11 permanent contracts — untouched.
- Stage 1's 14 LTM pytest cases — all still green (project_id defaults to None in every pre-existing call site).
- v4.88_Release byte-lock (SHA `58346b3`, 539 files) — 0 FAILED across all 4 commits.
- 5-profile parity cross-check tests — unaffected (no profile JSON touched).
- pytest: 251 → **259 passed** (+8 new / 0 regression).

## 6. Explicit non-goals

This milestone does NOT:

- Add vector retrieval, embedding dependencies, or any non-stdlib package.
- Implement self-evolution / auto-capture / auto-replay.
- Provide cross-project auto-merge or auto-suggest.
- Normalize lessismore or real RH content into a second corpus (the 4 RH entries are synthesized from EP decisions, not from any real project's LTM — because there is no real project LTM to normalize from).
- Touch M9.0 cold-start manifests (the new corpus is consumed by `consult()` only, not by any cold-start wire-up).

These are v4.90 territory.

## 7. What M10.0 Release inherits from M9.5

- A working cross-project namespace (shipped, not "planned").
- One registered project (`rh/`) with 4 seed entries demonstrating the namespace works end-to-end.
- A lexicon scrub guardrail that prevents future edits from leaking project-specific vocabulary into the generic runtime.
- An updated `ltm/INDEX.md` that documents the Layer A API exactly as shipped.

M10.0 RELEASE_NOTES should mention "cross-project LTM namespace (Layer A)" as a Phase 4 deliverable, with a pointer to this audit doc for the Layer B/C deferral rationale.

## 8. References

- Plan file: `~/.workbuddy/plans/stellar-forging-curie.md`
- Parent spec: `V4_89_PHASE_4_PLAN.md`
- Remaining roadmap: `V4_89_REMAINING_ROADMAP.md` (§三 Phase 3 candidates, §超远期 Evolution Roadmap ②)
- MATURITY: `runtime/MATURITY_MATRIX.md §3.8`
- CHANGELOG: `CHANGELOG.md §[v4.89 Phase 4 Step 3.5 — M9.5]`
- Commit chain: `d706049` → `2bcc4f3` → `25fc182` → (M9.5.4 this commit)
