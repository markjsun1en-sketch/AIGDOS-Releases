# TAG NOTE — v4.89-phase-4-coldstart

> **Status**: pending EP manual cut. This thread closes M9.0.8 as the 8-commit chain finale; EP makes the tag command.
> **Anchor commit**: the M9.0.8 docs-close commit (this very commit).
> **Branch**: `revise/phase-1-fork`.

---

## 1. Proposed Tag Command

```
git tag -a v4.89-phase-4-coldstart <M9.0.8 commit sha> \
  -m "v4.89 Phase 4 Step 3 — M9.0 Sprint+Agent Cold-start Governance"
```

Substitute `<M9.0.8 commit sha>` with the output of `git log --oneline -1` taken right after the M9.0.8 docs commit lands. Annotated tag matches M7.3 / M8.0 precedent.

## 2. Commit Chain Covered by the Tag

| # | SHA | Subject |
|--:|---|---|
| 1 | `94680c3` | `docs(v4.89): M9.0 Phase 1 audit — lessismore β-route, 6 locked decisions` |
| 2 | `f11bd74` | `feat(v4.89): backport sprint runtime registry skeleton from lessismore` |
| 3 | `0b7d115` | `feat(v4.89): add context_profiles_manifest.json (3 sprint mode)` |
| 4 | `bf616dc` | `feat(v4.89): rewrite generate_sprint_context_rollup.py + boot_agent_thread.py` |
| 5 | `5e99daa` | `feat(v4.89): rewrite generate_cold_start_pack.py for v4.89 conventions` |
| 6 | `fc8b71a` | `feat(v4.89): init writes sprint_window_state.json (Q6=B hook)` |
| 7 | `a2c201c` | `test(v4.89): cold-start governor pytest coverage` |
| 8 | (this) | `docs(v4.89): MATURITY §3.7 + CHANGELOG + parent-spec §四 close + TAG_NOTE` |

## 3. Acceptance Snapshot at Tag Time

- pytest **251 passed** (up from 192 baseline; +59).
- 9 mirror trees regenerated; mirror tests 40 all green; idempotency preserved.
- R1 16-row regression matrix 17 all green (cross-check behaviour unchanged — `sprint_window_state` is additive, does NOT join `_CONTRACT_SURFACE_FIELDS`).
- M7.3 init contract surface 14 tests still green + 11 new M9.0.6 sprint_window_state cases green.
- Lexicon scrub clean across the M9.0 changeset: 0 matches for `lessismore / RandomHeroes / Card.Roguelike / 爆衣 / 限界共鸣 / gourd / relic / 战斗 / 卡牌 / combat_vertical / world_exploration / big_map` and 0 matches for `SP-\d+` in the M9.0-added source tree.
- v4.88_Release byte-lock `58346b3` unchanged across all 8 commits.
- Parent spec `V4_89_PHASE_4_PLAN.md` §四 marked ✅ COMPLETE with the chain SHA sequence recorded.

## 4. Tag Scope Contract

The tag covers the 8-commit chain above ONLY. Any subsequent memory updates or cosmetic fixes land as new commits after the tag, matching M8.0 precedent (`v4.89-phase-4-skills` @ `66c8024` with the subsequent cosmetic rename `4015a4d` landing post-tag).

## 5. Next Step (post-tag)

- Memory write under `.workbuddy/memory/2026-05-07.md` (the current thread's working-day file) recording the M9.0 chain + tag cut.
- Next thread starts at **M10.0 v4.89 Release** (the final step of Phase 4). See `V4_89_PHASE_4_PLAN.md` §五.

## 6. References

- Plan file: `~/.workbuddy/plans/electric-thunder-turing.md`
- Audit doc: `docs/06_runtime_profiles/PHASE_4_M9_0_COLDSTART_AUDIT.md`
- MATURITY: `runtime/MATURITY_MATRIX.md` §3.7
- CHANGELOG: `CHANGELOG.md` top block `[v4.89 Phase 4 Step 3]`
- Parent spec: `V4_89_PHASE_4_PLAN.md` §四 (marked ✅ COMPLETE by M9.0.8)
- Source ref (read-only): `/Users/macsun/lessismore/startup_context_optimization_draft/` + `/Users/macsun/lessismore/tools/runtime/`
