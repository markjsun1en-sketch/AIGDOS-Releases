# TAG NOTE — `v4.89-release-rc3`

> **Purpose**: readiness note for EP's manual tag action finalizing v4.89 Release **rc3 v4.89 identity consistency overhaul**. This execution thread does not touch git tags; this note documents the rc2→rc3 delta, the exact anchor commit, invariants at tag time, and the verification recipe.

---

## 1. Tag target

- **Tag name**: `v4.89-release-rc3`
- **Commit to anchor**: rc3.9 chain finale (see `git log -10 revise/phase-1-fork`)
- **Branch**: `revise/phase-1-fork`
- **Predecessor tags**: `v4.89-release-rc1` + `v4.89-release-rc2` (both kept as historical archives, **not retired**)

## 2. Why rc3 exists

post-rc2 audit (EP-requested 10-dimension consistency check on 2026-05-08 13:48 GMT+8) found that v4.89_Release was inconsistent on the version-identity layer. After classifying out historical lineage, archive paths, and code-coupled strings, ~80 hits across 145 files were the package self-identifying as v4.88, including:

- `START_HERE.md` L3+L9: "single canonical entry point for v4.88" / "current AI_Game_Dev_OS v4.88 release-candidate line"
- `USER_GUIDE.md` §1: "AI Game Dev OS v4.88 (the stable line)"
- `docs/USAGE_GUIDE.md` §title: "v4.88 — Usage Guide"
- `docs/PHASE_4_TRIAL_GUIDE.md` §title: "v4.88 — Phase 4 Trial Guide"
- 11 schema/manifest version fields: `"version": "v4.88_first_tier"`
- `config/.core_os_root`: file content `v4.88-marker`
- `scripts/check_core_os_root.py` L36: `CURRENT_MAJOR_MINOR = "v4.88"`
- 9 starter templates: `"This project uses **AI_Game_Dev_OS v4.88**"`
- 18 governance/architecture/runtime_core/integrations/observability docs: `> **Scope**: v4.88` / `v4.88 governance`

RC2 had narrowed scope to file references only (rename + reference points + MANIFEST + CHECKSUMS + narrative for the 2 entry docs) and missed the version-identity layer.

**rc3 closes the gap with 9 commits across 5 phases**:
1. **Phase A onboarding entry区** (rc3.1)
2. **Phase B large identity docs** (rc3.2 USER_GUIDE; rc3.3 USAGE_GUIDE + PHASE_4_TRIAL_GUIDE + V4.89_BACKLOG)
3. **Phase C 5 mid-layer doc subdirs** (rc3.4)
4. **Phase D profile + starters + beta** (rc3.5)
5. **Phase E code + schema + templates + mock** (rc3.6 marker + CURRENT_MAJOR_MINOR; rc3.7 schema + Python + templates + mock)
6. **Phase F narrative + final regen** (rc3.8 this commit; rc3.9 final MANIFEST + CHECKSUMS regen)

**Historical preservation**: same as RC2 — `AI_Game_Dev_OS_v4.88_Release/` byte-locked archive (SHA `58346b3`, 539 files) carries all v4.88-viewpoint canonical sources unchanged.

## 3. What rc3 changes vs rc2

| Dimension | rc2 (`9e2ff22`) | rc3 final (rc3.9 anchor) |
|---|---|---|
| Onboarding entry区 (5 docs) | Self-identified as v4.88 ("single canonical entry point for v4.88") | **All self-identify as v4.89; lineage references preserved** |
| USER_GUIDE.md | Header v4.89 but body §1 / §1.1 / §3.2 / §3.4 / §4.1 / §6 / §7 / §7.5 / §8 spoke from v4.88-stable viewpoint | **Full v4.89 viewpoint with v4.88-stable lineage as historical narrative** |
| USAGE_GUIDE / PHASE_4_TRIAL_GUIDE / V4.89_BACKLOG | Self-identified as v4.88 in titles + body | **All self-identify as v4.89; historical narratives preserved** |
| 18 mid-layer docs | `Scope: v4.88 governance/architecture/runtime_core/integrations/observability` | **Scope: v4.89; lineage 'v4.88 RC12 lost X / v4.89 restores' framing** |
| 19 profile/starter/beta docs | Various v4.88 self-identity claims | **All v4.89 with v4.88-stable B+ Bridge Hardening lineage notes** |
| `.core_os_root` marker file | `v4.88-marker` (13 bytes) | **`v4.89-marker` (13 bytes); regex CONTENT_RE accepts both unchanged** |
| `check_core_os_root.py` `CURRENT_MAJOR_MINOR` | `"v4.88"` | **`"v4.89"`; self-verifies PASS / stale=false** |
| 11 schema `"version"` fields | `"v4.88_first_tier"` | **`"v4.89_first_tier"`; no code consumes the field, pure metadata** |
| 9 starter templates | `"AI_Game_Dev_OS v4.88"` identity | **All `"AI_Game_Dev_OS v4.89"` with maturity tier table pointer updated** |
| Mock files (10 trial run_sprint.py + 2 READMEs) | Self-identified as v4.88 trial | **v4.89 with v4.88-stable trial harness lineage note** |

## 4. RC3 commit chain (9 commits on `revise/phase-1-fork`)

| # | Commit | Subject | Files |
|---|---|---|---|
| rc3.1 | `0b0eb5f` | `chore(rc3): reflow v4.89 identity in 00_entry onboarding docs` | 10 |
| rc3.2 | `fbb7582` | `docs(rc3): rewrite USER_GUIDE.md to v4.89 viewpoint` | 2 / +202 / -100 |
| rc3.3 | `c27b1c8` | `docs(rc3): rewrite USAGE_GUIDE + PHASE_4_TRIAL_GUIDE + V4.89_BACKLOG to v4.89 viewpoint` | 6 / +238 / -156 |
| rc3.4 | `113a9e1` | `docs(rc3): reflow v4.89 identity in governance + architecture + runtime_core + integrations + observability` | 36 / +80 / -80 |
| rc3.5 | `33e767f` | `docs(rc3): reflow v4.89 identity in runtime_profiles + starters + beta_sprint` | 38 / +52 / -52 |
| **rc3.6** | **`d90f289`** | **`fix(rc3): update .core_os_root marker + check_core_os_root CURRENT_MAJOR_MINOR + Root_Discovery_Spec to v4.89`** — bootstrap-critical | **6 / +14 / -12** |
| rc3.7 | `76a5c29` | `chore(rc3): reflow v4.89 identity in schema + python code + starters templates + mock` | 92 / +114 / -114 |
| rc3.8 | (this commit) | `docs(rc3): RELEASE_NOTES + CHANGELOG + TAG_NOTE_v4.89-release-rc3 + MATURITY §3.11 + V4_89_PHASE_4_PLAN §五` | 5 |
| rc3.9 | (next commit) | `chore(rc3): regenerate RELEASE_MANIFEST.files[] + CHECKSUMS.sha post RC3 final content` | 3 |

**Plan template lesson #4 applied**: this TAG_NOTE deliberately does NOT quote final CHECKSUMS line counts or MANIFEST file_counts — those numbers are pinned by rc3.9, not rc3.8. Refer to `CHECKSUMS.sha` for current verification status.

## 5. Invariants at rc3 tag time (anchor = rc3.9 commit)

- **pytest 259 passed** at every commit, both dev tree and release tree.
- **`AI_Game_Dev_OS_v4.88_Release/` byte-lock SHA `58346b3`** — unchanged across the entire rc3 chain (verified via `git log --oneline -1 -- 'AI_Game_Dev_OS_v4.88_Release/'` at every commit).
- **Dev/release byte-equivalent** — `diff -q` empty for all files except **6** release-only divergence points (was 5 pre-rc3; new addition since rc3.x = `TAG_NOTE_v4.89-release-rc3.md`):
  - `pytest.ini`
  - `RELEASE_NOTES.md`
  - `CHECKSUMS.sha`
  - `TAG_NOTE_v4.89-release-rc1.md` + `rc2.md` + **`rc3.md`** (3 release-only TAG_NOTE files)
  - `RELEASE_MANIFEST.json` (dev vs release have different file_counts because release tree has 4 release-only artefacts)
- **CHECKSUMS.sha** — see file for current `OK / FAILED` count.
- **MANIFEST.json self-consistency** on both trees: 0 missing / 0 bytes_mismatch / 0 sha_mismatch (verified by rc3.9 regen).
- **`.core_os_root` marker** — content is `v4.89-marker` on both trees (verified by `python scripts/check_core_os_root.py` returning `verdict: PASS, stale: false`).
- **Reference scrub** — `grep -rn "v4\.88" AI_Game_Dev_OS_v4.89_Release/` should return only:
  - `AI_Game_Dev_OS_v4.88_Release/` byte-lock path references (historical archive)
  - `v4.88 RC12` / `v4.88_Revise` / `v4.88-stable` / `v4.88-release-{scaffold,bplus,stable}` lineage citations
  - `v4.89-trial-upgrade` / `v4.88_scaffold` / `v4.88 Phase 2 Step 3` code-coupled or historical phase strings
  - LTM corpus historical narrative timestamps
  - 0 self-identity claims
- **rc1 + rc2 tags preserved** — additive; rc3 is the new chain finale.

## 6. EP verification recipe

```bash
cd <UPSTREAM_REPO_ROOT>  # e.g. ~/Documents/AI_DEV_OS_Evolve (the workspace root, not the v4.89 subdir)

# 1. Confirm rc3 chain head
git log --oneline -10 revise/phase-1-fork
# expect: HEAD = rc3.9 chore(rc3): regenerate RELEASE_MANIFEST.files[] + CHECKSUMS.sha post RC3 final content

# 2. v4.88_Release byte-lock unchanged
git log --oneline -1 -- AI_Game_Dev_OS_v4.88_Release/
# expect: 58346b3 docs(v4.88+v4.89)…

# 3. CHECKSUMS self-check
cd AI_Game_Dev_OS_v4.89_Release
shasum -a 256 -c CHECKSUMS.sha | tail -3
# expect: …last 3 lines all OK; total OK / 0 FAILED

# 4. pytest both trees
cd ../AI_Game_Dev_OS_v4.89 && python3 -m pytest tests/ -q
cd ../AI_Game_Dev_OS_v4.89_Release && python3 -m pytest tests/ -q
# expect: 259 passed (both)

# 5. .core_os_root marker self-verify
cd AI_Game_Dev_OS_v4.89_Release && python3 scripts/check_core_os_root.py
# expect: {"content": "v4.89-marker", "current_expected_prefix": "v4.89", "stale": false, "verdict": "PASS"}

# 6. Onboarding entry doc check
head -3 AI_Game_Dev_OS_v4.89_Release/docs/00_entry/START_HERE.md
# expect: # START HERE / > **This is the single canonical entry point for v4.89.** ...

# 7. MANIFEST self-consistency
python3 -c "
import json, os, hashlib
for tree in ['AI_Game_Dev_OS_v4.89', 'AI_Game_Dev_OS_v4.89_Release']:
    with open(f'{tree}/RELEASE_MANIFEST.json') as f: m = json.load(f)
    miss = mb = ms = 0
    for e in m['files']:
        full = os.path.join(tree, e['path'])
        if not os.path.exists(full): miss += 1; continue
        if os.path.getsize(full) != e['bytes']: mb += 1
        if hashlib.sha256(open(full,'rb').read()).hexdigest() != e['sha256']: ms += 1
    print(f'{tree}: files={len(m[\"files\"])} miss={miss} bytes_mismatch={mb} sha_mismatch={ms}')
"
# expect: dev / release both 0/0/0 drift

# 8. Reference scrub check (should only return lineage / archive / code-coupled hits)
grep -rln "v4\\.88" AI_Game_Dev_OS_v4.89_Release/ | wc -l
# expect: see plan §1.2 unchanged-list for legitimate residual hits
```

## 7. EP manual tag command

```bash
git tag -a v4.89-release-rc3 <rc3.9-anchor-commit-sha> \
  -m "v4.89 Release rc3 — identity consistency overhaul (entry docs + USER_GUIDE / USAGE_GUIDE / PHASE_4_TRIAL_GUIDE rewrite + 18 mid-layer docs + 19 profile/starter/beta docs + .core_os_root marker + CURRENT_MAJOR_MINOR + 11 schema first_tier + 12 Python docstrings + 9 starter templates + 11 mock files + final MANIFEST/CHECKSUMS regen)"
```

Anchor commit = the rc3.9 commit (chain finale where MANIFEST + CHECKSUMS reflect the post-rc3.8 state of all narrative and content files).

## 8. References

- `~/.workbuddy/plans/electric-cascade-turing.md` — RC3 9-commit plan.
- `AI_Game_Dev_OS_v4.89_Release/RELEASE_NOTES.md §0.0` — RC3 narrative block.
- `AI_Game_Dev_OS_v4.89_Release/CHANGELOG.md` — RC3 commit-level entry (top of file).
- `AI_Game_Dev_OS_v4.89/runtime/MATURITY_MATRIX.md §3.11` — RC3 milestone ledger (9 rows).
- `V4_89_PHASE_4_PLAN.md §五` — RC3 row added to Step 4 break-down.
- `AI_Game_Dev_OS_v4.89_Release/docs/06_runtime_profiles/TAG_NOTE_v4.89-release-rc{1,2}.md` — rc1 + rc2 readiness notes (kept).
