# Phase 4 Step 1 — M7.3 Lift Gate Audit

> **Scope**: v4.89 Phase 4 Step 1 — lift the per-profile cross-check gate from
> "state explicitly declares contract field → check" to
> "init MUST canonically write contract surface + cross-check MUST match".
>
> **Parent spec**: `V4_89_PHASE_4_PLAN.md` §二 M7.3 (5 sub-steps).
>
> **Thread plan**: `.workbuddy/plans/electric-cascade-newton.md` (7-commit chain,
> EP approved, 4 decisions locked).
>
> **Status**: Commit 1 / 7 — audit doc only, 0 source change.
> **Commit label**: `docs(v4.89-M7.3.1): audit doc for lift gate — contract surface + Q1-Q4 decisions`.

---

## 1. Problem restated

Parent spec §0 issue #1 identified a **silent-PASS second-order residual** in the
per-profile cross-check gate:

- `runtime/schema_driven_check.py` `schema_driven_init_check()` at L202-208
  short-circuits with `if actual is None: continue` when a contract field is
  absent from `runtime_state.json`.
- `scripts/init_runtime_env.py::_stub_init` hard-writes only 6 fields and
  conditionally forwards 5 optional fields from `config_data`; it **does not
  read profile JSON at all**. Consequently the 8 contract-surface fields that
  the cross-check gate inspects are only ever present if the user provides them
  by hand through `config_data`.
- Net effect: a stock `init` run produces a `runtime_state` that triggers **no
  cross-check finding**, regardless of profile drift. The gate LOOKS green but
  never actually ran.

**M7.3 命题**: eliminate the silent-PASS by (a) forcing `_stub_init` to load
`<pkg>/config/profiles/<profile>.json` and canonically write the 8 contract
surface (profile, field) pairs, and (b) turning the `actual is None`
short-circuit into a hard `ERROR(missing contract field)`.

---

## 2. Contract surface — the 8 (profile, field) pairs

Source of truth: `runtime/schema_driven_check.py::_PROFILE_CHECK_FIELDS`
(L131-136). Listed in the exact order the check emits.

| # | Profile | Field | Ground-truth value (from config/profiles/\*.json) |
|--:|---|---|---|
| 1 | `codex` | `coordination_model` | `parent_subagents` |
| 2 | `codex` | `writeback_owner` | `parent` |
| 3 | `cursor` | `coordination_model` | `parallel_agents` |
| 4 | `cursor` | `writeback_owner` | `reviewed_apply_owner` |
| 5 | `claude_code_agent_teams` | `coordination_model` | `lead_teammates` |
| 6 | `claude_code_agent_teams` | `writeback_owner` | `lead` |
| 7 | `claude_code_subagents` | `audit_collector` | `claude_subagents_collector` |
| 8 | `claude_code_subagents` | `context_loading_method` | `claude_docs_plus_hooks` |

**Why these 8, not more**: each profile's legacy M6.4-M6.7 check-block (the
pre-schema-driven code path) inspected exactly this set. M7.3.3 preserves
byte-identical output, so the surface is fixed by historical contract.
Expansion is out-of-scope for M7.3 (YAGNI — would enlarge blast radius).

**Nested structs** (e.g. `rule_loading: { kind: …, order: [...] }`) are
deliberately NOT part of the contract surface: they have list-order ambiguity
and would require custom equality semantics. Decision Q1=A locks the surface
at 8 primitive string fields.

---

## 3. The six profile JSONs (producer set)

Located at `config/profiles/*.json`. All six carry the same 11 keys:

```
runtime_type, coordination_model, isolation_unit, writeback_owner,
cleanup_owner, merge_mode, rule_loading, context_loading_method,
audit_collector, known_limitations, recovery_sop
```

Of these six profiles:

| Profile | In cross-check allowlist? | `_stub_init` action (post-M7.3.2) |
|---|---|---|
| `codex` | ✅ yes (pairs #1-#2) | canonical write 4 primitive fields |
| `cursor` | ✅ yes (pairs #3-#4) | canonical write 4 primitive fields |
| `claude_code_agent_teams` | ✅ yes (pairs #5-#6) | canonical write 4 primitive fields |
| `claude_code_subagents` | ✅ yes (pairs #7-#8) | canonical write 4 primitive fields |
| `workbuddy_private` | ❌ no | **write but not checked** (Q4=A) |
| `default_beta_codex_tapd_git` | ❌ no | **write but not checked** (Q4=A) |

**Why write-but-not-check for the last two**: producer ≠ consumer. `_stub_init`
is the canonical producer, so every profile (including the two not yet under
cross-check) gets a uniform write path. But lifting the four cross-check tests
to cover the two extra profiles is NOT in M7.3 scope — it would require new
allowlist entries in `_PROFILE_CHECK_FIELDS` + four extra regression rows in
`test_stage_2_regression_r1.py`. Keep the cross-check gate at the current 4
profiles; revisit in a later phase if needed.

---

## 4. Short-circuit line to lift (M7.3.3)

`runtime/schema_driven_check.py` L202-208 (current):

```python
for field in _PROFILE_CHECK_FIELDS[declared]:
    actual = state.get(field)
    if actual is None:
        # Not explicitly declared in state — gate by-design;
        # M6.4-M6.7 blocks all use ``if x and x != expected``,
        # which is the same semantics.
        continue
    expected = ground_truth.get(field)
    ...
```

Post-M7.3.3 target:

```python
for field in _PROFILE_CHECK_FIELDS[declared]:
    actual = state.get(field)
    if actual is None:
        findings.append(_finding(
            "init", "ERROR",
            f"profile={declared} missing contract field {field!r} "
            f"— init must canonically write contract surface",
            path=str(state_path),
            contract_field=field,
        ))
        continue
    expected = ground_truth.get(field)
    ...
```

Rationale (Q2=A): the whole M7.3 proposition is "init MUST write". Downgrading
missing-field detection to WARN would tacitly admit init MAY skip, which
undoes the lift. ERROR is the semantically correct severity.

The `actual != expected` path remains WARN (schema drift — non-fatal
skew between user-edited state and profile ground truth).

---

## 5. EP-locked decisions (Q1-Q4)

From `.workbuddy/plans/electric-cascade-newton.md` §3.

| ID | Decision | Choice | Reason |
|---|---|---|---|
| Q1 | How wide should init's contract surface be? | **A — strict 8 fields** (current `_PROFILE_CHECK_FIELDS` coverage) | Minimal blast radius; YAGNI; nested structs have no unambiguous serialization contract |
| Q2 | Severity for missing contract field | **A — ERROR** | M7.3 命题本身要求 init 必写；downgrade 等于自我否定；R1 expected matrix 本就要重锁 |
| Q3 | Commit granularity | **A — split into 7 commits** (M7.3.2 init-impl/tests split, M7.3.4 mirror-content/sha-lock split) | Diff readability > parent-spec estimate; single >500-line commits fall off the review cliff |
| Q4 | `workbuddy_private` / `default_beta_codex_tapd_git` treatment | **A — write but do not check** | Producer ≠ consumer; keep cross-check profile count at 4 (minimum perturbation); wb_private already validated via the Phase 1 baseline |

Supplementary decision — thread boundary: single thread, one session end-to-end
(parent spec §M7.3 1-session budget respected).

---

## 6. 7-commit chain (locked)

Reproduced from plan §4 for quick local reference.

| # | Sub-step | Theme | Source touched? | Byte-lock impact |
|--:|---|---|:---:|---|
| 1 | **M7.3.1** | This audit doc → `docs/06_runtime_profiles/PHASE_4_LIFT_GATE_AUDIT.md` | — | none |
| 2 | **M7.3.2a** | `scripts/init_runtime_env.py::_stub_init` rewrite: load profile JSON → canonical-write 4 primitives (4 cross-check profiles) or tolerant-write (`wb_private` / `default_beta`) | ✅ | source |
| 3 | **M7.3.2b** | Add `tests/test_init_writes_contract_surface.py` (≥5 cases) | ✅ | +5 tests → pytest 178 → 183+ |
| 4 | **M7.3.3** | `runtime/schema_driven_check.py` L202-208 lift: `actual is None → ERROR(missing contract field)`; relock R1 expected matrix | ✅ | R1 expected re-lock |
| 5 | **M7.3.4a** | Regenerate all 11 mirrors via `mirror_trial_workspace.py --force` | ✅ | mirror bytes re-roll |
| 6 | **M7.3.4b** | sha256 + manifest re-lock in `test_mirror_trial_workspace.py` / `test_stage_2_regression_r1.py` | ✅ | sha re-lock |
| 7 | **M7.3.5** | LTM postmortem + `MATURITY_MATRIX.md §3.5` + `CHANGELOG.md §M7.3` + parent-spec §一 Step 1 ✅ | — | docs |

---

## 7. Risk register (M7.3-specific)

| ID | Risk | Mitigation |
|---|---|---|
| R1 | init change → all 11 mirrors invalidated → prior sha locks die | Split M7.3.4 into content-rewrite (4a) and sha-relock (4b); review diff before relock |
| R2 | Gate-lift changes R1 expected matrix rows | M7.3.3 isolated commit; if expected-row delta > 5, a bonus commit is acceptable |
| R3 | Profile JSON load failure (missing file, permission, malformed JSON) | `_stub_init` must `try/except` and fall back to `None` for missing primitives, so the downstream `actual is None → ERROR` path emits a readable diagnosis |
| R4 | `_live_init` parallel regression | `_live_init` calls `_stub_init` first and merges live fields on top, so the canonical write automatically propagates; manual verification in M7.3.2a |

---

## 8. Exit gates (E1-E8)

From plan §7. Copied here so the audit doc is self-contained.

- **E1**: pytest **183+ passed** (178 baseline + ≥5 new init tests) / 0 regression
- **E2**: R1 16-row all-green (post re-lock, row-by-row verified)
- **E3**: 4 per-profile cross-check tests byte-stable (run immediately after M7.3.3; update expected; rerun)
- **E4**: `test_schema_driven_equivalence.py` byte-stable
- **E5**: trial `rh_sprint_sim_01` → `verify` verdict **PASS / 0 error / 0 warn** (init now writes → contract surface complete → cross-check no longer short-circuits)
- **E6**: `v4.88_Release/` untouched — `git log AI_Game_Dev_OS_v4.88_Release/` top commit remains `58346b3`
- **E7**: All docs landed (CHANGELOG / MATURITY / LTM postmortem / this audit doc / parent-spec change-log)
- **E8**: tag `v4.89-phase-4-lift` (**EP manual — this thread does NOT touch git tag**)

---

## 9. Forbidden zones (re-affirmed)

- 11 permanent contracts from Phase 1 (§§1-11 of the permanent-contract ledger, incl. envelope 9-field schema / runtime_state path contract / LTM 4-domain layering)
- `AI_Game_Dev_OS_v4.88_Release/` byte state (immutable scaffold)
- Stage 2 charter §5.2 (closed; no retroactive edits)
- Tags `v4.89-phase-1-*`, `v4.89-phase-2-stage-2`, `v4.89-phase-3-collapse` (immutable)

Only addition allowed at thread end: tag `v4.89-phase-4-lift` (EP hand-stamped).

---

## 10. Baseline anchor (recorded for postmortem traceability)

- **HEAD at start of commit 1**: `b176a2a` (`chore(memory): record M7.2 collapse executed`)
- **Branch**: `revise/phase-1-fork`
- **pytest**: 178 passed / 2.88s (darwin / Python 3.13.2 / pytest 9.0.3)
- **v4.88_Release top commit**: `58346b3`
- **trial_workspaces/ count**: 11 (README + baseline + 4 positive + 4 negative + 1 default_beta)
- **Working language**: English inside v4.89 package (permanent contract §11)

---

*Author: Kai · Thread: electric-cascade-newton · Plan version: 2026-05-05 22:55*
