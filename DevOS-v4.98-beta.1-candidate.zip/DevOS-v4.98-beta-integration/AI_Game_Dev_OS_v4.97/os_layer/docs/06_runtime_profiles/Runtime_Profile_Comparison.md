# Runtime Profile Comparison

## Purpose
This document compares the five v4.89 runtime profiles at a practical level so that a project can select the least-complex profile that still fits the intended execution style.

## Comparison dimensions
The comparison should focus on:
- coordination model,
- isolation model,
- rule-loading surface,
- writeback owner,
- cleanup owner,
- audit collection style,
- typical Beta Sprint use case.

## Summary table
| Profile | Coordination model | Default isolation | Writeback owner | Best use |
|---|---|---|---|---|
| Codex | parent + subagents | worktree | parent | default Beta Sprint execution |
| Cursor | coordinator + parallel agents | worktree / isolated env | reviewed coordinator | parallel experimentation |
| Claude Subagents | main agent + subagents | worktree | main agent | hook-driven bounded execution |
| Claude Agent Teams | lead + teammates | coordinated team session (JSON: `shared_session`) | lead | high coordination, higher overhead |
| Workbuddy Private | private coordinated (JSON: `private_coordinated`) | project-defined | main session | continuation of existing Workbuddy-derived projects |

## Subsystem support (REV-4-007, 2026-04-22)

`skills/_generic_core/` provides subsystem-level Skills (art / design / uiux / engineering / ep / game-design / research / orchestrator / content-design / numeric / qa / sound-designer — see `skills/README.md`). Not all profiles support subsystem-based agent decomposition equally:

| Profile | Native subsystem decomposition | How to use Skills | Caveats |
|---|---|---|---|
| Codex | No (single parent + ephemeral subagents) | Parent agent reads `skills/_generic_core/<subsystem>/**` as context when the task calls for that subsystem role | No persistent subsystem agents; every subagent gets its role via prompt |
| Cursor | No (coordinator + parallel agents) | Coordinator assigns one subsystem Skill per parallel agent at spawn time | Parallel agents don't share subsystem state; merge via coordinator |
| Claude Subagents | Partial (subagent role = subsystem) | Each subagent task brief includes the relevant Skill path; subagent operates inside that Skill's contract | Subagents are ephemeral — subsystem state survives only via audit + registry |
| Claude Agent Teams | **Yes — strongest match** (teammate role = subsystem) | Each teammate spawned as a subsystem role (e.g. `teammate:engineering` / `teammate:qa`); uses that subsystem's Skill set persistently | Serial spawn per Mac memory ID 32993224; max_turns limits per teammate |
| Workbuddy Private | Yes (project-defined team roles map to subsystems) | Workbuddy AGENTS.md.template declares subsystem-equivalent roles; rich per-role context | Private profile; subsystem mapping is project-specific, not portable |

Projects choosing multi-subsystem workflows should prefer **Claude Agent Teams** or **Workbuddy Private** over Codex / Cursor / Claude Subagents when persistent subsystem state matters. For single-subsystem tasks, any profile works and simpler profiles are preferred.

## Selection guidance
Start from the simplest profile that satisfies the task:

1. Prefer Codex when the project is already aligned with the Codex starter and parent-owned writeback.
2. Prefer Cursor when broad parallel exploration matters more than strict hook-driven lifecycle control.
3. Prefer Claude subagents before agent teams unless teammate coordination is truly required.
4. Use Claude agent teams only with explicit need and cleanup discipline.
5. Use Workbuddy private only when you are intentionally preserving that runtime semantics.

## Anti-pattern
Do not start by asking which profile is most powerful. Start by asking which profile has the least coordination overhead for the intended sprint.
