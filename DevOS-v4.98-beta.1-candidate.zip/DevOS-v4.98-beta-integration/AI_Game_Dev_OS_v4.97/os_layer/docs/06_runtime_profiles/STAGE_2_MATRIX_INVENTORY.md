# v4.89 Phase 2 Stage 2 — M6.1 Matrix Inventory

> **Document type**: gap inventory (feed for M6.2-M6.8 execution)
> **Author**: Kai · **Date**: 2026-05-05 · **Version**: v4.89 Phase 2 Stage 2 / M6.1
> **Upstream charter**: `STAGE_2_5_PROFILE_PARITY_CHARTER.md` (§5.1 / §5.2 / §7)
> **Branch**: `revise/phase-1-fork` · **Base commit**: `938db66` (on top of tag `v4.89-phase-2-stage-2-b1` @ `b9ecd49`)
> **Code diff**: 0 files. This milestone is markdown-only.

---

## §1 Scope and dimensional definitions

Stage 2 parity coverage is defined over three orthogonal dimensions:

| Dim | Name | Stage 2 value | Source of truth |
|---|---|---|---|
| A | **Profile** | 6 profiles (5 core + 1 combo template) | `config/profiles/*.json` |
| B | **Maturity** | 2 tiers: `SCAFFOLD`, `GUIDED` | `runtime/MATURITY_MATRIX.md` §1 (MANUAL / PRODUCTION deferred to Phase 3+) |
| C | **Workspace shape** | 1 shape: `rh_sprint_sim_01` | charter §5.1 (other starter dirs remain "shape candidates", non-active in Stage 2) |

### 1.1 Profile enumeration (6, per EP Q1 = B)

EP resolved charter §7 Q1 as **B** on 2026-05-05: `default_beta_codex_tapd_git.json` is admitted as the **6th profile** participating in Stage 2 parity, lifting the combo count from 8 → 12.

| # | Profile ID | Role in Stage 2 |
|---|---|---|
| P1 | `workbuddy_private` | baseline regression (Phase 1 E1-E7 already green) |
| P2 | `codex` | core dry-run target (M6.4) |
| P3 | `cursor` | core dry-run target (M6.5) |
| P4 | `claude_code_agent_teams` | core dry-run target (M6.6) |
| P5 | `claude_code_subagents` | core dry-run target (M6.7) |
| P6 | `default_beta_codex_tapd_git` | combo-template load-and-parity validation (not a 6th independent Agent ecosystem; structurally a codex preset with extra `known_limitations`) |

### 1.2 Maturity scope

`runtime/MATURITY_MATRIX.md` §1 defines 4 tiers (SCAFFOLD / GUIDED / MANUAL / PRODUCTION). Stage 2 runs parity only on SCAFFOLD and GUIDED; MANUAL / PRODUCTION are out-of-scope per charter §8.

### 1.3 Workspace shape scope

Charter §5.1 locks Dim C at ×1 (`trial_workspaces/rh_sprint_sim_01/`). Other `starters/<profile>/` directories contain **boot assets** (templates, LOADSETs, hooks), not **trial workspace shapes**; they are consumed by M6.3 when deciding whether to mirror the single shape per profile, not as independent shapes.

---

## §2 Combo inventory — 12 rows

Column legend:
- `runnable_now` = can the **current** `verify_beta_sprint_exit.py` produce a meaningful PASS/CONDITIONAL/FAIL for this combo **without any M6.2+ changes**?
- `gaps` = short codes, fully enumerated in §3.

| # | combo_id | profile | maturity | workspace | runnable_now | gaps |
|---|---|---|---|---|---|---|
| C01 | `P1-SCAFFOLD` | `workbuddy_private` | SCAFFOLD | `rh_sprint_sim_01` | ✅ (Phase 1 baseline) | none (baseline) |
| C02 | `P1-GUIDED` | `workbuddy_private` | GUIDED | `rh_sprint_sim_01` | ✅ (Phase 1 baseline) | none (baseline) |
| C03 | `P2-SCAFFOLD` | `codex` | SCAFFOLD | `rh_sprint_sim_01` | ⚠️ partial (profile flag accepted; maturity flag absent → implicit) | G-a1, G-c1 |
| C04 | `P2-GUIDED` | `codex` | GUIDED | `rh_sprint_sim_01` | ❌ no maturity gate | G-a1, G-a2, G-c1 |
| C05 | `P3-SCAFFOLD` | `cursor` | SCAFFOLD | `rh_sprint_sim_01` | ⚠️ partial | G-a1, G-c1 |
| C06 | `P3-GUIDED` | `cursor` | GUIDED | `rh_sprint_sim_01` | ❌ | G-a1, G-a2, G-c1 |
| C07 | `P4-SCAFFOLD` | `claude_code_agent_teams` | SCAFFOLD | `rh_sprint_sim_01` | ⚠️ partial | G-a1, G-b1, G-c1 |
| C08 | `P4-GUIDED` | `claude_code_agent_teams` | GUIDED | `rh_sprint_sim_01` | ❌ | G-a1, G-a2, G-b1, G-c1 |
| C09 | `P5-SCAFFOLD` | `claude_code_subagents` | SCAFFOLD | `rh_sprint_sim_01` | ⚠️ partial | G-a1, G-c1 |
| C10 | `P5-GUIDED` | `claude_code_subagents` | GUIDED | `rh_sprint_sim_01` | ❌ | G-a1, G-a2, G-c1 |
| C11 | `P6-SCAFFOLD` | `default_beta_codex_tapd_git` | SCAFFOLD | `rh_sprint_sim_01` | ⚠️ partial | G-a1, G-b2, G-c2 |
| C12 | `P6-GUIDED` | `default_beta_codex_tapd_git` | GUIDED | `rh_sprint_sim_01` | ❌ | G-a1, G-a2, G-b2, G-c2 |

**Note on P6**: `default_beta_codex_tapd_git.json` is structurally a `codex` preset — same `runtime_type: codex` / `coordination_model: parent_subagents` / `audit_collector: codex_collector`, plus two extra `known_limitations` entries ("beta sprint package assumes parent-owned external writeback" + "do not switch runtime profile mid-sprint"). Its parity claim is **combo-template loadability**, not an independent Agent ecosystem.

**Note on P4 (`claude_code_agent_teams`)**: the profile JSON self-tags `known_limitations: ["experimental_feature"]`. Parity outcome on P4-GUIDED may surface contract-level issues the other 5 profiles do not; this is an expected Stage 2 signal, not a retry.

---

## §3 Gap classification

Every gap below is labelled with its resolving milestone (M6.2–M6.8).

### §3.1 Category (a) — Driver support gaps

| Code | Gap | Observed in | Resolver |
|---|---|---|---|
| **G-a1** | No `--maturity` flag on `verify_beta_sprint_exit.py` (only `--profile --sprint --workspace --audit-log --runtime-state --sprint-close-checklist --categories` exist; see `scripts/verify_beta_sprint_exit.py:827-850`). Maturity tier is currently hard-wired per category (`CATEGORY_TIER`), not a runtime-selectable gate. | C03–C12 (all non-P1 combos) | **M6.2** |
| **G-a2** | No `--shape` flag (workspace shape is chosen by `--workspace <path>`, not a canonical shape enumerator). For Stage 2 this still works (shape is ×1), but the CLI contract lacks the concept and will need it when Phase 3 lifts Dim C to >1. | C04/C06/C08/C10/C12 (GUIDED-tier rows; SCAFFOLD rows tolerate implicit shape) | **M6.2** |
| **G-a3** | **`beta_sprint_driver.py` does not exist.** Roadmap §four Step 2 names it as the target of M6.2 parameterisation, but the file is absent from `AI_Game_Dev_OS_v4.89/scripts/`. M6.2 must first decide: **new file** vs **extend `verify_beta_sprint_exit.py`** (see §4 below for trade-offs). | All 12 combos (infrastructure-level) | **M6.2** (decision gate) |

### §3.2 Category (b) — Profile JSON field gaps

All 6 profile JSONs share a common 11-field schema (`runtime_type`, `coordination_model`, `isolation_unit`, `writeback_owner`, `cleanup_owner`, `merge_mode`, `rule_loading.{entry_file,supports_hooks,supports_rules}`, `context_loading_method`, `audit_collector`, `known_limitations`, `recovery_sop`). Parity at schema level requires all 6 to carry identical keys.

| Code | Gap | Observed in | Resolver |
|---|---|---|---|
| **G-b1** | P4 `claude_code_agent_teams.json` has `known_limitations: ["experimental_feature"]`. Not a schema gap per se, but a **documented parity risk** that M6.6 dry-run must budget contingency for. | P4 combos (C07, C08) | **M6.6** |
| **G-b2** | P6 `default_beta_codex_tapd_git.json` **is missing `context_loading_method`** — all other 5 profiles carry this field; the combo template omits it. This is a concrete schema divergence discovered during M6.1 inventory. M6.2 or M6.8 must decide: (i) fill with the codex default (`project_docs_plus_selected_files`), (ii) treat combo templates as schema-relaxed, or (iii) fail-loud in driver. **RESOLVED in M7.0 (Phase 3 Lock-A, 2026-05-05)**: option (i) chosen; P6 JSON gained `context_loading_method=project_docs_plus_selected_files` AND `verify.py _VALID_PROFILES` enum extended to include P6 (the GUIDED CONDITIONAL/1W finding observed since M6.3 was actually triggered by the enum-miss, not the missing field — both were fixed together for schema completeness). | P6 combos (C11, C12) | ~~M6.2 / M6.8~~ → **M7.0** ✅ |

### §3.3 Category (c) — Starter / workspace assembly gaps

`starters/` contains per-profile boot assets (templates + DEFAULT_LOADSET), not trial-workspace shapes. The gap is whether every profile can **bootstrap a workspace equivalent to `rh_sprint_sim_01`** from its starter bundle without ad-hoc patching.

| Code | Gap | Observed in | Resolver |
|---|---|---|---|
| **G-c1** | 5 core profiles (P1-P5) each have a `starters/<profile>/` directory with asymmetric asset inventories (e.g. P1 has `SKILLS.md.template`, P2-P5 have `HOOKS.template.json` or `PROJECT_RULES.template.md`; codex has `BOOT_BLOCK.md`, cursor has same; claude\_\* have `CLAUDE.md.template`). Parity check: does the dry-run against `rh_sprint_sim_01` depend on any starter asset **not present** for the target profile? M6.3 owns the "shared workspace vs per-profile mirror" decision — depending on choice, G-c1 resolves either by staying shared (starters consulted only at init, not at verify) or by generating per-profile mirrors from the starter bundle. | C03, C05, C07, C09 (SCAFFOLD tier is most sensitive to missing assets) | **M6.3** |
| **G-c2** | **P6 `default_beta_codex_tapd_git` has no `starters/default_beta_codex_tapd_git/` directory.** It aliases to the codex starter (per its `recovery_sop: docs/06_runtime_profiles/codex/RECOVERY_SOP.md`). M6.2 must teach the driver this alias, or M6.3 must clone the codex starter into a combo-specific directory. | C11, C12 | **M6.2** (alias table) + **M6.3** (if mirror strategy chosen) |

---

## §4 Driver parameter contract draft (feeds M6.2)

This section is M6.1's formal handoff to M6.2. It does **not** pick between the two implementation options; it lists the contract surface both options must satisfy, plus the trade-offs.

### §4.1 Required CLI surface (post-M6.2)

```
<driver> \
  --profile {workbuddy_private | codex | cursor | claude_code_agent_teams | claude_code_subagents | default_beta_codex_tapd_git} \
  --maturity {SCAFFOLD | GUIDED} \
  --shape   rh_sprint_sim_01     # default; single allowed value in Stage 2
  [--workspace <path>]           # already exists on verify_beta_sprint_exit.py
  [--sprint <id>]                # already exists
  [--categories ...]             # already exists
```

### §4.2 Back-compat rules (must hold after M6.2)

- **B1**: `--profile workbuddy_private` + `--maturity GUIDED` (or maturity absent) with Phase 1 default args must produce the identical verdict as Phase 1 baseline on `rh_sprint_sim_01` — byte-for-byte JSON report diff tolerated only on new top-level fields added by M6.2.
- **B2**: Omitting `--maturity` must default to GUIDED (current hard-wire is GUIDED for init+evidence+close; SCAFFOLD for execution+external — this becomes a runtime gate instead of a constant).
- **B3**: Omitting `--shape` must default to `rh_sprint_sim_01`; unrecognised shape → exit 2 with `unknown shape` message.
- **B4**: Unknown profile → exit 2 (already the convention for `--categories`).

### §4.3 Option A vs Option B (M6.2 decision)

| | **Option A: New `scripts/beta_sprint_driver.py`** | **Option B: Extend `scripts/verify_beta_sprint_exit.py`** |
|---|---|---|
| Footprint | +1 file (~200 lines); old verify keeps Phase 1 CLI unchanged | 0 new files; verify.py grows by ~60 lines (arg parsing + dispatch) |
| Back-compat | Trivial — the old verify is byte-locked | Must actively preserve Phase 1 CLI semantics; every new flag needs a back-compat guard |
| Separation of concerns | Driver (orchestrate 12 combos) vs Verifier (single-combo contract check) cleanly split | Verifier conflates single-combo contract checking with multi-combo orchestration |
| pytest surface | New tests in a new file (e.g. `tests/test_beta_sprint_driver.py`); existing 12-case `test_*.py` on verify.py untouched | Existing verify.py tests must be re-validated; risk of regressing 65/65 |
| Phase 3+ evolution | Room to add `--parallel`, `--per-profile-mirror`, `--ltm-capture-on-fail` without re-touching verify.py | Every Phase 3 feature further bloats verify.py |
| Risk to Phase 1 byte-lock | None (new file) | verify.py is in-scope for Phase 1 regression — any line change is a regression risk |
| M6.2 velocity | Higher upfront cost (scaffolding a new CLI) | Lower upfront cost (reuse existing parser) |

M6.1 recommends **Option A** on separation-of-concerns grounds but does not decide; M6.2 entry gate is to pick one explicitly and record the decision in a new charter §7 Q-cell (Q5).

### §4.4 Driver ↔ verifier delegation (both options)

Regardless of A/B, the driver layer must call into the existing 5 category check functions (`check_init_integrity`, `check_execution_integrity`, `check_external_sync_integrity`, `check_evidence_integrity`, `check_close_integrity`) rather than reinventing them. Per-maturity gating applies at the **category inclusion** level (SCAFFOLD-only profiles skip GUIDED-tier categories, or vice versa) — the category functions themselves are maturity-agnostic today and Phase 3 owns any per-function tier escalation.

---

## §5 Trial workspace strategy — decision inputs (feeds M6.3)

M6.1 does **not** decide between shared and mirrored workspace models. It enumerates the trade-offs so M6.3 can pick.

| | **Option A: Shared single `rh_sprint_sim_01`** | **Option B: Per-profile mirror `rh_sprint_sim_01__<profile>/`** |
|---|---|---|
| Disk footprint | 1× | 6× (~6 mirrored trees) |
| Byte-lock impact | Zero — no baseline disturbance | v4.88_Release byte-lock untouched (mirrors live outside), but `trial_workspaces/` directory listing grows; Phase 1 pytest asserting workspace inventory (if any) must be re-checked |
| Cross-profile contamination risk | High — audit log, runtime_state.json, sprint_close_checklist.md must be reset per combo run (fresh-workspace contract G-c1.1) | None — each mirror is independent |
| Parallel execution | Impossible in Stage 2 (serial required) | Possible in Phase 3+ |
| Reset cost per combo | Full teardown + re-init (`init_runtime_env.py`) | Just delete + re-copy mirror |
| Audit archaeology | Harder — one audit stream interleaves 12 runs unless per-run rotated | Easier — each mirror has its own audit trail |
| Parity fidelity | Same workspace shape across all profiles — strongest parity evidence | Identical-by-construction mirrors preserve parity, but introduces a copy step that is itself testable |
| Starter-bundle validation | Starter bundle is consulted only at init-time; does not interact with verify-time | Per-profile mirror can exercise G-c1/G-c2 starter assembly end-to-end (richer signal, more moving parts) |

Decision criteria for M6.3:
1. Does the Stage 2 dry-run need to exercise starter assembly? If yes → Option B.
2. Is 6× disk cost on `trial_workspaces/` acceptable for a temporary stage? If no → Option A.
3. Does byte-lock of `v4.88_Release/` require the test harness to stay minimal? Both options preserve it; prefer A on "fewer moving parts" grounds.

### §5 refinement (post-M6.2, M6.3 decision — 2026-05-05)

M6.2 driver smoke (commit `970c317`) produced empirical evidence that
tipped the decision toward **Option B**:

```
$ beta_sprint_driver.py --profile codex \
    --workspace trial_workspaces/rh_sprint_sim_01
→ exit 1 / CONDITIONAL
findings:
  - init WARN  runtime_state profile='workbuddy_private' does not match --profile='codex'
```

Under Option A every non-P1 combo (C03–C12) would carry at least one
init-level WARN purely from the profile-mismatch — polluting the
PASS/FAIL signal M6.4-M6.7 need to produce.

**M6.3 resolution (charter §7 Q2 = B)**: 5 per-profile mirrors
(P2-P6) at `trial_workspaces/rh_sprint_sim_01__<profile>/`; P1 keeps
`rh_sprint_sim_01/` as baseline. Disk cost: 5 × ~148 KB ≈ 740 KB
(~+0.5% of v4.89/, well under the 250 KB/mirror guardrail enforced
by `test_mirror_disk_footprint_within_budget`).

Generator: `scripts/mirror_trial_workspace.py` — idempotent; part of
the M6.8 regression reproducibility contract. Key transforms per
mirror:

1. full tree copy via `shutil.copytree(symlinks=False)`
2. both `runtime_state.json` copies rewritten with mirror's profile
3. `config/profiles/` replaced with single `<profile>.json` copied
   from the authoritative `config/profiles/`
4. `runtime/logs/mcp_audit.jsonl` every event's `runtime_profile`
   rewritten (not truncated — verify.py fails 3 categories on an
   empty audit log)
5. `__pycache__/` + `.DS_Store` purged from copy
6. self-check: config/profiles single-JSON + nested runtime_state
   profile fields match

**Empirical confirmation** (all 5 mirrors at M6.3 close):

| mirror | SCAFFOLD verdict | GUIDED verdict |
|---|---|---|
| codex | PASS (exit 0) | PASS (exit 0) |
| cursor | PASS (exit 0) | PASS (exit 0) |
| claude_code_agent_teams | PASS (exit 0) | PASS (exit 0) |
| claude_code_subagents | PASS (exit 0) | PASS (exit 0) |
| default_beta_codex_tapd_git | PASS (exit 0) | CONDITIONAL (exit 1; 1 WARN) |

P6's GUIDED WARN is `init WARN runtime_state.profile='default_beta_codex_tapd_git' not in known enum`, confirming G-b2 (and surfacing an adjacent gap: verify.py's init-check hard-codes the 5-core-profile enum). Both are M6.8 regression territory — M6.3 does not touch verify.py.

### §5 refinement (post-M6.4 — 2026-05-05)

M6.4 confirmed the M6.3 closing matrix was **silence, not parity**:
the verifier had no rule capable of distinguishing codex from its
negation.  M6.4 added a negative-boundary mirror plus two narrow
cross-checks to fix that.

**Negative mirror**: `trial_workspaces/rh_sprint_sim_01__codex_negative/`
generated via `mirror_trial_workspace.py --inject-violation
contract_drift --profile codex` (opt-in flag; default no-op so the 5
positive mirrors regenerate byte-identical).  Fixture injects
`coordination_model: private_coordinated` + `writeback_owner:
main_session` into the nested runtime_state.json — both contradict
the codex profile JSON ground truth (`parent_subagents` / `parent`).

**Verifier**: `check_init_integrity` gained two cross-checks gated on
`runtime_state.profile == "codex"` AND the contract field being
explicitly declared in state.  Both fire WARN.  Patch size: +29
lines (within EP scope-guard ≤30; M6.4 plan §3.1).

**Post-M6.4 verdict matrix** (live re-run after the fix):

| profile / workspace                              | SCAFFOLD | GUIDED                  |
|--------------------------------------------------|----------|-------------------------|
| codex / `rh_sprint_sim_01__codex`                | PASS     | PASS                    |
| codex / `rh_sprint_sim_01__codex_negative`       | PASS *   | **CONDITIONAL (2 WARN)**|
| cursor / `rh_sprint_sim_01__cursor`              | PASS     | PASS                    |
| claude_code_agent_teams / `..__claude_code_agent_teams` | PASS | PASS                |
| claude_code_subagents / `..__claude_code_subagents`     | PASS | PASS                |
| default_beta_codex_tapd_git / `..__default_beta_codex_tapd_git` | PASS | PASS (G-b2 RESOLVED in M7.0) |

\* SCAFFOLD on negative mirror skips `init` category entirely (only
`execution,external` per maturity floor), so the new cross-checks do
not run — by design.

**Phase 3 candidate** (do not collapse in Stage 2): once M6.5–M6.7
each carry at least one cross-check, audit whether a unified
schema-driven cross-checker (read profile JSON contract fields →
emit WARN per drift) supersedes the per-profile if-tree.  See
`ltm/failures/2026-05-05_codex_silent_pass_blindness.md` Lesson +
Phase 3 candidate sections.

### §5 refinement (post-M6.5 — 2026-05-05)

M6.5 reproduced the same blindness pattern on the cursor profile.
The cursor `rh_sprint_sim_01__cursor` mirror still passed cleanly
after M6.4, but the negative cursor mirror (with
`coordination_model=private_coordinated` and
`writeback_owner=main_session` injected) also passed cleanly — proof
that the codex cross-check does not transitively cover cursor.
M6.5 added a symmetric cursor block to `check_init_integrity`
(declared=='cursor', expects `parallel_agents` /
`reviewed_apply_owner`), 26 lines, ≤30 EP scope-guard preserved.

**Post-M6.5 verdict matrix** (live re-run after the fix; +1 row vs
post-M6.4 matrix):

| profile / workspace                                 | SCAFFOLD | GUIDED                  |
|-----------------------------------------------------|----------|-------------------------|
| codex / `rh_sprint_sim_01__codex`                   | PASS     | PASS                    |
| codex / `rh_sprint_sim_01__codex_negative`          | PASS *   | CONDITIONAL (2 WARN)    |
| cursor / `rh_sprint_sim_01__cursor`                 | PASS     | PASS                    |
| cursor / `rh_sprint_sim_01__cursor_negative`        | PASS *   | **CONDITIONAL (2 WARN)**|
| claude_code_agent_teams / `..__claude_code_agent_teams` | PASS | PASS                |
| claude_code_subagents / `..__claude_code_subagents`     | PASS | PASS                |
| default_beta_codex_tapd_git / `..__default_beta_codex_tapd_git` | PASS | PASS (G-b2 RESOLVED in M7.0) |

\* SCAFFOLD on negative mirror skips `init` category entirely (only
`execution,external` per maturity floor), so the new cross-checks do
not run — by design.  Same caveat as M6.4 codex_negative.

Two postmortems now sit side-by-side in `ltm/failures/`:
`2026-05-05_codex_silent_pass_blindness.md` (M6.4) +
`2026-05-05_cursor_silent_pass_blindness.md` (M6.5), forming the
first two-sample evidence ladder for the recipe.  M6.6/M6.7 will
extend this to four samples; Phase 3 audit unblocks at that point.

### §5 refinement (post-M6.6 — 2026-05-05)

M6.6 reproduced the same blindness pattern on the
claude_code_agent_teams profile.  The positive
`rh_sprint_sim_01__claude_code_agent_teams` mirror still passed
cleanly after M6.4 / M6.5, but the negative claude_teams mirror
(with the same `coordination_model=private_coordinated` /
`writeback_owner=main_session` injection used for codex / cursor
also passed cleanly — third consecutive proof that the existing
per-profile cross-checks do not transitively cover other profiles.
M6.6 added a symmetric claude_teams block to
`check_init_integrity` (declared=='claude_code_agent_teams',
expects `lead_teammates` / `lead`), 27 lines, ≤30 EP scope-guard
preserved.

**Post-M6.6 verdict matrix** (live re-run after the fix; +1 row vs
post-M6.5 matrix):

| profile / workspace                                 | SCAFFOLD | GUIDED                  |
|-----------------------------------------------------|----------|-------------------------|
| codex / `rh_sprint_sim_01__codex`                   | PASS     | PASS                    |
| codex / `rh_sprint_sim_01__codex_negative`          | PASS *   | CONDITIONAL (2 WARN)    |
| cursor / `rh_sprint_sim_01__cursor`                 | PASS     | PASS                    |
| cursor / `rh_sprint_sim_01__cursor_negative`        | PASS *   | CONDITIONAL (2 WARN)    |
| claude_code_agent_teams / `..__claude_code_agent_teams` | PASS | PASS                |
| **claude_code_agent_teams / `..__claude_code_agent_teams_negative`** | **PASS \*** | **CONDITIONAL (2 WARN)** |
| claude_code_subagents / `..__claude_code_subagents`     | PASS | PASS                |
| default_beta_codex_tapd_git / `..__default_beta_codex_tapd_git` | PASS | PASS (G-b2 RESOLVED in M7.0) |

\* SCAFFOLD on negative mirror skips `init` category entirely (only
`execution,external` per maturity floor), so the new cross-checks do
not run — by design.  Same caveat as M6.4/M6.5.

Three postmortems now form the evidence ladder:
`2026-05-05_codex_silent_pass_blindness.md` (M6.4) /
`2026-05-05_cursor_silent_pass_blindness.md` (M6.5) /
`2026-05-05_claude_teams_silent_pass_blindness.md` (M6.6).

**M6.7 cross-check dimension WARNING**: claude_code_subagents
profile JSON declares `coordination_model = parent_subagents` and
`writeback_owner = parent` — **identical** to codex.  M6.7 cannot
reuse coordination_model + writeback_owner with `private_coordinated`
+ `main_session` as drift values, because the per-profile if-block
shape would still detect drift, but the *meaning* of the test
becomes ambiguous (the claude_subagents block expects the same
values codex expects).  M6.7 entry must pick a different dimension
pair from the claude_subagents profile JSON; candidates include
`audit_collector` (claude_subagents_collector ground truth) or
`context_loading_method` (claude_docs_plus_hooks).  Decision
deferred to M6.7 plan ASK.

### §5 refinement (post-M6.7 — 2026-05-05)

M6.7 reproduced the silent-PASS pattern a fourth time on the
claude_code_subagents profile, but with a structurally distinct
fix: the cross-check pair switched from coordination_model +
writeback_owner (used by M6.4/M6.5/M6.6) to **audit_collector +
context_loading_method**, because claude_subagents shares
coordination_model + writeback_owner ground truth with codex
(both `parent_subagents` / `parent`).  This is the first
asymmetric block in the per-profile if-tree, and it is the
strongest input the Phase 3 audit can have.

EP decisions (M6.7 plan ASK):
- Q1 = A: audit_collector + context_loading_method
- Q2 = A: WARN (uniform with M6.4-M6.6)
- Q3 = A: strict 7-step recipe with silent-PASS proof

verify.py block: 28 lines, ≤30 EP scope-guard preserved.

**Post-M6.7 verdict matrix** (live re-run after the fix; +1 row vs
post-M6.6 matrix):

| profile / workspace                                 | SCAFFOLD | GUIDED                  |
|-----------------------------------------------------|----------|-------------------------|
| codex / `rh_sprint_sim_01__codex`                   | PASS     | PASS                    |
| codex / `rh_sprint_sim_01__codex_negative`          | PASS *   | CONDITIONAL (2 WARN)    |
| cursor / `rh_sprint_sim_01__cursor`                 | PASS     | PASS                    |
| cursor / `rh_sprint_sim_01__cursor_negative`        | PASS *   | CONDITIONAL (2 WARN)    |
| claude_code_agent_teams / `..__claude_code_agent_teams` | PASS | PASS                |
| claude_code_agent_teams / `..__claude_code_agent_teams_negative` | PASS * | CONDITIONAL (2 WARN) |
| claude_code_subagents / `..__claude_code_subagents`     | PASS | PASS                |
| **claude_code_subagents / `..__claude_code_subagents_negative`** | **PASS \*** | **CONDITIONAL (2 WARN)** |
| default_beta_codex_tapd_git / `..__default_beta_codex_tapd_git` | PASS | PASS (G-b2 RESOLVED in M7.0) |

\* SCAFFOLD on negative mirror skips `init` category entirely (only
`execution,external` per maturity floor), so the new cross-checks do
not run — by design.  Same caveat as M6.4-M6.6.

Four postmortems now form the complete per-profile evidence ladder
for Stage 2:
`2026-05-05_codex_silent_pass_blindness.md` (M6.4) /
`2026-05-05_cursor_silent_pass_blindness.md` (M6.5) /
`2026-05-05_claude_teams_silent_pass_blindness.md` (M6.6) /
`2026-05-05_claude_subagents_silent_pass_blindness.md` (M6.7).
M6.8 = regression suite, M6.9 = Stage 2 close.

### §5 refinement (post-M6.8 — 2026-05-05)

M6.8 locks the post-M6.7 verdict matrix into an end-to-end
regression test (`tests/test_stage_2_regression_r1.py`).  The
test parametrises over **16 matrix rows** (6 positive mirror × 2
maturity = 12; 4 negative mirror × GUIDED = 4) plus 1 matrix-size
lock case.  Each parametrised case spawns
`scripts/beta_sprint_driver.py` as a subprocess (matching
production / CI invocation), parses the JSON envelope, and
asserts on **four signal fields**: verdict / error_count /
warn_count / init-WARN contract_field set.

EP decision (M6.8 plan ASK):
- Q1 = A: 16-verdict matrix end-to-end regression (subprocess driver)
- Q2 = A: single new file `tests/test_stage_2_regression_r1.py`
- Q3 = A: subprocess driver invocation (vs in-process verify.main)

Why the in-process unit-layer was not enough: the 4 per-profile
cross-check tests already cover `check_init_integrity` directly.
M6.8 fills the *integration* layer — driver CLI contract (M6.2),
mirror tree (M6.3), `--inject-violation` opt-in (M6.4 generator),
4 per-profile blocks (M6.4-M6.7), maturity gate (M6.0b → M6.2)
all wire up here for the first time in a single suite.

Why subprocess (and not `verify.main()`): the driver is a CLI
entry point; production usage is `python3 scripts/beta_sprint_driver.py
…`.  Subprocess exercises argparse, sys.path discovery, JSON
serialisation, and exit code handling — paths an in-process call
to `main()` skips.

**Post-M6.8 verdict matrix unchanged from post-M6.7** — M6.8 is
purely a witnessing layer, no source code changes to verify.py
or the mirror generator.  Inventory §5 post-M6.7 table remains
the canonical 9-row reference; the regression test's 16 rows
expand it to per-maturity granularity (each post-M6.7 row
breaks into its SCAFFOLD/GUIDED component, plus the 4
negative-mirror GUIDED-only rows).

The matrix-size lock test (`test_matrix_size_locked`) makes any
future change to the matrix surface intentional friction —
adding a row in v4.90+ requires updating both the regression test
*and* this inventory section in the same commit.

---

## §6 DoD (M6.1 exit criteria)

All must hold before M6.1 is declared DONE:

- [x] §2 combo table has 12 rows covering 6 profile × 2 maturity × 1 shape
- [x] §3 gap classification has ≥1 row in each of categories (a)/(b)/(c)
- [x] §3 every gap carries a milestone resolver label (M6.2 / M6.3 / M6.6 / M6.8)
- [x] §4 driver CLI draft lists both new-file and extend-existing options with trade-offs, without picking
- [x] §5 trial workspace strategy lists both options with trade-offs, without picking
- [x] Charter §5.1 updated to reference this document as authoritative 12-combo list
- [x] Charter §7 Q1 marked **RESOLVED (B)** with date 2026-05-05
- [x] v4.88_Release byte-lock intact — `shasum -c /tmp/v488_release_baseline.sha` → 539 OK / 0 FAILED
- [x] `AI_Game_Dev_OS_v4.89/tests/` pytest → 65/65 PASSED (no code changes)
- [x] Single commit diff scope: `docs/06_runtime_profiles/STAGE_2_MATRIX_INVENTORY.md` (+1 file) and `docs/06_runtime_profiles/STAGE_2_5_PROFILE_PARITY_CHARTER.md` (§5.1 / §7 edits)

### Handoff paragraph → M6.2

> M6.2 inherits the driver CLI draft in §4.1 and must, as its entry gate, pick between Option A (new `scripts/beta_sprint_driver.py`) and Option B (extend `scripts/verify_beta_sprint_exit.py`). The pick MUST be recorded as charter §7 Q5 **RESOLVED (A|B)** in the same commit that introduces the first line of driver code. The 3 back-compat rules (B1-B4) in §4.2 are non-negotiable — any M6.2 commit that breaks P1-SCAFFOLD / P1-GUIDED Phase 1 baseline verdict is a regression and must be reverted, not patched. Category (b) gaps G-b1 (P4 `experimental_feature`) and G-b2 (P6 missing `context_loading_method`) are informational for M6.2 but become action items for M6.6 and M6.2/M6.8 respectively. Category (c) gaps depend on M6.3's workspace strategy pick.

---

**— M6.1 INVENTORY END —**
