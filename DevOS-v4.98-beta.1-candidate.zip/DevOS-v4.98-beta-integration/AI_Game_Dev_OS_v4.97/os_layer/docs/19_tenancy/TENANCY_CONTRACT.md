# Tenancy Boundary Contract

> **Layer 1 (OS Core Spec)** — this document is project-name-free by invariant.
> Concrete project examples live under Layer 2 case studies (e.g. future
> `docs/19_tenancy/TENANCY_CASE_*.md`). Lint rule: `lint_layer_separation.py`
> guards every path matched by the `LAYER_1_ROOTS` glob set, including
> `docs/19_tenancy/`.

## 1. Why this contract exists

The Core release tree is shared across multiple adopting projects. A project
running its sprint loop captures memory entries, writes runtime caches, and
maintains adoption state — all of which are **legitimate runtime data** but
**must not be confused with Core release content**. Without an explicit
boundary, the release auditor (`verify_release_clean_tree.py`) cannot
distinguish:

- a file that should be in `RELEASE_MANIFEST.json::required_manifest_files`
  (Core release content) from
- a file that is the legitimate output of an adopting project's runtime
  (project-sovereign content).

Treating the latter as the former silently couples the Core release to a
specific project. Treating it as "extra" wrongly blocks the project. Both
outcomes erase the multi-tenant property of the Core.

The Tenancy Boundary Contract resolves this without granting the Core any
knowledge of specific projects. It is **bidirectional**: the Core declares
which path templates can be claimed; each adopting project explicitly claims
the concrete instantiation. Both halves must be present for a path to be
accepted by the auditor.

## 2. Scope

In scope (this contract governs):

- `RELEASE_MANIFEST.json` `classification_rules.tenant_runtime` block and
  the companion `tenant_runtime_entries[]` template list.
- `.ai_dev_os/project_runtime_protocol.yaml` `runtime_namespace.claims[]`
  block.
- The auditor reconciliation rule (implemented by `F-V-01`).
- The runtime-tree lint rule for project-id leaks (implemented by `F-V-01`).
- Cross-tenant promotion eligibility flag (`promotion_target`, consumed by
  `F-X-01`).

Out of scope:

- The semantics of `ltm/project/<project_id>/` content itself (governed by
  `docs/15_ltm_v2/`).
- The 9-state proposal ledger that gates cross-tenant promotion (governed
  by `docs/17_self_evolution/`).
- The atomic adoption lifecycle that produces a project's
  `runtime_namespace` block (governed by `docs/19_tenancy/ADOPTION_LIFECYCLE.md`,
  introduced by F-I-01).

## 3. Bidirectional occupation rule

A path `P` under the Core release tree is a **legitimate tenant runtime
path** if and only if all of the following hold:

1. The Core's `RELEASE_MANIFEST.json` declares a `tenant_runtime_entries[]`
   item whose `path_template` matches `P` after the literal token
   `<project_id>` is substituted with some valid project identifier.
2. Exactly one adopting project's
   `.ai_dev_os/project_runtime_protocol.yaml` declares a
   `runtime_namespace.claims[]` entry whose `path_glob` is the concrete
   instantiation of that template, with the substituted token equal to that
   project's `project_id`.
3. The substituted `project_id` matches the kebab/snake-case shape pattern
   `^[a-z][a-z0-9_-]*$` and is the one that owns the project yaml.

If any of (1), (2), (3) fails, `P` is **not** a tenant runtime path.
`verify_release_clean_tree.py` then treats `P` exactly as it always has:
absent from `required_manifest_files` and not matching any other exclusion,
it surfaces as `extra`.

### 3.1 Why both halves are mandatory

| Scenario                                 | Allowed? | Why |
|------------------------------------------|----------|-----|
| Manifest declares template; no project claims it | No  | A path appearing under the template is unowned and unauditable. |
| Project claims a path; manifest has no template  | No  | The Core has not granted that path tree to tenancy; the project is squatting. |
| Manifest template + project claim both present, but `project_id` mismatch | No | Cross-tenant leak; one project would be authoring under another's namespace. |
| Two projects both claim the same instantiation   | No  | Tenancy must be exclusive; the verifier flags both. |
| Manifest template + matching project claim       | Yes | This is the only legitimate state. |

### 3.2 Asymmetric shape

The two halves are deliberately structurally distinct so the asymmetric
occupation is visible in the file shapes themselves:

- **Manifest side** holds *generic templates*. The literal token
  `<project_id>` MUST appear exactly once. Concrete project ids never appear
  here — that would violate the Layer 1 invariant (`inv_002`).
- **Project side** holds *concrete claims*. The path glob MUST contain the
  project's own `project_id` exactly where the template's `<project_id>`
  placeholder is. The placeholder syntax never appears in the project
  claim.

The two sides cross-check at audit time but never share storage.

## 4. Path template shape

Manifest `path_template` rules:

- POSIX-style glob.
- Must end with `/**` (tenancy is a tree concept; single-file ownership is
  out of scope).
- Must contain the literal substring `<project_id>` exactly once.
- Must NOT contain backslashes, `..` segments, or absolute paths.
- Length 1–256 characters.

Project `path_glob` rules:

- POSIX-style glob.
- Must end with `/**`.
- The substring corresponding to the manifest's `<project_id>` placeholder
  must equal the owning project's `project_id`.
- Same forbidden tokens (`\\`, `..`, leading `/`).
- Length 1–256 characters.

## 5. Verifier behaviour (F-V-01 contract preview)

`scripts/governance/verify_release_clean_tree.py` performs three steps:

1. **Walk** the actual file tree, producing a set of paths not in
   `required_manifest_files`, not matching `self_referential` or
   `transient_patterns`, not under `generated_runtime_outputs`.
2. **Match** each remaining path against every `tenant_runtime_entries[]`
   `path_template`. For each match, extract the `<project_id>` substitution.
3. **Reconcile** by loading every adopting project's
   `.ai_dev_os/project_runtime_protocol.yaml` discovered under known
   project roots and confirming that the extracted `project_id` claims the
   matched glob in its `runtime_namespace.claims[]`. Paths that pass this
   reconciliation become legitimate tenant runtime; the rest remain
   `extra`.

Discovery of adopting projects is intentionally simple: the verifier reads
a registry of project roots (TBD by F-I-01 — the adoption journal is the
canonical source). Until F-I-01 lands, F-V-01 reads project yamls directly
from a single configured root or from a sibling `trial_workspaces/`-style
location. The shape of that registry is internal to F-V-01; the contract
this document describes is unchanged regardless.

## 6. Linter behaviour (F-V-01 lint rule preview)

`scripts/governance/lint_layer_separation.py` extends its scan from doc and
schema roots into the runtime tree. New rule:

> A `project_id` literal appearing under any path that is **not** an
> instantiated tenancy claim is a Layer 1 leak.

This means: `project_id` strings can legitimately appear inside paths
matched by `path_template` substitution (because that's where the claim
puts them) and inside the project's own yaml. They cannot appear anywhere
else under a Core-tracked path.

## 7. Promotion eligibility

The manifest entry's `promotion_target` flag controls whether the F-X-01
cross-tenant promotion gate accepts proposals to promote content from a
project's claim into a non-tenant location (`ltm/cross_project/`,
`ltm/pattern/`, etc.). The flag does not, by itself, promote anything; it
merely declares which tenancy domains are eligible inputs to the
proposal-gated promotion flow.

## 8. Versioning and evolution

| Artifact | Version | Bump rule |
|----------|---------|-----------|
| `schemas/tenancy/tenancy_boundary.schema.json` | `1.0.0` | Patch on shape changes; major on contract reinterpretation. |
| `schemas/protocol/project_runtime_protocol.schema.json` | `1.0.0` | Pinned at 1.0.0 by `inv_007`; new fields land as optional extensions only. |
| `RELEASE_MANIFEST.json` `manifest_schema_version` | `2.3` | Bumped from 2.2 by F-T-01; future tenancy changes bump again. |

New tenant runtime templates can be added to `tenant_runtime_entries[]`
without bumping `manifest_schema_version`, provided the schema shape itself
does not change. Adding new authority kinds (currently only
`adopting_project`) DOES bump the schema.

## 9. Anti-patterns (forbidden by charter)

- Adding `ltm/project/**` (or any tenant runtime tree) to
  `transient_patterns` or `generated_runtime_outputs`. Treats project
  sovereignty as noise.
- Registering a specific project's files into `required_manifest_files`.
  Couples the Core release to one project.
- Hard-coding any `project_id` value anywhere in the manifest, schemas,
  Core scripts, or non-fixture tests.
- Adding a `--allow-extra` or `--skip-tenant` flag to the verifier.
  Structurally hides the gap.
- Auto-promoting tenant content based solely on an evidence threshold.
  Bypasses the intent gate.

## 10. Where to read next

- Schema source of truth: `schemas/tenancy/tenancy_boundary.schema.json`.
- Project-side schema extension: `schemas/protocol/project_runtime_protocol.schema.json`
  (`runtime_namespace` block).
- Manifest template list: `RELEASE_MANIFEST.json::tenant_runtime_entries[]`.
- Verifier (when F-V-01 lands): `scripts/governance/verify_release_clean_tree.py`.
- Adoption lifecycle (when F-I-01 lands): `docs/19_tenancy/ADOPTION_LIFECYCLE.md`.
- Cross-tenant promotion (when F-X-01 lands): `docs/19_tenancy/CROSS_TENANT_PROMOTION.md`.
