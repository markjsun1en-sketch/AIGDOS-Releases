# docs/19_tenancy/

> **Layer 1 (OS Core Spec)** — project-name-free by invariant.

## What lives here

v4.91 F-T-01 introduces the **Tenancy Boundary Contract** — the rule by
which the Core release tree distinguishes its own content from runtime
data sovereign to adopting projects.

| Document | Purpose | Introduced by |
|----------|---------|---------------|
| [`TENANCY_CONTRACT.md`](TENANCY_CONTRACT.md) | The bidirectional occupation rule between `RELEASE_MANIFEST.json` and project `runtime_namespace` claims. | F-T-01 (v4.91) |
| `ADOPTION_LIFECYCLE.md` | Atomic adoption transaction (mount_core → register_tenant → seed_runtime_namespace → emit_journal_entry) with rollback contract. | F-I-01 (v4.91, lands next) |
| `CROSS_TENANT_PROMOTION.md` | Proposal-gated promotion of project-local content into shared LTM domains. | F-X-01 (v4.91, lands last) |

## Charter alignment

This directory is one of the four landing zones for v4.91's Multi-Tenant
Runtime Sovereignty release theme. The four EP-defined keywords map as:

- **Stable** — adoption transaction (F-I-01 → `ADOPTION_LIFECYCLE.md`)
- **Verifiable** — tenancy-aware verifier + lint (F-V-01 → `scripts/governance/`)
- **Isolated** — boundary contract (F-T-01 → `TENANCY_CONTRACT.md`)
- **Intent-bounded experience flow** — promotion ledger gate
  (F-X-01 → `CROSS_TENANT_PROMOTION.md`)

## Layer policy

Every file in this directory is Layer 1: it describes generic rules that
apply to all adopting projects without naming any of them. Concrete
project examples (case studies) belong under sibling files matching the
exemption pattern `TENANCY_CASE_*.md`, which the layer-separation lint
allows for project-specific evidence.

## See also

- `schemas/tenancy/` — formal schema for the boundary contract.
- `schemas/protocol/project_runtime_protocol.schema.json` — the
  project-side `runtime_namespace` extension.
- `RELEASE_MANIFEST.json::classification_rules.tenant_runtime` — the
  Core-side template declaration block.
- `docs/15_ltm_v2/` — the LTM domain model that produces the canonical
  tenant runtime tree (`ltm/project/<project_id>/`).
- `docs/20_project_mount/MOUNT_CONTRACT.md` — the **mount-level**
  superset of the F-T-01 tenancy contract (relocated from
  `docs/19_tenancy/` to `docs/20_project_mount/` in v4.91 Addendum-A
  for separation of concerns: tenancy = path-level boundary, mount =
  adoption-level boundary).
