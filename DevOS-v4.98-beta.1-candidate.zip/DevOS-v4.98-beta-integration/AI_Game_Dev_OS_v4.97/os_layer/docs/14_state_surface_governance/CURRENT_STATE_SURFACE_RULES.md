# Current State Surface Rules

> **Skeleton — v4.90 Batch 3 Step 1**
> **Layer 1 (OS Spec)** — no project names

## Required Fields per Surface

Every Tier 1 (current state) surface MUST declare:

```yaml
surface_kind: <sprint_board | agent_log | orchestrator_log | task_state | ...>
line_count_policy: standard | strict | lenient
content_kinds_allowed: [<list of allowed content categories>]
content_kinds_forbidden: [<list of explicitly forbidden categories>]
```

## Default Line-Count Policy Tiers

| Policy | sprint_board | agent_log | orchestrator_log |
| --- | ---: | ---: | ---: |
| `lenient` | ≤ 200 | ≤ 250 | ≤ 400 |
| `standard` (default) | ≤ 80 | ≤ 150 | ≤ 200 |
| `strict` | ≤ 50 | ≤ 100 | ≤ 120 |

Projects may override these defaults in `state_surface_policy.yaml`, but
a project that violates its own policy at audit time fails CI.

## Forbidden Content (universal)

A Tier 1 surface MUST NOT contain:

1. **Closed sprint summaries** beyond the most recent (one-line pointer max)
2. **Full handoff text** (only the latest handoff id + path)
3. **Routing decision history** (delegate to `orchestrator_decision_index`)
4. **Task evidence dumps** (delegate to per-task `current_summary` files)

## Required Sections (universal)

A Tier 1 agent log MUST contain (or pointer to) these sections:

```text
- Current Hot State
- Current Task
- Current Truth
- Active References
- Next Step
```

A Tier 1 sprint board MUST contain:

```text
- Sprint header (id / status / start / end)
- Active task rows (current sprint only)
- Current evidence pointer
- Index links (sprint_index, task_index)
```

## Active-Window Rule (for agent logs)

The "active window" of an agent log is the most recent N entries that
remain operationally relevant. Default N is determined by the
`line_count_policy` tier, NOT by date.

When the active window threshold is exceeded:

1. Older entries move to `logs/agents/archive/<period>/<agent>.md` (Tier 3)
2. The active log retains a one-line pointer: `→ archive/<period>/`
3. The agents/index.md is updated to reflect the move

## Schema

`schemas/governance/state_surface_policy.schema.json` validates the
per-project policy declaration.

## Layer Discipline

Layer 1 (OS Spec). No project names.
