# Cold-Start Readset Rules

> **Skeleton — v4.90 Batch 3 Step 1**
> **Layer 1 (OS Spec)** — no project names

## Purpose

When a runtime / agent / consumer cold-starts, what files does it
load by default to reach a usable state? This rule defines the **OS
minimum readset contract**: a small fixed set of paths every adopting
project must guarantee. Projects may extend the readset; they may NOT
shrink it below the minimum.

## OS Minimum Readset Contract (5 + 2)

The minimum contract, in load order:

```text
1. PROJECT_RUNTIME_PROTOCOL declaration   .ai_dev_os/project_runtime_protocol.yaml
2. agents index                           logs/agents/index.md
3. sprint board (current state)           tasks/sprint_board.md
4. sprint index                           tasks/sprint_index.md
5. task index                             tasks/task_index.md
6. orchestrator hot state                 logs/orchestrator_log.md
7. open issues                            logs/open_issues.md
```

Why 7 items?
- (1) tells the consumer which OS Core version is mounted
- (2-3) answer "what's happening / who is on it" — minimal Tier 1 content
- (4-5) answer "where to find anything else" — minimal Tier 2 routing
- (6) answers "what decisions are in flight"
- (7) answers "what needs human attention"

A project that cannot supply all 7 cannot pass `validate_cold_start_readset.py`.

## Project Extensions

Projects may add to the readset via
`state_surface_policy.yaml` under `cold_start_minimum_contract.project_extensions`:

```yaml
cold_start_minimum_contract:
  enabled: true
  project_extensions:
    - tasks/summaries/<active_task>_current_summary.md
    - Docs/Planning/MILESTONES.md
```

Project extensions are loaded AFTER the OS minimum, in declaration order.

## Readset Forbids

The cold-start readset MUST NOT include:

1. Files carrying "DO NOT LOAD BY DEFAULT" header (archives)
2. Files larger than `cold_start_max_file_size` (default 50 KB)
3. Generated artifacts (under `exports/`, `runtime/state/transient/`, etc.)
4. Test fixtures (paths matching `tests/`, `fixtures/`, `_mock_baselines/`)

`validate_cold_start_readset.py` checks all four constraints.

## Project-Side Implementation

Projects integrate with cold-start by writing their readset to
`runtime/config/context_profiles_manifest.json` (or equivalent) and
declaring the same paths in their `state_surface_policy.yaml`. The
two declarations must match — drift is a CI failure.

## Schema

`schemas/governance/cold_start_readset.schema.json` defines the readset
declaration shape. Skeleton in Batch 3 Step 1.

## Layer Discipline

Layer 1 (OS Spec). No project names. Real-world readset extension
examples belong in case-study files.
