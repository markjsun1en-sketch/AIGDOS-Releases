---
title: V4.89 Reference Audit
version: 1.0
status: closed
layer: layer_1_os_spec
since_batch: 14.4
protected_invariants:
  - inv_004_no_v4_89_active_stale_in_v4_90
---

# V4.89 Reference Audit — Step 14.4 / Consistency Audit C-05

> **Status**: ✅ Closed (Step 14.4 — 2026-05-15)
> **Tier**: Layer 2 case study (this document) + Layer 1 OS Spec (audit + lint scripts)
> **Branch**: `release/v4.90-fork`
> **Pre-fix HEAD**: `b70fa3f` (Step 14.3 closure)
> **Audit tooling**:
> - `scripts/audit/audit_v4_89_references.py` (GUIDED, 4-class classifier)
> - `scripts/lint/check_v4_89_baseline_integrity.py` (GUIDED, long-term invariant guard)

---

## 1. Mandate & method

### 1.1 Premise

The v4.90 working tree is forked from v4.89_Release and **deliberately
keeps the v4.89_Release tree in place as a byte-locked reference layer**.
This means literal `v4.89` strings appear in the working tree by design
in many places: byte-lock declarations, fork-point footprints, "Compatible
OS Baseline" pack manifests, runtime baseline pointers, historical
changelog entries, failure-case studies, etc.

A naive grep finds **1469 line-level / 307 file-level** occurrences of
`v4.89` / `"4.89"` in the v4.90 working tree (across `.md / .yaml /
.json / .py / .jsonl / .txt`). The Batch 14 plan initially treated
this number as a remediation target ("305 stale references"). On closer
inspection, the vast majority are legitimate — the audit's job is to
**separate legitimate references from genuine staleness**.

### 1.2 Method

Inspired by a prior sprint-level closure-consistency audit methodology
(see EP-tracked external reference, codename "332" — full citation
preserved in `MEMORY.md` outside Layer 1) and its `stale phrase family`
approach, we classify every match-line into one of four classes:

| Class | Label | Meaning | Treatment |
|---|---|---|---|
| **A** | `HISTORICAL_OK_BASELINE` | Legitimate baseline / fork-point / byte-lock declaration | Never modify |
| **B** | `HISTORICAL_OK_CHANGELOG` | Historical changelog / v4.89-era artifact / failure-case / LTM project knowledge | Never modify |
| **C** | `ACTIVE_STALE` | Self-identification claims that contradict v4.90 reality | Must fix |
| **D** | `INTENTIONAL_OPEN` | Known future migration items (e.g. v4.91 engine_pack split) | Tracked, not fixed in this batch |

### 1.3 Classifier priority

```
migration-arrow override (v4.89 → v4.90)  →  Class B
   ↓
Class C (stale phrase family)
   ↓
Class A (baseline patterns)
   ↓
Class B (changelog patterns)
   ↓
Class D (intentional-open patterns)
   ↓
default catch-all                         →  Class B
```

**Why C before A**: legitimate baseline path patterns (e.g.
`AI_Game_Dev_OS_v4\.89_Release(?:/|\s|$)`) would otherwise swallow
inline-code self-claim like `package name: AI_Game_Dev_OS_v4.89_Release`.
Class C's stale-phrase family is deliberately narrow to avoid false
positives.

**Why migration-arrow override comes first**: any line containing
`v4.89... → v4.90` is by definition describing a change in progress
(commit message, progress table, batch summary), which is a legitimate
changelog narrative even if it textually contains `package_name v4.89_Release`.

### 1.4 Self-reference exemption

The audit tool, its tests, the lint guard, and this audit report all
contain literal example phrases (e.g. `"package name: v4.89_Release"`
in docstrings) that would otherwise self-trigger Class C. These four
files are exempt:

- `scripts/audit/audit_v4_89_references.py`
- `tests/audit/test_v4_89_reference_classification.py`
- `scripts/lint/check_v4_89_baseline_integrity.py`
- `docs/14_state_surface_governance/V4_89_REFERENCE_AUDIT.md`

---

## 2. Statistics (post-fix, 2026-05-15 16:55)

| Class | Count | Share | Label |
|---|---:|---:|---|
| A | 200 | 13.6% | HISTORICAL_OK_BASELINE |
| B | 1252 | 85.3% | HISTORICAL_OK_CHANGELOG |
| C | **0** ✅ | 0.0% | ACTIVE_STALE |
| D | 15 | 1.0% | INTENTIONAL_OPEN |
| **Total** | **1467** | 100% | (across 307 files) |

**Pre-fix snapshot (Step 14.3 baseline)**: A 200 / B 1253 / C 1 / D 15 / Total 1469.

**Delta from fix**: README §"Package identity" 3 lines (`package root` /
`package name` / `version label`) all aligned to v4.90 working tree;
2 lines were grep-matched (the 3rd line `version label: 4.89-Release`
contained the bare `4.89` token which `4.90` does not).

### 2.1 Lint guard invariants

```
Class C (ACTIVE_STALE)        ceiling = 0
Class A + B (legitimate)      floor   = 500
```

Currently A+B = 1452 (margin 952 above floor). Floor is set
deliberately conservative — primary value is **regression detection**:
if a future refactor accidentally deletes large blocks of legitimate
v4.89 baseline references (e.g. truncates `game_type_packs/*/README.md`),
floor is breached and lint fails.

---

## 3. Class A samples — `HISTORICAL_OK_BASELINE`

5 representative entries (selected from 200 total):

| Path:Line | Sample | Why legitimate |
|---|---|---|
| `game_type_packs/narrative_puzzle_project_pack/checklists/PROJECT_BOOTSTRAP_CHECKLIST.md:3` | `` - [ ] `v4.89_Release Run Baseline layer` attached `` | Pack bootstrap declares the v4.89_Release reference layer it depends on; this is the **defined** layer-attachment contract |
| `game_type_packs/narrative_puzzle_project_pack/README.md:6` | `Compatible OS Baseline: v4.89_Release (Run Baseline layer)` | Compatibility declaration — pack states which OS baseline it is certified against |
| `game_type_packs/narrative_puzzle_project_pack/docs/bootstrap/STARTER_ATTACHMENT_RULES.md:7` | `` - `v4.89_Release Run Baseline layer` `` | Attachment-rules anchor; identifies a real reference path |
| `game_type_packs/narrative_puzzle_project_pack/docs/bootstrap/QUICK_START.md:21` | `` - Baseline: `v4.89_Release Run Baseline layer` `` | Quick-start invocation step pointing at byte-locked tree |
| `game_type_packs/narrative_puzzle_project_pack/docs/QUICK_START.md:3` | `` 1. Load `v4.89_Release Run Baseline layer`. `` | Concrete bootstrap command |

**Reason not to modify**: every Class A line declares or invokes the
**v4.89_Release reference layer**, which v4.90 deliberately preserves
byte-locked at SHA `bb48af169f9b4f57c4bb86ab9b82f2ddfef87767`. Removing
or renaming these would break pack-attachment contracts.

---

## 4. Class B samples — `HISTORICAL_OK_CHANGELOG`

5 representative entries (selected from 1252 total via `[::200]` stride):

| Path:Line | Sample | Why legitimate |
|---|---|---|
| `game_type_packs/spin_rogue_idle_project_pack/docs/bootstrap/PROJECT_BOOTSTRAP_STEPS.md:5` | `bootstrapping this project under AI_Game_Dev_OS v4.89_Release.` | Bootstrap-context narrative — v4.89_Release reference attachment story |
| `trial_workspaces/rh_sprint_sim_01__claude_code_subagents_negative/run_sprint.py:273` | `# v4.89 P0-Z Z1: write to the canonical path under runtime/state/.` | v4.89-era P0 phase marker, part of the trial-workspace history |
| `runtime/MATURITY_MATRIX.md:563` | `5 narrative docs landed: ... TAG_NOTE_v4.89-release-rc2.md (release-only)` | Maturity-matrix entry referring to the v4.89 release-tag artifact |
| `docs/06_runtime_profiles/PHASE_4_M9_0_COLDSTART_AUDIT.md:125` | `` `AI_Game_Dev_OS_v4.89/scripts/init_runtime_env.py`: `` | Phase-4 audit artifact (v4.89-era cold-start audit; `PHASE_4_M9` is a legitimate phase tag — D-14.4.P keeps the title) |
| `V4_90_README.md:19` | `branch release/v4.90-fork 与 commit 隔离 v4.89 / v4.90 历史` | v4.90 README narrative describing the fork-and-isolate history |

**Reason not to modify**: every Class B line is **historical narrative**
(commit messages, batch progress tables, phase tags, failure-case studies,
LTM project knowledge). Modifying these would erase audit trail.

---

## 5. Class C — `ACTIVE_STALE` — 1 stale section fix

### 5.1 Single hit

| Path:Line | Pre-fix |
|---|---|
| `README.md:53` | `` 2. package name: `AI_Game_Dev_OS_v4.89_Release`. `` |

This was the **only** line claiming the v4.90 package self-identifies
as v4.89, in direct contradiction to:
- Step 14.1's `RELEASE_MANIFEST.json` fix (`package_name` → `v4.90`)
- Step 14.2's `V4_90_README.md` post-RC2 status refresh

### 5.2 Fix scope (EP B decision)

Although the audit's Class C regex narrowly hit only line 53, the
README §"Package identity" opens with:

> The directory name, manifest root, and version label must stay aligned:

If only line 53 were corrected, lines 52 (`package root`) and 54
(`version label`) would remain at v4.89 wording — leaving the section
internally self-contradicting. **Per EP B decision in Step 14.4 resume
thread, the fix was extended to all 3 lines** (the entire §"Package
identity" sub-section):

```diff
-1. package root: `AI_Game_Dev_OS_v4.89_Release`.
-2. package name: `AI_Game_Dev_OS_v4.89_Release`.
-3. version label: `4.89-Release`.
+1. package root: `AI_Game_Dev_OS_v4.90` (working tree; `_Release` form deferred to post-Batch-14).
+2. package name: `AI_Game_Dev_OS_v4.90` (working tree; `_Release` form deferred to post-Batch-14).
+3. version label: `4.90`.
```

The "must stay aligned" invariant is now upheld: all three identifiers
match the v4.90 working tree.

### 5.3 Why "_Release" deferred

The v4.90 directory currently lives as `AI_Game_Dev_OS_v4.90/` (no
`_Release` suffix), per Batch 12 packaging convention. The `_Release`
suffix is a **publication-time** decoration that will be applied when
v4.90 is cut to a public release directory. README footnote
`(working tree; _Release form deferred to post-Batch-14)` makes this
explicit so readers don't expect a `v4.90_Release/` dir today.

---

## 6. Class D — `INTENTIONAL_OPEN`

15 hits, all of the form `"version": "v4.89_first_tier"` in pack manifests:

| File | Line | Field |
|---|---:|---|
| `game_type_packs/LAYER_MANIFEST.json` | 4 | `"version": "v4.89_first_tier"` |
| `game_type_packs/narrative_puzzle_project_pack/manifests/pack_definition.json` | 4 | same |
| `game_type_packs/generic_project_starter/manifests/pack_definition.json` | 4 | same |
| `game_type_packs/spin_rogue_idle_project_pack/manifests/pack_definition.json` | 4 | same |
| `game_type_packs/card_roguelike_project_starter/manifests/pack_definition.json` | 4 | same |
| `context_packs/LAYER_MANIFEST.json` | 5 | same |
| `context_packs/pack_selection_guide/manifests/pack_definition.json` | 4 | same |
| `context_packs/expanded_context_pack/manifests/pack_definition.json` | 4 | same |
| (… 7 more pack manifests) | — | — |

### 6.1 Why deferred

The `v4.89_first_tier` tier label is an **architectural placeholder**
awaiting v4.91's planned `engine_pack` split (see plan
`/Users/macsun/.workbuddy/plans/electric-cascade-lovelace.md` §"v4.91
roadmap"). When engine_pack splits land, all pack-tier labels will be
re-namespaced (`v4.91_engine_pack_tier1` or similar) in one coherent
migration. Renaming them now would force a duplicate migration in v4.91.

**Tracked**: lint guard's Class D bucket reports the count each run,
so accidental drift (e.g. someone adds a 16th pack) is visible.

---

## 7. EP decisions (Step 14.4)

| Decision | Choice | Effect |
|---|---|---|
| **D-14.4.X** | X-1 | audit + lint + fix true stale (1 line by classifier; expanded to 3 by EP B decision) |
| **D-14.4.P** | P-1 | `PHASE_4_M9_0_COLDSTART_AUDIT.md` title kept; v4.89 in title is a legitimate phase tag |
| **D-14.4.A2** | A2 | Absorbed external sprint-closure-audit methodology (codename "332") — `stale phrase family` approach + 4-class scheme + Closure Package Checklist (the latter for Step 14.10 closure) |
| **EP B (resume thread)** | Section-wide fix | Extended Class C fix to all 3 lines of README §"Package identity" to keep "must stay aligned" invariant |

---

## 8. Lint guard mechanism

`scripts/lint/check_v4_89_baseline_integrity.py` runs `audit()` and
asserts:

```python
violations = []
if class_C > 0:
    violations.append(f"Class C (ACTIVE_STALE) > 0: {class_C} stale lines")
if (class_A + class_B) < 500:
    violations.append(f"Legitimate references (A+B) {legit} < floor 500")
```

| Invariant | Direction | Threshold | Current | Margin |
|---|---|---:|---:|---:|
| Class C ceiling | ≤ | 0 | 0 | ∞ (cannot go lower) |
| A + B floor | ≥ | 500 | 1452 | +952 |

**CI integration**: lint guard is invoked from
`tests/audit/test_v4_89_reference_classification.py::test_lint_guard_exits_zero_on_clean_state`
as a subprocess. Each pytest run verifies exit 0.

---

## 9. Inspiration: external sprint-closure-audit framework (codename "332")

This audit is structurally a **release-level translation of** an
external sprint-level closure-consistency audit methodology that the EP
tracks under codename "332" (full project name and provenance preserved
in `MEMORY.md` outside Layer 1; not repeated here per Layer 1 OS-Spec
no-project-names rule):

| Dimension | v4.90 Batch 14.4 (this) | External "332" framework (sprint-level) |
|---|---|---|
| Scope | Release-level v4.89 ref consistency | Sprint-level status / handoff / decision consistency |
| Trigger | RC2 cut but README/manifest/schema metadata drift | Sprint REVIEW_READY but old artifacts say "still needs" |
| Classification | 4 classes (A/B/C/D) | 4 classes (ACTIVE_STALE / HISTORICAL_OK / INTENTIONAL_OPEN / NEEDS_HUMAN_DECISION) |
| Stale phrase family | `package_name.*v4\.89` etc. (9 patterns) | `still needs` / `Remaining Before Sprint DONE` etc. |
| Guard lint | A+B floor 500 / C ceiling 0 | "332" §7 sprint-closure-consistency check tool |
| Closure checklist | Batch 14.10 will adopt the 9-item checklist | "332" §6.7 D2 sprint review-ready package |

The two methodologies are **isomorphic**: feature-vs-metadata dual
track, closed via audit + lint + report + closure-gate.

### 9.1 Differences from "332"

- "332" operates on a **single sprint at a time**; this audit operates
  on the **entire v4.90 working tree** in one shot.
- "332"'s stale phrases are workflow-language ("still needs"); ours are
  identity-language ("package name").
- "332"'s guard runs on sprint close; ours runs on every pytest invocation
  (regression-detection cadence is much higher).

---

End of audit report.
