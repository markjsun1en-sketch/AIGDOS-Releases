# State Surface Migration Case — lessismore SP-115

> **Layer 2 — Project Migration Case Study**
> **Captured**: 2026-05-10
> **Source project**: `lessismore` (Slot+Roguelike+Idle+Extract Godot 4.x prototype, separate from this OS Core repo)
> **Source plan**: [`Docs/Workflow/330_State_Surface_Slimming_And_Indexing_Plan.md`](https://example.invalid/lessismore/330) (BATCH_7_DONE / RUNTIME_REGISTRY_SYNC_GUARDED, 465 lines)
> **Status**: GUIDED — first Layer 2 evidence file landed in v4.90 Batch 3.5

---

## 0. Layer 2 Notice

This file is **the only file under `docs/14_state_surface_governance/`
that is permitted to contain project-specific names** (sprint ids,
project codenames, agent role names). It is exempt from
`scripts/governance/lint_layer_separation.py` via the
`STATE_SURFACE_MIGRATION_CASE_*` regex in `LAYER_2_EXEMPTIONS`.

The exemption exists for a single purpose: **collect concrete real-world
evidence behind the Layer 1 generic rules**. Future readers should treat
this file as anchored historical context, **not** as Layer 1 doctrine.
If a clause from this case study deserves promotion to a generic rule,
it must first be re-expressed in project-name-free form and merged into
one of the Layer 1 RULES.md files; this file then references the new
clause, not the other way around.

OS Core directives (Layer 1) point ↘ at this case for evidence;
this case points ↗ at Layer 1 for the rule it instantiates. Never the
other direction.

---

## 1. Case Background

### 1.1 Project

- **Name**: `lessismore`
- **Engine**: Godot 4.x
- **OS Core baseline at time of slimming**: v4.89 (with v4.88 adoption preview tooling)
- **Workflow stack**: 80_WORKFLOW + 82_RE_ENTRY_PROTOCOL + 138_Workflow_Document_Status_Map
- **Active sprint at time of slimming**: `SP-115` (Whole Game Code Review Cleanup And Optimization)

### 1.2 Trigger

By 2026-05-10 the project's running narrative surfaces had grown to a
point where every cold-start invocation had to read large multi-purpose
files merely to recover "what is happening right now". Concretely:

| Surface | Pre-slim line count | Mixed responsibilities |
|---|---:|---|
| `tasks/sprint_board.md` | 233 | current sprint + previous sprint summaries + full historical task board + old subtasks + backlog notes |
| `logs/orchestrator_log.md` | 1139 | current orchestration + active agent table + decision history + long routing notes + sprint closure traces |
| `logs/agents/executive_producer_agent.md` | 611 | current hot state + many old routing decisions |
| `logs/agents/qa_playtest_agent.md` | 440 | current task + high-frequency historical evidence entries |
| `logs/agents/ui_ux_agent.md` | 269 | current task + accumulated visual iteration history |

These files were **frequently loaded by cold-start and re-entry flows**,
so historical content in them imposed a direct token cost and a
re-entry drift risk: re-entered agents would routinely re-derive
"current task" from a 600-line log instead of a focused current-state
surface.

### 1.3 Decision

- Owner: Executive Producer Agent + Documentation Steward
- Mandate: produce `Docs/Workflow/330_State_Surface_Slimming_And_Indexing_Plan.md` and execute it in 7 sequential batches **without changing task truth during the slimming pass**.
- Plan completed: `BATCH_7_DONE / RUNTIME_REGISTRY_SYNC_GUARDED` on 2026-05-10
- Implementation commit (single big rollup): `308919b` `codex: slim state surfaces and guard runtime sync`
- Sprint closure commit: `78cb225` `codex: close SP-115 cleanup sprint`
- Adoption preview commit: `a29d272` `codex: integrate v489 adoption closure`

This case captures the reusable structure behind the work, mapped to
v4.90 Layer 1 OS Core rules.

---

## 2. Pre-Slim State Symptoms (the "three-responsibility mix")

The 330 plan diagnosed the pre-slim state with one sentence that v4.90
adopted verbatim into Layer 1 doctrine:

> "Several live files now mix three responsibilities: (1) current state,
> (2) index / routing, (3) historical detail."

Each Tier 1 surface in lessismore pre-slim demonstrated the mix:

- `sprint_board.md` (233L) carried (1) current SP-115 row, (2) implicit routing because closed sprints had no separate index, and (3) full historical sprint summaries inline.
- `executive_producer_agent.md` (611L) carried (1) `Current Hot State` block at top, (2) historical decision references scattered through the body, and (3) the entire pre-Sprint-113 routing log.
- `orchestrator_log.md` (1139L) was the worst case: every routing decision since project inception lived next to "today's active routing".

The structural cause is **the same in every observed adoption**: a Tier 1 surface that lacks a dedicated Tier 2 index and Tier 3 archive evolves to absorb both responsibilities by accretion, because there is nowhere else to put historical content without breaking links.

The fix structure is therefore also the same: build the index shells
first, then move history out, then update the registry sync to tolerate
the new shape.

---

## 3. Migration Execution Mapped to Layer 1 Rules

This is the core of the case study. Each subsection takes one Layer 1
rule file and shows what SP-115 actually did to satisfy it.

### 3.1 `CURRENT_STATE_SURFACE_RULES.md` ← sprint_board slim

**OS Layer 1 rule (target)**:
- Tier 1 surfaces declare `surface_kind` + `line_count_policy`.
- A Tier 1 sprint board MUST contain only sprint header / active task rows / current evidence pointer / index links (`§ Required Sections`).
- Forbidden: closed sprint summaries beyond the most recent (one-line pointer max), full handoff text, routing decision history, task evidence dumps (`§ Forbidden Content`).
- Default `standard` policy: `sprint_board ≤ 80 lines`; `strict` ≤ 50.

**SP-115 implementation (BATCH_3 of the 330 plan)**:

The post-slim `tasks/sprint_board.md` (55 lines) follows exactly the
required section layout:

```text
# Sprint Board
                                    ← surface_kind: sprint_board (implicit)
## Index Routes                     ← required: index links
  → sprint_index.md
  → task_index.md
  → SP-115_current_summary.md
  → archive/2026-05-10_sprint_board_pre_slim.md
## Current Sprint                   ← required: sprint header (id/status/start/end)
  Sprint Name: SP-115
  Status: PASS_WITH_NOTE / SPRINT_CLOSED / STRUCTURAL_REFACTOR_DEFERRED
## Sprint Boundary                  ← OS-allowed extension (project policy block)
## Active Board                     ← required: active task rows (current sprint only)
  | Task ID | Task | Owner | ... |
  | SP-115  | Whole Game Code Review ... |
## Current Next Step                ← required: current evidence pointer
## Historical Lookup                ← required: index links (mirrored)
## Notes                            ← required: project-policy reminder block
```

**Quantified outcome**:
- Lines: 233 → 55 (-77%, well under `lenient` 200, comfortably under `strict` 50… actually slightly over `strict`; the project sits at `standard` per its declared policy).
- Closed sprints: removed inline summaries; a single one-line pointer to `2026-05-10_sprint_board_pre_slim.md` replaces all of them.
- Historical task rows: removed; only the active SP-115 row remains.
- Subtask blocks: removed; subtask routing now goes through `tasks/summaries/SP-115_current_summary.md`.

**Layer 1 rule satisfied via**:
- §`Required Sections` (sprint board): all six required structural blocks present.
- §`Forbidden Content`: closed sprint summary collapsed to one-line pointer; full handoffs replaced by `Latest Handoff` cell with link only; routing decisions delegated to `orchestrator_decision_index.md`.
- §`Default Line-Count Policy`: 55 lines satisfies `standard` (≤80) and `lenient` (≤200) for sprint_board.

---

### 3.2 `INDEX_SURFACE_RULES.md` ← four index shells

**OS Layer 1 rule (target)**:
- Every adopting project MUST maintain at least four indexes: `sprint_index`, `task_index`, `agents/index`, `orchestrator_decision_index` (`§ Required Index Surfaces (OS Minimum)`).
- Each row: `id / status / last_updated / detail_path` (`§ Per-Index Required Fields`).
- Routing only — no full evidence content, no narrative, no cross-index data (`§ Per-Index Required Fields, MUST NOT include`).
- Updated **at state-transition boundaries**, not continuously (`§ Index Update Discipline` clause 1).
- Written by the same actor that mutates underlying state (`§ Index Update Discipline` clause 2: "no asynchronous reconciliation").

**SP-115 implementation (BATCH_1 of the 330 plan)**:

All four OS-minimum indexes were created as routing-only shells before
any history was moved (the 330 plan calls this "Add Index Shells" and
explicitly states: *"No historical content is moved in this batch."*):

| Index | Path | Lines | Update boundary |
|---|---|---:|---|
| `sprint_index` | `tasks/sprint_index.md` | 28 | sprint open / close |
| `task_index` | `tasks/task_index.md` | 29 | task creation / status change / closure |
| `agents/index` | `logs/agents/index.md` | 21 | agent active-task change |
| `orchestrator_decision_index` | `logs/orchestrator_decision_index.md` | 32 | decision recorded / superseded |

**Quantified outcome**:
- Total Tier 2 weight: **110 lines across 4 files** — all four together are still smaller than the post-slim sprint_board.
- All four files are routing-only (rows of `id / status / date / link`); none duplicate Tier 1 content; none carry inline evidence.

**Layer 1 rule satisfied via**:
- §`Required Index Surfaces (OS Minimum)`: 4 of 4 mandatory indexes present.
- §`Index Update Discipline` clause 1: each index has a clearly declared transition boundary (matches the OS clause 1:1).
- §`Cold-Start Coupling`: all four indexes are explicitly part of the lessismore cold-start readset (see §3.4 below).

**Gap noted (for honest reporting)**:
- Per-row schema validation (`indexes:` node in `state_surface_policy.schema.json`) was added in v4.90 Batch 3 Step 3, AFTER lessismore's BATCH_1 ran. The lessismore indexes were therefore validated by manual review; v4.90-adopting projects benefit from the schema enforcement that lessismore did without.

---

### 3.3 `ARCHIVE_SURFACE_RULES.md` ← three archive snapshots

**OS Layer 1 rule (target)**:
- Tier 3 archive surfaces start with the literal header `> **DO NOT LOAD BY DEFAULT** — archive surface (Tier 3)` (`§ Mandatory Archive File Header`).
- Promotion trigger: surface exceeds `line_count_policy` upper bound, sprint closes, agent log active window exceeds threshold, or manual `slim_state_surface.py --target` (`§ Archive Promotion Trigger`).
- Two organizing strategies: `by_date` (greenfield default) or `by_sprint` (sprint-driven default); mixing forbidden (`§ Archive Strategy`).
- Read-only after creation; corrections create new archive files referencing predecessors via `predecessor_pointer` (`§ Read-Only Discipline`).

**SP-115 implementation (BATCH_3 / BATCH_4 / BATCH_5 of the 330 plan)**:

Three archive cohorts were created, all in the **`by_date`** strategy
keyed on `2026-05-10` (the slimming date):

```
tasks/archive/
  2026-05-10_sprint_board_pre_slim.md          ← 233-line snapshot of pre-slim sprint_board
  README.md
logs/orchestrator/archive/
  2026-05-10_orchestrator_log_pre_slim.md      ← 1139-line snapshot
  README.md
logs/agents/archive/
  2026-05-10_sp115_state_surface_slimming_pre_slim/
    executive_producer_agent.md                ← 611-line pre-slim
    qa_playtest_agent.md                       ← 440-line pre-slim
    ui_ux_agent.md                             ← 269-line pre-slim
    README.md
  (plus 3 prior archive cohorts from earlier sprints, also by_date)
```

**Quantified outcome**:
- 5 archive files created in this slimming pass + `README.md` index per archive directory.
- Total preserved: 233 + 1139 + 611 + 440 + 269 = **2 692 lines of historical content** kept off the cold-start path.
- Strategy chosen: `by_date`. Rationale: the slimming was a one-shot campaign tied to a single calendar date, not an ongoing per-sprint flush. Future per-sprint flushes (predicted for SP-116+) will continue with `by_date` because the project policy declared it.

**Layer 1 rule satisfied via**:
- §`Archive Promotion Trigger` clauses: all three triggers fired in this pass — sprint closure (SP-115), active window exceeded (3 high-volume agent logs), and explicit `slim_state_surface` action (sprint board + orchestrator log).
- §`Archive Strategy`: `by_date` chosen consistently; no `by_sprint` directory exists alongside (no mixing).
- §`Read-Only Discipline`: archive snapshots have not been edited since 2026-05-10; corrections (none observed) would create new dated archives.

**Gap noted**:
- The 330 plan archives **predate** the v4.90 mandatory header `> **DO NOT LOAD BY DEFAULT**`. Pre-existing archive files therefore lack that exact literal. Adopting projects entering v4.90 from a similar pre-existing archive set will need a one-time header backfill; v4.90 case-study evidence here suggests this is a low-risk mechanical pass.

---

### 3.4 `COLD_START_READSET_RULES.md` ← cold_start_pack reorder

**OS Layer 1 rule (target)**:
- OS minimum readset: 7 files in fixed load order — `project_runtime_protocol.yaml` / `agents/index.md` / `sprint_board.md` / `sprint_index.md` / `task_index.md` / `orchestrator_log.md` / `open_issues.md` (`§ OS Minimum Readset Contract`).
- Project extensions loaded AFTER the OS minimum, in declaration order (`§ Project Extensions`).
- Forbidden: files carrying `DO NOT LOAD BY DEFAULT` header / files > `cold_start_max_file_size` / generated artifacts / test fixtures (`§ Readset Forbids`).
- Project-side implementation: declare readset in `runtime/config/context_profiles_manifest.json` AND `state_surface_policy.yaml`; the two declarations must match (`§ Project-Side Implementation`).

**SP-115 implementation (BATCH_6 of the 330 plan)**:

After the four indexes existed and had correct content (precondition
the 330 plan stated: *"Update cold-start routing only after the new
indexes exist and have correct content"*), the project's cold-start
tool was retargeted:

- `tools/runtime/generate_cold_start_pack.py` updated to **prefer** task current summaries, task/sprint indexes, agent index, and decision index **before** registry evidence tails.
- `runtime/config/context_profiles_manifest.json` — the three readset profiles (`STANDARD`, `LEAN`, `V489_COMPRESSED`) all updated to include the new index stack.

**Quantified outcome (per 330 plan validation note)**:

```
generate_cold_start_pack.py --agent "Executive Producer Agent" \
                            --profile compressed --pack-mode compressed
→ active task   = SP-115
→ latest handoff = SP-115BP map_controller_remove_service_candidate_model
                   _runtime_pass
→ must_read_files            = 19
→ must_read_task_tail_truncated = false
```

19 must-read files for a cold-start of the EP role on the compressed
profile is well within budget; the same role on the same project
pre-slim would have pulled the 1139-line orchestrator log + the 611-line
EP agent log just to derive "what is the active task".

**Layer 1 rule satisfied via**:
- §`OS Minimum Readset Contract`: lessismore's `STANDARD` profile contains all 7 OS-minimum paths (the project also names them with project-specific additions, see Project Extensions below).
- §`Project Extensions`: lessismore extends with `tasks/summaries/SP-115_current_summary.md`, `Docs/Planning/MILESTONES.md`, and `Docs/Workflow/138_Workflow_Document_Status_Map.md`. All extensions load AFTER the OS minimum.
- §`Readset Forbids`: archives are excluded by glob (the manifest does not list any `archive/` path).

**Gap noted**:
- The dual-declaration requirement (`runtime/config/context_profiles_manifest.json` AND `state_surface_policy.yaml` matching) is a v4.90 OS Core requirement. lessismore declared the readset only in `context_profiles_manifest.json` because `state_surface_policy.yaml` did not yet exist as a concept when the slimming ran. **Migrating lessismore onto v4.90 requires producing `state_surface_policy.yaml` as the second declaration**; this is a one-time mechanical step and is the canonical first action for any v4.89 project adopting v4.90 P0-2.

---

### 3.5 `RUNTIME_REGISTRY_SYNC_GUARD.md` ← `sync_phase1_task_registry.py`

**OS Layer 1 rule (target — 7 required behaviours)**:
1. Preserve historical rows.
2. Update only matching rows.
3. Insert new rows.
4. Refuse silent deletion.
5. Multi-version schema tolerance.
6. Markdown marker stripping.
7. Dry-run mode.

**SP-115 implementation (BATCH_7 of the 330 plan)** — file: [`tools/runtime/sync_phase1_task_registry.py`](https://example.invalid/lessismore/sync_phase1) (187 lines):

| Required behaviour | Status | Implementation site |
|---|---|---|
| (1) Preserve historical rows | ✅ | `merge_with_existing_tasks` L138-162: existing registry rows are loaded first into `merged_by_id`, then parsed source rows update matching ids; rows present in registry but absent from source are kept by construction. |
| (2) Update only matching rows | ✅ | Same `merge_with_existing_tasks` L153-158: `merged = {**previous, **parsed}` — parsed values overlay previous, only for ids present in source. |
| (3) Insert new rows | ✅ | L159-160: `if task_id not in order: order.append(task_id)` extends the row order for new ids. |
| (4) Refuse silent deletion | ✅ | The function has no delete branch. There is no `--archive-stale` flag yet (see gap). |
| (5) Multi-version schema tolerance | ✅ | `parse_board` L108-113: `if len(parts) >= 10: ... else: parts (9 columns)` — both 10-column pre-slim and 9-column post-slim schemas are accepted in the same function. |
| (6) Markdown marker stripping | ✅ | `strip_cell_markup` L47-48: `value.strip().strip("\`").strip()` is invoked on `task_id`, `title`, `owner`, and (via `normalize_status`) on status values before they enter the JSON. |
| (7) Dry-run mode | ❌ **gap** | `main` L165-183 always writes via `TASK_REGISTRY.write_text(...)`. There is no `--dry-run` flag, no diff-only path. |

**Quantified outcome (per 330 plan validation note)**:
- After the guarded sync, `task_registry.json` contained **11 task rows preserved** plus one updated SP-115 row — the historical task population from prior sprints was not lost.
- `validate_phase1_jsonschema.py` and `validate_phase1_runtime_objects.sh` both passed after the guarded sync.

**Layer 1 rule satisfied via**:
- 6 of 7 required behaviours satisfied directly; behaviours (1)+(4) are particularly important and were the original motivation for the 330 plan BATCH_7 work.

**Gap noted (carried into §6)**:
- (7) Dry-run mode missing in lessismore's implementation. v4.90's `validate_registry_sync_guard.py` will warn-only on missing `--dry-run` (it cannot fail because project sync tools name flags inconsistently), but the rule clause is unambiguous: dry-run is required.

---

## 4. Quantified Outcomes (full picture)

### 4.1 Tier 1 size reduction

| Surface | Pre-slim | Post-slim | Reduction |
|---|---:|---:|---:|
| `tasks/sprint_board.md` | 233 | 55 | -76% |
| `logs/orchestrator_log.md` | 1139 | hot-state-only | massive (exact post-slim line count not captured in the 330 plan validation block but confirmed under the active-window threshold) |
| `logs/agents/executive_producer_agent.md` | 611 | 55 | -91% |
| `logs/agents/qa_playtest_agent.md` | 440 | 48 | -89% |
| `logs/agents/ui_ux_agent.md` | 269 | 48 | -82% |
| **Total Tier 1 (5 files)** | **2 692** | **~206** | **-92%** |

### 4.2 Tier 2 introduced (new weight)

| Index | Lines |
|---|---:|
| `tasks/sprint_index.md` | 28 |
| `tasks/task_index.md` | 29 |
| `logs/agents/index.md` | 21 |
| `logs/orchestrator_decision_index.md` | 32 |
| **Total Tier 2 (4 files)** | **110** |

### 4.3 Tier 3 preserved (off cold-start path)

- 5 archive snapshots covering 2 692 lines of historical content
- All carry README index files in archive directories

### 4.4 Cold-start pack outcome

- `V489_COMPRESSED --pack-mode compressed`: 19 must-read files
- `must_read_task_tail_truncated = false`
- Active task & latest handoff resolved before registry-tail fallback

### 4.5 Registry sync outcome

- 11 historical task rows preserved
- 1 active SP-115 row updated
- `validate_phase1_jsonschema.py` PASS post-sync
- `validate_phase1_runtime_objects.sh` PASS post-sync

### 4.6 Net effect summary

> Tier 1 weight dropped 92%, Tier 2 introduced 110 lines, Tier 3 preserved
> 100% of the historical content. Cold-start now resolves active state
> via 19 must-read files instead of pulling the multi-thousand-line
> pre-slim Tier 1 surfaces.

---

## 5. Lessons Learned → Layer 1 Rule Clauses

Each lesson is a real failure mode or near-miss observed during the
330 plan execution. Each maps to one or more Layer 1 OS Core rules.

### L1. "Sync truncated history when board was slimmed"

- **What happened**: pre-BATCH_7, running the unguarded sync against the slimmed sprint_board would have collapsed `task_registry.json` to a single SP-115 row, dropping all 11 prior task entries.
- **Why it almost happened**: the original sync was written against the 10-column full-history board; feeding it a 9-column current-only board produced a structural reset of the registry.
- **Layer 1 rules that capture this**:
  - `RUNTIME_REGISTRY_SYNC_GUARD.md` clause (1) Preserve historical rows
  - `RUNTIME_REGISTRY_SYNC_GUARD.md` clause (5) Multi-version schema tolerance
- **Generalisation**: any state-surface slimming that feeds a registry must guarantee history preservation as a precondition, not a follow-up patch.

### L2. "Indexes must exist before history moves"

- **What happened**: the 330 plan explicitly sequenced BATCH_1 (Add Index Shells) and BATCH_2 (Current Summary) before BATCH_3 (Sprint Board Slimming). Reversing the order would have left consumers with no Tier 2 routing surface for the moved history.
- **Layer 1 rules that capture this**:
  - `INDEX_SURFACE_RULES.md` §`Cold-Start Coupling` (indexes are required before cold-start can route deterministically)
  - `ARCHIVE_SURFACE_RULES.md` §`Archive Promotion Trigger` (archive promotion presumes a routing layer to point back from)
- **Generalisation**: governance migration must be index-first, slim-second, sync-last. v4.90 Batch 3 Step 3 enshrines this in the protocol governance node order.

### L3. "Cold-start update must follow indexes, not lead them"

- **What happened**: BATCH_6 of the 330 plan explicitly states *"Update cold-start routing only after the new indexes exist and have correct content"*.
- **Why**: a cold-start update that points at non-existent or empty indexes would degrade re-entry quality strictly worse than the pre-slim state.
- **Layer 1 rule that captures this**:
  - `COLD_START_READSET_RULES.md` §`Project-Side Implementation` (the dual-declaration requirement plus the index-availability precondition).
- **Generalisation**: cold-start changes are downstream of governance changes. They are validated last, not first.

### L4. "Archives must declare themselves loud"

- **What happened**: lessismore archive files use date-prefixed filenames (`2026-05-10_*_pre_slim.md`) and live in `archive/` directories — but they don't carry the literal `DO NOT LOAD BY DEFAULT` header. A cold-start tool that traversed by glob (which `generate_cold_start_pack.py` partially does) could have included them by accident.
- **What averted disaster**: explicit allow-listing in `context_profiles_manifest.json` prevented inclusion. But the implicit dependence on filename convention is fragile.
- **Layer 1 rule that captures this**:
  - `ARCHIVE_SURFACE_RULES.md` §`Mandatory Archive File Header` — the literal `DO NOT LOAD BY DEFAULT` marker is the canonical, fail-safe identifier.
- **Generalisation**: filename conventions are fragile signals; in-file headers are robust signals. v4.90 mandates the in-file header so `validate_cold_start_readset.py` can refuse archive inclusion structurally.

### L5. "Project status leaks into rule documents"

- **What happened**: during v4.90 Batch 1 Step 1, two Layer 1 OS Core documents (`docs/13_migration/README.md` and `V4_82_TO_V4_89_COMPATIBILITY_NOTES.md`) acquired the names "RandomHeroes" and "lessismore" verbatim while the author was thinking about real adoptions. Manual grep caught them; if the lint script had not been GUIDED-tier from day one, they would have shipped.
- **Why this matters here**: lessismore-side documents (the 330 plan itself) are full of project-specific identifiers, which is correct and expected — they ARE project documents. The OS Core mistake is treating those documents as direct sources for OS Core rules, which is exactly what this case study exists to mediate.
- **Layer 1 rule that captures this**:
  - `lint_layer_separation.py` is GUIDED-tier (zero violations, 8 roots)
  - `STATE_SURFACE_MIGRATION_CASE_*` regex in `LAYER_2_EXEMPTIONS` defines the *single allowed escape hatch* — this file
- **Generalisation**: real-world evidence and OS Core rules need a hard wall between them. Case study files are the mediator; lint script is the gate.

---

## 6. Known Gaps & Future Improvements

These are honest gaps in the SP-115 implementation as measured against
v4.90 Layer 1 doctrine. They are evidence material for v4.90 Batch 4
LTM v2 (Failure-Fix Memory).

### G1. Dry-run mode missing in `sync_phase1_task_registry.py`

- **Symptom**: clause (7) of the sync guard is not implemented.
- **Risk**: a fault in the sync logic would mutate `task_registry.json` before validation could refuse the change. In SP-115 the sync was correct so no harm occurred, but the fault tolerance is structurally absent.
- **Fix path**: add `--dry-run` flag that prints the JSON diff without invoking `TASK_REGISTRY.write_text`. v4.90's `validate_registry_sync_guard.py --sync-script <path>` will warn-only on this gap; the project will need to address it as part of v4.90 P0-2 adoption.
- **Owner if/when adopted**: project Tools & Pipeline Agent on lessismore side; v4.90 OS Core merely documents the requirement.

### G2. Archive files lack `DO NOT LOAD BY DEFAULT` literal header

- **Symptom**: the five 2026-05-10 archive snapshots use date-prefixed filenames as the load-deferral signal, not the v4.90 canonical in-file header.
- **Risk**: as discussed in L4, filename conventions are fragile.
- **Fix path**: one-time mechanical pass to backfill `> **DO NOT LOAD BY DEFAULT** — archive surface (Tier 3)` plus `Captured` / `Source` / `Predecessor pointer` lines into each existing archive file. Low risk because archives are read-only; this is the only edit they will ever see.

### G3. `state_surface_policy.yaml` does not exist on lessismore yet

- **Symptom**: the policy declaration that v4.90 expects lives only implicitly in `context_profiles_manifest.json`. The dual-declaration requirement is unmet.
- **Risk**: future drift between cold-start manifest and policy contract cannot be detected by `validate_cold_start_readset.py` because there is only one declaration to check against.
- **Fix path**: produce `state_surface_policy.yaml` as the canonical declaration; rebuild `context_profiles_manifest.json` from it (or add a CI step asserting the two stay aligned).

### G4. No `validate_archive_immutability.py` enforcement

- **Symptom**: `ARCHIVE_SURFACE_RULES.md` §`Read-Only Discipline` is documented but not enforced; v4.90 Batch 3 Step 2 did not include this validator.
- **Risk**: an editor who mutates `tasks/archive/2026-05-10_sprint_board_pre_slim.md` after creation would not be caught by CI.
- **Fix path**: deferred to v4.90 Batch 4 (the rule file already names it as a Batch 4 item: *"CI gate `validate_archive_immutability.py` (Batch 4) enforces this; for Batch 3 the rule is documentary."*).

### G5. Per-row index schema validation post-dates lessismore's BATCH_1

- **Symptom**: lessismore's four index shells were validated by manual review, not by the v4.90 Batch 3 Step 3 schema constraint that now lives in `state_surface_policy.schema.json`.
- **Risk**: row drift in the existing indexes would not be caught.
- **Fix path**: re-run `validate_current_state_surface.py --surface index` against lessismore once the project mounts v4.90.

---

## 7. Evidence Index

### 7.1 Source documents (read-only references)

- `Docs/Workflow/330_State_Surface_Slimming_And_Indexing_Plan.md` — 465 lines, status `BATCH_7_DONE / RUNTIME_REGISTRY_SYNC_GUARDED`. Authoritative plan.
- `tasks/sprint_board.md` — 55-line slimmed Tier 1 surface (post-BATCH_3).
- `tasks/sprint_index.md` / `tasks/task_index.md` / `logs/agents/index.md` / `logs/orchestrator_decision_index.md` — four OS-minimum Tier 2 indexes (BATCH_1 output).
- `tasks/archive/2026-05-10_sprint_board_pre_slim.md` — 233-line Tier 3 snapshot.
- `logs/agents/archive/2026-05-10_sp115_state_surface_slimming_pre_slim/{executive_producer_agent,qa_playtest_agent,ui_ux_agent}.md` — three high-volume agent log archives.
- `logs/orchestrator/archive/2026-05-10_orchestrator_log_pre_slim.md` — 1139-line orchestrator log archive.
- `tools/runtime/sync_phase1_task_registry.py` — 187-line sync-guard implementation (BATCH_7 output).

### 7.2 Project-side commits (lessismore git log refs)

| Commit | Subject | Role in this case |
|---|---|---|
| `308919b` | `codex: slim state surfaces and guard runtime sync` | Single rollup commit covering BATCH_3..BATCH_7 of the 330 plan. Adds 4 index shells + slimmed Tier 1 + 5 archives + sync_phase1_task_registry.py. |
| `78cb225` | `codex: close SP-115 cleanup sprint` | Sprint closure; sets `PASS_WITH_NOTE / SPRINT_CLOSED / STRUCTURAL_REFACTOR_DEFERRED`. |
| `a29d272` | `codex: integrate v489 adoption closure` | Confirms the slimmed surfaces stay valid under v4.89 adoption tooling. |
| `1d93fbd` | `codex: SP-115 code cleanup runtime passes` | Separate code-cleanup work (out of scope for this case but referenced in `SP115_Cleanup_Evidence_Index.md`). |
| `602fe63` | `codex: integrate v489 adoption and workflow relayering` | v4.89 adoption preview integration. |

### 7.3 Validation evidence (per 330 plan §Completion State, items 4–14)

- sprint_board.md: 233 → 54 lines (item 4)
- agent log line counts: EP `611 → 55`, QA `440 → 48`, UI/UX `269 → 48` (item 6)
- orchestrator_log.md: 1139 → hot-state-only (item 8)
- Cold-start compressed pack: 19 must-read files, latest handoff resolved before registry tail (items 10, 14)
- Registry sync: 11 task rows preserved (item 11)
- `validate_phase1_jsonschema.py` PASS (item 12)
- `validate_phase1_runtime_objects.sh` PASS (item 13)

### 7.4 v4.90-side cross-references (Layer 1 rules instantiated by this case)

- [`CURRENT_STATE_SURFACE_RULES.md`](./CURRENT_STATE_SURFACE_RULES.md) — sprint_board slim mapping (§3.1)
- [`INDEX_SURFACE_RULES.md`](./INDEX_SURFACE_RULES.md) — four index shells mapping (§3.2)
- [`ARCHIVE_SURFACE_RULES.md`](./ARCHIVE_SURFACE_RULES.md) — three archive cohorts mapping (§3.3)
- [`COLD_START_READSET_RULES.md`](./COLD_START_READSET_RULES.md) — readset reorder mapping (§3.4)
- [`RUNTIME_REGISTRY_SYNC_GUARD.md`](./RUNTIME_REGISTRY_SYNC_GUARD.md) — sync_phase1 7-behaviour mapping (§3.5)
- [`STATE_SURFACE_LAYERING.md`](./STATE_SURFACE_LAYERING.md) — three-tier model that this case validates end-to-end

### 7.5 Outbound references (this case will be cited by)

- v4.90 Batch 4 LTM v2: Failure-Fix Memory seed `ff_2026_001` will set
  `evidence_ref: docs/14_state_surface_governance/STATE_SURFACE_MIGRATION_CASE_SP115.md`
  with `failure_pattern = "state-surface bloat → cold-start cost balloon"`
  and `fix_pattern = "three-tier model + sync guard + index-first cold-start"`.
- v4.90 Batch 5.5 RH Real Adoption Simulation: will reuse §4 quantification
  format for the RandomHeroes-side equivalent case study.

---

## 8. Closing Notes

This case is anchored in time at `2026-05-10 / BATCH_7_DONE`. Future
governance work on lessismore (e.g. per-sprint flush of Tier 1 → Tier 3
on SP-116 close) is **not** retroactively folded into this file; that is
the proper subject of new case files
(e.g. `STATE_SURFACE_MIGRATION_CASE_SP116.md` or a per-sprint follow-up
appendix). This file's job is to anchor the BATCH_1..BATCH_7 evidence as
the founding Layer 2 case for v4.90 P0-2.

The single most important thing to take from this case is:

> The v4.90 Layer 1 governance rules are **not** invented from first
> principles. Every clause in the five RULES.md files corresponds to a
> concrete failure or near-miss observed in the lessismore SP-115 work.
> Reading those rules without this case strips the rules of their
> evidence. Reading this case without those rules strips the evidence
> of its generalisation. Both directions are wrong; the wall between
> Layer 1 and Layer 2 exists precisely so that both can be loaded
> together when needed and kept apart when not.
