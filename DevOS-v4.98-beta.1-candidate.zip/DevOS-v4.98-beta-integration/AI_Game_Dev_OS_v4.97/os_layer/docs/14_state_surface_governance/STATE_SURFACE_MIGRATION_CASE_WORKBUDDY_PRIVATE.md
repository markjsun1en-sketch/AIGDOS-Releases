# State Surface Migration Case — workbuddy_private starter adoption

> **Layer 2 — Project Migration Case Study**
> **Captured**: 2026-05-12
> **Source project**: `workbuddy_private` (the adopting runtime profile shipped inside v4.89_Release `starters/workbuddy_private/`)
> **Source package**: `AI_Game_Dev_OS_v4.89_Release/starters/workbuddy_private/` (byte-locked at v4.89 RC3 tip `24484ad`; re-bundled into v4.90 as `starters/workbuddy_private/` per Batch 0 fork init)
> **Status**: GUIDED — second Layer 2 evidence file, landed in v4.90 Batch 5.5 Step 5.5.3

---

## 0. Layer 2 Notice

This file is **the only file under `docs/14_state_surface_governance/`,
besides `STATE_SURFACE_MIGRATION_CASE_SP115.md`, that is permitted to
contain project-specific names** (profile codenames, starter file names,
adoption-side agent titles). It is exempt from
`scripts/governance/lint_layer_separation.py` via the
`STATE_SURFACE_MIGRATION_CASE_*` regex in `LAYER_2_EXEMPTIONS`.

The exemption exists for a single purpose: **collect concrete real-world
evidence behind the Layer 1 generic rules**. Future readers should treat
this file as anchored historical context, **not** as Layer 1 doctrine.
If a clause from this case deserves promotion to a generic rule, it must
first be re-expressed in project-name-free form and merged into a Layer 1
file; this file then references the new clause, not the other way
around.

OS Core directives (Layer 1) point ↘ at this case for evidence; this
case points ↗ at Layer 1 for the rule it instantiates. Never the other
direction.

---

## 1. Case Background

### 1.1 Profile

- **Profile**: `workbuddy_private`
- **Host**: `workbuddy` (per matrix row 10 enum + `docs/06_runtime_profiles/workbuddy_private/`)
- **Starter path**: `starters/workbuddy_private/` — 5 files (byte-locked at v4.89 `24484ad`):
  - `AGENTS.md.template` (743L)
  - `SKILLS.md.template` (390L)
  - `DEFAULT_LOADSET.json` (20L)
  - `TEAM_BOOT_GUIDE.md` (21L)
  - `TEAM_RULES.template.md` (11L)
- **Runtime-profile docs**: `docs/06_runtime_profiles/workbuddy_private/` (4 files: RULE_LOADING / CONTEXT_LOADING / WRITEBACK_POLICY / RECOVERY_SOP)
- **OS Core baseline at time of this case**: v4.90 Batch 5 closed (tag `v4.90-batch-5-closure`, HEAD `50cc4dd`)

### 1.2 Why this case exists

The `starters/workbuddy_private/` tree is the first fully-populated
adoption surface that ships inside the OS Core package itself — it has
no external codebase counterpart and is not a live sprint-driven
project. That makes it an ideal Layer 2 adoption case: we can measure
exactly how the v4.90 capability matrix + Batch 5 Agent Library / Pack
architecture + Batch 4 sprint_close hook map onto a realistic-but-static
adopting project, without needing to coordinate with a separate project
git history.

The case documents **how the 6 newly-GUIDED migration scripts
(Batch 5.5 Step 5.5.2) interpret this starter tree** when it is passed
as `--project starters/workbuddy_private/` to the pipeline:

```
detect_project_protocol
   → generate_capability_queue (via the matrix, not the scan)
   → validate_capability_adoption (row-by-row)
   → adopt_capability (state machine slice)
   → generate_migration_report
   → capture_sprint_close (Batch 5.5 Step 5.5.1)
```

### 1.3 Decision

- Owner: Batch 5.5 Module D / workbuddy_private profile maintainer
- Mandate: document the mapping between the 5 starter files + 4 runtime-profile docs and the v4.90 capability matrix rows they instantiate, plus the cluster seed packs they consume.
- Scope: no modification to starter content (`24484ad` byte-lock must hold); this case is pure evidence collection.
- Out of scope: promotion of starter content into Layer 1; that would strip the evidence from its case-study wrapper.

---

## 2. Mapping starter files to v4.90 capability matrix rows

Each starter file or runtime-profile doc corresponds to one or more
capability matrix rows. The mapping below was compiled by running
`validate_capability_adoption.py` on `starters/workbuddy_private/`
augmented with the OS Core tree (so the shared Layer 1 paths — which
only exist in the OS Core, not in a thin adopting project — are found
via the standard `--project` argument).

| Starter file / runtime doc | Matrix row(s) | Evidence |
|---|---|---|
| `AGENTS.md.template` | **09_agent_library** (agent roster declaration) + **06_context_governance** (who loads what) | 14-agent roster described in prose; ships as Layer 2 instantiation of the 8 generic `role_id` values from `agent_role.schema.json`. |
| `SKILLS.md.template` | **09_agent_library** (orchestration skill catalog) + **06_context_governance** | 390-line skill catalog; Batch 7+ may project this into a Pack-side structured ledger. |
| `DEFAULT_LOADSET.json` | **02_project_profile** (profile identity) + **06_context_governance** (loadset) + **10_pack_activation** (implicit pack selection by host key `workbuddy`) | 20-line JSON declares always-load + project-specific + runtime-profile lists. |
| `TEAM_BOOT_GUIDE.md` | **04_handoff_registry** (main-session/team-worker boundary) + **05_validation_evidence** (cold-start evidence plumbing) | 21-line operational guide covers main-session proxy sync + registry-sensitive task state + recovery owner. |
| `TEAM_RULES.template.md` | **02_project_profile** + **04_handoff_registry** | 11-line file encodes project-side execution rules the team runtime consumes. |
| `docs/06_runtime_profiles/workbuddy_private/RULE_LOADING.md` | **06_context_governance** | How rule files load at boot. |
| `docs/06_runtime_profiles/workbuddy_private/CONTEXT_LOADING.md` | **06_context_governance** + **11_profile_parity** | Context manifests for each profile tier. |
| `docs/06_runtime_profiles/workbuddy_private/WRITEBACK_POLICY.md` | **04_handoff_registry** + **13_adapter_bridge** | Governs which surfaces may be written by which runtime. |
| `docs/06_runtime_profiles/workbuddy_private/RECOVERY_SOP.md` | **04_handoff_registry** + **05_validation_evidence** | Re-entry / dirty-state recovery flow. |

No starter file declares `07_ltm_capture_consult` / `08_failure_fix_memory`
/ `14_self_evolution_proposal` content — those are consumed via the
OS Core runtime (`runtime/ltm/`, `proposals/`) rather than via the
profile-specific starter surface. Row **12_dashboard_exports** is not
exercised by a pure starter tree (no `exports/` artefacts) and has an
empty `required_checks[]` in the v4.90 matrix, so it surfaces as an
empty-checks pass in `validate_capability_adoption`.

---

## 3. Consumption of Batch 5 Agent Library cluster seed packs

Batch 5 Step 5.5 authored 5 cluster seed packs under `agent_packs/`:

| Seed pack | Cluster | Generic roles | Layer 2 mapping to `workbuddy_private` AGENTS.md |
|---|---|---|---|
| `ap_2026_001_executive_cluster.md` | executive | executive + orchestrator | "Executive Producer (EP)" + "Orchestrator" layers |
| `ap_2026_002_research_and_design_cluster.md` | research_design | research + design | "Game Research", "GameDesign", "Content Design", "UI/UX Design" |
| `ap_2026_003_implementation_cluster.md` | implementation | implementation | "Slot/Systems", "Engineering", "Numeric/Balance", "UI/UX implementation" |
| `ap_2026_004_validation_cluster.md` | validation | validation | "QA & Playtest" |
| `ap_2026_005_support_cluster.md` | support | support + archivist | "Tools Agent", "Art Direction Agent", "Art Production Agent", "Sound Designer" |

**Adoption lesson**: the 14-agent project roster inside `AGENTS.md.template`
maps cleanly onto the 5 generic clusters without any re-authoring.
Every project-specific agent title is a Layer 2 instantiation of at
least one of the 8 generic `role_id` values. No Layer 1 role was
invented, no starter file was modified; the clusters absorb the
project-specific roster purely by composition, which is precisely the
outcome Batch 5 D2=B + D5=A were designed to produce.

The two deferred clusters (`creative_cluster` / `tools_cluster`, v4.91)
are the only unfulfilled roles: AGENTS.md has dedicated creative agents
("Art Direction", "Art Production", "Sound Designer") that currently
shelter under `support_cluster`. v4.91 may promote them to a dedicated
`creative_cluster`; this case will be re-read at that point to verify
the promotion does not break the existing mapping.

---

## 4. Quantified adoption simulation outcome

Running the Batch 5.5 pipeline against `starters/workbuddy_private/` +
the OS Core root:

| Stage | Command | Outcome |
|---|---|---|
| Detect protocol | `detect_project_protocol.py --fallback-default` | legacy=`4.82`, target=`4.90`, mode=`progressive_adoption`, host=`codex` (fallback) |
| Build queue | `generate_capability_queue.py` | 14 entries; priority 0=`01_runtime_core`; 0 cycles |
| Validate row 09 | `validate_capability_adoption.py 09_agent_library --project <root>` | `overall_status=pass` (3/3 checks: agent_library_spec_present, agent_packs_ledger_present, agent_role_schema_valid) |
| Validate row 10 | `validate_capability_adoption.py 10_pack_activation --project <root>` | `overall_status=pass` (2/2 checks: pack_selection_policy_valid, pack_selection_manifest_integrity) |
| Adopt row 09 | `adopt_capability.py 09_agent_library --from not_present --to adopted` | `transition_status=applied`, `audit_event=migration.adopt` |
| Compatibility check | `validate_protocol_compatibility.py` (against OS Core tree) | Non-strict: 0 ERROR; `--strict`: WARN on unenumerated rows (expected). |
| Migration report | `generate_migration_report.py --format markdown` | `## Protocol / ## Capability Queue / ## Adoption Score / ## Transitions` all populated. |
| Capture closure | `capture_sprint_close.py --input <envelope> --dry-run` | Body renders with `## Outcome / ## Lessons / ## Evidence / ## Blockers Resolved` sections as spec'd. |

**Key numbers**:
- 5 starter files totalling **1185 lines** (byte-locked).
- 4 runtime-profile docs totalling **~300 lines** (byte-locked).
- 14 capability matrix rows scored; 0 deprecated (post-Batch 5).
- 5 cluster seed packs covering all 8 generic `role_id` values.
- 0 Layer 1 violations in `lint_layer_separation.py` across the 26
  scanned roots.

No starter content was modified during this case. The pipeline proves
that a fully-populated starter tree can be driven through the v4.90
adoption state machine **without** editing source-of-truth files — a
hard requirement for preserving the v4.89_Release byte-lock.

---

## 5. Migration execution mapped to Layer 1 rules

### 5.1 `STATE_SURFACE_LAYERING.md` ← starter as Tier 1 surface

**OS Layer 1 rule (target)**:
The three-tier model (Tier 1 = current state, Tier 2 = index/routing,
Tier 3 = archive) applies to runtime state, not to static configuration
like a starter tree. Starter files are therefore exempt from the
Tier 1 line-count policy; they function as **reference artefacts** that
adopting projects copy into their live tree and then slim.

**workbuddy_private implementation**:
- `AGENTS.md.template` (743L) exceeds any Tier 1 line policy; this is
  intentional — it is a template, not a live sprint surface. The rule
  is that once an adopting project renames it to `AGENTS.md` in their
  live tree, the Tier 1 policy starts applying.
- `DEFAULT_LOADSET.json` (20L) is the source-of-truth surface for
  loadset decisions and does satisfy Tier 1 line policies when it
  lands in a live project.

**Layer 1 rule satisfied via**:
- The starter-tree exemption is not codified in
  `STATE_SURFACE_LAYERING.md`; this case suggests a future rule
  amendment ("Starters and templates are exempt from Tier 1 policy
  until materialised into a live tree"), which would be proposal-gated
  per Batch 6.

### 5.2 `COLD_START_READSET_RULES.md` ← `DEFAULT_LOADSET.json`

**OS Layer 1 rule (target)**:
Cold-start readsets MUST declare which files load at boot, separated
into always / project-specific / runtime-specific tiers.

**workbuddy_private implementation**:
`DEFAULT_LOADSET.json` ships exactly this shape:

```json
{
  "profile": "workbuddy_private",
  "always_load": ["docs/00_entry/START_HERE.md", "docs/00_entry/CORE_OS_DIGEST.md"],
  "load_project_specific": ["AGENTS.md", "SKILLS.md", "TASK_EXECUTION_RULES.md", "WORKFLOW.md", "PROJECT_ADAPTATION_SUMMARY.md"],
  "load_runtime_specific": ["docs/06_runtime_profiles/workbuddy_private/RULE_LOADING.md", ...]
}
```

**Layer 1 rule satisfied via**:
- Three-tier structure matches the COLD_START_READSET_RULES default.
- No ambiguity about "who loads what"; the JSON is consumable by
  `scripts/governance/validate_cold_start_readset.py` without
  translation.

### 5.3 `PACK_CLUSTER_TAXONOMY.md` ← AGENTS.md 14-agent roster

**OS Layer 1 rule (target)**:
7 clusters group the 8 generic `role_id` values into compose units.
Adopting projects compose their own agent rosters via cluster imports
(Batch 7+ assembler; documented-only in v4.90).

**workbuddy_private implementation**:
The 14-agent roster in `AGENTS.md.template` decomposes into:
- executive_cluster ← "EP"
- orchestrator role in executive_cluster ← "Orchestrator"
- research_design_cluster ← "Game Research" / "GameDesign" / "Content Design" / "UI/UX Design"
- implementation_cluster ← "Slot/Systems" / "Engineering" / "Numeric/Balance" / "UI/UX"
- validation_cluster ← "QA & Playtest"
- support_cluster ← "Tools Agent" / "Art Direction Agent" / "Art Production Agent" / "Sound Designer"

**Layer 1 rule satisfied via**:
- Every project-specific title is traceable to at least one generic
  role_id.
- No new cluster is needed for this mapping; the deferred clusters
  (`creative_cluster` / `tools_cluster`) remain optional future
  refinements, not gaps.

### 5.4 `SPRINT_CLOSE_CAPTURE_HOOK.md` ← capture_sprint_close.py

**OS Layer 1 rule (target)**:
Adopting projects with a sprint-based workflow produce a schema-conformant
JSON envelope at sprint close and pipe it to `capture_sprint_close.py`.
The script projects the envelope into `runtime.ltm.capture(domain='project')`.

**workbuddy_private implementation**:
The starter ships `TEAM_BOOT_GUIDE.md` (21L) which documents the
main-session/team-worker boundary but does not yet include a
concrete sprint-close envelope producer. A future adoption iteration
may add a `docs/06_runtime_profiles/workbuddy_private/SPRINT_CLOSE.md`
guide describing how to produce the envelope from the project's own
closure flow. That guide would NOT modify OS Core; it would only
document project-side behaviour.

**Layer 1 rule satisfied via**:
- The Batch 5.5.1 script accepts a minimal envelope with
  `project_id='workbuddy_private'`, `outcome='PASS'`, and renders
  the spec'd body correctly (verified in
  `tests/ltm/test_capture_sprint_close.py::test_2`).
- No starter file modification required.

### 5.5 `validate_capability_adoption.py` ← rows 09 + 10 required_checks

**OS Layer 1 rule (target)**:
Matrix-declared `validation.required_checks` for a capability MUST be
executable by the validator. Batch 5 declared 5 checks across rows
09 + 10; Batch 5.5 Step 5.5.2 registered runners for all 5.

**workbuddy_private implementation**:
Because the starter tree relies on the OS Core for its shared Layer 1
paths (`docs/16_agent_library/`, `agent_packs/`, `schemas/agent_library/`,
`config/pack_selection_policy.yaml`, `game_type_packs/`, `context_packs/`),
validating against the OS Core root naturally produces
`overall_status=pass` for both rows. An adopting project that
copies only the starter tree without the shared Layer 1 paths would
(correctly) fail these checks until the OS Core is mounted.

**Layer 1 rule satisfied via**:
- 5 checks registered in `_CHECK_REGISTRY`.
- E5 exit criterion met.

---

## 6. Lessons

1. **A static starter is an excellent Layer 2 adoption case**. No
   coordination with a live project history is required, the byte-lock
   is naturally preserved, and the evidence can be refreshed
   deterministically by re-running the pipeline.

2. **The 5 cluster seed packs generalise cleanly over a 14-agent
   roster**. No cluster was left unused, no generic role was missing,
   and no Layer 1 concept had to be invented during this mapping.
   This validates Batch 5 D2=B (per-capability-cluster pack granularity)
   + D5=A (`docs/16_agent_library/` root name).

3. **`validate_capability_adoption` and `adopt_capability` cooperate
   correctly**. The state-machine transition is blocked when validation
   fails (see `test_adopt_capability::test_4_validation_failure_blocks_transition`)
   and allowed when it passes, giving adopting projects a deterministic
   gate.

4. **The starter tree exposes a gap in `STATE_SURFACE_LAYERING.md`**:
   the three-tier model does not currently address templates vs live
   surfaces. A future Self-Evolution proposal
   (`proposal_kind: architecture_principle`) could extend the rule to
   say "Starter/template trees inherit Tier 1 policies only once
   materialised into a live tree". This case is the evidence.

5. **The sprint_close hook is spec'd but not yet exercised end-to-end
   by the starter**. Batch 5.5 Step 5.5.1 delivers the hook; Step 5.5.4
   exercises it with a synthesised envelope. A future adopting-project
   iteration that ships a real envelope producer would close this gap.

---

## 7. Lookup Index

### 7.1 Command reference (copy-pasteable, run from v4.90 root)

```bash
# 1. protocol (adopting project ships its own yaml; use fallback for demo)
python3 scripts/migration/detect_project_protocol.py --fallback-default

# 2. matrix-driven queue
python3 scripts/migration/generate_capability_queue.py

# 3. per-row validation
python3 scripts/migration/validate_capability_adoption.py \
    09_agent_library --project . --format json
python3 scripts/migration/validate_capability_adoption.py \
    10_pack_activation --project . --format json

# 4. adopt
python3 scripts/migration/adopt_capability.py \
    09_agent_library --project . --from not_present --to adopted

# 5. sprint closure envelope (project-produced JSON; dry-run renders body)
python3 scripts/ltm/capture_sprint_close.py \
    --input <(echo '{
      "sprint_id": "baseline",
      "project_id": "workbuddy_private",
      "outcome": "PASS",
      "captured_at": "2026-05-12T14:30:00Z",
      "evidence_index": ["commit 50cc4dd"],
      "lessons": ["starter tree maps cleanly to 5 clusters"]
    }') --dry-run
```

### 7.2 v4.90-side cross-references (Layer 1 rules instantiated by this case)

- [`CURRENT_STATE_SURFACE_RULES.md`](./CURRENT_STATE_SURFACE_RULES.md) — Tier 1 starter exemption discussion (§5.1)
- [`COLD_START_READSET_RULES.md`](./COLD_START_READSET_RULES.md) — DEFAULT_LOADSET.json mapping (§5.2)
- `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` — 7-cluster taxonomy (§5.3)
- `docs/16_agent_library/AGENT_ROLE_CATALOG.md` — 8 generic `role_id` (§5.3)
- `docs/15_ltm_v2/SPRINT_CLOSE_CAPTURE_HOOK.md` — capture hook spec (§5.4)
- `docs/13_migration/CAPABILITY_COMPATIBILITY_MATRIX.md` rows 09, 10, 14 — promoted matrix rows (§5.5)

### 7.3 Outbound references (this case will be cited by)

- Batch 5.5 Step 5.5.4 harness e2e test: will consume this case as
  the oracle for the expected row-by-row outcomes.
- A future Self-Evolution proposal on starter-vs-live Tier 1 policy
  (proposed §5.1) would cite this case as its architectural evidence.

---

## 8. Closing Notes

This case is anchored in time at `2026-05-12 / Batch 5 closed @
v4.90-batch-5-closure tag`. Future governance work on
`workbuddy_private` (e.g. a Batch 7 RC hygiene pass that promotes
`schema_version: 0.1.0-beta` to `1.0.0` across the starter tree) is
**not** retroactively folded into this file; that is the proper
subject of a new case file or an appendix.

The single most important thing to take from this case is:

> The v4.90 Batch 5 Agent Library architecture does NOT require any
> adopting project to re-author its agent roster. A 14-agent
> project-specific roster fits inside the 5 Batch-5 cluster seed packs
> without inventing a new cluster or a new role, without modifying
> the byte-locked starter tree, and without introducing any Layer 1
> violations. The wall between Layer 1 and Layer 2 holds precisely
> because the 8 generic `role_id` values were chosen generic enough
> to absorb this concrete 14-agent case.

---

## 9. v4.90 Batch 9 Step 9.5 — Init Toolkit Revalidation Appendix

**Captured**: 2026-05-13 (post Batch 9 Step 9.4).
**Source**: `tests/adoption/test_init_workbuddy_private_e2e.py` and
`scripts/adoption/{init_project_runtime.py, run_mock_harness.py}`
(both GUIDED).

This appendix records the second-pass result of running the Batch 9
Project Adoption Toolkit (`init_project_runtime.py` + the
`run_mock_harness.py --emit-full-project-runtime` integration) against
the `workbuddy_private` fixture.

### 9.1 Two flows tested

| Flow | Driver | Notes |
|---|---|---|
| **Flow A — Pure init** | `python3 scripts/adoption/init_project_runtime.py --primary-host workbuddy --stage alpha --project-id wb_private_demo ...` | Step 9.2 path: scaffold a `.ai_dev_os/` tree from CLI flags only. |
| **Flow B — Harness emit** | `python3 scripts/adoption/run_mock_harness.py --fixture workbuddy_private --emit-full-project-runtime <out> --emit-primary-host workbuddy --emit-stage alpha ...` | Step 9.4 path: real scan+validate against the v4.89-shipped starter, followed by an in-process scaffold call (no subprocess fork). |

### 9.2 Fingerprint equivalence — observations

8 e2e tests in `test_init_workbuddy_private_e2e.py` confirm that, given
the same `--project-id`, `--primary-host`, and `--stage` inputs:

1. Layer 2 case doc is present (precondition).
2. Pure init scaffolds a `workbuddy`-host `.ai_dev_os/` tree.
3. Harness emit scaffolds a `workbuddy`-host `.ai_dev_os/` tree.
4. **Both flows produce identical file sets** (10 files: 6 yaml + 4
   dir READMEs). No drift on file names, no orphan files in either
   path.
5. `03_host_profile.yaml` field-equivalent on `schema_version` and
   `primary_host`.
6. `02_project_profile.yaml` field-equivalent on `schema_version`,
   `project_id`, and `stage`.
7. `06_adoption_state.yaml` carries all 14 capability ids in both
   flows.
8. Harness-emitted yaml validates against the three Step 9.1 schemas
   (`host_profile`, `project_profile`, `active_packs`).

### 9.3 What is NOT yet validated

The harness path does not yet propagate the Batch 5 D-cluster
`active_packs` from the workbuddy_private fixture into
`04_active_packs.yaml` — the file is emitted with `active_packs: []`
even when the fixture demonstrates 11/14 capabilities present. Closing
that gap is a candidate Batch 10/11 enhancement (likely via a new
`--emit-active-packs` flag that reads the validate output's
`detected_capabilities` list and maps it onto pack ids). It is
**out of Step 9.5 scope** by design — equivalence between the two
flows is the immediate revalidation goal.

### 9.4 Implication for the rest of v4.90

The Project Adoption Toolkit (Batch 9) is now usable by any v4.90
adopting project — the workbuddy_private case is the worked example;
generic guidance lives in `docs/13_migration/PROJECT_RUNTIME_PROTOCOL.md`
and in the schemas under `schemas/adoption/`.

No Layer 1 doctrine changes from this appendix. As §0 stipulates, if
any rule herein generalises, it must first be re-expressed in
project-name-free form and added to a Layer 1 doc; this appendix would
then reference it, not the other way around.
