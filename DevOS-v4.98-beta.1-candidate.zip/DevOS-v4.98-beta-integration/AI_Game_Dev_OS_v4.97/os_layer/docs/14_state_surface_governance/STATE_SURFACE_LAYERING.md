# State Surface Layering

> **Skeleton — v4.90 Batch 3 Step 1**
> **Layer 1 (OS Spec)** — no project names

## Three-Tier Surface Model

Every active project state surface MUST fit into one of three tiers:

```text
┌─────────────────────────────────────────────────────┐
│ Tier 1 — Current State                               │
│   answers: what / who / blocker / next               │
│   loaded: by default                                 │
│   size:   tight (default ≤ 80 lines per file)        │
│   forbidden: archive content, historical narrative   │
└─────────────────────────────────────────────────────┘
                       ↓
┌─────────────────────────────────────────────────────┐
│ Tier 2 — Index                                       │
│   answers: where to find … / which sprint / when     │
│   loaded: by default OR on light demand              │
│   size:   medium (one row per indexed entity)        │
│   forbidden: full evidence content (only pointers)   │
└─────────────────────────────────────────────────────┘
                       ↓
┌─────────────────────────────────────────────────────┐
│ Tier 3 — Detail / Archive                            │
│   answers: full historical record                    │
│   loaded: ONLY when an evidence_ref points to it     │
│   size:   unbounded (preserved verbatim)             │
│   header: MUST carry "DO NOT LOAD BY DEFAULT" marker │
└─────────────────────────────────────────────────────┘
```

## Tier Decision Rules

A surface is **Tier 1** iff it answers all of:
- "what is happening right now?"
- "who is responsible?"
- "what is blocked?"
- "what is the next step?"

A surface is **Tier 2** iff it answers:
- "where do I find …?"
- "which sprint did this happen in?"
- "what evidence_refs exist for this task?"

A surface is **Tier 3** iff:
- It exists primarily for audit / forensic purposes
- Loading it is opt-in, never default
- Other surfaces point at it via evidence_ref

## Per-Surface-Kind Examples (generic)

| Surface kind | Tier 1 form | Tier 2 form | Tier 3 form |
| --- | --- | --- | --- |
| `sprint_board` | active sprint only, ≤ 80 lines | sprint_index (one row per closed sprint) | archive snapshots |
| `agent_log` | active window (≤ 150 lines) | agents/index (status / current task) | archive/agents/<sprint>/ |
| `orchestrator_log` | active orchestration state | decision_index (one row per decision) | archive/orchestrator/<period>/ |
| `task_state` | current rows only | task_index (per task_id pointer) | archive/tasks/<closed_sprint>/ |

Project-side tier mappings live in
`STATE_SURFACE_MIGRATION_CASE_<project>.md` (Layer 2), not here.

## Anti-Patterns (forbidden)

1. **Mixed-tier file** — single file containing current + index + archive content
2. **Roadmap as truth source** — Roadmap is a Tier 2 index, NOT the source of completion truth
3. **Default-loaded archive** — archive files MUST NOT appear in cold-start readset
4. **Cross-tier write** — Tier 3 archive write must NOT mutate Tier 1 current state directly

## Schema

`schemas/governance/state_surface_policy.schema.json` validates per-project
declarations of which surfaces map to which tier. Skeleton in Batch 3 Step 1;
full content in Step 2.

## Layer Discipline

Layer 1 (OS Spec). No project names.
