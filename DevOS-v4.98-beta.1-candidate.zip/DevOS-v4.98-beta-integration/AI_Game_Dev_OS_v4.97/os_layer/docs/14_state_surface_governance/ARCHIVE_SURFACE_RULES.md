# Archive Surface Rules

> **Skeleton — v4.90 Batch 3 Step 1**
> **Layer 1 (OS Spec)** — no project names

## Purpose

Archive surfaces (Tier 3) preserve historical detail with audit fidelity.
They are NEVER loaded by default. Consumers reach them only via
`evidence_ref` pointers from Tier 1 / Tier 2 surfaces.

## Mandatory Archive File Header

Every archive file MUST start with:

```markdown
> **DO NOT LOAD BY DEFAULT** — archive surface (Tier 3)
> Captured: <ISO 8601>
> Source: <surface_kind that was slimmed; e.g. sprint_board / agent_log / orchestrator_log>
> Predecessor pointer: <evidence_ref or null>
```

This header serves three purposes:
1. Human readers immediately see the file is historical, not current.
2. CI tooling (`audit_state_surface_size.py`) can identify archives via
   the literal "DO NOT LOAD BY DEFAULT" marker without parsing structure.
3. cold-start readset validators (`validate_cold_start_readset.py`) can
   refuse to include any file carrying this header.

## Archive Strategy: by_date vs by_sprint

Two organizing strategies are supported (declared in
`state_surface_policy.yaml`):

### `by_date` (default for greenfield projects)
```
archive/
  2026-05-10/
    sprint_board_pre_slim.md
    orchestrator_log_pre_slim.md
    agents/<agent>.md
```

### `by_sprint` (default for sprint-driven projects)
```
archive/
  <sprint_id_n>/
    sprint_board.md
    orchestrator_log.md
    agents/<agent>.md
  <sprint_id_n+1>/
    ...
```

Mixing is forbidden — pick one strategy per project.

## Archive Promotion Trigger

Tier 1 → Tier 3 transition happens when ANY of:

- Active surface exceeds `line_count_policy` upper bound
- Sprint closes (entire sprint cohort slimmed in one batch)
- Agent log active window exceeds threshold (per `CURRENT_STATE_SURFACE_RULES`)
- Manual `slim_state_surface.py --target <surface>` invocation

## Archive Index (optional Tier 2 layer)

If `archive/` grows beyond the threshold (default: > 30 files OR any
single archive file > 800 lines), the project SHOULD generate
`archive/index.md` mapping period → archived files. This is itself a
Tier 2 index, NOT a Tier 3 surface.

## Read-Only Discipline

Archives are append-via-promotion only. They MUST NOT be edited in place
after creation (a corrected entry is a NEW archive file referring to the
old one via `predecessor_pointer`, not a mutation).

CI gate `validate_archive_immutability.py` (Batch 4) enforces this; for
Batch 3 the rule is documentary.

## Schema

`schemas/governance/state_surface_policy.schema.json` declares
`archive_strategy: by_date | by_sprint` field. Skeleton in Batch 3 Step 1.

## Layer Discipline

Layer 1 (OS Spec). No project names.
