# 14 — State Surface Governance

> **v4.90 Batch 3 Step 1 Skeleton** — created 2026-05-10
> **Status**: P0-2 State Surface Governance Spec entry. Layer 1 (OS Core)
> documents in this directory are project-name-free; project-specific
> evidence belongs in `STATE_SURFACE_MIGRATION_CASE_*.md` files (Layer 2).

## Purpose

Solve the cross-project problem documented during real adoption:

> "Active project surfaces (sprint board / orchestrator log / agent logs)
> grow without bound, mixing current state, indexes, and historical
> detail. Cold-start cost balloons. Re-entry drift increases. Manual
> slimming campaigns repeat in every project."

v4.90 P0-2 productizes the slimming + indexing methodology into reusable
OS-level rules, schemas, and tooling — so adopting projects gain it via
configuration rather than re-implementing it.

## v4.94 Authority Boundary

Runtime State is operational coordination state only. It may reference, but
cannot create, replace, approve, or overrule:

- Human decisions and approval records;
- Project Truth and its accepted revision;
- immutable Evidence and independent verification verdicts;
- LTM admission, promotion, supersession, retention, or deletion authority.

The packaged authority inputs are `RLC-V494@1.0.2`, `RLM-V494@1.0.2`, and the
byte-bound `TTR-V494@1.0.1` schema under `os_layer/contracts/runtime_state/`.
Runtime code resolves those packaged copies only and never reads
`.dev_os_meta`. Missing, incompatible, conflicted, or unresolved authority
fails closed without state advance.

The State Service command API is the sole v4.94 mutation boundary. Legacy
`runtime_db` JSON and registry surfaces remain read-only fixture/projection
inputs in PKG-1; a derived registry, snapshot, export, panel, or checkpoint is
not authoritative Runtime State and cannot be written back as truth. Agents do
not receive raw SQL, database, WAL/shm, service-instance, or epoch capability.

Current scope is the exact-host `B2-FIXTURE-LOCAL@1.0.3` profile under
`SEC-0 contract_only`. It is fixture-only and does not establish physical
isolation, portability, real-project write authority, Shadow/Pilot eligibility,
Pack promotion, supported adoption, or production readiness. No
`.ai_dev_os/state` root is created by this source tranche.

## Two-Layer Discipline (CRITICAL)

```text
┌─────────────────────────────────────────────────────────┐
│ Layer 1 — OS Spec (this directory, except case files)   │
│   - Generic rules / schema / scripts                     │
│   - NO project names anywhere                            │
│   - Enforced by scripts/governance/lint_layer_separation │
└─────────────────────────────────────────────────────────┘
                         ↓ abstracts from
┌─────────────────────────────────────────────────────────┐
│ Layer 2 — Project Migration Case (case-study files)     │
│   - Project names ALLOWED here                           │
│   - File pattern: STATE_SURFACE_MIGRATION_CASE_*.md      │
│   - Used as evidence; NOT promoted to Layer 1 verbatim  │
└─────────────────────────────────────────────────────────┘
```

## Documents in this Directory

| File | Layer | Status |
| --- | --- | --- |
| `README.md` (this file) | 1 | skeleton |
| `STATE_SURFACE_LAYERING.md` | 1 | skeleton |
| `CURRENT_STATE_SURFACE_RULES.md` | 1 | skeleton |
| `INDEX_SURFACE_RULES.md` | 1 | skeleton |
| `ARCHIVE_SURFACE_RULES.md` | 1 | skeleton |
| `COLD_START_READSET_RULES.md` | 1 | skeleton |
| `RUNTIME_REGISTRY_SYNC_GUARD.md` | 1 | skeleton |
| `STATE_SURFACE_MIGRATION_CASE_SP115.md` | 2 | GUIDED (case study) |

## Related Schemas (`schemas/governance/`)

| Schema | Validates |
| --- | --- |
| `state_surface_policy.schema.json` | Per-project surface size / archive policy declaration |
| `cold_start_readset.schema.json` | Cold-start readset minimum contract |
| `registry_sync_guard.schema.json` | Runtime registry sync guard configuration |

## Related Scripts (`scripts/governance/`)

| Script | Purpose |
| --- | --- |
| `lint_layer_separation.py` | **CI gate**: refuse Layer 1 files containing project names |
| `audit_state_surface_size.py` | Walk active surfaces, report against size policy |
| `generate_state_surface_index.py` | Materialize sprint_index / task_index / agents_index shells |
| `validate_current_state_surface.py` | Validate surface conformance against rules |
| `validate_cold_start_readset.py` | Verify readset includes the OS minimum contract |
| `validate_registry_sync_guard.py` | Verify sync guard runtime behaviour |

## Skeleton Discipline

Per `V4_90_README.md` §4.1 layering principle and EP plan §3.4:

1. **NO project names in Layer 1** — case studies isolate them.
2. **Schemas validate emptiness** — projects can opt-in incrementally.
3. **Scripts return exit 4 NOT_IMPLEMENTED** in skeleton tier.
4. **`lint_layer_separation.py` is GUIDED from day one** — it's the
   safety net for everything else; cannot land as STUB.

## v4.90 Roadmap (per plan §8 batch order)

```
Batch 3   This skeleton + lint_layer_separation.py GUIDED  ✅ closed
Batch 3.5 STATE_SURFACE_MIGRATION_CASE_SP115.md             ✅ closed (Layer 2 evidence)
Batch 4   LTM v2 / Failure-Fix Memory                       ⏳ next (consumes case study)
```

## Cross-References

- `docs/13_migration/` — P0-1 Progressive Adoption (sister module)
- `docs/13_migration/PROJECT_RUNTIME_PROTOCOL.md` — adoption yaml shape
  (will gain a `governance:` node referring to this module)
- `V4_90_README.md` §4.1 — layering principle source
