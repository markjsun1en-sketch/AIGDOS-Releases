# Index Surface Rules

> **Skeleton — v4.90 Batch 3 Step 1**
> **Layer 1 (OS Spec)** — no project names

## Purpose

Index surfaces (Tier 2) provide **routing only**, not content. They
answer "where do I find …?" without forcing the consumer to load
the underlying detail until needed.

## Required Index Surfaces (OS Minimum)

Every adopting project MUST maintain at least:

| Index | Purpose | Default location |
| --- | --- | --- |
| `sprint_index` | sprint id → status / closure report path | `tasks/sprint_index.md` |
| `task_index` | task id → state / owner / current_summary file | `tasks/task_index.md` |
| `agents/index` | agent → status / current task / archive pointer | `logs/agents/index.md` |
| `orchestrator_decision_index` | decision id → date / status / owner / link | `logs/orchestrator_decision_index.md` |

Projects may add more (e.g. milestone_index, handoff_index) but cannot
remove these four without explicit override.

## Per-Index Required Fields

A row in any index MUST include:

```yaml
id: <sprint id / task id / agent name / decision id>
status: <enum specific to the index kind>
last_updated: <ISO 8601>
detail_path: <relative path to Tier 3 archive or detail file>
```

A row MUST NOT include:

- Full evidence content (only path)
- Free-text narrative (use Tier 3 detail file)
- Cross-index data (e.g. task_index row should not duplicate sprint_index info)

## Index Update Discipline

1. Indexes update **at the boundary of state transitions**, not continuously.
   - sprint_index updates on sprint open / close
   - task_index updates on task creation / status change / closure
   - agents/index updates on agent active-task change
   - decision_index updates on decision recorded / superseded
2. Indexes are written by the same actor that mutates the underlying state
   (no asynchronous reconciliation; reconciliation = drift bug).
3. An index row missing for an active entity is a CI failure.

## Cold-Start Coupling

Indexes are part of the cold-start readset minimum contract — see
`COLD_START_READSET_RULES.md`. Without all four indexes loaded, the
runtime cannot resolve routing queries deterministically.

## Schema

Per-row shape per index kind in `schemas/governance/state_surface_policy.schema.json`
under the `indexes:` node. Skeleton in Batch 3 Step 1.

## Layer Discipline

Layer 1 (OS Spec). No project names.
