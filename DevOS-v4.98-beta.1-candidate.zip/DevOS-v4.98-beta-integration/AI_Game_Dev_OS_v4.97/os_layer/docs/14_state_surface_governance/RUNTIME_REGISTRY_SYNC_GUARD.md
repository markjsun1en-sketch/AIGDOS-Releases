# Runtime Registry Sync Guard

> **Skeleton — v4.90 Batch 3 Step 1**
> **Layer 1 (OS Spec)** — no project names

## Purpose

When narrative surfaces (sprint_board / agent_log) are slimmed and
runtime registries (task_registry.json / handoff_queue.json) are synced
from those surfaces, **historical rows must NOT be dropped**. This is
the single most-violated rule observed in real adoptions: a sync tool
designed against a "full history" board silently truncates registries
when fed a "current-only" slimmed board.

The sync guard is a runtime contract enforced by the sync tool itself.

## Sync Guard Required Behaviour

A registry sync tool MUST:

1. **Preserve historical rows**: rows for tasks NOT present in the
   current slimmed source survive untouched in the registry.
2. **Update only matching rows**: for each task id present in BOTH the
   source and the registry, update the registry row from source.
3. **Insert new rows**: tasks in source but not in registry are inserted.
4. **Refuse silent deletion**: rows in registry but not in source are
   NEVER removed without an explicit `--archive-stale` flag.
5. **Multi-version schema tolerance**: support both pre-slim full board
   schema AND post-slim current-only schema (column count diff).
6. **Markdown marker stripping**: strip backtick `inline-code` markers
   before writing task ids / status values to the JSON registry.
7. **Dry-run mode**: `--dry-run` prints diff without mutating the registry.

## Configuration Schema

```yaml
registry_sync_guard:
  source_kinds_supported:
    - sprint_board_v1   # pre-slim 10-column board
    - sprint_board_v2   # post-slim 9-column board
  preserve_historical_rows: true   # MUST be true; enforced by validator
  strip_markdown_markers: true
  refuse_silent_deletion: true
  archive_stale_explicit_flag: --archive-stale
  dry_run_supported: true
```

## Validator (Batch 3 Step 2)

`scripts/governance/validate_registry_sync_guard.py` will run a
synthetic before/after fixture pair through the project's sync tool and
assert all 7 required behaviours.

In Batch 3 Step 1 (this commit), the validator is STUB tier
(exit 4 NOT_IMPLEMENTED).

## Anti-Patterns Observed in Real Adoptions

Each entry below is a real failure mode that the guard rules above prevent:

| Anti-pattern | Failure mode | Guard rule that catches it |
| --- | --- | --- |
| Sync truncates history when board is slimmed | Closed sprints disappear from registry | (1) Preserve historical rows |
| Sync writes "  ` <task_id> `" as task_id (markdown inline-code wrapping) | JSON consumers fail to match | (6) Strip markdown markers |
| Sync silently drops rows for tasks no longer on board | Audit trail broken | (4) Refuse silent deletion |
| Sync hard-fails on column count change | Cannot adopt slim board incrementally | (5) Multi-version schema tolerance |
| Sync mutates registry before validation | Half-applied diffs on ERROR | (7) Dry-run mode + atomic write |

## Schema

`schemas/governance/registry_sync_guard.schema.json` defines the
configuration. Skeleton in Batch 3 Step 1.

## Layer Discipline

Layer 1 (OS Spec). No project names. The anti-pattern table above is
generic; project-specific incidents belong in case-study files.
