# Proposal Kind Catalog

> **v4.90 Batch 6 Module A**
> Enumerates the 6 `proposal_kind` values accepted by
> `schemas/self_evolution/proposal_entry.schema.json`.
> Layer 1 (OS Spec). No project names.

## Why a closed enum?

A closed `proposal_kind` enum keeps the ledger searchable and allows
batch-level governance rules (e.g. "all `schema_extension` proposals
must cite the schema file in `references[]`"). New kinds require a
meta-proposal that updates this catalog + the schema enum.

## Kinds (6)

### 1. `capability_promotion`

Promote a pattern observed across 2+ batches into a first-class
capability inside `docs/13_migration/CAPABILITY_COMPATIBILITY_MATRIX.md`
or a sibling matrix. Typically accompanied by a new fingerprint +
validation contract.

**Example**: "Promote the Batch 2 scan→validate pipeline into a
reusable capability fingerprint once 3 adopting projects have used
it end-to-end."

**Must reference**: the observation sources (batch close notes,
validator outputs), the target matrix row.

### 2. `architecture_principle`

Codify a cross-cutting OS Core principle that spans multiple modules
(e.g. layering rules, separation of concerns, naming conventions).

**Example**: `evo_2026_001` — codify Layer 1 / Layer 2 separation
as an OS Core principle.

**Must reference**: evidence from at least 2 existing batches or 1
batch + 1 Layer 2 case study.

### 3. `lifecycle_hook`

Add, modify, or retire an OS lifecycle hook (sprint_close,
cold_start, pack_activation, etc.).

**Example**: "Add a pre-commit hook spec in `docs/15_ltm_v2/` that
captures Failure-Fix entries during a live debugging session."

**Must reference**: the hook's spec doc, the script (STUB or GUIDED),
downstream consumers.

### 4. `schema_extension`

Extend an existing JSON Schema with new fields, enums, or
conditional-required rules. In-place additions (no breaking change);
breaking schema edits require a `deprecation` proposal first.

**Example**: "Extend `adoption_report.schema.json` with per-finding
`suggested_adapter` field."

**Must reference**: the `$id` of the schema, the draft version, any
cross-schema dependencies.

### 5. `runtime_contract`

Formalise a runtime I/O contract: a new CLI, a new exit-code map,
a new stdin/stdout format. Often pairs with a `schema_extension` if
the contract emits structured data.

**Example**: "Formalise `run_mock_harness.py` custom spec yaml
grammar so third-party consumers can author specs directly."

**Must reference**: the script path, the current exit-code map,
planned argv/stdin/stdout shapes.

### 6. `deprecation`

Retire a capability, schema field, script, or doc. Always paired
with a migration path (if any) and a target sunset batch.

**Example**: "Deprecate `scripts/migration/adopt_capability.py` STUB
in favour of `scripts/adoption/run_mock_harness.py --fixture custom`
once the harness covers the adoption use case."

**Must reference**: the artefact being deprecated, the replacement,
the target removal batch.

## Schema reference

`schemas/self_evolution/proposal_entry.schema.json` enforces:

```yaml
proposal_kind:
  enum:
    - capability_promotion
    - architecture_principle
    - lifecycle_hook
    - schema_extension
    - runtime_contract
    - deprecation
```

Additions to this enum are themselves `schema_extension` proposals.

## Layer Discipline

Layer 1 (OS Spec). Every example above is generic; project-specific
concretisations go into Layer 2 case studies.
