# PROPOSAL_VALIDATION_PLAN.md

> **v4.90 Batch 10 — Self-Evolution Validation Plan adopter guide**
> **Status**: adopter quickstart for the 1.1.0-beta proposal schema
> (validation_plan / change_candidate / sandbox_dir).
> **Discipline**: proposal-only (Q4=A). The validator is read-only, never
> auto-promotes state, never merges into canonical. Every mutation is
> still an explicit commit authored by a human maintainer.
> **Layer**: Layer 1 (OS Spec). All examples use generic identifiers.

---

## 1. Purpose

The 1.0.0 proposal schema (Batch 6) captured the 9-state lifecycle and
the 6 `proposal_kind` enum values, but it did not record **what must be
true before an accepted proposal can land in canonical source**. Two
gaps surfaced while drafting `evo_2026_001`:

1. A proposal flipped to `accepted` without declaring which regression
   checks (pytest, manifest regen, migration replay, human sign-off,
   etc.) are required before implementation may begin. Reviewers had to
   reconstruct the checklist from the proposal body text.
2. A proposal moving through `accepted → implementing` had no
   structural hook for pointing reviewers at the directory where
   experimental diffs could live without polluting canonical paths.

Step 10.1 addressed both gaps by extending the schema to **1.1.0-beta**
with three new front-matter fields:

- `validation_plan` — the checklist that gates the `accepted →
  implementing → implemented` transition.
- `change_candidate` — a read-only declaration of the directories a
  proposal *would* touch, useful for lint-scope planning.
- `sandbox_dir` — a path under `evolution/sandbox/` where experimental
  artefacts live during `implementing`, or `null` when no sandbox is
  needed (e.g. `architecture_principle` doctrine).

This guide documents the contract for each field, when the validator
enforces it (Step 10.3 state-conditional logic), and how adopters should
fill the fields in practice.

---

## 2. Scope and Status

**In scope for v4.90 Batch 10**:

- Schema field definitions (authoritative in
  `schemas/self_evolution/proposal_entry.schema.json`).
- State-conditional enforcement inside
  `scripts/self_evolution/validate_proposal.py`.
- Grandfather treatment for pre-1.1.0-beta `accepted` entries (WARN,
  not VIOLATION), allowing backfill on a proposal-by-proposal cadence.

**Out of scope (deferred)**:

- CLI wrapper (`ai-dev-os evolve validate`) — landed in v4.90 Batch 11.
- Batch runner that executes the declared checks — Batch 11+.
- Cross-proposal dependency graphs — deferred beyond v4.90.
- AI-driven proposal generation — explicitly excluded by Q4=A.

**Version gate**: every proposal entry MUST declare
`schema_version: "1.1.0-beta"`. The trailing `-beta` suffix marks the
minor bump window. Batch 12 Step 12.2 unifies this to `1.1.0` alongside
the rest of the Wave-2 schema promotions.

---

## 3. Schema Reference

Authoritative schema:
`schemas/self_evolution/proposal_entry.schema.json`

Three new fields introduced in Step 10.1 (all optional at the
jsonschema layer; conditional enforcement lives in the validator):

### 3.1 `validation_plan` (object)

```yaml
validation_plan:
  required:       # array, minItems=1, uniqueItems
    - <check>
  optional:       # array, uniqueItems
    - <check>
  notes: |        # string, free-form rationale
    ...
```

### 3.2 `change_candidate` (object)

```yaml
change_candidate:
  affected_dirs:  # array of non-empty strings, uniqueItems
    - <repo-relative dir>
```

### 3.3 `sandbox_dir` (string | null)

```yaml
sandbox_dir: "evolution/sandbox/<proposal_id>/"
# or
sandbox_dir: null
```

Pattern: `^evolution/sandbox/.+` when non-null.

---

## 4. `validation_plan` Contract

### 4.1 `required` (mandatory sub-field)

A non-empty, duplicate-free array naming the checks that MUST pass
before the proposal can transition to `implemented`. Allowed values
(five-member enum):

| Check | Meaning |
| --- | --- |
| `pytest` | Full `pytest -q` suite must remain green. |
| `smoke` | The runtime smoke harness must complete without error. |
| `manifest_check` | `RELEASE_MANIFEST.json` + `CHECKSUMS.sha` regenerate cleanly and the counts match the closure statement. |
| `migration_replay` | Mock-legacy-project migration replay succeeds end-to-end (applies when a proposal changes migration logic). |
| `human_review` | Explicit EP / maintainer sign-off recorded in `accepted_by` or as an equivalent commit trailer. |

Any value outside this enum is a hard VIOLATION (exit 1).

### 4.2 `optional` (recommended sub-field)

Same enum as `required`. Checks listed here are encouraged but not
blocking. Overlap with `required` is permitted (no warning either way)
— the validator only cares that `required` is non-empty and that every
entry belongs to the enum.

### 4.3 `notes` (recommended sub-field)

Free-form string explaining **why** the author picked this particular
set of checks. Example justifications: "doctrine-only proposal, so
`human_review` alone is sufficient", or "schema touches migration
scripts, so `migration_replay` is mandatory".

---

## 5. `change_candidate` Contract

`change_candidate.affected_dirs` is a **read-only declaration** of the
directories the proposal would touch if implemented. It is not a write
authorisation — sandbox discipline still applies, and canonical edits
happen in separate commits (see Step 6 in
`PROPOSAL_LIFECYCLE_GUIDE.md`).

Adoption recommendations:

1. List **repo-relative** directory paths (e.g.
   `scripts/governance`, `docs/14_state_surface_governance`). Avoid
   absolute paths and file-level granularity — directory level is
   enough for scope planning.
2. Include every Layer 1 root the implementation will touch.
3. If the implementation is expected to add a new Layer 1 root, include
   it; the lint scope extension becomes part of the
   `change_candidate` surface.
4. Keep the list **deduplicated**. Duplicate entries are a VIOLATION.
5. A proposal with no filesystem footprint (pure doctrine)
   MAY omit the field entirely, or emit
   `change_candidate: {affected_dirs: []}` to signal explicit
   intent.

---

## 6. `sandbox_dir` Contract

The `evolution/sandbox/` tree (Step 10.2) is the one place where a
proposal's implementing author may stage experimental diffs without
touching canonical. Naming convention:

```
evolution/sandbox/<proposal_id>/
```

Lifecycle:

- **draft / submitted / under_review / accepted** — `sandbox_dir`
  MAY be `null`. Acceptance alone does not require a sandbox.
- **implementing** — the maintainer SHOULD create the sandbox
  directory and set `sandbox_dir` to its repo-relative path. When the
  proposal is pure doctrine (`proposal_kind: architecture_principle`)
  and implementation is a paper trail only, `sandbox_dir` MAY remain
  `null`; the validator emits a WARN but not a VIOLATION (see §7).
- **implemented** — the sandbox MAY be archived; the `sandbox_dir`
  value stays in the front-matter as historical evidence.

Structural rules:

- Value MUST match `^evolution/sandbox/.+` or be `null`. Any other
  string is a VIOLATION.
- The corresponding directory SHOULD exist under
  `evolution/sandbox/` with a short `README.md` describing the
  experiment (see `evolution/sandbox/README.md` for the template).

---

## 7. State-Conditional Enforcement Rules

Step 10.3 wired the new fields into
`scripts/self_evolution/validate_proposal.py`. Enforcement is
deliberately state-conditional so pre-existing entries stay passing
through the 1.0.0 → 1.1.0-beta window:

| State | `validation_plan` | `sandbox_dir` | `change_candidate` |
| --- | --- | --- | --- |
| `draft` | optional | optional | optional |
| `submitted` | optional | optional | optional |
| `under_review` | optional | optional | optional |
| **`accepted`** | **recommended (WARN if missing)** | optional | optional |
| **`implementing`** | recommended | **recommended (WARN if missing)** | optional |
| `implemented` | recommended | optional | optional |
| `rejected` | not validated | not validated | not validated |
| `superseded` | not validated | not validated | not validated |
| `withdrawn` | not validated | not validated | not validated |

Key properties:

- **Grandfather clause** — missing fields on `accepted` or
  `implementing` entries produce WARN (exit stays 0), not VIOLATION.
  This lets pre-1.1.0-beta proposals stay green until their next
  substantive edit.
- **Structural violations are still hard** — if the field IS present
  but ill-shaped (wrong type, unknown enum value, bad pattern), the
  validator emits VIOLATION and returns exit 1.
- **`change_candidate`** is never required by state; the validator only
  checks its internal shape when present.

---

## 8. Authoring Workflow

Expected editing sequence aligned with
`PROPOSAL_LIFECYCLE_GUIDE.md`:

1. **Draft and submit** — fill the Batch 6 baseline (nine required
   keys). `validation_plan` / `change_candidate` / `sandbox_dir` may
   be absent.
2. **Under review** — discussion may refine the intended check list.
   Reviewers MAY insert a draft `validation_plan` for the author to
   confirm.
3. **Transition to `accepted`** — in the same commit that sets
   `state: accepted` + `accepted_at` + `accepted_by`, add the
   `validation_plan` block (at minimum, the `required` list). Commit
   message SHOULD reference the new field:
   `feat(v4.90 proposal): accept evo_YYYY_NNN with validation_plan`.
4. **Transition to `implementing`** — if the proposal will produce
   diffs, create `evolution/sandbox/<proposal_id>/` and set
   `sandbox_dir`. Add `change_candidate.affected_dirs` listing the
   canonical roots the implementation will touch.
5. **Transition to `implemented`** — record the implementing commits
   in `implemented_by_commits`. The canonical diff itself is NOT part
   of the proposal file — the proposal records rationale, not patches.

At every step, run
`python3 scripts/self_evolution/validate_proposal.py --file <path>`.
Exit 0 means no VIOLATION (WARNs are still acceptable); exit 1 means
fix before committing.

---

## 9. Validator Usage

### 9.1 Single file

```bash
python3 scripts/self_evolution/validate_proposal.py \
    --file proposals/evo_YYYY_NNN_<slug>.md
```

### 9.2 Whole ledger

```bash
python3 scripts/self_evolution/validate_proposal.py \
    --dir proposals/
```

### 9.3 JSON output

```bash
python3 scripts/self_evolution/validate_proposal.py \
    --dir proposals/ --format json
```

Emits a ledger-shaped JSON record suitable for downstream CI.

### 9.4 Exit codes

| Code | Meaning |
| --- | --- |
| `0` | OK — no VIOLATIONs (WARNs may still be present). |
| `1` | VIOLATION — one or more shape or state-conditional rules failed. |
| `3` | INTERNAL — parser crashed or schema drifted. |
| `4` | INPUT_MISSING — `--file` / `--dir` target not found or empty. |

The validator never mutates any file. It only reads front-matter and
emits diagnostics.

---

## 10. Reference Implementations and Next Steps

**Seed proposal**:
`proposals/evo_2026_001_layer_separation_principle.md` — backfilled in
Step 10.4 with a minimal `validation_plan` (`human_review` required,
`pytest` optional, `sandbox_dir: null` because this is a doctrine
proposal with no dedicated sandbox).

**Sibling documents**:

- `PROPOSAL_STATE_MODEL.md` — 9-state lifecycle, 12 allowed transitions.
- `PROPOSAL_KIND_CATALOG.md` — 6 `proposal_kind` enum values.
- `PROPOSAL_LIFECYCLE_GUIDE.md` — 7-step authoring flow.
- `README.md` — module entry point.

**Batch 11 preview** (CLI wrapper):

```
ai-dev-os evolve validate [--file <path>] [--dir proposals/] [--format text|json]
```

Same exit semantics as the underlying script. Batch 11 will also wire
the `validation_plan.required` list into a batch runner so CI can fail
fast when a required check drifts.

**Batch 12** will promote `schema_version: "1.1.0-beta"` to `"1.1.0"`
as part of the Wave-2 unify-promote, retire the `-beta` suffix across
all new Batch 8/9/10/11 schemas, and rebuild `CHANGELOG.md` with the
final schema inventory.
