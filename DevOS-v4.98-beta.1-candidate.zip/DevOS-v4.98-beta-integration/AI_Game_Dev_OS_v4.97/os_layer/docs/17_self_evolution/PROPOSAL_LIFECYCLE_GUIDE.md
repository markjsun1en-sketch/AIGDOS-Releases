# Proposal Lifecycle Guide

> **v4.90 Batch 6 Module A**
> 7-step flow from draft to implemented / closed.
> Layer 1 (OS Spec). No project names.

## Flow

```
  1. Draft
        │
        ▼
  2. Submit for review
        │
        ▼
  3. Review (open)
        │
        ▼
  4. Decide  ───────────┐──────────────┐
        │               │              │
        ▼               ▼              ▼
  5a. Accept       5b. Reject     5c. Supersede
        │                                     (by other proposal)
        ▼
  6. Implement
        │
        ▼
  7. Implemented (or withdrawn / rejected on blocker)
```

## Step-by-step

### 1. Draft

- Create `proposals/evo_YYYY_NNN_short-slug.md`.
- Set `state: draft`.
- Fill out required front-matter: `proposal_id`, `proposal_kind`,
  `title`, `submitted_at` (use the time you expect to submit, not
  draft-start), `submitted_by` (generic identifier), `summary`,
  `references[]`.
- Body should include: Background, Proposal, Evidence, Open
  questions. Wait to fill Implementation Status until Step 6.
- Run `python3 scripts/self_evolution/validate_proposal.py --file <path>`.
  Fix any shape errors before moving on.

### 2. Submit for review

- Flip `state: submitted`.
- Commit with message `feat(v4.90 proposal): submit evo_YYYY_NNN`.
- Notify stakeholders (Layer 2 case for who exactly; Layer 1 just
  says "the relevant batch owners").

### 3. Review (open)

- First reviewer flips `state: under_review` and commits.
- Reviewers comment in-tree (PR review, or a paired `REVIEW_NOTES.md`
  Layer 2 case file; proposal body SHOULD stay clean).
- Iterate on the proposal body if needed. Every edit is a commit.

### 4. Decide

After review, one of three transitions:

- **5a. Accept** — consensus reached; proposal will drive canonical
  edits. Set `state: accepted`, fill `accepted_at` + `accepted_by`.
- **5b. Reject** — consensus against or blocked by a hard constraint.
  Set `state: rejected`, fill `rejected_at`.
- **5c. Supersede** — another `evo_YYYY_NNN` proposal lands that
  covers the same ground better. Set `state: superseded`, fill
  `superseded_by` with that proposal id.

### 5a. Accept

The proposal now becomes the source of truth for a pending canonical
change. Implementation happens in subsequent commits (Step 6).

### 5b. Reject / 5c. Supersede

Terminal. The file stays in the ledger as evidence. Do not delete it —
future proposals may cite prior rejections as rationale.

### 6. Implement

- Flip `state: implementing`.
- Canonical edits land via normal commits (NOT through the proposal
  itself — the proposal is a rationale anchor, not a patch).
- Each implementing commit SHOULD reference the proposal id in its
  message: `feat(v4.90 batch-X step-X.Y): <change> (implements evo_YYYY_NNN)`.
- If a blocker surfaces, flip back to `rejected` with a
  `rejected_at` note and open a new proposal if the work should
  restart.

### 7. Implemented

- Flip `state: implemented`.
- Fill `implemented_at` (optional field reserved for Batch 7+).
- Update the proposal's Implementation Status section with a bullet
  list of the implementing commits.
- Terminal success state.

## Withdrawal (any time before implementation)

At any point during states `draft`, `submitted`, `under_review`, or
`accepted`, the original submitter may retract the proposal. Set
`state: withdrawn` and commit. No outgoing transitions.

## Validation touchpoints

- **On every commit**: run
  `python3 scripts/self_evolution/validate_proposal.py --file <path>`.
- **In CI (Batch 7)**: `--dir proposals/` validates the whole ledger.
- **Layer 1 lint**: `scripts/governance/lint_layer_separation.py`
  covers `proposals/` via the `evo_\d{4}_\d{3}*.md` regex exemption.

## Layer Discipline

Layer 1 (OS Spec). All guidance is generic; project-team-specific
review workflow belongs in a Layer 2 case study.
