---
title: Proposal State Model
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: 14.6
protected_invariants:
  - inv_003_state_machine_doc_schema_aligned
---

# Proposal State Model

> **v4.90 Batch 6 Module A**
> Mirrors the 9-state structure of `docs/13_migration/ADOPTION_STATE_MODEL.md`.
> Layer 1 (OS Spec). No project names.

## States (9)

```
draft              — proposal being drafted, not yet submitted for review
submitted          — author declared ready; opens the review window
under_review       — actively being evaluated
accepted           — approved; awaiting implementation
rejected           — declined; closed without implementation
implementing       — accepted and in-flight (canonical edits landing)
implemented        — implementation complete; terminal success state
superseded         — an alternative proposal (referenced via superseded_by)
                     has replaced this one; terminal
withdrawn          — author retracted; closed without implementation
```

## State diagram

```
                     ┌─────────┐
                     │  draft  │
                     └────┬────┘
                          │
                          ▼
                  ┌───────────────┐
                  │   submitted   │
                  └───────┬───────┘
                          │
                          ▼
                  ┌───────────────┐
         ┌────────│ under_review  │────────┐
         │        └───────┬───────┘        │
         │                │                │
         ▼                ▼                ▼
  ┌────────────┐  ┌─────────────┐  ┌────────────┐
  │  accepted  │  │   rejected  │  │ superseded │
  └──────┬─────┘  └─────────────┘  └────────────┘
         │                ▲
         ▼                │
  ┌──────────────┐        │
  │ implementing │────────┘   (rare: discovered blocker)
  └──────┬───────┘
         │
         ▼
  ┌──────────────┐
  │ implemented  │   ← terminal success
  └──────────────┘

  * → withdrawn    (allowed from draft / submitted / under_review /
                    accepted; NOT from implementing / implemented /
                    rejected / superseded / withdrawn)
```

## Transition table (12 allowed)

| From | To | Allowed | Trigger |
| --- | --- | --- | --- |
| `draft` | `submitted` | yes | author hits "submit for review" |
| `submitted` | `under_review` | yes | first reviewer opens the file |
| `under_review` | `accepted` | yes | review reached consensus |
| `under_review` | `rejected` | yes | review declined the proposal |
| `under_review` | `superseded` | yes | a better alternative landed first |
| `accepted` | `implementing` | yes | implementation work begins |
| `implementing` | `implemented` | yes | implementation complete |
| `implementing` | `rejected` | yes | blocker surfaced during implementation |
| `draft` | `withdrawn` | yes | author retracts before submission |
| `submitted` | `withdrawn` | yes | author retracts during review window |
| `under_review` | `withdrawn` | yes | author retracts during review |
| `accepted` | `withdrawn` | yes | author retracts before implementation |

**Terminal states**: `implemented`, `rejected`, `superseded`, `withdrawn`.
No outgoing transitions; subsequent change requires a fresh
`evo_YYYY_NNN` proposal.

## Schema

`schemas/self_evolution/proposal_state.schema.json` validates the
per-proposal state document. `proposal_entry.schema.json` encodes
conditional-required fields:

- `state: accepted` → `accepted_at`, `accepted_by` required
- `state: rejected` → `rejected_at` required
- `state: superseded` → `superseded_by` (pattern `^evo_\d{4}_\d{3}$`) required
- `state: withdrawn` → `withdrawn_at` required (optional in 1.0.0)

`transition_history[]` entries use an `allOf.anyOf` whitelist of the
12 transitions above (matches the `capability_adoption_state.schema.json`
Batch 2.5 tightening pattern).

## Layer Discipline

Layer 1 (OS Spec). No project names. Transition history entries are
referenced by proposal_id; per-proposal implementation evidence
goes into Layer 2 case studies under `docs/14_state_surface_governance/`
with the `STATE_SURFACE_MIGRATION_CASE_*.md` regex exemption.
