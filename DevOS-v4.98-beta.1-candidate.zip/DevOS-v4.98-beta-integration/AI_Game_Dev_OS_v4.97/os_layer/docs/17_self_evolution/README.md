# 17 — Self-Evolution

> **v4.90 Batch 6 — P1-2 Self-Evolution Skeleton**
> **Status**: proposal-only skeleton; no auto-merge, no AI-driven
> proposal generation, no cross-project sync in v4.90. The seed
> proposal `evo_2026_001` is accepted as Layer 1 / Layer 2
> separation principle.
> **Layering principle**: this directory MUST stay project-name-free
> (Layer 1 OS Spec). The sibling `proposals/` directory has a Layer 2
> regex exemption for `evo_\d{4}_\d{3}*.md` files so that seed
> proposals can cite case studies when needed.

## Purpose

Capture OS Core evolution decisions as schema-validated, first-class
artefacts. Every meaningful architectural / schema / lifecycle change
to the v4.90 OS Core from Batch 6 onwards SHOULD surface as a proposal
before the change lands in canonical source — providing a traceable
rationale ledger that outlives individual sprints.

## Documents in this directory

| File | Role | Status |
| --- | --- | --- |
| `README.md` (this file) | Module entry point + NOT-in-v4.90 guardrails | skeleton |
| `PROPOSAL_STATE_MODEL.md` | 9-state lifecycle + 12 allowed transitions + schema refs | skeleton |
| `PROPOSAL_KIND_CATALOG.md` | 6 `proposal_kind` enum values + examples | skeleton |
| `PROPOSAL_LIFECYCLE_GUIDE.md` | 7-step flow from draft to implemented | skeleton |

## Sister artefacts

- `schemas/self_evolution/proposal_entry.schema.json` — per-file
  front-matter contract (draft-07, 1.0.0).
- `schemas/self_evolution/proposal_state.schema.json` — per-proposal
  state tracker, mirrors `capability_adoption_state.schema.json`.
- `schemas/self_evolution/proposal_ledger.schema.json` — aggregate
  ledger across `proposals/`.
- `scripts/self_evolution/validate_proposal.py` — read-only validator
  (GUIDED tier, Batch 6 Module B).
- `proposals/` — the ledger itself (Layer 1 root with `evo_*` regex
  exemption).

## Two-layer discipline (CRITICAL)

Documents in this module MUST stay **principle-level** and
**project-name-free**. Concrete project migrations that illustrate a
proposal belong in `STATE_SURFACE_MIGRATION_CASE_<PROJECT>.md`
(Layer 2, regex-exempt under `docs/14_state_surface_governance/`).

Seed proposal files (`proposals/evo_*.md`) may cite Layer 2 case
studies by relative path reference, but MUST NOT inline project-name
content themselves.

## 9 states (see PROPOSAL_STATE_MODEL.md)

```
draft → submitted → under_review → accepted → implementing → implemented
                                 → rejected
                                 → superseded
                                 → withdrawn
```

## 6 proposal_kind enum values (see PROPOSAL_KIND_CATALOG.md)

1. `capability_promotion` — promote a pattern/fingerprint into the
   capability matrix.
2. `architecture_principle` — codify a cross-cutting OS principle.
3. `lifecycle_hook` — add or modify an OS lifecycle hook.
4. `schema_extension` — extend an existing schema with new fields.
5. `runtime_contract` — formalise a runtime I/O contract.
6. `deprecation` — retire a capability / schema / script.

## Batch 6 deliverables (closed 2026-05-11)

- 4 skeleton docs (this file + 3 siblings)
- 3 schemas in `schemas/self_evolution/`
- `scripts/self_evolution/validate_proposal.py` GUIDED
- `proposals/README.md` + 1 seed proposal
- 1 capability matrix update: row 14 `14_self_evolution_proposal`
  promoted from `deprecated` to `requires_adapter`, consuming
  `07_ltm_capture_consult`. See V4_90_README §5.8 for the
  scored 11→12 / deprecated 3→2 knock-on.

## What is NOT in v4.90 Batch 6

- **No auto-merge / auto-apply**. Every canonical mutation is still
  an explicit commit. Proposals document intent, not state.
- **No AI-driven proposal generation**. Seed proposals are hand-authored.
- **No cross-project evolution sync**. Proposals are local to this
  OS Core version until a dedicated adapter lands (Batch 7+).
- **No voting / review workflow engine**. State transitions are still
  human-driven edits.
