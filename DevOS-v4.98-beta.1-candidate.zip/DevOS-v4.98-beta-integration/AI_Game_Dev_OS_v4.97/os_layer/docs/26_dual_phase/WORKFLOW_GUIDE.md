# Workflow Guide — `stage` × `game_dev_phase`

> **Layer 1 (OS Spec).** v4.91 P7 / B-DUAL-PHASE-DOC.
>
> Sister docs: [`README.md`](README.md) · [`DECISION_MATRIX.md`](DECISION_MATRIX.md)

---

## 1. Adoption flow — first-time setup

A host project initialising its `<.ai_dev_os>/` directory:

```bash
# Recommended: declare both fields explicitly.
python3 scripts/adoption/init_project_runtime.py \
    --project-id <opaque-pid> \
    --name "<Human Name>" \
    --stage alpha \
    --game-dev-phase mvp

# Acceptable: omit --game-dev-phase and let the CLI pick a default
# from --stage. This was the v4.90.9 default-derivation behaviour;
# it is preserved into v4.91.
python3 scripts/adoption/init_project_runtime.py \
    --project-id <opaque-pid> \
    --name "<Human Name>" \
    --stage alpha
```

The init CLI writes both fields into
`<.ai_dev_os>/02_project_profile.yaml`. After init, the EP / lead
operator should look up the resulting `(stage, game_dev_phase)`
pair in [`DECISION_MATRIX.md`](DECISION_MATRIX.md) and confirm the
posture matches expectations.

## 2. Adoption flow — migrating from a single-stage project

Projects that adopted v4.90 / earlier had a single `stage` field;
v4.90.9 split it. The migration path:

1. Read the existing `02_project_profile.yaml`. Confirm
   `schema_version` is `1.0.0` or older.
2. Run the schema upgrade tool (or hand-edit; the schema bump is
   small):
   - Add the required `game_dev_phase` field. If unsure, pick the
     value the v4.90.9 init CLI would have chosen for the
     existing `stage` (see `scripts/adoption/init_project_runtime.py`
     :: `_default_phase_for_stage`).
   - Bump `schema_version` to `1.1.0`.
3. Confirm the cell with [`DECISION_MATRIX.md`](DECISION_MATRIX.md).
4. Commit.

## 3. Day-to-day — when do these fields change?

| Field | When it changes | Who decides |
|-------|-----------------|-------------|
| `project_id` | Never (immutable; Charter anti-pattern #2 — namespace stability). | n/a |
| `stage` | When the company moves the title forward in its lifecycle (incubation → alpha → beta → ...). Typically once per release cycle. | EP. |
| `game_dev_phase` | When the game-build pipeline crosses a workflow boundary (prototype → MVP → vertical_slice → ...). Typically several times per `stage` cycle. | Game director / lead engineer. |

The independence is by design: `game_dev_phase` may oscillate
inside a stable `stage` without forcing a stage change.

## 4. Common edge cases

### 4.1 Live title prototyping

`stage=production`, `game_dev_phase=prototype` — a LIVE commercial
title is exploring a new feature. The matrix flags this LATE:
honour the live-title gate cadence even though the feature is a
prototype.

Workflow:

1. Author the prototype on a feature branch.
2. Write the `evolution/` proposal up front (Charter anti-pattern
   #11 — recording != closure-gate pass; the proposal is
   evidence, not exemption).
3. Run the closure gate at the live-title cadence (typically
   `--profile fast` per commit + `--profile full` per release).
4. Promote / merge only after the proposal is approved AND the
   gate is clean.

### 4.2 Pre-funded experiment

`stage=incubation`, `game_dev_phase=alpha_build` — a one-week
experiment somehow reached feature-complete. Matrix flag: EARLY.

Workflow:

1. Skip the optional gates the company-stage row would cap, BUT
2. Write an `evolution/` proposal that documents the under-shoot
   so future audits know the build is `alpha_build`-grade despite
   `incubation`-row gating.
3. If the project graduates to `alpha`, re-run the gate cadence
   the new row prescribes; the prior under-shoot is preserved as
   audit history (Charter anti-pattern #14 — pointer-only).

### 4.3 Wind-down

`stage=sunset`, any `game_dev_phase` — uniformly TERMINAL.

Workflow:

1. Run the final certification: full closure gate, full memory
   uplink (typically Level-2 or Level-3 with rationale, since
   the certification archives a permanent contract change), final
   panel export to capture the wind-down state.
2. Subsequent commits run only mandatory gates.
3. When the project archives entirely, the
   `02_project_profile.yaml` stays in place as a tombstone
   record; deleting the project_id namespace is a separate
   archive-tier action outside this matrix.

## 5. FAQ

### Q: Can I set `game_dev_phase` higher than `stage` would normally imply?

A: Yes; that is the EARLY posture. Document the under-shoot in
`evolution/` so the audit trail is intact.

### Q: Can I set `game_dev_phase` lower than `stage` would normally imply?

A: Yes; that is the LATE posture. Honour the company-stage gate
cadence; the workflow descriptor doesn't relax governance.

### Q: Are there cells the matrix forbids?

A: No. Every cell is documented (TYPICAL / EARLY / LATE / REVIEW /
TERMINAL). REVIEW cells should trigger an EP review at adoption
time; they are NOT errors.

### Q: Does `game_dev_phase` ever feed into a Layer 1 gate?

A: No. `game_dev_phase` is a workflow descriptor only. Optional
gates consult `stage`. Adding a gate that reads `game_dev_phase`
would be a contract change requiring EP + matrix-owner approval.

### Q: What about `mount_mode`?

A: Orthogonal. `mount_mode` (3-enum: `external_core` /
`thin_scaffold` / `vendor_snapshot`, governed by Charter
anti-pattern #15) is independent of both `stage` and
`game_dev_phase`. A project on `external_core` can be in any cell
of the matrix.

### Q: Can the matrix change?

A: Yes — adding rows / columns / cells, or changing posture
labels, is a contract change requiring EP + matrix-owner approval
and a fresh batch (e.g. a future B-DUAL-PHASE-DOC-v2). The
underlying schema enums are also closed and require their own
EP-approved minor bump.

## 6. Cross-references

- Schema: `schemas/adoption/project_profile.schema.json` (1.1.0)
- v4.90.9 derive-default behaviour:
  `scripts/adoption/init_project_runtime.py`
- Sister docs:
  - [`README.md`](README.md) — overview + Charter alignment.
  - [`DECISION_MATRIX.md`](DECISION_MATRIX.md) — the 7×7 cell table.
- Adjacent invariants: `inv_002_layer_1_no_project_names` (the
  matrix doc itself uses no project names; only the 14 generic
  enum values across both axes appear).
