# Decision Matrix — `stage` × `game_dev_phase`

> **Layer 1 (OS Spec).** v4.91 P7 / B-DUAL-PHASE-DOC.
>
> Sister docs: [`README.md`](README.md) · [`WORKFLOW_GUIDE.md`](WORKFLOW_GUIDE.md)

---

## 1. The 7×7 matrix

The cells below recommend a **posture** for each
(`stage`, `game_dev_phase`) combination. Posture values:

- **TYPICAL** — well-trodden combination; default tooling
  defaults are appropriate.
- **EARLY** — the game-dev phase leads the company stage; expect
  to under-shoot some optional governance until the company stage
  catches up.
- **LATE** — the company stage leads the game-dev phase; expect
  to over-shoot some optional governance for a while (the live
  title's gate cadence applies even though the new feature is
  still a prototype).
- **REVIEW** — uncommon combination; flag for EP review at
  adoption time.
- **TERMINAL** — sunset / wind-down; minimal-touch posture.

Read columns left-to-right (`game_dev_phase`); read rows
top-to-bottom (`stage`).

| stage \ game_dev_phase | prototype | mvp | vertical_slice | alpha_build | beta_build | production | post_launch |
|---|---|---|---|---|---|---|---|
| `incubation`          | TYPICAL   | TYPICAL | EARLY        | EARLY       | EARLY      | EARLY      | REVIEW      |
| `alpha`               | LATE      | TYPICAL | TYPICAL      | TYPICAL     | EARLY      | EARLY      | REVIEW      |
| `beta`                | LATE      | LATE    | TYPICAL      | TYPICAL     | TYPICAL    | EARLY      | EARLY       |
| `release_candidate`   | LATE      | LATE    | LATE         | TYPICAL     | TYPICAL    | TYPICAL    | EARLY       |
| `production`          | LATE      | LATE    | LATE         | LATE        | TYPICAL    | TYPICAL    | TYPICAL     |
| `maintenance`         | REVIEW    | REVIEW  | LATE         | LATE        | LATE       | TYPICAL    | TYPICAL     |
| `sunset`              | TERMINAL  | TERMINAL| TERMINAL     | TERMINAL    | TERMINAL   | TERMINAL   | TERMINAL    |

## 2. Posture details

### 2.1 TYPICAL

Adoption tooling's defaults are appropriate. Optional gates run
at the cadence that the company-stage row prescribes (see
[`README.md`](README.md) § 3.1). Memory-uplink Level-1 default;
Level-2 / 3 by host decision.

### 2.2 EARLY

The game-dev phase is more advanced than the company stage. The
host project may legitimately under-shoot some optional governance
that would normally apply to the higher game-dev phase, because
the company-stage row caps the strictness. The operator should
nevertheless capture an `evolution/` proposal explaining the
intentional under-shoot — Charter anti-pattern #11 (recording !=
closure-gate pass) means the proposal is evidence, not exemption.

### 2.3 LATE

The company stage is more advanced than the game-dev phase. The
host project should expect to honour the strictness the
company-stage row prescribes even on a feature that is still a
prototype. Practical example: a live `production` title prototyping
a new mode runs the live-title gate cadence on the prototype
branch, not the prototype-phase cadence.

### 2.4 REVIEW

The combination is uncommon enough that the EP should flag it at
adoption time. Common review reasons:

- `incubation` + `post_launch`: the company is new, but the
  game-dev pipeline is treating an existing live title? Likely a
  data-entry error; verify.
- `maintenance` + `prototype` / `mvp`: a feature-frozen title
  starting a brand-new build pipeline? May be valid (a live-ops
  bridge to a sequel) but warrants a written rationale.

### 2.5 TERMINAL

The `sunset` row is uniformly TERMINAL across all 7 game-dev
phases. The project is winding down. Optional gates run only for
the final certification batch; subsequent commits skip optional
gates. Memory-uplink defaults to off; Level-1 / 2 / 3 emissions
are the operator's discretion.

## 3. Cell count and coverage

- 7 rows × 7 cols = **49 cells** total.
- Posture distribution (matches the table above):
  - **TYPICAL**: 13 cells
  - **EARLY**: 9 cells
  - **LATE**: 17 cells
  - **REVIEW**: 4 cells
  - **TERMINAL**: 7 cells (entire `sunset` row)

These counts are NOT an OS-level invariant — they're a
documentation aid. The matrix is recommendation-only; a host
project may choose a different posture for any cell with EP
written rationale.

## 4. How the matrix interacts with optional gates

Optional gates that consult `stage` (NOT `game_dev_phase`) for
strictness:

- Adoption-time gates in `scripts/adoption/`.
- Hub link-time gates in `scripts/hub/` (e.g.
  `validate_project_mount.py`).
- Version-lock policy decisions in `scripts/hub/lock_core_version.py`.
- Memory uplink default level for the host's uplink consumer
  (the level itself is still authored by the operator, but the
  default suggested by tooling can scale with `stage`).

`game_dev_phase` is NOT consulted by any Layer 1 gate today.
That's intentional: phase is a workflow descriptor, not a
governance lever (Charter anti-pattern #5). Adding a gate that
reads `game_dev_phase` would be a contract change requiring EP +
matrix-owner approval.

## 5. Worked examples

### Example A — `stage=production`, `game_dev_phase=prototype`

A live commercial title is prototyping a brand-new game mode in
a feature branch.

- Matrix cell: **LATE**.
- Recommended posture: run the live-title gate cadence (frequent
  closure-gate, frequent uplink emission, full memory-uplink
  reviewer chain) even on the prototype branch.
- Rationale: the prototype is connected to the live title's
  release pipeline; degraded governance there propagates risk to
  the live audience.

### Example B — `stage=alpha`, `game_dev_phase=alpha_build`

A small team is approaching feature-complete on their first build.

- Matrix cell: **TYPICAL**.
- Recommended posture: tooling defaults are appropriate. Optional
  gates: advisory; closure-gate per release. Memory-uplink at
  Level-1 default.

### Example C — `stage=incubation`, `game_dev_phase=alpha_build`

A pre-funding experiment that has somehow reached
feature-complete.

- Matrix cell: **EARLY**.
- Recommended posture: skip the optional gates the
  company-stage row would normally cap, but write an
  `evolution/` proposal documenting the under-shoot. The matrix
  recognises the legitimate possibility but flags it as
  not-yet-typical.

### Example D — `stage=sunset`, anything

The title is being wound down.

- Matrix cell: **TERMINAL**.
- Recommended posture: minimal-touch. Run optional gates ONLY
  for the final certification batch; afterwards, only mandatory
  gates run.

## 6. Caveats

- The matrix is RECOMMENDATIONS, not an enforcement table. No
  Layer 1 gate fails because of an "unusual" cell combination.
  REVIEW / EARLY / LATE postures are operational guidance.
- The matrix is INDEPENDENT of `mount_mode` (which is governed by
  `docs/20_project_mount/MOUNT_CONTRACT.md` and Addendum-B
  Charter anti-pattern #15). A project on `external_core` can be
  in any cell of this matrix; mount mode is orthogonal.
- The matrix is INDEPENDENT of cross-project memory promotion
  (which is governed by Charter anti-pattern #6 and `inv_010`).
  Stage / phase do not change auto-promote semantics.

## 7. Cross-references

- Schema: `schemas/adoption/project_profile.schema.json` (1.1.0)
- Init CLI: `scripts/adoption/init_project_runtime.py`
- v4.90.9 patch context: `RELEASE_NOTES.md` §
  "v4.90.9 — B-CG closed: fast/full closure gate split + PG-safe
   runner extraction + game-dev phase split (2026-05-17)"
- Sister docs: [`README.md`](README.md) · [`WORKFLOW_GUIDE.md`](WORKFLOW_GUIDE.md)
