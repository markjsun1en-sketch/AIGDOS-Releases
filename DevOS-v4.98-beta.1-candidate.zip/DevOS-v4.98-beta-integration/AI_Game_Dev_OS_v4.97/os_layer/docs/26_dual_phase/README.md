# Dual-Phase Decision — `stage` × `game_dev_phase`

> **Layer 1 (OS Spec) — adoption surface.** v4.91 P7 / B-DUAL-PHASE-DOC.
>
> **Underlying schema (v4.90.9, no change in P7)**:
> - [`schemas/adoption/project_profile.schema.json`](../../schemas/adoption/project_profile.schema.json) (1.1.0)
>
> **Underlying CLIs (v4.90.9, no change in P7)**:
> - [`scripts/adoption/init_project_runtime.py`](../../scripts/adoption/init_project_runtime.py) — auto-derives `game_dev_phase` from `--stage` when omitted.
> - [`scripts/hub/inspect_project.py`](../../scripts/hub/inspect_project.py) — surfaces both fields.
>
> **Tests** (v4.90.9, no change in P7): `tests/adoption/`, `tests/hub/`, `tests/version/`.
>
> **Sister docs in this directory**:
> - [`DECISION_MATRIX.md`](DECISION_MATRIX.md) — full 7×7 stage × phase matrix with recommended postures.
> - [`WORKFLOW_GUIDE.md`](WORKFLOW_GUIDE.md) — adoption flow + edge cases + FAQ.

---

## 1. Why this directory exists

`docs/26_dual_phase/` is the formal Layer 1 decision-matrix
documentation for the v4.90.9-era separation of two distinct
project descriptors:

- `stage` — **project lifecycle stage** (a 7-enum: `incubation`,
  `alpha`, `beta`, `release_candidate`, `production`,
  `maintenance`, `sunset`). Drives the strictness of OPTIONAL
  governance gates. A live commercial title in `production` runs
  the strictest profile; a one-week experiment in `incubation`
  may opt out of optional gates entirely.
- `game_dev_phase` — **game-development workflow phase** (a
  7-enum: `prototype`, `mvp`, `vertical_slice`, `alpha_build`,
  `beta_build`, `production`, `post_launch`). Describes WHERE the
  game-build pipeline sits, independent of when the company
  cuts a release.

The two were collapsed in early v4.91 plans into a single
"stage" field; v4.90.9 split them because the adoption tooling
needed both axes to choose sensible defaults (e.g. an `alpha` stage
title doing a `prototype` game-dev phase needs lighter LTM
filtering than an `alpha` stage title doing an `alpha_build` —
even though "alpha" appears in both).

The schema landed in v4.90.9. The decision matrix WORKFLOW
documentation deliberately landed in v4.91 P7 (this batch) once
the surrounding pieces (Hub Core / Project Mount / Version Lock /
Memory Sync / Panel Export) were all available to reference.

## 2. Plain-English summary

When a host project initialises (or migrates) its
`<.ai_dev_os>/02_project_profile.yaml`, it MUST declare BOTH
fields. The init CLI auto-derives `game_dev_phase` from `stage`
when omitted, but the host can override either independently.

The fields enter the system in these places:

- **LTM tagging**: `project_id` is the namespace tag; `stage` and
  `game_dev_phase` are NOT used as filter keys (they would
  fragment the LTM ledger). Consumers that want stage-aware
  filtering query the project's profile separately.
- **Optional gate strictness**: Adoption tools READ `stage` to
  decide whether an optional gate is mandatory, advisory, or
  skipped. They do NOT read `game_dev_phase` for gating purposes
  (game-dev workflow phase has no Charter-level gate consequence).
- **Decision matrix doc** (this directory): for each of the 49
  `stage × game_dev_phase` cells, the matrix recommends a posture
  for the host operator.

## 3. The two enums at a glance

### 3.1 `stage` — project lifecycle (7-enum, closed)

| Value | Posture |
|-------|---------|
| `incubation` | One-off / experiment / pre-team. Optional gates: skip-by-default. |
| `alpha` | Internal-only build; small team. Optional gates: advisory. |
| `beta` | External testing / closed beta. Optional gates: advisory; some required. |
| `release_candidate` | Final cut before launch. Optional gates: required. |
| `production` | Live commercial title. Optional gates: required + frequent. |
| `maintenance` | Live but feature-frozen. Optional gates: required (verify-only mode acceptable). |
| `sunset` | End-of-life; minimal change. Optional gates: skip after the final certification. |

### 3.2 `game_dev_phase` — game-build workflow (7-enum, closed)

| Value | Description |
|-------|-------------|
| `prototype` | Throwaway proof-of-concept. |
| `mvp` | Minimum viable build (one playable loop). |
| `vertical_slice` | Single area / level shipped to production quality. |
| `alpha_build` | Feature-complete game; content not final. |
| `beta_build` | Content-complete game; bug-fixing. |
| `production` | Shipping game in active development. |
| `post_launch` | Live ops / DLC / season content. |

## 4. Why two enums (not one)

The two enums collapsed into one would force false equivalences.
Examples that clarify the separation:

- A studio in **company stage** `production` (a live game) might
  start a brand-new feature at **game-dev-phase** `prototype`. The
  stage is "live commercial title"; the phase is "throwaway POC".
- A studio in **company stage** `alpha` (early team, internal
  builds) might iterate at **game-dev-phase** `vertical_slice` for
  the demo while the rest of the game is still `prototype`-grade.
  The two axes describe distinct things.

Conflating the axes would also create churn: every internal-build
phase change would falsely flip the company stage, and every
company-stage change would falsely lock the build phase.

## 5. Charter alignment

| # | Anti-pattern | Where enforced |
|---|---|---|
| 4 | Extend, don't replace | The v4.90.9 minor bump from 1.0.0 → 1.1.0 ADDED `game_dev_phase` rather than restructuring the existing `stage`. The schema_version is now const-locked at `1.1.0`; further bumps are minor (additive only). |
| 5 | Core does not bind to project narrative | Both enums use generic vocabulary; no project name appears in either enum or in any doc in this directory. |
| 11 | Recording != closure-gate pass | Docs in this directory are decision-support for human operators; declaring a `stage` / `game_dev_phase` does not bypass any closure-gate check. |

## 6. What this batch (P7) DOES NOT include

P7 is **doc-only**. It does NOT:

- Change the schema (`project_profile.schema.json` stays at 1.1.0).
- Change the init CLI (`init_project_runtime.py` keeps its v4.90.9
  derive-default behaviour).
- Add new fast-gate items (no F21).
- Add new invariants (no inv_012).
- Cut a release tag (per MEMORY contract #16, P7 commits + manifest sync only).

P7 ships only:

- `docs/26_dual_phase/README.md` (this file).
- `docs/26_dual_phase/DECISION_MATRIX.md` (the 7×7 cell table).
- `docs/26_dual_phase/WORKFLOW_GUIDE.md` (adoption walkthrough).
- `inv_002` trigger glob extension to cover the new doc root.
- `LAYER_1_ROOTS` extension to cover the new doc root.
- `RELEASE_MANIFEST.json` sync via the canonical rebuilder path.

## 7. Cross-references

- v4.90.9 patch notes: `RELEASE_NOTES.md` § "v4.90.9 — B-CG closed: fast/full closure gate split + PG-safe runner extraction + game-dev phase split (2026-05-17)".
- Earlier mention in `docs/MANIFEST_HISTORY.md` and
  `docs/13_migration/PROJECT_INIT_GUIDE.md` (which describes the
  init-time defaulting from `--stage` to `game_dev_phase`).
- Sister docs:
  - [`DECISION_MATRIX.md`](DECISION_MATRIX.md)
  - [`WORKFLOW_GUIDE.md`](WORKFLOW_GUIDE.md)
