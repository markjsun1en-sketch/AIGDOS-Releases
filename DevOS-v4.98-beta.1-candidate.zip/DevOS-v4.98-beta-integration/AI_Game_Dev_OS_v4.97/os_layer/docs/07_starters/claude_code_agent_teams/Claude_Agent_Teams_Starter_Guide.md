# Claude Code Agent Teams Starter Guide

## Purpose
This starter is for the experimental Claude agent-teams profile.

## Startup sequence
1. select `claude_code_agent_teams`,
2. read shared startup docs,
3. read team profile docs,
4. install lead/teammate startup files,
5. define cleanup and quality-gate ownership,
6. begin with a small number of teammates.

## Expected files
- `CLAUDE.md.template`
- `TEAM_BOOT_GUIDE.md`
- `HOOKS.template.json`
- `DEFAULT_LOADSET.json`

## Warning
Do not use this starter just because it feels more powerful. Use it only when teammate coordination is worth the extra governance overhead.

## See also
- `docs/USAGE_GUIDE.md §6` — authoritative three-step sprint close flow (`init_runtime_env.py` → `run_beta_sprint_check.py` → `verify_beta_sprint_exit.py`) + v4.89 maturity tier table (inherited from v4.88-stable B+ Bridge Hardening line).
