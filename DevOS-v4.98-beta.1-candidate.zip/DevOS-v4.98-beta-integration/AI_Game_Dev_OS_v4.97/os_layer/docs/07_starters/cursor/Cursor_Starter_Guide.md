# Cursor Starter Guide

## Purpose
This guide describes how to start a project under the Cursor runtime profile in v4.89.

## Startup sequence
1. Select the `cursor` execution profile.
2. Load the shared startup docs.
3. Load the Cursor runtime profile docs.
4. install the Cursor starter files and project rules.
5. confirm the coordinator and merge/apply owner.
6. open the first bounded worktree-scoped task.

## Expected files
- `PROJECT_RULES.template.md`
- `BOOT_BLOCK.md`
- `DEFAULT_LOADSET.json`

## Operating assumptions
- parallel agents are allowed,
- isolated work surfaces are preferred,
- final apply/merge is serialized,
- external writeback is coordinator-owned.

## See also
- `docs/USAGE_GUIDE.md §6` — authoritative three-step sprint close flow (`init_runtime_env.py` → `run_beta_sprint_check.py` → `verify_beta_sprint_exit.py`) + v4.89 maturity tier table (inherited from v4.88-stable B+ Bridge Hardening line).
