# Starter Family Overview

> **Authority note (REV-5-011, 2026-04-22)**: this `shared/` version is a **summary / pointer doc**, not the canonical overview. The canonical overview lives at `docs/07_starters/Starter_Family_Overview.md` (one level up). The two files coexist for legacy compatibility; when they disagree, the canonical version wins. Future v4.89 may either delete this shorter version or rename it to `Starter_Family_Overview_Summary.md` per REV-5-011 original recommendation.

## Goal
4.88 no longer ships a single starter that assumes one agent runtime. Instead, it provides:
1. a shared starter layer for portable project assets
2. a runtime-specific starter overlay for execution behavior

## Shared Layer
The shared layer contains:
- project adaptation summary template
- must-override file list
- task / handoff / QA templates
- loadset model

## Runtime Overlays
Each runtime starter defines:
- boot entry file(s)
- context loading pattern
- worker launch pattern
- writeback owner
- cleanup expectations

## Selection Rule
Choose a runtime profile first, then choose the matching starter.
