# Agent Definition Template

Use this template when defining an agent for a runtime-specific starter or project adaptation layer.

## Sections

- Name / short name
- Layer / role class
- Purpose
- Primary responsibilities
- Inputs expected
- Outputs owned
- Write boundaries
- Explicit non-responsibilities
- Escalation path
- Validation / review expectations

## Rule

An agent definition should make it possible to answer:
- what this agent is for,
- what it may write,
- what it must not pretend to own,
- who reviews or receives its outputs.
