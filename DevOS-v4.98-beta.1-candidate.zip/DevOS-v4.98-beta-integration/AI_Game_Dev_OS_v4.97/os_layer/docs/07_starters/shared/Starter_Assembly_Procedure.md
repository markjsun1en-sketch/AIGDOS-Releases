# Starter Assembly Procedure

This document defines the canonical assembly path for building a new project starter from the 4.88 starter family.

## Inputs

A starter assembly requires five inputs:

1. project name / project identifier
2. selected runtime profile
3. TAPD workspace + sprint operating assumptions
4. Git branch / isolation policy
5. chosen Beta Sprint target scope

## Assembly sequence

### Phase 1 — Shared layer

Copy:

- PROJECT_ADAPTATION_SUMMARY.template.md
- TASK_TEMPLATE.yaml
- HANDOFF_TEMPLATE.yaml
- QA_GATE_TEMPLATE.yaml
- MUST_OVERRIDE_FILES.md

### Phase 2 — Runtime overlay

Copy exactly one of:

- Codex starter
- Cursor starter
- Claude Code Subagents starter
- Claude Code Agent Teams starter
- Workbuddy Private starter

### Phase 3 — Project override

Replace placeholders for:

- project_id
- runtime profile name
- external workspace IDs
- branch / worktree naming rule
- audit location
- Beta Sprint default profile

### Phase 4 — Validation

Run:

- validate_execution_profile.py
- validate_runtime_paths.py
- verify_required_content.py

### Phase 5 — Freeze

Tag the assembled starter as Sprint 0 / Beta Sprint input. Do not keep mutating the starter while the first execution cycle is in progress.

## Assembly anti-patterns

- Mixing two runtime overlays in one starter
- Leaving writeback ownership implicit
- Allowing starter files to inherit old version path references
- Treating starter assembly as equivalent to runtime initialization

## Output expectation

A completed starter assembly should be reviewable by another operator without guessing:

- what runtime is used
- who owns merge / cleanup / writeback
- how a new worker cold-starts
- how TAPD and Git expectations map into the starter
