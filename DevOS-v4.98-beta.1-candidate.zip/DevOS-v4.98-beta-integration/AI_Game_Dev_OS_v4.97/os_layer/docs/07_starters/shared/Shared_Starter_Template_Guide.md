# Shared Starter Template Guide

The shared starter layer contains the portable templates that every runtime-specific starter family must consume.

## Purpose

The shared starter layer exists so that task structure, handoff shape, QA gates, and project adaptation summaries remain stable even when the execution runtime changes.

## Shared artifacts

### PROJECT_ADAPTATION_SUMMARY.template.md

Used to declare:

- project type and scope
- chosen runtime profile
- chosen TAPD + Git operating assumptions
- must-override file decisions
- starter family chosen
- beta sprint target scope

### TASK_TEMPLATE.yaml

Used to define the smallest portable task shape. The runtime may attach additional execution fields, but the shared template owns:

- task identifier
- owner role / owner agent
- purpose
- acceptance criteria
- evidence expectation
- handoff expectation
- external sync requirement

### HANDOFF_TEMPLATE.yaml

Used to carry bounded, reviewable state between workers. It should remain smaller than a full task or design doc and must never become a substitute for Registry truth.

### QA_GATE_TEMPLATE.yaml

Used to define what “pass”, “conditional pass”, and “fail” mean for a checkpoint. The shared template is intentionally portable so project and runtime overlays can extend it without breaking downstream consumers.

### MUST_OVERRIDE_FILES.md

Used to stop teams from shipping a starter without updating project-specific identity, profile, paths, external workspace identifiers, and release markers.

## Assembly rule

A valid starter is always:

`shared starter templates + exactly one runtime starter overlay + project-specific overrides`

It is never valid to use a runtime starter without the shared templates.

## Typical flow

1. Pick runtime profile.
2. Copy shared starter files.
3. Copy one runtime-specific starter overlay.
4. Fill project adaptation summary.
5. Run path and profile validation.
6. Freeze starter for Sprint 0 / Beta Sprint.

## Review questions

- Has the runtime profile been selected explicitly?
- Are all must-override files actually overridden?
- Is the boot readset small enough for repeatable cold start?
- Do task, handoff, and QA templates agree on evidence model?
- Is the external writeback owner visible in starter docs?

## Non-goals

The shared starter layer should not encode tool-specific hooks, AGENTS entries, CLAUDE session wiring, or Workbuddy private semantics. Those belong to runtime overlays.
