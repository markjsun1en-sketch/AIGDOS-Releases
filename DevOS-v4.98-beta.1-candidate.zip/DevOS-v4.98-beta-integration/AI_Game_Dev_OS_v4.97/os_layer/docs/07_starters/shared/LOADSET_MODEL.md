# Loadset Model

## Purpose
A loadset defines the minimum context that should be loaded for a new project session.

## Layers
1. Portable Core Layer
2. Runtime Profile Layer
3. Project Layer
4. Active Sprint Layer

## Rules
- keep loadsets minimal by default
- runtime overlays only add environment-specific context
- project-specific docs should not duplicate portable core docs
- active sprint context should be swappable without editing the base loadset

## Recommended Keys
- profile
- core_docs
- runtime_docs
- project_docs
- sprint_docs
- optional_docs

## Density Variants (deferred, v4.89 note)

v4.8.2's Context Pack four-tier density model (LEAN / STANDARD / EXPANDED / FULL_REFERENCE) was not preserved in v4.88, and v4.89 (inheriting from v4.88_Revise) continues to reduce to a single `DEFAULT_LOADSET.json` per runtime profile without a density dimension. See `docs/12_release_notes/V4.87_to_V4.88_Upgrade_Notes.md` → Capability Deprecations for rationale.

Projects that need density tiers should author them at the project layer (e.g. `policy/default_loadset.json` + `policy/default_loadset.expanded.json`) and let their project bootstrap pick the right variant. The shared `LOADSET_MODEL.md` remains density-agnostic until v4.89 or later reconsiders.
