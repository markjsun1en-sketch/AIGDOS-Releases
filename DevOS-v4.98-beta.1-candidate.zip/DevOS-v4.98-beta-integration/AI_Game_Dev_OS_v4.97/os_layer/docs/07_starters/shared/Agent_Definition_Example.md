# Agent Definition Example

## Example: Orchestrator / Control Agent

- **Layer**: orchestration / control
- **Purpose**: route work, manage scope, supervise execution flow
- **Primary responsibilities**:
  - task routing
  - control ownership
  - sprint coordination
  - escalation and handoff management
- **Outputs owned**:
  - routing decisions
  - control summaries
  - coordination records
- **Does not own**:
  - downstream specialist deliverables
  - final implementation truth
  - automatic external writeback unless profile allows it
- **Escalation path**:
  - to EP / user / lead owner when scope or ownership is unclear

## Why this matters

This example shows the difference between **control authority** and **production authority**.
The router of work is not automatically the rightful author of specialist outputs.
