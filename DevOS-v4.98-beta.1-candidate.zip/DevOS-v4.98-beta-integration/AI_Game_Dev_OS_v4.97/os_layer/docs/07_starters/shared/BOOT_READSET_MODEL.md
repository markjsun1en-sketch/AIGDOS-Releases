# Boot Readset Model

## Minimum Readset
Every new worker/session should read:
- START_HERE / overview
- execution profile selection
- selected runtime profile rule loading doc
- TAPD baseline
- Git workflow baseline
- project adaptation summary

## Runtime-Specific Additions
The selected runtime starter may add:
- AGENTS.md or CLAUDE.md or rules file
- hook configs
- worker launch guide
- cleanup SOP
