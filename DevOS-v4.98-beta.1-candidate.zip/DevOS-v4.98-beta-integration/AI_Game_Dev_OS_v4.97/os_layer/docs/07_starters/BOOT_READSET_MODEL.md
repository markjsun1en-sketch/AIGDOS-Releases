# Boot Readset Model

## Purpose
The boot readset defines the minimum files a runtime should load before productive work begins. Its goal is to reduce context drift and prevent giant cold-start prompts.

## Shared boot readset
Every runtime should begin from:
- `START_HERE.md`
- `EXECUTION_PROFILE_SELECTION.md`
- `CORE_OS_DIGEST.md`
- selected runtime profile guide
- selected starter guide

## Task readset
After the shared readset, add only the task-scoped files required for the current sprint wave.

## Deep reference set
Everything else belongs to deep reference and should be pulled only on demand.

## Review rule
If the boot readset grows large enough that a new worker cannot explain it briefly, the readset is too large.
