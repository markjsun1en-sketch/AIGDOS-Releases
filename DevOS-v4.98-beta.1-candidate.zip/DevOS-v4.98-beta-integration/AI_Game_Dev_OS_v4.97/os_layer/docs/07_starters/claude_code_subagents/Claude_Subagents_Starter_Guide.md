# Claude Code Subagents Starter Guide

## Purpose
This starter is for the Claude profile that uses subagents, not agent teams.

## Startup sequence
1. select `claude_code_subagents`,
2. read shared startup docs,
3. read Claude subagent runtime docs,
4. install CLAUDE and HOOK templates,
5. define bounded subagent task packets,
6. confirm main-agent ownership of writeback.

## Expected files
- `CLAUDE.md.template`
- `SUBAGENTS.template.md`
- `HOOKS.template.json`
- `DEFAULT_LOADSET.json`

## Operating assumptions
- subagents are task-scoped,
- hooks enforce gates,
- worktree isolation is preferred,
- cleanup and writeback stay with the main agent.

## See also
- `docs/USAGE_GUIDE.md §6` — authoritative three-step sprint close flow (`init_runtime_env.py` → `run_beta_sprint_check.py` → `verify_beta_sprint_exit.py`) + v4.89 maturity tier table (inherited from v4.88-stable B+ Bridge Hardening line).
