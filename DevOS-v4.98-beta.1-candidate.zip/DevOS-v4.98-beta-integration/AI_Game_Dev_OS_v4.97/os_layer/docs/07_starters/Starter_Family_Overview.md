# Starter Family Overview

## Purpose
v4.89 does not ship a single universal starter. It ships a **starter family** because runtime semantics differ enough that the startup layer must reflect them.

## Shared layer
All starters inherit from the shared starter layer:
- adaptation summary template,
- task / handoff / QA templates,
- boot readset model,
- must-override list,
- loadset model.

## Runtime-specific layer
Each runtime then adds its own startup contract:
- Codex starter -> AGENTS-based startup, subagent/worktree assumptions.
- Cursor starter -> rules-based startup, worktree/parallel-agent assumptions.
- Claude subagents starter -> CLAUDE + hooks + bounded subagent packet assumptions.
- Claude teams starter -> lead/teammate startup and quality-gate assumptions.
- Workbuddy private starter -> project-specific team-mode assumptions.

## Selection rule
Choose the starter that matches the selected execution profile. Do not mix starter/runtime pairs unless you are performing an explicit adaptation experiment.

## Minimal success condition
A starter is only valid if a new worker can answer these questions immediately:
- what runtime am I in,
- what may I edit,
- who owns final writeback,
- how do I hand work back,
- where do I look first if things go wrong.
