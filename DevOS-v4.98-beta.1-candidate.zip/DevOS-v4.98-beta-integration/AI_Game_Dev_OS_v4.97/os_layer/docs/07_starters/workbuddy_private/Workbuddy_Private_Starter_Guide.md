# Workbuddy Private Starter Guide

## Purpose

This starter preserves Workbuddy-derived project practice without projecting those semantics onto the portable core.

## What makes this starter specific

In the Workbuddy private path, `AGENTS.md` is an active startup artifact, not just a background reference.
The same is true for companion files such as `SKILLS.md`, task execution rules, workflow rules, and re-entry guidance.

## Startup sequence

1. select `workbuddy_private`
2. read shared startup docs
3. read the private Workbuddy runtime docs
4. load project-facing execution files (`AGENTS.md`, `SKILLS.md`, execution/workflow rules)
5. install team-mode boot files
6. confirm proxy-sync and dirty-state recovery ownership
7. start with limited team fan-out

## Expected files

- `TEAM_BOOT_GUIDE.md`
- `TEAM_RULES.template.md`
- `DEFAULT_LOADSET.json`
- `AGENTS.md.template`
- `SKILLS.md.template`
- `RE_ENTRY_CHECKLIST.md`

## Warning

This starter is intentionally private. It should not be chosen for new cross-runtime baselines unless you are intentionally preserving existing Workbuddy-specific workflow behavior.

## See also
- `docs/USAGE_GUIDE.md §6` — authoritative three-step sprint close flow (`init_runtime_env.py` → `run_beta_sprint_check.py` → `verify_beta_sprint_exit.py`) + v4.89 maturity tier table (inherited from v4.88-stable B+ Bridge Hardening line).
