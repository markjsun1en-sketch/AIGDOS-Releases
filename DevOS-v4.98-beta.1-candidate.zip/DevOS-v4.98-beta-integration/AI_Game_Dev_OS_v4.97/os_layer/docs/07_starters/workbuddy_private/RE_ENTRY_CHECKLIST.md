# Workbuddy Private Re-Entry Checklist

Use this checklist when resuming a Workbuddy-style project after interruption.

- confirm selected runtime profile is still `workbuddy_private`
- verify current control owner
- reload `AGENTS.md`
- reload `SKILLS.md`
- reload current workflow / task execution rules
- inspect task/registry state for drift
- confirm proxy-sync status before resuming external writeback
- resume through controlled fan-out, not ad-hoc continuation
