# Codex Starter Guide

## Purpose
This guide describes how to start a project under the Codex runtime profile in v4.89.

## Startup sequence
1. Confirm the execution profile is `codex`.
2. Read the shared startup docs.
3. Read the Codex runtime profile docs.
4. Install or copy the Codex starter files.
5. Confirm worktree and writeback policy.
6. Begin with a bounded task packet.

## Expected files
- `AGENTS.md.template`
- `BOOT_BLOCK.md`
- `DEFAULT_LOADSET.json`

## Operating assumptions
- parent session owns orchestration,
- subagents are bounded,
- worktrees isolate edits,
- merge and TAPD writeback stay centralized.

## Trial advice
For the first Beta Sprint, do not optimize for maximum autonomy. Optimize for clarity, reproducibility, and clean evidence.

## See also
- `docs/USAGE_GUIDE.md §6` — authoritative three-step sprint close flow (`init_runtime_env.py` → `run_beta_sprint_check.py` → `verify_beta_sprint_exit.py`) + v4.89 maturity tier table (inherited from v4.88-stable B+ Bridge Hardening line).
