# Starter Review Checklist

Use this checklist when reviewing whether a starter is ready for real use.

## Core checks
- Does the starter clearly declare its runtime profile?
- Does it point to the shared boot readset?
- Does it state writeback ownership?
- Does it define cleanup ownership?
- Does it include merge/apply discipline?
- Does it map to the shared task/handoff/QA templates?

## Runtime checks
- Codex: AGENTS entry and worktree discipline are explicit.
- Cursor: rules and parallel-agent boundaries are explicit.
- Claude subagents: hook expectations and bounded packets are explicit.
- Claude teams: lead/teammate responsibilities are explicit.
- Workbuddy: private-profile limitations are explicit.

## Trial readiness
A starter is trial-ready only if it can be used by a new worker without referring back to old batch notes.
