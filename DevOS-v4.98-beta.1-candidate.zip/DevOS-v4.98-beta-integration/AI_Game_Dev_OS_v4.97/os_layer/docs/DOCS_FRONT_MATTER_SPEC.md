# DOCS_FRONT_MATTER_SPEC.md — Optional YAML front-matter for v4.90 docs

> **Layer**: root-level documentation (NOT under any
> `docs/<NN>_*` Layer 1 governance directory). Pinned at
> v4.90 Batch 14 Step 14.9.
>
> **Status**: optional convention. Documents without front-matter
> are still valid; only those that *opt in* by declaring an
> opening `---` block must conform to this spec.

---

## 1. Mandate

Some documents in `AI_Game_Dev_OS_v4.90/docs/**` and root-level
`*.md` files want machine-readable metadata so tooling can:

- Surface which OS layer a doc belongs to (Layer 1 OS Spec vs
  Layer 2 case study vs root-level meta).
- Cross-reference protected behavior invariants
  (`runtime/protected_contracts/protected_regression_matrix.yaml`)
  that the doc helps preserve, so contributors editing the doc
  know which regressions they are touching.
- Render compact doc indexes without relying on title regex.

This spec defines the field set and sample format. The
`scripts/lint/check_docs_front_matter.py` lint validates conformance
**only on docs that opt in within the scoped scan area**: every
`*.md` under `docs/**` plus root-level meta files (`CHANGELOG.md`,
`README.md`, `V4_90_README.md`, `RELEASE_NOTES*.md`). Other tracked
markdown files (e.g. `agent_packs/*.md`, `ltm/failures/*.md`,
`runtime/*.md`, `proposals/*.md`) carry their own domain front-matter
schemas (pack schema, failure-fix schema, …) and are out of scope.
There is no requirement that every doc carry front-matter.

---

## 2. Structure

A document opts in by starting with a YAML block delimited by `---`
on the very first line and a closing `---` line, followed by the
usual markdown content:

```markdown
---
title: State Machines Index
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: 14.6
protected_invariants:
  - inv_003_state_machine_doc_schema_aligned
---

# State Machines Index — v4.90

...rest of the document...
```

The `---` opening delimiter MUST be on line 1 (no blank line,
no BOM). The closing `---` MUST be on its own line. Anything
between is parsed as YAML by `_yaml_subset` (the same zero-dep
loader used elsewhere in v4.90).

---

## 3. Fields

| Field | Required | Type | Description |
|---|---|---|---|
| `title` | yes | string | Short human-readable title (≤ 80 chars). Should match the H1 in the body. |
| `version` | yes | string | Doc revision (e.g. `1.0`, `2.1`). Bumped only on breaking content change. |
| `status` | yes | string | One of `active`, `draft`, `deprecated`, `closed`. |
| `layer` | yes | string | One of `layer_1_os_spec`, `layer_2_case_study`, `root_meta`. Layer 1 docs are subject to lint_layer_separation; Layer 2 docs are case studies (project names allowed); root_meta is RELEASE_NOTES / CHANGELOG / MANIFEST_HISTORY style. |
| `since_batch` | yes | string | First batch ID where this doc reached its current shape (e.g. `14.6`, `14.8`). |
| `protected_invariants` | optional | list[string] | List of invariant IDs from `runtime/protected_contracts/protected_regression_matrix.yaml` that this doc helps preserve. Each ID must match `^inv_\d{3}_[a-z0-9_]+$`. Omit the field if no invariant applies. |

`additionalProperties` is **rejected** by the lint — only the six
fields above may appear. This keeps front-matter from sprawling
into ad-hoc metadata.

---

## 4. Examples

### Layer 1 OS Spec doc with one protected invariant

```yaml
---
title: State Machines Index
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: 14.6
protected_invariants:
  - inv_003_state_machine_doc_schema_aligned
---
```

### Layer 2 case study, no protected invariants

```yaml
---
title: V4.89 Reference Audit
version: 1.0
status: closed
layer: layer_2_case_study
since_batch: 14.4
protected_invariants:
  - inv_004_no_v4_89_active_stale_in_v4_90
---
```

### Root-level meta doc (changelog style)

```yaml
---
title: MANIFEST_HISTORY
version: 1.0
status: active
layer: root_meta
since_batch: 14.7
protected_invariants:
  - inv_007_schema_version_const_locked
---
```

---

## 5. Authoring guidance

- Add front-matter only when there is a real consumer (lint, doc
  index, cross-reference test). Don't add it preemptively.
- When you list a `protected_invariants` ID, the test
  `tests/governance/test_docs_front_matter.py` will cross-check
  that the ID exists in the active invariants registry. Removing
  an invariant from the registry without updating the doc fails
  the gate.
- `version` is the **doc** version, not a software version.
- `layer` should match the directory: docs under
  `docs/13_migration/`, `docs/14_state_surface_governance/` (excluding
  `STATE_SURFACE_MIGRATION_CASE_*.md`), `docs/15_ltm_v2/`, and the
  other Layer 1 roots are `layer_1_os_spec`. Migration case studies
  are `layer_2_case_study`. Root-level docs are `root_meta`.

---

## 6. How to add front-matter to an existing doc

1. Open the doc.
2. Insert a YAML block as the first 7-8 lines (per §2 / §4).
3. Ensure the H1 title in the body matches the `title:` field
   (or is at least a superset — minor decoration in the H1 like
   "— v4.90" is fine, the lint tolerates it).
4. Run `python3 scripts/lint/check_docs_front_matter.py` to
   confirm conformance.
5. If the doc declares any `protected_invariants` IDs, run
   `python3 -m pytest tests/governance/test_docs_front_matter.py -q`
   to confirm the cross-check passes.
