# UI Review Gate Contract

Gate result: PASS, PASS_WITH_FIXES, or FAIL. Require screenshot, wireframe, implementation scene, low-resolution check, or state variant review as evidence.
