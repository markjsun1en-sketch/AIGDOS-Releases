# Godot UI Handoff Contract

A Godot UI handoff must include scene path, scene tree, node responsibilities, data model, signals, assets, theme resources, anchors/containers, states, and tests.
