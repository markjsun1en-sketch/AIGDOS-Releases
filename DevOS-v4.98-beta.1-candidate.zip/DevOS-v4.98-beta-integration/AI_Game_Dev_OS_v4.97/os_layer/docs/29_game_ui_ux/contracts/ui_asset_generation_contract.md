# UI Asset Generation Contract

Reject generated UI assets if they contain unwanted text, fake transparency checkerboard, too much noise, ambiguous silhouette, baked runtime values, or cropped important edges.
