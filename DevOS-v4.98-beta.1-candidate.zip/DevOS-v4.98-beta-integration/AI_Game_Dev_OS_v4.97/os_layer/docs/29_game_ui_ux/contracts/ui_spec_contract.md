# UI Spec Contract

A valid UI spec includes screen role, platform, resolution, hierarchy, components, zones, state variants, runtime text, assets, implementation notes, and acceptance checklist. It is incomplete if it only describes visual style.
