# Example: Screen Alpha — Battle HUD Spec

Top center: turn/wave summary. Center-left: protagonist actor with status chips above head. Center-right: enemies with HP and intent. Lower-left: HP 68/68, block, energy pips, consumables. Lower center/right: 5-card hand dock. Right side: End Turn and Ultimate.

Risk notes: avoid placing statuses inside resource area; keep enemy intent distinct from status; preserve actor silhouette; avoid decorative noise behind card text.
