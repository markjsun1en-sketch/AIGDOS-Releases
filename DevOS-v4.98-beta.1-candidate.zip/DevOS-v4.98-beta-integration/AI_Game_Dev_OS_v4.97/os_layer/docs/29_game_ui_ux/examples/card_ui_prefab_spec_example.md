# Example: 2:3 Attack Card Prefab

Source art 1024x1536. Hand display 180x270. Layout: cost badge, type chip, two-line title, illustration slot, keyword strip, effect panel. Cost/name/effect are rendered by engine, not baked into art.
