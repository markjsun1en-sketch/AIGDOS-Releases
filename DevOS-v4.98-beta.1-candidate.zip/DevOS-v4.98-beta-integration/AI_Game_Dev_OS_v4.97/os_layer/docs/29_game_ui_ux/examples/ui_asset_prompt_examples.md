# UI Asset Prompt Examples

Enemy intent icon: transparent PNG, true alpha, 1024x1024, readable at 48x48, attack silhouette, no text, no numbers, no fake checkerboard.

Card frame: vertical 2:3 reusable card frame, reserved cost/type/title/art/keyword/effect zones, no baked text, calm text zones, transparent PNG.
