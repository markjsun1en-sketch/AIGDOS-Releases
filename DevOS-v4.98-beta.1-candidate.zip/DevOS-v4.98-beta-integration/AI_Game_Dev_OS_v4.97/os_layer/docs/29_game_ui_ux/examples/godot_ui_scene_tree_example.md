# Example: Godot Battle UI Scene Tree

```text
BattleUIScreen.tscn
  CanvasLayer
    ControlRoot
      SafeAreaMargin
        TopBar
        ActorOverlay
        BottomHUD
          PlayerResourcePanel
          CardDock
          ActionPanel
        TooltipLayer
        ModalLayer
```
