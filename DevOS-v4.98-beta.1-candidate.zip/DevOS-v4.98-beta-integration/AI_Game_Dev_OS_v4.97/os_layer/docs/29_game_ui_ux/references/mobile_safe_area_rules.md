# Mobile and Multi-Aspect Safe Area Rules

Check 16:9, 16:10, 19.5:9, and tablet if relevant. Avoid critical UI under notches, OS bars, bottom gesture zones, and unreachable corners. Define card dock compression, status overflow, and text scaling.
