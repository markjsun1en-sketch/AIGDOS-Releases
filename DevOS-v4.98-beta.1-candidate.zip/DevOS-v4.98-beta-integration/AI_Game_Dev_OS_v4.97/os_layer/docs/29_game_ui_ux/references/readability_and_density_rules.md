# Readability and Density Rules

Readability includes size, contrast, spacing, silhouette, grouping, and motion. Test at target size, 75%, 50%, and thumbnail if icons/cards are involved. Keep text panels calm and low-noise.
