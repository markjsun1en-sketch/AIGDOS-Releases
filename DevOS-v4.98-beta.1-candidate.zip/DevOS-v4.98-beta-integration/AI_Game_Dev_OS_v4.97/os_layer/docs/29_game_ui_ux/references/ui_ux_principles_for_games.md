# UI/UX Principles for Games

Game UI supports decisions. It must show current state, available choices, consequences, threat, reward, and progression.

Common failures: too many equally bright elements, status icons that look like buttons, enemy intent mixed with statuses, card art competing with text, HUD blocking actor silhouettes, no text overflow plan, no disabled/selected states.

Ask: What decision is the player making? What must be clear in one second? What can move to tooltip? What must survive downscale?
