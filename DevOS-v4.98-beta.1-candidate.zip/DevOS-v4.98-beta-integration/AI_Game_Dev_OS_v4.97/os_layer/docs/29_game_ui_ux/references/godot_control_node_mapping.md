# Godot Control Node Mapping

Control root, CanvasLayer for UI over gameplay, MarginContainer for safe area, HBox/VBox/GridContainer for repeatable layout, TextureRect for icons, Label/RichTextLabel for text, Button/TextureButton for actions, Theme for shared style.
