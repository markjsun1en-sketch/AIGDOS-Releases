# UI Asset Image Prompt Constraints

Specify asset type, size, style, background/alpha, text rules, safe padding, and downscale readability. Baseline negative: no text, letters, numbers, watermark, fake checkerboard, excessive particles, noisy microtexture.
