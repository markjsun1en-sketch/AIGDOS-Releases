# Card Battle UI Layout Rules

A card battle screen must answer: Am I safe? What will enemies do? What can I afford? Which cards are playable? What happens if I play this card? What ends my turn?

Recommended zones: top summary; center actors; player status above actor; enemy intent above enemies; lower-left resources; lower-center/right card dock; right-side action buttons.
