# Game UI Design Tokens Guide

Use semantic tokens: color.text.primary, color.status.danger, color.resource.energy, spacing.md, shape.radius.card, component.card.frame.default. Separate type, rarity, resource, and status colors.
