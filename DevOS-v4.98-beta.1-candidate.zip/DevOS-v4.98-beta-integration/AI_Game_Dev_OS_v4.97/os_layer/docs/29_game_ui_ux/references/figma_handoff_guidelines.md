# Figma Handoff Guidelines

Recommended pages: 00_Cover, 01_Foundations, 02_Components, 03_Screens, 04_States, 05_Prototype, 06_Export, 99_Archive. Export icons and frames separately. Avoid baked runtime text.
