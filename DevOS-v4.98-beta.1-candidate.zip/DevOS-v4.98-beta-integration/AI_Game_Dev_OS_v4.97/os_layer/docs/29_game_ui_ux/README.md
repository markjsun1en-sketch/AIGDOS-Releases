# docs/29_game_ui_ux/

> **v4.91 Milestone H — Creative Cluster Pack Documentation (sub-domain 2)**
> **Authority**: pack ledger `agent_packs/ap_2026_006_creative_cluster.md`
> **Activation**: capability_promotion `proposals/evo_2026_003_creative_cluster_uiux_subdomain.md`
> **Layer 1 (OS Spec)** — content here is generic across projects; specific adopting-project names stay in workspace `MEMORY.md`.

## Role

Provides the documentation surface for the v4.91 second creative_cluster
sub-domain — 8 skills covering game UI/UX design and handoff. The pack
ledger (`agent_packs/ap_2026_006_creative_cluster.md`) carries gate
authority across both sub-domains; the skills
(`skills/_generic_core/game_ui/` × 6 +
`skills/_generic_core/qa/game-ui-ux-auditor` +
`skills/_engine_specific/godot/godot-ui-implementation-planner`)
carry actionable content; this directory carries shared references,
templates, examples, contracts, and the cross-project provenance
record.

## Layout

```
docs/29_game_ui_ux/
├── README.md                              # this file
├── AGENT_PACK_OVERVIEW.md                 # pack adoption guide for projects
├── AI_LIMITATIONS_AND_HUMAN_GATE.md       # what AI can / cannot do; mandatory human gates
├── CROSS_PROJECT_PROMOTION_LESSONS.md     # methodology of L2 → L1 abstraction
├── provenance.yaml                        # provenance metadata (Layer 1 generic)
├── references/                            # 8 reference docs (rules + checklists)
│   ├── card_battle_ui_layout_rules.md
│   ├── figma_handoff_guidelines.md
│   ├── game_ui_design_tokens_guide.md
│   ├── godot_control_node_mapping.md
│   ├── image_prompt_constraints.md
│   ├── mobile_safe_area_rules.md
│   ├── readability_and_density_rules.md
│   └── ui_ux_principles_for_games.md
├── templates/                             # 8 output templates (7 .md + 1 .json)
│   ├── battle_hud_spec.template.md
│   ├── card_prefab_spec.template.md
│   ├── design_system_tokens.template.json
│   ├── figma_handoff.template.md
│   ├── godot_ui_implementation_plan.template.md
│   ├── ui_asset_prompt.template.md
│   ├── ui_audit_report.template.md
│   └── wireframe_spec.template.md
├── examples/                              # 4 worked examples
│   ├── card_ui_prefab_spec_example.md
│   ├── godot_ui_scene_tree_example.md
│   ├── screen_alpha_battle_hud_spec_example.md   # sanitised filename
│   └── ui_asset_prompt_examples.md
└── contracts/                             # 4 runtime governance docs
    ├── godot_ui_handoff_contract.md
    ├── ui_asset_generation_contract.md
    ├── ui_review_gate_contract.md
    └── ui_spec_contract.md
```

## Workflow map

### Battle screen workflow (recommended starting point)

```
Input: GDD / combat loop / target platform
  ↓ game-ui-wireframe-generator        (low-fidelity zone map)
  ↓ battle-hud-designer                 (battle HUD spec)
  ↓ card-ui-prefab-spec                 (card prefab spec)
  ↓ game-design-system-builder          (design tokens)
  ↓ ui-asset-prompt-engineer            (icon / frame / panel prompts)
  ↓ godot-ui-implementation-planner     (Godot Control tree + Theme)
  ↓ figma-handoff-spec                  (developer-ready handoff)
  ↓ game-ui-ux-auditor                  (QA gate)
  ↓ Fix handoff (back to battle-hud-designer or card-ui-prefab-spec)
```

### Audit workflow (for existing screens)

```
Input: UI screenshot / mockup / Godot preview
  ↓ game-ui-ux-auditor                  (issue table + severity)
  ↓ Fix handoff (to relevant designer skill)
```

### Tokens-first workflow

```
Input: brand mood + target platform
  ↓ game-design-system-builder          (tokens + component rules)
  ↓ game-ui-wireframe-generator         (apply tokens to layout)
  ↓ battle-hud-designer / card-ui-prefab-spec  (sub-screen specs)
  ↓ figma-handoff-spec
```

## When to use this pack

- The user / task asks for game UI screens, battle HUDs, card prefabs,
  design tokens, Figma handoff specs, Godot UI Control trees, mobile
  safe-area-aware layouts, or UI asset prompts.
- The target is card-battle, RPG, roguelike, mobile game, prototype,
  or vertical slice.
- The work touches runtime UI elements that consume game state
  (cost, HP, status, intent, inventory) rather than purely static
  marketing screens.

## When NOT to use this pack

- The task is web / desktop tool UI without game-state binding —
  prefer `skills/_generic_core/uiux/` (6 abstract UI flow primitives)
  instead.
- The asset is purely promotional (key art, splash screen) — out of
  scope; route to general image-generation guidance.
- The task requires real-time animation rigs (skinned characters,
  spine animations) — route to the v4.91 M-G animation sub-domain
  (`docs/28_2d_character_animation/`).

## Hard boundary (Charter alignment)

Do NOT bake runtime-mutable text into generated UI art. Always
identify:

- screen role and assumptions;
- target platforms and resolutions;
- screen zones and information hierarchy;
- runtime text zones (separate from baked art);
- state variants (default / hover / pressed / disabled / insufficient
  resource / etc.);
- safe areas and anchors;
- engine implementation constraints;
- acceptance criteria for QA.

For card battle screens, prefer screens that read clearly under
gameplay pressure over visually dense compositions. See
`AI_LIMITATIONS_AND_HUMAN_GATE.md` for the full list of human gates.

## References

- Pack ledger: `agent_packs/ap_2026_006_creative_cluster.md`
- Capability promotion: `proposals/evo_2026_003_creative_cluster_uiux_subdomain.md`
- Animation sibling sub-domain: `docs/28_2d_character_animation/`
- Animation capability promotion: `proposals/evo_2026_002_creative_cluster_role_aliasing.md`
- Skill content: `skills/_generic_core/game_ui/` (6) + `skills/_generic_core/qa/game-ui-ux-auditor/` + `skills/_engine_specific/godot/godot-ui-implementation-planner/`
- Schemas: `schemas/uiux/` — ui_screen_spec, card_prefab_spec, ui_design_tokens, ui_asset_prompt (all 1.0.0)
- Validator scripts: `scripts/uiux/`
- Skills tree convention: `skills/README.md` §1
- Cluster taxonomy: `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` § 6 creative_cluster
- Generic abstract UI/UX (sibling, non-game): `skills/_generic_core/uiux/`
