# Agent Pack Overview — Creative Cluster (Game UI/UX)

> **v4.91 Milestone H** — second creative_cluster sub-domain adoption guide.
> **Pack ledger**: `agent_packs/ap_2026_006_creative_cluster.md` (16 skills total post-M-H)
> **Sibling sub-domain**: `docs/28_2d_character_animation/AGENT_PACK_OVERVIEW.md` (animation, M-G)

## What this sub-domain is

A coordinated set of 8 skills + 8 references + 8 templates + 4
examples + 4 runtime contracts + 4 schemas + 3 scripts that together
turn a fragile one-shot AI task ("design me a card battle screen")
into a gated production pipeline with explicit human gates,
evidence-driven acceptance, and engine-specific implementation
plans.

The 8 skills compose the same `{design, implementation, validation}`
role primitives as the M-G animation sub-domain, sharing the
`creative_cluster` exemption surface via the `evo_2026_003`
capability_promotion proposal (an additional authorising id alongside
the M-G `evo_2026_002`).

## What this sub-domain is NOT

- **NOT an auto-designer.** No skill promises to take a one-line
  brief and emit a finished battle HUD. Each skill produces a
  *spec*; humans (or downstream tools the project chooses) iterate
  on the spec before implementation.
- **NOT a closure-gate replacement.** `game-ui-ux-auditor` produces
  an advisory report. Final gameplay-readiness sign-off is a separate
  human decision per Charter anti-pattern #11.
- **NOT a code generator.** `godot-ui-implementation-planner` produces
  scene-tree plans, Theme/StyleBox lists, and signal/binding
  checklists — not GDScript. The implementation step itself remains
  the project's authority.
- **NOT a runtime text baker.** `ui-asset-prompt-engineer` writes
  prompts that explicitly forbid baked card cost numbers, card names,
  effect text, ability descriptions, or other runtime-mutable text
  inside generated images. inv_014 (M-H c4) enforces this at
  compile-time on the prompts and templates.

## Pack composition (sub-domain 2 — game UI/UX)

| Skill | Role primitive | Location |
|---|---|---|
| game-ui-wireframe-generator | design | `skills/_generic_core/game_ui/` |
| battle-hud-designer | design | `skills/_generic_core/game_ui/` |
| card-ui-prefab-spec | design | `skills/_generic_core/game_ui/` |
| game-design-system-builder | design | `skills/_generic_core/game_ui/` |
| figma-handoff-spec | design | `skills/_generic_core/game_ui/` |
| ui-asset-prompt-engineer | implementation | `skills/_generic_core/game_ui/` |
| godot-ui-implementation-planner | implementation | `skills/_engine_specific/godot/` |
| game-ui-ux-auditor | validation | `skills/_generic_core/qa/` |

Five `design` skills + two `implementation` skills + one
`validation` skill. The cross-cluster role aliasing is authorised by
`proposals/evo_2026_003_creative_cluster_uiux_subdomain.md` (or the
sibling `evo_2026_002` — either authorises the same exemption
surface per the M-H c0 widened registry).

## Adoption recipe

### 1. Confirm scope

Ask the producer / EP:

- Which screen genres? (battle / map / collection / shop /
  deck-builder / settings)
- Which engine? (Godot is fully supported via
  `godot-ui-implementation-planner`; Unity / Unreal get
  planning-only output from the design skills, no engine-specific
  implementer)
- Which target platforms? (mobile / desktop / multi-aspect — the
  spec MUST declare this; safe-area rules differ across platforms)
- Are there existing tokens or design system constraints? (use
  `game-design-system-builder` first to ratify or extend them)

### 2. Read the limits

Read `AI_LIMITATIONS_AND_HUMAN_GATE.md` end-to-end. Every gate listed
there is a real production failure mode if skipped — particularly
the runtime text gate, the safe-area gate, and the state-coverage
gate.

### 3. Pick a workflow

See README.md "Workflow map". For card-battle screens, start with
the battle screen workflow (wireframe -> battle HUD -> card prefab
-> tokens -> prompts -> Godot plan -> Figma handoff -> audit). For
existing screens, skip to the audit workflow.

### 4. Run the skills sequentially

Do NOT pipe all 8 skills in a single AI request. Each skill produces
a spec that needs human review before the next runs. The sub-domain
is explicitly gated.

### 5. Use the templates

Every skill emits to one of the templates under `templates/`. Diff
the AI output against the template structure to confirm completeness
before proceeding to the next gate. Templates use a flat
`*.template.md` / `*.template.json` naming convention.

### 6. Audit before integration

Run `game-ui-ux-auditor` against the in-engine output (a Godot
preview, mockup screenshot, or interactive prototype). Resolve all
*Blocker* and *Major* issues before merging into the project's
canonical screen set.

## Schema-backed surfaces (4)

| Schema | Consumer skill | Purpose |
|---|---|---|
| `schemas/uiux/ui_screen_spec.schema.json` | wireframe-generator + battle-hud-designer | Validate full screen spec shape (zones / components / states / acceptance) |
| `schemas/uiux/card_prefab_spec.schema.json` | card-ui-prefab-spec | Validate 2:3 card prefab layout (zones / state variants / rarity variants) |
| `schemas/uiux/ui_design_tokens.schema.json` | game-design-system-builder | Validate design tokens (color / typography / spacing / state) |
| `schemas/uiux/ui_asset_prompt.schema.json` | ui-asset-prompt-engineer | Validate prompt declarations (forbid_baked_text gate explicit) |

All schemas are `additionalProperties: false` + `schema_version`
const "1.0.0" + draft-07 + canonical host
`https://ai-dev-os.local/v4.91/schemas/uiux/<filename>`. Project-side
fixtures MUST use opaque `screen_alpha` / `card_alpha` /
`<screen_id>` / `<card_id>` tokens (Charter #2).

## Cross-references

- `agent_packs/ap_2026_006_creative_cluster.md` — pack ledger entry (16 skills post-M-H)
- `proposals/evo_2026_003_creative_cluster_uiux_subdomain.md` — capability promotion (UI/UX sub-domain)
- `proposals/evo_2026_002_creative_cluster_role_aliasing.md` — capability promotion (animation sub-domain; widened registry alt-id)
- `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` § 6 — cluster taxonomy (sub-domain table)
- `docs/16_agent_library/AGENT_ROLE_CATALOG.md` — 8 role primitives
- `docs/28_2d_character_animation/AGENT_PACK_OVERVIEW.md` — sibling animation sub-domain
- `docs/29_game_ui_ux/CROSS_PROJECT_PROMOTION_LESSONS.md` — provenance methodology (mirrors M-G version)
- `skills/README.md` § 1 — skills tree structure (game_ui category added v4.91 M-H)
