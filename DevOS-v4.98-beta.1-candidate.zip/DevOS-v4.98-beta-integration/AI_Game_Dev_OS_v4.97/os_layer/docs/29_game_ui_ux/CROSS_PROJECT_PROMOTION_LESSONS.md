# Cross-Project Promotion Lessons — Game UI/UX Sub-Domain

> **v4.91 Milestone H c3** — methodology record.
> Second documented L2 → L1 abstraction in the v4.91 OS Core.
> Layer 1 (OS Spec). No project literals. The specific adopting-project name lives in workspace `MEMORY.md`.

## Why this document exists

This is the second time the v4.91 OS Core has distilled an adopting
project's working pipeline into a creative_cluster sub-domain. The
first was the M-G animation sub-domain (see
`docs/28_2d_character_animation/CROSS_PROJECT_PROMOTION_LESSONS.md`).
This document records what changed in the second iteration: which
parts of the methodology survived intact, which parts were
refined, and what the M-H process specifically taught about
multi-sub-domain accumulation under a single seed pack.

Q5=B (EP decision, 2026-05-28) preserves the methodology
cross-reference pattern: the M-G sibling document remains the
canonical first reference, and this document layers M-H-specific
deltas on top rather than restating the full methodology.

## What carried over from M-G unchanged

The 5-stage extraction method (surface inventory / functional
decomposition / authority partition / sanitation / hardening)
applied identically to the UI/UX pipeline. Re-read the M-G doc for
the canonical method. Bullet checklist of items that worked exactly
the same way:

- The 4-condition triggering signal (≥2 completed rollouts +
  decomposable into ≥6 generic skills + EP signals reusability +
  no existing OS Core coverage) gated the M-H promotion the same
  way.
- The G / L / C tagging produced the same 80%+ G rate; only one
  example filename and one example body literal needed sanitising.
- The functional decomposition mapped 8 UI/UX skills onto the same
  `{design, implementation, validation}` primitive surface, again
  without inventing a new primitive.
- The 3-tier authority partition (gate authority -> agent_packs/;
  content -> skills/; methodology -> docs/) held intact.
- Schema hardening recipe (draft-07 + schema_version const "1.0.0"
  + additionalProperties=false + closed enums + canonical
  `ai-dev-os.local/v4.91/schemas/<group>/` host) ported directly.

## What M-H taught us beyond M-G

### Lesson 1 — Multi-sub-domain accumulation under one pack

M-G left an open question: "if/when a second creative_cluster pack
arrives (narrative, audio), can it inherit this exemption
automatically by listing evo_2026_002, or does each new sub-domain
need its own evidence record?"

M-H answered: **each new sub-domain emits its own
capability_promotion proposal, but the same single pack
accumulates skills.required[] and references[] entries.** The
validator's exemption registry is widened from a single proposal
id slot to a tuple of authorising proposal ids. A pack listing
*either* id satisfies the gate.

This avoids two failure modes:

- **One pack per sub-domain (rejected)**: would fragment the cluster
  into ap_2026_006 / ap_2026_007 / ... with each pack's
  references[] needing only one proposal. Cluster cohesion is lost;
  the validator can't tell whether two packs claiming
  creative_cluster are the same author or competing.
- **One omnibus proposal (rejected)**: would have evo_2026_002
  rewritten over time as each sub-domain joined. Proposal lifecycle
  becomes mutable; the audit trail granularity drops; future
  sub-domain-specific reasoning is hard to attribute.

The chosen pattern (one proposal per sub-domain + one shared pack +
widened registry) preserves both proposal append-only discipline
and pack cohesion.

### Lesson 2 — Schema host normalisation pays off

The M-G c3 schemas inherited the audit-normalised
`ai-dev-os.local/v4.91/` canonical host (Phase 3 audit on
2026-05-28 normalised 8 schemas across 3 groups). M-H c3 schemas
shipped directly with the canonical host on day 1 — no second-pass
normalisation needed.

Recommendation for future sub-domains: always start with the
canonical host. The audit work was a one-shot debt; new schemas
should not re-incur it.

### Lesson 3 — Generic-core category vs engine-specific split survives

M-G placed 6 SKILL.md in `_generic_core/animation/`, 1 in
`_generic_core/qa/animation-qa-auditor/`, and 1 in
`_engine_specific/godot/godot-2d-animation-implementer/`. M-H placed
6 SKILL.md in `_generic_core/game_ui/` (NEW category), 1 in
`_generic_core/qa/game-ui-ux-auditor/`, and 1 in
`_engine_specific/godot/godot-ui-implementation-planner/`.

The split is not arbitrary. The pattern: every sub-domain has
- one engine-specific implementation planner (engine name in path)
- one cross-cutting QA / auditor skill (joins existing qa/)
- the rest in a sub-domain-named generic-core category

When the next sub-domain (narrative? audio?) lands, it will likely
follow the same triple split. The engine-specific dir grows
linearly; the qa/ dir grows linearly; the generic-core gains one
new category per sub-domain.

### Lesson 4 — Generic vs game-domain category naming matters

The OS Core already had `skills/_generic_core/uiux/` (6 abstract
UI/UX flow primitives — component spec, flow definition,
information architecture, review, screen structure, visual
guideline binding). M-H needed to land game-specific UI/UX skills
without polluting that abstract category.

The decision (Q2=A): create a parallel `skills/_generic_core/game_ui/`.
The two categories sit side-by-side; `uiux/` covers software-UI
flows (settings panels, dashboards, tools), `game_ui/` covers
game-domain UI primitives (battle HUDs, card prefabs, runtime-safe
text zones, mobile safe areas).

Recommendation for future sub-domains: when an adjacent abstract
category exists, prefer a named-parallel category over nesting or
diluting the abstract one. The naming should make it obvious which
category applies for a given task.

### Lesson 5 — Pack-version semver is minor on sub-domain widening

M-G shipped ap_2026_006 at `pack_version: 0.1.0-beta` (initial
sub-domain). M-H bumped it to `0.2.0-beta` (second sub-domain
landed). Each sub-domain widens the pack's contract surface, so
the bump is minor not patch.

When a future sub-domain (3rd) lands, expect `0.3.0-beta`. The
pack is still pre-active (the lifecycle_state remains `draft`); the
1.0.0 promotion is reserved for the schema-wave unify-promote.

### Lesson 6 — Charter inv_013 / inv_014 patterns are reusable

Both invariants are compile-time gates that live in
`runtime/protected_contracts/protected_regression_matrix.yaml`,
both have parametrised tests under `tests/<sub-domain>/`, and both
focus on a sub-domain-specific failure mode (animation: no
auto-rig promise; UI/UX: no baked runtime text + spec-required
acceptance).

Recommendation for future sub-domains: every sub-domain SHOULD
ship its own invariant (inv_015, inv_016, ...) capturing its
specific Charter alignment. Re-using an existing invariant
defaults the sub-domain into a generic guard that misses the
sub-domain-specific failure mode.

## Triggering signal (carried from M-G)

The 4 conditions that gated M-H promotion are unchanged from M-G:

1. ≥2 completed character-rollouts / screen-rollouts.
2. Decomposable into ≥6 generic skills.
3. EP signals reusability beyond the originating project.
4. No matching coverage in the existing OS Core 5 + 1 seed packs.

If only 2 of 4 hold, keep the work in the project's
`<project>/.ai_dev_os/skills/` (Layer 2). Do not promote.

## Open question deferred to v4.92

- **Generalised exemption registry**: today the
  `_CLUSTER_ALIASING_EXEMPTIONS` registry is a hand-edited Python
  dict in the validator script. After M-H accumulates 2 sub-domain
  proposals, the next promotion (3rd sub-domain or new cluster)
  will repeat the dict-edit pattern. A v4.92 promotion should
  consider promoting the registry itself to a YAML
  (`docs/16_agent_library/exemption_registry.yaml`) consumed by the
  validator at load time.
- **Cross-engine UI implementation planners**: a hypothetical
  `unity-ui-implementation-planner` would land in
  `skills/_engine_specific/unity/` if v4.92 adds Unity engine
  support. The existing `_engine_specific/godot/` pattern is the
  template; no inheritance from creative_cluster needed.
- **Methodology compaction**: the M-G + M-H sibling cross-reference
  pattern works for the second iteration. By the third or fourth
  sub-domain, a single shared methodology document at
  `docs/16_agent_library/CROSS_PROJECT_PROMOTION_METHODOLOGY.md`
  may be more efficient than per-sub-domain CROSS_PROJECT_LESSONS
  files. Defer the consolidation decision until N=3 evidence is
  available.

## Cross-references

- `docs/28_2d_character_animation/CROSS_PROJECT_PROMOTION_LESSONS.md` — sibling M-G methodology record (canonical 5-stage method)
- `proposals/evo_2026_001_layer_separation_principle.md` — Layer 1 / Layer 2 separation principle
- `proposals/evo_2026_002_creative_cluster_role_aliasing.md` — animation sub-domain capability promotion (M-G)
- `proposals/evo_2026_003_creative_cluster_uiux_subdomain.md` — game UI/UX sub-domain capability promotion (M-H)
- `agent_packs/ap_2026_006_creative_cluster.md` — single pack accumulating sub-domains
- `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` § 6 — sub-domain table
- `runtime/protected_contracts/protected_regression_matrix.yaml` — inv_013 (animation) + inv_014 (UI/UX)
