# Card UI Prefab Spec Template

## Card role
## Aspect ratio and target sizes
## Layout zones
## Text rules
## States
## Rarity and type variants
## Asset rules
## Engine prefab structure
## QA checklist
