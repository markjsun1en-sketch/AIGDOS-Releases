# Godot UI Implementation Plan Template

## UI screen
## Scene path
## Scene tree
## Node responsibilities
## Theme resources
## Data model
## Signals
## Input handling
## Asset imports
## Test cases
