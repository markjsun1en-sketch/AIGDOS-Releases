# Figma Handoff Template

## Frame list
## Page organization
## Component inventory
## Naming rules
## Auto-layout notes
## Token mapping
## Asset export rules
## Interaction annotations
## Developer notes
