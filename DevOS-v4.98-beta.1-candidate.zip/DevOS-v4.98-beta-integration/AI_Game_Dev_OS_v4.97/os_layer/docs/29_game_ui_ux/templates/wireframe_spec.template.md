# Wireframe Spec Template

## Screen purpose
## Player goal
## Primary actions
## Information hierarchy
## ASCII wireframe
## Component list
## Interaction flow
## State variants
## Safe-area notes
