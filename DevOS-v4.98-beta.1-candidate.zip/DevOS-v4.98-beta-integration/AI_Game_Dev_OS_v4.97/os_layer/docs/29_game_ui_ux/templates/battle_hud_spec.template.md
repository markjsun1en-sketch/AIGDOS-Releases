# Battle HUD Spec Template

## Screen role
## Target platforms and resolution
## Combat assumptions
## Screen zones
## Player HUD
## Enemy HUD
## Card / command dock
## Action buttons
## State variants
## Engine notes
## Acceptance checklist
- [ ] Critical info readable at target size
- [ ] Enemy intent readable without tooltip
- [ ] Card cost readable
- [ ] Actor silhouettes not blocked
- [ ] Safe area specified
- [ ] Disabled/selected states defined
