# UI Audit Report Template

## Summary verdict
## Screen role
## What works
## Critical issues
| Severity | Issue | Why it matters | Fix |
|---|---|---|---|
## Medium issues
## Minor polish issues
## Recommended fix plan
## Acceptance checklist
