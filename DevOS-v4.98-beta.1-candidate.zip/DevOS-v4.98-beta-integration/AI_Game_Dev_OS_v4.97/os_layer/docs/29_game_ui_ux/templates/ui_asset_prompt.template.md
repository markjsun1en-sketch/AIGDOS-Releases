# UI Asset Prompt Template

## Asset purpose
## Asset type
## Target size
## Background / alpha
## Style constraints
## Runtime constraints
## Positive prompt
## Negative prompt
## Export notes
## QA checklist
