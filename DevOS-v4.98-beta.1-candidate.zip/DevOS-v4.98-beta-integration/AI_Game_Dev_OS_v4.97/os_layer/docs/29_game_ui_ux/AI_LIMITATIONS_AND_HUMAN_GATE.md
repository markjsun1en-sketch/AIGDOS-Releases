# AI Limitations and Human Gates — Game UI/UX Pack

> **v4.91 Milestone H** — sibling to `docs/28_2d_character_animation/AI_LIMITATIONS_AND_HUMAN_GATE.md`.
> The mandatory human gates listed below MUST appear in every adopting
> project's UI/UX workflow. Skipping any of them is a production
> failure mode.

## Why this document exists

AI-generated UI specs and assets fail in predictable ways. The
failures are not random; they cluster around (1) runtime text baked
into images, (2) state coverage gaps, (3) safe-area violations, (4)
information density that ignores gameplay pressure, and (5) handoff
specs that omit the data binding layer. This document enumerates
the gates that protect against each failure mode.

## Gate 1 — Runtime text MUST NOT be baked into generated art

**Failure mode**: card art ships with cost number, card name, or
effect text rendered into the image. When the runtime cost / name /
text changes (balance pass, localisation, dynamic effects), the art
becomes wrong.

**Gate**: every prompt produced by `ui-asset-prompt-engineer` MUST
declare `runtime_text_zones` separate from baked art. The
`schemas/uiux/ui_asset_prompt.schema.json` schema enforces a
`forbid_baked_text` field with `const: true`. inv_014 (M-H c4)
enforces this at compile-time across templates and prompts.

**Human review**: before sending a prompt to an image-generation
service, a human MUST confirm the prompt does not contain literal
runtime values (e.g. "2-cost fireball" instead of "fireball with
empty cost slot").

## Gate 2 — Every screen spec MUST list state variants

**Failure mode**: a screen ships with only the "happy path" state
designed. At runtime, hover / pressed / disabled / insufficient
resource / loading / error states fall back to engine defaults that
clash with the designed system.

**Gate**: every spec produced by `battle-hud-designer`,
`card-ui-prefab-spec`, or `game-ui-wireframe-generator` MUST list
state variants explicitly. Minimum set:

- default
- hover (or focused, on touch)
- pressed
- disabled
- insufficient_resource (where applicable)
- selected (where applicable)

**Human review**: the audit step (`game-ui-ux-auditor`) MUST flag
any screen with fewer than 3 state variants as a Major issue.

## Gate 3 — Safe areas MUST be declared per target platform

**Failure mode**: UI works on the design canvas, breaks on a phone
with a notch / on a tablet aspect ratio / on landscape orientation.

**Gate**: every screen spec MUST declare `target_platforms` and
`target_resolutions`. The `schemas/uiux/ui_screen_spec.schema.json`
schema requires both fields. `mobile_safe_area_rules.md` reference
specifies the allowed margin patterns.

**Human review**: when targeting mobile, the human MUST verify the
spec's anchor layout against the safe-area rule reference before
implementation.

## Gate 4 — Information density MUST account for gameplay pressure

**Failure mode**: a battle HUD looks great in a static screenshot
but is unreadable when the player is making decisions in 3 seconds.
Ten status icons stacked in 60 pixels do not work.

**Gate**: `battle-hud-designer` MUST output a priority-ordered
information hierarchy. `readability_and_density_rules.md` reference
gives the rules of thumb (minimum touch target, maximum stacked
icons, recovery-zone separation from action zone).

**Human review**: any battle HUD spec MUST include a "decision
timeline" subsection answering: under 5 seconds of pressure, can the
player identify enemy intent + their own resources + their available
actions in three glances? If no, the spec fails this gate.

## Gate 5 — Handoff specs MUST declare data binding

**Failure mode**: a Figma file ships to engineering. Engineering
implements the layout, then asks "where does the HP value come
from?" The handoff has to be redone.

**Gate**: `figma-handoff-spec` and `godot-ui-implementation-planner`
MUST declare:

- which UI nodes render game state (HP, energy, status, intent)
- which UI nodes render static text (titles, button labels)
- which UI nodes render runtime text from localisation
- which signals fire on user interaction
- where game state is read from (the binding layer is project-side
  but its required shape is sub-domain-side)

**Human review**: the handoff document MUST include a binding table
before merging to engineering. The `godot_ui_handoff_contract.md`
under `contracts/` defines the required minimum.

## Gate 6 — Card prefabs MUST separate art zone from text zone

**Failure mode**: a card prefab uses a beautiful illustration that
covers the area where effect text needs to render. At runtime, text
overlaps the illustration's focal point and becomes unreadable.

**Gate**: `card-ui-prefab-spec` MUST emit a 2:3 layout with
explicitly separated zones (cost badge / type chip / title / art /
keyword strip / effect panel / footer). The
`schemas/uiux/card_prefab_spec.schema.json` schema enforces zone
separation.

**Human review**: any card art prompt MUST declare the art zone is
the centre rectangle only; text zones must remain blank or
neutral-noise for the runtime text to render legibly.

## Gate 7 — Design tokens MUST be ratified before screen design

**Failure mode**: each screen designer picks ad-hoc colors and
spacings. The screens individually look fine but don't compose into
a coherent design system. Later tokens-pass requires re-spec across
all screens.

**Gate**: `game-design-system-builder` MUST run before the first
screen-spec skill (or its output MUST be supplied to the screen-spec
skills as input). Tokens cover: color (background / foreground /
state / rarity), typography (heading / body / caption / numeric),
spacing (4 / 8 / 12 / 16 / 24 / 32), radius, elevation, animation
duration.

**Human review**: an existing project's tokens MUST be loaded into
the AI context before any screen-spec skill runs. Otherwise the
screens will silently invent fresh tokens.

## Gate 8 — UX audit findings MUST be advisory

**Failure mode**: a producer treats `game-ui-ux-auditor` output as
a closure gate ("the audit passed, ship it"). The audit only
inspects spec shape and visible patterns; it does not run the game.

**Gate**: every audit report MUST state explicitly that gameplay
sign-off is a separate human decision (Charter anti-pattern #11).
The `ui_review_gate_contract.md` under `contracts/` codifies the
"advisory not closure-gate" boundary.

**Human review**: project EPs MUST treat audit reports as input to
their own ship/no-ship decision, not as the decision itself.

## Gate 9 — Prompts MUST declare style consistency anchors

**Failure mode**: prompts are written one screen at a time with no
style anchor. The resulting assets drift across the project (icon
style A on one screen, icon style B on another).

**Gate**: every prompt MUST inherit from a project-side style anchor
(brand keyword, illustration treatment, palette reference) declared
once in the design system. `ui-asset-prompt-engineer` MUST emit
prompts that reference the anchor explicitly.

**Human review**: before generating a batch of icons / frames /
panels, a human MUST confirm the style anchor is current and
applied to every prompt in the batch.

## Hard rule

Do NOT trust an AI-produced UI spec that skips any of these gates.
The pack is explicitly designed so each skill emits the gate-related
fields; if a field is missing or "TBD", that is a Blocker for the
audit step and a Blocker for human review.
