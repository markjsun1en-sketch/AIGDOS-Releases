---
title: State Machines Index
version: 1.0
status: active
layer: layer_1_os_spec
since_batch: 14.6
protected_invariants:
  - inv_003_state_machine_doc_schema_aligned
---

# State Machines Index — v4.90

> **Purpose**: Single entry point listing every lifecycle state
> machine declared in v4.90 OS Core. Cold-start agents and new
> contributors should consult this file first to locate the canonical
> model document, schema, and consumer scripts for any state machine
> they encounter in code or fixtures.
> Layer 1 (OS Spec). No project names.

## 1. Mandate

v4.90 OS Core defines three independent state machines, each
governing a distinct kind of artifact:

- **Proposals** — author-driven self-evolution proposals
  (`evo_YYYY_NNN`)
- **Capabilities** — per-capability adoption progress in adopting
  projects
- **Agent packs** — publication lifecycle of reusable agent packs
  (`ap_YYYY_NNN_*`)

Each machine has the same 5-section model document structure
(states / state diagram / transition table / schema / layer
discipline) so a reader who has internalised one can read any other
in seconds. All three share the same `transition_history` schema
shape (`allOf.anyOf` whitelist), so a single validator iterates
the family.

## 2. Registry matrix

| Machine | States | Transitions | Model doc | Schema | Primary consumer scripts |
|---|---:|---:|---|---|---|
| `proposal_state` | 9 | 12 | [`docs/17_self_evolution/PROPOSAL_STATE_MODEL.md`](17_self_evolution/PROPOSAL_STATE_MODEL.md) | [`schemas/self_evolution/proposal_state.schema.json`](../schemas/self_evolution/proposal_state.schema.json) | `scripts/self_evolution/` |
| `capability_adoption_state` | 9 | 15 | [`docs/13_migration/ADOPTION_STATE_MODEL.md`](13_migration/ADOPTION_STATE_MODEL.md) | [`schemas/protocol/capability_adoption_state.schema.json`](../schemas/protocol/capability_adoption_state.schema.json) | `scripts/adoption/` |
| `pack_lifecycle_state` | 5 | 6 | [`docs/16_agent_library/PACK_LIFECYCLE_STATE_MODEL.md`](16_agent_library/PACK_LIFECYCLE_STATE_MODEL.md) | [`schemas/agent_library/agent_pack_state.schema.json`](../schemas/agent_library/agent_pack_state.schema.json) | `scripts/agent_library/` |

Transition counts include wildcard expansion (e.g.
`capability_adoption_state` declares 8 explicit rows + one
`* → disabled (except from verified)` wildcard, which expands to
7 disabled transitions for a total of 15).

## 3. Family invariants

All three state machines obey the same OS Core conventions:

1. **Schema shape**: state value lives in
   `properties.<state_field>.enum`; allowed transitions live in
   `properties.transition_history.items.allOf[0].anyOf` as
   `{from: const, to: const}` (occasionally `{to: enum}` for
   one-from-many fan-outs).
2. **Entry shape**: every transition_history entry has
   `from / to / at` required, plus optional `actor / trigger` and
   machine-specific evidence fields (`commit_ref` for proposals,
   `evidence_ref` for capabilities, etc.).
3. **Conditional required fields**: terminal-or-decision states
   require additional fields, encoded as schema `if/then` (or
   conditional-required pattern in entry sub-schema).
4. **Layer discipline**: every model doc lives in Layer 1
   (OS Spec); per-instance evidence (which proposal, which
   project, which pack adoption case) goes in Layer 2 case
   studies (`docs/14_state_surface_governance/STATE_SURFACE_MIGRATION_CASE_*.md`).
5. **Alignment**: doc transition table and schema anyOf must
   agree bidirectionally; enforced by
   [`scripts/governance/check_state_machine_alignment.py`](../scripts/governance/check_state_machine_alignment.py).

## 4. Adding a new state machine — checklist

When introducing a new lifecycle state machine in v4.91 or later:

1. **Design** — sketch enum + transition graph. Aim for ≤ 9
   states; if more, split into sub-machines.
2. **Schema** — write
   `schemas/<area>/<name>_state.schema.json` with
   `properties.<state_field>.enum`,
   `properties.transition_history.items.allOf[0].anyOf` whitelist,
   and `schema_version` const `1.0.0`.
3. **Model doc** — write
   `docs/<NN_area>/<NAME>_STATE_MODEL.md` following the 5-section
   template (States / State diagram / Transition table / Schema /
   Layer Discipline). Match the wording style of an existing
   sibling (e.g. PROPOSAL_STATE_MODEL.md).
4. **Register** — append a row to §2 of this file with all five
   columns filled in.
5. **Alignment** — append a `dict` to the `STATE_MACHINES` list in
   `scripts/governance/check_state_machine_alignment.py` (`name`
   / `doc` / `schema` / `state_field`); run the script and ensure
   exit 0.

A pytest case in `tests/test_state_machines_index.py` enforces
that every machine declared in `STATE_MACHINES` (the script's
config) has a matching row in this index.

## 5. Layer Discipline

Layer 1 (OS Spec). No project names. This file is the canonical
catalog; project-specific state machine adoption is documented
in Layer 2 case studies, never inlined here.
