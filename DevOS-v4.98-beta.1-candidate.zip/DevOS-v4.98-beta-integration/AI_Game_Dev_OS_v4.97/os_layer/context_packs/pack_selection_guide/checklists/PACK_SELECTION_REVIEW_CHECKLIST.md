# Pack Selection Review Checklist

## Context profile
- [ ] Did I choose Lean / Standard / Expanded / FULL_REFERENCE intentionally?
- [ ] Is the chosen profile aligned with the actual task complexity?
- [ ] Am I avoiding FULL_REFERENCE for normal daily work?

## Starter
- [ ] Did I attach a project starter?
- [ ] Is the starter aligned with the project type?
- [ ] Did I define a default context profile and stage mode inside the project starter?

## Layering
- [ ] Is `docs/` + `runtime/` + `config/` + `scripts/` treated as the canonical runtime baseline?
- [ ] Is `context_packs/full_reference/` treated as reference rather than the default runtime workset?
- [ ] Are project starter files (under `game_type_packs/`) acting as project instantiation rather than replacing the canonical baseline?

## Escalation
- [ ] If Lean feels insufficient, did I escalate to STANDARD?
- [ ] If Standard is insufficient for cross-subsystem or architecture work, did I escalate to EXPANDED?
- [ ] If historical ambiguity remains, did I escalate to FULL_REFERENCE?
