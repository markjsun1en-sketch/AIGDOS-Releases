# AI Game Dev OS v4.88 Pack Selection Guide

This pack is the assembly/navigation layer for choosing and combining:
- the canonical runtime baseline
- context profile packs
- project starter packs

It does not replace the canonical system pack. It helps the user or agent pick the right combination for:
- new project startup
- daily development
- short execution threads
- complex cross-subsystem work
- framework audit and historical investigation

## Core role split
- `docs/` + `runtime/` + `config/` + `scripts/` = canonical runtime baseline
- `context_packs/full_reference/` = full reference layer
- Context packs (`context_packs/{lean,standard,expanded,full_reference}/`) = loading-width control
- Project starter packs (`game_type_packs/`) = project instantiation layer

## Currently covered
### Context profiles
- `LEAN`
- `STANDARD`
- `EXPANDED`
- `FULL_REFERENCE`

### Project starters
- Generic
- Card / Roguelike

## Recommended default
For a new real project:
- Runtime baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- Reference layer: `context_packs/full_reference/`
- Context profile: `context_packs/standard/` (`standard_context_pack`)
- Starter: `game_type_packs/generic/` (`generic_project_starter`) or a type-specific starter under `game_type_packs/`
