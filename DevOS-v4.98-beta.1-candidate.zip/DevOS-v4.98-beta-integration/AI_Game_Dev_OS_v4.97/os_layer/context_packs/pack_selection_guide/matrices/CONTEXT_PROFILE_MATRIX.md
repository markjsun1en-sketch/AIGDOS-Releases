# Context Profile Matrix

| Profile | Default use | Load width | Archive/reference loading | Typical trigger |
|---|---|---:|---|---|
| LEAN | short execution thread | low | off by default | bugfix, local patch, known-path execution |
| STANDARD | normal daily work | medium | off by default | new project startup, daily development |
| EXPANDED | complex execution and architecture work | medium-high | selective | multi-subsystem work, architecture change |
| FULL_REFERENCE | audit and historical tracing | high | on | framework audit, legacy conflict resolution |
