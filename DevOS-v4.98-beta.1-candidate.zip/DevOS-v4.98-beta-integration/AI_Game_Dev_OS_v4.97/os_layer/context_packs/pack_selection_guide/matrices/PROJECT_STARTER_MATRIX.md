# Project Starter Matrix

| Starter | Best for | Default stage mode | Default context profile | Notes |
|---|---|---|---|---|
| generic_project_starter | any project needing a neutral bootstrap | MVP | STANDARD | use when type is not fully fixed |
| card_roguelike_project_starter | deckbuilder, build-oriented roguelike, content batch heavy projects | MVP or VERTICAL_SLICE | STANDARD | emphasizes simulation, content batch, progression and numeric validation |
