# Pack Compatibility Matrix

## Core compatibility
All context profile packs assume:
- Canonical baseline: `docs/` + `runtime/` + `config/` + `scripts/`

## Reference compatibility
`context_packs/full_reference/` is optional for:
- Lean
- Standard
- Expanded

It is strongly recommended for:
- Full Reference

## Starter compatibility
- `generic_project_starter` is compatible with all context profiles
- `card_roguelike_project_starter` is compatible with all context profiles, but `Standard` is the default and `Expanded` is preferred for larger rebalance/content-batch work

## Recommended pairings
- Lean + current project starter
- Standard + Generic or type-specific starter
- Expanded + type-specific starter for complex execution
- Full Reference + no daily default; reserve for audit/restructure cases
