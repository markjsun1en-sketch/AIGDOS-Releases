# Example Pack Combination

## Scenario
New card / roguelike project, initial bootstrap

## Selected packs
- Canonical baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- Reference layer: `context_packs/full_reference/`
- `context_packs/standard/` (`standard_context_pack`)
- `game_type_packs/card_roguelike/` (`card_roguelike_project_starter`)

## Intent
Use the canonical runtime baseline for actual operation, keep the full repacked archive as a reference layer, and instantiate the project with the card/roguelike starter.
