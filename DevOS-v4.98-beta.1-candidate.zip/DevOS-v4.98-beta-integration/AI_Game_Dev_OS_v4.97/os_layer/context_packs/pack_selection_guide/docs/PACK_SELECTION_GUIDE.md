# Pack Selection Guide

> **Status (v4.88-stable)**: v4.89_Release prefix names
> (`AI_Game_Dev_OS_v4.87_Optimized_*`) were sunset in the B1-B6 renaming
> sweep; see `CHANGELOG.md` §B1-B6. All paths below point to the current
> v4.88 package layout.

## Primary rule
Do not use the full reference layer as the default runtime workset.

Use this split instead:
1. `docs/` + `runtime/` + `config/` + `scripts/` for canonical runtime operation (the "Run Baseline" layer)
2. `context_packs/full_reference/` for reference and historical trace-back
3. one context profile pack under `context_packs/` (Lean / Standard / Expanded) for load width control
4. one project starter pack under `game_type_packs/` for project instantiation

## Selection order
1. Choose project starter (under `game_type_packs/`)
2. Choose stage mode inside the starter
3. Choose context profile (under `context_packs/`)
4. Attach the runtime baseline (`docs/` + `runtime/` + `config/` + `scripts/`)
5. Keep `context_packs/full_reference/` available but not default-loaded

## Default recommendation
### New project
- Runtime baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- Reference layer: `context_packs/full_reference/`
- Context profile: `context_packs/standard/`
- Starter: `game_type_packs/generic/` unless a project type starter already exists

### Short execution thread
- Runtime baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- Context profile: `context_packs/lean/`
- Starter: current project starter under `game_type_packs/`
- Reference layer: available but not default-loaded

### Complex feature / architecture adjustment
- Runtime baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- Context profile: `context_packs/expanded/`
- Starter: current project starter under `game_type_packs/`
- Reference layer: selectively consulted

### Framework audit / historical conflict resolution
- Runtime baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- Context profile: `context_packs/full_reference/`
- Starter: optional
- Reference layer: actively loaded
