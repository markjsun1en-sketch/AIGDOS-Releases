# Default Combinations

> **Status (v4.88-stable)**: v4.89_Release prefix names
> (`AI_Game_Dev_OS_v4.87_Optimized_*`) were sunset in the B1-B6 renaming
> sweep. All paths below point to the current v4.88 package layout.

## Combination A — New project bootstrap
- Canonical baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- Reference layer: `context_packs/full_reference/`
- Context profile: `context_packs/standard/` (`standard_context_pack`)
- Starter: `game_type_packs/generic/` (`generic_project_starter`)

## Combination B — Card / Roguelike new project
- Canonical baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- Reference layer: `context_packs/full_reference/`
- Context profile: `context_packs/standard/` (`standard_context_pack`)
- Starter: `game_type_packs/card_roguelike/` (`card_roguelike_project_starter`)

## Combination C — Short bugfix / local execution thread
- Canonical baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- Context profile: `context_packs/lean/` (`lean_context_pack`)
- Starter: current project starter under `game_type_packs/`
- Reference layer: consult only if blocked by background ambiguity

## Combination D — Large feature with multiple subsystems
- Canonical baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- Context profile: `context_packs/expanded/` (`expanded_context_pack`)
- Starter: current project starter under `game_type_packs/`
- Reference layer: selective consultation allowed

## Combination E — Framework audit / heavy historical trace-back
- Canonical baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- Context profile: `context_packs/full_reference/` (`full_reference_context_pack`)
- Reference layer: `context_packs/full_reference/`
- Starter: optional
