# Quick Start by Scenario

> **Status (v4.88-stable)**: v4.89_Release prefix names were sunset in
> the B1-B6 renaming sweep. All paths below point to the current v4.88
> package layout.

## I want to start a new project, but the exact type is not fully fixed
Use:
- Canonical baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- Reference layer: `context_packs/full_reference/`
- `context_packs/standard/` (`standard_context_pack`)
- `game_type_packs/generic/` (`generic_project_starter`)

## I want to start a card / roguelike project
Use:
- Canonical baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- Reference layer: `context_packs/full_reference/`
- `context_packs/standard/` (`standard_context_pack`)
- `game_type_packs/card_roguelike/` (`card_roguelike_project_starter`)

## I want to open a short implementation thread
Use:
- Canonical baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- `context_packs/lean/` (`lean_context_pack`)
- current project starter under `game_type_packs/`

## I want to work on a multi-subsystem feature
Use:
- Canonical baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- `context_packs/expanded/` (`expanded_context_pack`)
- current project starter under `game_type_packs/`
- optionally consult `context_packs/full_reference/`

## I want to audit framework history or resolve legacy rule conflicts
Use:
- Canonical baseline: `docs/` + `runtime/` + `config/` + `scripts/`
- `context_packs/full_reference/` (`full_reference_context_pack`)
