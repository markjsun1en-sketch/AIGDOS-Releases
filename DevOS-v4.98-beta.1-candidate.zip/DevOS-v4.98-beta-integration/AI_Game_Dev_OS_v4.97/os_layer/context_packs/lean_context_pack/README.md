# v4.89_Release Lean Context Pack

## Purpose

This pack defines the **lightest recommended runtime context profile** for short-lived threads, narrow tasks, and low-ambiguity execution work.

It is not a replacement for the canonical system baseline. It is a **loading profile and operating attachment layer** that should be used together with:

- `v4.89_Release Run Baseline layer` as the canonical runtime baseline
- `v4.89_Release Reference layer` as optional reference-only background
- a project starter pack when work is attached to a real project

## Best-fit scenarios

Use Lean when:

- the task is narrow and well scoped
- the required owner and subsystem are already known
- the thread is expected to stay short
- the work does not require architecture reinterpretation
- the task mostly executes already-decided rules

Typical examples:

- fix one bug in a known module
- update one config table or card batch entry set
- perform one validation pass
- execute one content prep step
- produce one bounded handoff-ready artifact under an existing plan

## What Lean tries to optimize

Lean is designed to reduce:

- cold-start context cost
- repeated loading of broad framework explanations
- accidental authority drift caused by overloading reference material
- long-thread context inflation

## What Lean should not be used for

Do not keep Lean as the default if the task expands into:

- cross-subsystem architecture changes
- unclear ownership or unclear authority disputes
- thread closure or lifecycle redesign work
- policy changes
- starter/template redesign
- broad project re-planning

In those cases, escalate to `standard_context_pack`, and if needed later to `expanded_context_pack`.
