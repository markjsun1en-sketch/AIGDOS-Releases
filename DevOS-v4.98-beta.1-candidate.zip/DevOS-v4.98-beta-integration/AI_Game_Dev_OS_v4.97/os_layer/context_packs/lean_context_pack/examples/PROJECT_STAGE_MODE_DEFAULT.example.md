# PROJECT_STAGE_MODE_DEFAULT

- Default Stage Mode: MVP
- Lean Context Compatibility: strong for local execution tasks
- Escalate Context Profile if stage-sensitive policy interpretation becomes necessary
