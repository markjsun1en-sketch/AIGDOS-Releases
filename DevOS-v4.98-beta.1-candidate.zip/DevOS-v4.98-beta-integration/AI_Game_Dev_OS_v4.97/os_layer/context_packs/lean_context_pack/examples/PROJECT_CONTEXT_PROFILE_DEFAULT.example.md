# PROJECT_CONTEXT_PROFILE_DEFAULT

- Default Context Profile: LEAN
- Upgrade Target: STANDARD
- Use Lean for: bounded execution threads, local fixes, local content updates, direct validation tasks
- Do Not Use Lean For: project replanning, architecture review, policy edits, broad subsystem coordination
