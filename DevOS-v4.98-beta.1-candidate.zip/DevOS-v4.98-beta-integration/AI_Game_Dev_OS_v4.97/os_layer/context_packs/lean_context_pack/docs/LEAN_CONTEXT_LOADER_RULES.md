# Lean Context Loader Rules

## Goal

Lean mode should load only the material required to execute the current task without re-opening broad framework history.

## Loader principles

### 1. Authority first
Always load the current authority chain before task-specific material.

Minimum authority chain:
- `README.md`
- `docs/INDEX.md`
- `docs/CURRENT_BASELINE_AUTHORITY.md`

### 2. Project before framework expansion
If the task belongs to a real project, load the project starter baseline before broadening framework context.

### 3. Task scope before subsystem breadth
Only load the subsystem material that is directly necessary for the active task.

### 4. Reference stays opt-in
`v4.89_Release Reference layer` is not part of the default Lean loadset. It is only used when ambiguity or historical tracing demands it.

## Default Lean load sequence

1. Current authority documents
2. Project baseline and adaptation docs if present
3. Current task brief or task start pack
4. Active stage mode default if needed
5. Directly relevant subsystem-local contract/doc/tool references
6. Minimal validation requirements for the task

## Things Lean should avoid loading by default

- archive/reference full text
- unrelated runbooks
- unrelated subsystem bundles
- old migration notes
- release notes and package maps
- broad architecture overviews beyond what the current task needs

## Escalate out of Lean when

Escalate to Standard if any of the following happens:

- the thread needs more than one subsystem family in depth
- the task changes governance or policy
- the task changes ownership/writable scope interpretation
- the task requires historical reasoning from reference docs
- the thread becomes planning-heavy rather than execution-heavy
