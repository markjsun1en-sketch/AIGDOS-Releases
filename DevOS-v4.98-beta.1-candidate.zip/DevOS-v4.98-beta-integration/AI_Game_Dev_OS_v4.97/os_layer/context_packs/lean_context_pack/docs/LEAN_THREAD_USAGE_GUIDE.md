# Lean Thread Usage Guide

## What Lean threads are for

Lean threads are execution-first threads. They are best for:

- local bugfixes
- bounded content changes
- one validator or one prep pass
- one artifact completion loop

## Recommended Lean thread lifecycle

### Start
- attach current project baseline if present
- attach the current task brief or task start pack
- load only directly relevant subsystem materials

### Execute
- stay within known ownership and known authority
- avoid broad framework reinterpretation
- keep outputs tightly scoped

### Close
- produce the narrowest useful closure summary
- if follow-up work expands scope, route the next thread to Standard

## Anti-patterns

Do not use Lean to:

- redesign policies
- redesign starter packs
- re-open architecture boundaries
- perform framework audit work
- perform broad project planning
