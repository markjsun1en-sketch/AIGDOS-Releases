# Escalation to Standard Rules

Lean is intentionally narrow. Escalate to `standard_context_pack` when the current thread crosses any of these thresholds.

## Escalation triggers

### Ownership ambiguity
- owner is unclear
- writable scope is unclear
- more than one team/subsystem must actively coordinate

### Authority ambiguity
- current rule source is uncertain
- the thread needs historical rationale rather than current rule execution

### Scope growth
- the task now spans more than one subsystem in a non-trivial way
- the task is no longer a bounded execution loop
- design/policy/runtime interpretation must be revisited

### Validation growth
- validation requirements become cross-subsystem or stage-sensitive
- evidence expectations cannot be satisfied with the current minimal loadset

### Project planning growth
- the thread starts producing new planning structures rather than executing a known plan

## Upgrade rule

When one escalation trigger is confirmed, the next thread should default to `standard_context_pack` unless there is a strong reason to stay Lean.
