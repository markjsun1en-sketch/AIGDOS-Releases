# Lean Context Pack Quick Start

## Default use

Use Lean when you already know:

- the current project baseline
- the current owner or active subsystem
- the task is bounded
- the task does not require broad historical background

## Recommended attachment stack

1. `v4.89_Release Run Baseline layer`
2. current project starter docs
3. current task start pack or equivalent scoped task brief
4. `lean_context_pack`

## Optional reference layer

Do not attach `v4.89_Release Reference layer` by default.
Only use it when the task hits an authority or historical ambiguity.

## Default recommendation

If uncertain between Lean and Standard, start with Standard.
Lean is best when the task is clearly narrow.
