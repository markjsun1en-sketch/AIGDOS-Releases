# Lean Context Pack Review Checklist

## Packing checks
- [ ] Lean pack does not duplicate the canonical runtime baseline
- [ ] Lean pack clearly references `v4.89_Release Run Baseline layer` as the runtime baseline
- [ ] Lean pack clearly treats `v4.89_Release Reference layer` as optional reference only

## Loading checks
- [ ] default loadset is narrower than Standard
- [ ] archive/reference is excluded by default
- [ ] unrelated subsystem material is excluded by default

## Escalation checks
- [ ] clear triggers to upgrade to Standard are documented
- [ ] ownership ambiguity is treated as an upgrade trigger
- [ ] authority ambiguity is treated as an upgrade trigger

## Thread checks
- [ ] Lean is described as execution-first, not planning-first
- [ ] Lean thread closure guidance is included
- [ ] Lean is not positioned as the default for broad project startup
