# Lean Profile Selection Guide

## Choose Lean when

- you want the smallest reasonable loading surface
- the task is execution-oriented
- the task fits one bounded problem statement
- the owner and subsystem are already known

## Choose Standard instead when

- the thread may expand beyond one subsystem
- the task may change workflow/gates/validation interpretation
- the task may trigger planning or baseline updates
- the project is in active startup or broad reorganization

## Choose Expanded or Full Reference when

- you need broad cross-subsystem context
- you need reference/history frequently
- you are auditing or restructuring the system itself

## Default pairing recommendations

### Bugfix / local implementation
- `lean_context_pack`
- current project starter
- current task start pack

### Small content batch update
- `lean_context_pack`
- current project starter
- direct content batch policy and validation references only

### Broad feature kickoff
- use `standard_context_pack` instead
