# v4.89_Release Expanded Context Pack

This pack defines the **Expanded** context profile for AI Game Dev OS v4.89_Release.

Expanded is the recommended profile for:
- multi-subsystem features
- architecture adjustments
- complex implementation tasks
- cross-module debugging
- work that needs more policy, subsystem, and limited reference context than Standard

Expanded is **not** the default profile for all work.
Use it when Lean or Standard is no longer sufficient, but you still do **not** want to open the full historical reference layer.

## Role in the three-layer operating model

- **Final Integrated** = canonical runtime baseline
- **Full Content Repacked** = complete reference layer
- **Expanded Context Pack** = complex-task working profile

Expanded should load more than Standard, but must still preserve:
- authority discipline
- current baseline priority
- thread hygiene
- controlled reference usage

## Default pairing
Recommended default pairings:
- Stage Mode: `VERTICAL_SLICE` or `PRODUCTION_LIKE`
- Project Starter: whichever matches the active project type
- Reference usage: selective, not full-open by default
