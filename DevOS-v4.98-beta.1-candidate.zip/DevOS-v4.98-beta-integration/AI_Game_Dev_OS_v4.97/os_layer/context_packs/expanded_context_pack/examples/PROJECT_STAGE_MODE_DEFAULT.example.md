# PROJECT_STAGE_MODE_DEFAULT

Default Stage Mode: VERTICAL_SLICE

Rationale:
- The project requires stronger validation and cross-subsystem coordination than MVP.
- Production-like strictness is not yet the default for every thread.
