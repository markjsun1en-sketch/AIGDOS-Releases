# PROJECT_CONTEXT_PROFILE_DEFAULT

Default Context Profile: EXPANDED

Rationale:
- The project currently involves multi-subsystem work.
- Standard remains the normal fallback, but Expanded is the default for major feature threads.
- Full historical reference remains selective and opt-in.
