# Profile Selection Guide

## Lean
Use for local execution threads, small fixes, and minimal-context tasks.

## Standard
Use for normal project startup and most day-to-day development.

## Expanded
Use for complex tasks that require broader subsystem, policy, and selective reference context.

## FULL_REFERENCE
Use for framework audits, historical reconciliation, migration analysis, and archive-heavy investigation.

## Rule of thumb
If the task is still execution-first but crosses boundaries, choose **Expanded**.
If the task becomes history-first or audit-first, choose **FULL_REFERENCE**.
