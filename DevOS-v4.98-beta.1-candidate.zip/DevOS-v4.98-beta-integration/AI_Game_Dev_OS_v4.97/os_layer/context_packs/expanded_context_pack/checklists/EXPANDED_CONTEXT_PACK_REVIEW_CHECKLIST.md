# Expanded Context Pack Review Checklist

- [ ] Expanded is positioned as a complex-task profile, not the default for all work
- [ ] Current authority chain remains primary
- [ ] Archive/reference usage is selective, not full-open by default
- [ ] Upgrade triggers from Standard are explicit
- [ ] Escalation to Full Reference is clearly bounded
- [ ] Project Starter attachment is required for project-specific execution
- [ ] Expanded is compatible with Lean and Standard semantics
