# Escalation From Standard Rules

Escalate from **Standard** to **Expanded** when one or more of the following becomes true:

## Escalation triggers
- the task crosses subsystem boundaries
- the task changes multiple contracts or delivery surfaces
- policy interpretation requires broader supporting material
- current docs are sufficient for authority, but insufficient for execution detail
- selective historical reference is required to resolve a practical ambiguity

## Do not escalate merely because:
- the task feels difficult
- there are many files in the repo
- the tool wants more context "just in case"

## Escalation discipline
When escalating to Expanded:
- declare why Standard is insufficient
- identify which additional layers are needed
- keep archive/reference pulls selective
- avoid turning Expanded into Full Reference by accident
