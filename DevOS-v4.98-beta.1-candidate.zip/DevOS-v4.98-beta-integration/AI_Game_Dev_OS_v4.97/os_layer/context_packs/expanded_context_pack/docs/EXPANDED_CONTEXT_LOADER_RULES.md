# Expanded Context Loader Rules

## Purpose
Expanded is the complex-task working profile.

It exists to bridge the gap between:
- **Standard**: balanced day-to-day work
- **Full Reference**: historical or audit-heavy work

Expanded must support broader task execution without collapsing back into uncontrolled full-context loading.

## Loader rules

### 1. Preserve the canonical authority chain
Always load the current baseline first:
1. `README.md`
2. `docs/INDEX.md`
3. `docs/CURRENT_BASELINE_AUTHORITY.md`
4. core/governance docs relevant to the task
5. policies relevant to the task
6. enabled subsystem docs relevant to the task
7. active Project Starter docs
8. selective archive/reference material only if needed

### 2. Expand breadth, not chaos
Expanded may load:
- more subsystem docs
- more policy docs
- more runbooks
- selected archive/reference indexes or source docs

Expanded must **not** default to loading all historical material.

### 3. Keep reference material subordinate
Historical reference exists to resolve ambiguity, not to replace current authority.

### 4. Favor selective reference pulls
When using the full reference layer:
- pull only the specific source family needed
- do not open all archive layers by default
- summarize reference findings back into the active thread context

### 5. Maintain thread hygiene
Expanded should still produce:
- clear task scope
- explicit authority references
- closure outputs
- carry-forward packs when needed
