# Expanded Context Pack Quick Start

## Recommended use
Use this profile for complex but still execution-oriented work.

## Default assembly
- `v4.89_Release Run Baseline layer`
- one active Project Starter
- `expanded_context_pack`
- `v4.89_Release Reference layer` only as selective reference

## Recommended stage modes
- `VERTICAL_SLICE`
- `PRODUCTION_LIKE`

## Typical escalation path
- start in `Standard`
- escalate to `Expanded` when the task crosses subsystem, policy, or architecture boundaries
- escalate to `Full Reference` only when selective reference no longer resolves the issue
