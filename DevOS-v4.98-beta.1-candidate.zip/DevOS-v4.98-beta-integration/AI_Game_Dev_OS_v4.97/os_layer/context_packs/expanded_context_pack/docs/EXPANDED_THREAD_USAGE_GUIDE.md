# Expanded Thread Usage Guide

Use Expanded when the task is larger than a local execution thread but still has a clear delivery target.

## Good fits
- implementing a feature that touches design, UIUX, and art interfaces
- changing routing or validation expectations across multiple modules
- reconciling delivery bundle shape with subsystem docs
- multi-layer bug investigation
- architecture-sensitive refactors

## Poor fits
Expanded is a bad default for:
- tiny fixes
- single-file edits
- small documentation tweaks
- pure historical audits

For those, prefer:
- **Lean** for local execution tasks
- **Standard** for normal project work
- **Full Reference** for framework or archive-heavy analysis

## Working pattern
1. Start from current authority
2. Load only relevant subsystems
3. Attach the Project Starter
4. Pull only the minimum needed archive/reference
5. Produce a closure result that narrows the next thread again where possible
