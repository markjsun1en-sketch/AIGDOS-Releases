# ContextPack Recommendation Guide

## Default rule
Use the lightest context pack that still preserves correct operation.

## Recommendations
- **Lean**: short-lived implementation threads, low context budget, focused bugfix or tool work.
- **Standard**: default project operation mode for most ongoing development.
- **Expanded**: broad cross-domain coordination, reconciliation-heavy work, or wide runtime/design overlap.
- **Full Reference**: historical deep dives, migration checks, or archive-heavy investigation.

## Escalation rule
Do not escalate context weight only because the thread feels uncertain. First prefer snapshot refresh, registry rebuild, or targeted reference lookup.
