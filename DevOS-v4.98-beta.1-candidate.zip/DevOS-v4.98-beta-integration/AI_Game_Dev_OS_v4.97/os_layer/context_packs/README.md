# AI Game Dev OS v4.89_Release ContextPacks

This package owns the **context-loading mode**. It does not define base runtime grammar, nor does it replace the Run Baseline.

## Scope

- Decides how much context to load for this thread / session
- Decides cold-start payload size and the scope of historical material
- Does not decide the Runtime Object Model
- Does not replace Stage Policy / Gate / Starter rules

## Loading Order

1. Load the `Run Baseline` first
2. Then choose a `ContextPack`
3. Attach a `GameTypePack` when the project requires it
4. Consult a `Reference` when deeper grounding is needed

## Available Packs

- `lean_context_pack`
- `standard_context_pack`
- `expanded_context_pack`
- `full_reference_context_pack`
- `pack_selection_guide`

## Conflict Handling

If a ContextPack statement conflicts with the v4.87 Run Baseline, the Run Baseline wins.

- `CONTEXTPACK_RECOMMENDATION_GUIDE.md`
