# Profile Selection Guide

## Lean
Use for narrow execution threads and small scoped tasks.

## Standard
Use for normal project startup and default day-to-day work.

## Expanded
Use for multi-subsystem work, complex features, and architectural adjustments.

## Full Reference
Use for audit, historical traceability, migration analysis, and deep framework-level investigation.

## Default recommendation
Prefer the lightest profile that can still complete the task reliably.
