# Full Reference Context Pack Review Checklist

- Is this task actually dependent on historical/reference depth?
- Has the canonical baseline been established before archive loading?
- Are archive docs being treated as reference, not default authority?
- Is the task unsuitable for Lean/Standard/Expanded?
- Is there a clear plan to downgrade the next execution thread after ambiguity is resolved?
