# PROJECT_STAGE_MODE_DEFAULT

Default Stage Mode: PRODUCTION_LIKE

## Rationale
Full Reference is most appropriate when framework integrity, migration correctness, or deep system traceability matters more than speed.
