# PROJECT_CONTEXT_PROFILE_DEFAULT

Default Context Profile: FULL_REFERENCE

## Use only when
- this project phase is primarily audit-oriented
- migration and historical reconciliation are active concerns
- the task routinely requires reference-layer access

## Normal recommendation
For most projects, do not set FULL_REFERENCE as the everyday default.
Prefer STANDARD or EXPANDED and escalate when necessary.
