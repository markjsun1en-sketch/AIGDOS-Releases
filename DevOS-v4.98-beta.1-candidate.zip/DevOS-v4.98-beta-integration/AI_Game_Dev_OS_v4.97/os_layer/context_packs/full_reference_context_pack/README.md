# AI Game Dev OS v4.89_Release — Full Reference Context Pack

This pack defines the **Full Reference** context profile for AI Game Dev OS v4.89_Release.

## Purpose
Use this profile when the task requires:
- framework audit and historical traceability
- large-scale refactor planning
- naming / rule conflict investigation
- migration reasoning across versions
- deep reference lookups beyond the current canonical baseline

## Role in the system
This pack is **not** the default runtime working profile.

It sits above:
- Lean Context Pack
- Standard Context Pack
- Expanded Context Pack

and should be used only when the current task cannot be completed reliably with those lighter profiles.

## Intended combination
- Canonical runtime baseline: `v4.89_Release Run Baseline layer`
- Full reference layer: `v4.89_Release Reference layer`
- Project instantiation layer: a project starter pack

## Key principle
Default work should still happen against the canonical baseline.
Full Reference exists to add controlled access to historical and archive material, not to replace the authority chain.
