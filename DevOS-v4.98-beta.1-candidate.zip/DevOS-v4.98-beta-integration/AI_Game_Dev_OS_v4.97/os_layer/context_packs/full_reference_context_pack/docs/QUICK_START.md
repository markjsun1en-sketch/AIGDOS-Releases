# Quick Start

## Use this pack when
- you are auditing the framework
- you need historical traceability
- you are resolving migration or naming conflicts
- you need both the canonical baseline and archive/reference material

## Combine with
- `v4.89_Release Run Baseline layer`
- `v4.89_Release Reference layer`
- a project starter pack, if the task is project-specific

## Default rule
Current authority remains with the canonical baseline.
Archive/reference content is loaded to explain, compare, or recover intent.
