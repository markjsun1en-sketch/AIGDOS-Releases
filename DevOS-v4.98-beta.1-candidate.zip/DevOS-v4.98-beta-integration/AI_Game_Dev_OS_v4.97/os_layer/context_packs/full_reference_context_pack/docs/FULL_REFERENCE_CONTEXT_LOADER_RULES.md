# Full Reference Context Loader Rules

## Purpose
This profile is used when the active task needs both the current canonical baseline and the broader historical/reference layer.

## Loader behavior
The loader should:
1. establish the current canonical authority first
2. load the current baseline before any archive material
3. treat archive/reference content as secondary evidence
4. avoid replacing current rules with historical documents unless the task is explicitly audit or migration analysis

## What Full Reference may load
- current canonical docs and policies
- governance and threading rules
- subsystem docs relevant to the task
- final assembly and review docs
- archive indices
- archived historical source documents
- full source reference trees from repacked source material

## What it should not do
- treat legacy docs as current authority by default
- replace project adaptation docs with historical examples
- use old naming unless the task is explicitly comparative or migratory

## Recommended trigger conditions
Use Full Reference when:
- current rules appear inconsistent with a past decision
- a migration needs to preserve intent from older versions
- a naming conflict cannot be resolved from the canonical baseline alone
- a refactor spans multiple subsystem generations
