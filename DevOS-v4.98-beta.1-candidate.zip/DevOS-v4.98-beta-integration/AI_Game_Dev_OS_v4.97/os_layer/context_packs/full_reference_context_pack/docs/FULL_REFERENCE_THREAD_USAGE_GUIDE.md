# Full Reference Thread Usage Guide

## Suitable threads
- architecture audit threads
- migration reconciliation threads
- semantic cleanup threads
- archive-assisted research threads
- framework-level rewrite planning

## Unsuitable threads
- narrow bugfix threads
- simple content entry tasks
- local UI tweaks
- straightforward implementation tasks with stable authority

## Working pattern
1. start from the canonical baseline
2. identify the ambiguity or missing rationale
3. consult archive/reference material selectively
4. produce an explicit conclusion about what remains canonical
5. return future execution threads to Standard or Expanded when possible
