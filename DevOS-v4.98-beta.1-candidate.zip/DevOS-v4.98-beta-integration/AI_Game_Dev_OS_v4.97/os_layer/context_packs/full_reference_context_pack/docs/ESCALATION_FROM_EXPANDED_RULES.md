# Escalation From Expanded Rules

Escalate from **Expanded** to **Full Reference** only when one or more of the following is true:

- Expanded still cannot explain a terminology mismatch
- current and archived documents appear to contradict each other
- the task requires reconstructing historical intent across versions
- a subsystem migration decision depends on old pack content
- framework-level cleanup needs broad archive coverage

## Anti-pattern
Do **not** escalate to Full Reference merely because the task feels important.
Importance alone is not a valid trigger. The trigger must be historical or reference-depth dependent.
