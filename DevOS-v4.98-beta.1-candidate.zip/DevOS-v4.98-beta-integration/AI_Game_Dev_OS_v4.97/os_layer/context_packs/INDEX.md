# ContextPacks Index

ContextPacks are selected **after** loading Run Baseline.

## Available packs
- `lean_context_pack`
- `standard_context_pack`
- `expanded_context_pack`
- `full_reference_context_pack`
- `pack_selection_guide`

## Rule of use
Context packs control **how much** context is attached, not **how runtime rules are redefined**.

## Recommended flow
1. Load `../v4.89_Release Run Baseline layer`
2. Select one context pack
3. Attach one GameTypePack if needed
4. Read Reference only when ambiguity remains

- `CONTEXTPACK_RECOMMENDATION_GUIDE.md`

## Selection support
- `CONTEXTPACK_RECOMMENDATION_GUIDE.md`
- Use Run Baseline `scripts/run_attachment_preview.sh` to validate selection pairings.
