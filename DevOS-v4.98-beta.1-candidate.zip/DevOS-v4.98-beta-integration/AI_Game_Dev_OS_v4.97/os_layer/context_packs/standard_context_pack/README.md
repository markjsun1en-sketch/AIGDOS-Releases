# v4.89_Release Standard Context Pack

## Purpose

This pack defines the **default working context profile** for using AI Game Dev OS v4.89_Release with a real project and a coding agent such as Codex or Claude Code.

It is not a replacement for the canonical system pack. Instead, it tells the tool:

- what to load by default
- what to defer unless needed
- how to combine the canonical runtime baseline with project-specific startup material
- when to downgrade from `STANDARD` to `LEAN`
- when to escalate from `STANDARD` to `EXPANDED` or `FULL_REFERENCE`

## Intended usage

Use this pack together with:

1. `v4.89_Release Run Baseline layer` as the canonical runtime baseline
2. a project-specific starter layer as the current project instantiation
3. `v4.89_Release Reference layer` only as optional reference

## Default position in the system

- **Runtime baseline:** `v4.89_Release Run Baseline layer`
- **Context profile:** `STANDARD`
- **Recommended stage mode for new projects:** `MVP`
- **Recommended reference access:** on-demand, not preloaded

## What this pack optimizes for

- stable cold start
- enough governance/policy context to work normally
- enough subsystem context to execute current project work
- lower context load than `EXPANDED` / `FULL_REFERENCE`
- better daily usability than `LEAN`
