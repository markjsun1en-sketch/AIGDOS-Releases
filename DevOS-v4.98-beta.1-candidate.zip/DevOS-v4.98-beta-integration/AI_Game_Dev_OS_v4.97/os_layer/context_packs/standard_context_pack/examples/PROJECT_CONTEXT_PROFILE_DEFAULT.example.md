# PROJECT_CONTEXT_PROFILE_DEFAULT.md

Default context profile for this project: `STANDARD`

Use `LEAN` for small local tasks and short-lived threads.
Use `EXPANDED` for cross-subsystem changes, architecture work, or policy-sensitive refactors.
Use `FULL_REFERENCE` only for framework audit or historical tracing.
