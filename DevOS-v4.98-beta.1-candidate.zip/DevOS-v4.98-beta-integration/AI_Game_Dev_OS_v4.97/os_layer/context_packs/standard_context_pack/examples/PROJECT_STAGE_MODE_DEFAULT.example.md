# PROJECT_STAGE_MODE_DEFAULT.md

Default stage mode for this project: `MVP`

Escalate to `VERTICAL_SLICE` when the project enters quality, content, and stability hardening.
Escalate to `PRODUCTION_LIKE` only when ownership, regression control, and approval discipline need to be materially stronger.
