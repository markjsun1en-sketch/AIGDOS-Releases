# STANDARD vs LEAN vs EXPANDED

## Use STANDARD when

- starting a new project normally
- doing regular daily implementation
- working within one active subsystem and one project baseline
- you need governance and policy context, but not full historical trace

## Use LEAN when

- the task is narrow and local
- you already know the relevant files
- you want the smallest possible cold start

## Use EXPANDED when

- the task crosses multiple subsystems
- you need broader policy/runbook context
- a refactor touches ownership, gates, workflow, or shared modules

## Use FULL_REFERENCE when

- you are auditing the framework
- you need historical rationale or migration context
- you are comparing legacy rules with the current canonical structure
