# Standard Context Pack Review Checklist

- [ ] Uses `v4.89_Release Run Baseline layer` as canonical runtime baseline
- [ ] Treats `v4.89_Release Reference layer` as optional reference, not default preload
- [ ] Includes project starter layer before project work begins
- [ ] Loads governance main chain before subsystem-local docs
- [ ] Loads only active subsystem domains by default
- [ ] Does not preload archive or full historical reference by default
- [ ] Escalates to Expanded only when scope or ambiguity justifies it
- [ ] Uses Lean only for narrow, local tasks
