# Standard Context Pack Loader Rules

## Default preload set

Load the canonical main chain first:

1. `README.md`
2. `docs/INDEX.md`
3. `docs/CURRENT_BASELINE_AUTHORITY.md`
4. `docs/CORE_ARCHITECTURE_OVERVIEW.md`
5. `docs/CORE_ADAPTATION_EXTENSION_BOUNDARY.md`
6. `docs/GAME_TYPE_ADAPTATION_RULES.md`
7. key governance docs
8. current stage mode overview
9. current project starter files

## Then load only what the current task needs

For normal work, extend the context with:

- the active subsystem domain only
- the active project workflow / validation / gate docs only
- the current task_start_pack or relevant thread pack material only

## Do not preload by default

Do **not** preload:

- archive
- migration notes
- release notes
- legacy governance
- unrelated subsystems
- full source reference

## Escalate to Expanded profile when

Escalate to `EXPANDED` if the task involves one or more of the following:

- cross-subsystem architecture changes
- workflow/gate/policy redesign
- ambiguity in current authority that requires historical tracing
- large refactor affecting shared modules or ownership boundaries
