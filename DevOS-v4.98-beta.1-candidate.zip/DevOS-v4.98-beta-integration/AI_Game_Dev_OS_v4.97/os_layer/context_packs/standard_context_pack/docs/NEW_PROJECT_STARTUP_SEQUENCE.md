# New Project Startup Sequence (Standard)

## Goal

Use the Standard profile to start a new project with enough context to work effectively, but without overloading the agent with full-reference history.

## Sequence

1. Mount `v4.89_Release Run Baseline layer` as the canonical system baseline.
2. Make `v4.89_Release Reference layer` available as **optional reference only**.
3. Add a project starter layer to the project repo.
4. Set the default stage mode for the project.
5. Set the default context profile to `STANDARD`.
6. Load only the currently enabled subsystem domains.
7. For each new thread, start from the project starter files plus the current task pack.

## Minimum project starter files required

- `PROJECT_BASELINE.md`
- `PROJECT_ADAPTATION_PROFILE.md`
- `PROJECT_AGENTS.md`
- `PROJECT_GATES.md`
- `PROJECT_VALIDATION_MATRIX.md`
- `PROJECT_WORKFLOW.md`
- `PROJECT_CONTEXT_PROFILE_DEFAULT.md`
- `PROJECT_STAGE_MODE_DEFAULT.md`
- `PROJECT_DIRECTORY_BOOTSTRAP.md`

## Notes

The Standard profile is the recommended default for:

- new-project setup
- day-to-day implementation
- normal subsystem coordination
- most Codex working threads
