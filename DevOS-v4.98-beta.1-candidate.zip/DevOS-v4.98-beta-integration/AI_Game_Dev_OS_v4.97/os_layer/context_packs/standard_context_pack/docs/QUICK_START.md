# Standard Context Pack Quick Start

## Recommended default combination

- Canonical baseline: `v4.89_Release Run Baseline layer`
- Context profile: `STANDARD`
- Project layer: project starter
- Historical reference: `v4.89_Release Reference layer` (optional)

## For a new project

1. Mount the canonical pack
2. Add the project starter layer
3. Set default stage mode to `MVP`
4. Set default context profile to `STANDARD`
5. Load only the enabled subsystem domains
6. Start the first implementation thread with the relevant task pack
