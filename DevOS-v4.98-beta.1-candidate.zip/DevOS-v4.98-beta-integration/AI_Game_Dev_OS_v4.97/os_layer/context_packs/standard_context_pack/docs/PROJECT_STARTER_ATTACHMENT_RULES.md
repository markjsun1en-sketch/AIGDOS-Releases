# Project Starter Attachment Rules

## Standard profile assumptions

The Standard profile assumes that a project-specific starter layer exists.

## Required attachment points

The project starter should define:

- current project baseline
- project type / engine / stage
- active agents
- active gates
- validation baseline
- workflow routing
- directory bootstrap
- default context profile
- default stage mode

## Relationship to canonical pack

- The canonical pack defines the OS baseline.
- The project starter defines the current project instance.
- The Standard context profile defines the default loading boundary.

## Relationship to full reference pack

The full reference pack is **not** a default preload source. It is used only when the current task requires historical tracing or deeper background.
