# ContextPacks — Resurrected from v4.87

> **Phase 1 §B status**: content in this directory was **copied verbatim from v4.87** (only copy, no modify). Any field rewrite, path TRANSFORM, adapter re-attach, RENAME, etc. is pushed to Phase 2+.

## Origin

- **Source package**: `AI_Game_Dev_OS_v4.87_Stabilization_AdapterObs_Concrete/AI_Game_Dev_OS_v4.87_Optimized_ContextPacks/`
- **Migration action**: `cp -a` whole-package copy (preserves original mtime / permissions / sub-directory structure)
- **Migration date**: 2026-04-21
- **Migration tool**: unix `cp -a`, verified by `diff -rq` (zero diff)
- **Prerequisite decision**: v4.88 9-point locked decision #6 (revive the three-artifact bundle)
- **This action's option**: B1 (strict "only copy, no modify") + P1 (ContextPack elevated to a first-class layer alongside GameTypePack)

## Inventory (5 tiers = 58 files)

| Tier | Files | Notes |
| --- | ---:| --- |
| `Pack_Selection_Guide/` | ~10 | Decision matrix for choosing one of the four tiers |
| `Lean_Context_Pack/` | ~11 | Light tier, minimum context |
| `Standard_Context_Pack/` | ~11 | Standard tier, default recommendation |
| `Expanded_Context_Pack/` | ~11 | Expanded tier, all-Agent scenarios |
| `Full_Reference_Context_Pack/` | ~11 | Reference tier, includes archive |
| Top-level 4 files | 4 | INDEX / README / LAYER_MANIFEST / CONTEXTPACK_RECOMMENDATION_GUIDE |

## Change Log (Phase 3 Step 3.1 finished 2026-04-22)

| Check item | Phase 1–2 state | Phase 3 Step 3.1 state (current) |
| --- | --- | --- |
| Filename casing | ✅ retained v4.87 CamelCase | ✅ **all lower_case_with_underscores** (A2-a: `standard_context_pack/` etc.; IDs renamed in step with directories) |
| v4.87 prefix | ✅ retained | ✅ **removed** (A3-a: long → short names) |
| File contents | ✅ `diff -rq` against the v4.87 source shows zero diff | ⚠️ expected pack ID / path deltas against v4.87 source |
| Path references | ✅ RENAME not executed | ✅ **batch-replaced** |
| `LAYER_MANIFEST.json` version | ✅ not changed | ✅ **bumped to v4.88_first_tier** |

## Phase 2 Backlog (not in Phase 1 scope)

> **2026-04-21 17:10**: after Phase 2 kicked off EP chose **option Y1**, deferring RENAME to Phase 3.
> **2026-04-22 13:56**: Phase 3 Step 3.1 completed the RENAME pass (A1-a + A2-a + A3-a all landed).

### Still Phase 2 (runtime re-attachment)

- [ ] Adapter re-attachment (co-ordinated with GameTypePack)

### New in Phase 3 (moved from Phase 2)

- [ ] RENAME the five tier directories to `lower_case_with_underscores` (PATH_MAPPING_TABLE §B-19~23)
- [ ] Bump the `LAYER_MANIFEST.json` version to v4.88
- [ ] Update the four-tier path references inside `CONTEXTPACK_RECOMMENDATION_GUIDE`
- [ ] Decide on Pack ID ↔ path (ID = directory name vs. adding an ID → path mapping layer)

## Upstream References

- Plan: `086af2bd06074626ae5a1c88358eb6d2` — v4.88 Phase 1 execution plan
- Phase 0 evidence: historical archive, see CHANGELOG "Phase 1 §C" entry
- Decision list: `MEMORY.md §7` 9-point locked decisions

## Relation to GameTypePack

ContextPack provides the **general context layer** (four progressive tiers); GameTypePack provides the **game-type specialisation layer** (four sub-packs). The two are orthogonal; when combined, `assemble_project_attachment.py` first applies the chosen ContextPack tier and then layers the GameTypePack sub-pack content on top. See the source of `scripts/assemble_project_attachment.py` at the same level (v4.87 original, not modified) for details.
