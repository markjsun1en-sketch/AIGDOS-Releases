# v4.91 Batch 0 (B0) — Fast-Gate Runner Finalization Evidence

> ⚠️ **CORRECTION (2026-05-30, RC2-FC1) — the original B0 fix below was
> INCOMPLETE and its evidence was a FALSE POSITIVE.**
>
> A second external review reproduced the very leak B0 claimed to close:
> after a fast-gate timeout, an orphan `pytest` survived. Root cause:
> the fast gate nests process-group-safe runners — the dispatcher wraps
> each F-item via `run_pg_safe_to_file_v2(start_new_session=True)`
> [group A], but the F-item helper ALSO called the runner with
> `start_new_session=True` [group B] to launch pytest. The dispatcher's
> outer `killpg` reaped group A only; pytest in group B escaped. The
> `killed_pg=True` field was a false positive (a signal was *sent* to
> group A; it does not mean the leaf died). The original c4 e2e test was
> itself a false positive — its hang hook deliberately spawned its tree
> WITHOUT a new session, so it never exercised the escaping path.
>
> **Real fix (RC2-FC P0 c1–c3):** `_process_runner` v2 runners gained a
> `new_session` parameter; the dispatcher sets `GATE_IN_SINGLE_ITEM=1`
> on the wrapper and `_runner_imports()` then hands F-item helpers
> runners defaulting to `new_session=False`, keeping pytest/validator in
> the wrapper's group so the dispatcher's single outer `killpg` reaps the
> whole nested tree. Verified two ways: (1) a controlled two-layer
> nesting experiment (orphan before / reaped after); (2) a rewritten
> regression test that FAILS when the fix is reverted and PASSES with it.
>
> **RC2-FC acceptance (2026-05-30):**
> 3× `--fast-total-timeout 300`: dispatcher_exit=0, 25 pass / 0 fail,
> **0 stray** processes each run. tiny-budget `--fast-total-timeout 5`
> negative case: report records timeout/killed, **0 orphan** pytest.
>
> The §3 "3-run evidence" below is the PRIOR cycle's record and is
> retained only as historical lineage. Treat the box above as current.

> ⚠️ **SECOND CORRECTION (2026-05-30, RC2-FC2) — the RC2-FC1 fix above
> was ITSELF incomplete.**
>
> A THIRD external review reproduced the orphan again, on the real F6
> path. RC2-FC1 only fixed the runners the dispatcher obtains via
> `_runner_imports()`. But fast items **F5** (consistency aggregate) and
> **F6** (required regressions) do not spawn pytest through that runner
> directly — they shell out to SECOND-level scripts
> (`check_consistency_aggregate.py` / `check_required_regressions.py`),
> and THOSE call the LEGACY `run_pg_safe` wrapper, which hard-coded
> `new_session=True` (it never exposed the parameter). So the dispatcher
> set `GATE_IN_SINGLE_ITEM=1` and spawned the wrapper in its group, but
> the second-level script's pytest still re-created its own session and
> escaped the outer `killpg`.
>
> **Root-cause fix (RC2-FC2 P0-1):** both legacy wrappers
> (`run_pg_safe` / `run_pg_safe_to_file`) now read `GATE_IN_SINGLE_ITEM`
> and forward `new_session=not nested`. One fix covers F5+F6; env unset →
> `new_session=True` as before (zero regression). **Regression (P0-2):**
> `test_dispatcher_kills_legacy_wrapper_inner_process_group` drives the
> dispatcher→legacy-wrapper→pytest chain (`GATE_TEST_HANG_VIA_LEGACY=1`);
> bidirectional verification (fix→green, revert→reproduces orphan).
>
> **RC2-FC2 acceptance (2026-05-30):** 3× `--fast-total-timeout 300` →
> dispatcher_exit=0, **25/25** pass, **0 stray** each (~11s). 5s negative
> → RC=1, **F6 killed**, 18 skipped, **0 stray**. Full pytest 1763
> passed / 2 skipped. Full closure gate 13/13 PASS in both trees.
> Lesson: nested-killpg must be audited across EVERY spawn layer, not
> just the dispatcher's direct runner — single-layer fixes are false
> negatives.

> **Scope:** RC1-review P0 fix only. Records the maintainer 3-run
> evidence for the fast-gate supervisor rework (c1–c5). Other batches'
> content failures (F5, F6) are documented here as the *correctly
> reported* output of a now-trustworthy gate, NOT as B0 deliverables.
>
> **Layer 1 (OS Spec). No project names.**

---

## 1. What B0 fixed

The RC1 review identified the load-bearing blocker:

> The fast gate's outer supervisor (`_run_fast_item_with_supervisor`)
> wrapped each F-item in a `threading.Thread(daemon=True)` and relied on
> `Thread.join(timeout)`. When the watchdog tripped it only *recorded* a
> timeout and returned — it had no handle on the subprocess (or its
> process group) the F-item helper had spawned. A `pytest --collect-only`
> child (and its grandchildren) kept running after the gate "returned".
> The plan's Batch 0 requirement — *"Timeout kills child/grandchild
> process trees"* — was therefore NOT met.

### Root cause
A daemon thread cannot be killed, and the subprocess started *inside*
the thread inherited no process group the dispatcher could reach with
`killpg`. The PG-safe primitives in `_process_runner.py`
(`run_pg_safe_to_file_v2` + `cleanup_process_group_on_exit`) already
existed — but the supervisor never used them on the per-item dispatch
path, so the kill capability was architecturally stranded.

### Fix (commits c1–c4)
- **c1** — new `--run-single-fast-item <ID>` entry point: each F-item
  can run as its own OS process, emitting one JSON record to stdout.
- **c2** — `_run_fast_item_via_subprocess()` replaces the thread
  watchdog. Each item is launched via
  `run_pg_safe_to_file_v2(timeout=budget, cleanup_process_group_on_exit=True)`
  with `start_new_session=True`, so the dispatcher owns the child's
  pgid and `killpg`s the **entire child/grandchild tree** on budget
  exhaustion. File capture (not PIPE) removes the fd-inheritance
  back-pressure deadlock.
- **c3** — removed the dead daemon-thread watchdog and `import threading`.
  No unkillable execution path remains.
- **c4** — structured `killed_pg` status classification + a
  cross-process regression test
  (`tests/governance/test_fast_gate_supervisor_killpg.py`) that proves
  a hanging item's child **and** grandchild are reaped, leaving zero
  stragglers.

---

## 2. Maintainer 3-run evidence

Command (per run, tree cleaned between runs via `clean_transients.py`):

```
python3 scripts/governance/run_release_closure_gate.py \
  --profile fast --fast-total-timeout 300 --format json
```

Environment: macOS (darwin), CPython 3.13, gate report schema 1.0.0,
23 fast-gate items (F1, F3, F4, F5, F6, F7, F9–F20, F8a–F8d, F2).

Timestamp: 2026-05-29T23:16:43+0800

| Run | dispatcher_exit | overall_exit | elapsed | pass | fail | failing items | stray pytest after |
|-----|-----------------|--------------|---------|------|------|---------------|--------------------|
| 1   | 1               | 1            | 9.347s  | 21   | 2    | F5, F6        | 0                  |
| 2   | 1               | 1            | 9.387s  | 21   | 2    | F5, F6        | 0                  |
| 3   | 1               | 1            | 9.567s  | 21   | 2    | F5, F6        | 0                  |

### What this proves (the B0 acceptance criteria)
- **No hang.** The gate returns deterministically in ~9.4s. The RC1
  symptom (outer 240s timeout with no return) is gone.
- **Process-group-safe.** `stray pytest after = 0` on every run: no
  child/grandchild survives the gate's return.
- **Timeout-safe / killpg proven.** The dedicated regression test
  dispatches a deliberately hanging item with a 3s budget and asserts
  the child (sh) and grandchild (sleep) pids are both dead and the
  record is classified `killed` (supervisor_timeout ∧ killed_pg).
- **Stable PASS/FAIL.** The 21/2 split is byte-reproducible across all
  three runs — the gate now reports the package's *real* state.

---

## 3. Why overall_exit is 1 (and why that is correct)

`overall_exit=1` is **not** a B0 failure. It is the gate correctly
surfacing two pre-existing content failures that belong to other
batches:

- **F5** — `consistency aggregate`: sub-check *5. Schema self-validation
  (pytest)* fails (`rc=1`).
- **F6** — `protected regressions`: 6/11 invariants PASS; the following
  FAIL: `inv_006_capability_id_pattern_intact`,
  `inv_007_schema_version_const_locked`,
  `inv_009_no_auto_rollback_execution`,
  `inv_010_no_auto_level_2_3_promotion`,
  `inv_011_panel_no_runtime_mutation`.

**Attribution.** The B0 c1–c4 changes touched exactly two files:
`scripts/governance/run_release_closure_gate.py` and the new
`tests/governance/test_fast_gate_supervisor_killpg.py`. None of the
scripts F5/F6 invoke were modified. These failures are therefore
**pre-existing**, independent of the gate-runner rework, and are
tracked for resolution under their owning batches before
`v4.91-RC2` / `v4.91-release`.

A trustworthy gate that reports `F5/F6 fail` honestly is the *success
condition* for B0 — it replaces a gate that hung or reported stale
PASS evidence.

---

## 4. Evidence handling note

The raw per-run `fast_gate_report.json` is **runtime-generated
transient** output written under `exports/closure/` and reaped by
`clean_transients.py` (it is excluded from `RELEASE_MANIFEST.json` by
design — pinning it would guarantee drift on the next run). This
markdown file is the durable, manifest-tracked B0 evidence record per
contract #13 (maintainer evidence record: 3-run timestamp).
