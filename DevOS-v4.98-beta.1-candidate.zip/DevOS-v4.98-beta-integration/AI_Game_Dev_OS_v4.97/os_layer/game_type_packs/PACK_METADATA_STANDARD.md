# GameTypePack Metadata Standard

All GameType packs should expose a `manifests/pack_definition.json` with the following fields:

- `pack_name`
- `pack_type`
- `version`
- `genre_domain`
- `depends_on_run_baseline`
- `required_context_pack`
- `optional_reference_layer`
- `recommended_stage`
- `validation_focus`
- `adaptation_rules`
- `do_not_override`
- `entry_docs`

This standard exists to keep all Starter / Pack attachments consistent and machine-readable.
