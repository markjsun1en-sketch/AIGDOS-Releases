# Starter Attachment Standard

This top-level standard mirrors the Run Baseline starter attachment rules so GameTypePack and Starter materials do not drift.

## Required fields
- starter purpose
- maturity
- supported stages
- supported context modes
- compatibility notes
- forbidden overrides
- attach steps

## Boundary rule
A starter may specialize project setup, but it must not redefine baseline truth, acceptance, or ownership rules.
