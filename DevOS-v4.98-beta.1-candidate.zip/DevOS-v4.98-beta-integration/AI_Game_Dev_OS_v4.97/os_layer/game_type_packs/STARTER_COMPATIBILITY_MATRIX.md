# Starter Compatibility Matrix

| Starter | Generic Pack | Card Roguelike | Narrative Puzzle | Spin Rogue Idle |
|---|---:|---:|---:|---:|
| Generic Project Starter | Yes | Conditional | Conditional | Conditional |
| Card Roguelike Project Starter | No | Yes | No | No |
| Narrative Puzzle Project Pack starter docs | No | No | Yes | No |
| Spin Rogue Idle Project Pack starter docs | No | No | No | Yes |

## Rule
`Conditional` means the starter can be adapted, but should not be treated as the default pairing.
