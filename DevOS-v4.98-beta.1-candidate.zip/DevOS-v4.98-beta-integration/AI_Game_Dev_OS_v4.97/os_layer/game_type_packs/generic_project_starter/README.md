# AI Game Dev OS v4.89_Release Generic Project Starter


> **Baseline alias note (v4.90.2+)**:
> "v4.89_Release Run Baseline layer" referenced below is preserved as the
> historical compatible alias of "v4.90_Release Run Baseline layer". Both
> labels resolve to the byte-locked v4.89 reference + the active v4.90
> runtime. Manifests carry `baseline_versions: ["v4.89_Release",
> "v4.90_Release"]`. New v4.91+ packs should write `v4.90_Release`
> directly.

This starter is the generic project instantiation layer for a new project built on top of:

- `v4.89_Release Run Baseline layer` as the canonical runtime baseline
- `v4.89_Release Reference layer` as the full historical/reference layer
- `standard_context_pack` as the default working context profile

## Purpose

Use this starter when you are opening a new project and need a concrete project-level layer that defines:

- project baseline
- project adaptation profile
- active agents
- active gates
- validation baseline
- workflow baseline
- directory bootstrap
- default stage mode and context profile

This starter is generic. It is not specialized for VR, card/roguelike, narrative, or UI-heavy projects.

## What this pack does

It gives a new project a stable instantiation shell without modifying the canonical v4.89_Release system baseline.

## What this pack does not do

It does not replace project-specific adaptation. After using this starter, you should still specialize:

- game type
- engine
- enabled subsystems
- stricter or weaker gates
- project-specific validation evidence

## Recommended default combination

- Baseline system: `v4.89_Release Run Baseline layer`
- Reference layer: `v4.89_Release Reference layer`
- Context profile: `standard_context_pack`
- Starter: `generic_project_starter`
- Stage mode: `MVP`

## Main files

- `templates/PROJECT_BASELINE.md`
- `templates/PROJECT_ADAPTATION_PROFILE.md`
- `templates/PROJECT_AGENTS.md`
- `templates/PROJECT_GATES.md`
- `templates/PROJECT_VALIDATION_MATRIX.md`
- `templates/PROJECT_WORKFLOW.md`
- `templates/PROJECT_CONTEXT_PROFILE_DEFAULT.md`
- `templates/PROJECT_STAGE_MODE_DEFAULT.md`
- `templates/PROJECT_DIRECTORY_BOOTSTRAP.md`
- `templates/STARTER_TASK_START_PACK_TEMPLATE.md`

Start with `docs/QUICK_START.md`.
