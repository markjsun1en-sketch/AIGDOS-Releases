# Project Starter Usage Guide

## When to use this starter

Use this starter when:

- a project is new
- the project type is not yet strongly specialized
- the team needs a stable generic shell first
- the canonical OS baseline is already chosen

## When not to stop at this starter

Do not stop at this starter if the project is clearly:

- VR/MR heavy
- card/roguelike heavy
- narrative heavy
- UI-heavy/meta-heavy

In those cases, start here and then specialize into a type-specific starter pack.

## Expected next step after the generic starter

After the first pass, produce a type-specific adaptation layer with:

- refined agents
- refined gates
- refined validation matrix
- refined enabled subsystems
- refined workflow routing
