# Starter Attachment Rules


> **Baseline alias note (v4.90.2+)**: "v4.89_Release Run Baseline layer"
> mentioned below is preserved as the historical compatible alias of
> "v4.90_Release Run Baseline layer". Both labels resolve to the same
> byte-locked v4.89 reference + active v4.90 runtime; manifest field
> `baseline_versions` carries `["v4.89_Release", "v4.90_Release"]`.

## Role of this starter

This starter is an attachment layer. It should not replace canonical system rules.

## Attachment order

1. `v4.89_Release Run Baseline layer` defines current authority.
2. `standard_context_pack` defines the default working loadset.
3. `generic_project_starter` instantiates the project.
4. `v4.89_Release Reference layer` remains reference-only unless escalation or historical lookup is needed.

## Rules

- Do not redefine core runtime object semantics here.
- Do not redefine thread lifecycle semantics here.
- Do not rename canonical stage modes here.
- Do not introduce project-only handoff semantics that collide with runtime handoff or thread handoff pack semantics.
- Use project delivery language only when defining project-specific downstream deliverables.

## Allowed project specialization

- enabled agents
- enabled subsystems
- workflow routing
- gate criteria emphasis
- validation matrix emphasis
- evidence requirements
- engine-specific directory bootstrap
