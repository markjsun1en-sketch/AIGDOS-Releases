# Quick Start

## Recommended order

1. Attach `v4.89_Release Run Baseline layer` as the canonical system baseline.
2. Keep `v4.89_Release Reference layer` available as reference, not as the default working set.
3. Attach `standard_context_pack` as the default context profile.
4. Copy the templates in this starter into your project docs area.
5. Fill the baseline, adaptation, agents, gates, validation, and workflow files.
6. Generate the first project task start pack from the starter template.

## Minimum files to fill before work begins

- `PROJECT_BASELINE.md`
- `PROJECT_ADAPTATION_PROFILE.md`
- `PROJECT_AGENTS.md`
- `PROJECT_GATES.md`
- `PROJECT_VALIDATION_MATRIX.md`
- `PROJECT_WORKFLOW.md`
- `PROJECT_CONTEXT_PROFILE_DEFAULT.md`
- `PROJECT_STAGE_MODE_DEFAULT.md`
- `PROJECT_DIRECTORY_BOOTSTRAP.md`

## Minimum project decisions required

- project name
- game type
- engine
- current stage mode
- default context profile
- enabled subsystems
- active agents
- expected evidence standard
- repo/doc directory layout
