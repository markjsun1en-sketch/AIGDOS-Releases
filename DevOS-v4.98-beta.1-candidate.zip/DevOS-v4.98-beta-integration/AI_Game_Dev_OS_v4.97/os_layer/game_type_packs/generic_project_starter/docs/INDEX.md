# generic_project_starter Index

This pack is the **generic** adaptation layer.

## Entry docs
- `README.md`
- `docs/QUICK_START.md`
- `docs/STARTER_ATTACHMENT_RULES.md`

## Additional directories
- `templates/`
