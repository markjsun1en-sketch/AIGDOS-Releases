# PROJECT_DIRECTORY_BOOTSTRAP

## Suggested Layout
- /docs/project/
- /docs/contracts/
- /docs/threads/
- /runtime/
- /assets/
- /src/
- /tests/

## OS Attachment Points
- Canonical OS baseline path:
- Project docs root:
- Thread pack storage:
- Delivery bundle storage:
- Validation evidence storage:

## Engine-Specific Notes
- Engine:
- Asset directory conventions:
- Export/build notes:
