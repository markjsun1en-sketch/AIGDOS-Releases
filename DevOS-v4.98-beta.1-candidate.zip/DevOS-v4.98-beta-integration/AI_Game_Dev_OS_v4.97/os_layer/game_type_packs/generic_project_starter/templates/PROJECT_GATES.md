# PROJECT_GATES

## Active Canonical Gates
- Readiness Gate:
- Validation Gate:
- Approval Gate:
- Closure Gate:

## Emphasis Gates
- Playtest Gate:
- Performance Gate:
- Content Batch Gate:
- Narrative/Continuity Gate:
- UI Flow Gate:

## Project Notes
- Which gates are mandatory:
- Which gates are lightweight in MVP:
- Which gates are strict in VS or Production-like:
