# PROJECT_AGENTS

## Active Agents
- Orchestrator:
- Design Planning:
- Art Direction:
- Art Production:
- UI/UX:
- Engineering:
- QA/Validation:

## Optional or Deferred Agents
- Narrative:
- Economy/Numeric:
- Performance:
- Localization:

## Notes
- Which agents are merged in this project:
- Which agents are deferred:
- Which agents are read-only vs writable by default:
