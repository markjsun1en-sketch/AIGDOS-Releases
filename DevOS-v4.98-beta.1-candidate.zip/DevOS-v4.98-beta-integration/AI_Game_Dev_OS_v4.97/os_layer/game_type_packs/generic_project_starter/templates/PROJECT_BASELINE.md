# PROJECT_BASELINE

## Project Identity
- Project Name:
- Working Codename:
- Repository Name:
- Owner:

## Project Classification
- Primary Game Type:
- Secondary Game Type:
- Engine:
- Platform Targets:
- Team Shape:

## Current Runtime Defaults
- Canonical System Baseline: v4.89_Release Run Baseline layer
- Reference Layer: v4.89_Release Reference layer
- Default Context Profile:
- Current Stage Mode:

## Current Goals
- Current Goal Window:
- Current Prototype/VS/Production Objective:
- Current Constraints:

## Current Source of Truth
- Repo Path:
- Project Docs Root:
- Contracts Root:
- Runtime Working Root:
