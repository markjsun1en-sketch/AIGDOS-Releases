# PROJECT_ADAPTATION_PROFILE

## Classification
- Primary Type:
- Secondary Type:
- Primary Risk Domains:
- Primary Review Domains:

## Enabled Subsystems
- Design:
- Art:
- UIUX:
- Additional Subsystems:

## Default Governance Emphasis
- Validation Strength:
- Gate Strictness:
- Approval Strictness:
- Autonomy Level:
- Playtest Dependence:

## Project-Specific Focus
- Core Loop Proof:
- Content Batch Intensity:
- Performance Sensitivity:
- Narrative/Continuity Sensitivity:
- UI/Flow Sensitivity:

## Required Future Specialization
- Which specialized starter should replace or extend this generic starter:
