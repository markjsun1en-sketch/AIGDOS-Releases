# PROJECT_STAGE_MODE_DEFAULT

- Default Stage Mode:
- Why this stage mode is currently selected:
- Conditions for switching to VERTICAL_SLICE:
- Conditions for switching to PRODUCTION_LIKE:
