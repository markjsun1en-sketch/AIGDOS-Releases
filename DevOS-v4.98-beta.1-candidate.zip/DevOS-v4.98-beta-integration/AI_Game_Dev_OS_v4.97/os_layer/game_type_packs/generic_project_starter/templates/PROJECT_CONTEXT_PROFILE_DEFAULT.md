# PROJECT_CONTEXT_PROFILE_DEFAULT

- Default Context Profile: STANDARD
- Use LEAN for: small tasks, bug fixes, narrow follow-ups
- Use EXPANDED for: architecture changes, multi-subsystem work, complex refactors
- Use FULL_REFERENCE for: historical audit, framework conflict analysis, migration review
