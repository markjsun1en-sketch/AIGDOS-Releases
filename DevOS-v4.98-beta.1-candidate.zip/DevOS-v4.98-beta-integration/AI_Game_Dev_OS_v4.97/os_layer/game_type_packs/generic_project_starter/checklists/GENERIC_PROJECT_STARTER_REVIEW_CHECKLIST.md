# Generic Project Starter Review Checklist

- [ ] Project baseline is filled.
- [ ] Project adaptation profile is filled.
- [ ] Active agents are explicitly named.
- [ ] Active gates are explicitly named.
- [ ] Validation baseline is filled.
- [ ] Workflow baseline is filled.
- [ ] Default context profile is set.
- [ ] Default stage mode is set.
- [ ] Directory bootstrap is set.
- [ ] The starter does not redefine core runtime semantics.
- [ ] The starter does not redefine thread pack semantics.
- [ ] The starter does not misuse handoff terminology.
