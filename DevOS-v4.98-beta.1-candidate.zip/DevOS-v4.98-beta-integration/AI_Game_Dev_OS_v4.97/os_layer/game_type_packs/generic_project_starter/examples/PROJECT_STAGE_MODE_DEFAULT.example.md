# Example: PROJECT_STAGE_MODE_DEFAULT

- Default Stage Mode: MVP
- Why this stage mode is currently selected: project is proving core loop and setup viability.
- Conditions for switching to VERTICAL_SLICE: stable core loop, clearer quality targets, stronger validation requirements.
- Conditions for switching to PRODUCTION_LIKE: stable team rhythm, stronger regression discipline, production-oriented closure requirements.
