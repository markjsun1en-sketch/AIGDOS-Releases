# Example: PROJECT_CONTEXT_PROFILE_DEFAULT

- Default Context Profile: STANDARD
- LEAN is allowed for short task-specific bugfix threads.
- EXPANDED is allowed for cross-subsystem refactors.
- FULL_REFERENCE is reserved for framework/history investigations.
