# GameTypePack — Resurrected from v4.87

> **Phase 1 §B status**: content in this directory was **copied verbatim from v4.87** (only copy, no modify). Any field rewrite, path TRANSFORM, adapter re-attach, RENAME, etc. is pushed to Phase 2+.

## Origin

- **Source package**: `AI_Game_Dev_OS_v4.87_Stabilization_AdapterObs_Concrete/AI_Game_Dev_OS_v4.87_Optimized_GameTypePack/`
- **Migration action**: `cp -a` whole-package copy (preserves original mtime / permissions / sub-directory structure)
- **Migration date**: 2026-04-21
- **Migration tool**: unix `cp -a`, verified by `diff -rq` (zero diff)
- **Prerequisite decisions**: v4.88 9-point locked decision #6 (revive the three-artifact bundle) + #7 (GameTypePack as a first-class layer)
- **This action's option**: B1 (strict "only copy, no modify") + P1 (GameTypePack and ContextPack co-exist as first-class layers)

## Inventory (4 sub-packs + 10 top-level = 93 files)

| Sub-pack | Files | Notes |
| --- | ---:| --- |
| `Card_Roguelike_Project_Starter/` | 21 | Card Roguelike project starter pack |
| `Spin_Rogue_Idle_Project_Pack/` | 22 | Slot + Roguelike + Idle project pack (the RandomHeroes prototype) |
| `Narrative_Puzzle_Project_Pack/` | 21 | Narrative-puzzle project pack |
| `Generic_Project_Starter/` | 19 | Generic project starter |
| Top-level 10 files | 10 | INDEX / README / LAYER_MANIFEST / PACK_METADATA_STANDARD / PACK_RECOMMENDATION_MATRIX / PACK_USAGE_AND_CONFLICT_RULES / ASSEMBLY_FLOW_OVERVIEW / STARTER_ATTACHMENT_STANDARD / STARTER_COMPATIBILITY_MATRIX / GAMETYPEPACK_RECOMMENDATION_GUIDE |

## Change Log (Phase 3 Step 3.1 finished 2026-04-22)

| Check item | Phase 1–2 state | Phase 3 Step 3.1 state (current) |
| --- | --- | --- |
| Filename casing | ✅ retained v4.87 CamelCase | ✅ **all lower_case_with_underscores** (A2-a decision: `card_roguelike_project_starter/` etc.; IDs renamed in step with directories) |
| v4.87 prefix | ✅ retained (`AI_Game_Dev_OS_v4.87_Optimized_*`) | ✅ **removed** (A3-a decision: long → short names; v4.87 provenance is carried by this document instead) |
| File contents | ✅ `diff -rq` against the v4.87 source shows zero diff | ⚠️ expected pack ID / path deltas against v4.87 source (introduced by A1-a / A2-a / A3-a); everything else stays byte-identical |
| Path references | ✅ RENAME not executed | ✅ **batch-replaced** (11 JSON `pack_name` entries + ~78 markdown back-tick IDs + markdown link paths) |
| `LAYER_MANIFEST.json` version | ✅ not changed (still `v4.87_optimized_first_tier`) | ✅ **bumped to v4.88_first_tier** |

## Phase 2 Backlog (not in Phase 1 scope)

> **2026-04-21 17:10**: after Phase 2 kicked off EP chose **option Y1**, deferring RENAME to Phase 3.
> **2026-04-22 13:56**: Phase 3 Step 3.1 completed the RENAME pass (A1-a + A2-a + A3-a all landed).

### Still Phase 2 (runtime re-attachment)

- [ ] `assemble_project_attachment.py` path adaptation to the new scaffold (TRANSFORM)
- [ ] Adapter re-attachment onto the v4.88 Runtime Profile layer

### New in Phase 3 (moved from Phase 2)

- [ ] RENAME sub-pack directories to `lower_case_with_underscores` (PATH_MAPPING_TABLE §A-11~14)
- [ ] Split the 10 top-level files into `docs/08_gametypepack/` (PATH_MAPPING §A-1~10)
- [ ] Bump the `LAYER_MANIFEST.json` version to v4.88
- [ ] Decide on Pack ID ↔ path (ID = directory name vs. adding an ID → path mapping layer)

## Upstream References

- Plan: `086af2bd06074626ae5a1c88358eb6d2` — v4.88 Phase 1 execution plan
- Phase 0 evidence: historical archive, see CHANGELOG "Phase 1 §C" entry
- Decision list: `MEMORY.md §7` 9-point locked decisions
