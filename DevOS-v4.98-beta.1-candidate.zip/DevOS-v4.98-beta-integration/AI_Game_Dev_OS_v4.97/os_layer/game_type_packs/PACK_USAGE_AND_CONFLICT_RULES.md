# Pack Usage and Conflict Rules

## Basic Principles

1. Starters / Packs only cover project-type adaptation — they do not replace the OS's own runtime rules.
2. A type Pack may add validation focus, starter templates, patterns, and adaptation notes.
3. If a type Pack's field definition, state definition, or gate rule conflicts with the v4.87 Run Baseline, the v4.87 Run Baseline wins.

## Recommended Choice

- Project type unclear: start with `generic_project_starter`.
- Card / deck-builder: use `card_roguelike_project_starter`.
- Narrative + puzzle: use `narrative_puzzle_project_pack`.
- Idle / spin / rogue-lite: use `spin_rogue_idle_project_pack`.
