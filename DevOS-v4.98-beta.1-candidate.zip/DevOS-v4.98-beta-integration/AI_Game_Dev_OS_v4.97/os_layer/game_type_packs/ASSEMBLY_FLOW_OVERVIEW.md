# GameTypePack Assembly Flow Overview

This overview turns the Starter / GameTypePack layer from a documentation-only concept into a repeatable attachment flow.

## Core rule
Attach in this order:
1. Run Baseline
2. Stage Policy
3. ContextPack
4. GameTypePack
5. Optional Starter companion (only when the selected pack allows it)
6. Reference on demand

## Selection boundaries
- A ContextPack controls load density, not runtime truth.
- A GameTypePack controls genre adaptation and validation focus.
- A Starter may scaffold project setup, but must not override baseline truth, acceptance, or ownership rules.

## Operational path
Use the Run Baseline scripts to resolve a selection into an exported attachment manifest:
- `scripts/assemble_project_attachment.py`
- `scripts/run_attachment_preview.sh`
- `scripts/verify_attachment_preview.sh`
