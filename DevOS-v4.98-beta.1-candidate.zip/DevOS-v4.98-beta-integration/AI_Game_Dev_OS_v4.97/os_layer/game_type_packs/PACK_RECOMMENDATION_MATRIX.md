# Pack Recommendation Matrix

| Project profile | Recommended GameTypePack | Notes |
|---|---|---|
| New project, pack undecided | Generic Project Starter | Start light and specialize later |
| Deckbuilder / run combat | Card Roguelike Project Starter | Best when card systems drive validation |
| Story + puzzle progression | Narrative Puzzle Project Pack | Best when narrative pacing and puzzle gates dominate |
| Spin + idle + roguelite meta | Spin Rogue Idle Project Pack | Best when economy and idle loops are core |
