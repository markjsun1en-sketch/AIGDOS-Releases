# GameTypePack Recommendation Guide

## Purpose
This guide helps select the right GameTypePack without relying on archive-only background knowledge.

## Recommendations
- **Generic Project Starter**: use when project genre fit is still broad or starter behavior should stay minimal.
- **Card Roguelike Project Starter**: use for deckbuilding, run-based combat, and card-centric progression.
- **Narrative Puzzle Project Pack**: use when narrative flow, pacing, and puzzle structure dominate the validation focus.
- **Spin Rogue Idle Project Pack**: use for spin economy, idle/meta loops, and roguelite progression combinations.

## Selection rule
Choose the pack that best matches the dominant validation focus of the project, not the broadest list of possible mechanics.
