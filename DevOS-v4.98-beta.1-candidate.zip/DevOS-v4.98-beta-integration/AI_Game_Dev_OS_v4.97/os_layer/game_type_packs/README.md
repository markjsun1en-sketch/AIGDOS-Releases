# AI Game Dev OS v4.89_Release GameTypePack

This package holds **project-type Starters / Genre Packs**, to be assembled on demand by new projects.

## Scope

- This area stores type templates, Starters, genre experience, and adaptation material.
- It does not store any running project's registry / snapshot / issue / handoff state.
- When a statement here conflicts with the Run Baseline, the Run Baseline wins.

## Loading Order

1. Always load the `Run Baseline` first.
2. Choose a Stage Policy and a ContextPack.
3. Attach a Starter / Pack from this directory based on the project type.

## Currently Included

- `generic_project_starter`
- `card_roguelike_project_starter`
- `narrative_puzzle_project_pack`
- `spin_rogue_idle_project_pack`

- `GAMETYPEPACK_RECOMMENDATION_GUIDE.md`

## Attachment and assembly
Use the Run Baseline attachment preview scripts together with these docs to validate a GameTypePack selection before making it a project default.

Key references:
- `ASSEMBLY_FLOW_OVERVIEW.md`
- `PACK_RECOMMENDATION_MATRIX.md`
- `STARTER_COMPATIBILITY_MATRIX.md`
