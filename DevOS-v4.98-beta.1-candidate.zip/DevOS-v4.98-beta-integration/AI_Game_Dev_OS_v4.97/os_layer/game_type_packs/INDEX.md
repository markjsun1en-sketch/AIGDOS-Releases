# GameTypePack Index

GameTypePack is the project-type adaptation layer.

## Available packs
- `generic_project_starter`
- `card_roguelike_project_starter`
- `narrative_puzzle_project_pack`
- `spin_rogue_idle_project_pack`

## Rule of use
A GameTypePack may add:
- starter templates
- genre patterns
- validation focus
- adaptation notes

A GameTypePack may **not** replace Run Baseline contracts.

- `GAMETYPEPACK_RECOMMENDATION_GUIDE.md`

## Attachment and assembly
Use the Run Baseline attachment preview scripts together with these docs to validate a GameTypePack selection before making it a project default.

Key references:
- `ASSEMBLY_FLOW_OVERVIEW.md`
- `PACK_RECOMMENDATION_MATRIX.md`
- `STARTER_COMPATIBILITY_MATRIX.md`
