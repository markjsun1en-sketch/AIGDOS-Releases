
# PROJECT_STAGE_MODE_DEFAULT

Default Stage Mode: MVP

Escalate to VERTICAL_SLICE once the project needs stronger validation for balance, progression, and content quality.
