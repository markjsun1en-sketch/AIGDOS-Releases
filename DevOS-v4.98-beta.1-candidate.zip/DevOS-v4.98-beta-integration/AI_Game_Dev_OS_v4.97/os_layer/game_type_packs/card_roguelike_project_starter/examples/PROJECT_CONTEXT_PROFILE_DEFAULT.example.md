
# PROJECT_CONTEXT_PROFILE_DEFAULT

Default Context Profile: STANDARD

Use Expanded when reviewing large card batches, economy overhauls, or progression redesign.
