
# Card / Roguelike Project Starter Review Checklist

- Project baseline clearly identifies card / roguelike as the primary type.
- Active agents cover system design, numeric balance, progression/meta, and content batch responsibilities.
- Validation matrix distinguishes one-off content from batch content.
- Batch policy defines when stronger checks are required.
- Simulation baseline explains when evidence is mandatory.
- Default context profile is explicit.
- Default stage mode is explicit.
- Project directory bootstrap separates project-side content/config from canonical OS docs.
