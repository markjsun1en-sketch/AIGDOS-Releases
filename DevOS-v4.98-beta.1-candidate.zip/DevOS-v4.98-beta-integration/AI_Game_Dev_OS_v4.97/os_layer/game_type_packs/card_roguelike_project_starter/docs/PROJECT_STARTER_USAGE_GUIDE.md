
# Project Starter Usage Guide

Use this starter when the project's design burden is dominated by content systems, build variety, balance, and progression tuning.

## Best fit

- deckbuilders
- card roguelikes
- relic / item heavy runs
- turn-based build optimization games
- content-heavy tactics roguelites with strong config surfaces

## Less ideal fit

- VR-first interaction projects
- pure narrative games
- projects where movement feel and spatial comfort dominate all other concerns

## How to customize

- expand or merge agents depending on team size
- strengthen or weaken simulation requirements by stage
- define batch size thresholds for content review
- specify economy and progression evidence outputs
