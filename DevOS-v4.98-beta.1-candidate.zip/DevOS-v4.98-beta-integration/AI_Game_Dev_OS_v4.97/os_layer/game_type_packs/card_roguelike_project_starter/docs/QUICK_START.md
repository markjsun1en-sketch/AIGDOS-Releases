
# Quick Start

1. Attach this starter on top of `v4.89_Release Run Baseline layer`.
2. Keep `v4.89_Release Reference layer` available as reference only; do not treat archive/reference as the default working set.
3. Fill out the templates in this order:
   - `PROJECT_BASELINE.md`
   - `PROJECT_ADAPTATION_PROFILE.md`
   - `PROJECT_AGENTS.md`
   - `PROJECT_GATES.md`
   - `PROJECT_VALIDATION_MATRIX.md`
   - `PROJECT_WORKFLOW.md`
   - `PROJECT_CONTENT_BATCH_POLICY.md`
   - `PROJECT_SIMULATION_BASELINE.md`
4. Set default context profile to `STANDARD` unless the task is tiny enough for `LEAN`.
5. Start in `MVP` unless the project already requires stronger balance, content batch control, and evidence discipline.
6. Create a first `STARTER_TASK_START_PACK_TEMPLATE.md` for the initial playable loop.

## Recommended first milestone

For a card / roguelike project, the first practical milestone is:

- one complete run loop
- one stable combat/battle resolution loop
- one minimal card or item pool
- one reward and progression loop
- one minimal content batch validation path
