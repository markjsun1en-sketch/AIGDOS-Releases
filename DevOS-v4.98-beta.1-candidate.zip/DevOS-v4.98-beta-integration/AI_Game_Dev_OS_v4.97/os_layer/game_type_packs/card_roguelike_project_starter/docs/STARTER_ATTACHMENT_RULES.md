
# Starter Attachment Rules


> **Baseline alias note (v4.90.2+)**: "v4.89_Release Run Baseline layer"
> mentioned below is preserved as the historical compatible alias of
> "v4.90_Release Run Baseline layer". Both labels resolve to the same
> byte-locked v4.89 reference + active v4.90 runtime; manifest field
> `baseline_versions` carries `["v4.89_Release", "v4.90_Release"]`.

This starter is an adaptation layer. It must not replace or redefine the canonical system baseline.

## Attach to

- `v4.89_Release Run Baseline layer` for runtime baseline, governance, policies, and subsystem structure
- `standard_context_pack` for default working context rules

## Reference only

- `v4.89_Release Reference layer` is for historical or archival lookup
- Do not use archive/reference content as the primary rule source when current canonical docs already answer the question

## Override scope

This starter may specialize:

- project agents
- workflow routing
- gate emphasis
- validation evidence requirements
- content batch safety rules
- simulation requirements
- subsystem emphasis

This starter must not redefine:

- core runtime objects
- thread lifecycle packs
- canonical handoff semantics
- canonical stage mode naming
