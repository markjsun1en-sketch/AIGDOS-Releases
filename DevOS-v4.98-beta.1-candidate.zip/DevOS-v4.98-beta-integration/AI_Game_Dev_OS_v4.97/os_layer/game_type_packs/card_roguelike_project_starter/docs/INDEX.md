# card_roguelike_project_starter Index

This pack is the **card_roguelike** adaptation layer.

## Entry docs
- `README.md`
- `docs/QUICK_START.md`
- `docs/STARTER_ATTACHMENT_RULES.md`

## Additional directories
- `templates/`
