
# AI Game Dev OS v4.89_Release Card / Roguelike Project Starter


> **Baseline alias note (v4.90.2+)**:
> "v4.89_Release Run Baseline layer" referenced below is preserved as the
> historical compatible alias of "v4.90_Release Run Baseline layer". Both
> labels resolve to the byte-locked v4.89 reference + the active v4.90
> runtime. Manifests carry `baseline_versions: ["v4.89_Release",
> "v4.90_Release"]`. New v4.91+ packs should write `v4.90_Release`
> directly.

This starter is the project instantiation layer for card, deckbuilding, roguelike, and build-oriented projects built on top of:

- `v4.89_Release Run Baseline layer` as the canonical runtime baseline
- `v4.89_Release Reference layer` as the full historical/reference layer
- `standard_context_pack` as the default working context profile

## Purpose

Use this starter when a new project is primarily driven by:

- deck / build construction
- content combinatorics
- numeric balance and economy tuning
- progression / meta design
- simulation evidence
- large configuration surfaces
- batch content generation and validation

## What this pack adds

Compared with the Generic Project Starter, this pack gives stronger defaults for:

- system design ownership
- numeric balance and progression review
- content batch gating
- simulation evidence requirements
- economy and build variance validation
- content-safe workflow routing

## Recommended default combination

- Baseline system: `v4.89_Release Run Baseline layer`
- Reference layer: `v4.89_Release Reference layer`
- Context profile: `standard_context_pack`
- Starter: `card_roguelike_project_starter`
- Stage mode: `MVP` for prototype, `VERTICAL_SLICE` once balance and content depth matter

## Main files

- `templates/PROJECT_BASELINE.md`
- `templates/PROJECT_ADAPTATION_PROFILE.md`
- `templates/PROJECT_AGENTS.md`
- `templates/PROJECT_GATES.md`
- `templates/PROJECT_VALIDATION_MATRIX.md`
- `templates/PROJECT_WORKFLOW.md`
- `templates/PROJECT_CONTENT_BATCH_POLICY.md`
- `templates/PROJECT_SIMULATION_BASELINE.md`
- `templates/PROJECT_CONTEXT_PROFILE_DEFAULT.md`
- `templates/PROJECT_STAGE_MODE_DEFAULT.md`
- `templates/PROJECT_DIRECTORY_BOOTSTRAP.md`
- `templates/STARTER_TASK_START_PACK_TEMPLATE.md`

Start with `docs/QUICK_START.md`.
