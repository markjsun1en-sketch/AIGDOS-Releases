
# PROJECT_DIRECTORY_BOOTSTRAP

## Recommended Project-Side Roots
- `docs/project/`
- `docs/project/baseline/`
- `docs/project/validation/`
- `docs/project/batches/`
- `docs/project/runs/`
- `data/cards/`
- `data/relics/`
- `data/items/`
- `data/enemies/`
- `data/progression/`
- `data/economy/`

## Notes
- Keep project config/content separate from canonical OS docs.
- Use project-side docs for current balance, progression, and content batch specifics.
- Keep runtime/threading packs in the canonical system structure unless intentionally mirrored for project workflows.
