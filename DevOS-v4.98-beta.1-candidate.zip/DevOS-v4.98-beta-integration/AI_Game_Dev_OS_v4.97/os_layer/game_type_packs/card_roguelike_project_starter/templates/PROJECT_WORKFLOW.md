
# PROJECT_WORKFLOW

## Recommended Baseline Flow
1. Design intent defined
2. Numeric / progression implications identified
3. Content batch or single-item scope classified
4. Required validation path chosen
5. Simulation or sanity evidence generated if needed
6. Human review applied where thresholds require it
7. Closure only after evidence is attached

## Routing Notes
- Treat batch content work differently from one-off feature work.
- Route economy and progression changes through stronger validation than simple content copy.
- Route exploit-risk or runaway-synergy changes to explicit review even in MVP.

## Handoff / Delivery Notes
- Design outputs should use delivery bundles, not runtime handoff semantics.
- Thread lifecycle rules still follow canonical task/thread packs from the main system.
