
# PROJECT_CONTENT_BATCH_POLICY

## Purpose
Define when card / relic / item / enemy / modifier batches can move fast and when they require stronger checks.

## Batch Classes
- Small batch:
- Medium batch:
- Large batch:

## Required Checks By Batch Class
- Small batch:
- Medium batch:
- Large batch:

## Escalation Triggers
- repeated schema failures
- duplicated effects or excessive overlap
- economy spikes
- exploit loops
- runaway synergy clusters
- progression pacing distortion

## Closure Requirement
No batch is considered closed until the required evidence bundle is attached.
