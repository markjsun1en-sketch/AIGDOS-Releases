
# PROJECT_ADAPTATION_PROFILE

## Type Profile
- Primary Type: Card / Roguelike / Build-Oriented
- Secondary Types:
- Build Variety Importance: Low / Medium / High
- Numeric Balance Importance: Low / Medium / High
- Progression / Meta Importance: Low / Medium / High
- Batch Content Importance: Low / Medium / High

## Default Emphasis
- Simulation Evidence: Optional / Recommended / Required
- Content Batch Safety: Weak / Standard / Strong
- Economy Curve Review: Weak / Standard / Strong
- Build Variance Review: Weak / Standard / Strong

## Default Enabled Subsystems
- Design:
- UIUX:
- Art:
- Engineering (project-side if present):
- QA / Simulation (project-side if present):

## Default Working Assumptions
- Primary playable proof target:
- Primary balance risk:
- Primary content scaling risk:
