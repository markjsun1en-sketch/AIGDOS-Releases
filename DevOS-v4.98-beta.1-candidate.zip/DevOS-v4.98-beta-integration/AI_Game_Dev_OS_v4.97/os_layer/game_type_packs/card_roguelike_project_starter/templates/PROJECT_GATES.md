
# PROJECT_GATES

## Recommended Gate Emphasis
- Readiness Gate
- Simulation Evidence Gate
- Content Batch Gate
- Progression Consistency Gate
- Validation Gate
- Closure Gate

## Gate Notes
- Use stronger content batch review once the project starts generating many cards, relics, enemies, or modifiers per sprint.
- Use stronger simulation evidence once balance tuning begins affecting run viability or economy pacing.
- Escalate to stronger closure criteria in `VERTICAL_SLICE` and beyond.

## Project-Specific Thresholds
- Batch size requiring structured review:
- Changes requiring simulation before merge:
- Changes requiring manual playtest before closure:
