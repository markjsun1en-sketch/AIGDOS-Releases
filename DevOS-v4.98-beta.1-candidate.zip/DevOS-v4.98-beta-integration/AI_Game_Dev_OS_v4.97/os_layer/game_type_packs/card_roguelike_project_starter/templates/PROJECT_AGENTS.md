
# PROJECT_AGENTS

## Recommended Active Agents
- System Design Agent
- Numeric Balance Agent
- Progression / Meta Agent
- Content Batch Agent
- UIUX Agent
- Art Agent(s) as needed
- QA / Simulation Agent (or equivalent responsibility)

## Minimal Solo-Friendly Merge Option
- Design + Numeric + Progression combined
- Content Batch folded into Design until scale increases
- QA / Simulation handled as explicit validation responsibility instead of full separate role

## Ownership Focus
- System rules and card/item logic ownership:
- Numeric thresholds and balance ownership:
- Progression / economy ownership:
- Content batch preparation ownership:
- Validation evidence assembly ownership:
