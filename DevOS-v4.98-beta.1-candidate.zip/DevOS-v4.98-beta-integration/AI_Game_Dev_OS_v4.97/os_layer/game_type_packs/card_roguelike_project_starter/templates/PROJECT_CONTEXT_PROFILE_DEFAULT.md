
# PROJECT_CONTEXT_PROFILE_DEFAULT

Default Context Profile: STANDARD

## Override Guidance
- Use Lean for tiny scoped fixes with stable local context.
- Use Expanded for large content batch reviews, progression overhauls, or cross-subsystem changes.
- Use Full Reference only for framework-level audit, migration, or historical trace work.
