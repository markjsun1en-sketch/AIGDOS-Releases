
# PROJECT_VALIDATION_MATRIX

| Change Type | Minimum Validation | Recommended Evidence | Human Review Required | Notes |
|---|---|---|---|---|
| New card / item / relic | schema/config validation | design note + quick sanity output | Sometimes | strengthen after batch scale increases |
| Numeric adjustment | config validation | before/after numbers + simulation summary | Often | especially for economy and run viability |
| Progression / meta change | logic/config validation | progression curve note + economy evidence | Often | stronger in VS |
| Content batch update | batch validation | batch summary + anomaly list | Usually | use batch policy |
| Reward table / shop / drop tuning | config validation | distribution summary + economy note | Usually | avoid drift and exploit loops |
| UI surfacing of build/progression data | UI spec validation | walkthrough note | Sometimes | depends on player-facing complexity |
