
# STARTER_TASK_START_PACK_TEMPLATE

## Task Identity
- Task Name:
- Task Type: feature / tuning / batch / progression / ui / validation
- Scope Size: small / medium / large

## Direct Objective
- Primary output:
- Required evidence:
- Required review:

## Card / Roguelike Specific Notes
- Affected content pools:
- Affected economy/progression systems:
- Expected synergy risk:
- Batch class if applicable:

## Context Attachments
- Relevant baseline docs:
- Relevant project docs:
- Relevant data/config roots:
