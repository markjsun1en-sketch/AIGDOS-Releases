
# PROJECT_BASELINE

## Project Identity
- Project Name:
- Short Name:
- Working Title:
- Repo Name:

## Core Type
- Primary Type: Card / Roguelike / Build-Oriented
- Secondary Type(s):
- Engine:
- Target Platforms:

## Current Stage
- Stage Mode: MVP / VERTICAL_SLICE / PRODUCTION_LIKE
- Current Milestone:
- Current Sprint Objective:

## Core Loop Focus
- Run Loop:
- Battle / Resolution Loop:
- Reward Loop:
- Meta / Progression Loop:

## Current Source of Truth
- Primary baseline docs:
- Active project docs:
- Active data/config roots:
