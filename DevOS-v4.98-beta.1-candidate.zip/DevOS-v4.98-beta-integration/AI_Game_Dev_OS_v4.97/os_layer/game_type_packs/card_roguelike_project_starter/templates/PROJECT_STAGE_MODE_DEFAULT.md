
# PROJECT_STAGE_MODE_DEFAULT

Default Stage Mode: MVP

## Escalation Guidance
- Move to `VERTICAL_SLICE` when balance, progression, and content quality need stronger gates and evidence.
- Move to `PRODUCTION_LIKE` only when ownership, regression discipline, and operational rigor must be consistently enforced.
