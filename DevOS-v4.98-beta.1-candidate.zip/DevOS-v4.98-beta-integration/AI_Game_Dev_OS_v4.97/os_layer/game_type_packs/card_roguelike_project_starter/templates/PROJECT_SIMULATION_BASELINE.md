
# PROJECT_SIMULATION_BASELINE

## Purpose
Define the minimum simulation or structured sanity evidence used by this project.

## Recommended Use Cases
- balance-sensitive numeric changes
- reward / shop / drop distribution changes
- progression curve changes
- new high-impact synergy introductions
- large content batch releases

## Minimum Evidence Types
- parameter diff summary
- anomaly list
- distribution or trend summary
- notable outlier note
- human interpretation note

## Stage Guidance
- MVP: use lightweight simulation or structured sanity checks where possible
- VERTICAL_SLICE: stronger simulation evidence for balance and progression
- PRODUCTION_LIKE: treat major economy or content batch changes as evidence-heavy by default
