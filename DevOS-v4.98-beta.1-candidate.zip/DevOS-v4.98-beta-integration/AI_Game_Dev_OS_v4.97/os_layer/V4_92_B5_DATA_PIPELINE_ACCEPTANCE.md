---
title: V4.92 B5 Data Pipeline Acceptance
version: 1.0
status: active
layer: root_meta
since_batch: B5
---

# v4.92 Batch 5 — Data Pipeline Vertical Slice Acceptance Evidence

> **Date**: 2026-05-31 · **Pack**: `data_pipeline_pack` · **Target**: an independent Slot+Roguelike Godot 4.4 project (separate git repo).
> Vertical slice acceptance for Charter §5.2 P0-9.

---

## 1. Target data-pipeline defect (before)

- `set_nested_value` (target `policy/tools/data/xlsx_to_json.py`) walked the path
  as dict keys only; it could not inject into array elements.
- The `heroes` table used `$hero_id` injection (`["heroes","$hero_id","animations"]`)
  and was therefore marked `skip_convert: true` — `heroes.json` was hand-merged.
- The pity Monte Carlo (`game/tests/pity_montecarlo_validation.py`) was an isolated
  script, not a pipeline gate.

## 2. Fix applied (target repo, Sprint 10)

| Change | File |
|---|---|
| `set_nested_value` v2 — `$key` array-element injection (group by field, match element, index by `state`, raise on unmatched) | `policy/tools/data/xlsx_to_json.py` |
| `postprocess_heroes` — flat columns → nested `base_stats`/`growth`/`leveling`; `hero_id`→`id`; drop redundant `hero_id`/`state` from injected records; split `frame_paths` ";"-string into a list | `policy/tools/data/xlsx_to_json.py` |
| remove `skip_convert` from `heroes` | `game/data/xlsx/manifest.json` |
| regenerate `heroes.json` from xlsx | `game/data/heroes.json` |

## 3. Equivalence vs hand-merged file

Regenerated `heroes.json` hero element vs the backed-up hand-merged version:

```
PASS id           (hero_01)
PASS base_stats   ({"hp":100,"atk":10,"def":5,"spd":10})
PASS growth       ({"hp":8,"atk":1.5,"def":0.8,"spd":0.3,"decay_after":15,"decay_rate":0.5})
PASS leveling     ({"exp_base":20,"exp_linear":5,"exp_quad":2,"exp_cubic":0.5,"max_level":30})
animation states  9/9 (idle walk run dash attack fight hit_react victory happy)
sfx states        9/9
battle_formula    preserved (preserve_keys)
heroes validator  PASS
```

## 4. Pity gate integration

```
$ pity_gate.py game/tests/pity_montecarlo_validation.py \
    --pass-sentinel "ALL TESTS PASSED" --fail-sentinel "TESTS FAILED"
pity_gate: PASS — pass sentinel 'ALL TESTS PASSED' found   (exit 0)
```

The simulation already prints `ALL TESTS PASSED ✅`; the gate turns that into a
blocking exit status the pipeline can act on.

## 5. Full-chain acceptance

Edit one xlsx field → auto-convert → validate → runtime data updated:

```
STEP1 edit xlsx:        hero_stats.base_hp 100 -> 150
STEP2 auto-convert:     heroes[0].base_stats.hp = 150
STEP3 validator heroes: PASS
STEP4 runtime updated:  PASS

FULL_CHAIN_ACCEPTANCE: PASS
```

## 6. OS-side verification

- `test_data_pipeline_pack` 13/13 (incl. heroes-shape `$key` injection unit test,
  unmatched-key raise, schema_check, pity_gate sentinels).
- pack passes Batch 1 schema + Batch 2 boundary linter + Batch 2 practicality gate.
- `validate_data_pipeline_pack.py` reports coherent under bare python3.

## 7. Rollback

Target files backed up before edit (`xlsx_to_json.py`, `manifest.json`,
`heroes.json`). Revert = restore the three files; the fix is additive and the
old `skip_convert` path still works if restored.
