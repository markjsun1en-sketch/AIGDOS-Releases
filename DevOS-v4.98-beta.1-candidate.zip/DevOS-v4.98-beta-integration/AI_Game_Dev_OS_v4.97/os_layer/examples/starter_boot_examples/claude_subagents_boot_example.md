# Claude Code Subagents Boot Example

1. Read START_HERE and execution profile selection.
2. Choose the Claude Code Subagents runtime profile.
3. Install or adapt `CLAUDE.md.template`, `SUBAGENTS.template.md`, and `HOOKS.template.json`.
4. Confirm the main agent owns writeback during the first beta sprint.
5. Run bounded tasks through the shared starter templates.
