# Codex Boot Example

1. Read START_HERE.
2. Select the Codex runtime profile.
3. Load `starters/codex/AGENTS.md.template` into the project adaptation layer.
4. Create a task-local boot block from `starters/codex/BOOT_BLOCK.md`.
5. Validate the chosen profile with `scripts/validate_execution_profile.py`.
6. Run the controlled beta sprint path.
