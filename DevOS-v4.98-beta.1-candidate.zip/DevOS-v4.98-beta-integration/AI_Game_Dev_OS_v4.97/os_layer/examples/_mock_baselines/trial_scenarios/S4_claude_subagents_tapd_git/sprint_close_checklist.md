# Sprint Close Checklist — sprint-s4 (S4 Claude subagents FAIL sample, post-M7.3 Lift gate)

## Initialization integrity
- [x] Runtime environment initialized without demo residue
- [x] Runtime profile selection explicit (`claude_code_subagents`) and validated
- [x] Starter family slice identifiable (`starters/claude_code_subagents/`)

## Execution integrity
- [x] Worker execution followed claude profile (parent_subagents)
- [x] Worktree isolation respected for both tasks
- [x] Serial merge.apply executed
- [x] No unresolved dirty state (FT-302 cleanup deferred but main is clean)

## External sync integrity
- [x] 2/2 TAPD writes validated
- [x] FT-301 read-after-write verify performed
- [x] Parent/child aggregation state not stale

## Evidence integrity
- [x] Audit log parseable (17 events)
- [x] Handoff + validation evidence for both tasks
- [x] Conditional findings documented in trial.check

## Close integrity
- [x] Sprint snapshot generated
- [x] Archive transition recorded
- [x] Delta summary in trial.check (conditional findings listed)

> Checklist fully ticked — operator acknowledges FT-302's missing
> tapd.verify + deferred merge.cleanup are acceptable non-ideal
> outcomes per BETA_SPRINT_EXIT_CRITERIA §Acceptable non-ideal
> outcomes. The verifier should still surface these as WARN findings
> on the audit log, yielding overall verdict CONDITIONAL.
