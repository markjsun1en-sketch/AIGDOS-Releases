# S4 — Claude Code Subagents + TAPD + Git (FAIL, post-M7.3 Lift gate)

> **Mock scenario calibrating the M7.3 Lift gate** — demonstrates how
> the GUIDED-tier verifier escalates a contract-surface gap (init
> writing `runtime_state.json` without all four canonical fields) to
> ERROR and yields an overall `FAIL / exit=2`. Pre-M7.3 (≤2026-05-05)
> this same fixture was tagged `CONDITIONAL / exit=1`; the change is
> the **intended hardening**, not a regression.

## Verdict history

| Era | Expected verdict | Why |
| --- | --- | --- |
| **Pre-M7.3** (≤ 2026-05-05) | `CONDITIONAL / 0 ERROR / 1 WARN / exit=1` | SCAFFOLD tier — only the missing `external.tapd.verify` was caught (1 WARN). Missing contract fields in `runtime_state` were silently accepted. |
| **Post-M7.3** (≥ 2026-05-06, current) | `FAIL / 2 ERROR / 2 WARN / exit=2` | GUIDED tier — M7.3 Lift gate (commit `6414cac`, tag `v4.89-phase-4-lift`) requires init to canonically write the contract surface; missing `audit_collector` + `context_loading_method` now ERROR. The two WARNs (missing `external.tapd.verify` + missing `merge.cleanup`) remain. |

## Why S4 exists (post-M7.3 framing)

`BETA_SPRINT_EXIT_CRITERIA.md` allows a sprint to "still count as
valid" if "one or more items are marked conditional pass but clearly
logged". S4 originally instantiated this WARN-only path. After M7.3
the Lift gate added a second, stricter axis — **missing contract
fields in `runtime_state` are not acceptable, even when the operator
has acknowledged the WARN-tier gaps**. S4 now tests that both axes
fire together: the operator-acknowledged WARN gaps remain visible
**plus** the contract gap correctly escalates to FAIL.

## Diff vs S1 (golden sample)

| Aspect | S1 (codex, PASS) | S4 (claude subagents, FAIL) |
| --- | --- | --- |
| `runtime_type` | `codex` | `claude_code_subagents` |
| Task count | 3 | 2 |
| `audit_collector` in runtime_state | present | **missing** → 1 ERROR (M7.3) |
| `context_loading_method` in runtime_state | present | **missing** → 1 ERROR (M7.3) |
| `external.tapd.verify` coverage | 3/3 | **1/2** — FT-302 verify omitted → 1 WARN |
| `merge.cleanup` coverage | 3/3 | 1/2 — FT-302 cleanup deferred → 1 WARN |
| Final verdict | PASS (0 ERROR / 0 WARN) | **FAIL (2 ERROR / 2 WARN)** |

## Trigger mechanism

S4 fires **two** trigger axes in parallel:

### Axis A — M7.3 Lift gate (2 ERROR)

`runtime_state.json` is intentionally captured **without** two of the
four canonical contract-surface fields that init must write per M7.3:

- `audit_collector` — missing → 1 ERROR
- `context_loading_method` — missing → 1 ERROR

The schema-driven cross-check (`runtime/schema_driven_check.py`) treats
absence of these fields as a Lift-gate violation rather than silently
defaulting. This proves the M7.3 hardening is wired end-to-end.

### Axis B — SCAFFOLD pair-matching (2 WARN)

`sample_audit.jsonl` deliberately omits two events:

- No `external.tapd.verify` paired with `external.tapd.write` for FT-302
  → `check_external_sync_integrity` emits 1 WARN.
- No `merge.cleanup` paired with `merge.apply` for FT-302
  → `check_execution_integrity` emits 1 WARN.

Note: the v4.90 Batch 0.5 GUIDED upgrade may tighten `check_execution` to
treat `cleanup_count < apply_count` as ERROR; that upgrade would
re-classify the second WARN to ERROR but the verdict (FAIL) would not
change — the M7.3 ERRORs already dominate.

## Operator judgement reflected in checklist

Even though the audit log is incomplete on Axis B, the operator ticked
every `sprint_close_checklist.md` item to record that they reviewed
the gap and deemed it WARN-acceptable (per EXIT_CRITERIA §Acceptable
non-ideal outcomes). `check_close_integrity` therefore does not ERROR
— close integrity is about operator acknowledgement, external sync
integrity is about data trust, contract surface is about init's
producer-side honesty. The three checks are independent.

## Files in this directory

| File | Purpose |
| --- | --- |
| `runtime_state.json` | claude_code_subagents profile, 2 archived tasks; **deliberately missing audit_collector + context_loading_method** to trigger the M7.3 ERROR pair |
| `sample_audit.jsonl` | 17 events (1 verify + 1 cleanup deliberately missing → 2 WARN) |
| `handoff.json` | 2 engineering→qa handoffs, all resolved |
| `sprint_close_checklist.md` | All 15 items ticked (operator accepted the WARN gaps) |
| `expected_verdict.json` | Current contract: `FAIL / 2 ERROR / 2 WARN / exit=2`; carries `history.pre_m7_3_expected` for traceability |

## Expected verifier output

```bash
python scripts/verify_beta_sprint_exit.py \
    --audit-log examples/_mock_baselines/trial_scenarios/S4_claude_subagents_tapd_git/sample_audit.jsonl \
    --runtime-state examples/_mock_baselines/trial_scenarios/S4_claude_subagents_tapd_git/runtime_state.json \
    --sprint-close-checklist examples/_mock_baselines/trial_scenarios/S4_claude_subagents_tapd_git/sprint_close_checklist.md \
    --sprint sprint-s4 --profile claude_code_subagents
```

Returns `verdict: "FAIL"`, `error_count: 2`, `warn_count: 2`,
`exit_code: 2`. The two ERRORs are on category `init`; the two WARNs
are on category `external`.

## What this scenario proves

1. The M7.3 Lift gate is wired end-to-end: missing canonical
   contract-surface fields in `runtime_state` correctly produce ERROR
   findings rather than silently passing.
2. ERROR-tier findings dominate the verdict: even though the operator
   acknowledged the WARN-tier gaps via the checklist, the contract gap
   is non-negotiable.
3. Verdict-aware tooling can still distinguish the gap categories —
   `error_count` vs `warn_count` is preserved, so callers that care
   about WARN-only escalation paths can read both fields.
4. Pre-M7.3 → post-M7.3 contract evolution is auditable: the
   `expected_verdict.json` `history` block records both eras, and the
   transition anchor (`commit 6414cac`, `tag v4.89-phase-4-lift`) is
   embedded in the fixture itself.
