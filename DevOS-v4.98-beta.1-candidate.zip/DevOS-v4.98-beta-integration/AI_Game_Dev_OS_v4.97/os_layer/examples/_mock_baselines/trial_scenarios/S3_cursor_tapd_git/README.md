# S3 — Cursor + TAPD + Git (PASS, Profile Switch Validation)

> **Diff-against-S1 Mock scenario** — verifies that the same verifier
> logic passes cleanly on a different runtime profile (`cursor`
> instead of `codex`).

## Why S3 exists

`TRIAL_SCENARIO_MATRIX.md` defines S3 as "Cursor + TAPD + Git, one
parallel implementation slice, compare runtime profile behavior". The
Mock emphasizes the **profile switch dimension** without changing the
verification contract — both S1 and S3 should verdict `PASS`.

## Diff vs S1 (golden sample)

| Aspect | S1 (codex) | S3 (cursor) |
| --- | --- | --- |
| `runtime_type` | `codex` | `cursor` |
| `coordination_model` | `parent_subagents` | `parallel_agents` |
| `writeback_owner` | `parent` | `reviewed_apply_owner` |
| Task count | 3 | 2 |
| `merge.apply.actor` | `engineering` | `reviewed_apply_owner` |

Everything else (event families, ticking pattern, serial merge
contract) is identical to S1.

## Files in this directory

| File | Purpose |
| --- | --- |
| `runtime_state.json` | Sprint id, cursor profile, 2 archived tasks |
| `sample_audit.jsonl` | 20 events (parallel work, serial merge) |
| `handoff.json` | 2 engineering→qa handoffs, all resolved |
| `sprint_close_checklist.md` | All 15 items ticked |
| `expected_verdict.json` | `PASS` contract for Step 3 smoke test |

## Expected verifier output

```bash
python scripts/verify_beta_sprint_exit.py \
    --audit-log examples/_mock_baselines/trial_scenarios/S3_cursor_tapd_git/sample_audit.jsonl \
    --runtime-state examples/_mock_baselines/trial_scenarios/S3_cursor_tapd_git/runtime_state.json \
    --sprint-close-checklist examples/_mock_baselines/trial_scenarios/S3_cursor_tapd_git/sprint_close_checklist.md \
    --sprint sprint-s3 --profile cursor
```

Returns `verdict: "PASS"`, `error_count: 0`, `warn_count: 0`,
`exit_code: 0`.

## What this scenario proves

The SCAFFOLD-tier verifier is **profile-agnostic** — it checks the
structural properties of the audit log and state file, not
profile-specific semantics. The v4.90 Batch 0.5 GUIDED upgrade will add
profile-aware checks (e.g. isolation_unit vs branches touched,
writeback_owner vs merge.apply.actor cross-checks).

See S1 for the complete walk-through of the 5 integrity checks.
