# S5b — Workbuddy Private + TAPD + Git (Hardened-Pass Sample)

> **Mock scenario for `verify_beta_sprint_exit.py` regression (B+ phase)**
> — this directory is the **hardened-pass complement** to S5. Where S5
> demonstrates what the verifier flags when the Workbuddy Private trial
> is broken, S5b demonstrates what a **clean** Workbuddy Private trial
> looks like after every B+ hardening target is satisfied.

## Why S5b exists

B+ Bridge Hardening promoted `init_integrity`, `evidence_integrity`,
and `close_integrity` from SCAFFOLD to GUIDED. The existing S5 sample
was intentionally broken (FAIL contract) to exercise the deep checks.
S5b is its positive twin — same profile, same three checks run at
GUIDED tier, but every integrity category is clean.

Keep S5 for the "this is what FAIL looks like" demo. Read S5b for
the "this is what PASS looks like on the Workbuddy path" demo.

## Profile snapshot

From `config/profiles/workbuddy_private.json`:

| Field | Value |
| --- | --- |
| `runtime_type` | `workbuddy_private` |
| `coordination_model` | `private_coordinated` |
| `isolation_unit` | `project_defined` |
| `writeback_owner` | `main_session` |
| `cleanup_owner` | `main_session` |
| `merge_mode` | `serial` |

The Mock `runtime_state.json` mirrors these exactly. Crucially,
`dirty_worktree=false` — this is what keeps C10's init.GUIDED rule
("dirty_worktree + isolation_unit=project_defined -> ERROR") quiet.

## Files in this directory

| File | Purpose |
| --- | --- |
| `runtime_state.json` | Sprint id, profile, 2 archived tasks, closed_at non-null, audit_dir + tapd_config_path + git_info fields |
| `sample_audit.jsonl` | 20 events across 11 families (full lifecycle with complete pair-up) |
| `handoff.json` | 2 engineering→qa handoffs, both resolved |
| `sprint_close_checklist.md` | All 17 items ticked |
| `expected_verdict.json` | `PASS` contract for Step 3 smoke test |

## Expected verifier output

```bash
python3 scripts/verify_beta_sprint_exit.py \
    --audit-log examples/_mock_baselines/trial_scenarios/S5b_workbuddy_private_hardened_pass/sample_audit.jsonl \
    --runtime-state examples/_mock_baselines/trial_scenarios/S5b_workbuddy_private_hardened_pass/runtime_state.json \
    --sprint-close-checklist examples/_mock_baselines/trial_scenarios/S5b_workbuddy_private_hardened_pass/sprint_close_checklist.md \
    --sprint sprint-s5b --profile workbuddy_private
```

Returns `verdict: "PASS"`, `error_count: 0`, `warn_count: 0`,
`exit_code: 0`.

## What each of the 5 checks sees (post-B+)

### check 1 — Initialization integrity (GUIDED)
- `runtime_state.json` parses and has all required fields
- declared profile = `workbuddy_private` matches `--profile` ✅
- `initialized_at` is ISO 8601 ✅
- `dirty_worktree=false` under `isolation_unit=project_defined` ✅
  (edge case C.2 satisfied)
- no demo residue

### check 2 — Execution integrity (SCAFFOLD)
- 4 `runtime.transition` events ✅
- 2 `merge.apply` + 2 matching `merge.cleanup` events ✅

### check 3 — External sync integrity (SCAFFOLD)
- 2 `external.tapd.write` events each paired with `external.tapd.verify` ✅
- all 2 verifies have `verification_ok=true` ✅

### check 4 — Evidence integrity (GUIDED)
- audit log has 20 parseable lines ✅
- every event has event_type + timestamp + actor + status ✅
- all 4 coverage classes present: runtime_create, external, merge,
  trial_or_archive ✅
- timestamps monotonically increasing ✅

### check 5 — Close integrity (GUIDED)
- `sprint_close_checklist.md` has 17 ticked items, 0 unticked ✅
- `runtime_state.closed_at` is non-null ✅
- terminal events: `runtime.archive` + `trial.check` ✅
- 2 `merge.apply` + 2 matching `merge.cleanup` by `task_id` ✅

## Narrative timeline

```
08:55  sprint-s5b initialized (runtime_state.json + .workbuddy/ overlay)
09:00  FT-501 / FT-502 created from sprint spec
09:30  FT-501 engineering work begins
09:45  FT-502 engineering work begins
12:00  FT-501 handoff engineering -> qa
12:30  FT-501 qa validation pass
12:35  FT-501 validation_pending -> done
12:40  FT-501 TAPD writeback + verify (verification_ok=true)
13:00  FT-502 handoff -> qa
13:30  FT-502 qa validation pass
13:35  FT-502 validation_pending -> done
13:40  FT-502 TAPD writeback + verify (verification_ok=true)
15:30  FT-501 merge into integration + cleanup
15:50  FT-502 merge into integration + cleanup
17:30  sprint-s5b snapshot generated
18:00  sprint-s5b archive
18:05  trial.check close: sprint_close_readiness = pass
18:05  runtime_state.closed_at updated
```

## Relationship to S5

S5 and S5b share the same profile and isolation model.  The intent is
a 1:1 delta pair:

| Aspect | S5 (FAIL) | S5b (PASS) |
| --- | --- | --- |
| `dirty_worktree` | `true` | `false` |
| `closed_at` | `null` | set |
| TAPD verify | `verification_ok=false` | `verification_ok=true` |
| `merge.cleanup` | missing | present, paired |
| Checklist | 10 unticked | all ticked |
| Terminal events | none | `runtime.archive` + `trial.check` |

Reading the two fixtures side-by-side shows exactly what a B+-
hardened Workbuddy Private trial must satisfy for the Exit Verifier's
GUIDED tier to emit PASS.
