# S1 — Codex + TAPD + Git (Golden Sample, PASS)

> **Mock scenario for `verify_beta_sprint_exit.py` regression** — this
> directory is the **golden sample** that demonstrates what a clean
> Beta Sprint close looks like to the SCAFFOLD-tier verifier.

## Why S1 exists

`docs/09_beta_sprint/TRIAL_SCENARIO_MATRIX.md` defines S1 as "Codex +
TAPD + Git, one small feature wave, default first trial". This Mock
instantiates that scenario with three features (`FT-101` / `FT-102`
/ `FT-103`) walking through the **full minimum trial scope**:

- one sprint kickoff
- three runtime tasks created and transitioned
- three TAPD writebacks each paired with a read-after-write verify
- three serial merges each paired with a cleanup
- one snapshot + one archive + one trial.check close

Every integrity category passes, so the verifier's expected verdict is
`PASS` with `error_count=0` and `warn_count=0`.

## Profile snapshot

From `config/profiles/codex.json`:

| Field | Value |
| --- | --- |
| `runtime_type` | `codex` |
| `coordination_model` | `parent_subagents` |
| `isolation_unit` | `worktree` |
| `writeback_owner` | `parent` |
| `cleanup_owner` | `parent` |
| `merge_mode` | `serial` |

The Mock `runtime_state.json` mirrors these values exactly so
`check_init_integrity` finds no profile mismatch.

## Files in this directory

| File | Purpose |
| --- | --- |
| `runtime_state.json` | Sprint id, profile, 3 tasks with archived state |
| `sample_audit.jsonl` | 28 events across 11 event families (full lifecycle) |
| `handoff.json` | 3 engineering→qa handoffs, all resolved |
| `sprint_close_checklist.md` | All 17 items ticked |
| `expected_verdict.json` | `PASS` contract for Step 3 smoke test |

## Expected verifier output

```bash
python scripts/verify_beta_sprint_exit.py \
    --audit-log examples/_mock_baselines/trial_scenarios/S1_codex_tapd_git/sample_audit.jsonl \
    --runtime-state examples/_mock_baselines/trial_scenarios/S1_codex_tapd_git/runtime_state.json \
    --sprint-close-checklist examples/_mock_baselines/trial_scenarios/S1_codex_tapd_git/sprint_close_checklist.md \
    --sprint sprint-s1 --profile codex
```

Returns `verdict: "PASS"`, `error_count: 0`, `warn_count: 0`,
`exit_code: 0`.

## What each of the 5 checks sees

### check 1 — Initialization integrity
- `runtime_state.json` parses as JSON ✅
- declared `profile` = `codex` matches `--profile codex` ✅
- result: no findings

### check 2 — Execution integrity
- audit log has 6 `runtime.transition` events ✅
- 3 `merge.apply` events, 3 matching `merge.cleanup` events ✅
- result: no findings

### check 3 — External sync integrity
- 3 `external.tapd.write` events, all have matching
  `external.tapd.verify` by `(task_id, object_id)` ✅
- all verifies have `verification_ok=true` ✅
- result: no findings

### check 4 — Evidence integrity
- audit log exists, 28 lines, parseable ✅
- evidence families represented: `runtime.validation`,
  `runtime.handoff`, `runtime.snapshot`, `trial.check` ✅
- result: no findings

### check 5 — Close integrity
- `sprint_close_checklist.md` has 17 ticked items, 0 unticked ✅
- terminal events present: `runtime.archive` + `trial.check` ✅
- result: no findings

## Narrative timeline

```
08:55  sprint-s1 initialized (runtime_state.json written)
09:00  FT-101 / FT-102 / FT-103 created from spec
09:10  FT-101 engineering work begins
10:00  FT-102 engineering work begins
11:00  FT-103 engineering work begins
12:30  FT-101 handoff engineering -> qa
13:00  FT-101 qa validation pass
13:05  FT-101 validation_pending -> done
13:10  FT-101 TAPD writeback + verify
14:00  FT-102 handoff -> qa (...)
14:35  FT-102 TAPD writeback + verify
15:00  FT-103 handoff -> qa (...)
15:40  FT-103 TAPD writeback + verify
16:30  FT-101 merge into main + cleanup
16:45  FT-102 merge into main + cleanup
17:00  FT-103 merge into main + cleanup
17:30  sprint-s1 snapshot generated
18:00  sprint-s1 archive (FT-101/102/103 done -> archived)
18:05  trial.check close: sprint_close_readiness = pass
```

## How to extend

When a future scenario wants to show a variant of this golden path
(e.g. "what if merge.cleanup is delayed?"), **copy this directory**
and delete / mutate only the event(s) that change behavior. Keeping
S1 as the diff base makes the verdict delta obvious to readers.
