# S5 — Workbuddy Private + TAPD + Git (FAIL, Invalid Trial Signals)

> **Mock scenario calibrating FAIL verdict** — demonstrates how the
> SCAFFOLD-tier verifier surfaces BETA_SPRINT_EXIT_CRITERIA "invalid
> trial signals" as ERROR findings that yield an overall verdict of
> `FAIL` (exit=2) — the kind of sprint that should **not** be
> considered a valid Beta Sprint trial.

## Why S5 exists

`BETA_SPRINT_EXIT_CRITERIA.md §Invalid trial signals` lists several
patterns that invalidate a sprint trial: runtime profile never
actually selected, TAPD state not trustworthy, merge ownership
unclear, audit evidence absent or unreadable, cleanup leaving the
runtime in a dirty state. S5 Mock stacks several of these into one
scenario so the verifier surfaces multiple ERROR findings across
categories.

## Diff vs S1 (golden sample)

| Aspect | S1 (codex, PASS) | S5 (workbuddy_private, FAIL) |
| --- | --- | --- |
| `runtime_type` | `codex` | `workbuddy_private` |
| `isolation_unit` | `worktree` | `project_defined` |
| Task count | 3 all archived | 2 (1 done, 1 still in_progress) |
| TAPD verify | all `verification_ok=true` | **1 `verification_ok=false` after 2 retries** |
| Merge cleanup | 3/3 | 0/1 — cleanup never ran |
| Terminal event | `runtime.archive` + `trial.check` | **none** |
| Checklist | 17/17 ticked | 6/16 ticked — 10 items left unticked |
| Final verdict | PASS (0 errors) | **FAIL (2 errors + 2 warnings)** |

## Trigger mechanisms (multiple, stacked)

1. **external ERROR**: `external.tapd.verify` for FT-401 has
   `verification_ok=false` after 2 retries. `check_external` emits
   ERROR (not WARN) because a failed verify is a silent-failure red
   flag per `AUDIT_LOG_STANDARD §Red Flags` §"status write succeeded
   but verification failed".
2. **close ERROR**: `sprint_close_checklist.md` has 10/16 items
   unticked. `check_close` ERRORs because close integrity requires
   all items ticked.
3. **execution WARN**: `merge.apply` event present but no
   `merge.cleanup` — the current SCAFFOLD check emits WARN only
   when cleanup_count is zero.
4. **close WARN**: no `runtime.archive` or `trial.check` terminal
   event recorded — the sprint was abandoned rather than closed.

FT-402 never transitions past `in_progress`, but the SCAFFOLD checks
do not cross-reference runtime_state.tasks against the audit log.
The v4.90 Batch 0.5 GUIDED upgrade will add that check; until then,
the existing WARN/ERROR already push the verdict to FAIL.

## Files in this directory

| File | Purpose |
| --- | --- |
| `runtime_state.json` | workbuddy_private profile, dirty_worktree=true, 1 task still in_progress |
| `sample_audit.jsonl` | 10 events (missing cleanup + terminal; 1 verify failure) |
| `handoff.json` | 1 engineering→qa handoff (FT-402 never handed off) |
| `sprint_close_checklist.md` | 6/16 items ticked (operator did not acknowledge close readiness) |
| `expected_verdict.json` | `FAIL` contract (≥2 errors, expected_exit_code=2) |

## Expected verifier output

```bash
python scripts/verify_beta_sprint_exit.py \
    --audit-log examples/_mock_baselines/trial_scenarios/S5_workbuddy_private_tapd_git/sample_audit.jsonl \
    --runtime-state examples/_mock_baselines/trial_scenarios/S5_workbuddy_private_tapd_git/runtime_state.json \
    --sprint-close-checklist examples/_mock_baselines/trial_scenarios/S5_workbuddy_private_tapd_git/sprint_close_checklist.md \
    --sprint sprint-s5 --profile workbuddy_private
```

Returns `verdict: "FAIL"`, `error_count: 2`, `warn_count: 2`,
`exit_code: 2`. ERROR findings span categories `external` and
`close`; WARN findings span `execution` and `close`.

## What this scenario proves

1. Verdict `FAIL` (exit=2) is the blocking signal for CI /
   orchestrator pipelines — this sprint should not be treated as a
   valid Beta Sprint trial.
2. Multiple independent ERRORs can coexist and the verifier reports
   all of them (operator decides which to fix first).
3. `verification_ok=false` on TAPD verify is treated as stricter than
   "verify missing" (S4) — the former is an operator-visible
   confirmed-bad state, the latter is an incomplete-audit state.
4. A sprint-close checklist with unticked items is the single
   clearest "trial is not ready to close" signal — it translates
   directly to ERROR without needing any cross-reference.
