# Trial Scenarios — v4.89 Mock Verification Pack

> **Phase 4 Step 2 deliverable (2026-04-22)**. Each scenario below is an
> **in-repo Mock fixture** that `scripts/verify_beta_sprint_exit.py` can be
> pointed at to demonstrate how the SCAFFOLD-tier 5 integrity checks
> translate into a PASS / CONDITIONAL / FAIL verdict. They are **not**
> runtime traces from a real project — real-project trial runs are
> v4.89 scope per 9-decision #5 ("harden, do not expand").

## Purpose

These Mock scenarios close three Phase 4 requirements simultaneously:

1. **Golden-sample regression** for `verify_beta_sprint_exit.py` (Step 3
   smoke test re-runs all 4 scenarios and compares stdout JSON against
   `expected_verdict.json`).
2. **Narrative examples** for `docs/USAGE_GUIDE.md` (Step 4) and
   `docs/PHASE_4_TRIAL_GUIDE.md` (Step 5) — readers can inspect a
   concrete `runtime_state.json` + `sample_audit.jsonl` + handoff +
   checklist to understand what a Beta Sprint leaves behind.
3. **Verdict calibration** — by covering all three verdict tiers we
   give new projects a reference point for "what does CONDITIONAL
   actually look like?"

## Scenario matrix

| Scenario | Runtime Profile | `isolation_unit` | Expected verdict | Trigger |
| --- | --- | --- | --- | --- |
| [S1_codex_tapd_git](S1_codex_tapd_git/) | `codex` | `worktree` | **PASS** | Golden sample — full kickoff → 3 tasks → TAPD write+verify → merge apply+cleanup → handoff → validation → archive → trial.check close |
| [S3_cursor_tapd_git](S3_cursor_tapd_git/) | `cursor` | `worktree` | **PASS** | Profile switch validation — mirrors S1 structure with `writeback_owner="reviewed_apply_owner"` and parallel-agents coordination |
| [S4_claude_subagents_tapd_git](S4_claude_subagents_tapd_git/) | `claude_code_subagents` | `worktree` | **FAIL** (post-M7.3) | Dual trigger — (1) runtime_state omits `audit_collector` + `context_loading_method` → 2 ERROR via M7.3 Lift gate; (2) drops one `external.tapd.verify` → 1 WARN; no `merge.cleanup` → 1 WARN. Pre-M7.3 expected was CONDITIONAL/exit=1; post-M7.3 the same fixture correctly escalates to FAIL/exit=2. |
| [S5_workbuddy_private_tapd_git](S5_workbuddy_private_tapd_git/) | `workbuddy_private` | `project_defined` | **FAIL** | Deliberately leaves `sprint_close_checklist.md` items unticked (close ERROR) and a `verification_ok:false` tapd event (external ERROR) |

Scenario S2 (recovery drill on Codex) is intentionally **deferred to
v4.89** per `docs/09_beta_sprint/TRIAL_SCENARIO_MATRIX.md` — Phase 4
covers first-trial scope only.

## Directory anatomy

Every scenario directory has the **same six files** (for easy diffing):

```
<scenario>/
  ├── README.md                 # narrative + expected verdict + triggers
  ├── runtime_state.json        # profile + isolation_unit + sprint id
  ├── sample_audit.jsonl        # 10–30 events covering the minimum trial scope
  ├── handoff.json              # handoff chain (engineering → qa → …)
  ├── sprint_close_checklist.md # tick-state matches expected verdict
  └── expected_verdict.json     # what verify_beta_sprint_exit.py should return
```

## Usage

Each scenario is verified via:

```bash
python scripts/verify_beta_sprint_exit.py \
    --workspace examples/_mock_baselines/trial_scenarios/<scenario_id> \
    --audit-log examples/_mock_baselines/trial_scenarios/<scenario_id>/sample_audit.jsonl \
    --runtime-state examples/_mock_baselines/trial_scenarios/<scenario_id>/runtime_state.json \
    --sprint-close-checklist examples/_mock_baselines/trial_scenarios/<scenario_id>/sprint_close_checklist.md \
    --sprint <sprint_id_from_state> \
    --profile <profile_from_state>
```

Or, in Phase 4 Step 3 smoke test form:

```bash
bash scripts/run_mock_smoke.sh
```

The harness invokes the verifier against all 4 scenarios, writes each
`actual_verdict.json` next to its `expected_verdict.json`, and
returns exit 0 only if every scenario's (verdict, exit_code) pair
matches its contract. See `docs/09_beta_sprint/PHASE_4_STEP_3_SMOKE_REPORT.md`
for the authoritative latest pass record.

## Cross-references

- `docs/09_beta_sprint/BETA_SPRINT_EXIT_CRITERIA.md` — 5 integrity
  category definitions and script binding (Phase 4 Step 1 updated)
- `docs/09_beta_sprint/TRIAL_SCENARIO_MATRIX.md` — original S1–S5
  scenario catalog
- `docs/05_observability/AUDIT_LOG_STANDARD.md` — canonical event type
  families Mock audit files emit
- `config/profiles/*.json` — canonical `isolation_unit` /
  `writeback_owner` / `coordination_model` values each scenario's
  `runtime_state.json` must match
- `scripts/verify_beta_sprint_exit.py` — the verifier under test
- `examples/_mock_baselines/beta_sprint_tapd_git/` — earlier Phase 3 narrative example
  (S1 here is a leaner, verifier-oriented sibling)
