# Sample Beta Sprint Timeline

> **Note (REV-3-019, 2026-04-22)**: "Day 0" activities below are **pre-sprint setup**, not counted in the sprint working-day total. The TAPD Sprint iteration is created as part of pre-sprint setup so that sprint working days (Day 1+) can assume the iteration already exists. This aligns with `BETA_SPRINT_READY_GUIDE.md` which lists TAPD config validation in "Pre-sprint".

## Day 0 (pre-sprint setup)
- select runtime profile: codex
- run init with no demo data
- verify required files
- validate TAPD config (`scripts/validate_execution_profile.py` + manual review of `integrations/tapd/tapd_config.template.json`)
- create Sprint iteration in TAPD

## Day 1
- create parent story and child tasks
- complete first small task in isolated worktree
- perform first verified TAPD writeback

## Day 2
- execute parallel worker tasks
- queue serial merges
- run daily inspection and audit summary

## Day 3
- perform close candidate review
- reconcile any failed verification or state mismatch
- run sprint close checklist
- run `scripts/verify_beta_sprint_exit.py` and produce `pilot_evaluation.md` (per `Pilot_Evaluation_Checks.md`)
