# Beta Sprint Example — TAPD + Git (Codex Profile)

> **Status (REV-5-001, 2026-04-22)**: upgraded from "Example Placeholder" to a **runnable narrative example** during Phase 3 Step 2. The sample files below walk through one feature's complete lifecycle and can be inspected with the v4.89 scripts listed at the bottom. A **second-project trial run** (where a project actually executes these scripts end-to-end) is v4.90 work.

## What this example demonstrates

A single feature `FT-001` progressing through a 4-day Beta Sprint using:

- **Codex profile** (parent-driven subagents, worktree isolation, parent-owned writeback)
- **TAPD** as external collaboration layer
- **Git** as version control layer
- **v4.89 portable baseline** (Registry Writeback Contract + Architecture Linter [Rule C real; A/B/D stub — see `docs/05_architecture_linter/README.md`] + Managed Autonomy Guardrails + 5 adapter stubs + Route A scripts all active; inherits the v4.88-stable layout)

## Files in this directory

| File | Purpose | Size |
| --- | --- | --- |
| `README.md` | This guide | — |
| `boot_sequence.md` | Step-by-step Codex profile boot sequence | — |
| `sample_beta_sprint_timeline.md` | Day-by-day narrative (Day 0 pre-sprint + Day 1-3 execution) | — |
| `sample_task_registry.json` | Registry snapshot at sprint close (was 2-line stub; now shows FT-001 full lifecycle) | — |
| `sample_tapd_sync_report.json` | TAPD writeback + verification report for FT-001 | — |
| `sample_mcp_audit.jsonl` | 12 audit events spanning all 11 event families (REV-3-004 populated) | 12 lines |

## How to inspect this example

### Read the narrative

1. Start with `boot_sequence.md` to see how Codex profile boots
2. Follow `sample_beta_sprint_timeline.md` Day 0 → Day 3 for the task lifecycle
3. Cross-check against `sample_task_registry.json` for the registry state at each milestone
4. Verify external state match via `sample_tapd_sync_report.json`

### Parse the audit trail

```bash
# summarize audit events by family
python scripts/read_audit.py examples/_mock_baselines/beta_sprint_tapd_git/sample_mcp_audit.jsonl --summary

# filter for FT-001 runtime transitions
python scripts/read_audit.py examples/_mock_baselines/beta_sprint_tapd_git/sample_mcp_audit.jsonl --filter task_id=FT-001 event_type=runtime.transition

# check TAPD verification results
python scripts/read_audit.py examples/_mock_baselines/beta_sprint_tapd_git/sample_mcp_audit.jsonl --filter event_type=external.tapd.verify
```

### Simulate a sprint close gate

```bash
# run the 5-category integrity checker against the example state
python scripts/verify_beta_sprint_exit.py --sprint sprint-1 --profile codex
```

Expected output at v4.89 level: a JSON report showing MIXED-tier checks running (init/evidence/close run at GUIDED inherited from the v4.88-stable B+ Bridge Hardening line; execution/external still SCAFFOLD, awaiting v4.90 GUIDED promotion).

## What this example does NOT yet do

Per 9-decision #5 ("harden, do not expand"), v4.89 **continues to stop at "inspectable narrative example"** (inheriting from v4.88_Revise). The following belong to v4.90 trial work:

- **End-to-end reproducibility**: a true `run_demo.sh` that re-creates all 12 audit events from seed data and verifies each with structured assertions (v4.87 had `run_minimal_tier2_demo.sh` + `verify_demo_outputs.sh`; REV-5-001 Phase 4 target)
- **Real TAPD credentials**: the sync report is hand-crafted sample data, not live TAPD API responses
- **GUIDED-tier verifier integration**: the 5 integrity categories in `verify_beta_sprint_exit.py` need real state parsers (currently SCAFFOLD per `runtime/MATURITY_MATRIX.md`)

## Cross-references

- `docs/09_beta_sprint/BETA_SPRINT_READY_GUIDE.md` — pre-sprint readiness
- `docs/09_beta_sprint/BETA_SPRINT_EXIT_CRITERIA.md` — 5 integrity categories this example narrates
- `docs/06_runtime_profiles/codex/` — profile used in this example
- `docs/04_integrations/TAPD_Integration_Baseline.md` — TAPD contract
- `docs/05_observability/AUDIT_LOG_STANDARD.md` — audit schema this example emits
- `scripts/read_audit.py` — reader used above
- `scripts/verify_beta_sprint_exit.py` — exit-gate checker
