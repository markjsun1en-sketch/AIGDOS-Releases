# boot_sequence

1. unpack package into project root
2. copy `config/runtime_config.beta_sprint.template.json` to local runtime config
3. fill TAPD workspace and sprint values
4. run `python scripts/init_runtime_env.py --project-id <id> --runtime-profile codex`
5. run `python scripts/run_beta_sprint_check.py`
6. kickoff sprint after checklist passes
