# `_mock_baselines/` — Mock Verification Fixtures

> **Semantic**: these are **Mock fixtures** — hand-crafted sample data
> used to exercise the verifier and runtime harness. They are **not**
> records from a real project sprint. Real-project trial evidence
> belongs in a sibling directory (e.g. `examples/real_trials/`)
> when such evidence exists.

## Why the `_mock_` prefix

The leading underscore signals two things:

1. **Sort order** — these directories sort before the other `examples/`
   subfolders, making it obvious at a glance that the rest of
   `examples/` contains different kinds of material (non-verification
   examples, profile selection samples, starter boot examples).
2. **Reserved semantic** — `examples/real_trials/` is the intended
   home for real-project trial evidence (Workbuddy + RandomHeroes
   first sprint output). Keeping Mock fixtures in a clearly-labeled
   `_mock_baselines/` avoids accidentally conflating the two kinds of
   evidence.

## Current contents

### `trial_scenarios/` (Mock verification pack)

Four scenarios calibrating the three verifier verdict tiers:

| Scenario | Profile | Expected verdict |
| --- | --- | --- |
| `S1_codex_tapd_git/` | codex | PASS (golden sample) |
| `S3_cursor_tapd_git/` | cursor | PASS (profile-switch variant) |
| `S4_claude_subagents_tapd_git/` | claude_code_subagents | FAIL (post-M7.3 Lift gate) |
| `S5_workbuddy_private_tapd_git/` | workbuddy_private | FAIL |

See `trial_scenarios/README.md` for the full matrix and re-run
instructions.

### `beta_sprint_tapd_git/` (earlier Mock narrative)

A six-file narrative example on the Codex profile path, predating
`trial_scenarios/`. Preserved for continuity; `trial_scenarios/` is
the leaner successor that drives the verifier regression harness.

## Relationship to B+ (Bridge Hardening)

Per `.workbuddy/reviews/v4.88_release/B_PLUS_BRIDGE_HARDENING_MEMO.md`,
the upcoming B+ phase targets the **Workbuddy Private** profile (not
Codex). When B+ runs a real Workbuddy + RandomHeroes sprint:

- Use **S5_workbuddy_private_tapd_git/** as the Mock baseline to
  diff against real audit / state output.
- Real trial output should land under `examples/real_trials/`
  (to be created by B+ when the first real sprint closes).
- Delta between S5 Mock and real trial artifacts is itself the
  primary evidence B+ produces.

## How to run the Mock smoke harness

From Release package root:

```bash
bash scripts/run_mock_smoke.sh
```

The harness is path-aware after the B3 move; no script change should
be needed.

## Do not

- Do not treat any of these files as evidence from a live sprint.
- Do not edit them to reflect real runs — keep them as Mock contracts.
  If a real run needs to be recorded, put the artifact in
  `examples/real_trials/<scenario_id>/` instead.

## Provenance

- `trial_scenarios/`: authored during Phase 4 Step 2 (commits
  `5100dc7` S1 + `c1a1326` S3/S4/S5) as companion to
  `scripts/verify_beta_sprint_exit.py`.
- `beta_sprint_tapd_git/`: inherited from v4.88 RC12, upgraded to a
  runnable narrative during Phase 3 Step 2 (REV-5-001).
- This directory layout created during B3 cleanup (2026-04-23).
