# Adapter Mock Events

These files simulate minimal external system events for the file-backed adapter connect demo.

## Included systems
- Jira
- Git
- Build
- TAPD

## Flow
1. `scripts/ingest_adapter_events.py` normalizes these files.
2. Normalized external state is written into `runtime_db/external/*.json`.
3. `reconcile_external_state.py` consumes that external state and produces candidate transitions / pending reconcile.
