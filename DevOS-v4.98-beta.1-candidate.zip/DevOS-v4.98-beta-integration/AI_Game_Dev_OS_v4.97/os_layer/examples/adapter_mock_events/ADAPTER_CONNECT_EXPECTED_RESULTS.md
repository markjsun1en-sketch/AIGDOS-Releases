# Adapter Connect Expected Results

## Expected minimum results
- `runtime_db/external/jira.json` contains `TASK-0003`
- `runtime_db/external/git.json` contains `pr_001`
- `runtime_db/external/build.json` contains `build_001`
- reconcile should produce at least one candidate after adapter ingest
