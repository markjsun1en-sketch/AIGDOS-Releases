---
schema_version: "1.1.0"
pack_id: "ap_2026_005_support_cluster"
pack_version: "1.0.0"
cluster: "support"
roles:
  - "support"
  - "archivist"
roles_detailed:
  owners:
    - "archivist"
  doers:
    - "support"
    - "archivist"
  reviewers: []
skills:
  required: []
  optional: []
activation:
  default_stages:
    - "alpha"
    - "beta"
    - "release_candidate"
    - "production"
  host_profiles:
    - "codex"
    - "cursor"
    - "claude_code"
    - "claude_code_subagents"
    - "workbuddy"
dependencies:
  requires: []
  conflicts_with: []
lifecycle_state: "draft"
created_at: "2026-05-11"
references:
  - "docs/16_agent_library/README.md"
  - "docs/16_agent_library/AGENT_ROLE_CATALOG.md"
  - "docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md"
  - "docs/15_ltm_v2/README.md"
summary: "Support cluster seed pack covering toolchain infra and decision-archive curation."
_skeleton_notes:
  tier: "Batch 5 Module D — seed pack initial 0.1.0-beta; schema_version promoted to 1.0.0 in Batch 7 Step 7.1.a; pack_version promoted to 1.0.0 in Batch 12 Step 12.1 (D-1=B); schema_version minor-bumped to 1.1.0 in Batch 13 Step 13.2 (plan §7.4 字面 fields backfilled)"
  todo_later:
    - "Promote to active once Batch 7 assembler integration contract lands"
---

# ap_2026_005 — Support Cluster Pack

> **State**: draft (2026-05-11)
> **Cluster**: support
> **Roles covered**: `support`, `archivist`

## Purpose

Toolchain + decision archive ship together because they share the
same "background steady-state" cadence and the same governance
surface: both write rarely but broadly across the repo, both keep
the development loop reliable, and both interact with sprint-close
hooks (`support` for CI gates, `archivist` for LTM ledger appends).

## Roles

### `support` (scope: infra)

Toolchain, CI, environment, repository hygiene. Owns lint rules, CI
workflow definitions, dependency bumps, governance script
maintenance, and the developer ergonomics around running validators
and gates.

Inputs (typical):
- Failing builds / slow tests
- Missing tooling reports from implementation / validation
- Governance lint extensions (new Layer 1 roots, new exemption
  regexes)

Outputs (typical):
- CI workflow updates
- Dependency bumps (with paired test runs)
- Governance script extensions (e.g.
  `scripts/governance/lint_layer_separation.py` LAYER_1_ROOTS
  growth)
- Toolchain documentation in `scripts/<module>/README.md`

### `archivist` (scope: record-only)

Memory curation, doc history, decision archive. Bridge between live
work and Long-Term Memory (`docs/15_ltm_v2/`). Appends LTM ledger
entries when sprints close, summarises daily logs into MEMORY.md
distillations, archives accepted proposals, and consumes Failure-Fix
entries when they cross the 30-day promotion threshold.

Inputs (typical):
- Closed sprints / tagged batches
- Accepted proposals (`proposals/evo_*.md` with `state: accepted` /
  `implemented`)
- Closed Failure-Fix entries (`docs/15_ltm_v2/`)
- Daily logs / batch summaries

Outputs (typical):
- LTM ledger appends
- MEMORY.md long-term entries (distilled)
- Archived daily logs
- Decision archive entries

## Handoff surface

```
implementation → support (toolchain / CI gap report)
validation → support (CI infra request for gates)
executive → archivist (signed decision record append)
implementation → archivist (commit history reference)
support → orchestrator (CI / lint failure surface)
archivist → executive (LTM consult on prior decisions)
```

## Schema-driven invariants

- `roles` MUST be a non-empty subset of `{support, archivist}`
  (enforced by validator's cluster taxonomy check).
- `cluster` MUST equal `"support"` (enforced by 7-cluster enum +
  filename suffix `_support_cluster`).
- Promotion to `active` requires `activated_at` and removal of
  `_skeleton_notes`.

## Open questions / known limits

- **Tool integration boundary**: `tools_cluster` (deferred to
  v4.91) is intended as the home for MCP / external-tool integration
  agents. The boundary against `support` will sharpen once that
  cluster lands.
- **Archive granularity**: this pack does not specify how often the
  archivist distills daily logs — that is deliberately project-side.
  An adopting project may run distillation per sprint, per month, or
  per release.
- **Memory schema authority**: `docs/15_ltm_v2/` (Batch 4) owns the
  LTM schema; archivists writeback through that contract, not
  through this pack.

## References

- `docs/16_agent_library/AGENT_ROLE_CATALOG.md` — role definitions
- `docs/16_agent_library/PACK_BOUNDARY_SPEC.md` — pack contract
- `docs/16_agent_library/PACK_LIFECYCLE_GUIDE.md` — state model
- `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` — cluster taxonomy
- `docs/15_ltm_v2/README.md` — LTM schema authority
- `schemas/agent_library/agent_pack_entry.schema.json` — schema
- `scripts/agent_library/validate_agent_pack.py` — validator
