# agent_packs/ — Agent Library Pack Ledger

> **v4.90 Batch 5 — P1-1 Agent Library / Pack Architecture**
> Path: `agent_packs/`
> Layer 1 (OS Spec) root, with `ap_\d{4}_\d{3}*.md` Layer 2 regex exemption.

## Role

Holds every authored agent pack for the v4.90 OS Core. Each pack is a
single Markdown file with a YAML front-matter block conforming to
`schemas/agent_library/agent_pack_entry.schema.json`.

## Filename convention

```
agent_packs/ap_YYYY_NNN_<cluster_slug>.md
```

- `YYYY` — authoring year (e.g. `2026`).
- `NNN` — zero-padded pack sequence within that year (001, 002, ...).
- `<cluster_slug>` — 1-4 lowercase tokens separated by `_`, ending
  in `_cluster` for cluster-scoped packs (e.g. `executive_cluster`,
  `research_and_design_cluster`).

Only files matching `^ap_\d{4}_\d{3}.*\.md$` are exempt from the
Layer 1 lint rule — every other file in this directory MUST stay
project-name-free (this README included).

## read-only discipline (CRITICAL)

`agent_packs/` is a **compose ledger**, not a runtime configuration.
A pack documents which roles ship together and how their writebacks
land, but it MUST NEVER:

- Carry per-agent prompt text or runtime configuration.
- Trigger automatic agent activation in adopting projects.
- Be merged into `assemble_project_attachment.py` until Batch 7+
  decides on the integration contract (D6=B in v4.90).

The validator in `scripts/agent_library/validate_agent_pack.py` is
read-only: it parses, checks schema + cluster taxonomy, and reports.
It never mutates pack files.

## Lifecycle — 5 states + sentinel (see PACK_LIFECYCLE_GUIDE.md)

```
draft → active → deprecated → superseded
              → withdrawn
draft → withdrawn
```

See `docs/16_agent_library/PACK_LIFECYCLE_GUIDE.md` for the full
state machine and 6 allowed transitions.

## Cluster taxonomy

7 clusters, 6 active (5 v4.90 seeds + 1 v4.91 M-G/M-H activation with two sub-domains) + 1 deferred:

| cluster | roles | seed pack | status |
| --- | --- | --- | --- |
| `executive` | executive + orchestrator | `ap_2026_001_executive_cluster.md` | draft |
| `research_design` | research + design | `ap_2026_002_research_and_design_cluster.md` | draft |
| `implementation` | implementation | `ap_2026_003_implementation_cluster.md` | draft |
| `validation` | validation | `ap_2026_004_validation_cluster.md` | draft |
| `support` | support + archivist | `ap_2026_005_support_cluster.md` | draft |
| `creative_cluster` | design + implementation + validation (via evo_2026_002 + evo_2026_003) | `ap_2026_006_creative_cluster.md` | draft (v4.91 M-G + M-H) |
| `tools_cluster` | (TBD) | — | deferred (v4.91 / v4.92) |

The 5 v4.90 seeds together cover all 8 generic roles in
`docs/16_agent_library/AGENT_ROLE_CATALOG.md`. The v4.91 M-G
`creative_cluster` activation composes existing roles via the
`evo_2026_002` capability_promotion exemption rather than
introducing a new primitive. M-H widens the same cluster's
exemption registry to accept `evo_2026_003` as an alternate
authorising proposal id, allowing the cluster to grow new
sub-domains (animation -> game UI/UX) without altering the role
catalog.

## Current inventory

| File | Cluster | Roles | Skills | State |
| --- | --- | --- | --- | --- |
| `ap_2026_001_executive_cluster.md` | executive | executive, orchestrator | — | draft |
| `ap_2026_002_research_and_design_cluster.md` | research_design | research, design | — | draft |
| `ap_2026_003_implementation_cluster.md` | implementation | implementation | — | draft |
| `ap_2026_004_validation_cluster.md` | validation | validation | — | draft |
| `ap_2026_005_support_cluster.md` | support | support, archivist | — | draft |
| `ap_2026_006_creative_cluster.md` | creative_cluster | design, implementation, validation | 16 (8 animation + 8 game UI/UX) | draft |

## How to add a new pack

1. Pick the next `ap_YYYY_NNN` id and a cluster from
   `PACK_CLUSTER_TAXONOMY.md`.
2. Draft the file; start in `lifecycle_state: draft` with a
   `_skeleton_notes` block.
3. Run `python3 scripts/agent_library/validate_agent_pack.py
   --file <path>`.
4. Run `python3 scripts/governance/lint_layer_separation.py` to
   ensure no project-name leakage.
5. Once validated and socialised, promote to `active` with an
   explicit commit that adds `activated_at` and removes
   `_skeleton_notes`.

Layer 1 (OS Spec). No project names outside the `ap_*` exemption.
