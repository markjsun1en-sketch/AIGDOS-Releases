---
schema_version: "1.1.0"
pack_id: "ap_2026_006_creative_cluster"
pack_version: "0.2.0-beta"
cluster: "creative_cluster"
roles:
  - "design"
  - "implementation"
  - "validation"
roles_detailed:
  owners:
    - "design"
  doers:
    - "design"
    - "implementation"
  reviewers:
    - "validation"
skills:
  required:
    - "2d-character-motion-designer"
    - "sprite-sheet-planner"
    - "character-layer-splitter"
    - "rigging-prep-handoff"
    - "combat-animation-spec"
    - "asset-prompt-animation-helper"
    - "godot-2d-animation-implementer"
    - "animation-qa-auditor"
    - "game-ui-wireframe-generator"
    - "battle-hud-designer"
    - "card-ui-prefab-spec"
    - "game-design-system-builder"
    - "figma-handoff-spec"
    - "ui-asset-prompt-engineer"
    - "godot-ui-implementation-planner"
    - "game-ui-ux-auditor"
  optional: []
activation:
  default_stages:
    - "alpha"
    - "beta"
    - "release_candidate"
    - "production"
  host_profiles:
    - "codex"
    - "cursor"
    - "claude_code"
    - "claude_code_subagents"
    - "workbuddy"
dependencies:
  requires: []
  conflicts_with: []
lifecycle_state: "draft"
created_at: "2026-05-28"
references:
  - "proposals/evo_2026_002_creative_cluster_role_aliasing.md"
  - "proposals/evo_2026_003_creative_cluster_uiux_subdomain.md"
  - "docs/16_agent_library/AGENT_ROLE_CATALOG.md"
  - "docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md"
  - "docs/16_agent_library/PACK_BOUNDARY_SPEC.md"
  - "docs/16_agent_library/PACK_LIFECYCLE_GUIDE.md"
  - "docs/28_2d_character_animation/README.md"
  - "docs/29_game_ui_ux/README.md"
summary: "Creative cluster seed pack covering two sub-domains: (1) 2D character animation production — motion design, layer split, rigging prep, sprite-sheet planning, combat-animation spec, Godot animation implementation, asset-prompt authoring, animation QA (8 skills, M-G); (2) game UI/UX — wireframe, battle HUD, card prefab, design tokens, Figma handoff, UI asset prompt, Godot UI implementation planning, UI/UX audit (8 skills, M-H). Both sub-domains compose design + implementation + validation per evo_2026_002 / evo_2026_003 capability_promotion exemptions."
_skeleton_notes:
  tier: "v4.91 Milestone G + Milestone H — first creative_cluster seed pack with two sub-domains (animation + game UI/UX); activates the v4.90-deferred creative_cluster via the evo_2026_002 / evo_2026_003 capability_promotion pair. pack_version 0.2.0-beta reflects the M-H widening (was 0.1.0-beta in M-G); promotion to 1.0.0 is deferred to a future schema-wave unify-promote (mirrors v4.90 Batch 12 Step 12.1)."
  todo_later:
    - "Promote to active once 16 skill files land in skills/_generic_core/animation/ (M-G c2) + skills/_generic_core/game_ui/ (M-H c2) + skills/_generic_core/qa/{animation-qa-auditor,game-ui-ux-auditor}/ + skills/_engine_specific/godot/{godot-2d-animation-implementer,godot-ui-implementation-planner}/"
    - "Add docs/28_2d_character_animation/* + docs/29_game_ui_ux/* references once authored (M-G c3 + M-H c3)"
    - "Promote pack_version to 1.0.0 alongside next schema wave"
---

# ap_2026_006 — Creative Cluster Pack (Animation + Game UI/UX)

> **State**: draft (last touched 2026-05-29 in v4.91 Milestone H c1)
> **Cluster**: creative_cluster
> **Roles covered**: `design`, `implementation`, `validation` (per evo_2026_002 + evo_2026_003)
> **Sub-domains**: 2D character animation (M-G) + game UI/UX (M-H)

## Purpose

Creative cluster's first seed pack, accumulating sub-domains harvested
from real adopting-project pipelines. Each sub-domain ships 8 skills
that decompose into the same `{design, implementation, validation}`
role primitives. The 8-role catalog stays at 8; the 7-cluster taxonomy
stays at 7; only the validator's exemption registry widens its
proposal allow-list per sub-domain.

### Sub-domain 1 — 2D character animation (Milestone G, 2026-05-28)

For adopting projects whose actor art is delivered as full-body
illustration / green-screen actor / layered art and needs to ship as
in-engine cutout or sprite-sheet animation.

The sub-domain does NOT promise auto-rigging from a single image. It
turns a fragile one-shot task into a gated production pipeline:

```text
character art / green-screen actor
→ motion intent
→ layer split plan
→ rigging handoff
→ combat timing spec
→ sprite sheet or cutout implementation
→ Godot / Spine / Unity import plan
→ animation QA
→ correction handoff
```

### Sub-domain 2 — game UI/UX (Milestone H, 2026-05-28/29)

For adopting projects building game-domain UI surfaces (battle HUDs,
card prefabs, in-combat status chips, mobile safe-area-aware layouts)
that need to ship as Godot Control trees, Figma handoff specs, and
runtime-stable UI asset prompts.

The sub-domain does NOT bake runtime text (cost numbers, card names,
effect text) into generated images. It turns scattered "design a
screen" requests into a contracted production pipeline:

```text
GDD / combat loop / screenshot
→ UI audit or wireframe
→ battle HUD / card prefab / screen spec
→ design tokens and component rules
→ Figma / Godot / Unity handoff
→ UI asset prompt generation
→ QA gate and revision handoff
```

## Cross-cluster role aliasing rationale

This pack composes three role primitives — `design`,
`implementation`, `validation` — that are also covered by
`ap_2026_002_research_and_design_cluster.md` (design),
`ap_2026_003_implementation_cluster.md` (implementation), and
`ap_2026_004_validation_cluster.md` (validation). Per
`PACK_CLUSTER_TAXONOMY.md` § Per-cluster invariants, cross-cluster
role aliasing requires a `capability_promotion` proposal.

The pack lists **two** authorising proposals — one per sub-domain —
in its `references[]`:

1. `proposals/evo_2026_002_creative_cluster_role_aliasing.md`
   (animation sub-domain, M-G)
2. `proposals/evo_2026_003_creative_cluster_uiux_subdomain.md`
   (game UI/UX sub-domain, M-H)

The validator (`scripts/agent_library/validate_agent_pack.py`)
accepts the pack as long as **at least one** of the registered
authorising proposals appears; both being listed is the expected
steady state once both sub-domains have shipped.

### Functional decomposition (16 skills total)

| Skill | Role primitive | Sub-domain |
|---|---|---|
| `2d-character-motion-designer` | design | animation |
| `sprite-sheet-planner` | design | animation |
| `character-layer-splitter` | design | animation |
| `rigging-prep-handoff` | design | animation |
| `combat-animation-spec` | design | animation |
| `asset-prompt-animation-helper` | implementation | animation |
| `godot-2d-animation-implementer` | implementation | animation |
| `animation-qa-auditor` | validation | animation |
| `game-ui-wireframe-generator` | design | game_ui |
| `battle-hud-designer` | design | game_ui |
| `card-ui-prefab-spec` | design | game_ui |
| `game-design-system-builder` | design | game_ui |
| `figma-handoff-spec` | design | game_ui |
| `ui-asset-prompt-engineer` | implementation | game_ui |
| `godot-ui-implementation-planner` | implementation | game_ui |
| `game-ui-ux-auditor` | validation | game_ui |

Sub-domain totals: animation = 5 design + 2 implementation + 1 validation = 8.
Game UI/UX = 5 design + 2 implementation + 1 validation = 8.

No new role primitive is introduced (8-role catalog stays at 8).

## Roles

### `design` (scope: spec)

Owns motion-set design, layer-split plans, sprite-sheet timing,
combat-animation spec, rigging handoff (animation sub-domain), plus
UI screen wireframes, battle HUD specs, card prefab specs, design
tokens, component rules, and Figma handoff packets (game UI/UX
sub-domain). Outputs Markdown specifications consumed downstream by
`implementation`.

Inputs (typical):
- Animation: full-body actor art / concept reference / camera spec /
  combat or locomotion requirements / engine target
- Game UI/UX: GDD / combat loop / screenshot / target platform / safe
  area constraints

Outputs (typical):
- Animation: layer split plan / sprite-sheet plan / combat animation
  spec / rigging handoff
- Game UI/UX: wireframe spec / screen zone map / battle HUD spec /
  card prefab spec / design tokens / Figma handoff packet

### `implementation` (scope: code)

Converts design specs into engine-ready resources: Godot scene trees
(animation: AnimationPlayer / AnimationTree; UI: Control / CanvasLayer
/ Theme), and authoring-stable image-generation prompts. Limited to
the engine-specific implementer + asset prompt authoring inside this
pack.

Inputs (typical):
- Animation: layer split plan / combat animation spec / rigging
  handoff / engine version constraints
- Game UI/UX: screen spec / card prefab spec / design tokens / engine
  version constraints

Outputs (typical):
- Animation: Godot scene tree + AnimationPlayer track plan + import
  setting checklist + asset prompt sheets
- Game UI/UX: Godot UI scene tree + Control/Theme plan + asset prompt
  sheets for icons / frames / panels

### `validation` (scope: verify-only)

Audits creative output for sub-domain-specific risks. Read-only by
definition.

Inputs (typical):
- Animation: animation frames / GIF / video / Godot preview / sprite
  sheet / combat animation spec / acceptance criteria
- Game UI/UX: UI screenshot / mockup / Godot scene preview / screen
  spec / acceptance criteria

Outputs (typical):
- QA report (issue table + severity + fix recommendation)
- Acceptance / rejection record
- Re-test checklist

## Handoff surface

```
external_input → design (specs per sub-domain)
design         → implementation (engine plan + import settings + prompts)
implementation → validation (preview + sprite sheet / Godot scene)
validation     → design (correction handoff: blockers / majors)
validation     → archivist (acceptance record into LTM ledger)
```

The pack does NOT directly couple to `executive` (no auto-promotion
of acceptance), `orchestrator` (multi-skill workflow is host-side),
or `support` (toolchain). Adopting projects compose those clusters
separately.

## Schema-driven invariants

- `roles` MUST be a non-empty subset of `{design, implementation, validation}`
  (creative_cluster exemption per evo_2026_002 / evo_2026_003).
- `cluster` MUST equal `"creative_cluster"`.
- `references[]` MUST contain at least one of
  `"proposals/evo_2026_002_creative_cluster_role_aliasing.md"` or
  `"proposals/evo_2026_003_creative_cluster_uiux_subdomain.md"`
  (validator exemption gate; M-H c0 widened the registry to accept
  either id).
- Promotion to `active` requires `activated_at` and removal of
  `_skeleton_notes`.
- 16 skill names in `skills.required[]` MUST match the 16 SKILL.md
  files materialising under the following layout:
  - `skills/_generic_core/animation/` (6 SKILL.md, M-G c2)
  - `skills/_generic_core/qa/animation-qa-auditor/` (M-G c2)
  - `skills/_engine_specific/godot/godot-2d-animation-implementer/` (M-G c2)
  - `skills/_generic_core/game_ui/` (6 SKILL.md, M-H c2)
  - `skills/_generic_core/qa/game-ui-ux-auditor/` (M-H c2)
  - `skills/_engine_specific/godot/godot-ui-implementation-planner/` (M-H c2)

## Hard boundary (Charter alignment)

Per Charter anti-pattern enforcement (carried by inv_013 in M-G c4
for animation; inv_014 in M-H c4 for UI/UX):

- **No magic auto-rig promise** (animation sub-domain) — every
  animation skill's `## Hard rules` (or equivalent gate sections like
  `## Use when` + `## Do not use when` + `## Required output`) MUST
  declare manual gates and identify what AI cannot reliably do
  (Charter #6).
- **No baked runtime text** (game UI/UX sub-domain) — UI asset prompt
  schemas / templates MUST forbid prompts that bake card cost numbers,
  card names, effect text, ability descriptions, or other
  runtime-mutable text into generated images (Charter #6 family,
  applied to image-generation pipelines; inv_014 first gate).
- **Spec-required acceptance** (game UI/UX sub-domain) — every UI
  screen / card prefab spec schema MUST require an `acceptance[]`
  section with at least one testable check; a spec without acceptance
  criteria is a mood board, not a contract (Charter #11; inv_014
  second gate).
- **`requires_preflight_review`-equivalent semantics** —
  `animation-qa-auditor` and `game-ui-ux-auditor` issues are
  advisory; gameplay sign-off is a separate human decision
  (Charter #11).
- **No project literals** — skill fixtures and references use opaque
  `<character_id>` (animation) / `screen_alpha` / `card_alpha` (UI/UX)
  / generic actor templates only (Charter #2). Adopting-project
  identifiers stay in workspace `MEMORY.md` per the Layer 1 / Layer 2
  separation principle (evo_2026_001).

## Open questions / known limits

- **Engine specialisation**: the pack ships one Godot animation
  implementer and one Godot UI implementation planner. Spine,
  DragonBones, Unity 2D, and Live2D are out of scope for v4.91;
  future `_engine_specific/<engine>/` extensions may add matching
  implementers without altering the cluster contract.
- **Locomotion gap (animation)**: walk / run / jump / turn-around
  animations are intentionally out of scope. Source-art constraints
  make these unreliable in a one-shot AI workflow; adopting projects
  needing full locomotion should escalate to a professional animator.
- **Asset-prompt / image-gen integration**: the
  `asset-prompt-animation-helper` and `ui-asset-prompt-engineer`
  write prompts but do NOT generate images. Image generation remains
  an external host-side capability.
- **Multi-pack creative_cluster sequencing**: when narrative or audio
  sub-domain packs land (future v4.92+), they will follow the
  evo_2026_002 / evo_2026_003 pattern — emit their own
  capability_promotion proposal, the validator widens its allow-list,
  this single pack file accumulates `skills.required[]` and
  `references[]` entries.

## References

- `proposals/evo_2026_002_creative_cluster_role_aliasing.md` — capability_promotion (animation)
- `proposals/evo_2026_003_creative_cluster_uiux_subdomain.md` — capability_promotion (game UI/UX)
- `docs/16_agent_library/AGENT_ROLE_CATALOG.md` — 8-role primitives
- `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` — 7-cluster taxonomy
- `docs/16_agent_library/PACK_BOUNDARY_SPEC.md` — pack contract
- `docs/16_agent_library/PACK_LIFECYCLE_GUIDE.md` — state model
- `docs/28_2d_character_animation/README.md` — animation sub-domain adoption guide (M-G c3)
- `docs/29_game_ui_ux/README.md` — game UI/UX sub-domain adoption guide (M-H c3)
- `schemas/agent_library/agent_pack_entry.schema.json` — schema
- `scripts/agent_library/validate_agent_pack.py` — validator (registry widened in M-H c0)
