---
schema_version: "1.1.0"
pack_id: "ap_2026_003_implementation_cluster"
pack_version: "1.0.0"
cluster: "implementation"
roles:
  - "implementation"
roles_detailed:
  owners:
    - "implementation"
  doers:
    - "implementation"
  reviewers: []
skills:
  required: []
  optional: []
activation:
  default_stages:
    - "alpha"
    - "beta"
    - "release_candidate"
    - "production"
  host_profiles:
    - "codex"
    - "cursor"
    - "claude_code"
    - "claude_code_subagents"
    - "workbuddy"
dependencies:
  requires: []
  conflicts_with: []
lifecycle_state: "draft"
created_at: "2026-05-11"
references:
  - "docs/16_agent_library/README.md"
  - "docs/16_agent_library/AGENT_ROLE_CATALOG.md"
  - "docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md"
summary: "Implementation cluster seed pack covering code and engineering output."
_skeleton_notes:
  tier: "Batch 5 Module D — seed pack initial 0.1.0-beta; schema_version promoted to 1.0.0 in Batch 7 Step 7.1.a; pack_version promoted to 1.0.0 in Batch 12 Step 12.1 (D-1=B); schema_version minor-bumped to 1.1.0 in Batch 13 Step 13.2 (plan §7.4 字面 fields backfilled)"
  todo_later:
    - "Promote to active once Batch 7 assembler integration contract lands"
---

# ap_2026_003 — Implementation Cluster Pack

> **State**: draft (2026-05-11)
> **Cluster**: implementation
> **Roles covered**: `implementation`

## Purpose

Solo cluster intentionally — engineering output has a distinct
cadence (daily commits) and a distinct review surface (paired with
`validation` but kept separate to preserve verifier-vs-implementer
boundary). Fan-out by adopting-project agent count happens at the
project layer, not inside this cluster.

## Roles

### `implementation` (scope: code)

Translates `design` specs into source-tree mutations. Writes scripts,
runtime modules, test fixtures, and paired test additions.
Coordinates with `support` on toolchain needs and with `validation`
on QA gating.

Inputs (typical):
- Design specs / schema drafts
- Open spec questions resolved by design
- CI failures from support
- Verifier rejections from validation

Outputs (typical):
- Code commits (preferring small, atomic commits matching the OS
  Core's per-step convention)
- Refactor batches (separate from feature batches)
- Test additions paired with code changes

## Handoff surface

```
design → implementation (spec handoff)
implementation → validation (verification request)
validation → implementation (rejection / regression)
support → implementation (CI / lint failure)
implementation → orchestrator (completion ack)
implementation → archivist (commit history reference)
```

## Schema-driven invariants

- `roles` MUST be exactly `["implementation"]` (single-role cluster;
  enforced by validator's cluster taxonomy check).
- `cluster` MUST equal `"implementation"` (enforced by 7-cluster
  enum + filename suffix `_implementation_cluster`).
- Promotion to `active` requires `activated_at` and removal of
  `_skeleton_notes`.

## Open questions / known limits

- **Multi-stack coverage**: this pack does not split per-language /
  per-runtime implementation work. Adopting projects that span
  multiple stacks may need parallel imports of this pack with
  different `pack_id`s once a future variant convention lands.
- **Refactor cadence**: nothing in this pack distinguishes feature
  work from refactor work; that is a project-side concern.
- **Pair-programming scope**: out of scope for v4.90. The pack
  describes function, not collaboration mode.

## References

- `docs/16_agent_library/AGENT_ROLE_CATALOG.md` — role definitions
- `docs/16_agent_library/PACK_BOUNDARY_SPEC.md` — pack contract
- `docs/16_agent_library/PACK_LIFECYCLE_GUIDE.md` — state model
- `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` — cluster taxonomy
- `schemas/agent_library/agent_pack_entry.schema.json` — schema
- `scripts/agent_library/validate_agent_pack.py` — validator
