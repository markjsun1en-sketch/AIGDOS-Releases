---
schema_version: "1.1.0"
pack_id: "ap_2026_002_research_and_design_cluster"
pack_version: "1.0.0"
cluster: "research_design"
roles:
  - "research"
  - "design"
roles_detailed:
  owners:
    - "design"
  doers:
    - "research"
    - "design"
  reviewers: []
skills:
  required: []
  optional: []
activation:
  default_stages:
    - "alpha"
    - "beta"
    - "release_candidate"
    - "production"
  host_profiles:
    - "codex"
    - "cursor"
    - "claude_code"
    - "claude_code_subagents"
    - "workbuddy"
dependencies:
  requires: []
  conflicts_with: []
lifecycle_state: "draft"
created_at: "2026-05-11"
references:
  - "docs/16_agent_library/README.md"
  - "docs/16_agent_library/AGENT_ROLE_CATALOG.md"
  - "docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md"
summary: "Research and design cluster seed pack covering investigation and specification roles."
_skeleton_notes:
  tier: "Batch 5 Module D — seed pack initial 0.1.0-beta; schema_version promoted to 1.0.0 in Batch 7 Step 7.1.a; pack_version promoted to 1.0.0 in Batch 12 Step 12.1 (D-1=B); schema_version minor-bumped to 1.1.0 in Batch 13 Step 13.2 (plan §7.4 字面 fields backfilled)"
  todo_later:
    - "Promote to active once Batch 7 assembler integration contract lands"
---

# ap_2026_002 — Research and Design Cluster Pack

> **State**: draft (2026-05-11)
> **Cluster**: research_design
> **Roles covered**: `research`, `design`

## Purpose

Co-locate investigation and specification because they are tightly
coupled: research without design is a report nobody acts on, design
without research is hand-wavy. Adopting projects that ship under
v4.90 typically need both before any `implementation` work can
start.

## Roles

### `research` (scope: read-only)

Domain investigation, evidence collection, prior-art survey. Reads
existing docs, schemas, codebase, external references. Produces
research notes that downstream `design` consumes; never directly
mutates canonical schemas or the matrix.

Inputs (typical):
- Existing module docs / specs
- External documentation, RFCs, prior-art surveys
- Codebase greps + file inventory

Outputs (typical):
- Evidence report (Phase 1 of a Plan workflow)
- Prior-art matrix
- Open-question list for `executive`

### `design` (scope: spec)

Architecture and specification design covering structure, data
shapes, UI surface, content taxonomies, numerics. Translates research
into shippable specs that `implementation` can build against.

Inputs (typical):
- Research evidence
- Executive constraints (scope, budget, exit criteria)
- Prior batch close notes

Outputs (typical):
- Spec docs in `docs/<module>/`
- Schema drafts (handed to implementation for filling)
- ADRs / proposals (for cross-cutting principles)

## Handoff surface

```
research → design (evidence -> spec)
design → executive (spec sign-off request)
design → implementation (spec handoff)
implementation → design (clarification request)
validation → design (spec ambiguity report)
archivist ← design (ADR / proposal append)
```

## Schema-driven invariants

- `roles` MUST be a non-empty subset of `{research, design}`
  (enforced by validator's cluster taxonomy check).
- `cluster` MUST equal `"research_design"` (enforced by 7-cluster
  enum + filename suffix `_research_and_design_cluster`).
- Promotion to `active` requires `activated_at` and removal of
  `_skeleton_notes`.

## Open questions / known limits

- **Spec format**: this pack does not prescribe Markdown vs ADR vs
  proposal as the canonical spec format. Each module under `docs/`
  has its own convention.
- **Numerics design**: when an adopting project has heavy numerics
  work (game balance, ML hyperparameters), it may need a dedicated
  variant of the `design` role. Out of scope for v4.90.
- **Cross-cluster role overlap**: if a project's research feeds
  multiple downstream clusters simultaneously, the orchestrator
  fans the output out; the pack stays single-cluster.

## References

- `docs/16_agent_library/AGENT_ROLE_CATALOG.md` — role definitions
- `docs/16_agent_library/PACK_BOUNDARY_SPEC.md` — pack contract
- `docs/16_agent_library/PACK_LIFECYCLE_GUIDE.md` — state model
- `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` — cluster taxonomy
- `schemas/agent_library/agent_pack_entry.schema.json` — schema
- `scripts/agent_library/validate_agent_pack.py` — validator
