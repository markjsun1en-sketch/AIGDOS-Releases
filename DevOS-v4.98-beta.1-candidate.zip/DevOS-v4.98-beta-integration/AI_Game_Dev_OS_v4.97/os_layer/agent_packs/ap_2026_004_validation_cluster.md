---
schema_version: "1.1.0"
pack_id: "ap_2026_004_validation_cluster"
pack_version: "1.0.0"
cluster: "validation"
roles:
  - "validation"
roles_detailed:
  owners:
    - "validation"
  doers:
    - "validation"
  reviewers: []
skills:
  required: []
  optional: []
activation:
  default_stages:
    - "alpha"
    - "beta"
    - "release_candidate"
    - "production"
  host_profiles:
    - "codex"
    - "cursor"
    - "claude_code"
    - "claude_code_subagents"
    - "workbuddy"
dependencies:
  requires: []
  conflicts_with: []
lifecycle_state: "draft"
created_at: "2026-05-11"
references:
  - "docs/16_agent_library/README.md"
  - "docs/16_agent_library/AGENT_ROLE_CATALOG.md"
  - "docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md"
summary: "Validation cluster seed pack covering testing, QA, and fingerprint verification."
_skeleton_notes:
  tier: "Batch 5 Module D — seed pack initial 0.1.0-beta; schema_version promoted to 1.0.0 in Batch 7 Step 7.1.a; pack_version promoted to 1.0.0 in Batch 12 Step 12.1 (D-1=B); schema_version minor-bumped to 1.1.0 in Batch 13 Step 13.2 (plan §7.4 字面 fields backfilled)"
  todo_later:
    - "Promote to active once Batch 7 assembler integration contract lands"
---

# ap_2026_004 — Validation Cluster Pack

> **State**: draft (2026-05-11)
> **Cluster**: validation
> **Roles covered**: `validation`

## Purpose

Solo cluster intentionally — same reason as `implementation`: a
distinct review authority that MUST stay independent of the role it
audits. Co-locating validation with implementation would dilute the
verifier-vs-implementer separation that the OS Core relies on for
its capability fingerprint contract and its sprint-close gates.

## Roles

### `validation` (scope: verify-only)

Testing, QA, fingerprint verification, regression gating. Verifies
that what was built matches what was specified, by running validator
scripts, fingerprint scans, lint gates, and the test suite. Produces
reports that drive `executive` exit-criteria decisions; does NOT
mutate the artefacts under test.

Inputs (typical):
- Validator scripts (`scripts/<module>/validate_*.py`)
- Capability fingerprint definitions
- Test fixtures
- The artefacts to verify (read-only)

Outputs (typical):
- Test results (pytest summary, per-module pass/fail counts)
- Validator reports (text + JSON ledger output)
- QA findings + Layer 1 lint reports
- Fingerprint scan output (matrix row coverage)

## Handoff surface

```
implementation → validation (verification request)
validation → implementation (rejection / regression report)
validation → executive (exit-criteria gate report)
validation → orchestrator (blocking surface for next step)
support → validation (CI infrastructure for running gates)
archivist ← validation (verifier ledger archive)
```

## Schema-driven invariants

- `roles` MUST be exactly `["validation"]` (single-role cluster;
  enforced by validator's cluster taxonomy check).
- `cluster` MUST equal `"validation"` (enforced by 7-cluster enum +
  filename suffix `_validation_cluster`).
- Promotion to `active` requires `activated_at` and removal of
  `_skeleton_notes`.
- Read-only invariant is documented but cannot be schema-enforced;
  it is the validator's job + reviewer attention to keep validation
  agents from straying into mutation.

## Open questions / known limits

- **Test authoring vs test running**: this pack treats both as
  validation; an adopting project that prefers TDD may split
  authoring (closer to `implementation`) from running. A future
  variant pack may codify the split.
- **Performance / load testing**: out of scope for v4.90. May
  warrant a sibling `qa_cluster` in a later release.
- **Security audit**: also out of scope for v4.90; held back until
  a `security_cluster` proposal lands.

## References

- `docs/16_agent_library/AGENT_ROLE_CATALOG.md` — role definitions
- `docs/16_agent_library/PACK_BOUNDARY_SPEC.md` — pack contract
- `docs/16_agent_library/PACK_LIFECYCLE_GUIDE.md` — state model
- `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` — cluster taxonomy
- `schemas/agent_library/agent_pack_entry.schema.json` — schema
- `scripts/agent_library/validate_agent_pack.py` — validator
