---
schema_version: "1.1.0"
pack_id: "ap_2026_001_executive_cluster"
pack_version: "1.0.0"
cluster: "executive"
roles:
  - "executive"
  - "orchestrator"
roles_detailed:
  owners:
    - "executive"
  doers:
    - "executive"
    - "orchestrator"
  reviewers: []
skills:
  required:
    - "subagent-routing-gate"
  optional: []
activation:
  default_stages:
    - "alpha"
    - "beta"
    - "release_candidate"
    - "production"
  host_profiles:
    - "codex"
    - "cursor"
    - "claude_code"
    - "claude_code_subagents"
    - "workbuddy"
dependencies:
  requires: []
  conflicts_with: []
lifecycle_state: "draft"
created_at: "2026-05-11"
references:
  - "docs/16_agent_library/README.md"
  - "docs/16_agent_library/AGENT_ROLE_CATALOG.md"
  - "docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md"
  - "skills/_generic_core/orchestrator/subagent-routing-gate/SKILL.md"
summary: "Executive cluster seed pack covering decision-only and coordination roles."
_skeleton_notes:
  tier: "Batch 5 Module D — seed pack initial 0.1.0-beta; schema_version promoted to 1.0.0 in Batch 7 Step 7.1.a; pack_version promoted to 1.0.0 in Batch 12 Step 12.1 (D-1=B); schema_version minor-bumped to 1.1.0 in Batch 13 Step 13.2 (plan §7.4 字面 fields backfilled); v4.91 Addendum-C added required skill 'subagent-routing-gate' (executive + orchestrator must route via Delegation Gate before implementation/validation/audit/tooling work)."
  todo_later:
    - "Promote to active once Batch 7 assembler integration contract lands"
---

# ap_2026_001 — Executive Cluster Pack

> **State**: draft (2026-05-11)
> **Cluster**: executive
> **Roles covered**: `executive`, `orchestrator`

## Purpose

Provide the decision + dispatch surface for any project adopting
v4.90. Without this cluster active, batch sign-off and multi-agent
dispatch have no anchor; the OS Core's lifecycle hooks
(`sprint_close`, `pack_active`, future `proposal_accept`) all assume
an executive role exists somewhere in the roster.

## Roles

### `executive` (scope: decision-only)

Owns the irreversible-action call: capability promotion, schema
break, sprint close, batch closure tag. Reads roll-up reports, risk
register, exit-criteria reports; writes a signed-off decision record
into the archivist's history (no direct canonical writeback).

Inputs (typical):
- Closed batch reports (`V4_xx_README.md` sections)
- Risk register / pre-Step grep checklists
- Adoption / verifier outputs

Outputs (typical):
- Signed decision record (Layer 2 case study or proposal `accepted`
  state transition)
- Tag-and-close instruction to the orchestrator

### `orchestrator` (scope: coordination)

Decomposes a batch plan into ordered steps, assigns owners, tracks
blocking dependencies, surfaces handoff artefacts. Does NOT edit
canonical OS files; writeback is delegated to whichever role owns
the artefact.

Inputs (typical):
- Batch plan + dependency graph
- Per-step handoff manifests
- Blocked-task surface from validation

Outputs (typical):
- Per-step task list / progress ledger
- Handoff manifest emissions
- Escalation requests to executive

## Handoff surface

```
research_design → executive (proposal review, design sign-off)
executive → orchestrator (dispatch instruction)
orchestrator → implementation (per-step task)
orchestrator → validation (verification request)
implementation → orchestrator (completion ack)
validation → executive (gate report at exit criteria)
support → orchestrator (CI / lint failures)
archivist ← executive (decision record append)
```

## Schema-driven invariants

- `roles` MUST be a non-empty subset of `{executive, orchestrator}`
  (enforced by validator's cluster taxonomy check).
- `cluster` MUST equal `"executive"` (enforced by 7-cluster enum +
  filename suffix `_executive_cluster`).
- Promotion to `active` requires `activated_at` and removal of
  `_skeleton_notes` (see `PACK_LIFECYCLE_GUIDE.md`).

## Open questions / known limits

- **Decision-record format**: this pack does not prescribe a single
  on-disk format for executive decisions; adopting projects choose
  between proposals + Layer 2 case studies. A future
  `capability_promotion` proposal MAY tighten this.
- **Multi-executive composition**: when a project has multiple
  decision-makers (e.g. EP + technical lead), this pack treats them
  as a single role. A future variant pack may split them.

## References

- `docs/16_agent_library/AGENT_ROLE_CATALOG.md` — role definitions
- `docs/16_agent_library/PACK_BOUNDARY_SPEC.md` — pack contract
- `docs/16_agent_library/PACK_LIFECYCLE_GUIDE.md` — state model
- `docs/16_agent_library/PACK_CLUSTER_TAXONOMY.md` — cluster taxonomy
- `schemas/agent_library/agent_pack_entry.schema.json` — schema
- `scripts/agent_library/validate_agent_pack.py` — validator
- `skills/_generic_core/orchestrator/subagent-routing-gate/SKILL.md` —
  required Delegation Gate skill (v4.91 Addendum-C). Executive and
  orchestrator MUST run the gate before implementation, validation,
  audit, or tooling work; the decision (`SPAWN_SUBAGENT` /
  `LOCAL` / `ESCALATE`) is recorded to
  `runtime/registries/delegation_decision_ledger.jsonl`.
- `runtime/protected_contracts/protected_regression_matrix.yaml`
  (`inv_008_delegation_gate_recorded`) — invariant guarding the
  Delegation Gate's audit trail.
