---
title: v4.90 Release Candidate 3 — Release Notes
version: 1.0
status: closed
layer: root_meta
since_batch: 14.10
protected_invariants:
  - inv_001_v4_89_byte_lock_immutable
  - inv_002_layer_1_no_project_names
  - inv_003_state_machine_doc_schema_aligned
  - inv_004_no_v4_89_active_stale_in_v4_90
  - inv_005_naming_alias_catalog_valid
  - inv_006_capability_id_pattern_intact
  - inv_007_schema_version_const_locked
---

> **v4.93 embedding note**: this is historical OS baseline provenance inherited
> into `AI_Game_Dev_OS_v4.93/os_layer/`. It is not a v4.93 release note and it
> is not a v4.93 entrypoint. If v4.93 needs release notes, they belong at the
> `AI_Game_Dev_OS_v4.93/` root.

# v4.90 Release Candidate 3 — Release Notes

> **Tag**: `v4.90-rc3` (annotated)
> **Date**: 2026-05-15
> **Branch**: `release/v4.90-fork`
> **Predecessor**: `v4.90-rc2` (Batch 13 RC2 remediation closure)
> **Status at cut**: pytest **901 passed / 2 skipped** · Layer 1 lint **33 roots / 0 violations** · v4.89 byte-lock `bb48af1...87767`

---

## 0. What's new in RC3 vs RC2

RC3 closes Batch 14 — the consistency-audit batch. The functional
surface is unchanged from RC2; the new content is governance:
machine-readable contracts that pin the gates already enforced by
14.1-14.6. RC3 is the first v4.90 release candidate where:

- Every protected behavior gate has a contract entry (7 active
  invariants, machine-readable yaml, schema-validated).
- Changing certain trigger files automatically routes the
  Required-regressions check, which now runs commands by default.
- Six core docs declare a Layer + a Protected Invariant link in
  YAML front-matter, so reviewers see at a glance which contracts
  a doc edit might brush against.
- A single closure-gate runner exits 0 only when 13 line items
  pass; it gated this very tag.

Residual risk: the `--enforced` default in
`scripts/governance/check_required_regressions.py` is the most
behavioural change. Callers that relied on the previous
"report-only" default must pass `--advisory` explicitly. Wide audit
preceding RC3 already verified all 7 invariants pass enforced
execution.

---

## 1. Consistency audit closure (Batch 14, all 9 + 1 steps)

| Step | Commit | Theme | tests |
|---|---|---|---:|
| 14.1 | `2dbc119` | RELEASE_MANIFEST metadata realignment (C-01) | 836→839 |
| 14.2 | `4a97954` | V4_90_README post-RC2 status refresh (C-02) | 839→841 |
| 14.3 | `b70fa3f` | 14 promoted schemas: schema_version const+required (C-03) | 841→856 |
| 14.4 | `9c1b076` | v4.89 reference audit + lint + 1 stale fix (C-05) | 856→864 |
| 14.6 | `f42ff02` | State machine alignment guard + master index (C-07) | 864→872 |
| 14.5 | `6af9a9b` | Naming alias machine-readable catalog (C-04 + C-09) | 872→881 |
| **14.8** | `09debc6` | **Protected behavior contract Phase 1 + consistency aggregate (C-08)** | **881→895** |
| 14.8.fu | `fb6fe04` | followup: invariant trigger globs + validation paths | 895 |
| 14.7 | `80ad2d3` | manifest_schema_notes string→array + history doc (C-06) | 895→896 |
| 14.9 | `1915fec` | Docs front-matter spec + 6 instrumented core docs (C-10) | 896→901 |
| 14.8.fu2 | `75a62b9` | followup-2: drop wrong inv_006 trigger | 901 |
| **14.10** | `<this commit>` | **Closure + RC3 tag + Phase 4 minimal gate** | 901 |

Net: **+65 tests** since RC2 (836 → 901), **0 collateral failure**,
**0 v4.89 byte-lock drift**.

---

## 2. Protected Behavior Contract — Phase 1 minimal (333 plan)

Step 14.8 lands the Phase 1 minimal subset of the 333 plan
(Protected Behavior Contract Workflow). RC3 does **not** include
Phase 2 (agent-culture intent gate), Phase 3 (drift detector), or
the full waiver system; those are deliberately deferred per EP
decision D-14.333.phase.

### 2.1 The 7 active invariants

Each invariant is back-traced to a gate already implemented in
Batch 14.1-14.6; **no new behavior** is introduced, only its
machine-readable record:

| ID | Behavior pinned |
|---|---|
| `inv_001_v4_89_byte_lock_immutable` | v4.89_Release tree SHA equals the Batch-9 baseline |
| `inv_002_layer_1_no_project_names` | Layer 1 OS Spec dirs contain zero project-specific names |
| `inv_003_state_machine_doc_schema_aligned` | 3 state machine doc transition tables ≡ schema anyOf |
| `inv_004_no_v4_89_active_stale_in_v4_90` | v4.89 audit Class C count == 0 |
| `inv_005_naming_alias_catalog_valid` | naming_aliases.yaml entries reach real READMEs / CLI commands |
| `inv_006_capability_id_pattern_intact` | capability_id enum = 14 entries, all `^\d{2}_\w+$` |
| `inv_007_schema_version_const_locked` | 14 promoted schemas have schema_version const "1.0.0" + required |

### 2.2 Phase 4 minimal gate (the default flip)

`scripts/governance/check_required_regressions.py` now defaults to
`--enforced`: invoking the script without flags will execute the
required_validation commands and exit non-zero on failure. Callers
that want the legacy report-only behavior must pass `--advisory`
explicitly. The aggregate (`check_consistency_aggregate.py`) and
the contracts test pinned `--advisory` in their own invocations
during Step 14.8 to keep their semantics stable across the flip.

### 2.3 Closure-gate runner

`scripts/governance/run_v490_rc3_closure_gate.py` runs 13 line
items spread across 3 sections (Code & Tests / Protected Behavior
/ Closure Deliverables) and exits 0 only when every item passes.
This script gated the v4.90-rc3 tag.

---

## 3. LAYER_1_ROOTS evolution (24 → 33)

| Stage | Roots | Trigger |
|---|---:|---|
| Pre-Batch-3 | 24 | Initial governance + migration + ltm + protocol stubs |
| Post-Batch-5 (P1-1) | 26 | `schemas/agent_library`, `tests/agent_library` |
| Post-Batch-10.2 | 28 | `evolution/candidates`, `evolution/sandbox` |
| Post-Batch-11.1 | 31 | `docs/18_cli`, `scripts/cli`, `tests/cli` |
| **Post-Batch-14.8 (RC3)** | **33** | `schemas/contracts`, `tests/contracts` |

`runtime/protected_contracts/` deliberately stays out of LAYER_1_ROOTS
(it carries data, not OS Spec).

---

## 4. New artefacts (RC3 only)

```
AI_Game_Dev_OS_v4.90/
├── schemas/contracts/                                          (NEW)
│   ├── protected_invariant.schema.json                          1.0.0
│   └── protected_regression_matrix.schema.json                  1.0.0
├── runtime/protected_contracts/                                (NEW data dir)
│   └── protected_regression_matrix.yaml                         7 invariants
├── scripts/governance/
│   ├── check_required_regressions.py                          (NEW, GUIDED)
│   ├── check_consistency_aggregate.py                         (NEW, GUIDED)
│   └── run_v490_rc3_closure_gate.py                           (NEW, GUIDED)
├── scripts/lint/
│   └── check_docs_front_matter.py                             (NEW, GUIDED)
├── tests/contracts/                                           (NEW, +14 tests)
│   ├── test_protected_invariant_schema.py
│   ├── test_required_regressions_router.py
│   └── test_consistency_aggregate.py
├── tests/governance/
│   └── test_docs_front_matter.py                              (NEW, +5 tests)
├── tests/test_manifest_schema_notes_consistency.py            (NEW, +1 test)
├── docs/MANIFEST_HISTORY.md                                   (NEW, root-meta)
├── docs/DOCS_FRONT_MATTER_SPEC.md                             (NEW, root-meta)
└── 6 core docs gain YAML front-matter                         (modified)
```

---

## 5. Tag

```
git tag -a v4.90-rc3 -m "v4.90 Release Candidate 3 — Batch 14 \
consistency audit closure + Protected Behavior Contract Phase 1"
```

The `v4.90-rc3` tag is annotated (not lightweight). `git show
v4.90-rc3` returns a non-empty tag message.

---

## 6. Forward roadmap (out of scope for RC3)

The following items were explicitly deferred per EP D-14.333.scope_guard:

- 333 Phase 2: agent-culture intent gate (commit-message intent block)
- 333 Phase 3: behavior-drift detector (semantic diff over commits)
- 333 §6 test-name hardening (rename test files to inv_NNN-prefixed names)
- Full waiver system (per-invariant owner / expiry / justification)

These will be reconsidered in v4.91+ where the multi-project
service-isation work happens.

---

## 7. Acknowledgements & decision trail

EP-locked decisions that shaped RC3 (full record in
`V4_90_BATCH_14_REMAINING_HANDOFF.md`):

- D-14.1 / 14.2 / 14.3' / 14.4.X / 14.4.A2 / 14.4.B / 14.5.A / 14.6.A
  (Batch 14 individual step framings)
- D-14.333.scope = C-revised — 333 lands in v4.90, not v4.91
- D-14.333.phase = Phase 1 + Phase 4 minimal — no Phase 2/3, no waivers
- D-14.7-A = A — manifest_schema_notes preserves v2.0/v2.1 history
  as first array item (no audit-trail loss)
- D-14.333.scope_guard — strict; RC3 refused multiple scope-creep
  invitations during Batch 14 execution

EP: Mac. AI partner: Kai.

---

## 8. Post-RC3 Patch History (v4.90.1 .. v4.90.11)

The RC3 closure contract above is still the **source of truth** for
the v4.90 final. Every post-RC3 patch is layered on top and is
verified by the same `run_v490_rc3_closure_gate.py` 13-check gate
(now also surfaced via `run_release_closure_gate.py --profile fast|full`).

| Patch | Theme | Key deltas |
|---|---|---|
| v4.90.1 | hygiene patch | identity unify (package_name / package_root_dir / VERSION / .core_os_root) + clean-tree gate + doc drift refresh; pytest 901→906 |
| v4.90.2 | portability + dual-track | inv_001 portable mode-aware checker (source_tree / release_package / standalone-zip auto-detect) + game_type_packs baseline dual-track + docs/18_cli alignment + USER_GUIDE inherited narrative; pytest 906→915 |
| v4.90.3 | final polish | README/USER_GUIDE 911→920 / RELEASE_NOTES Patch History / docs/18_cli ltm consult STUB sweep (17→22 leaves wired / 0 STUB) / `clean_transients.py` new tool / closure gate `--pytest-timeout` flag; pytest 915→920 |
| v4.90.4 | doc polish | CLI_USAGE_GUIDE.md skeleton/placeholder sweep / RELEASE_NOTES §4 heading correction / `--pytest-timeout 1800` slow-CI hint; pure doc, 0 source/schema/test changes |
| v4.90.5 | doc precision | docs/18_cli script-name corrections (list_packs.py / propose_skeleton.py) / CLI_USAGE_GUIDE 4× `Planned leaf shape` → `Current leaf shape` + alias/list-activate/propose real commands; RELEASE_NOTES factual corrections |
| v4.90.6 | active-state label sweep | README L69 + USER_GUIDE L21 `(post v4.90.3)` → `(post v4.90.5)`; V4_90_README plan-files inline plan refresh |
| v4.90.7 | aggregate stability + §4 sync | `check_consistency_aggregate.py` reordering (schema_self_validation before required_regressions) + `--timeout SECS` flag + `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1` isolation; closure gate `--aggregate-timeout` flag + C8 transparent passthrough + failed sub-check name surfaced; +3 tests; pytest 920→923 |
| v4.90.8 | closure gate hardening | `_run()` subprocess-leak hardened: `subprocess.Popen(start_new_session=True)` + `os.killpg(SIGTERM)` + 10s grace + escalate `SIGKILL` + 5s drain; new `extra_env` parameter merged into `os.environ`; new `--pytest-disable-plugin-autoload` flag; +3 tests; pytest 923→926 |
| **v4.90.9** | **fast/full split + PG-safe runner extraction + game-dev phase split** | **(1)** `scripts/governance/_process_runner.py` extracts `run_pg_safe` shared by closure gate + `check_required_regressions.py` + `check_consistency_aggregate.py` (closes the v4.90.8 hardening gap on the other two governance subprocess sites). **(2)** `scripts/governance/run_release_closure_gate.py` dispatcher with `--profile fast\|full`: fast = 7 minimal checks (collect-only / clean-tree / v4.89 audit / Layer 1 lint / aggregate / protected regressions / targeted regression subset); full = transparent passthrough to RC3 13-check gate; banner prints the `v4.90.1..v4.90.9` patch chain. **(3)** `schemas/adoption/project_profile.schema.json` 1.0.0 → 1.1.0 with required `game_dev_phase` enum (`prototype / mvp / vertical_slice / alpha_build / beta_build / production / post_launch`) decoupled from project lifecycle `stage`; `init_project_runtime.py --game-dev-phase` auto-derives default from `--stage` when omitted (beta→mvp, release_candidate→vertical_slice, ...). **(4)** Docs / EXPECTED_PYTEST 926→946 / manifest rebuild. **(5)** +20 tests (4 process_runner / 5 dispatcher / 8 stage_aliases / 3 schema). **B-CG closed.** New v4.91 backlog item: B-DUAL-PHASE-DOC. pytest **926→946**. |
| **v4.90.10** | **optional polish: gate timing language + dual-gate semantics + v4.90.9 evidence record** | **(1)** Soften timing language: dispatcher source / README / RELEASE_NOTES / V4_90_README replace hard `≤ 10s` / `≤ 180s` claims with `benchmark target` + `typical range` phrasing; the 180s assertion in `test_fast_profile_runs_seven_checks_in_under_three_minutes` is documented as a CI safeguard, not a benchmark. **(2)** Dual-gate semantics: README §Verification + RELEASE_NOTES §4 + V4_90_README + dispatcher `--help` now state explicitly that fast = reviewer smoke gate / full = final release evidence gate / fast is NOT a substitute for full at release time. **(3)** v4.90.9 evidence record: maintainer laptop run on 2026-05-17 17:05+: `pytest tests/` 946/2 in 29.46s; `--profile full --skip-deliverables` 8/8 PASS in 31.74s; `--profile fast` 3-run sample 6.22 / 6.50 / 6.32s avg 6.35s. **(4)** No source/schema/test logic changes — pure documentation + comment polish; EXPECTED_PYTEST stays at 946; manifest required count stays at 903. pytest **946** unchanged. |
| **v4.90.11** | **fast gate F5/F7 pipe-deadlock hardening + 13/13 evidence + doc alignment** | **(1)** Root cause: `_process_runner.run_pg_safe` uses `subprocess.PIPE` (~64 KB OS buffer); F5 consistency aggregate (6 sub-checks) accumulated > 64 KB in nested pytest, causing back-pressure deadlock — standalone PASS, nested via dispatcher hung silently. **(2)** New helper `run_pg_safe_to_file` captures stdout/stderr to temporary files instead of pipes (file writes not pipe-buffered, so back-pressure path eliminated); preserves PG-safe contract verbatim. F5 + F7 migrate; F1 stays on PIPE (bounded output). **(3)** New CLI flag `--fast-aggregate-wall-timeout SECS` (default 300, fast-profile-only) decouples wall-clock cap from per-sub-check `--aggregate-timeout` (v4.90.10's `aggregate_timeout * 6 + 60` formula was unpredictable). **(4)** +7 tests (5 to_file + 2 dispatcher new flag) → **953 passed / 2 skipped**. **(5)** Maintainer laptop evidence (2026-05-17 19:50+): pytest 953/2 in 33.67s; `--profile fast` 7/7 PASS in ~8.5s (incl. EP's v4.90.10 sandbox-hang reproducer with `--aggregate-timeout 1800` now PASS in ~8.4s); **`--profile full --pytest-timeout 1800 --aggregate-timeout 1800 --pytest-disable-plugin-autoload` (full release ceremony with deliverables): 13/13 PASS in ~36s**. **(6)** Doc alignment: §4 title `(v4.90.9 final)` → `(v4.90.11 patched state; test baseline 953 unchanged within v4.90.11)`; new "Two evidence bands" paragraph clarifies 8/8 (A+B without deliverables) vs 13/13 (A+B+C with deliverables) — only 13/13 acceptable for external freeze. EXPECTED_PYTEST 946 → **953**. pytest **946→953**. |

**Migration notes (v4.90.9)**:
- The RC3 entry point `run_v490_rc3_closure_gate.py` remains the closure contract source of truth. External callers should prefer the dispatcher (`run_release_closure_gate.py`) for new tooling, but the RC3 entry is preserved indefinitely for backward compatibility.
- `project_profile.schema.json` is now `1.1.0` (was `1.0.0`). The schema bump is **required** (game_dev_phase must be present). The package ships zero pre-existing `02_project_profile.yaml` instances, so no on-disk backfill is needed; new instances generated by `init_project_runtime.py` automatically include the field via stage-derived default.
- The PG-safe runner extraction is **API-compatible**: `closure_gate._run()` keeps its old signature and forwards to `_process_runner.run_pg_safe`. No external caller changes are required.

**Rollback safety**: each v4.90.9 atomic commit can be reverted independently; the RC3 gate remains usable as a fallback if the dispatcher is removed.
