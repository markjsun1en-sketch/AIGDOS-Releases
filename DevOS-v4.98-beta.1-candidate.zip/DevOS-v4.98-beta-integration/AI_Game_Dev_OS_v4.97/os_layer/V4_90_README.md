# V4_90_README compatibility stub

This file is intentionally retained in the v4.92 release package because the
frozen v4.90 RC3 closure contract still probes `V4_90_README.md` for its legacy
C11 deliverable check.

For current release information, read:

1. `V4_92_README.md`
2. `README.md`
3. `RELEASE_NOTES.md`

Legacy C11 compatibility markers: 14.7, 14.8, 14.9, 14.10.
