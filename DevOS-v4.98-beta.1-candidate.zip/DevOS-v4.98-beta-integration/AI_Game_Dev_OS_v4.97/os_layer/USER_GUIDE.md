# AI Game Dev OS v4.92 — Release User Guide

> **Current status (2026-06-04)**: this guide is attached to the clean
> `AI_Game_Dev_OS_v4.92_Release/` package.

> **Purpose**: release-package orientation plus inherited v4.90/v4.91 operating
> guide.
> **Audience**: an EP / tech lead / reviewer opening the v4.92 release package.
> **Where to go next**: for active v4.92 closure state, start with
> `docs/13_migration/V4_92_REOPEN_PROGRESS_REPORT.md` and
> `docs/13_migration/V4_92_B12_VALIDATION_REPORT.md`.

---

## 0. v4.92 release status (read this first)

v4.92 is the capability-production and migration-closure line forked from
`AI_Game_Dev_OS_v4.91_Release/`. This release package currently carries:

- `4.92-Release` release-package version state.
- `v4.92-Capability_Foundation` plus B10/B11/B11.5/B12 migration and evidence
  hardening work.
- a current engineering baseline of 1949 passed / 2 skipped tests and 72 Layer 1
  lint roots / 0 violations when run in the expected validation environment.
- final `AI_Game_Dev_OS_v4.92_Release/` package identity.

The remainder of this guide preserves the inherited v4.90/v4.91 operating guide
so historical workflows remain discoverable in the release package.

## 0b. v4.90 at a glance (historical baseline)

**v4.90** is the **Progressive Adoption & Memory-Governed Pack Runtime** release. It inherits the v4.89 Portable Core skeleton (byte-locked baseline `bb48af16…87767`) and adds:

- **Progressive Adoption Framework** — `docs/13_migration/`, 14-row capability compatibility matrix, mock legacy harness, scan/validate/adopt scripts.
- **State Surface Governance** — `docs/14_state_surface_governance/`, strict Layer 1 (OS Core) / Layer 2 (Project Case) separation; Layer 1 lint enforces zero project names in OS surface.
- **LTM v2 + Failure-Fix Memory** — `docs/15_ltm_v2/`, FTS5 retrieval engine, failure-fix capture/promote/quarantine, sprint_close hook.
- **Agent Library / Pack Architecture** — `docs/16_agent_library/`, `agent_packs/` 5 cluster seed packs, pack lifecycle CLI.
- **Self-Evolution skeleton** — `docs/17_self_evolution/`, proposal-only ledger; validator is read-only by design.
- **Unified CLI** — `docs/18_cli/`, `scripts/cli/ai_dev_os.py` aggregate entry. Invoke as `python3 -m scripts.cli.ai_dev_os <ns> <cmd> ...`. The `bin/ai-dev-os` shim and `pyproject.toml` console_scripts are deferred to v4.91.
- **Protected Behavior Contract Phase 1** — `runtime/protected_contracts/`, 7 invariants enforced (byte-lock, Layer 1, state machine, audit, naming, capability_id, schema_version). v4.90.2 patch made the byte-lock invariant portable across source-tree / release-package / standalone-zip deployments.

**953 passed / 2 skipped pytest baseline / 13/13 closure gate PASS (full = final release evidence gate, with deliverables) / 8/8 closure gate PASS (full --skip-deliverables, A+B contract) / 7/7 fast gate PASS (fast = reviewer smoke gate, benchmark target under 10s on a 2024-class laptop, v4.90.11+ pipe-deadlock-hardened) / 33/0 Layer 1 lint / v4.89 byte-lock unchanged (post v4.90.11).**

Sections 1-7 below carry the v4.89-era getting-started narrative (still operationally accurate) plus marginal notes for v4.90 changes. **For per-batch detail of v4.90 see `V4_90_README.md`; for ground-truth release narrative see `RELEASE_NOTES.md`; for changelog see `CHANGELOG.md`.**

---

## 1. What is this pack

**AI Game Dev OS v4.90** is an "operating system for AI-assisted game development" — not a game engine, not a specific tool, but a collection of **procedures + scripts + templates** that, when a human EP and a set of AI Agents collaborate on a game project, ensures that:

- every sprint starts from a **clean initialisation** (with a traceable `runtime_state`);
- every external writeback (TAPD / Git / ticket system) carries **audit + post-hoc verification**;
- every sprint close gets a **three-tier verdict** (PASS / CONDITIONAL / FAIL) plus five integrity categories;
- multiple runtime profiles (Codex / Cursor / Claude Code / WorkBuddy, etc.) **share a common contract** for exchanging events and evidence.

**One-liner**: constrain the AI development workflow "the infrastructure way" — so that sprint-produced evidence is machine-verifiable and combinations are auditable.

### 1.1 How v4.90 relates to earlier generations

```
v4.7        Runtime muscle (governance / contract / adapters first took shape)
v4.78       Tier1 directory layout
v4.8.2      Final Integrated suite
v4.87       Runtime Core solidified + Route A trio
v4.88 RC12  Portable Core skeleton (but the runtime muscle was missing)
v4.88-stable      v4.87 runtime re-mounted onto v4.88 skeleton + B+ Bridge
                  Hardening promoted init / evidence / close / verifier from
                  SCAFFOLD to GUIDED (the "v4.88_Revise" line, kept locally
                  as `AI_Game_Dev_OS_v4.88_Revise/` and as the historical
                  byte-locked `AI_Game_Dev_OS_v4.88_Release/`).
v4.89       ← previous inherited Beta Sprint Exit baseline. Adds Phase 1
                (11 permanent contracts), Phase 2 Stage 1 (LTM MVP),
                Phase 2 Stage 2 (5-profile parity), Phase 3 (schema-driven
                cross-checker collapse), Phase 4 (lift gate + skills import +
                sprint+agent cold-start governance + cross-project LTM
                Layer A namespace). Tree byte-locked at SHA `bb48af16…87767`
                and preserved as the immutable reference layer alongside
                this pack.
v4.90       ← this pack: Progressive Adoption & Memory-Governed Pack
                Runtime release. Inherits the v4.89 Portable Core byte-lock
                and adds Progressive Adoption Framework, State Surface
                Governance (Layer 1/2 separation), LTM v2 + Failure-Fix
                Memory, Agent Library / Pack Architecture, Self-Evolution
                proposal-only skeleton, unified CLI, and Protected Behavior
                Contract Phase 1 (7 invariants enforced).
v4.90.2     Hygiene patch (2026-05-16): inv_001 byte-lock checker made
                portable; pytest baseline 906 → 915; USER_GUIDE / pack
                manifests / CLI status doc all aligned.
```

Full evolution narrative is in `AI_Game_Dev_OS_Version_Evolution_and_Roadmap_v4.88.md` (workspace-level; named after v4.88 because it was first authored at v4.88 freeze; contents extend through v4.90).

---

## 2. What you get

> **Note**: the active pack is `AI_Game_Dev_OS_v4.92_Release/` (this directory). The byte-locked v4.89 reference baseline remains preserved per inv_001 of the Protected Behavior Contract. The directory tree shown below is the inherited layout; v4.92 additions live under `capability_protocols/`, `packs/`, `scripts/capability/`, and `docs/30_capability_packs/`.

```
AI_Game_Dev_OS_v4.92_Release/         ← this pack (active)
├── docs/                    ← procedures / governance / runtime profiles / starters
│   ├── 00_entry/            ← English official entry (START_HERE, etc.)
│   ├── USAGE_GUIDE.md       ← EP's English usage manual (334 lines)
│   ├── PHASE_4_TRIAL_GUIDE.md  ← first Beta Sprint walk-through (392 lines)
│   └── 09_beta_sprint/      ← Beta Sprint's 5 integrity contracts
├── config/                  ← 5 profile configuration files
├── scripts/                 ← runtime trio + Mock smoke + verification tools
├── runtime/                 ← audit collector / maturity matrix / LTM engine
├── ltm/                     ← LTM corpus (4 domains + Layer A `project/<id>/`)
├── integrations/            ← tapd / git adapter stubs (pluggable)
├── skills/                  ← 31 generic-core skills + 12 adaptation hooks
├── context_packs/           ← Lean / Standard / Expanded / Full Reference
├── game_type_packs/         ← Generic / Card-Roguelike and other project-type templates
├── starters/                ← starters for 5 runtime profiles
├── examples/_mock_baselines/trial_scenarios/   ← 5 Mock validation scenarios
└── trial_workspaces/        ← test-suite fixture trees (M6.8 contract); regular users can ignore
```

5 one-line entries:

| What you want | Where to go |
|---|---|
| See what this pack is | the file you are reading — `USER_GUIDE.md` |
| English official entry | `docs/00_entry/START_HERE.md` |
| EP system configuration + detailed usage | `docs/USAGE_GUIDE.md` |
| Run a Mock Sprint yourself | `docs/PHASE_4_TRIAL_GUIDE.md` |
| See the audit / verify script source | `scripts/verify_beta_sprint_exit.py` |

---

## 3. 5-minute read: core concepts

### 3.1 The 5 Runtime Profiles

Pick one per project; do not switch mid-sprint:

| Profile | Who it suits |
|---|---|
| `codex` | single-Agent serial execution; the default trial path |
| `cursor` | in-IDE collaboration |
| `claude_code_subagents` | Claude Code with a single main + sub-Agents isolated per worktree |
| `claude_code_agent_teams` | multiple teams running in parallel, heavier governance |
| `workbuddy_private` | WorkBuddy's private path (used by RandomHeroes) |

### 3.2 A sprint's three-step chain (the v4.89 core skeleton)

```bash
# Step 1: initialise (start of sprint)
python3 scripts/init_runtime_env.py \
    --project-id my_sprint_01 \
    --runtime-profile codex \
    --output-dir /path/to/project

# Step 2: during the sprint, periodically run the 5-module health check
python3 scripts/run_beta_sprint_check.py --workspace /path/to/project

# Step 3: at sprint close, run the exit-gate verification
python3 scripts/verify_beta_sprint_exit.py \
    --workspace /path/to/project \
    --sprint sprint-01 --profile codex
```

Step 3 produces a three-tier verdict:

| verdict | exit code | meaning |
|---|---|---|
| `PASS` | 0 | all five integrity categories green |
| `CONDITIONAL` | 1 | only WARN findings; EP may accept |
| `FAIL` | 2 | at least one ERROR; the sprint is not a valid trial |

### 3.3 The five integrity categories (what the verifier checks)

1. **init integrity** — `runtime_state` exists; profile matches.
2. **execution integrity** — at least one transition; merge apply is paired with cleanup.
3. **external integrity** — every TAPD write is paired with a verify.
4. **evidence integrity** — audit log non-empty and parseable; evidence-class events present.
5. **close integrity** — checklist fully ticked; terminal event present.

### 3.4 Maturity Tier

In v4.89 the verifier checks the five categories **by tier** — three categories run at GUIDED and two at SCAFFOLD (inherited from the v4.88-stable B+ Bridge Hardening line; v4.90 will lift the remaining two):

| Category | v4.89 (current) | v4.90 will promote to |
|---|---|---|
| init | **GUIDED** | — |
| execution | SCAFFOLD | GUIDED |
| external | SCAFFOLD | GUIDED |
| evidence | **GUIDED** | — |
| close | **GUIDED** | — |

The verdict output's `"maturity_tier": "MIXED"` reflects this mixed state.

---

## 4. 15-minute hands-on: run a Mock Sprint

A Mock Sprint is a **reproducible pre-baked sample** — no real TAPD, no real Git, yet the whole chain runs end-to-end.

```bash
cd /path/to/AI_Game_Dev_OS_v4.89_Release

# Run all 5 scenarios in one go
bash scripts/run_mock_smoke.sh
```

Expected output (5/5 PASS):

```
SCENARIO                                  EXPECTED       ACTUAL         RESULT
S1_codex_tapd_git                         PASS           PASS           PASS
S3_cursor_tapd_git                        PASS           PASS           PASS
S4_claude_subagents_tapd_git              FAIL           FAIL           PASS
S5_workbuddy_private_tapd_git             FAIL           FAIL           PASS
S5b_workbuddy_private_hardened_pass       PASS           PASS           PASS
Total: 5   Pass: 5   Fail: 0
```

Each scenario demonstrates one kind of verdict:

| Scenario | What it shows |
|---|---|
| **S1** codex | all events present → PASS (the golden sample) |
| **S3** cursor | same as S1 but a different profile → PASS (proving verifier is profile-agnostic) |
| **S4** claude_subagents | runtime_state omits `audit_collector` + `context_loading_method` → 2 ERROR (M7.3 Lift gate); plus 1 missing `external.tapd.verify` and 1 missing `merge.cleanup` → 2 WARN; final verdict **FAIL / exit 2**. Demonstrates the post-M7.3 contract-surface enforcement. |
| **S5** workbuddy_private (counter-example) | `verification_ok=false` + 10/16 items unchecked → FAIL (2 ERRORs) |
| **S5b** workbuddy_private (hardened) | the hardened workbuddy_private on the same content yields PASS → proving the profile itself is not the culprit |

Understanding the differences between these 5 scenarios = understanding how the verifier decides the three verdict tiers.

### 4.1 Optional: `trial_workspaces/rh_sprint_sim_01/` (test fixture, replayable)

> **Most users can skip this section.** `trial_workspaces/` is the v4.89 test
> suite's fixture tree (M6.8 regression reproducibility contract); it ships
> in the package because pytest needs it, not because users are expected to
> consume it.

If you are a contributor or want to see the runtime end-to-end on a
realistic input, `trial_workspaces/rh_sprint_sim_01/` is a real sprint
workspace produced end-to-end on 2026-05-02 via the workbuddy_private
hardened path during the v4.88-stable era. Replay steps are in
`trial_workspaces/README.md`. The expected verdict on this evidence is
`CONDITIONAL` (0 errors / 2 warns); those 2 warns happen to be one of the
three P0 categories that v4.89 Phase 1 hardening has since addressed
(envelope contract + malformed-audit fallback + profile alias).

---

## 5. FAQ

### Q1. Do I have to use TAPD?
No. `common/hook_sprint_tracker_sync.md` allows plugging in any tracker (Jira / Linear / home-grown) — as long as the adapter output aligns with the event contract.

### Q2. Do I have to use all 5 profiles?
No. **Pick one; do not switch mid-sprint.** Change it in the next sprint if you want.

### Q3. Do I have to use every skill under `skills/`?
A project can override any same-named skill under `policy/skills/<subsystem>/`; during assemble, the project's override takes priority automatically.

### Q4. What is the difference between v4.88-stable and v4.88 RC12?
RC12 is the "skeleton pack" — docs were complete but runtime muscle was missing. v4.88-stable closed two gaps:
1. **Phase 2** re-mounted v4.87 runtime onto the v4.88 skeleton.
2. **B+ Bridge Hardening** promoted 4 core modules (init / evidence / close / verifier) from SCAFFOLD to GUIDED, validated end-to-end by a real trial.

v4.89 then inherited v4.88-stable in full and added 11 permanent contracts + LTM MVP + 5-profile parity + schema-driven cross-check + lift gate + skills library + cold-start governance + cross-project LTM Layer A. See `RELEASE_NOTES.md` §3 Headline Features for the per-Phase delta.

### Q5. Is there Long-Term Memory / Self-Evolution / cross-project platforming?
**LTM**: yes (since v4.89 Phase 2 Stage 1 MVP + Phase 4 M9.5 Layer A namespace). 4 domains (`os / project / pattern / failures`), `consult / capture` two-call API, optional `project_id` YAML field for per-project partition.
**Self-Evolution / cross-project platforming**: **deferred to v4.90+** (Layer C `replay()` + auto-promotion of cross-project patterns / Evolution Roadmap stages 2/3/4). These were intentionally out of v4.88's scope (9-decision item #5: harden, don't expand) and remain out of v4.89 scope.

### Q6. Where do my game's specialised content go?
Into `game_type_packs/<pack_name>/`. Point `game_pack` to it in the selection JSON at assemble time.

### Q7. Where do I file bugs?
- Bugs: to the project tracker (TAPD / GitHub / ...).
- v4.90 backlog: see `docs/V4.89_BACKLOG.md`.

---

## 6. Deeper reading paths

Read in the order that matches your role:

### 6.1 EP / tech lead (from zero to running)
1. This document (you are reading it).
2. `docs/USAGE_GUIDE.md` §1-§5 (profile / assemble / governance).
3. `docs/USAGE_GUIDE.md` §6 (Beta Sprint three-step chain + Maturity table).
4. `docs/PHASE_4_TRIAL_GUIDE.md` — follow it to run a Mock sprint.
5. `docs/09_beta_sprint/BETA_SPRINT_EXIT_CRITERIA.md` — authoritative 5-integrity definitions.

### 6.2 The operator who actually runs sprints
1. §3 §4 of this document.
2. `docs/PHASE_4_TRIAL_GUIDE.md` in full (§4 verifier / §5 S1 sample / §7 finding interpretation).
3. `trial_workspaces/README.md` — replay flow for the real workspace.
4. `scripts/verify_beta_sprint_exit.py --help`.

### 6.3 Reviewers / auditors
1. This document.
2. `AI_Game_Dev_OS_v4.90_Release/CHANGELOG.md` (§B+ / §B1-B6 / §v4.89-Phase 1 through Phase 4 / §RC1 / §RC2 / §RC3 / §v4.90 Batch 0-14 / §v4.90.1 / §v4.90.2 — v4.89 history is consolidated into v4.90's CHANGELOG).
3. `runtime/MATURITY_MATRIX.md` (maturity tag per script + per-Phase milestone ledger §3.1-§3.11).
4. External review records under `.workbuddy/reviews/v4.88_release/` (directory name retains its v4.88 origin; not inside the pack).

### 6.4 Script authors / maintainers
1. §3 of this document.
2. `docs/PHASE_4_TRIAL_GUIDE.md` §10 Regression Assertions + §10.1 B+ hardening table.
3. The 4 module-level smokes `scripts/_smoke_*.py`.
4. `CHANGELOG.md §B+` — technical details of the 12 hardening commits.

---

## 7. Next steps

- **First time trying?** → Read §6.1 in order and run one §4 Mock Sprint.
- **Want to use it on a real project?** → After reading §6.1, pick a profile and walk through §3.2's three-step chain once.
- **Want to review this pack?** → Read §6.3.
- **Want to pick up v4.90 hardening?** → see `docs/V4.89_BACKLOG.md` for the deferral list (Layer B retrieval upgrade / Layer C self-evolution / TAPD-Git live adapters / Architecture Linter rules A/B/D / Exit Verifier GUIDED tier upgrade).

### 7.5 v4.89 capabilities on top of v4.88-stable

> v4.89 adds the following on top of the v4.88-stable line. **Every usage in §3's three-step chain stays the same**; the additional capabilities surface only when you opt into them.

**7.5.1 Unified adapter event-envelope contract** (Phase 1)

The normalized record returned by an adapter no longer needs hand-built audit envelopes; the collector provides a helper:

```python
from runtime.observability.runtime_event_collectors.workbuddy_collector import (
    append_audit, wrap_external_record,
)
envelope = wrap_external_record(record, source_layer="tapd",
                                 runtime_profile="codex")
append_audit(workspace, envelope)
```

`wrap_external_record` fills in `event_id` / `timestamp` / `audit_status` for you. Locked as one of the 11 permanent contracts.

**7.5.2 Malformed event fallback** (Phase 1)

`append_audit(strict=False)` no longer silently drops non-conforming events; they land in
`<workspace>/runtime/logs/mcp_audit.malformed.jsonl`.

**7.5.3 Profile field alias + runtime_state path contract** (Phase 1)

- `runtime_state.json` writes both `profile` and `runtime_profile`; the verifier accepts either.
- The canonical location is `<workspace>/runtime/state/runtime_state.json`; a 1-line pointer shim stays at the workspace root for v4.88-stable backwards compatibility (will be removed in v4.90 per Phase 1 contract #4).

**7.5.4 LTM runtime + Layer A cross-project namespace** (Phase 2 Stage 1 + Phase 4 M9.5)

```python
from runtime.ltm import consult, capture
hits = consult("envelope contract")                      # all domains
hits = consult("handoff", project_id="rh")               # M9.5 namespace filter
capture(domain="project", title="Sprint retro", content="...",
        evidence_ref="commit abc1234", project_id="rh")
```

CLI: `python -m runtime.ltm "query" [--domain X] [--project Y] [--limit N]`. 4 domains + 5 Gate rules + 19 + 4 seed entries.

**7.5.5 5-profile parity + schema-driven cross-check** (Phase 2 Stage 2 + Phase 3)

All 5 runtime profiles' cross-check now flows through one `runtime/schema_driven_check.py` engine driven by profile JSON. R1 16-row regression matrix passes byte-identically before vs after the per-profile if-tree collapse.

**7.5.6 Lift gate + skills library + cold-start governance + Layer A namespace** (Phase 4 M7.3 / M8.0 / M9.0 / M9.5)

- `_stub_init` writes the full contract surface canonically; cross-check requires `field exists AND matches`.
- 28 generic + 3 godot SKILLs + 12 adaptation hooks (lexicon-scrubbed).
- 5 registries + manifest + 3 cold-start profiles + 16-key `cold_start_pack.v1` JSON. `boot_agent_thread` end-to-end.
- Optional `project_id` YAML field + `consult(project_id=...)` + per-project path `ltm/project/<id>/`.

**7.5.7 pytest baseline**

`tests/` contains a 259-case pytest suite covering every Phase 1 → Phase 4 contract. CI is **GitHub Actions + pre-commit** across two layers:

```bash
cd /path/to/AI_Game_Dev_OS_v4.89_Release
python3 -m pytest tests/ -v            # should be 259/259 green
```

Detailed setup in `DEVELOPMENT.md`.

**7.5.8 What v4.90 will do**

- Lift `execution` / `external` from SCAFFOLD to GUIDED.
- Layer B retrieval upgrade (SQLite FTS5 / `sqlite-vec` vector search).
- Layer C self-evolution (`replay()` + auto-promotion of cross-project patterns).
- TAPD / Git live adapters (currently normalize stubs).
- Architecture Linter rules A / B / D real implementations.
- Cross-project platform step (Evolution Roadmap stage 4).

See `docs/V4.89_BACKLOG.md` for the full deferral list.

---

## 8. Tag timeline

```
v4.88-release-scaffold  ← v4.88 skeleton + first Phase 4 successful run (historical)
v4.88-release-bplus     ← B+ Bridge Hardening complete (init / evidence / close / verifier
                          promoted to GUIDED) (historical)
v4.88-release-stable    ← v4.88 user-doc surface aligned with code (historical anchor of
                          v4.88_Revise development line)
v4.89-phase-1           ← v4.89 Phase 1: 11 permanent contracts + envelope contract +
                          E1-E7 green on workbuddy_private (2026-05-02)
v4.89-phase-2-m5        ← Phase 2 Stage 1 LTM MVP (2026-05-03)
v4.89-phase-2-stage-2-b1 ← Phase 2 Stage 2 5-profile parity (2026-05-04)
v4.89-phase-3-audit     ← Phase 3 schema-driven cross-checker audit
v4.89-phase-3-collapse  ← Phase 3 per-profile if-tree collapse
v4.89-phase-4-lift      ← Phase 4 M7.3 lift gate (2026-05-06)
v4.89-phase-4-skills    ← Phase 4 M8.0 skills import (2026-05-06)
v4.89-phase-4-coldstart ← Phase 4 M9.0 sprint+agent cold-start governance (2026-05-07)
v4.89-phase-4-cross-ltm ← Phase 4 M9.5 cross-project LTM Layer A (2026-05-08)
v4.89-release-rc1       ← M10.0 release freeze (2026-05-08)
v4.89-release-rc2       ← entry doc rename + content rewrite reflow (2026-05-08)
v4.89-release-rc3       ← v4.89 identity consistency overhaul ← current pack reflects this state
```

---

*This document is the first-read entry for v4.89. For deeper technical details, authoritative English terminology, and the strict semantics of the 5 integrity categories, go to `docs/USAGE_GUIDE.md` and `docs/PHASE_4_TRIAL_GUIDE.md`.*
