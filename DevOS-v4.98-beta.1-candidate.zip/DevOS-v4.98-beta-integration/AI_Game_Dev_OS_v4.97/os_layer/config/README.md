# config

This directory now stores the first stabilization-phase runtime policies.

## Core policies
- `stage_policy.yaml`
- `runtime_storage_policy.yaml`
- `initial_state_policy.yaml`

## Operational policies
- `reconciliation_thresholds.yaml`
- `context_loading_policy.yaml`
- `memory_retrieval_policy.yaml`
- `starter_attachment_policy.yaml`

These files are intentionally lightweight. Their role is to convert repeated prose assumptions into a canonical baseline contract.

- `starter_compatibility_policy.yaml`
