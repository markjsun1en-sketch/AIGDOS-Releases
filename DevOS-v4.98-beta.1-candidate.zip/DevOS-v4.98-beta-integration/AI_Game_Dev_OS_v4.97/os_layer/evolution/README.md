# evolution/ — Self-Evolution Authoring Tree (naming alias)

> **State**: v4.90 Batch 13 Step 13.3 — naming alignment with plan §8.2 字面.
> **Layer**: Layer 1 (OS Spec). No project names.
> **Governance note**: This top-level README and the
> `proposals/` / `accepted/` / `rejected/` placeholder subdirs
> created in Step 13.3 are **not** scanned by
> `scripts/governance/lint_layer_separation.py` (per EP D-13.3.2=B
> decision: keep 31 LAYER_1_ROOTS unchanged). Only
> `evolution/candidates/` and `evolution/sandbox/` remain under Layer
> 1 lint coverage. If these placeholder subdirs ever gain real
> content, fold them into `LAYER_1_ROOTS` at that time.

---

## 1. Naming alias

Plan §8.2 字面 lists this directory tree as the 5-folder authoring
surface for Self-Evolution proposals. v4.90 ships canonical content
split between two parents for historical reasons; this README
documents the mapping so cross-refs are unambiguous.

| plan §8.2 字面 path     | v4.90-rc2 canonical location |
|---|---|
| `evolution/proposals/`  | `proposals/` (workspace-level) — see `evolution/proposals/.gitkeep` for the indirection pointer |
| `evolution/accepted/`   | derived view: filter `proposals/evo_*.md` for `state == accepted` |
| `evolution/rejected/`   | derived view: filter `proposals/evo_*.md` for `state == rejected` |
| `evolution/candidates/` | `evolution/candidates/` (this tree, real subdir, Layer 1 lint coverage) |
| `evolution/sandbox/`    | `evolution/sandbox/` (this tree, real subdir, Layer 1 lint coverage) |
| `schemas/evolution/`    | `schemas/self_evolution/` (canonical) — see `schemas/evolution/README.md` |

---

## 2. Why a split

- `proposals/` lives at workspace root because v4.90 Batch 6 Step 6.1
  established it as the authoring surface for Self-Evolution drafts;
  cross-refs from `docs/17_self_evolution/` and the v4.90 ledgers
  point there.
- `candidates/` and `sandbox/` live under `evolution/` because they
  were introduced later (Batch 10 Step 10.2 + Step 10.4) as
  derivative stages where promoted proposals get their RFC notes and
  experimental diffs.

Migrating either side now would break dozens of cross-refs. The plan
§8.2 字面 alias here is the lower-risk path.

---

## 3. accepted/ and rejected/ as derived views

Neither `accepted/` nor `rejected/` holds independent files; they
are filtered views over `proposals/evo_*.md` keyed by the YAML
`state:` field. A future tool MAY materialise them as symlinks or
auto-generated indices. For now the `.gitkeep` markers in those
subdirs document intent only.

---

## 4. Cross-references

- `docs/17_self_evolution/SELF_EVOLUTION_OVERVIEW_v2.md` — pipeline doc
- `proposals/README.md` — authoring guide
- `evolution/candidates/README.md` — candidate stage spec (Layer 1)
- `evolution/sandbox/README.md` — sandbox discipline (Layer 1)
- `schemas/self_evolution/proposal_entry.schema.json` — canonical schema
- `schemas/evolution/README.md` — schemas alias README
