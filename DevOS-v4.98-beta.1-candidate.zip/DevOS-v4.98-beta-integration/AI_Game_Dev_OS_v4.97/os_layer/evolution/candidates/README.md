# evolution/candidates/ — Self-Evolution Candidate Landing Zone

> **Status**: shipped 2026-05-13 (v4.90 Batch 10 Step 10.2).
> **Layer**: Layer 1 (OS Spec). No project names.
> **Q4=A discipline**: proposal-only — nothing in this directory mutates canonical OS Core artefacts.

---

## 1. Role

Holds **candidate** materials for proposals that have transitioned to
`state == "accepted"` but have not yet entered `state == "implementing"`.
A candidate captures the structured plan (e.g. expanded
`change_candidate.affected_dirs`, expanded `validation_plan.required`,
risk registry, RFC-style discussion notes) that justifies the
upcoming implementation.

Pipeline relative to `proposals/` and `evolution/sandbox/`:

```
proposals/evo_YYYY_NNN_*.md  (state: draft -> submitted -> under_review -> accepted)
        │
        │  promote-to-candidate (manual; OS maintainer writes here)
        ▼
evolution/candidates/cand_evo_YYYY_NNN_<slug>.md   ← this dir
        │
        │  begin implementation (state: accepted -> implementing)
        ▼
evolution/sandbox/<evo_id>/                        ← read-only diff / experiment area
        │
        │  sign off + record commits (state: implementing -> implemented)
        ▼
proposal entry's implemented_at + implemented_by_commits filled in
```

---

## 2. Naming convention (recommended)

```
evolution/candidates/cand_<evo_id>_<short-kebab-slug>.md
```

- `<evo_id>` matches the source `proposals/evo_YYYY_NNN_*.md` proposal id (e.g. `cand_evo_2026_001_layer_separation.md`).
- The slug may differ from the proposal slug (e.g. focus on the
  candidate's main angle).

The convention is **not enforced** — Layer 1 lint accepts any
project-name-free filename. The recommendation exists to keep
proposal ↔ candidate ↔ sandbox traceability obvious.

---

## 3. Write rules

| Rule | Detail |
|---|---|
| **Who writes** | OS maintainer (or a delegated reviewer the maintainer has named in the proposal's `accepted_by` field). |
| **When** | Only after the source proposal has reached `state == "accepted"` (with `accepted_at` + `accepted_by` filled in). |
| **What** | Free-form Markdown describing the candidate plan. No specific schema enforced (yet). |
| **What NOT** | No canonical mutation. No silent overrides. No project-specific names. |

---

## 4. Q4=A boundary

This dir is **proposal-only** by contract. Per the EP-locked decision
recorded in `V4_90_COMPLETE_PLAN.md` §0:

> Self-Evolution stays **proposal-only**: only adds fields + directory
> skeleton; does NOT write a sandbox executor.

Concretely:
- No script under `scripts/` reads `evolution/candidates/*.md` and acts on it.
- No CI workflow auto-promotes a candidate to implementing.
- The transition `accepted -> implementing` is recorded by manually
  editing the source proposal's `state` field (validated by
  `scripts/self_evolution/validate_proposal.py` Step 10.3).

---

## 5. Schema link

The `proposal_entry.schema.json` (Batch 10 Step 10.1) introduces:

- `validation_plan.required[]` — the checklist a candidate's eventual
  implementation must pass.
- `change_candidate.affected_dirs[]` — repo-relative paths the
  candidate would touch. **Read-only metadata** — does NOT authorise
  mutation.

Both fields are filled in on the source proposal (`proposals/evo_*.md`),
not duplicated here. The candidate Markdown body may *reference* those
fields and elaborate, but the schema-bound source of truth lives in
the proposal entry.

---

## 6. Cross-references

- `proposals/` — upstream proposal ledger.
- `evolution/sandbox/` — downstream read-only experiment area.
- `schemas/self_evolution/proposal_entry.schema.json` — schema contract.
- `docs/17_self_evolution/PROPOSAL_LIFECYCLE_GUIDE.md` — full state model.
- `docs/17_self_evolution/PROPOSAL_VALIDATION_PLAN.md` — Step 10.5 doc on validation_plan rules.
