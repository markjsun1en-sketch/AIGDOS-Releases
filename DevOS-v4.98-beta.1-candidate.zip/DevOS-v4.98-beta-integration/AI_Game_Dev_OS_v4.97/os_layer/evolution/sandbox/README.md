# evolution/sandbox/ — Self-Evolution Read-Only Experiment Area

> **Status**: shipped 2026-05-13 (v4.90 Batch 10 Step 10.2).
> **Layer**: Layer 1 (OS Spec). No project names.
> **Q4=A discipline**: read-only by contract — sandbox NEVER writes canonical OS Core artefacts.

---

## 1. Role

Hosts the **read-only diff / experiment material** for proposals that
have transitioned to `state == "implementing"`. Each such proposal
SHOULD have a dedicated subdirectory:

```
evolution/sandbox/<evo_id>/
```

(matching the schema `sandbox_dir` field's `^evolution/sandbox/.+`
pattern). Inside that subdir, the implementer accumulates artefacts
that document **what would change** if the proposal were applied —
without actually applying it.

---

## 2. Allowed contents

| Kind | Examples |
|---|---|
| Unified diff files | `proposed.patch`, `runtime_change.diff` (output of `git diff` against a hypothetical change branch — never applied to canonical) |
| Experiment reports | `pytest_run_2026_05_13.txt`, `smoke_summary.json` |
| Migration replay logs | `mock_legacy_replay.log` (output of `run_mock_harness.py --fixture <preset> --out`) |
| Design notes | `design.md`, `risks.md`, `rollback_plan.md` |
| Schema deltas | `schema_changes.diff` (proposed JSON Schema additions) |
| Tooling output | Coverage reports, lint-baseline diffs, profiling traces |

All artefacts are **read-only-by-contract**. The implementer's job is
to *describe* the change well enough that an EP-approved
`accepted -> implemented` transition can subsequently apply it via a
real commit, **outside** the sandbox.

---

## 3. Forbidden actions (Q4=A enforcement)

The Q4=A boundary recorded in `V4_90_COMPLETE_PLAN.md` §0 forbids:

- ❌ Writing canonical OS Core files (`runtime/`, `schemas/`,
  `scripts/`, `docs/`, `agent_packs/`, etc.) **from within sandbox**.
- ❌ Auto-flow-back: no script reads sandbox content and propagates
  it into canonical artefacts.
- ❌ Sandbox-side scripts that mutate the parent repo. Anything
  executable under `evolution/sandbox/<evo_id>/` MUST be inert
  exploration code (e.g. `print()` smoke / `pytest --collect-only`
  output capture).
- ❌ Project-specific identifiers in sandbox README / design notes
  unless the file is explicitly a Layer 2 case study (NOT applicable
  by default — the sandbox lives under a Layer 1 root).

**No CI enforcement** of these rules ships in Step 10.2 — they are
contract-level discipline. A future tightening batch could add a
sandbox-allowlist linter (e.g. flag any `.py` under sandbox that
imports `runtime.*`); that is out of Step 10.2 scope.

---

## 4. Lifecycle

```
proposal state: accepted
        │
        │  1. Create sandbox/<evo_id>/ subdirectory.
        │  2. Set proposal's sandbox_dir field to "evolution/sandbox/<evo_id>"
        │     (validated by validate_proposal.py — Step 10.3).
        │  3. Transition proposal state -> implementing.
        ▼
proposal state: implementing
        │
        │  Implementer iterates inside sandbox/<evo_id>/:
        │    - drafts diffs / experiments / reports
        │    - runs pytest snapshots, harness replays, etc.
        │    - documents risks, rollback plans
        │  No canonical mutation occurs.
        │
        │  When the candidate is mature + EP signs off:
        │    - A real commit lands the change in canonical files
        │      (made outside sandbox; reviewed normally).
        │    - Proposal's implemented_at + implemented_by_commits
        │      get filled in.
        │    - Proposal state -> implemented.
        ▼
proposal state: implemented
        │
        │  Sandbox subdir may stay as historical evidence,
        │  or be archived (e.g. moved to a tarball under
        │  archive/ in a project's adopting tree).
```

---

## 5. Naming convention

```
evolution/sandbox/<evo_id>/
```

- `<evo_id>` matches the source `proposals/evo_YYYY_NNN_*.md` id
  exactly (no slug suffix — keeps the dir name short and deterministic).
- Inside the subdir, files use lowercase kebab/underscore. No project
  names.

Layer 1 lint will reject any sandbox file that mentions a
well-known external project identifier (the project-name allowlist
declared in `scripts/governance/lint_layer_separation.py`) —
sandbox is **not** Layer-2-exempt by default.

---

## 6. Schema link

`schemas/self_evolution/proposal_entry.schema.json` (Batch 10 Step 10.1):

```json
"sandbox_dir": {
  "type": ["string", "null"],
  "pattern": "^evolution/sandbox/.+"
}
```

Validation rules:

| Proposal state | sandbox_dir requirement |
|---|---|
| `draft` / `submitted` / `under_review` | Optional. May be `null` or omitted. |
| `accepted` | Optional. The implementer typically fills it in just before transitioning to implementing. |
| `implementing` | **Required + non-null** (enforced by `validate_proposal.py` — Step 10.3). |
| `implemented` | Retained as historical pointer. |

When a proposal does not need a sandbox (e.g. a pure
`architecture_principle` proposal that adds doctrine without code
change), `sandbox_dir` may stay `null` even in `implementing` —
Step 10.3 will treat that as a documented exception.

---

## 7. Cross-references

- `proposals/` — upstream proposal ledger.
- `evolution/candidates/` — pre-implementing candidate plans.
- `schemas/self_evolution/proposal_entry.schema.json` — schema contract.
- `docs/17_self_evolution/PROPOSAL_LIFECYCLE_GUIDE.md` — full state model.
- `docs/17_self_evolution/PROPOSAL_VALIDATION_PLAN.md` — Step 10.5 doc.
- `scripts/self_evolution/validate_proposal.py` — validator (Step 10.3 will enforce sandbox_dir non-null when state == implementing).
