# v4.89 Developer Setup

## Test gate (two-layer, CI configs repo-side only)

v4.89 Phase 1 defines a **two-layer test gate** (EP-locked decision Q2,
2026-05-02). The gate is conceptual; the **CI / pre-commit configs
themselves are NOT shipped inside the release zip** — they live only in
the source repository that builds the release, and are enabled there.

If you are consuming this release as a downstream package (e.g. you
unpacked `AI_Game_Dev_OS_v4.89_Release/` into your project), you should
run the tests manually (see "Running tests manually" below). If you are
working inside the source repository, enable the CI layers per the
Upstream Repository section.

### Layer 1 — GitHub Actions (server-enforced, repo-side)

Workflow (repo-side only): `.github/workflows/v4_89_tests.yml`

Jobs (run on every push / PR that touches the v4.89 release source):

- `pytest-v4-89` — Python 3.11 + 3.12 matrix; runs the full
  `tests/` suite.
- `smoke-v4-89` — `scripts/run_mock_smoke.sh` (S1/S3/S4/S5/S5b
  matrix) plus the 4 `scripts/_smoke_*.py` regressions.

Server-enforced means: the workflow runs unconditionally on merged
code in the upstream repo. It is not part of the release artifact.

Initial validation: the workflow includes `workflow_dispatch` so the
EP can trigger one manual run to verify the YAML before the first
push-triggered run lands.

### Layer 2 — pre-commit (local, opt-in, repo-side)

Config (repo-side only): `.pre-commit-config.yaml`

This is the **fast-feedback loop** for contributors working in the
upstream repo. It runs a reduced pytest + smoke pass locally before
each commit, so you don't push a red CI.

**To enable (one-time per clone of the upstream repo)**:

```bash
pip install pre-commit
pre-commit install
```

Once installed, every `git commit` that touches
`tests/ scripts/ integrations/ runtime/` Python files will run pytest
locally; commits touching `scripts/_smoke_*.py` will also re-run the
relevant smoke scripts.

If you prefer not to install pre-commit, the Actions layer still
catches regressions on push — you just find out slower.

## Running tests manually

Run these **from the `AI_Game_Dev_OS_v4.89_Release/` directory**
(i.e. the release root, which is also the repo root when working
upstream):

```bash
python -m pytest tests/ -v        # 259 cases
bash scripts/run_mock_smoke.sh    # 5-scenario mock matrix (S1/S3/S4/S5/S5b)
for s in scripts/_smoke_*.py; do
  python3 "$s" || exit 1
done
```

Notes:

- Smoke harness outputs go to `exports/smoke/latest/` (runtime-generated;
  excluded from `RELEASE_MANIFEST.json` / `CHECKSUMS.sha`).
- `exports/` is safe to delete at any time.

## Why two layers

- **Actions** (repo-side) is the single source of truth for "this is
  green" — the tag `v4.89-phase-1` is only valid for a sha where
  Actions passed.
- **pre-commit** (repo-side) catches mistakes in seconds instead of in
  the CI queue. Optional because some contributors work from laptops
  where installing dev tooling is friction-heavy; Actions is the
  backstop.

## Upstream Repository

The CI configs described above are maintained in the upstream source
repository (not shipped in this release zip). If you need to view or
modify them, work against that repository rather than editing files
inside an unpacked release tarball.
