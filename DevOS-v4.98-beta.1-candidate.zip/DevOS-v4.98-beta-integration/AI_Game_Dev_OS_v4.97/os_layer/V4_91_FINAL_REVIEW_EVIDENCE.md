# V4.91 FINAL REVIEW EVIDENCE

> **Single-version evidence record.** This file carries ONLY the current
> v4.91 RC1-review-cycle evidence. It deliberately does not mix the long
> per-stage history kept in `RELEASE_NOTES.md`. Created in response to the
> RC1 review (gap D: "release evidence documents have stale-version
> residue"). Maintainer evidence per contract #13.
>
> **Timestamp:** 2026-05-30 (RC2-FC2 re-baseline — 3rd review closure)
> **Version labels (dual-track, EP Q1=a):** the working tree
> `AI_Game_Dev_OS_v4.91/` carries `VERSION = 4.91-WIP` as the v4.92
> `base_from` anchor; the byte-locked release artifact
> `AI_Game_Dev_OS_v4.91_Release/` carries `VERSION = 4.91-Release`.
> Both are correct and coexist by design — this is NOT a stale residue.
> All release-facing labels use the exact form `4.91-Release`.
> **Layer 1 (OS Spec). No project names.**

---

## 1. Package fingerprint

| Metric | Value |
|---|---|
| `required_manifest_files` | 1214 |
| `optional_seed_files` | 31 |
| `test_fixtures` | 120 |
| pytest collected | 1765 tests |
| protected invariants | 15 (`inv_001`..`inv_015`) |
| fast-gate items | 25 (F1, F3–F22, F8a–F8d, F2) |
| manifest `--check` | clean ✓ byte-stable, no drift |

## 2. Interpreter requirement (READ FIRST)

The closure gate's pytest-based checks run under **the interpreter that
launches the gate** (v4.91 P2 A1 fix: aggregate + required-regressions now
normalize a leading `python3` token to `sys.executable`). That interpreter
**MUST have `pytest`** (and, for the schema *tests*, `jsonschema`).

- Governance **validators** are zero-dependency and run under any Python 3.x
  (v4.89 discipline) — e.g. `validate_delegation_decisions.py`,
  `validate_preflight_reviews.py`.
- Governance **gate sub-checks that invoke pytest** (F1 collect-only,
  F5 schema_self_validation, F8a–F8d, F6 pytest invariants) require pytest
  in the launching interpreter.

Running the gate with an interpreter that lacks pytest will fail those
items — that is an environment misconfiguration, not a package defect.

## 3. Fast closure gate — 3-run evidence

Command (per run, tree cleaned between runs):

```
python3 scripts/governance/run_release_closure_gate.py \
  --profile fast --fast-total-timeout 300 --format json
```

Launched by an interpreter with the test toolchain.

| Run | dispatcher_exit | overall_exit | elapsed | pass | fail | stray pytest after |
|-----|-----------------|--------------|---------|------|------|--------------------|
| 1   | 0               | 0            | 9.127s  | 25   | 0    | 0                  |
| 2   | 0               | 0            | 9.346s  | 25   | 0    | 0                  |
| 3   | 0               | 0            | 9.387s  | 25   | 0    | 0                  |

**All 25 fast-gate items pass; overall_exit=0; zero stray processes.**
This is the first fully-green fast gate since the v4.91 freeze reopened.

## 4. Pytest split (by domain, launched with pytest)

Targeted suites exercised during this cycle (all green):

| Suite | Result |
|---|---|
| `tests/hub` | 47 passed |
| `tests/mount` | 58 passed |
| `tests/version` | 42 passed |
| `tests/hub/test_preflight_pattern_registry.py` (P1-b) | 12 passed |
| `tests/preflight/test_preflight_schemas.py` (P1-c) | 11 passed |
| `tests/governance/test_fast_gate_supervisor_killpg.py` (P0) | 4 passed |
| dispatcher + grandchild-cleanup + report-schema (P0 regression) | 17 passed |
| 5 previously-"failing" invariant suites (F6) | 58 passed |

Full collection: 1765 tests. (A full single-process sweep is the Final
ceremony's job; this record captures the targeted evidence for the
review fix cycle.)

## 5. Full closure gate

`--profile full` delegates verbatim to the frozen RC3 13-check contract
with the v4.91 baseline-override layer (EXPECTED_PYTEST_V4_91 /
EXPECTED_LAYER1_ROOTS_V4_91). To be run at the Final ceremony under an
interpreter with pytest:

```
python3 scripts/governance/run_release_closure_gate.py --profile full \
  --pytest-timeout 1800 --aggregate-timeout 1800 \
  --pytest-disable-plugin-autoload --format json
```

## 6. RC1-review resolution map

| RC1-review item | Resolution | Commits |
|---|---|---|
| **P0** Batch 0 gate runner: timeout doesn't kill child/grandchild | Daemon-thread watchdog replaced with killpg-able per-item subprocess model; cross-process regression test proves child+grandchild reaped | `8d891a1`..`7a49ee7` (B0 c1–c5) |
| **gap A** `hub/versions.lock` seed-vs-generated ambiguity | Documented as a generated artifact (not a seed); 3 doc clarifications + explicit "Seed vs generated" block | `529c98d`,`1504614` (P1-a c1–c2) |
| **gap B** `hub/preflight/` only `.gitkeep` | Seeded governance pattern candidate registry (schema + seed + index + metrics + CLI + tests + F21) | `1ffddd8`..`2c3255c` (P1-b c1–c5) |
| **gap C** project-level multi-agent preflight workflow missing | S3 hybrid: event-stream ledger + 3 typed details schemas + templates + zero-dep validator + F22 + inv_015; SKILL/REFERENCES "no schema" claims retracted | `dc7d3ae`..`d0c477e` (P1-c c1–c5) |
| **gap D** release evidence stale-version residue | This file (single-version evidence) + REQUIRED_CONTENT_CHECKLIST v4.90→v4.91 + RC-status note | P2 c1–c2 |
| **F5/F6** spurious failures | Root cause = gate ran `python3 -m pytest` against an interpreter without pytest; fixed by `sys.executable` normalization in aggregate + required-regressions (byte-locked matrix untouched) | `c264663`,`8b654db`,`d426694` (P2 A1 c1–c3) |

## 7. Known limitations / non-goals

- **Interpreter dependency** — pytest-based gate items require pytest in the
  launching interpreter (see §2). Documented, not a defect.
- **B5 cross-project learning write path** — the hub preflight pattern
  registry (P1-b) and the project-level preflight ledger (P1-c) ship with
  seed/empty content + read-only CLI + validator. The *write* path (real
  cross-project promotion) is a future B5 deliverable, not v4.91.
- **Advisory ≠ enforcement** — the multi-agent preflight surface records and
  shape-checks decisions; it never gates closure (`inv_015`). Gate-blocking
  preflight remains the separate B5B path (`run_preflight_consensus.py`).
- **VERSION dual-track** — the working tree stays `4.91-WIP` (v4.92
  `base_from` anchor); the byte-locked release artifact carries
  `4.91-Release`. Both correct by design (EP Q1=a), not stale residue.

## 8. Path to Final

1. (done) P0 + P1-a/b/c + P2 + F5/F6 — fast gate green.
2. (done) RC2 closure-gate replay (full profile) under a pytest-equipped
   interpreter → tag `v4.91-RC2`.
3. (RC2-FC1, SUPERSEDED) Batch 0 fast-gate nested-killpg orphan fix —
   added a `new_session` param + `GATE_IN_SINGLE_ITEM` wiring for the
   dispatcher's direct runner. Tagged `v4.91-release` as "Final", but
   the 3rd review reproduced the orphan again on the real F6 path: this
   fix did NOT cover the F5/F6 second-level scripts. The `v4.91-release`
   tag was retracted (`git tag -d`, EP-approved).
4. (RC2-FC2, done) Root-cause fix for the second-level-script leak —
   the legacy `run_pg_safe` / `run_pg_safe_to_file` wrappers now honour
   `GATE_IN_SINGLE_ITEM` (`new_session=not nested`), so F5/F6 inner
   pytest stays in the dispatcher's group and the single outer killpg
   reaps the whole tree. One fix covers F5+F6. Bidirectionally-verified
   regression (`test_dispatcher_kills_legacy_wrapper_inner_process_group`:
   fix→green, revert→reproduces orphan). 3× fast gate 300s: exit=0,
   25/25 pass, 0 stray; 5s negative: RC=1, F6 killed, 0 stray; full
   pytest 1763 passed / 2 skipped; full closure gate 13/13 in both trees.
   Tagged `v4.91-RC2-FC2`.
5. (Final, done 2026-05-30) Final ceremony — the 4th external review
   accepted the RC2-FC2 artifact at **9.0/10** as
   `AI_Game_Dev_OS_v4.91_Final_Candidate_Accepted`. The release artifact
   keeps `VERSION = 4.91-Release`, the `_Release/` byte-locked tree, and
   the clean zip; the working tree stays `4.91-WIP` as the v4.92 anchor.
   Tagged `v4.91-Final_Candidate_Accepted`. The four residual remarks are
   non-blocking and tracked for v4.92 (see §9).

## 9. 4th external review — acceptance record (2026-05-30)

**Verdict: 9.0 / 10 — accepted as `AI_Game_Dev_OS_v4.91_Final_Candidate_Accepted`.**
First Final acceptance after four ceremony retractions/rejections
(P10 / P10' / P10'-reexec / RC2-FC1). The reviewer reproduced the official
acceptance commands independently:

| Suite | Result |
|---|---|
| fast gate (full profile) | **25/25 pass** (≈265.77s wall, within the 300s budget) |
| fast gate timeout negative | **0 stray** (F6 killed, rest skipped, RC=1) |
| `tests/hub` | **59 pass** |
| `tests/mount` | **58 pass** |
| version suite | **42 pass** |
| `tests/preflight` | **23 pass** |
| killpg regression | **5 pass** (incl. the second-level legacy-wrapper path) |

**Non-blocking remarks (tracked for v4.92, not Final blockers):**
1. fast-gate total ≈265.77s — passes within 300s but headroom is modest.
2. `tests/hub` / `tests/mount` run slowly — Hub/Mount CLI is still heavy.
3. `RELEASE_NOTES.md` is long — historical RC/FC lineage raises external
   reviewer reading cost.
4. `REQUIRED_CONTENT_CHECKLIST.md` was checkbox-style — now SIGNED_OFF at
   this Final ceremony; a fully templated sign-off form is a v4.92 polish.

**Decision (EP)**: standing as `Final_Candidate_Accepted` (the stricter of
the reviewer's two suggested labels). v4.91 freeze sequence is COMPLETE; no
further feature batches enter v4.91 — the four remarks roll into v4.92.
