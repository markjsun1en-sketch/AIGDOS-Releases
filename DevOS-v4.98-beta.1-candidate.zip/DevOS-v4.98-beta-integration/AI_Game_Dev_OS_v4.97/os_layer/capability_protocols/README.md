# capability_protocols/ — Capability Protocol Layer (v4.92)

> **Status**: ACTIVE (v4.92 B1-B12) — protocol schemas and evidence contracts
> are present in this directory. B13 still needs release-dir packaging and final
> consistency evidence.
> **Layer**: Layer 1 — Capability Protocol Layer (roadmap §5 / Implementation Plan §5)
> **Path decision**: This is the canonical home per **Charter §6**. The Implementation Plan §25 alias `schemas/capability/` is **retired** (EP sign-off 2026-05-31).

---

## Purpose

This layer does **not** implement any concrete game-production capability. It defines the
**contracts** that every production capability pack / agent / skill MUST satisfy before it can
advance past `draft` in the pack lifecycle.

It is the structural firewall that prevents future agents / skills from sprawling (roadmap R1/R2/R5).

## Current contents

| File | Purpose |
|---|---|
| `capability_pack.schema.json` | Pack manifest contract (pack_id / version / layer / lifecycle / engine_support / depends_on / allowed_writes / forbidden_writes / validation / rollback / collision_policy / adoption) |
| `agent_contract.schema.json` | Agent production contract (owns / can_modify / must_not_modify / required_inputs / required_outputs / validation / handoff_triggers / completion_evidence / non_completion_conditions) |
| `skill_contract.schema.json` | Skill landing contract (use_when / allowed_writes / forbidden_writes / required_outputs / execution_steps / open_decision_space / validation_commands / failure_handling / rollback / example_task / non_completion) |
| `validation_evidence.schema.json` | Reviewed validation evidence envelope for production handoff. |
| `production_handoff.schema.json` | Production handoff contract tying owner, evidence, writes, and completion state. |
| `rollback_note.schema.json` | Rollback / recovery note contract for capability tasks. |
| `lead_capability.schema.json` | Lead-capability control-plane contract. |
| `os_verdict.schema.json` | OS-level verdict envelope for capability migration decisions. |
| `hooks/` | Minimal hook stub schemas used by the v4.92 capability protocol layer. |

Validators (`run_practicality_gate.py`, `run_boundary_linter.py`) live under
`scripts/capability/`.

## Engineering directive (Charter §4)

机制先于内容:Phase 0 (schema + gate + linter) 锁死后再做 pack 内容。所有 governance/validator
脚本遵守**零外部依赖纪律**(MEMORY 永久教训:validator 用 bare `python3` 跑,不 import jsonschema)。
