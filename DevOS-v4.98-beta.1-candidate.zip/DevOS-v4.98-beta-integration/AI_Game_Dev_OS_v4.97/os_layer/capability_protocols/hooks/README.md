# capability_protocols/hooks/ — v4.93+ Minimal Hooks (v4.92 Batch 7)

> **Status**: INTERFACE STUBS ONLY (Charter §5.3 / roadmap R7).
> These five hooks reserve the interface surface for the six original roadmap
> mainlines that v4.92 deferred to v4.93+. They carry a minimal, forward-
> compatible schema each, and **no runtime implementation**. Their purpose is
> to prevent a future "line break" — when v4.93 implements a mainline, it
> extends the stub instead of inventing a new surface.

---

## The five hooks

| Hook file | Reserves | v4.93+ mainline |
|---|---|---|
| `truth_map.stub.schema.json` | shared-truth minimal map (project fact index) | Shared Truth |
| `architecture_scan.stub.schema.json` | minimal architecture scan record | Architecture Baseline |
| `event_trace.stub.schema.json` | minimal event-trace entry | Observability |
| `owner_approval.stub.schema.json` | minimal owner / approval marker | Teamwork / Review Queue |
| `pack_evidence_metadata.stub.schema.json` | minimal pack-evidence metadata | Pack Registry / DB-RAG |

## Rules

- Each stub is draft-07 valid and `additionalProperties: false` so a v4.93
  implementation must consciously widen it (no silent sprawl).
- Each carries `_deferred: { since: "v4.92", implement_in: "v4.93+", mainline: "..." }`.
- Nothing in v4.92 reads or writes these — they are reservation only.
- A stub MUST NOT grow logic in v4.92. If a task seems to need one, that is a
  signal the work belongs in v4.93, not here.
