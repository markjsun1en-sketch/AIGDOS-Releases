# REQUIRED CONTENT CHECKLIST

The following content checklist is attached to the clean **v4.92 release
package**.
It preserves the inherited v4.91 release-package checklist and adds the v4.92
capability / migration closure surface.

> **Status (v4.92 Release, 2026-06-04):** this is the release-dir
> content-presence checklist. B12 implementation and validation evidence are
> committed; B13 acceptance is proven by the v4.92 C9-C13 deliverable overlay,
> annotated `v4.92-release` tag, and workspace-level release rehearsal evidence.

> **Inherited baseline:** the v4.91 rows below remain relevant because v4.92 is
> additive on top of `AI_Game_Dev_OS_v4.91_Release/`. They do not by themselves
> certify v4.92 closure.

## Entry / version
- [ ] README.md is current for the active release package
- [ ] MERGE_MANIFEST.md matches actual package root wording
- [ ] VERSION matches this release artifact's label: `4.92-Release`.

## Core entry
- [ ] docs/00_entry/START_HERE.md
- [ ] docs/00_entry/AI_Game_Dev_OS_v4.89_Overview.md
- [ ] docs/00_entry/CORE_OS_DIGEST.md
- [ ] docs/00_entry/EXECUTION_PROFILE_SELECTION.md

## Governance / runtime core
- [ ] docs/02_governance/PORTABLE_AGENT_BOUNDARIES.md
- [ ] docs/02_governance/PORTABLE_RECOVERY_PRINCIPLES.md
- [ ] docs/02_governance/GOVERNANCE_MAP.md
- [ ] docs/03_runtime_core/Runtime_Bootstrap_Spec.md
- [ ] docs/03_runtime_core/Root_Discovery_Spec.md
- [ ] docs/03_runtime_core/Runtime_Init_No_Demo_Spec.md
- [ ] docs/03_runtime_core/Migration_and_Path_Validation.md

## Integrations / observability
- [ ] docs/04_integrations/TAPD_Integration_Baseline.md
- [ ] docs/04_integrations/Git_Agent_Workflow_Baseline.md
- [ ] docs/05_observability/AUDIT_LOG_STANDARD.md

## Runtime profiles
- [ ] docs/06_runtime_profiles/Runtime_Profile_Comparison.md
- [ ] public runtime profile directories present
- [ ] workbuddy_private contains rule loading, context loading, writeback policy, recovery SOP, and private limitation docs

## Starters
- [ ] docs/07_starters/Starter_Family_Overview.md
- [ ] docs/07_starters/shared/Agent_Definition_Template.md
- [ ] docs/07_starters/shared/Agent_Definition_Example.md
- [ ] docs/07_starters/workbuddy_private/Workbuddy_Private_Starter_Guide.md
- [ ] workbuddy starter templates include AGENTS and SKILLS templates

## Beta sprint
- [ ] docs/09_beta_sprint/BETA_SPRINT_READY_GUIDE.md
- [ ] docs/09_beta_sprint/SPRINT0_PRECHECK.md

---

## v4.92 Capability Foundation (additive release)

> v4.92 is an **additive** release on top of the v4.91 content surface above
> (no v4.91 content removed; this release package carries `4.92-Release`). The boxes below cover the
> capability packs/agents/skills layer added in v4.92 B1–B9. Checked at the
> v4.92 ceremony by the EP, not by tooling. Engineering evidence:
> `V4_92_B8_DEMO_EVIDENCE.md` + the full closure gate 13/13 record.

### Capability protocols & docs
- [x] capability_protocols/{capability_pack,agent_contract,skill_contract}.schema.json (B1)
- [x] schemas/adoption/{capability_pack_adoption_state,capability_pack_lock}.schema.json (B3)
- [x] docs/30_capability_packs/DATA_PIPELINE_PACK.md (incl. §7 Output Adapter, B5/B5.5)
- [x] docs/30_capability_packs/PACK_ADOPTION_FLOW.md (incl. §8 Phase-4 tools)
- [x] docs/30_capability_packs/GODOT_2D_ADAPTER.md (B4)
- [x] docs/30_capability_packs/CAPABILITY_DEMO.md (B8)

### Packs & tools
- [x] packs/engine_adapters/godot_2d/ (B4 engine-adapter pack)
- [x] packs/game_system_packs/data_pipeline/ (B5 vertical slice + B5.5 output adapter)
- [x] scripts/capability/ adoption track (adopt_pack + list/validate_active/report + demo + evidence)

### Release evidence
- [x] V4_92_B8_DEMO_EVIDENCE.md (B0–B8 + B5.5 + P0-9 closure)
- [x] full closure gate `--profile full` 13/13 PASS (overrides=[C1,C2], 2-run deterministic)
- [x] joint regression 1874/2; capability tests 93; layer separation 72 roots / 0 violations
- [x] v4.91 byte-lock (inv_001) + v4.89 byte-lock untouched across all of v4.92

### EP sign-off (v4.92-Capability_Foundation)
- [ ] EP: content present + engineering evidence reviewed → approve tag `v4.92-Capability_Foundation`
