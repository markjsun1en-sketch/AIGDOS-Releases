# AI Game Dev OS v4.89 Assembly Guide

> **Status (v4.89)**: this guide documents assembly for the v4.89 Release tree. v4.89 inherits the v4.88 Portable Core layout with Phase 1-4 hardening applied; the assembly principles below are unchanged since v4.88-stable (the "Run_Baseline" layer + context_packs + game_type_packs separation still holds). See `CHANGELOG.md` for the per-phase delta and `RELEASE_NOTES.md` for the v4.89 consumer summary.

## Recommended directory layering

- `docs/` — runtime rules, governance, runtime-profile specs, starter docs (the "Run_Baseline" layer).
- `context_packs/` — Lean / Standard / Expanded / Full Reference context-loading modes.
- `game_type_packs/` — project-type templates (generic / card_roguelike / spin_rogue_idle_project_pack / ...).
- `skills/` + `config/` + `integrations/` + `scripts/` — the actual runtime surface being assembled.

## Recommended loading order

1. **Base Runtime**: load `docs/` + `config/` + `scripts/` + `runtime/` as the Run Baseline.
2. **Stage Policy**: pick MVP / VS / Production (see `docs/02_governance/GOVERNANCE_MAP.md`).
3. **Context Loading Mode**: pick one tier under `context_packs/` (Lean / Standard / Expanded / Full Reference).
4. **Genre / Starter Adaptation**: mount one `game_type_packs/<pack>/` that matches the project type.
5. **On-Demand Reference Retrieval**: only consult `context_packs/full_reference/` when traceability is required.

## Minimal usage principles

- Runtime rules, field definitions, state machines, governance loops → `docs/` + `runtime/`.
- Context-loading modes → `context_packs/`.
- Project-type templates → `game_type_packs/`.
- Historical rationale and extension materials → `context_packs/full_reference/` or the external `.workbuddy/reviews/`.

## Conflict precedence

`docs/` + `runtime/` > `game_type_packs/` / `context_packs/` > `full_reference`.

## Other entries

- The authoritative usage document for the pack is `docs/USAGE_GUIDE.md` (this file gives only a minimal assembly skeleton).
- This file was originally introduced in v4.88 as a placeholder while v4.87 assets were being migrated; it now documents the stable v4.89 assembly skeleton. For actual usage details, prefer `USAGE_GUIDE.md`.
