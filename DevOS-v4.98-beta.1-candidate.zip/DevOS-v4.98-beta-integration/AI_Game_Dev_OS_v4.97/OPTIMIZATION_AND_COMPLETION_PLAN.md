# AI Game Dev OS v4.93 Optimization and Completion Plan

Status: local planning document
Scope: `AI_Game_Dev_OS_v4.93/`
Roadmap baseline: `AI_Game_Dev_OS_Roadmap_v4.91_to_v5.0_Production_Capability_First_Revised.md`
Target interpretation: v4.93 = Core Layer inheritance + Pack Layer expansion + Core-Pack Integration evidence

Current alignment note: this file is a historical implementation plan. For the
current v4.93 root-level entrypoint and machine-readable manifest, use
`INDEX.md` and `MANIFEST.json`. For current completion status, use
`packs/game_system_packs/end_to_end_production/docs/roadmap/PHASE_STATUS.md`.

## 1. Current Understanding

The current v4.93 tree is concentrated in three areas:

- `packs/game_system_packs/end_to_end_production/`
- `scripts/delivery/`
- `tests/delivery/`

The implemented surface is strongest in end-to-end production pack contracts, GDD orchestration, GDD quality evaluation, delivery artifact validation, project readiness checks, and fixture-backed evidence.

The current tree is not a complete v4.93 Core Layer implementation. It inherits the Core/Hub/Mount/Gate/Version Lock and capability protocol foundations from v4.91/v4.92, then adds a v4.93 `game_system_pack` layer on top.

## 2. Roadmap Gap Summary

Roadmap v4.93 target:

```text
Shared Truth
+ Architecture Baseline
+ Controlled Small Refactor
+ Production Pack Beta
```

Current v4.93 status:

```text
Production Pack Draft
+ strong GDD production harness
+ delivery artifact validation
+ runtime/data/art/QA contracts
+ project readiness fixtures
```

Main gap:

```text
The pack layer is strong, but the roadmap-level shared truth,
architecture baseline, controlled refactor demo, and beta evidence
are not yet implemented as first-class v4.93 closure surfaces.
```

## 3. Target State

Move v4.93 from:

```text
Production Pack Draft + strong GDD/delivery harness
```

to:

```text
v4.93 Roadmap-complete Beta Candidate
```

The target state requires:

- Full capability README and capability map.
- Working CLI paths for `start`, `plan`, and `validate`.
- Shared Truth index for artifacts, sources, owners, evidence, and write-back requests.
- Architecture baseline for project runtime surfaces.
- One controlled small refactor demo with approval and before/after evidence.
- Agent execution trace/run-plan protocol for external runtime adapters.
- Beta readiness gate and evidence package.

## 4. Phase 0 - Entry Point and Harness Credibility

Priority: P0
Estimated scope: small
Purpose: remove immediate trust gaps before adding new capability.

### Work Items

1. Fix `run_gdd_orchestrator.py validate`.
   - Current failure: `validate --artifact-root ...` can raise `AttributeError: 'Namespace' object has no attribute 'intent'`.
   - Expected behavior: `validate` should not require `intent` or `project_id`.

2. Add exact CLI regression tests.
   - `start` creates run package.
   - `plan` creates run package.
   - `validate` with only run package returns `waiting_for_agent_outputs`.
   - `validate` with passing fixture returns a non-blocked state.
   - `validate` with bad or incomplete artifacts returns `blocked` or `quality_failed`.

3. Rewrite v4.93 README into a full capability README.
   - Keep GDD quick start, but demote it from full v4.93 identity.
   - Add layer map, pack map, agent map, harness map, roadmap alignment, and known gaps.

### Acceptance Criteria

- `python3 AI_Game_Dev_OS_v4.93/scripts/delivery/run_gdd_orchestrator.py validate --artifact-root <planned_root>` does not crash.
- Focused delivery tests pass.
- README no longer implies v4.93 is only GDD generation.

## 5. Phase 1 - Shared Truth Foundation

Priority: P0/P1
Purpose: convert pack-local truth into a project/shared truth surface.

### New Surfaces

Proposed files:

- `packs/game_system_packs/end_to_end_production/references/shared_truth/truth_source_map.schema.json`
- `packs/game_system_packs/end_to_end_production/references/shared_truth/artifact_index.schema.json`
- `packs/game_system_packs/end_to_end_production/references/shared_truth/git_evidence_refs.schema.json`
- `packs/game_system_packs/end_to_end_production/references/shared_truth/writeback_request.schema.json`

Proposed scripts:

- `scripts/delivery/generate_shared_truth_index.py`
- `scripts/delivery/validate_shared_truth_index.py`

### Minimum Capability

- Index v4.93 artifacts by artifact type, path, owner, source refs, evidence refs, and status.
- Map `canonical_gdd_index`, `design_fact_registry`, production specs, QA evidence, RawData manifests, runtime manifests, and approval records into one shared truth view.
- Detect orphan artifacts, duplicate canonical owners, missing evidence refs, and unresolved proposed facts.
- Support approved write-back request records without performing automatic external write-back.

### Acceptance Criteria

- A generated artifact index covers all 43 valid delivery fixture artifacts.
- Missing source refs fail validation.
- Duplicate canonical truth ownership fails validation.
- GDD canonical facts can be traced to shared truth entries.

## 6. Phase 2 - Architecture Baseline

Priority: P1
Purpose: add code/project architecture understanding, not only GDD dependency maps.

### New Surfaces

Proposed schemas:

- `references/architecture/module_map.schema.json`
- `references/architecture/scene_script_map.schema.json`
- `references/architecture/resource_map.schema.json`
- `references/architecture/design_code_trace_matrix.schema.json`
- `references/architecture/architecture_smell_report.schema.json`

Proposed scripts:

- `scripts/delivery/inspect_architecture_baseline.py`
- `scripts/delivery/validate_architecture_baseline.py`

### Minimum Capability

- Scan Godot-style project surfaces:
  - `res://scripts/**`
  - `res://scenes/**`
  - `res://resources/**`
  - `res://data/**`
  - `RawData/**`
- Map scene to script, script to data/resource, and production spec to runtime surface.
- Produce an architecture smell report without automatically refactoring.
- Require architecture baseline references before selected runtime production execution paths.

### Acceptance Criteria

- Ready project fixture can produce an architecture baseline.
- Missing scene/script/resource references are reported.
- Production spec patch can cite architecture baseline entries.
- Runtime execution is blocked when required architecture refs are missing.

## 7. Phase 3 - Controlled Small Refactor Demo

Priority: P1
Purpose: implement the roadmap Demo B closure path.

### Demo Candidate

Recommended small slice:

```text
Status display / buff boundary / GameString display repair
```

This aligns with existing valid delivery fixtures that already include RawData, GameString-like runtime data, status display scene/script artifacts, QA evidence, visual crop evidence, and rollback notes.

### New Artifacts

Proposed schemas:

- `architecture_smell_report.schema.json`
- `small_refactor_proposal.schema.json`
- `approved_refactor_handoff.schema.json`
- `before_after_evidence_report.schema.json`
- `refactor_regression_report.schema.json`

### Required Flow

```text
architecture baseline
-> smell report
-> refactor proposal
-> approval gate
-> execution handoff
-> runtime/data change
-> before/after evidence
-> focused QA evidence
-> rollback note
-> shared truth update
-> architecture baseline update
```

### Acceptance Criteria

- Refactor execution is blocked without approval.
- Refactor does not violate pack `allowed_writes` / `forbidden_writes`.
- Before/after evidence is present.
- Focused QA passes or routes failure to a named owner.
- Rollback note exists.
- Shared truth and architecture baseline reference the refactor evidence.

## 8. Phase 4 - Agent Harness Protocol

Priority: P1
Purpose: make the external runtime adapter boundary machine-readable and testable.

Current state:

- `run_gdd_orchestrator.py` generates a human-readable agent brief.
- Workflow JSON binds skills to owners.
- The repo does not directly spawn LLM agents.

Target state:

- The repo still does not call LLM APIs directly.
- The repo emits a standard agent run plan.
- External runtimes can execute the plan and return standardized traces.

### New Surfaces

Proposed schemas:

- `agent_run_plan.schema.json`
- `agent_execution_trace.schema.json`
- `handoff_lane.schema.json`

Proposed scripts:

- `scripts/delivery/generate_agent_run_plan.py`
- `scripts/delivery/validate_agent_execution_trace.py`

### Minimum Capability

- Generate one machine-readable run plan from accepted scope, workflow, and artifact routes.
- Record agent id, skill id, input artifact refs, expected output refs, allowed write surfaces, and downstream routes.
- Validate execution trace for:
  - owner correctness
  - artifact schema correctness
  - source refs
  - handoff refs
  - blocked/non-completion conditions

### Acceptance Criteria

- A generated run plan covers all planned specialist GDD modules.
- A trace with wrong owner fails.
- A trace with missing output ref fails.
- A trace with blocked condition cannot be marked complete.

## 9. Phase 5 - Production Pack Beta Gate

Priority: P1/P2
Purpose: provide evidence to promote the pack from `draft` toward `beta`.

### New Surfaces

Proposed files:

- `references/beta_readiness_criteria.json`
- `scripts/delivery/evaluate_pack_beta_readiness.py`
- `tests/delivery/v493_beta_readiness_tests.py`
- `docs/beta/V493_BETA_READINESS_REPORT.md`

### Beta Evidence Requirements

- Pack manifest validates.
- Agent contracts validate.
- Skill contracts validate.
- Practicality gate passes.
- Boundary linter passes.
- Project readiness report passes.
- Shared truth index passes.
- Architecture baseline passes.
- Controlled small refactor demo passes.
- Delivery artifact closure passes.
- QA evidence bundle exists.
- Rollback note exists.
- Known limitations are documented.
- README and manifest lifecycle status are consistent.

### Acceptance Criteria

- `evaluate_pack_beta_readiness.py` returns PASS only when all required evidence is present.
- `lifecycle_status` remains `draft` until beta evidence is present.
- Beta report separates inherited Core capability, v4.93 Pack capability, and Core-Pack Integration evidence.

## 10. Phase 6 - Documentation and Scoring Alignment

Priority: P2
Purpose: prevent future mis-scoring and reduce onboarding ambiguity.

### Proposed Documents

- `CAPABILITY_MAP.md`
- `ROADMAP_ALIGNMENT.md`
- `AGENT_HARNESS.md`
- `SHARED_TRUTH_AND_ARCHITECTURE_BASELINE.md`
- `BETA_READINESS_REPORT.md`

### Documentation Rules

- Do not describe v4.93 as only GDD generation.
- Do not claim full roadmap completion until Shared Truth, Architecture Baseline, Controlled Refactor, and Beta evidence are present.
- Separate:
  - inherited Core Layer
  - v4.93 Pack Layer
  - Core-Pack Integration evidence
  - fixture evidence
  - real project adoption evidence

## 11. Recommended Execution Order

1. Fix CLI validate bug.
2. Add exact CLI tests.
3. Rewrite v4.93 README.
4. Add capability map and roadmap alignment docs.
5. Implement Shared Truth schemas and validators.
6. Implement Architecture Baseline schemas and validators.
7. Implement Controlled Small Refactor Demo.
8. Add Agent Harness Protocol.
9. Add Beta Readiness Gate.
10. Re-evaluate score and only then consider lifecycle promotion.

## 12. Test Plan

Baseline command:

```bash
python3 -m pytest AI_Game_Dev_OS_v4.93/tests/delivery/test_v493_end_to_end_skill_contracts.py -q --tb=short
```

Target additional commands:

```bash
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/run_gdd_orchestrator.py start --intent "smoke"
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/run_gdd_orchestrator.py validate --artifact-root <artifact_root>
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/generate_shared_truth_index.py --artifact-root <artifact_root>
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/validate_shared_truth_index.py <truth_index.json>
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/inspect_architecture_baseline.py --project-root <project_root>
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/validate_architecture_baseline.py <architecture_baseline.json>
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/evaluate_pack_beta_readiness.py --project-root <project_root> --artifact-root <artifact_root>
```

## 13. Non-goals

- Do not move Core Layer code into v4.93 pack.
- Do not bypass v4.92 capability protocol schemas.
- Do not auto-write to external trackers or Git remotes.
- Do not auto-run LLM agents from repo scripts.
- Do not promote `lifecycle_status` to `beta` before evidence exists.
- Do not treat fixture-only success as real project adoption evidence.

## 14. Completion Definition

v4.93 can be considered roadmap-complete beta candidate when:

- README and capability docs accurately describe full v4.93 scope.
- CLI entry points work and are tested.
- Shared Truth exists as a validated project-level index.
- Architecture Baseline exists as a validated project/runtime map.
- Controlled Small Refactor Demo is closed with approval, evidence, QA, and rollback.
- Agent Harness Protocol is machine-readable and trace-validated.
- Beta readiness gate passes.
- The final assessment separates inherited Core, current Pack, and Core-Pack Integration evidence.
