# AI Game Dev OS v4.94 Development Status

This file describes the current function-first v4.94 development surface. It
does not declare qualification, Gate passage, package promotion, or release.

The exact v4.93-to-v4.94 path inventory and manifest split are recorded in
`V494_PACKAGE_IDENTITY_RECONCILIATION.md`.

The root manifest, schema, README, index, and command paths now carry a coherent
v4.94 development identity. The production pack remains inherited v4.93
provenance, and the OS-layer release manifest/checksums remain future
source-freeze inputs rather than current closure evidence.

## Current Functional Baseline

The v4.94 Codex development path currently provides:

- project-local persistent task, issue, blocker, and handoff state;
- explicit task queue, prepare, start, resume, progress, checkpoint, cancel,
  completion claim, independent PASS closure, and FAIL-to-rework paths;
- bounded Git context, task input inspection, exact revision readsets, input
  impact preview, Truth replacement loading, and persistent input rebind;
- real Git commit and blob checks at claim time and once before the first
  independent development PASS;
- a read-only completion summary for closed tasks;
- explicit project-memory promotion from a selected closed task, plus bounded
  manual keyword/tag retrieval;
- read-only `production_spec_patch` impact replay with state-specific focused
  review suggestions.

These are development capabilities. They are not Evidence Core qualification
receipts and do not create production authority.

## Development Runtime Writes

Ordinary task state is stored only below:

```text
<game_project>/.ai_dev_os/development/runtime_state/
```

Project memory is absent by default. An explicit promotion call may create:

```text
<game_project>/.ai_dev_os/development/project_memory/
```

Closing a task does not promote memory. Starting or resuming a task does not
query or inject memory. Memory retrieval is an explicit, bounded read.

The development adapter does not create `.ai_dev_os/state/` and does not write
to the selected game's source files.

## Recommended Function-First Flow

1. Select one explicit, non-production game-project root.
2. Queue or start the smallest functional task.
3. Read only the task's declared inputs when their content is needed.
4. Implement and commit the game-project change.
5. Claim completion with real Git implementation references.
6. Use one independent bounded functional review.
7. After closure, optionally promote a concise reusable memory.
8. Use production-spec replay only as a read-only impact preview until a
   separate caller explicitly chooses to apply a revision change.

Manifest rebuild, file-digest refresh, full package validation, qualification,
and Gate execution are not prerequisites for steps 1-8.

## Remaining Before v4.94 Closure

- optionally perform one explicitly selected real-game-project read-only spec
  replay if a project and an actual patch/revision pair are later supplied;
- freeze the chosen whole-package development source boundary;
- refresh release inventory/checksums only after that source freeze;
- run qualification and Gate work only under separate authority;
- prepare release identity only after the development surface is stable.

The optional Codex Shadow remains deferrable and is not required for the
function-first development baseline.

## Explicit Non-Claims

- no qualification result;
- no Gate B, C, or D passage;
- no package promotion or release;
- no production data or game-source write authority;
- no automatic memory capture, retrieval, or global LTM promotion;
- no assertion that the inherited OS-layer release inventory/checksums describe
  all current v4.94 source bytes.
