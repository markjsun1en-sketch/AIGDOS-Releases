# v4.94 Package Identity Reconciliation

Status: static development inventory; not qualification, Gate, package
promotion, checksum refresh, or release acceptance.

## Comparison Boundary

The reproducible provenance comparison is:

```text
v4.93 source commit: e91fcc8c53d816e5a6e9b95e49a522289c067a83
v4.93 package tree:  e40766e8c2dcebfa7698c9dac9adf84ad2b33ecf
v4.94 first commit:   025b4c122e13dedb51048481f06d01e2faaab6b9
inventory preimage:  3fc8f06750cbc08df5957fe3818a5c4ad975c2de
v4.94 preimage tree: c5288b0ccd209f2783ac6423cdc3dc55528818bd
```

The two trees are compared as package roots, not by their different directory
names:

```bash
git diff --no-renames --name-status \
  e91fcc8c53d816e5a6e9b95e49a522289c067a83:AI_Game_Dev_OS_v4.93 \
  3fc8f06750cbc08df5957fe3818a5c4ad975c2de:AI_Game_Dev_OS_v4.94
```

This report itself is the one additional v4.94 file after that preimage. It
does not change the functional inventory.

## Exact Inventory Result

At this report's intended post-image, the package contains 2,377 tracked
files:

- 2,238 paths are byte-identical inherited v4.93 provenance;
- 115 paths are added by v4.94, including this report;
- 24 inherited paths have v4.94 modifications;
- no inherited path is deleted or renamed.

| Package area | Added | Modified | Meaning |
| --- | ---: | ---: | --- |
| root | 2 | 2 | v4.94 development status/reconciliation plus README/INDEX pointers |
| `adapters/` | 2 | 4 | Codex task and project-memory implementation plus adapter contracts |
| `os_layer/` | 111 | 14 | Runtime State, assurance tranche, schemas, fixtures, migration, tests, and integration changes |
| `pack_layer/` | 0 | 2 | inherited delivery path handling adjustments |
| root `scripts/` mirror | 0 | 1 | inherited delivery path handling adjustment |
| root `tests/` mirror | 0 | 1 | inherited documentation-path test adjustment |
| **total** | **115** | **24** | **139 paths differ from v4.93** |

The 115 added paths are completely partitioned as follows:

| Added group | Count | Path boundary |
| --- | ---: | --- |
| root development documents | 2 | `V494_DEVELOPMENT_STATUS.md`, this report |
| Codex development implementation | 2 | `adapters/codex/development_task_adapter.py`, `adapters/codex/development_project_memory.py` |
| configuration | 2 | `os_layer/config/assurance/`, `os_layer/config/runtime_state_t1_mirror_policy.json` |
| assurance/runtime contracts | 9 | `os_layer/contracts/assurance/`, `os_layer/contracts/runtime_state/` |
| Runtime State documentation | 3 | `os_layer/docs/runtime_state/` |
| assurance/runtime fixtures | 24 | `os_layer/fixtures/assurance/`, `os_layer/fixtures/runtime_state/` |
| Runtime State migration | 1 | `os_layer/migrations/runtime_state/` |
| assurance/runtime schemas | 23 | `os_layer/schemas/assurance/`, `os_layer/schemas/runtime_state/` |
| assurance/runtime source | 18 | `os_layer/scripts/assurance/`, `os_layer/scripts/runtime_state/` |
| assurance/runtime tests | 31 | `os_layer/tests/assurance/`, `os_layer/tests/runtime_state/` |
| **total** | **115** | |

The 24 modified paths are also bounded:

- root: `README.md`, `INDEX.md`;
- Codex adapter: `adapters/codex/README.md`,
  `adapters/codex/codex_integration_policy.json`,
  `adapters/codex/codex_invocation_profile.json`,
  `adapters/codex/codex_runtime_adapter_contract.md`;
- OS-layer identity/release notes: `os_layer/CHANGELOG.md`,
  `os_layer/CHECKSUMS.sha`, `os_layer/RELEASE_MANIFEST.json`,
  `os_layer/RELEASE_NOTES.md`;
- OS-layer configuration/docs: `os_layer/config/runtime_storage_policy.yaml`,
  `os_layer/docs/14_state_surface_governance/README.md`;
- OS-layer runtime integration:
  `os_layer/scripts/governance/lint_layer_separation.py`,
  `os_layer/scripts/runtime/registry_manager.py`,
  `os_layer/scripts/runtime/runtime_common.py`,
  `os_layer/scripts/runtime/runtime_object_cli.py`,
  `os_layer/scripts/runtime/snapshot_generator.py`, and
  `os_layer/scripts/runtime/state_transition_engine.py`;
- OS-layer tests: `os_layer/tests/conftest.py`,
  `os_layer/tests/self_evolution/test_lint_exemption.py`;
- delivery compatibility paths:
  `pack_layer/scripts/delivery/validate_markdown_local_paths.py`,
  `pack_layer/tests/delivery/v493_docs_path_tests.py`,
  `scripts/delivery/validate_markdown_local_paths.py`, and
  `tests/delivery/v493_docs_path_tests.py`.

## Manifest Findings

These objects have different roles and must not be updated as if they were one
manifest:

| Object | Current identity | Finding |
| --- | --- | --- |
| root `MANIFEST.json` | blob `fc824affa34a5f07cd6711381984f081fa487152` | byte-identical to v4.93; still declares `AI_Game_Dev_OS_v4.93`, `draft` |
| `os_layer/MANIFEST.json` | blob `1b09d98cb2cb3a21d53cee2d71ca8b7879fae27d` | byte-identical inherited Core view; still declares `4.92-Release` over `4.91-Release` |
| `os_layer/RELEASE_MANIFEST.json` | blob `1ec7216b3f32bbb9ac2d383e12b54029eef5dac4` | names v4.94, but last changed at `210218c` on 2026-08-04, before function-first development |
| `os_layer/CHECKSUMS.sha` | blob `0d944c3abf13722238843f3a7327aca385309334` | last changed at `2fa8b9a` on 2026-08-09, also before function-first development |

Representative later paths absent from the release inventory include
`os_layer/scripts/runtime_state/task_workflow.py`,
`os_layer/scripts/runtime_state/truth_invalidation.py`, and
`os_layer/tests/runtime_state/test_codex_development_task_adapter.py`. Root-level Codex
adapter files are outside the OS-layer release-manifest boundary entirely.

Therefore:

- the root manifest cannot currently identify the whole v4.94 development
  package;
- the OS-layer Core manifest should remain inherited provenance unless a
  separate Core-version decision changes it;
- the OS-layer release manifest and checksum file must not be cited as a
  current whole-source closure;
- changing only version strings would create a false package identity.

## Minimal Reconciliation Sequence

### Necessary before a v4.94 package candidate

1. Freeze the function-first source surface after any explicitly selected
   real-project read-only replay or explicitly defer that replay.
2. Decide the delivery boundary: whole `AI_Game_Dev_OS_v4.94/` package versus
   OS-layer-only release inventory. The current split does not cover the new
   root adapter source with one file inventory.
3. Update the root version identity and command paths as one coherent docs and
   manifest change; do not rewrite inherited OS-layer provenance fields merely
   to match the directory name.
4. Rebuild OS-layer release inventory/checksums only after the boundary and
   source freeze are fixed.
5. Run package validation, qualification, and Gates only under their separate
   authority and only after steps 1-4.

### Useful but not required for ordinary development

- add a small machine-readable development capability index for adapter
  discovery;
- consolidate the inherited v4.93 changelog with the function-first v4.94
  development history at package-candidate time;
- replace stale v4.93 example command roots when the root identity is updated.

### Optional or deferrable

- Codex Shadow;
- global/cross-project LTM publication;
- vector search or automatic memory injection;
- release packaging before a real project is selected.

## Inventory-Time Decision

No manifest or checksum mutation is justified by this static inventory alone.
The correct continuation baseline is the current clean branch after this
report. The next material choice is either:

- select a real game project and an actual old/new spec revision pair for one
  read-only replay; or
- explicitly defer that replay and begin the coherent root package-identity
  refresh.

Neither choice grants qualification, Gate, production write, tag, push, or
release authority.

## Subsequent Root-Identity Refresh

The real-project read-only replay was deferred. The subsequent bounded refresh
updates only the whole-package root identity, root schema, root entry documents,
current command paths, and their direct static contract assertion.

The refresh deliberately preserves:

- the inherited v4.93 production-pack artifact namespace and fixtures;
- the OS-layer Core manifest as provenance;
- the existing OS-layer release manifest and checksum bytes;
- `lifecycle_status: "draft"` and every qualification, Gate, promotion, and
  release non-claim.

The exact inventory above remains anchored to its stated comparison commits and
report post-image. It is historical evidence for why the bounded refresh was
needed, not a claim that its file counts describe this later post-image.
