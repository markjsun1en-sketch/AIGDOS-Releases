"""Schema-driven cross-checker prototype (Phase 3 Lock-B / M7.1).

Purpose
-------
Audit prototype that *replaces* the four per-profile cross-check
``if`` blocks (M6.4-M6.7) in
``scripts/verify_beta_sprint_exit.check_init_integrity`` with a
single data-driven loop that reads each profile JSON's contract
surface and emits WARN findings byte-identical to the original
blocks.

This module is wired into ``check_init_integrity`` via the
``STAGE_2_USE_SCHEMA_CHECKER=1`` environment variable, which
selects the schema-driven path instead of the per-profile if-tree.
The default path (env unset or ``=0``) preserves the original
M6.4-M6.7 blocks byte-stable, so the per-profile evidence ladder
remains intact.

Acceptance contract for collapsing the per-profile if-tree (Phase
3 Step 2, NOT in scope for M7.1): byte-identical JSON envelopes on
every row of the 16-row R1 regression matrix
(``tests/test_stage_2_regression_r1.py::_MATRIX``).  This is what
``tests/test_schema_driven_equivalence.py`` measures.

Design choices
--------------

1. **Data, not code, for the contract surface**.  The list of
   contract fields the checker scans is held in ``_CONTRACT_FIELDS``
   below.  The ground-truth values come from the profile JSONs
   (``config/profiles/<profile>.json``), which are the same source
   of truth the M6.4-M6.7 hard-coded blocks reference.

2. **Same gate as M6.4-M6.7** (pre-M7.3): a finding fires only when the
   contract field is *explicitly declared* in ``runtime_state.json``
   AND the value mismatches the ground truth.  This keeps the six
   positive mirrors green (their state files do not declare these keys)
   without any per-profile carve-outs.

   **M7.3 (Phase 4 Step 1 lift)**: the ``actual is None`` short-circuit
   was a silent-PASS second-order residual — it let a state that never
   declared a contract field silently bypass the gate, even though
   ``_stub_init`` is contractually required to write all four surface
   fields from the authoritative profile JSON.  Post-M7.3 the schema
   checker emits ``ERROR(missing contract field)`` instead of skipping;
   the ``actual != expected`` path remains WARN (schema drift — still a
   non-fatal skew between hand-edited state and profile ground truth).
   See ``docs/06_runtime_profiles/PHASE_4_LIFT_GATE_AUDIT.md`` §1 §4
   for the full rationale.

3. **Same emit shape as M6.4-M6.7**: each finding goes through
   ``verify_beta_sprint_exit._finding`` with category=``init``,
   severity=``WARN``, message in the M6.4-M6.7 phrasing
   (``"profile=<p> requires <f>=<v!r>, got <a!r> — schema drift suspected"``),
   plus the ``contract_field`` key.  Byte-identical message text
   matters — ``test_schema_driven_equivalence.py`` diffs JSON
   envelope strings, not parsed structures.

4. **Iteration order matters**.  The per-profile blocks emit in a
   specific order: M6.4-M6.6 emit
   ``coordination_model`` then ``writeback_owner``; M6.7 emits
   ``audit_collector`` then ``context_loading_method``.  The schema
   checker iterates ``_CONTRACT_FIELDS`` in declaration order, and
   that order is chosen to reproduce the original block emit
   sequence on the matrix's 16 rows.  See ``_CONTRACT_FIELDS``
   ordering rationale below.

5. **Profiles outside the M6.4-M6.7 cross-check scope** (today:
   only ``workbuddy_private`` and ``default_beta_codex_tapd_git``)
   are silently skipped in this prototype: the per-profile if-tree
   does not check them either, so the schema-driven path must
   match.  When the eventual collapse happens (Phase 3 Step 2),
   this carve-out can be revisited — but for byte-identical
   audit it must stay.

Phase 3 Lock-B audit deliverable; not yet a production code path.
"""
from __future__ import annotations

import json
from pathlib import Path


# Local copy of verify_beta_sprint_exit._finding to avoid a circular
# import once the per-profile if-tree (M6.4-M6.7) collapses into this
# module (Phase 3 M7.2). The function body is intentionally identical
# to verify.py's `_finding` so emitted envelopes stay byte-identical
# with the historical M6.4-M6.7 output captured by the M7.1 audit.
def _finding(category: str, severity: str, message: str, **extra) -> dict:
    entry = {
        "category": category,
        "severity": severity,
        "message": message,
    }
    entry.update(extra)
    return entry


# ---------------------------------------------------------------------------
# Contract surface declaration
# ---------------------------------------------------------------------------
#
# Fields the per-profile if-tree (M6.4-M6.7) cross-checks.  Order matters:
# the schema-driven path emits findings in this iteration order, and the
# expected byte-identical output is built from the per-profile blocks
# which emit in this exact order:
#
#   M6.4 codex block       — coordination_model, writeback_owner
#   M6.5 cursor block      — coordination_model, writeback_owner
#   M6.6 claude_teams      — coordination_model, writeback_owner
#   M6.7 claude_subagents  — audit_collector, context_loading_method
#
# Listing M6.4-M6.6's pair first means rows whose profile uses that pair
# (codex/cursor/claude_teams) emit in the right order; M6.7's pair listed
# second means claude_subagents rows emit in the right order.  No row
# emits findings on more than one pair (per-profile gate ensures
# disjointness), so the ordering decision is symmetric per row.
_CONTRACT_FIELDS: tuple[str, ...] = (
    "coordination_model",
    "writeback_owner",
    "audit_collector",
    "context_loading_method",
)


# Profiles that have a per-profile cross-check block in M6.4-M6.7.
# Other profiles (workbuddy_private, default_beta_codex_tapd_git) are
# not cross-checked even when state declares contract fields, so the
# schema-driven path must skip them to stay byte-identical.
_CHECKED_PROFILES: frozenset[str] = frozenset({
    "codex",
    "cursor",
    "claude_code_agent_teams",
    "claude_code_subagents",
})


# Per-profile field allowlist: which fields each profile's M6.4-M6.7
# block actually checks.  Schema-driven path must match this exactly
# to produce byte-identical output.  Listed in the order the original
# block emits.
_PROFILE_CHECK_FIELDS: dict[str, tuple[str, ...]] = {
    "codex":                   ("coordination_model", "writeback_owner"),
    "cursor":                  ("coordination_model", "writeback_owner"),
    "claude_code_agent_teams": ("coordination_model", "writeback_owner"),
    "claude_code_subagents":   ("audit_collector", "context_loading_method"),
}


# ---------------------------------------------------------------------------
# Ground-truth loader
# ---------------------------------------------------------------------------


_PROFILE_DIR = Path(__file__).resolve().parent.parent / "config" / "profiles"


def _load_profile_ground_truth(profile: str) -> dict:
    """Load ``config/profiles/<profile>.json`` and return the dict.

    On missing file or bad JSON, return an empty dict — this is a
    defensive read identical in spirit to verify.py's envelope-aware
    pattern (consult never raises on filesystem errors).
    """
    path = _PROFILE_DIR / f"{profile}.json"
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


# ---------------------------------------------------------------------------
# Schema-driven cross-check
# ---------------------------------------------------------------------------


def schema_driven_init_check(
    state: dict,
    state_path: Path,
) -> list[dict]:
    """Schema-driven equivalent of the M6.4-M6.7 per-profile if-tree.

    Reads ``runtime_state.profile`` (or ``runtime_profile``), looks up
    the corresponding profile JSON's ground-truth values, and emits a
    WARN finding for each contract field that is explicitly declared
    in state with a value that contradicts the ground truth.

    Iteration order (within a single profile's findings) follows the
    per-profile field allowlist in ``_PROFILE_CHECK_FIELDS`` to
    reproduce M6.4-M6.7 byte-identical output.

    Returns
    -------
    list[dict]
        Findings in the same ``_finding`` envelope shape as the
        per-profile blocks emit.  Empty list if no drift detected
        or profile is not in the cross-check scope.
    """
    declared = state.get("profile") or state.get("runtime_profile")
    if not declared or declared not in _CHECKED_PROFILES:
        return []

    ground_truth = _load_profile_ground_truth(declared)
    if not ground_truth:
        # Profile JSON missing or unreadable — defer to other checks
        # (verify.py L451 enum check fires on this).  Schema-driven
        # path silent here for byte-identical match with M6.4-M6.7.
        return []

    findings: list[dict] = []
    for field in _PROFILE_CHECK_FIELDS[declared]:
        actual = state.get(field)
        if actual is None:
            # M7.3.3 (Phase 4 Step 1 lift gate): the original M6.4-M6.7
            # if-tree used ``if x and x != expected`` semantics, which
            # silently passed on ``x is None``.  That was M7.3's silent-
            # PASS second-order residual (see ltm/failures/
            # 2026-05-05_codex_silent_pass_blindness.md and
            # docs/06_runtime_profiles/PHASE_4_LIFT_GATE_AUDIT.md §1).
            #
            # M7.3.2 now makes ``_stub_init`` canonically write every
            # contract field, so ``actual is None`` means init either
            # never ran, ran with profile JSON degraded, or a caller
            # hand-edited the state and dropped the field.  All three
            # are contract violations — emit ERROR (Q2=A).
            findings.append(_finding(
                "init", "ERROR",
                f"profile={declared} missing contract field {field!r} "
                f"— init must canonically write contract surface",
                path=str(state_path),
                contract_field=field,
            ))
            continue
        expected = ground_truth.get(field)
        if expected is None:
            # Ground truth missing this field; cannot meaningfully
            # cross-check.  Skip for byte-identical match.
            continue
        if actual == expected:
            continue
        # Match the M6.4-M6.7 message phrasing exactly:
        #   f"profile={p} requires {field}={expected!r}, "
        #   f"got {actual!r} — schema drift suspected"
        findings.append(_finding(
            "init", "WARN",
            f"profile={declared} requires {field}={expected!r}, "
            f"got {actual!r} — schema drift suspected",
            path=str(state_path),
            contract_field=field,
        ))

    return findings
