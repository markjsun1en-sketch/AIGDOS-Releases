#!/usr/bin/env python3
"""Audit summary CLI skeleton for v4.89 (preserved from v4.88_Revise Batch 3)."""
from __future__ import annotations
import argparse
import json
from collections import Counter
from pathlib import Path


def load_jsonl(path: Path):
    rows = []
    if not path.exists():
        return rows
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            rows.append({"event_type": "invalid_json", "raw": line})
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("audit_file", type=Path)
    args = parser.parse_args()

    rows = load_jsonl(args.audit_file)
    by_type = Counter(r.get("event_type", "unknown") for r in rows)
    by_actor = Counter(r.get("actor", "unknown") for r in rows)

    summary = {
        "rows": len(rows),
        "by_type": dict(by_type),
        "by_actor": dict(by_actor),
    }
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
