#!/usr/bin/env python3
"""workbuddy_collector — event normalization + hardened audit surface.

v4.89 Phase 2 Stage 2 (2026-05-04):
The hardened audit surface (``append_audit`` / ``wrap_external_record``
/ ``AuditAppendError`` / envelope constants / malformed-fallback sink)
has moved to the shared module ``._base`` so the four sibling profile
collectors (``codex`` / ``cursor`` / ``claude_teams`` / ``claude_subagents``)
can re-use the exact same contract without duplicating ~350 lines.

**Public API is unchanged.** Existing callers that import
``workbuddy_collector.append_audit``, ``wrap_external_record``,
``AuditAppendError``, ``AUDIT_STATUS_*``, etc. continue to work via
module-level re-exports below — no behavioural change, no signature
change, pytest 45 cases must stay green (see B2 regression commit).

Historical phases:
- B+ Bridge Hardening (2026-05-02): introduced ``append_audit`` /
  ``AuditAppendError``.
- v4.89 Phase 1 P0-A (2026-05-02): added ``wrap_external_record`` /
  ``AUDIT_STATUS_*`` / ``_ALLOWED_SOURCE_LAYERS`` (narrow-by-design).
- v4.89 Phase 1 P0-C C1: added ``mcp_audit.malformed.jsonl`` fallback.
- v4.89 Phase 2 Stage 2 (this commit): extracted the above into ``._base``.

Profile note (Q-B, Stage 2): the narrow ``_ALLOWED_SOURCE_LAYERS`` tuple
stays at ``("tapd", "git", "workbuddy")``. Runtime profile identity
(workbuddy_private / codex / cursor / claude_*) travels via the envelope's
independent ``runtime_profile`` field, not via source_layer.
"""
from __future__ import annotations

# Re-export the entire hardened surface from the shared base so callers
# importing ``workbuddy_collector.<symbol>`` keep working unchanged.
from ._base import (
    # Public constants
    AUDIT_RELATIVE_PATH,
    MALFORMED_AUDIT_RELATIVE,
    AUDIT_STATUS_PENDING,
    AUDIT_STATUS_EMITTED,
    AUDIT_STATUS_FAILED,
    # Public exception
    AuditAppendError,
    # Public API
    wrap_external_record,
    append_audit,
    # Internal helpers — re-exported with their original names so existing
    # tests that patch ``workbuddy_collector._utc_now_iso`` etc. keep
    # working without modification.
    _utc_now_iso,
    _validate_event_envelope,
    _ensure_audit_dir,
    _handle_failure,
    _append_malformed,
    _REQUIRED_ENVELOPE_FIELDS,
    _ALLOWED_SOURCE_LAYERS,
    _AUDIT_BACKEND,
)

__all__ = [
    # Public constants
    "AUDIT_RELATIVE_PATH",
    "MALFORMED_AUDIT_RELATIVE",
    "AUDIT_STATUS_PENDING",
    "AUDIT_STATUS_EMITTED",
    "AUDIT_STATUS_FAILED",
    # Public exception
    "AuditAppendError",
    # Public API
    "normalize_event",
    "wrap_external_record",
    "append_audit",
]


# ---------------------------------------------------------------------------
# Profile-specific projection — this is what makes this a ``workbuddy``
# collector rather than a generic one. Other profiles keep their own
# ``normalize_event`` projection in their own modules.
# ---------------------------------------------------------------------------


def normalize_event(raw_event: dict) -> dict:
    """Project a raw MCP event into the Workbuddy collector shape.

    Signature and behaviour are preserved from the v4.88-release-scaffold
    baseline; downstream tooling relying on the existing keys continues to
    work unchanged.
    """
    return {
        "event_type": raw_event.get("event_type", "unknown"),
        "timestamp": raw_event.get("timestamp"),
        "actor": raw_event.get("actor", "unknown"),
        "runtime_profile": raw_event.get("runtime_profile"),
        "result": raw_event.get("result", "unknown"),
        "details": raw_event,
    }
