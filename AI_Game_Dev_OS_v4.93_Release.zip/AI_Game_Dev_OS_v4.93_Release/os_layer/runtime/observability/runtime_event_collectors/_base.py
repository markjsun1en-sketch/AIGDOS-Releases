#!/usr/bin/env python3
"""Shared hardened surface for runtime-event collectors.

v4.89 Phase 2 Stage 2 (2026-05-04, §11.X admitted):
This module houses the hardened audit-envelope surface that was historically
embedded inside ``workbuddy_collector`` alone. Stage 2 5-profile parity
hardening extracts it so that the four sibling collectors
(``codex`` / ``cursor`` / ``claude_teams`` / ``claude_subagents``) can share
the exact same contract instead of each duplicating ~350 lines.

Responsibilities owned here:
- Envelope constants (``_REQUIRED_ENVELOPE_FIELDS``, ``AUDIT_STATUS_*``,
  ``_ALLOWED_SOURCE_LAYERS``, ``AUDIT_RELATIVE_PATH``,
  ``MALFORMED_AUDIT_RELATIVE``).
- ``AuditAppendError`` (strict-mode silent-failure surfacing).
- ``wrap_external_record`` (Phase 1 P0-A adapter → envelope).
- ``append_audit`` (Phase 1 P0-C C1 malformed-fallback sink).
- Internal helpers ``_utc_now_iso`` / ``_validate_event_envelope``
  / ``_ensure_audit_dir`` / ``_handle_failure`` / ``_append_malformed``.

**Not** owned here: the per-collector ``normalize_event`` projection. Each
collector keeps its own ``normalize_event`` signature so profile-specific
projection preferences (e.g. Claude Code subagents may surface different
event types than Codex) remain pluggable.

Invariants preserved from Phase 1 (must stay green under pytest 45):
- Envelope 9-field contract unchanged.
- ``_ev_get`` read-side unchanged (owned by ``verify_beta_sprint_exit``).
- ``_ALLOWED_SOURCE_LAYERS = ("tapd", "git", "workbuddy")`` narrow-by-design.
- ``top_level=`` deprecated bridge **removed in v4.90 Batch 0 Step 2**
  (was owned by ``run_sprint.py``; read-side now relies entirely on
  ``_ev_get`` envelope-aware lookup root → details.* → default).
- Public API of ``workbuddy_collector`` unchanged (re-exports via this module).
"""
from __future__ import annotations

import json
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

__all__ = [
    # Public constants
    "AUDIT_RELATIVE_PATH",
    "MALFORMED_AUDIT_RELATIVE",
    "AUDIT_STATUS_PENDING",
    "AUDIT_STATUS_EMITTED",
    "AUDIT_STATUS_FAILED",
    # Public exception
    "AuditAppendError",
    # Public API
    "wrap_external_record",
    "append_audit",
]

# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------

AUDIT_RELATIVE_PATH: str = "runtime/logs/mcp_audit.jsonl"
"""Path (relative to workspace root) where MCP audit events are appended."""

MALFORMED_AUDIT_RELATIVE: str = "runtime/logs/mcp_audit.malformed.jsonl"
"""v4.89 P0-C C1 (Real Trial v1 F6): parallel sink for events that fail
envelope validation / JSON encoding / file append, so non-strict callers
never silently drop audit intent. One JSONL line per rejected event with
``{reason, recorded_at, raw_record}`` — separate filename ensures the
canonical audit reader (verify_beta_sprint_exit L184) does not pick it
up as a real event."""

# Envelope contract matches ``schemas/mcp_audit_log.schema.json`` required
# fields; ``correlation_id``/``target_id``/``details`` remain optional.
_REQUIRED_ENVELOPE_FIELDS: tuple[str, ...] = (
    "event_type",
    "timestamp",
    "actor",
    "runtime_profile",
    "result",
)

# Backend hook — reserved for future MCP feed wiring. B+ keeps file-only.
_AUDIT_BACKEND: str = "file"

# ---------------------------------------------------------------------------
# v4.89 P0-A envelope constants
# ---------------------------------------------------------------------------

AUDIT_STATUS_PENDING: str = "pending"
AUDIT_STATUS_EMITTED: str = "emitted"
AUDIT_STATUS_FAILED: str = "failed"

# Allowed source_layer values for wrap_external_record. Keep narrow — any
# new adapter source must be added here explicitly (fail-loud by design).
# Stage 2 Q-B: profile identity (codex/cursor/claude_*) is NOT admitted
# here; profile info travels via the envelope's ``runtime_profile`` field
# which is independent of source_layer.
_ALLOWED_SOURCE_LAYERS: tuple[str, ...] = ("tapd", "git", "workbuddy")


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class AuditAppendError(RuntimeError):
    """Raised when ``append_audit`` fails in strict mode.

    Non-strict callers receive a ``False`` return value and a ``stderr``
    warning instead — but NEVER a silent swallow, which is the anti-pattern
    this helper is explicitly designed to prevent (see COLLECTOR_NOTES.md
    MCP disconnect audit-gap risk).
    """


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def wrap_external_record(
    record: dict,
    *,
    source_layer: str,
    runtime_profile: str,
    actor: str = "main_session",
    event_type: str | None = None,
    result: str | None = None,
    audit_status: str = AUDIT_STATUS_PENDING,
) -> dict:
    """Wrap an adapter-level normalized record into the canonical audit envelope.

    v4.89 Phase 1 P0-A: adapter stubs (tapd / git / …) return a flat
    ``normalize`` shape (see ``integrations/*_adapter_stub.py``). That
    shape cannot be appended to the MCP audit log directly because
    ``append_audit`` requires the envelope contract in
    ``_REQUIRED_ENVELOPE_FIELDS`` plus v4.89 adds ``event_id`` /
    ``source_layer`` / ``audit_status`` for traceability.

    This helper is the single place where adapters' raw records become
    envelopes. It generates a fresh ``event_id`` (uuid4) and stamps
    ``timestamp`` with UTC now so callers never have to compute them.

    Parameters
    ----------
    record:
        The adapter's normalize shape. Must be a dict. Its original
        contents are preserved under ``details`` (no lossy projection).
    source_layer:
        Which adapter produced the record. Must be one of
        ``_ALLOWED_SOURCE_LAYERS``. Fail-loud on unknown values so we
        do not accept silent typo sources.
    runtime_profile:
        The active runtime profile name (e.g. ``workbuddy_private``,
        ``codex``, ``cursor``, ``claude_code_agent_teams``,
        ``claude_code_subagents``). Required — envelope contract enforces it.
    actor:
        Who triggered the event. Defaults to ``main_session`` matching
        adapter stub defaults.
    event_type:
        Canonical event type. When ``None``, falls back to
        ``record["event"]`` (tapd normalize shape), then
        ``record["event_type"]`` (git shape), else ``"unknown"``.
    result:
        Event outcome. When ``None``, falls back to ``record["result"]``
        or ``record["status"]``, else ``"unknown"``.
    audit_status:
        Envelope audit classification. Defaults to
        :data:`AUDIT_STATUS_PENDING`; set to
        :data:`AUDIT_STATUS_FAILED` for silent-failure records.

    Returns
    -------
    dict
        A canonical envelope dict ready for :func:`append_audit`.

    Raises
    ------
    TypeError
        If ``record`` is not a dict.
    ValueError
        If ``source_layer`` is not in :data:`_ALLOWED_SOURCE_LAYERS`,
        or if ``runtime_profile`` is empty.
    """
    if not isinstance(record, dict):
        raise TypeError(
            "wrap_external_record: record must be a dict, "
            f"got {type(record).__name__}"
        )
    if source_layer not in _ALLOWED_SOURCE_LAYERS:
        raise ValueError(
            "wrap_external_record: source_layer must be one of "
            f"{_ALLOWED_SOURCE_LAYERS}, got {source_layer!r}"
        )
    if not runtime_profile:
        raise ValueError(
            "wrap_external_record: runtime_profile is required (non-empty)"
        )

    resolved_event_type = (
        event_type
        or record.get("event")
        or record.get("event_type")
        or "unknown"
    )
    resolved_result = (
        result
        or record.get("result")
        or record.get("status")
        or "unknown"
    )

    envelope: dict[str, Any] = {
        "event_id": str(uuid.uuid4()),
        "event_type": resolved_event_type,
        "timestamp": _utc_now_iso(),
        "actor": actor,
        "runtime_profile": runtime_profile,
        "result": resolved_result,
        "source_layer": source_layer,
        "audit_status": audit_status,
        "details": dict(record),
    }
    return envelope


def append_audit(
    workspace: os.PathLike[str] | str,
    event: dict,
    *,
    strict: bool = False,
) -> bool:
    """Append one event as a JSONL line under ``<workspace>/runtime/logs/``.

    Parameters
    ----------
    workspace:
        Root of the project runtime workspace. The audit log lives at
        ``<workspace>/runtime/logs/mcp_audit.jsonl`` (directory is created
        on-demand).
    event:
        The event envelope dict. Must contain the fields listed in
        ``_REQUIRED_ENVELOPE_FIELDS``.
    strict:
        ``True`` → raise :class:`AuditAppendError` on any failure.
        ``False`` → emit a ``stderr`` warning and return ``False``.

    Returns
    -------
    bool
        ``True`` on successful write; ``False`` on failure (non-strict mode).

    Notes
    -----
    Silent failure prevention: envelope validation, directory creation,
    JSON encoding, and file append are each guarded. Any failure is either
    raised (strict) or surfaced via ``stderr`` (non-strict). This is the
    B+ countermeasure to the collector trial-blocking gap called out in
    ``MATURITY_MATRIX.md`` and the MCP disconnect audit-gap risk from
    COLLECTOR_NOTES.md.
    """
    workspace_path = Path(workspace)

    missing = _validate_event_envelope(event)
    if missing:
        return _handle_failure(
            reason=f"event envelope missing required fields: {missing}",
            strict=strict,
            workspace=workspace_path,
            raw_record=event,
        )

    try:
        audit_path = _ensure_audit_dir(workspace_path)
    except OSError as exc:
        return _handle_failure(
            reason=f"could not create audit directory: {exc!r}",
            strict=strict,
            workspace=workspace_path,
            raw_record=event,
        )

    try:
        line = json.dumps(event, ensure_ascii=False, sort_keys=True)
    except (TypeError, ValueError) as exc:
        return _handle_failure(
            reason=f"event is not JSON-serialisable: {exc!r}",
            strict=strict,
            workspace=workspace_path,
            raw_record=event,
        )

    try:
        with audit_path.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError as exc:
        return _handle_failure(
            reason=f"write to {audit_path} failed: {exc!r}",
            strict=strict,
            workspace=workspace_path,
            raw_record=event,
        )

    return True


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _utc_now_iso() -> str:
    """Return current UTC time as ISO-8601 string with ``Z`` suffix.

    Isolated behind a helper so tests can monkeypatch one target rather
    than patching ``datetime`` globally.
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _validate_event_envelope(event: Any) -> list[str]:
    """Return the sorted list of required envelope fields missing from ``event``."""
    if not isinstance(event, dict):
        return list(_REQUIRED_ENVELOPE_FIELDS)
    return sorted(
        field
        for field in _REQUIRED_ENVELOPE_FIELDS
        if event.get(field) in (None, "")
    )


def _ensure_audit_dir(workspace: Path) -> Path:
    """Create ``runtime/logs/`` if needed and return the audit file path."""
    audit_path = workspace / AUDIT_RELATIVE_PATH
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    return audit_path


def _handle_failure(
    *,
    reason: str,
    strict: bool,
    workspace: Path | None = None,
    raw_record: Any = None,
) -> bool:
    """Surface an append failure per the strict flag.

    v4.89 P0-C C1 (Real Trial v1 F6):
    Non-strict path now tries to preserve the rejected raw record by
    appending to ``<workspace>/runtime/logs/mcp_audit.malformed.jsonl``
    before returning False. This closes the "silent drop" gap — even
    when a caller ignores the return value, the failed record is on
    disk for later forensics.

    New keyword-only parameters ``workspace`` and ``raw_record`` default
    to ``None`` so direct callers from the pre-C1 tests (which only pass
    ``reason`` + ``strict``) stay green; when either is ``None`` the
    malformed sink is skipped.
    """
    # NOTE: the caller tag still reads "workbuddy_collector.append_audit"
    # for backward compatibility with existing log grep lines and test
    # expectations. When the call originates from a P2-P5 collector the
    # caller prefixes its own tag before invoking this helper — or the
    # consumer uses ``source_layer`` / ``runtime_profile`` in the envelope
    # to disambiguate.
    message = f"[workbuddy_collector.append_audit] {reason}"
    if strict:
        raise AuditAppendError(message)
    print(f"WARN {message}", file=sys.stderr)
    # Best-effort malformed sink — never raises, never masks the
    # original False return. A second failure here degrades silently
    # to the stderr warn alone (which has already been emitted).
    if workspace is not None and raw_record is not None:
        try:
            _append_malformed(workspace, raw_record, reason)
        except Exception:
            # Anti-loop guard: swallow and rely on the stderr warn above.
            pass
    return False


def _append_malformed(workspace: Path, record: Any, reason: str) -> bool:
    """Append one rejected record to the malformed audit sink.

    Guarantees:
    - Creates ``runtime/logs/`` if missing (shared with the main audit).
    - Never raises; returns ``False`` on any failure (caller ignores it).
    - Stores ``raw_record`` as-is when JSON-serialisable; otherwise
      stores ``repr(record)`` as a string so the rejection trace is
      still recoverable.
    """
    try:
        path = workspace / MALFORMED_AUDIT_RELATIVE
        path.parent.mkdir(parents=True, exist_ok=True)
    except OSError:
        return False

    try:
        serialisable = json.dumps(record, ensure_ascii=False, sort_keys=True)
        raw_repr: Any = record
    except (TypeError, ValueError):
        serialisable = None
        raw_repr = repr(record)

    entry = {
        "reason": reason,
        "recorded_at": _utc_now_iso(),
        "raw_record": raw_repr if serialisable is None else record,
    }
    try:
        line = json.dumps(entry, ensure_ascii=False, sort_keys=True, default=repr)
    except (TypeError, ValueError):
        return False

    try:
        with path.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        return False
    return True
