#!/usr/bin/env python3
"""cursor_collector — event normalization + shared hardened audit surface.

v4.89 Phase 2 Stage 2 B1 (2026-05-04):
Inherits the hardened audit-envelope surface from ``._base`` so this
collector is contract-equivalent to ``workbuddy_collector`` per the
Stage 2 5-profile parity claim (see
``docs/06_runtime_profiles/STAGE_2_5_PROFILE_PARITY_CHARTER.md``).

Allowed to differ between profiles (Stage 2 charter §3):
- concrete audit sink destination (file vs collector service) — hidden
  inside ``append_audit`` backend selection.
- workspace partitioning granularity tied to ``isolation_unit``.
- the identity of ``cleanup_owner``.

Must stay equivalent:
- envelope 9-field contract (via ``wrap_external_record``).
- ``_ALLOWED_SOURCE_LAYERS = ("tapd", "git", "workbuddy")`` narrow-by-design
  — profile identity (cursor) travels via the envelope ``runtime_profile``
  field, independent of source_layer.
- malformed-fallback sink at ``runtime/logs/mcp_audit.malformed.jsonl``.

The ``normalize_event`` projection stays cursor-specific. The skeleton
projection is preserved verbatim from the v4.88 Batch-3 baseline; any
Cursor-specific refinement is deferred to Stage 2 S2.5 dry-run.
"""
from __future__ import annotations

from ._base import (
    # Public constants
    AUDIT_RELATIVE_PATH,
    MALFORMED_AUDIT_RELATIVE,
    AUDIT_STATUS_PENDING,
    AUDIT_STATUS_EMITTED,
    AUDIT_STATUS_FAILED,
    # Public exception
    AuditAppendError,
    # Public API
    wrap_external_record,
    append_audit,
    # Internal helpers — re-exported for monkeypatch parity with
    # workbuddy_collector.
    _utc_now_iso,
    _validate_event_envelope,
    _ensure_audit_dir,
    _handle_failure,
    _append_malformed,
    _REQUIRED_ENVELOPE_FIELDS,
    _ALLOWED_SOURCE_LAYERS,
    _AUDIT_BACKEND,
)

__all__ = [
    "AUDIT_RELATIVE_PATH",
    "MALFORMED_AUDIT_RELATIVE",
    "AUDIT_STATUS_PENDING",
    "AUDIT_STATUS_EMITTED",
    "AUDIT_STATUS_FAILED",
    "AuditAppendError",
    "normalize_event",
    "wrap_external_record",
    "append_audit",
]


def normalize_event(raw_event: dict) -> dict:
    """Project a raw MCP event into the Cursor collector shape.

    Signature and behaviour are preserved from the v4.88 Batch-3 skeleton
    so existing callers and smoke scripts stay green. Cursor-specific
    projection refinements (e.g. IDE-agent event_type namespacing) are
    deferred to Stage 2 S2.5 dry-run divergence.
    """
    return {
        "event_type": raw_event.get("event_type", "unknown"),
        "timestamp": raw_event.get("timestamp"),
        "actor": raw_event.get("actor", "unknown"),
        "runtime_profile": raw_event.get("runtime_profile"),
        "result": raw_event.get("result", "unknown"),
        "details": raw_event,
    }
