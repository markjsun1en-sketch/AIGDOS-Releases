"""LTM capture — gated write API for the ltm/ corpus.

v4.89 Phase 2 Stage 1 (MVP) — records go to ``ltm/<domain>/<slug>.md``
after a policy Gate. Rejected payloads land in ``ltm/_quarantine/``
instead of being dropped, so a periodic human review can reflow or
discard them.

Gate rules (MVP, see plans/swift-nebula-babbage.md §5.2):

1. ``domain`` must be a known domain (lowercased; maps from
   :data:`runtime.ltm.KNOWN_DOMAINS`). Unknown domain → ValueError
   (programmer bug).
2. For domains ∈ {project, pattern, failures}: ``evidence_ref`` is
   REQUIRED (any non-empty string — we don't format-check; the point
   is to force the author to cite something). Missing evidence →
   route to _quarantine/ with ``gate='blocked'``.
3. ``canonical_override_block``: if domain == 'os' AND content mentions
   'canonical' or 'override', log a stderr WARN but still pass. MVP
   does NOT auto-reject; Phase 3 Self-Evolution tightens this.
4. ``requires_approval=True`` unconditionally forces quarantine.
5. [Phase 4 M9.5] If domain == 'project': ``project_id`` is REQUIRED.
   A blank / missing project_id on a project-domain capture is a
   hardening guardrail — prevents stray project postmortems from
   leaking into the "global / unscoped" pool that every
   project-filtered consult() treats as inherited OS wisdom.
   Non-project domains accept ``project_id`` as an optional tag
   (pattern entries CAN be project-scoped if the author wants).

Defensive I/O (Phase 1 pattern):
- Never raises on filesystem errors; on failure returns a dict with
  ``'gate': 'blocked'`` and a ``reason`` describing the I/O problem.
- Exception: ValueError on unknown domain (same philosophy as
  consult — programmer bug surfaces; environment errors are silenced).
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path

from runtime.ltm.consult import _LTM_ROOT

GATE_STATUS_PASSED: str = "passed"
GATE_STATUS_BLOCKED: str = "blocked"

# Domains that require ``evidence_ref`` at capture time. The OS domain
# accepts captures without evidence_ref because OS-level rules are
# already cross-referenced via MEMORY §x.y anchors in their content.
_EVIDENCE_REQUIRED_DOMAINS: frozenset[str] = frozenset(
    {"project", "pattern", "failures"}
)

# Patterns that trigger the canonical-override soft-warning on the OS
# domain. Deliberately loose: we want authors to see the warning for
# any passage that *could* be interpreted as revising canonical truth,
# and rely on human review at PR time to catch real violations.
_CANONICAL_OVERRIDE_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\bcanonical\b", re.IGNORECASE),
    re.compile(r"\boverride\b", re.IGNORECASE),
)


def capture(
    domain: str,
    title: str,
    content: str,
    *,
    evidence_ref: str | None = None,
    actor: str = "main_session",
    requires_approval: bool = False,
    project_id: str | None = None,
) -> dict:
    """Append an experience record to ``ltm/<domain>/<slug>.md``.

    Parameters
    ----------
    domain:
        One of the policy domains (case-insensitive; see
        :data:`runtime.ltm.KNOWN_DOMAINS`).
    title:
        Human-readable H1 heading. Used verbatim as the first line of
        the written file (``# <title>``) and slugified for the
        filename.
    content:
        Markdown body. Written below the H1 without transformation.
    evidence_ref:
        Commit sha / audit event_id / path reference. REQUIRED for
        domains in :data:`_EVIDENCE_REQUIRED_DOMAINS`; otherwise
        optional but recommended.
    actor:
        Who initiated the capture. Recorded in file front-matter.
        Defaults to ``"main_session"``, matching the Phase 1 driver
        default.
    requires_approval:
        When True, unconditionally route to _quarantine/ regardless
        of domain / evidence_ref status. Used when an orchestrator
        wants human sign-off before publishing.
    project_id:
        Phase 4 M9.5 — optional cross-project namespace tag. Written
        into the YAML front-matter as ``project_id: <value>`` when
        supplied. For ``domain='project'`` this is REQUIRED (Gate
        rule 5); a missing / blank value routes the payload to
        quarantine instead of writing it into the global pool.
        Non-project domains accept the field as a pure tag — it
        does not alter gate decisions but becomes available to
        ``consult(project_id=...)`` as a filter criterion.

    Returns
    -------
    dict
        ``{
            "path": str,                     # relative to package root
            "gate": "passed" | "blocked",
            "reason": str | None,            # only when blocked
            "captured_at": "<UTC-ISO-Z>",
            "warnings": list[str],
        }``

    Raises
    ------
    ValueError
        Unknown domain.
    """
    # Defer the import to avoid circular import via __init__.
    from runtime.ltm import KNOWN_DOMAINS

    domain_norm = domain.strip().lower() if isinstance(domain, str) else ""
    if domain_norm not in KNOWN_DOMAINS:
        raise ValueError(
            f"unknown domain {domain!r}; "
            f"expected one of {KNOWN_DOMAINS}"
        )

    # Normalise project_id once; empty / whitespace collapses to None
    # so explicit 'project_id=""' does not masquerade as a real tag.
    project_id_norm: str | None
    if isinstance(project_id, str) and project_id.strip():
        project_id_norm = project_id.strip().lower()
    else:
        project_id_norm = None

    timestamp = _utc_now_iso()
    warnings: list[str] = []

    # Gate rule 2: evidence_ref required for project/pattern/failures.
    evidence_missing = (
        domain_norm in _EVIDENCE_REQUIRED_DOMAINS
        and not (evidence_ref and evidence_ref.strip())
    )

    # Gate rule 5 (Phase 4 M9.5): project domain requires project_id.
    # Checked AFTER evidence_missing so the original block reason
    # still surfaces first when both are missing (evidence is the
    # older + coarser signal; keeping its precedence preserves the
    # 6 existing capture tests).
    project_id_missing = (
        domain_norm == "project" and project_id_norm is None
    )

    # Gate rule 3: canonical_override_block SOFT warning on OS domain.
    if domain_norm == "os":
        hits = [
            pat.pattern for pat in _CANONICAL_OVERRIDE_PATTERNS
            if pat.search(content or "")
        ]
        if hits:
            warnings.append(
                "soft-warn: OS-domain content references "
                f"{hits} — ensure it does not override canonical truth "
                "(see memory_retrieval_policy.yaml canonical_override_block)."
            )

    # Gate decision.
    if requires_approval:
        return _route_to_quarantine(
            domain_norm, title, content, timestamp,
            reason="requires_approval=True",
            evidence_ref=evidence_ref,
            actor=actor,
            warnings=warnings,
            project_id=project_id_norm,
        )
    if evidence_missing:
        return _route_to_quarantine(
            domain_norm, title, content, timestamp,
            reason=f"domain={domain_norm!r} requires evidence_ref",
            evidence_ref=evidence_ref,
            actor=actor,
            warnings=warnings,
            project_id=project_id_norm,
        )
    if project_id_missing:
        return _route_to_quarantine(
            domain_norm, title, content, timestamp,
            reason="domain='project' requires project_id",
            evidence_ref=evidence_ref,
            actor=actor,
            warnings=warnings,
            project_id=project_id_norm,
        )

    # Gate passed — write to the real domain directory.
    return _write_captured(
        domain_norm, title, content, timestamp,
        evidence_ref=evidence_ref,
        actor=actor,
        warnings=warnings,
        project_id=project_id_norm,
    )


# ---------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------


def _utc_now_iso() -> str:
    """UTC ISO-8601 with Z suffix (mirrors A1 collector helper style)."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slugify(title: str) -> str:
    """Lowercase kebab-case slug. Falls back to 'untitled' when empty."""
    slug = _SLUG_RE.sub("-", (title or "").lower()).strip("-")
    return slug or "untitled"


def _format_document(
    title: str,
    content: str,
    timestamp: str,
    *,
    evidence_ref: str | None,
    actor: str,
    gate: str,
    project_id: str | None = None,
) -> str:
    """Render the .md body with front-matter + title + content."""
    front_matter = [
        "---",
        f"captured_at: {timestamp}",
        f"actor: {actor}",
        f"gate: {gate}",
        f"evidence_ref: {evidence_ref or ''}",
    ]
    # project_id is Phase 4 M9.5; only emit the field when a value
    # is actually supplied so the 19 legacy entries remain the
    # byte-wise ground truth for "missing ≡ global" semantics.
    if project_id:
        front_matter.append(f"project_id: {project_id}")
    front_matter.extend([
        "---",
        "",
    ])
    return (
        "\n".join(front_matter)
        + f"# {title}\n\n"
        + (content if content.endswith("\n") else content + "\n")
    )


def _write_captured(
    domain: str,
    title: str,
    content: str,
    timestamp: str,
    *,
    evidence_ref: str | None,
    actor: str,
    warnings: list[str],
    project_id: str | None = None,
) -> dict:
    """Write payload to ltm/<domain>/<slug>.md. Never raises.

    Phase 4 M9.5 — when ``domain == 'project'`` and ``project_id`` is
    set, the target becomes ``ltm/project/<project_id>/<slug>.md`` so
    the directory partition stays consistent with the registered
    ``ltm/project/<project_id>/`` convention (see
    ``ltm/project/README.md``). All other domains continue to write
    flat under their domain directory.
    """
    slug = _slugify(title)
    if domain == "project" and project_id:
        target = _LTM_ROOT / domain / project_id / f"{slug}.md"
    else:
        target = _LTM_ROOT / domain / f"{slug}.md"

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            _format_document(
                title, content, timestamp,
                evidence_ref=evidence_ref, actor=actor,
                gate=GATE_STATUS_PASSED,
                project_id=project_id,
            ),
            encoding="utf-8",
        )
    except OSError as exc:
        # Filesystem failure → downgrade to blocked. The caller can
        # decide whether to retry; we do NOT fall back to quarantine
        # because quarantine would hit the same filesystem.
        return {
            "path": _relpath(target),
            "gate": GATE_STATUS_BLOCKED,
            "reason": f"write failed: {exc!r}",
            "captured_at": timestamp,
            "warnings": warnings,
        }

    return {
        "path": _relpath(target),
        "gate": GATE_STATUS_PASSED,
        "reason": None,
        "captured_at": timestamp,
        "warnings": warnings,
    }


def _route_to_quarantine(
    domain: str,
    title: str,
    content: str,
    timestamp: str,
    *,
    reason: str,
    evidence_ref: str | None,
    actor: str,
    warnings: list[str],
    project_id: str | None = None,
) -> dict:
    """Drop the payload into ltm/_quarantine/ for human review."""
    # Filename: <ts>_<domain>_<slug>.quarantined.md
    ts_safe = timestamp.replace(":", "-")
    slug = _slugify(title)
    target = _LTM_ROOT / "_quarantine" / (
        f"{ts_safe}_{domain}_{slug}.quarantined.md"
    )

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        # Augment front-matter so a reviewer sees why it was blocked.
        body = _format_document(
            title, content, timestamp,
            evidence_ref=evidence_ref, actor=actor,
            gate=GATE_STATUS_BLOCKED,
            project_id=project_id,
        )
        body = body.replace(
            "---\ncaptured_at:",
            f"---\nintended_domain: {domain}\nblock_reason: {reason}\ncaptured_at:",
            1,
        )
        target.write_text(body, encoding="utf-8")
    except OSError as exc:
        return {
            "path": _relpath(target),
            "gate": GATE_STATUS_BLOCKED,
            "reason": f"{reason}; additionally quarantine write failed: {exc!r}",
            "captured_at": timestamp,
            "warnings": warnings,
        }

    return {
        "path": _relpath(target),
        "gate": GATE_STATUS_BLOCKED,
        "reason": reason,
        "captured_at": timestamp,
        "warnings": warnings,
    }


def _relpath(absolute: Path) -> str:
    """Return path relative to the package root (like consult)."""
    pkg_root = _LTM_ROOT.parent
    try:
        return str(absolute.relative_to(pkg_root))
    except ValueError:
        return str(absolute)
