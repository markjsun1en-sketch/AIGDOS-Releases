"""v4.89 Long-Term Memory (LTM) engine.

Phase 2 Stage 1 MVP entry point. Exposes:

- :func:`consult` — keyword search over ltm/ corpus (M2).
- :func:`capture` — gated append (M3).
- :data:`KNOWN_DOMAINS` — policy-derived domain allowlist.
- :data:`GATE_STATUS_PASSED` / :data:`GATE_STATUS_BLOCKED` — capture result.

See ``AI_Game_Dev_OS_v4.89/ltm/INDEX.md`` for the layered documentation
and ``.workbuddy/plans/electric-forging-babbage.md`` for the design
whitepaper.

Design notes:

- Policy loaded lazily once per process (see ``_load_policy``).
- All file I/O is defensive — consumers never see unexpected raises
  from corpus traversal; every helper returns an empty / neutral value
  on corpus-side error, matching the Phase 1 ``_ev_get`` /
  ``_resolve_state_path`` pattern.
- No vector search. No LLM summarisation. No DB. Pure filesystem +
  tokenised string matching. This is a deliberate MVP constraint
  (Phase 3 Self-Evolution may relax it; Phase 2 Stage 1 does NOT).
"""
from __future__ import annotations

from runtime.ltm.capture import (
    GATE_STATUS_BLOCKED,
    GATE_STATUS_PASSED,
    capture,
)
from runtime.ltm.consult import consult

__all__ = [
    "consult",
    "capture",
    "KNOWN_DOMAINS",
    "GATE_STATUS_PASSED",
    "GATE_STATUS_BLOCKED",
]

# Policy-derived domain allowlist. Normalised to lowercase at module
# load so callers can pass any casing. Kept in sync with
# ``AI_Game_Dev_OS_v4.89/config/memory_retrieval_policy.yaml``.
KNOWN_DOMAINS: tuple[str, ...] = (
    "os",
    "project",
    "pattern",          # ← corresponds to policy's "Pattern_Capability"
    "failures",         # ← corresponds to policy's "FailureFix"
)
