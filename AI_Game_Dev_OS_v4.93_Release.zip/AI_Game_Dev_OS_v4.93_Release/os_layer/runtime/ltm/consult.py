"""LTM consult — keyword-based retrieval over the ltm/ corpus.

v4.89 Phase 2 Stage 1 (MVP): pure filesystem walk + case-insensitive
whitespace-tokenised matching. Deterministic, inspection-friendly,
zero external dependencies.

Design invariants
-----------------
- **Never raise on I/O.** A missing directory, unreadable file, non-UTF8
  byte, etc. should degrade to "this file contributes 0 hits" silently.
  The caller gets an empty / truncated result list, never an exception.
  This mirrors the Phase 1 ``_ev_get`` / ``_resolve_state_path`` pattern
  and is mandatory per the M1 scaffolding contract.
- **Root-relative paths.** Returned ``path`` fields are relative to
  ``AI_Game_Dev_OS_v4.89/`` (package root), so callers can stitch them
  onto any absolute prefix without guessing.
- **`_quarantine/` is NOT scanned.** Policy: that's staging, not content.
- **Tokenisation is boundary-aware.** ``envelope`` matches ``envelope``
  but also ``envelope_9_field``; we do substring match per token to keep
  the matcher useful on kebab/snake_case filenames.

Performance
-----------
MVP target <= 500 files total. A naive walk + line-by-line scan is well
under 50 ms on SSD. No caching; every call re-scans. Phase 3 may add an
index if corpus size grows past ~5k files.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

# Package root = AI_Game_Dev_OS_v4.89/  (three levels up from this file:
# runtime/ltm/consult.py -> ltm/ -> runtime/ -> package root).
_PKG_ROOT: Path = Path(__file__).resolve().parents[2]
_LTM_ROOT: Path = _PKG_ROOT / "ltm"

# Max lines to scan per file when matching inside body text. Documents
# longer than this still count filename hits and the first N lines of
# content. Keeps the search bounded even if a contributor drops a 100k
# transcript into ltm/.
_BODY_SCAN_LIMIT: int = 50

# Max excerpt length in the hit result. Enough for a one-liner;
# callers that want more should Read the file directly.
_EXCERPT_CHARS: int = 200

# Domains excluded from default search. ``_quarantine/`` is not real
# LTM content; it's the Gate-reject landing zone (see ltm/_quarantine/
# README.md).
_EXCLUDED_DIRS: frozenset[str] = frozenset({"_quarantine"})

# M9.5 — How many lines we scan when harvesting the optional
# ``project_id`` YAML front-matter field. Front-matter blocks live
# within the first handful of lines (``captured_at``, ``actor``,
# ``gate``, ``evidence_ref``, optional ``project_id``), so 20 is a
# generous cap that still bounds I/O cost on pathological inputs.
_FRONTMATTER_SCAN_LIMIT: int = 20

# Capture the raw value of a ``project_id:`` YAML line. Accepts
# unquoted, single-quoted, and double-quoted forms; trims trailing
# comments. Empty value = ``None`` (unscoped / global entry).
_PROJECT_ID_RE: re.Pattern[str] = re.compile(
    r"^\s*project_id\s*:\s*(?P<val>.*?)\s*(?:#.*)?$"
)


def consult(
    query: str,
    *,
    domain: str | None = None,
    limit: int = 10,
    project_id: str | None = None,
    engine: str = "auto",
) -> list[dict]:
    """Search the LTM corpus by keyword.

    Parameters
    ----------
    query:
        Search phrase. Whitespace-split into tokens; matching is
        case-insensitive substring per token. Empty / whitespace-only
        query returns ``[]``.
    domain:
        Restrict search to ``ltm/<domain>/``. Must be one of
        :data:`runtime.ltm.KNOWN_DOMAINS`. If ``None``, all domains
        except ``_quarantine`` are scanned.
    limit:
        Max hits. Must be >= 1; values < 1 are coerced to 1 to avoid
        silent empty results from typos. Default 10.
    project_id:
        Phase 4 M9.5 — optional project-namespace filter. Semantics:

        - ``None`` (default) → no project filtering; every scored hit
          is returned (pre-M9.5 behaviour; 19 legacy entries remain
          discoverable unchanged).
        - ``"<id>"`` → keep hits whose front-matter ``project_id``
          equals ``<id>`` OR is missing/blank. The "missing ≡ global"
          semantic means cross-project OS / pattern / failures entries
          remain visible to every project-scoped query; only entries
          tagged with a *different* ``project_id`` get excluded.

        This preserves full backward compatibility for the 10 OS + 6
        failures + 2 patterns entries captured before M9.5 (none of
        them carries a ``project_id``).
    engine:
        v4.90 Layer B — retrieval engine selector. Three values:

        - ``"auto"`` (default) — resolves to ``"substring"`` for
          backward compatibility. v4.89 Layer A scoring + tie-break
          contract is preserved bit-identical. (FTS5 ranking would
          break ``test_score_ranking_and_tie_break``, so auto does NOT
          opt in by default. See
          ``docs/15_ltm_v2/LAYER_B_OVERVIEW.md`` §"Default-mode
          contract".)
        - ``"substring"`` — explicit Layer A path; identical to
          ``"auto"``. Always available.
        - ``"fts5"`` — explicit Layer B path. Uses
          ``runtime.ltm._fts5_index.query`` with BM25 ranking. Raises
          ``RuntimeError`` if FTS5 is unavailable in this Python's
          sqlite3 build (loud failure on explicit opt-in).

    Returns
    -------
    list[dict]
        Sorted by ``score`` descending, then by ``path`` alphabetical
        (substring engine) or by BM25 ascending mapped to descending
        ``score`` (fts5 engine). Each hit:
          ``{"path": str, "domain": str, "title": str,
             "excerpt": str, "score": float | int}``

    Raises
    ------
    ValueError
        If ``domain`` is set but not in KNOWN_DOMAINS, OR if ``engine``
        is not one of ``"auto"`` / ``"substring"`` / ``"fts5"``.
    RuntimeError
        If ``engine="fts5"`` but FTS5 is not available in sqlite3.
    """
    # Defer the import to avoid circular import via __init__.
    from runtime.ltm import KNOWN_DOMAINS

    # Engine validation. Must happen BEFORE domain validation so a
    # bogus engine surfaces even when query/domain are also bogus.
    engine_norm = (engine or "auto").strip().lower()
    if engine_norm not in {"auto", "substring", "fts5"}:
        raise ValueError(
            f"unknown engine {engine!r}; "
            f"expected one of 'auto', 'substring', 'fts5'"
        )

    # FTS5 path. Validate domain via KNOWN_DOMAINS first so the
    # ValueError contract is the same as the substring path.
    if engine_norm == "fts5":
        if domain is not None:
            domain_norm = domain.strip().lower()
            if domain_norm not in KNOWN_DOMAINS:
                raise ValueError(
                    f"unknown domain {domain!r}; "
                    f"expected one of {KNOWN_DOMAINS}"
                )
        else:
            domain_norm = None
        from runtime.ltm._fts5_index import (  # noqa: E402
            probe_fts5_available, query as _fts5_query,
        )
        if not probe_fts5_available():
            raise RuntimeError(
                "engine='fts5' requested but FTS5 is unavailable in "
                "this Python's sqlite3. Use engine='substring' or "
                "engine='auto' for backward-compatible behaviour."
            )
        return _fts5_query(
            query, domain=domain_norm, limit=limit, project_id=project_id,
        )

    # 'auto' resolves to substring (Layer A bit-identical).
    # 'substring' is explicit Layer A.
    # Both fall through to the original implementation.

    tokens = _tokenise(query)
    if not tokens:
        return []

    if domain is not None:
        domain_norm = domain.strip().lower()
        if domain_norm not in KNOWN_DOMAINS:
            raise ValueError(
                f"unknown domain {domain!r}; "
                f"expected one of {KNOWN_DOMAINS}"
            )
        search_dirs: Iterable[Path] = [_LTM_ROOT / domain_norm]
    else:
        search_dirs = _iter_domains()

    # Normalise the project filter once up front. An all-whitespace or
    # empty string collapses to ``None`` so callers that pass an empty
    # CLI arg don't silently exclude every entry.
    project_filter: str | None
    if isinstance(project_id, str) and project_id.strip():
        project_filter = project_id.strip().lower()
    else:
        project_filter = None

    limit = max(1, limit)
    hits: list[dict] = []
    for directory in search_dirs:
        hits.extend(_scan_directory(directory, tokens, project_filter))

    # Secondary sort by path keeps output deterministic when scores tie.
    hits.sort(key=lambda h: (-h["score"], h["path"]))
    return hits[:limit]


# ---------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------


def _tokenise(query: str) -> list[str]:
    """Split ``query`` into lowercase tokens.

    No stopword removal, no stemming — MVP keeps this literal.
    """
    if not isinstance(query, str):
        return []
    return [tok for tok in query.lower().split() if tok]


def _iter_domains() -> list[Path]:
    """Yield each domain directory under ltm/, skipping _quarantine."""
    if not _LTM_ROOT.exists():
        return []
    try:
        children = sorted(p for p in _LTM_ROOT.iterdir() if p.is_dir())
    except OSError:
        return []
    return [p for p in children if p.name not in _EXCLUDED_DIRS]


def _scan_directory(
    directory: Path,
    tokens: list[str],
    project_filter: str | None = None,
) -> list[dict]:
    """Walk ``directory`` recursively and score every .md file.

    When ``project_filter`` is not None, entries whose front-matter
    ``project_id`` differs from the filter are excluded. Entries with
    no ``project_id`` remain visible (the "missing ≡ global" semantic
    introduced in Phase 4 M9.5).
    """
    if not directory.exists():
        return []

    try:
        md_files = sorted(directory.rglob("*.md"))
    except OSError:
        return []

    # Domain = the top-level folder under ltm/ (e.g. "os", "failures").
    try:
        domain = directory.relative_to(_LTM_ROOT).parts[0]
    except (IndexError, ValueError):
        domain = directory.name

    hits: list[dict] = []
    for md in md_files:
        if project_filter is not None:
            entry_pid = _read_project_id(md)
            if entry_pid is not None and entry_pid != project_filter:
                # Explicitly tagged with a different project → skip.
                continue
            # entry_pid is None → unscoped / global → remain visible.
            # entry_pid == project_filter → scoped match → remain.
        score, excerpt = _score_file(md, tokens)
        if score <= 0:
            continue
        hits.append({
            "path": _relpath(md),
            "domain": domain,
            "title": _first_heading(md),
            "excerpt": excerpt,
            "score": score,
        })
    return hits


def _read_project_id(path: Path) -> str | None:
    """Return the lowercase ``project_id`` YAML field or ``None``.

    Scans at most :data:`_FRONTMATTER_SCAN_LIMIT` lines. A missing
    field, blank value, unreadable file, or non-UTF8 byte all degrade
    to ``None`` — matching the defensive-I/O contract of the rest of
    consult.py. Callers treat ``None`` as "unscoped / global" and
    therefore always-visible under any project filter.
    """
    try:
        with path.open("r", encoding="utf-8") as fh:
            for lineno, raw in enumerate(fh, start=1):
                if lineno > _FRONTMATTER_SCAN_LIMIT:
                    break
                match = _PROJECT_ID_RE.match(raw.rstrip("\n"))
                if match is None:
                    continue
                value = match.group("val").strip()
                # Strip matching surrounding quotes (``'rh'`` / ``"rh"``).
                if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
                    value = value[1:-1].strip()
                return value.lower() or None
    except (OSError, UnicodeDecodeError):
        return None
    return None


def _score_file(path: Path, tokens: list[str]) -> tuple[int, str]:
    """Return (score, excerpt) for ``path`` given the token set.

    Scoring: +1 per unique token found in filename OR in the first
    ``_BODY_SCAN_LIMIT`` lines. ``excerpt`` is the first body line
    that contained a token hit (filename-only hits fall back to the
    H1 heading).
    """
    name_lower = path.name.lower()
    filename_hits = {tok for tok in tokens if tok in name_lower}

    body_hits: set[str] = set()
    excerpt = ""
    try:
        with path.open("r", encoding="utf-8") as fh:
            for lineno, raw in enumerate(fh, start=1):
                if lineno > _BODY_SCAN_LIMIT:
                    break
                line = raw.rstrip("\n")
                lower = line.lower()
                found_here = {tok for tok in tokens if tok in lower}
                if found_here and not excerpt:
                    # Trim noise (leading markdown markers / whitespace).
                    excerpt = line.strip()
                    if len(excerpt) > _EXCERPT_CHARS:
                        excerpt = excerpt[:_EXCERPT_CHARS - 1] + "…"
                body_hits |= found_here
    except OSError:
        return 0, ""
    except UnicodeDecodeError:
        return 0, ""

    total_hits = filename_hits | body_hits
    if not total_hits:
        return 0, ""

    # Score = number of DISTINCT tokens that fired anywhere (filename
    # or body). A token firing in both counts once — prevents artificial
    # ranking inflation from repeating a keyword throughout the body.
    score = len(total_hits)

    if not excerpt:
        # Fall back to file title or filename when only filename matched.
        excerpt = _first_heading(path) or path.stem
    return score, excerpt


def _first_heading(path: Path) -> str:
    """Return the first ``# `` heading, or the filename if absent."""
    try:
        with path.open("r", encoding="utf-8") as fh:
            for lineno, raw in enumerate(fh, start=1):
                if lineno > _BODY_SCAN_LIMIT:
                    break
                line = raw.strip()
                if line.startswith("# "):
                    return line[2:].strip()
    except (OSError, UnicodeDecodeError):
        return path.stem
    return path.stem


def _relpath(absolute: Path) -> str:
    """Render ``absolute`` as a path relative to the package root."""
    try:
        return str(absolute.relative_to(_PKG_ROOT))
    except ValueError:
        return str(absolute)
