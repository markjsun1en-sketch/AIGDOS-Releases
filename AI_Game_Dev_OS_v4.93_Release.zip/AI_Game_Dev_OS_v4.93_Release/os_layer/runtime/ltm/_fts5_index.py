"""runtime.ltm._fts5_index — SQLite FTS5 retrieval upgrade for LTM Layer B.

v4.90 Batch 4 Module C — GUIDED tier.

Design contract (locked by docs/15_ltm_v2/LAYER_B_OVERVIEW.md):

* Public surface area: ``probe_fts5_available()`` / ``rebuild_index()`` /
  ``query()`` / ``index_path()``. The Layer A consult.py imports these
  and chooses between substring and FTS5 paths via the ``engine`` kwarg.
* **Default ``engine="auto"`` MUST behave identically to Layer A**
  because Layer A test ``test_score_ranking_and_tie_break`` asserts
  exact ranking + score values that FTS5 ranking would not preserve.
  Therefore ``_AUTO_PREFERS_FTS5 = False`` — auto resolves to substring;
  FTS5 is opt-in via ``engine="fts5"``. See Step 4.5.a research note.
* Zero external dependencies (stdlib sqlite3 only). PyYAML / jsonschema
  not used.
* Atomic rebuild: write to ``<index>.tmp`` then ``os.replace``.
* Index file is a generated artifact — not in RELEASE_MANIFEST /
  CHECKSUMS / git (see .gitignore).

Public API:

>>> from runtime.ltm import _fts5_index
>>> _fts5_index.probe_fts5_available()
True
>>> _fts5_index.rebuild_index()
{'entries_indexed': 22, 'index_path': 'ltm/.fts_index.sqlite'}
>>> hits = _fts5_index.query('envelope contract', limit=5)
>>> [h['path'] for h in hits[:2]]
['ltm/os/envelope_9_field_contract.md', ...]

Hit shape (matches consult.py):
    {'path': str, 'domain': str, 'title': str, 'excerpt': str,
     'score': float, 'project_id': str | None}
"""
from __future__ import annotations

import os
import re
import sqlite3
from pathlib import Path
from typing import Any

# ----------------------------------------------------------------------
# Module constants
# ----------------------------------------------------------------------

# Default behaviour of engine='auto'. False = always fall through to
# substring (parity-safe with Layer A tests). Tests that explicitly want
# FTS5 must pass engine='fts5'. See Step 4.5.a decision in
# docs/15_ltm_v2/LAYER_B_OVERVIEW.md §"Default-mode contract".
_AUTO_PREFERS_FTS5: bool = False

# Resolved at import time from runtime/ltm/consult.py to share the same
# corpus root + excluded-dirs convention.
from runtime.ltm.consult import (  # noqa: E402
    _LTM_ROOT,
    _EXCLUDED_DIRS,
    _EXCERPT_CHARS,
    _FRONTMATTER_SCAN_LIMIT,
)

# Index file name. Lives under _LTM_ROOT so monkey-patching _LTM_ROOT
# in tests redirects the index too.
_INDEX_BASENAME: str = ".fts_index.sqlite"

# Cache for the FTS5 capability probe (None = not yet probed).
_FTS5_PROBE_CACHE: bool | None = None


# ----------------------------------------------------------------------
# Capability probe
# ----------------------------------------------------------------------

def probe_fts5_available() -> bool:
    """Return True if SQLite FTS5 virtual tables can be created here.

    First call performs the probe; subsequent calls return the cached
    result. Tests can reset the cache with :func:`_reset_probe_cache`.
    """
    global _FTS5_PROBE_CACHE
    if _FTS5_PROBE_CACHE is not None:
        return _FTS5_PROBE_CACHE
    try:
        conn = sqlite3.connect(":memory:")
        try:
            conn.execute("CREATE VIRTUAL TABLE _t USING fts5(x)")
            _FTS5_PROBE_CACHE = True
        finally:
            conn.close()
    except sqlite3.OperationalError:
        _FTS5_PROBE_CACHE = False
    except sqlite3.Error:
        # Be defensive — any other sqlite error is treated as "FTS5
        # not available" so the caller falls back to substring.
        _FTS5_PROBE_CACHE = False
    return _FTS5_PROBE_CACHE


def _reset_probe_cache() -> None:
    """Test helper — force the next probe_fts5_available() call to
    re-evaluate. Public so tests can use it without reaching into a
    private name."""
    global _FTS5_PROBE_CACHE
    _FTS5_PROBE_CACHE = None


# ----------------------------------------------------------------------
# Index location
# ----------------------------------------------------------------------

def index_path() -> Path:
    """Resolve the current index file path.

    Re-imports _LTM_ROOT each call so monkey-patched test fixtures land
    on the test tmp_path.
    """
    from runtime.ltm.consult import _LTM_ROOT as live_root  # noqa: E402
    return Path(live_root) / _INDEX_BASENAME


# ----------------------------------------------------------------------
# Document harvesting (shared with substring path semantics)
# ----------------------------------------------------------------------

_TITLE_RE = re.compile(r"^#\s+(?P<title>.+?)\s*$", re.MULTILINE)
_PROJECT_ID_RE = re.compile(
    r"^project_id:\s*(?P<value>\S+)", re.MULTILINE
)


def _read_text(path: Path) -> str:
    """Defensively read text. Returns '' on any I/O / decode error."""
    try:
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return ""


def _extract_title(text: str, fallback: str) -> str:
    m = _TITLE_RE.search(text)
    if m:
        return m.group("title").strip()
    return fallback


def _extract_project_id(text: str) -> str | None:
    """Read the optional project_id YAML front-matter field.

    Bounds the scan to the first _FRONTMATTER_SCAN_LIMIT lines, matching
    consult.py's behaviour.
    """
    head = "\n".join(text.splitlines()[:_FRONTMATTER_SCAN_LIMIT])
    m = _PROJECT_ID_RE.search(head)
    if m is None:
        return None
    val = m.group("value").strip().strip("\"'")
    if val.lower() in {"null", "~", ""}:
        return None
    return val.lower()


def _strip_front_matter(text: str) -> str:
    """Drop the leading ``---\\n...---\\n`` block if present."""
    if not text.startswith("---\n"):
        return text
    end = text.find("\n---\n", 4)
    if end == -1:
        return text
    return text[end + len("\n---\n"):]


def _iter_corpus_files() -> list[Path]:
    """Walk _LTM_ROOT for .md files, excluding _quarantine/ and the
    index file itself."""
    from runtime.ltm.consult import _LTM_ROOT as live_root  # noqa: E402
    root = Path(live_root)
    if not root.exists() or not root.is_dir():
        return []
    out: list[Path] = []
    for p in root.rglob("*.md"):
        # Skip files under _EXCLUDED_DIRS (e.g. _quarantine/).
        try:
            rel = p.relative_to(root)
        except ValueError:
            continue
        first = rel.parts[0] if rel.parts else ""
        if first in _EXCLUDED_DIRS:
            continue
        out.append(p)
    return out


def _classify_domain(rel_path_parts: tuple[str, ...]) -> str:
    if not rel_path_parts:
        return ""
    return rel_path_parts[0]


# ----------------------------------------------------------------------
# Index build / rebuild
# ----------------------------------------------------------------------

_FTS5_DDL = """
CREATE VIRTUAL TABLE entries USING fts5(
    path UNINDEXED,
    domain UNINDEXED,
    project_id UNINDEXED,
    title,
    content,
    tokenize = 'unicode61 remove_diacritics 2'
);
"""


def rebuild_index() -> dict[str, Any]:
    """(Re)build the FTS5 index file atomically.

    Returns a dict with diagnostic fields:
        {
          'index_path': str,            # relative to package root
          'entries_indexed': int,
          'fts5_available': bool,
          'rebuilt': bool,              # True if write succeeded
        }

    Raises ``RuntimeError`` when FTS5 is unavailable. The caller is
    expected to have probed first; raising loudly here matches the
    contract for explicit ``engine='fts5'`` failures.
    """
    if not probe_fts5_available():
        raise RuntimeError(
            "FTS5 unavailable — cannot rebuild index. "
            "Use engine='substring' or run on a Python with FTS5-enabled sqlite3."
        )

    target = index_path()
    tmp = target.with_suffix(target.suffix + ".tmp")
    target.parent.mkdir(parents=True, exist_ok=True)
    if tmp.exists():
        try:
            tmp.unlink()
        except OSError:
            pass

    files = _iter_corpus_files()
    rows: list[tuple[str, str, str | None, str, str]] = []
    from runtime.ltm.consult import _LTM_ROOT as live_root  # noqa: E402
    pkg_root = Path(live_root).parent
    for p in files:
        text = _read_text(p)
        if not text:
            continue
        try:
            rel_to_root = p.relative_to(live_root)
        except ValueError:
            continue
        body = _strip_front_matter(text)
        title = _extract_title(body, fallback=p.stem)
        project_id = _extract_project_id(text)
        domain = _classify_domain(tuple(rel_to_root.parts))
        try:
            rel_to_pkg = p.relative_to(pkg_root)
            path_str = str(rel_to_pkg)
        except ValueError:
            path_str = str(p)
        rows.append((path_str, domain, project_id, title, body))

    conn = sqlite3.connect(str(tmp))
    try:
        conn.execute(_FTS5_DDL)
        conn.executemany(
            "INSERT INTO entries(path, domain, project_id, title, content) "
            "VALUES (?, ?, ?, ?, ?)",
            rows,
        )
        conn.commit()
    finally:
        conn.close()

    os.replace(tmp, target)
    return {
        "index_path": _relpath_to_pkg(target),
        "entries_indexed": len(rows),
        "fts5_available": True,
        "rebuilt": True,
    }


# ----------------------------------------------------------------------
# Querying
# ----------------------------------------------------------------------

def _ensure_index_fresh() -> Path | None:
    """Make sure the index file exists and is at least as new as the
    newest corpus file. Rebuild lazily when stale.

    Returns the index path on success, or None if FTS5 is unavailable.
    """
    if not probe_fts5_available():
        return None
    target = index_path()
    if not target.exists():
        rebuild_index()
        return target
    # Stale check: any .md newer than the index → rebuild.
    try:
        index_mtime = target.stat().st_mtime
    except OSError:
        rebuild_index()
        return target
    for p in _iter_corpus_files():
        try:
            if p.stat().st_mtime > index_mtime:
                rebuild_index()
                break
        except OSError:
            continue
    return target


def _quote_for_fts5(token: str) -> str:
    """Escape a single token for FTS5 phrase matching.

    FTS5 special characters: ``"`` (phrase delim) is doubled; everything
    else is wrapped in double-quotes to disable operator interpretation.
    """
    return '"' + token.replace('"', '""') + '"'


def _build_fts5_query(query: str) -> str:
    """Compose a token-by-token AND query, like consult.py's substring
    AND-of-tokens semantics. Multi-word substrings inside quotes are
    treated as a single phrase.
    """
    raw_tokens = [t for t in query.split() if t]
    if not raw_tokens:
        return ""
    return " AND ".join(_quote_for_fts5(t) for t in raw_tokens)


def query(
    query_str: str,
    *,
    domain: str | None = None,
    limit: int = 10,
    project_id: str | None = None,
) -> list[dict[str, Any]]:
    """FTS5-backed query. Lazy-rebuilds index if stale or absent.

    Returns a list of hit dicts in score-ranked order
    (lowest BM25 score first ≡ most relevant first per FTS5 convention,
    converted here to a positive `score` so callers can sort descending).
    """
    if not query_str or not query_str.strip():
        return []

    target = _ensure_index_fresh()
    if target is None:
        # FTS5 unavailable; caller should not have reached here. Return
        # empty rather than raise — parity with consult's defensive I/O.
        return []

    fts_q = _build_fts5_query(query_str)
    if not fts_q:
        return []

    sql = (
        "SELECT path, domain, project_id, title, content, "
        "       bm25(entries) AS score "
        "FROM entries "
        "WHERE entries MATCH ? "
    )
    params: list[Any] = [fts_q]
    if domain is not None:
        sql += "AND domain = ? "
        params.append(domain)
    sql += "ORDER BY bm25(entries) ASC LIMIT ?"
    params.append(int(limit) * 4)  # over-fetch for project_id filtering

    conn = sqlite3.connect(str(target))
    try:
        try:
            cur = conn.execute(sql, params)
            raw_rows = cur.fetchall()
        except sqlite3.OperationalError:
            return []
    finally:
        conn.close()

    hits: list[dict[str, Any]] = []
    for path_str, dom, pid, title, content, bm25_score in raw_rows:
        # M9.5 namespace filter — "missing ≡ global" semantics.
        if project_id is not None:
            if pid is not None and pid != project_id.strip().lower():
                continue
        excerpt = (content or "").splitlines()[0:3]
        excerpt_text = " ".join(excerpt).strip()[:_EXCERPT_CHARS]
        # Convert BM25 (lower = better) to a positive 'score' so callers
        # can sort descending the same way they do for substring hits.
        # We negate and rebase: higher score ≡ more relevant.
        score = -float(bm25_score) if bm25_score is not None else 0.0
        hits.append({
            "path": path_str,
            "domain": dom or "",
            "title": title or "",
            "excerpt": excerpt_text,
            "score": score,
            "project_id": pid,
        })
        if len(hits) >= limit:
            break

    return hits


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------

def _relpath_to_pkg(absolute: Path) -> str:
    pkg_root = Path(_LTM_ROOT).parent
    try:
        return str(absolute.relative_to(pkg_root))
    except ValueError:
        return str(absolute)
