"""CLI wrapper for runtime.ltm.consult (v4.89 P2 M2.3 + v4.90 Step 13.1).

Usage
-----
    python -m runtime.ltm "envelope contract"
    python -m runtime.ltm "closed_at" --domain failures
    python -m runtime.ltm "pointer shim" --limit 3 --format json
    python -m runtime.ltm "sprint close" --project rh

Entry point is ``python -m runtime.ltm`` (the package), which routes
to this ``__main__`` module. We deliberately do NOT ship
``python -m runtime.ltm.consult`` as a CLI path — running a submodule
as script also works but emits a RuntimeWarning because runpy sees
the submodule already imported via the package. Package-level -m
is the cleaner convention.

Exit codes (v4.90 Batch 13 Step 13.1, plan §9 字面 alignment)
------------------------------------------------------------
  0 — OK. 0 or more hits printed successfully.
  1 — INPUT_ERROR. Unknown domain, unknown engine, or argparse-rejected
      value. Caller should fix invocation.
  3 — INTERNAL. ``--engine fts5`` requested but FTS5 unavailable in
      this Python's sqlite3 build (loud failure on explicit opt-in).
  4 — INPUT_MISSING. Query empty AND ltm/ corpus directory absent
      (CLI invoked outside the package root, no rebuild requested).

Why no non-zero exit on empty hits:
  Empty results are a legitimate outcome (the query just didn't match
  anything), not a failure. Callers that want to gate on ">=1 hit"
  can pipe through ``| grep .`` or use --format json mode and
  ``jq 'length > 0'``.

Backward compatibility
----------------------
  ``--json`` is retained as a DEPRECATED alias of ``--format json`` so
  existing v4.89-era invocations keep working. New scripts SHOULD
  use ``--format json``.
"""
from __future__ import annotations

import argparse
import json
import sys

from runtime.ltm import KNOWN_DOMAINS, consult

# Exit codes — plan §9 字面 alignment (v4.90 Batch 13 Step 13.1).
EXIT_OK: int = 0
EXIT_INPUT_ERROR: int = 1     # unknown domain/engine, argparse rejected value
EXIT_INTERNAL: int = 3        # FTS5 unavailable on explicit opt-in
EXIT_INPUT_MISSING: int = 4   # query empty AND ltm/ absent


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m runtime.ltm",
        description="Search the LTM corpus by keyword (v4.89 Phase 2 MVP).",
    )
    parser.add_argument(
        "query",
        nargs="?",
        default="",
        help=(
            "Search phrase (case-insensitive; whitespace-tokenised). "
            "May be omitted when --rebuild-index is used standalone."
        ),
    )
    parser.add_argument(
        "--domain",
        choices=KNOWN_DOMAINS,
        default=None,
        help=f"Narrow to one domain ({'/'.join(KNOWN_DOMAINS)}).",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=10,
        help="Max hits to return (default 10).",
    )
    parser.add_argument(
        "--project",
        default=None,
        metavar="PROJECT_ID",
        help=(
            "Phase 4 M9.5 — filter to entries tagged "
            "``project_id: <PROJECT_ID>`` plus unscoped (global) "
            "entries. Missing / blank project_id means an entry is "
            "visible to every project-scoped query. No choices= "
            "validation: any future project_id works without a code "
            "change."
        ),
    )
    parser.add_argument(
        "--format",
        choices=("text", "json"),
        default="text",
        help=(
            "v4.90 Step 13.1 — output format (default 'text'). "
            "'json' emits NDJSON, one hit per line. Plan §9 字面."
        ),
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="json_alias",
        help=(
            "DEPRECATED alias of --format json. Retained so v4.89-era "
            "invocations continue to work; new scripts SHOULD prefer "
            "--format json."
        ),
    )
    parser.add_argument(
        "--engine",
        choices=("auto", "substring", "fts5"),
        default="auto",
        help=(
            "v4.90 Layer B — retrieval engine. 'auto' (default) is "
            "bit-identical to Layer A substring matching. 'fts5' opts "
            "in to SQLite FTS5 BM25 ranking; raises if FTS5 is not "
            "available in this Python's sqlite3."
        ),
    )
    parser.add_argument(
        "--rebuild-index",
        action="store_true",
        help=(
            "v4.90 Layer B — force rebuild of the FTS5 index file "
            "(ltm/.fts_index.sqlite). Implies --engine=fts5. The "
            "index is otherwise lazy-built on first FTS5 query and "
            "auto-refreshed when stale."
        ),
    )
    return parser


def _format_hit_human(hit: dict) -> str:
    """Single-line human-readable rendering.

    Format: ``<score> <path>: <title> — <excerpt>``
    """
    return (
        f"{hit['score']}  {hit['path']}: "
        f"{hit['title']} — {hit['excerpt']}"
    )


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        # argparse already printed the usage line. argparse uses code=2
        # for unknown choices/missing args, code=0 for --help. Map:
        #   0 (help)  -> EXIT_OK
        #   non-zero  -> EXIT_INPUT_ERROR (plan §9 字面)
        return EXIT_OK if not exc.code else EXIT_INPUT_ERROR

    # --rebuild-index implies --engine=fts5 (rebuilding makes no sense
    # otherwise). Accept either ordering of the two flags.
    if args.rebuild_index:
        try:
            from runtime.ltm._fts5_index import (  # noqa: E402
                rebuild_index, probe_fts5_available,
            )
        except ImportError as exc:
            print(f"error: cannot import FTS5 module: {exc}", file=sys.stderr)
            return EXIT_INTERNAL
        if not probe_fts5_available():
            print(
                "error: --rebuild-index requested but FTS5 is unavailable "
                "in this Python's sqlite3.",
                file=sys.stderr,
            )
            return EXIT_INTERNAL
        result = rebuild_index()
        print(
            f"FTS5 index rebuilt: {result['entries_indexed']} entries -> "
            f"{result['index_path']}",
            file=sys.stderr,
        )
        # Force fts5 engine for the subsequent query (if any non-empty
        # query was supplied; allow rebuild-only invocation).
        engine = "fts5"
    else:
        engine = args.engine

    # If invoked purely for index rebuild with a placeholder query,
    # skip the consult call. We use empty/whitespace query as the
    # convention since consult() returns [] for those anyway.
    if args.rebuild_index and not args.query.strip():
        return EXIT_OK

    # v4.90 Step 13.1 — INPUT_MISSING (exit 4) detection.
    # Distinguish "query empty + ltm/ corpus absent" from "query empty
    # + corpus present (legitimate empty result)". Avoids silent
    # confusion when CLI is invoked outside the package root.
    # Imported lazily to avoid widening the module-level import surface.
    from runtime.ltm.consult import _LTM_ROOT  # noqa: PLC0415
    if not args.query.strip() and not _LTM_ROOT.exists():
        print(
            f"error: query empty AND ltm/ corpus not found at {_LTM_ROOT}",
            file=sys.stderr,
        )
        return EXIT_INPUT_MISSING

    try:
        hits = consult(
            args.query,
            domain=args.domain,
            limit=args.limit,
            project_id=args.project,
            engine=engine,
        )
    except ValueError as exc:
        # Programmer-side input bug: unknown domain or engine name
        # bypassing argparse choices=. Plan §9 INPUT_ERROR.
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_INPUT_ERROR
    except RuntimeError as exc:
        # Raised when engine='fts5' explicit but FTS5 unavailable.
        # Plan §9 INTERNAL — environment problem, not user input.
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_INTERNAL

    # Output mode — --format wins; --json is deprecated alias.
    emit_json = args.format == "json" or args.json_alias

    if emit_json:
        for hit in hits:
            sys.stdout.write(json.dumps(hit, ensure_ascii=False) + "\n")
    else:
        if not hits:
            print("(no hits)", file=sys.stderr)
        for hit in hits:
            print(_format_hit_human(hit))

    return EXIT_OK


if __name__ == "__main__":
    raise SystemExit(main())
