# Sprint Runtime Registries — v4.89

> **Status**: skeleton (M9.0.2). Empty registries shipped as the cold-start governance baseline. First project to adopt v4.89 OS seeds its own data.
> **Owner**: `v489_sprint_window_governor`
> **Sync mode**: `manual` (cold-start governor reads; project tools write).
> **Working language**: English (permanent contract §11).

---

## 1. File Inventory

| File | Role |
|---|---|
| `task_registry.json` | Authoritative list of project tasks (id, title, status, owner_agent, sprint_id, blocker_ids, handoff_ids, evidence_refs, updated_at). |
| `blocker_registry.json` | Open and resolved blockers (id, title, owner_agent, status, reason, linked_task_ids, priority). Includes `admission_policy` block. |
| `handoff_queue.json` | All handoffs (active + archived) with id, file_path, status, source, created_at, accepted_at, completed_at, consumed_by, archive_ready, age_days, linked_issue_ids. |
| `project_status_snapshot.json` | Aggregated one-page view: `summary` (counts) + `queues` (id lists per status) + `by_owner` (per-agent rollup) + `health` (status + notes). |
| `archive_index.json` | Lookup index over `logs/orchestrator_log.md` and `logs/handoffs/archive/` so cold-start can locate historical entries without full-scan. |

## 2. Common Top-Level Schema

Every registry file carries the same envelope:

```json
{
  "schema_version": "1.0",
  "project": "v4.89_os",
  "sync_mode": "manual",
  "generated_at": null,
  "source_refs": [...]
}
```

`sync_mode` values:
- `manual` — registry maintained by project tooling; cold-start reads only. (Default for v4.89 OS skeleton.)
- `semi_auto` — partial automation (e.g. handoff_queue is regenerated from `logs/handoffs/`).
- `auto` — fully tool-managed.

`generated_at` is `null` in the skeleton; it becomes an ISO 8601 UTC string once a project ingests data and runs the rollup tooling.

## 3. Per-Entry Schemas

### 3.1 task_registry.tasks[i]
```json
{
  "task_id": "string (matches runtime/config/task_id_pattern.json)",
  "title": "string",
  "status": "open | in_progress | blocked | validation_pending | done",
  "owner_agent": "string (agent name)",
  "sprint_id": "string | null",
  "blocker_ids": ["string"],
  "handoff_ids": ["string"],
  "evidence_refs": ["path | url"],
  "updated_at": "ISO 8601 UTC"
}
```

### 3.2 blocker_registry.blockers[i]
```json
{
  "blocker_id": "string",
  "title": "string",
  "owner_agent": "string",
  "status": "open | in_progress | resolved",
  "reason": "string",
  "linked_task_ids": ["string"],
  "priority": "low | medium | high",
  "source_status": "string | null",
  "updated_at": "ISO 8601 UTC"
}
```

### 3.3 handoff_queue.handoffs[i]
```json
{
  "handoff_id": "string",
  "file_path": "logs/handoffs/<file>.md or logs/handoffs/archive/<file>.md",
  "status": "open | accepted | completed | archived",
  "source": "string (originating agent)",
  "created_at": "ISO 8601 UTC",
  "accepted_at": "ISO 8601 UTC | null",
  "completed_at": "ISO 8601 UTC | null",
  "consumed_by": "string | null",
  "archive_ready": "boolean",
  "age_days": "number",
  "linked_issue_ids": ["string"]
}
```

### 3.4 project_status_snapshot
Top-level keys:
- `summary` — integer counts per status bucket.
- `queues` — id arrays per status bucket (parallels `summary` keys).
- `by_owner` — `{ owner_agent: { active, blocked, done, ... } }`.
- `health.status` — `empty | green | yellow | red`. `empty` means skeleton; downstream tooling sets the rest.

### 3.5 archive_index.entries[i]
```json
{
  "entry_id": "string",
  "kind": "handoff | log_entry",
  "file_path": "string",
  "sprint_ids": ["string"],
  "created_at": "ISO 8601 UTC",
  "summary": "string (≤200 chars)"
}
```

## 4. Task ID Pattern

The task id pattern is **not hardcoded** in tools. Projects declare it via `runtime/config/task_id_pattern.json`. The skeleton ships a permissive default; projects override.

## 5. Skeleton Acceptance Bar

- [x] All 5 registry JSON validate against this README schema.
- [x] `project` field equals `"v4.89_os"`.
- [x] All entry arrays empty (no fake seeded data).
- [x] No upstream-project lexicon residue inside the registry payloads — the skeleton ships generic only; verified by the M9.0.2 commit acceptance grep.
- [x] `health.status = "empty"` in snapshot.

## 6. Adoption Workflow

A project adopts v4.89 cold-start governance by:
1. Copying the registry skeleton.
2. Setting `project` to its own identifier and `sync_mode` per its tooling choice.
3. Defining its task ID pattern in `runtime/config/task_id_pattern.json`.
4. Running `tools/runtime/generate_sprint_context_rollup.py` to populate `sprint_context_rollup.json` and `archive_index.json` (these two are generator outputs — see M9.0.4).
5. Running `tools/runtime/boot_agent_thread.py` for cold-start invocation (see M9.0.4 / M9.0.5).

## 7. References

- M9.0 plan: `~/.workbuddy/plans/electric-thunder-turing.md`
- M9.0 audit: `docs/06_runtime_profiles/PHASE_4_M9_0_COLDSTART_AUDIT.md`
- Source reference (read-only, outside the v4.89 package): the upstream sprint-governance project under `<UPSTREAM_SOURCE_ROOT>/lessismore/`. Backport mapping recorded in the M9.0 audit.
