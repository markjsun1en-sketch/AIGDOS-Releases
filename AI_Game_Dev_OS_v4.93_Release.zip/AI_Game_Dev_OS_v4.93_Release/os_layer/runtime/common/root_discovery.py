"""Root discovery for AI_Game_Dev_OS v4.89.

This module avoids brittle fixed-depth directory assumptions.
"""
from __future__ import annotations

import os
from pathlib import Path

MARKER_FILENAME = ".core_os_root"


def validate_core_os_root(root: Path) -> bool:
    required = [
        root / "docs",
        root / "runtime",
        root / "config",
    ]
    return all(path.exists() for path in required)


def discover_core_os_root(start_path: Path) -> Path:
    env_root = os.environ.get("CORE_OS_ROOT")
    if env_root:
        candidate = Path(env_root).resolve()
        if validate_core_os_root(candidate):
            return candidate

    current = start_path.resolve()
    for candidate in [current, *current.parents]:
        marker = candidate / MARKER_FILENAME
        if marker.exists() and validate_core_os_root(candidate):
            return candidate

    raise RuntimeError(
        "Unable to discover Core OS root. "
        f"Searched upward from: {start_path}. "
        f"Expected marker: {MARKER_FILENAME} and required dirs: docs/, runtime/, config/."
    )
