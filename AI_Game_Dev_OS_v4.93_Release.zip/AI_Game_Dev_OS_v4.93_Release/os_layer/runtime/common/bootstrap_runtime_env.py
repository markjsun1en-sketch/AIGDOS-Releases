"""Shared runtime bootstrap for AI_Game_Dev_OS v4.89.

This module centralizes common runtime initialization behavior so that
individual scripts do not need to re-implement import bootstrapping and
root discovery.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path


def bootstrap_paths() -> Path:
    """Ensure the current script directory is importable and discover root.

    Returns:
        Path: discovered Core OS root path.
    """
    current_dir = Path(__file__).resolve().parent
    if str(current_dir) not in sys.path:
        sys.path.insert(0, str(current_dir))

    from root_discovery import discover_core_os_root  # local import after path bootstrap

    root = discover_core_os_root(current_dir)
    os.environ.setdefault("CORE_OS_ROOT", str(root))
    return root


def ensure_runtime_context() -> Path:
    """Bootstrap and validate runtime context.

    Returns:
        Path: discovered Core OS root path.
    """
    root = bootstrap_paths()
    if not root.exists():
        raise RuntimeError(f"Discovered CORE_OS_ROOT does not exist: {root}")
    return root
