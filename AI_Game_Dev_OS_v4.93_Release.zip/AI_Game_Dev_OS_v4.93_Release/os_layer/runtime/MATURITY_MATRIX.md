# Runtime Script Maturity Matrix

> **Scope**: v4.88 per-script maturity labels using the 4-tier model from `docs/01_architecture/PACK_MATURITY_MODEL.md` (SCAFFOLD / GUIDED / MANUAL / PRODUCTION).
> **Purpose**: make the gap between "script exists" and "script is trial-ready" visible so reviewers and Phase 4 trial coordinators know which scripts are safe to rely on vs which are skeletons pending expansion.

## 1. Maturity Tier Recap

| Tier | Line count indicator | Operational stance |
| --- | --- | --- |
| SCAFFOLD | < 1 KB (~30 lines) | interface named; body is stub or placeholder; not operationally usable |
| GUIDED | 1–5 KB | reader/caller can use it with some manual filling; edge cases may fail |
| MANUAL | 5–20 KB | operationally complete for documented flow; not covered by automated tests |
| PRODUCTION | 20+ KB with test coverage | hardened, test-backed, production-ready |

(Sizes are heuristic; a small script may still be MANUAL if it wraps tested functionality.)

## 2. Script Inventory

### 2.1 runtime/integrations/git/

| Script | Bytes | Tier | Notes |
| --- | ---: | --- | --- |
| `git_branch_cleanup.py` | 280 | SCAFFOLD | v4.88 RC12 inherited; Phase 4 to expand |
| `git_daily_inspection.py` | 695 | SCAFFOLD | v4.88 RC12 inherited; no real inspection logic yet |
| `merge_conflict_checker.py` | 337 | SCAFFOLD | v4.88 RC12 inherited |
| `serial_merge_guard.py` | 706 | SCAFFOLD | v4.88 RC12 inherited; full impl is a Phase 4 priority |

### 2.2 runtime/integrations/tapd/

| Script | Bytes | Tier | Notes |
| --- | ---: | --- | --- |
| `parent_child_aggregation.py` | (v4.88 RC12 inherited) | GUIDED | interface defined; Phase 4 validation needed |
| `read_after_write_verifier.py` | (v4.88 RC12 inherited) | GUIDED | |
| `status_mapping_validator.py` | (v4.88 RC12 inherited) | GUIDED | |
| `tapd_sync_executor.py` | (v4.88 RC12 inherited) | GUIDED | |

### 2.3 runtime/observability/

| Script | Bytes | Tier | Notes |
| --- | ---: | --- | --- |
| `audit_summary_cli.py` | (v4.88 RC12 inherited) | SCAFFOLD | |
| `reconciliation_report_cli.py` | (v4.88 RC12 inherited) | SCAFFOLD | |
| `sprint_close_audit_cli.py` | 318 | SCAFFOLD | v4.88 RC12 inherited |
| `runtime_event_collectors/workbuddy_collector.py` | ~4,800 (B+ C1 hardening) | GUIDED | B+ 2026-05-02: append_audit helper + AuditAppendError; silent-failure detection (strict mode raises, non-strict writes stderr WARN — never silently swallows). Other 4 sibling collectors remain SCAFFOLD (v4.89 P1-4 equal-coverage scope). |
| `runtime_event_collectors/{claude_subagents,claude_teams,codex,cursor}_collector.py` (4 files) | ~485 each | SCAFFOLD | collector protocol under REV-2-018 work; equal-coverage hardening deferred to v4.89 per BP+Q4 scope boundary |

### 2.4 runtime/common/

| Script | Bytes | Tier | Notes |
| --- | ---: | --- | --- |
| `bootstrap_runtime_env.py` | (v4.88 RC12 inherited) | GUIDED | used by Phase 2 integration-tested flow |
| `root_discovery.py` | (v4.88 RC12 inherited) | GUIDED | covered by Output Contract (REV-2-011 commit f67d62e) |

### 2.5 scripts/runtime/ (v4.87 restored Phase 2)

| Script | Bytes | Tier | Notes |
| --- | ---: | --- | --- |
| `reconcile_external_state.py` | 20,712 | MANUAL | v4.87 substantive work, integration-tested |
| `snapshot_generator.py` | 19,650 | MANUAL | v4.87 substantive work |
| `state_transition_engine.py` | 21,320 | MANUAL | v4.87 substantive work |
| `sprint_close_readiness_checker.py` | 16,770 | MANUAL | v4.87 substantive work |
| `registry_manager.py` | 12,530 | MANUAL | v4.87 substantive work |
| `runtime_object_cli.py` | 7,070 | MANUAL | v4.87 substantive work |
| `runtime_common.py` | (Phase 2 Step 1.0) | GUIDED | shared utility module for Route A scripts |

### 2.6 scripts/ (top-level)

| Script | Bytes | Tier | Notes |
| --- | ---: | --- | --- |
| `assemble_project_attachment.py` | ~7,140 | GUIDED | v4.87 restored; PKG_ROOT TRANSFORM pending Phase 3 Step 3 |
| `export_runtime_summary.py` | 4,570 | GUIDED | v4.87 restored Phase 2 |
| `ingest_adapter_events.py` | 4,910 | GUIDED | v4.87 restored Phase 2 + integration-tested |
| `init_runtime_env.py` | ~15,400 (B+ C3 hardening) | GUIDED | B+ 2026-05-02: real init (audit dir seeded, tapd_config_instance.json written, workbuddy_private overlay preflight, dirty-state recovery hint); exit codes aligned with REV-2-011 (0/1/2/3); stub fallback preserved for isolated tempdirs |
| `validate_runtime_paths.py` | ~4,600 (REV-5-007 upgrade) | GUIDED | 2/5 targets impl: stale-version scan + markdown link existence check (`--mode stale|links|all`); remaining 3 targets (REV-2-006 coverage matrix) scheduled for v4.90 Batch 0.5 |
| `verify_required_content.py` | (v4.88 RC12 inherited) | GUIDED | |
| `run_beta_sprint_check.py` | ~15,700 (B+ C5 hardening) | GUIDED | B+ 2026-05-02: 5 check blocks (docs / profile / adapter+collector / agents_guard / checklist); AGENTS.md.template ≥32 KiB tagged as opaque_blob (edge case C.1); --profile / --strict / --workspace flags |
| `verify_beta_sprint_exit.py` | ~25,700 (B+ C10 hardening) | MIXED | B+ 2026-05-02: init_integrity + evidence + close promoted SCAFFOLD→GUIDED (profile 3-way cross-check, ISO-8601, dirty_worktree+project_defined edge case C.2, demo residue scan; envelope completeness + 4 coverage classes + timestamp monotonicity; enumerated unticked items + closed_at null + per-id merge.apply/cleanup pairing). execution + external remain SCAFFOLD (v4.89 P0-2 remainder). Report carries per-category tier. |
| `run_mock_smoke.sh` | ~3,200 (B+ C11 extended; Python rewrite 2026-05-10) | GUIDED | 5 scenarios S1/S3/S4/S5/S5b; thin proxy to `run_mock_smoke.py` (in-process Python harness, ~20× faster, SIGALRM 30s timeout); CI integration scheduled for v4.90 Batch 0.5 |
| `read_audit.py` | ~4,400 (Phase 3 Step 2) | GUIDED | jsonl filter + summary; REV-3-004 |
| `check_core_os_root.py` | ~3,700 (Phase 3 Step 2) | GUIDED | root discovery + content regex; REV-5-003 |
| `stamp_project_overrides.py` | ~6,200 (Phase 3 Step 2) | GUIDED | starter bundle placeholder substitution; REV-5-008 |
| `linter/architecture_linter.py` + RULE_A/B/C/D | (Phase 2 Step 3) | **mixed**: runner=GUIDED, RULE_C=GUIDED, RULE_A/B/D=SCAFFOLD | Runner orchestrates 4 rules and emits per-rule `maturity` (`REAL`/`STUB`); RULE_C is real (line-count + size + 3 allowlists, WARN/FAIL); RULE_A/B/D ship as specs + policy stubs (no scanning runs). Real A/B/D deferred to v4.90. See `docs/05_architecture_linter/README.md` "Status in v4.89 Release" |

## 3. Trial-Critical Subset

The minimum script set required for a Beta Sprint trial run (Phase 4 readiness):

**Must-have (must reach GUIDED or better)**:
- `runtime/common/bootstrap_runtime_env.py` ✅ GUIDED
- `runtime/common/root_discovery.py` ✅ GUIDED
- `scripts/init_runtime_env.py` ✅ GUIDED (B+ C3, 2026-05-02)
- `scripts/runtime/snapshot_generator.py` ✅ MANUAL
- `scripts/runtime/reconcile_external_state.py` ✅ MANUAL
- `scripts/runtime/sprint_close_readiness_checker.py` ✅ MANUAL
- `scripts/runtime/state_transition_engine.py` ✅ MANUAL
- `scripts/ingest_adapter_events.py` ✅ GUIDED
- `scripts/export_runtime_summary.py` ✅ GUIDED

**Nice-to-have (SCAFFOLD acceptable at Phase 4 entry)**:
- runtime/integrations/git/* (manual git workflow compensates)
- runtime/integrations/tapd/* (Orchestrator can do proxy sync manually)
- runtime/observability/runtime_event_collectors/workbuddy_collector.py ✅ GUIDED (B+ C1); other 4 sibling collectors remain SCAFFOLD
- `scripts/verify_beta_sprint_exit.py` — MIXED (B+ C10): init+evidence+close GUIDED; execution+external SCAFFOLD (v4.89 P0-2 remainder)

**Trial-blocking gaps resolved by B+ (2026-05-02)**:
- ~~`scripts/init_runtime_env.py` SCAFFOLD~~ → GUIDED (B+ C3)
- ~~`scripts/run_beta_sprint_check.py` SCAFFOLD~~ → GUIDED (B+ C5)
- `scripts/validate_runtime_paths.py` — GUIDED (REV-5-007 upgrade, 2/5 targets impl); remaining 3 targets scheduled for v4.90 Batch 0.5

REV-2-012-trial-blocking is CLOSED for the Workbuddy Private path;
remaining items move to v4.89 equal-coverage backlog (P1-4).

## 3.1 v4.89 Phase 1 Hardening (2026-05-02)

**Scope**: Beta Sprint Hardening 15 commits (seed + A1-A5 + C1-C4 + Pre-Z1 + B1-B3 + Z1) on branch `revise/phase-1-fork`, tag `v4.89-phase-1`.

**Modules upgraded to GUIDED-pytested**:

| Script | B+ tier | v4.89 Phase 1 tier | pytest file |
| --- | --- | --- | --- |
| `runtime/observability/runtime_event_collectors/workbuddy_collector.py` | GUIDED (B+ C1) | **GUIDED-pytested** | `test_wrap_external_record.py` + `test_append_audit_malformed.py` (11 cases) |
| `integrations/tapd_adapter_stub.py` | GUIDED (B+ C7) | **GUIDED-pytested** | `test_tapd_envelope.py` (2 cases) |
| `integrations/git_adapter_stub.py` | GUIDED (B+ C8) | **GUIDED-pytested** | `test_git_source_layer.py` (3 cases) |
| `scripts/verify_beta_sprint_exit.py` | MIXED (B+ C10) | **GUIDED-pytested** for init + close + external (A5+C4+Pre-Z1); evidence upgraded by Pre-Z1 W2 (audit monotonicity) | `test_ev_get.py` + `test_resolve_state_path.py` + `test_profile_alias.py` (12 cases) |
| `scripts/init_runtime_env.py` | GUIDED (B+ C3) | **GUIDED-pytested** | `test_profile_alias.py` (covers C2 alias + C4 path contract via subprocess) |
| `scripts/run_beta_sprint_check.py` | GUIDED (B+ C5) | **GUIDED-pytested** (C3 fallback) | `test_check_profile_fallback.py` (3 cases) |

**New infrastructure**:

- `AI_Game_Dev_OS_v4.89/tests/` — 31-case pytest suite (B1, `0943813`).
- `.github/workflows/v4_89_tests.yml` — Actions 3.11+3.12 matrix + smoke job (B2, `dbc2697`).
- `.pre-commit-config.yaml` — local opt-in hooks for pytest + smoke (B2).

**Contract / semantics upgrades in v4.89 Phase 1**:

1. **Envelope contract** (A1-A5): adapter → audit passes through `wrap_external_record()`; consumers read via `_ev_get()`.
2. **Path contract** (C4 + Pre-Z1): `runtime_state.json` + `sprint_close_checklist.md` each have canonical location + fallback resolver.
3. **Profile alias** (C2): `profile` ↔ `runtime_profile` bidirectional.
4. **Silent-drop elimination** (C1): collector non-strict failures land in `mcp_audit.malformed.jsonl` instead of stderr only.
5. **Timestamp monotonicity** (Pre-Z1): trial driver interleaves per-task events + `task_idx*2` offset across adapter loops — originally Phase 2 red line, delivered in Phase 1 via swift-forging-tesla Q3 provision.

**Trial outcome** (pre-Z1 sanity): `rh_sprint_sim_01` verdict=**PASS** / error=0 / warn=0 (was CONDITIONAL / error=0 / warn=3 at §2 baseline).

**v4.89 Phase 1 tier label semantics**:

- `GUIDED-pytested` = GUIDED (operationally usable with documented flow) + pytest coverage for the hardened contracts introduced by this phase. Not yet MANUAL/PRODUCTION — those require wider integration testing against real TAPD / real git repos, Phase 2+.

## 3.2 v4.89 Phase 2 Stage 1 LTM MVP (2026-05-03)

**Scope**: Long-Term Memory layer MVP — 10 commits on branch `revise/phase-1-fork`, tag `v4.89-phase-2-m5`. Introduces the `ltm/` documentation tree and the `runtime/ltm/` engine package.

**New modules at GUIDED-pytested tier**:

| Module | Tier | pytest file |
| --- | --- | --- |
| `runtime/ltm/__init__.py` | **GUIDED-pytested** | indirectly via the two tests below |
| `runtime/ltm/consult.py` | **GUIDED-pytested** | `tests/test_ltm_consult.py` (6 cases) + `tests/test_ltm_integration.py` (2 cases) |
| `runtime/ltm/capture.py` | **GUIDED-pytested** | `tests/test_ltm_capture.py` (6 cases) |
| `runtime/ltm/__main__.py` (CLI) | **GUIDED** | CLI wrapper; self-tested at commit time via 4 invocation scenarios; no pytest (parse-args + forward to consult) |

**Corpus (not source code, but part of the deliverable)**:
- `ltm/INDEX.md` — entry point
- `ltm/os/*.md` — 10 Phase 1 permanent contracts + 1 subrange-immutable rule
- `ltm/failures/*.md` — 2 Phase 1 postmortems (A4 dry-run fail / Z1 closed_at null)
- `ltm/project/` / `ltm/pattern/` / `ltm/_quarantine/` — domain READMEs only (populated Stage 2+)

**Contract / semantics introduced**:

1. **4-domain corpus layering** — OS / Project / Pattern / FailureFix. Policy alignment: `config/memory_retrieval_policy.yaml` `memory_domains` extended from 3 → 4.
2. **Envelope-aware read pattern applied to LTM** — `consult()` never raises on I/O; `ValueError` only for unknown domain.
3. **Gate rules at write time** — evidence_ref required for non-OS domains; canonical-override soft warn for OS domain; requires_approval forces quarantine.
4. **`_quarantine/` sink** — rejected captures are preserved (not dropped) for human review.
5. **Separation from `.workbuddy/memory/`** — LTM is OS corpus; Kai's `.workbuddy/memory/` is session continuity (private).

**Phase 2 Stage 1 outcome**:
- pytest 45-case (31 Phase 1 + 6 consult + 6 capture + 2 integration).
- `run_mock_smoke.sh` 5/5 PASS (Phase 1 baseline preserved).
- Trial `rh_sprint_sim_01` verdict=PASS / error=0 / warn=0 (unchanged from Phase 1 — LTM doesn't touch trial).
- `consult('envelope')` returns 6 hits from `ltm/os/` (Stage 1 §11 target was ≥3).
- `v4.88_Release/` 539-file shasum baseline untouched.

## 3.3 v4.89 Phase 2 Stage 2 — 5-profile parity hardening (2026-05-05)

**Scope**: Per-profile contract-level parity for the five non-baseline runtime profiles (codex / cursor / claude_code_agent_teams / claude_code_subagents / default_beta_codex_tapd_git) plus an integration-layer regression that locks the 16-verdict matrix as the Stage 2 acceptance contract. **9 milestones M6.0 → M6.9 / 9 commits on branch `revise/phase-1-fork`**, tag `v4.89-phase-2-m6`.

**Thesis**: Stage 1 LTM hardened the *memory* layer; Stage 2 hardens the *parity* layer.  Before Stage 2 the verifier could give every non-P1 mirror a clean PASS — but that PASS was probe blindness, not evidence.  Stage 2 instruments the verifier so it can fire when each profile's contract is broken, and proves the firing works on every profile.  "Parity is not all PASS; parity is the verifier can tell apart the profile from its negation."

**New modules at GUIDED-pytested tier**:

| Module | Tier | pytest file |
| --- | --- | --- |
| `scripts/beta_sprint_driver.py` (M6.2) | **GUIDED-pytested** | `tests/test_beta_sprint_driver.py` (15 cases) |
| `scripts/mirror_trial_workspace.py` (M6.3 + M6.4–M6.7 fixtures) | **GUIDED-pytested** | `tests/test_mirror_trial_workspace.py` (40 parametrised cases) |
| `scripts/verify_beta_sprint_exit.py` `check_init_integrity` 4 per-profile cross-check blocks (M6.4–M6.7) | **GUIDED-pytested** | 4 per-profile cross-check tests (24 cases total) |
| `tests/test_verify_codex_cross_check.py` (M6.4) | **GUIDED-pytested** | self (6 cases C1–C6) |
| `tests/test_verify_cursor_cross_check.py` (M6.5) | **GUIDED-pytested** | self (6 cases C1–C6) |
| `tests/test_verify_claude_teams_cross_check.py` (M6.6) | **GUIDED-pytested** | self (6 cases C1–C6) |
| `tests/test_verify_claude_subagents_cross_check.py` (M6.7) | **GUIDED-pytested** | self (6 cases C1–C6) |
| `tests/test_stage_2_regression_r1.py` (M6.8) | **GUIDED-pytested** | self (16 matrix rows + 1 size-lock = 17 cases) |

**Trial workspace mirrors (committed reproducibility artefacts)**:
- 5 positive mirrors (M6.3): `trial_workspaces/rh_sprint_sim_01__{codex,cursor,claude_code_agent_teams,claude_code_subagents,default_beta_codex_tapd_git}/` (12 files / ~110 KB each, idempotent regenerable from generator)
- 4 negative mirrors (M6.4–M6.7): `trial_workspaces/rh_sprint_sim_01__<profile>_negative/` (12 files each, generated via `--inject-violation contract_drift`)

**Postmortem corpus (evidence ladder for Stage 2 close)**:
- `ltm/failures/2026-05-05_codex_silent_pass_blindness.md` (M6.4)
- `ltm/failures/2026-05-05_cursor_silent_pass_blindness.md` (M6.5)
- `ltm/failures/2026-05-05_claude_teams_silent_pass_blindness.md` (M6.6)
- `ltm/failures/2026-05-05_claude_subagents_silent_pass_blindness.md` (M6.7)

**Contract / semantics introduced**:

1. **Per-profile schema cross-check** — each non-baseline profile has a profile-gated `if` block in `check_init_integrity` that fires WARN when contract fields are explicitly declared with values that contradict the profile JSON ground truth.  Three profiles (codex / cursor / claude_teams) use `coordination_model + writeback_owner`; one profile (claude_subagents) uses `audit_collector + context_loading_method` due to ground-truth collision with codex.
2. **Negative-mirror discipline** — every cross-check is witnessed by a deliberately contract-violating mirror generated by `--inject-violation contract_drift`.  Step 3 silent-PASS proof (run verify against the negative mirror BEFORE adding the cross-check) is the load-bearing artefact: it proves the gap exists rather than asserting it.
3. **Maturity floor on negative mirrors** — SCAFFOLD on a negative mirror skips the `init` category by design (matching M6.0b → M6.2 maturity gate semantics), so the cross-check fires only under GUIDED.  This keeps the negative-mirror evidence narrow and the SCAFFOLD path uncluttered.
4. **R1 regression as acceptance contract** — `test_stage_2_regression_r1.py` parametrises the 16-row verdict matrix end-to-end (subprocess driver → JSON envelope → 4 signal field assertions).  Any future Phase 3 schema-driven cross-checker must produce byte-identical envelopes on every matrix row before the per-profile if-tree is allowed to be removed.
5. **Symmetric-vs-asymmetric block evidence** — three of four profiles can use the same dimension pair; one cannot.  This heterogeneity is intentionally preserved as the input to a future Phase 3 schema-driven cross-checker audit (uniform if-tree would have been weaker evidence).

**Phase 2 Stage 2 outcome**:
- pytest 45-case (Stage 1) → **161-case** (+116: M6.2 driver 15 + M6.3 mirror 40 + 4 × cross-check 24 + R1 regression 17 + 20 misc covered earlier).
- 16-row verdict matrix locked: 6 positive mirror × 2 maturity (12) + 4 negative mirror × GUIDED (4); 4 negative all CONDITIONAL/2 WARN/0 ERROR.
- Trial `rh_sprint_sim_01` baseline (P1) verdict=PASS unchanged.
- 4 postmortems form a complete per-profile evidence ladder (codex / cursor / claude_teams / claude_subagents).
- Phase 1 11 permanent contracts: untouched.
- v4.88_Release 539-file shasum baseline: untouched.
- 4 per-profile cross-check blocks in `verify.py` (M6.4–M6.7) sum to 110 lines additions, all within the EP scope-guard ≤30 per block.
- Subprocess driver runtime: ~0.78s for 17 R1 cases.

**Phase 3 handoff (deferred candidates, NOT in Stage 2 scope)**:
- Schema-driven cross-checker — read profile JSON full contract surface → emit WARN per drift, no per-profile if-tree.  Acceptance gate: byte-identical R1 regression envelopes on all 16 rows.
- Lift cross-check gate from "explicitly declared in state" to "any declared profile contract field must match profile JSON" (requires init-time canonical write of contract surface; bigger change, defer pending init refactor).
- Remove the per-profile if-tree only after schema-driven checker proves equivalence; Stage 2's per-profile blocks are the auditable comparison baseline.

## 3.4 v4.89 Phase 3 — schema-driven cross-checker audit (2026-05-05)

**Scope**: Phase 3 Lock-A (M7.0 G-b2 fix) + Lock-B (M7.1 schema-driven cross-checker audit) on branch `revise/phase-1-fork`. Audit-only milestone — does not yet collapse the per-profile if-tree from M6.4-M6.7. Tag `v4.89-phase-3-audit` (cut at M7.1 close).

**Thesis**: Stage 2 closed with four per-profile cross-check `if` blocks (110 lines additions to verify.py). M7.1 audits whether a single schema-driven cross-checker that reads each profile JSON's contract surface can produce byte-identical findings on all 16 R1 matrix rows. If yes, the per-profile if-tree is informationally redundant.

**New modules at GUIDED-pytested tier**:

| Module | Tier | pytest file |
| --- | --- | --- |
| `runtime/schema_driven_check.py` (M7.1 prototype) | **GUIDED-pytested** | `tests/test_schema_driven_equivalence.py` (17 cases: 16 matrix rows + 1 size lock) |
| `tests/test_schema_driven_equivalence.py` (M7.1) | **GUIDED-pytested** | self |

**Updates to existing modules** (M7.0 + M7.1):

| Module | Change | Tier impact |
| --- | --- | --- |
| `scripts/verify_beta_sprint_exit.py` `_VALID_PROFILES` | M7.0: +1 line (added `default_beta_codex_tapd_git`) | tier unchanged (GUIDED-pytested) |
| `scripts/verify_beta_sprint_exit.py` `check_init_integrity` | M7.1: +14-line env switch at function entry; per-profile if-tree (M6.4-M6.7 four blocks) preserved byte-stable | tier unchanged |
| `config/profiles/default_beta_codex_tapd_git.json` | M7.0: +1 line (`context_loading_method=project_docs_plus_selected_files`) | data, not code |
| `trial_workspaces/rh_sprint_sim_01__default_beta_codex_tapd_git/` | M7.0: byte-level update via `--force` regenerate | data, not code |

**Audit deliverables**:
- `ltm/pattern/2026-05-05_phase_3_schema_driven_audit.md` — full audit report (Question / Methodology / Findings / Recommendation / Lesson) including the empirical verdict that all 16 matrix rows are byte-identical between paths.

**Contract / semantics introduced**:

1. **Env-switched dual cross-checker** — `STAGE_2_USE_SCHEMA_CHECKER=1` selects the schema-driven path; default path keeps the M6.4-M6.7 per-profile if-tree byte-stable. Both paths produce identical JSON envelopes on every R1 row.
2. **Per-profile field allowlist as the equivalence anchor** — `_PROFILE_CHECK_FIELDS` in `runtime/schema_driven_check.py` encodes the same field choices M6.4-M6.7 made (codex/cursor/claude_teams use `coordination_model + writeback_owner`; claude_subagents uses `audit_collector + context_loading_method`). The allowlist is what preserves byte-identical output; replacing it with "scan all profile JSON fields" would surface previously-uncovered dimensions and break equivalence.
3. **Acceptance contract for Phase 3 Step 2 collapse** — empirical evidence (16/16 byte-identical) supports collapsing the per-profile if-tree in a follow-up milestone (M7.2 candidate). EP retained the call: Option A (audit-only, current state) preserves the Stage 2 evidence ladder; Option B (collapse) is behaviour-preserving but mutates postmortems' line-number references.

**Phase 3 outcome**:
- pytest 161 (Stage 2 close) → **178** (+17 equivalence test cases).
- 16-row R1 matrix verdict unchanged (P6/GUIDED upgraded from CONDITIONAL/1W to PASS via M7.0 G-b2 fix).
- v4.88_Release shasum: 539 / 0 FAILED (preserved).
- 4 per-profile cross-check blocks in verify.py byte-stable through M7.0 + M7.1.
- 4 postmortems gained an M7.0 footer (G-b2 RESOLVED note); their original verdict lines are preserved as historical snapshots.

**Phase 3 Step 2 handoff (deferred)**:
- Option B (collapse) requires removing the four per-profile if blocks (110 lines) and making the schema-driven path the default. Acceptance gate already met. Tracked in `ltm/pattern/2026-05-05_phase_3_schema_driven_audit.md` §"Phase 3 candidate Step 2".
- Lift cross-check gate from "explicitly declared in state" to "any declared profile contract field must match profile JSON" — requires init refactor; defer to Phase 4.

### §3.4 update — Phase 3 M7.2 collapse executed (2026-05-05)

The Phase 3 Step 2 candidate (Option B — collapse the per-profile if-tree into the schema-driven path) was **executed in M7.2** rather than deferred. Tag: `v4.89-phase-3-collapse`.

**What changed in `scripts/verify_beta_sprint_exit.py`** (M7.2 collapse):

| Before M7.2 | After M7.2 |
|---|---|
| 4 per-profile `if` blocks (M6.4-M6.7), 110 lines, in `check_init_integrity` body | Single `findings.extend(schema_driven_init_check(state, state_path))` call site (~10 lines incl. comment), plus 1-line top-level import |
| `STAGE_2_USE_SCHEMA_CHECKER` env switch (M7.1 audit dual-path bridge) | Removed — schema-driven path is now the only path |
| `runtime/schema_driven_check.py` `from verify_beta_sprint_exit import _finding` (M7.1) | Inlined identical `_finding()` body (avoids circular import once verify.py imports schema_driven_check at top) |

**Net source-line impact**: -103 lines in verify.py. The four per-profile cross-check tests (`tests/test_verify_codex_cross_check.py` + cursor + claude_teams + claude_subagents = 24 cases) remain **byte-stable** and continue to pass under the schema-driven path, witnessing that the per-profile gate semantics survived collapse without any test rewrite — exactly the audit-on-evidence outcome M7.1 promised.

**Phase 3 outcome (M7.2 close)**:
- pytest 178 unchanged (M7.1 baseline preserved).
- 16-row R1 matrix verdict unchanged.
- 4 postmortems gain a Phase 3 M7.2 footer note; original verdict / line-number references preserved as frozen historical snapshots.
- Audit report (`ltm/pattern/2026-05-05_phase_3_schema_driven_audit.md`) gains a Phase 3 M7.2 footer recording the executed collapse + outcomes.
- Equivalence test (`test_schema_driven_equivalence.py`) becomes trivial (both paths invoke the same code) but is kept as a regression guard for future profile additions; see its module docstring for rationale.
- v4.88_Release shasum: 539 / 0 FAILED (preserved across M7.0 + M7.1 + M7.2).

**Phase 4 candidates (deferred to Phase 4 entry)**:
- Lift cross-check gate from "explicitly declared in state" to "any declared profile contract field must match profile JSON" — requires init refactor.
- Self-evolution / cross-project replay / vector retrieval — Phase 4 platform-phase territory.

## 3.5 v4.89 Phase 4 Step 1 — M7.3 Lift gate (2026-05-06)

The Phase 3 deferred candidate (lift the cross-check gate from explicit-declaration to canonical contract surface) was **executed in M7.3** as the entry point of Phase 4.  Pending tag: `v4.89-phase-4-lift` (EP hand-stamp).

**What changed across three modules** (M7.3 7-commit chain):

| Module | Role | Change |
|---|---|---|
| `scripts/init_runtime_env.py` | producer | `_stub_init` now reads `config/profiles/<profile>.json` and canonically writes the 4 contract surface fields (`coordination_model` / `writeback_owner` / `audit_collector` / `context_loading_method`) for every `_VALID_PROFILES` entry.  New helper `_load_profile_ground_truth` swallows missing / malformed JSON to None so the consumer can flag the miss.  +73 lines. |
| `runtime/schema_driven_check.py` | consumer | `schema_driven_init_check` L202-208: replaced the silent-PASS short-circuit `if actual is None: continue` with `emit ERROR(missing contract field)`.  The `actual != expected` path remains WARN. +39 / -10 lines. |
| `scripts/mirror_trial_workspace.py` | re-stamper | `_rewrite_runtime_state` now loads the target profile JSON and re-stamps the 4 contract surface fields onto the copied state.  Missing profile JSON is a hard error here (mirrors must not carry baseline ground-truth values).  +66 / -3 lines. |

The three modules now share a `_CONTRACT_SURFACE_FIELDS` (or `_CONTRACT_FIELDS`) constant that lists the same 4 primitive strings — kept in lock-step manually.  A drift between the three constants would break the chain; the M7.3.5 postmortem flags this in the pattern doc.

**Test surface impact**:

| Test file | Change | Cases |
|---|---|---|
| `tests/test_init_writes_contract_surface.py` (new) | producer regression | +14 |
| `tests/test_stage_2_regression_r1.py` | helper rename `init_warn_fields → init_contract_fields` (union WARN+ERROR); 4 GUIDED positive rows pass through transient FAIL/0/2 in commit 4 → narrow to PASS/0/0 in commit 6 | 16 (unchanged) |
| `tests/test_mirror_trial_workspace.py` | `rc in (0, 1)` → `(0, 1, 2)` → `(0, 1)` (transient open/close in same chain) | 5 (unchanged) |
| `tests/test_verify_codex_cross_check.py` | rewrite — added `_codex_missing_findings` filter; C2 flips from "0 findings" silent-PASS to "2 ERROR + 0 WARN" | 6 (unchanged) |
| `tests/test_verify_cursor_cross_check.py` | rewrite (parallel) | 6 (unchanged) |
| `tests/test_verify_claude_teams_cross_check.py` | rewrite (parallel) | 6 (unchanged) |
| `tests/test_verify_claude_subagents_cross_check.py` | rewrite (parallel); C6 adds explicit `2 codex ERRORs` symmetry-guard assertion | 6 (unchanged) |

**Net pytest impact**: 178 → **192 passed** (+14, 0 regression).

**Maturity moves**:

- `scripts/init_runtime_env.py` — already PRODUCTION (Phase 1 hardened); contract surface write deepens the production claim with 14-case regression coverage.
- `runtime/schema_driven_check.py` — already MANUAL (M7.1 audit, M7.2 collapse); the M7.3 lift adds 4 ERROR-emitting branches and `init_contract_fields` semantics in R1, so this script is now PRODUCTION (full test coverage including the new ERROR path).
- `scripts/mirror_trial_workspace.py` — already MANUAL (M6.3 contract); the M7.3.4 contract-surface re-stamp + `_load_target_ground_truth` raise it to PRODUCTION.

**Phase 4 Step 1 outcome**:
- Silent-PASS second-order residual sealed (parent spec §0 issue #1).
- Trial `rh_sprint_sim_01` GUIDED runs verdict=PASS / 0 error / 0 warn against ALL 5 cross-checked profiles; the 4 negative mirrors still produce CONDITIONAL with 2 WARN drift signals.
- v4.88_Release shasum: 539 / 0 FAILED (unchanged across M7.0 + M7.1 + M7.2 + M7.3).
- LTM postmortem `ltm/pattern/2026-05-06_phase_4_lift_gate.md` records the cross-commit transient pattern + the producer-only-test anti-pattern, both reusable for future milestones.

**Phase 4 Step 2-4 (M8.0 done; M9.0 + M10.0 deferred to next thread)**:
- M9.0 Sprint-window cold-start.
- M10.0 v4.89 Release freeze.

## 3.6 M8.0 Skills 引入 (Phase 4 Step 2 — DONE 2026-05-06)

**Thesis**: v4.89/skills/ already had 19 SKILL.md (Phase 3 Step 1 dual-source from v4.8.2 + RandomHeroes contracts) but the `_generic_core/` task-skill layer was thin under engineering / qa / orchestrator / game-design / numeric / content-design subdirs. M8.0 absorbs the lessismore project's 16 task-skill SKILL.md as a third source: 9 NEW task-skills land in `_generic_core/` role subdirs, 2 OVERLAP art SKILLs are fattened with lessismore richer bodies, 3 Godot-bound skills move to a new `_engine_specific/godot/` third axis parallel to `_generic_core/` and `_adaptation_hooks/`.

**EP-locked decisions** (4 items, EP 2026-05-06 11:00 GMT+8 — see `~/.workbuddy/plans/stellar-vortex-einstein.md` and `docs/06_runtime_profiles/PHASE_4_M8_0_SKILLS_AUDIT.md` §5):

1. Q1 — full absorption (10 NEW after pulling rawdata to GODOT + handle 4 OVERLAP + 3 GODOT).
2. Q2 — OVERLAP fatten by paste-replace body; preserve v4.89 kebab `name`; merge `description` only when v4.89's is shorter (effective scope = 2, not 4: asset-breakdown byte-equal, engine-export already cleaner in v4.89).
3. Q3 — new `_engine_specific/godot/` third axis parallel to `_generic_core/` + `_adaptation_hooks/`; README §1 grows tri-axis row + new §10 namespace contract.
4. Q4 — 5 commits (audit / 9 NEW / 2 fatten / 3 GODOT / docs finale).

**5-commit chain**:

| # | Commit | Theme | Surface |
|--:|---|---|---|
| 1 | `3f4e465` | M8.0.1 audit doc — lessismore-16 vs v4.89-19 mapping, Q1-Q4 lock, subdir map | `docs/06_runtime_profiles/PHASE_4_M8_0_SKILLS_AUDIT.md` (new, +177). 0 SKILL.md change. |
| 2 | `4c07e0e` | M8.0.2 import 9 NEW with kebab frontmatter | 9 SKILL.md across 5 role subdirs + 3 reference files + README §1 update (+745 / -13). |
| 3 | `b30133a` | M8.0.3 fatten 2 OVERLAP (art-concept 25→282L, image-cleanup 28→65L) with lessismore project-residue scrub | 2 SKILL.md (+308 / -13). |
| 4 | `439e20b` | M8.0.4 introduce `_engine_specific/godot/` third-axis namespace | 3 SKILL.md + 11 reference files + README §1 third-axis row + §10 namespace contract (+1257 / -7). |
| 5 | (this commit) | M8.0.5 finale — MATURITY §3.6 + CHANGELOG + parent spec §三 ✅ + README final reconciliation + TAG_NOTE | 4 docs modified + 1 doc added (this commit). |

**Source attribution clarification**: parent spec §三 named `RandomHeroes/skills/` as source. That path does not exist on disk. The actual source is `/Users/macsun/lessismore/skills/` (16 SKILL.md). RandomHeroes's own skill directory `RandomHeroes/.workbuddy/skills/` (15 `rh-*` agent-role files) is a structurally distinct layer (subsystem contracts, already absorbed into v4.89 in Phase 3 Step 1.3-1.4) and is not the same artifact set as lessismore's task-skill SKILL.md. The mother spec is corrected in §九 ChangeLog.

**Skill table relocation** (per audit doc §4 disposition):

| lessismore source | disposition | v4.89 destination |
|---|---|---|
| 9 task-skills (contract_check, task_breakdown, qa_regression, doc_sync, gdd_to_spec, combat_feature_rollout, numeric_id_planning, data_config_layering, gamestring_localization_contract) | NEW import | `_generic_core/{engineering, orchestrator, qa, game-design, numeric, content-design}/<kebab>/SKILL.md` |
| art-concept-from-design-brief | OVERLAP fatten | `_generic_core/art/art-concept-from-design-brief/SKILL.md` (25→282L; 5 lessismore-only vocabulary tokens scrubbed: 爆衣 / 限界共鸣 / 七宗罪 / S0/S1/S2 named states) |
| image-cleanup-pipeline | OVERLAP fatten | `_generic_core/art/image-cleanup-pipeline/SKILL.md` (28→65L; 1 path adjustment `tools/art/cleanup_images.py` → `scripts/cleanup_images.py`) |
| asset-breakdown-for-engine | OVERLAP skip | byte-equal with existing 24L; no action |
| engine-export-packaging | OVERLAP skip | v4.89 already cleaner (`scripts/export_packaging.py` no Godot residue vs lessismore `tools/art/...` + `config/godot_export_rules.json`) |
| godot_2d_responsive_layout | GODOT (third-axis) | `_engine_specific/godot/godot-2d-responsive-layout/SKILL.md` + 4 references (lessismore_battle_case.md dropped) |
| godot_2d_responsive_layout_general | GODOT (third-axis) | `_engine_specific/godot/godot-2d-responsive-layout-general/SKILL.md` + 7 references |
| rawdata_pipeline_check | GODOT (third-axis) | `_engine_specific/godot/rawdata-pipeline-check/SKILL.md` (snake → kebab) |

**Net SKILL.md scale change**:

| Layer | Pre-M8.0 | Post-M8.0 | Delta |
|---|---:|---:|---:|
| `_generic_core/` SKILL.md | 19 | 28 | +9 NEW |
| `_generic_core/` contract/ops files | 15 | 15 | 0 |
| `_adaptation_hooks/` | 12 | 12 | 0 |
| `_engine_specific/godot/` SKILL.md | 0 | 3 | +3 (new axis) |
| `_engine_specific/godot/` references | 0 | 11 | +11 |

**Files modified**:

| Path | Action |
|---|---|
| `skills/_generic_core/{engineering, orchestrator, qa, game-design, numeric, content-design}/<9 dirs>/SKILL.md` | new (C2) |
| `skills/_generic_core/numeric/numeric-id-planning/references/id_segmentation_patterns.md` | new (C2) |
| `skills/_generic_core/numeric/data-config-layering/references/layering_patterns.md` | new (C2) |
| `skills/_generic_core/content-design/gamestring-localization-contract/references/gamestring_patterns.md` | new (C2) |
| `skills/_generic_core/art/art-concept-from-design-brief/SKILL.md` | rewrite (C3) |
| `skills/_generic_core/art/image-cleanup-pipeline/SKILL.md` | rewrite (C3) |
| `skills/_engine_specific/godot/<3 dirs>/SKILL.md` + references | new (C4) |
| `skills/README.md` | three updates (C2 §1, C4 §1 + new §10, C5 final reconciliation) |
| `docs/06_runtime_profiles/PHASE_4_M8_0_SKILLS_AUDIT.md` | new (C1) |
| `docs/06_runtime_profiles/TAG_NOTE_v4.89-phase-4-skills.md` | new (C5) |
| `runtime/MATURITY_MATRIX.md` §3.6 | new (this commit, C5) |
| `CHANGELOG.md` §[v4.89 Phase 4 Step 2] | new (C5) |
| `V4_89_PHASE_4_PLAN.md` §三 + §九 ChangeLog | M8.0 ✅ + 5-commit SHA chain + source attribution correction (C5) |

**Maturity moves**: skills/ is content rather than runtime; no script in `runtime/` or `scripts/` changed shape. The maturity matrix sees no MANUAL → PRODUCTION transitions on M8.0. Net effect is content depth only.

**Phase 4 Step 2 outcome**:
- v4.89 generic-core SKILL.md depth +9 across 5 previously-thin role subdirs (engineering, orchestrator, qa, game-design, numeric, content-design now have task-skill files alongside their three-artifact contracts).
- 2 art OVERLAP stubs fattened with cross-project-portable bodies (lessismore project vocabulary scrubbed).
- New `_engine_specific/<engine>/` axis ratified in README §10 with placement decision rules and "adding a new engine" recipe (Unity / Unreal can follow the same pattern).
- pytest 192 passed across all 5 commits (no test depends on skills/ layout — pre-flight verified).
- v4.88_Release `58346b3` last-touch unchanged across all 5 commits (skills/ is outside runtime mirror set).

**Phase 4 Step 3-4 (deferred to next thread)**:
- M9.0 Sprint-window cold-start (now relevant — 28+3 = 31 SKILL.md plus 12 hooks plus 15 contract/ops files exceeds the cold-start threshold called out in parent spec §四).
- M10.0 v4.89 Release freeze.

## 3.7 v4.89 Phase 4 Step 3 — M9.0 Sprint+Agent Cold-start Governance (2026-05-06 → 2026-05-07)

**Thesis (re-aligned)**: Phase 1 audit on the candidate source `/Users/macsun/lessismore/startup_context_optimization_draft/` rejected the parent spec §四 premise ("31 SKILL.md cold-start is too costly") — the lessismore three-piece-set governs **sprint context** (task / blocker / handoff / archive rollups) and **agent boot**, not SKILL.md. M9.0 was redirected to **route β**: backport the lessismore live cold-start pack (749 LoC) plus the draft three-piece-set (rollup 316 + manifest 85 + promotion guide 132) into v4.89 OS as a v4.89-native blind rewrite, scrubbed of project lexicon. SKILL.md governance remains M8.0 final.

**Branch**: `revise/phase-1-fork` (continuing M8.0 line).
**Base**: M8.0 chain finale `66c8024` + memory `ec25d58` + tag `v4.89-phase-4-skills`.

**EP-locked decisions** (Q1-Q6, EP 2026-05-06 14:55 → 15:08 GMT+8 — see `~/.workbuddy/plans/electric-thunder-turing.md`):

| # | Question | Lock |
|---|---|---|
| Q1 | Scope | **B = sprint context only** (skill governance untouched) |
| Q2 | Cold-start ingest | **B = draft three-piece-set + live cold-start pack** |
| Q3 | Artifact treatment | **A = backport registry instances, scrub project lexicon** |
| Q4 | Profile adaptation | **A = each of v4.89's 6 profiles declares sprint_cold_start** |
| Q5 | 749-LoC live source | **B = blind rewrite (v4.89-native)** |
| Q6 | Init hook | **B = init writes sprint_window_state, separate code path from M7.3 contract surface** |

**8-commit chain**:

| # | Commit | Theme | Surface |
|--:|---|---|---|
| 1 | `94680c3` | M9.0.1 audit doc | `docs/06_runtime_profiles/PHASE_4_M9_0_COLDSTART_AUDIT.md` (new, +193). 0 source code change. |
| 2 | `f11bd74` | M9.0.2 registry skeleton | 5 registry JSON + README + task_id_pattern.json + sprint_board template + orchestrator_log + 2 .gitkeep (+363). 0 project lexicon. |
| 3 | `0b7d115` | M9.0.3 manifest + 6 profile sprint_cold_start | `runtime/config/context_profiles_manifest.json` (3 profiles) + sprint_cold_start block injected into 6 profile JSON (+112 / −3). |
| 4 | `bf616dc` | M9.0.4 rollup + boot wrapper | `tools/runtime/_runtime_common.py` (248 LoC) + `generate_sprint_context_rollup.py` (403) + `boot_agent_thread.py` (138). Total 789 LoC. |
| 5 | `5e99daa` | M9.0.5 cold-start pack rewrite | `tools/runtime/generate_cold_start_pack.py` (459 LoC) + 11-file fixture under `tests/fixtures/sprint_window/` (+711). |
| 6 | `fc8b71a` | M9.0.6 init writes sprint_window_state (Q6=B) | `scripts/init_runtime_env.py` extended; `scripts/mirror_trial_workspace.py` extended; 5 positive + 4 negative trial-workspace mirrors regenerated; baseline state hand-edited; +11 init contract tests (+292 / −13). |
| 7 | `a2c201c` | M9.0.7 pytest coverage | 3 test files (rollup 9 / pack 23 / boot 16) + conftest sys.path extension (+688). |
| 8 | (this) | M9.0.8 docs close | MATURITY §3.7 (this section) + CHANGELOG block + parent spec §四 ✅ + TAG_NOTE. |

**Pytest journey**: 192 → 251 (+59 across the 8-commit chain).
- M9.0.1 → M9.0.5: 192 unchanged (no test added).
- M9.0.6: 192 → 203 (+11 init contract tests covering sprint_window_state writes for all 6 profiles + override / fallback / boundary cases).
- M9.0.7: 203 → 251 (+48 cold-start tooling tests across rollup parser, pack heuristics, boot CLI, full subprocess chain).

**Risk and forbidden zone observance**:
- R1 (M9.0.6 mirror regen): 9 mirror trees regenerated with `--force`; idempotency-based mirror tests (40) all green; R1 16-row regression matrix verdicts unchanged because `sprint_window_state` does NOT join `_CONTRACT_SURFACE_FIELDS` (Q6=B nuance — cross-check coverage deferred to M9.1, plan §6 R4).
- R2 (Q5=B blind rewrite, ~25 hardcoded items dropped): final scrub `grep -rniE 'lessismore|RandomHeroes|Card.Roguelike|爆衣|限界共鸣|gourd|relic|战斗|卡牌|combat_vertical|world_exploration|big_map'` returns 0 matches across `tools/runtime/`, `tests/fixtures/sprint_window/`, `runtime/registries/`, `runtime/config/`, `tasks/`, `logs/`, modified profile JSON, modified test files. `SP-\d+` hardcoded patterns: 0 in `tools/runtime/` + `tests/fixtures/sprint_window/`.
- R3 (over-engineering): registry payloads ship empty; first project to adopt seeds its own data. Adoption workflow documented in `runtime/registries/README.md` §6.
- Forbidden zones: 11 permanent contracts untouched; v4.88_Release byte-lock `58346b3` unchanged across all 8 commits; Stage 2 charter §5.2 untouched; M8.0 skills/ tree untouched (read-only); M7.3 contract surface logic extended (`sprint_window_state` added) but cross-check scope preserved.

**Highlights / cross-cutting outcomes**:
- v4.89 OS now ships a complete sprint+agent cold-start governance baseline: registries (`runtime/registries/`), manifest (`runtime/config/context_profiles_manifest.json`), tooling (`tools/runtime/`), per-profile declarations (`config/profiles/*.json::sprint_cold_start`), runtime state field (`sprint_window_state`), and 48 tests.
- Generic regex contract: task / issue / sprint id patterns live in `runtime/config/task_id_pattern.json`. No project-specific regex anywhere in v4.89 source.
- 3 cold-start profiles (SPRINT_GOVERNED default / SPRINT_DEEP / ARCHIVE_LOOKUP) honoured by both `boot_agent_thread.py` and `generate_cold_start_pack.py`; load_width_policy and context_files differ across profiles.
- Full subprocess chain validated: `boot_agent_thread → generate_cold_start_pack → 16-key cold_start_pack.v1 JSON` end-to-end on the M9.0.5 fixture, with the 4 boot decorator keys (`boot_mode / boot_source / cold_start_performed / profile`) injected by the wrapper.

**Phase 4 Step 4 (deferred to next thread)**:
- M10.0 v4.89 Release freeze: `cp -r AI_Game_Dev_OS_v4.89/ AI_Game_Dev_OS_v4.89_Release/`, RELEASE_NOTES, shasum lock, tag `v4.89-release-rc1`.

## 3.8 v4.89 Phase 4 Step 3.5 — M9.5 Cross-Project LTM Layer A (2026-05-07)

| Milestone | Commit | Pytest | Byte-lock |
|---|---|---:|---|
| M9.5.1 consult() + CLI project_id filter | `d706049` | 251 (unchanged) | ✅ 539/539 |
| M9.5.2 capture() + Gate rule 5 project_id requirement | `2bcc4f3` | 251 (unchanged) | ✅ 539/539 |
| M9.5.3 4 synthesized RH corpus entries + namespace docs | `25fc182` | 251 (unchanged) | ✅ 539/539 |
| M9.5.4 8 namespace tests + MATURITY §3.8 + CHANGELOG + audit + TAG_NOTE | (this commit) | **251 → 259** | ✅ 539/539 |

**Scope**: Layer A = namespace + cross-ingest skeleton. Explicitly NOT in scope: vector retrieval, self-evolution, embedding dependencies, multi-project merge. (See `docs/06_runtime_profiles/PHASE_4_M9_5_CROSS_LTM_AUDIT.md` for the Layer A/B/C decision tree and why Layers B/C are deferred to v4.90.)

**Schema change**:
- `project_id` (optional, snake_case string) added to the YAML front-matter of any LTM entry. Present in the 4 new RH seed entries; absent on the 19 legacy entries (which remain unscoped / global-visible).
- No migration required — "missing ≡ global" semantic means every pre-M9.5 entry stays reachable under any project filter.

**API change**:
- `consult(query, *, domain=None, limit=10, project_id=None)` — when `project_id` is set, entries tagged with a *different* project are excluded; untagged entries remain.
- `capture(domain, title, content, *, evidence_ref=None, actor="...", requires_approval=False, project_id=None)` — Gate rule 5 (new): `domain='project'` without `project_id` routes to `_quarantine/`. When writing succeeds, entries land under `ltm/project/<project_id>/` (per-project directory partition).
- CLI: `python -m runtime.ltm "query" --project <id>` — no `choices=` enforcement, so any future project_id works without a code change.

**Corpus additions**:
- `ltm/project/rh/2026-05-07_sprint_close_handoff_pattern.md` (pattern archetype — six-slot handoff structure)
- `ltm/project/rh/2026-05-07_writeback_owner_drift.md` (helper-scope failure archetype)
- `ltm/project/rh/2026-05-07_profile_switch_audit_gap.md` (two-layer silent-PASS failure; cross-links to M7.3 lift gate)
- `ltm/project/rh/2026-05-07_mirror_trial_workspace_cold_start.md` (cache-staleness failure; cross-links to M9.0 cold-start pack)
- `ltm/project/rh/README.md` (scoped to rh via front-matter)

**Tests** (`tests/test_ltm_namespace.py`, 8 cases):
- Filter inclusion (rh-tagged + unscoped both visible under `--project rh`).
- Filter exclusion (foo-tagged entries hidden under `--project rh`).
- Missing project_id stays global across every filter value.
- CLI `--project` exits 0.
- Gate rule 5 quarantines project-domain captures without project_id.
- Capture writes project_id into front-matter + routes to per-project dir.
- Real-corpus spot check: `consult("writeback owner drift", project_id="rh")` returns the synthesized RH entry.
- Lexicon scrub guardrail: `ltm/project/rh/*.md` must contain zero forbidden project-specific terms.

**Key invariants preserved**:
- Phase 1's 11 permanent contracts — untouched.
- Stage 1's 14 LTM pytest cases — all still passing (project_id defaults to None in every existing call site).
- v4.88_Release byte-lock (SHA `58346b3`, 539 files) — unchanged across all 4 commits.
- 5-profile parity cross-check tests — unaffected (no profile JSON touched).

**Phase 4 Step 4 (next thread)**: M10.0 v4.89 Release freeze — unchanged from §3.7's deferral note, M9.5 slots cleanly in front of it.

## 3.9 v4.89 Phase 4 Step 4 — M10.0 v4.89 Release freeze (2026-05-07)

| Milestone | Commit | Pytest | Byte-lock |
|---|---|---:|---|
| M10.0.1 cp v4.89 → v4.89_Release baseline | `3bf6df2` | 259 (unchanged, both trees) | ✅ v4.88 539/539 |
| M10.0.2-5 4-dimension Review (file existence / API correctness / cross-refs / pytest+byte-lock) | (review-only, no commits) | — | — |
| M10.0.6 3 Review findings reflowed + Release pytest.ini | `5200891` | 259 (both trees) | ✅ v4.88 539/539 |
| M10.0.7 RELEASE_NOTES.md | `8ec7342` | 259 (both trees) | ✅ v4.88 539/539 |
| M10.0.8 + M10.0.9 CHECKSUMS.sha + TAG_NOTE + §3.9 + CHANGELOG | (this commit) | 259 (both trees) | ✅ v4.88 539/539 + v4.89_Release 754/754 |

**Review outcome**: 3 doc drifts (ASSEMBLY_GUIDE.md broken `docs/GOVERNANCE_MAP.md` ref; `ltm/INDEX.md` capture signature missing `actor` + `requires_approval`; `ltm/INDEX.md` Life cycle not reflecting M9.5 Layer A ship state) + 1 Release-tree hygiene gap (missing `pytest.ini` caused `cd Release/ && pytest` to climb to workspace pytest.ini). The 3 doc drifts existed in BOTH `AI_Game_Dev_OS_v4.89/` and the fresh `AI_Game_Dev_OS_v4.89_Release/` cp, so per EP's reflow constraint they were fixed in v4.89/ first and cp'd to Release. The Release-only `pytest.ini` was added directly to Release.

**Release tree invariants at tag time**:
- 754 files locked in `CHECKSUMS.sha` (0 FAILED on self-check).
- v4.88_Release byte-lock SHA `58346b3` — **still unchanged** across the entire M10.0 chain.
- `AI_Game_Dev_OS_v4.89/` (dev tree) and `AI_Game_Dev_OS_v4.89_Release/` (release tree) are byte-identical EXCEPT for 4 Release-only artifacts: `pytest.ini` / `RELEASE_NOTES.md` / `CHECKSUMS.sha` / `docs/06_runtime_profiles/TAG_NOTE_v4.89-release-rc1.md`.
- v4.89/ stays frozen at the M10.0.6 state as the historical dev-line reference. Future v4.90 work branches from this tree.

**EP manual action pending**: tag `v4.89-release-rc1` — see `AI_Game_Dev_OS_v4.89_Release/docs/06_runtime_profiles/TAG_NOTE_v4.89-release-rc1.md` for the exact command and verification recipe.

**Phase 4 CLOSED**. v4.90 scope will branch from this tag (not in this plan).

## 3.10 v4.89 Phase 4 M10.0.x rc1 → rc2 reflow (2026-05-08)

| Milestone | Commit | Pytest | Byte-lock + Verification |
|---|---|---:|---|
| rc2.1 rename + rewrite Overview + Master_Outline (dev + release) | `580a1c7` | 259 (both trees) | ✅ v4.88 539/539 |
| rc2.2 update 7 reference points (10 files / 14 LoC) | `e1a0595` | 259 (both trees) | ✅ v4.88 539/539 |
| rc2.3 rewrite RELEASE_NOTES L176 + review_pack_consistency self-check | `8f411d7` | 259 (both trees) | ✅ v4.88 539/539 |
| rc2.4 regenerate CHECKSUMS.sha (755 lines, --check 755/755 OK) — placement turned out wrong, fixed in rc2.6 | `8afc286` | 259 (both trees) | ✅ v4.88 539/539 + v4.89_Release 755/755 (transient) |
| rc2.5 RELEASE_NOTES + CHANGELOG + TAG_NOTE_rc2 + MATURITY §3.10 + PHASE_4_PLAN §五 | `106c581` | 259 (both trees) | ✅ v4.88 539/539 (CHECKSUMS stale 752/3) |
| rc2.6 regenerate CHECKSUMS.sha post rc2.5 (756/756 OK) — fixup for rc2.4 placement error | `1e48127` | 259 (both trees) | ✅ v4.88 539/539 + v4.89_Release 756/756 |
| rc2.7 post-RC2 consistency audit — MANIFEST 2-entry sha sync + RELEASE_NOTES §7 add Master_Outline + CHECKSUMS regen 3 | `bd7b2dc` | 259 (both trees) | ✅ v4.88 539/539 + v4.89_Release 756/756 |
| **rc2.8 regenerate RELEASE_MANIFEST.files[] as v4.89 current snapshot (dev 201→723 / release 201→727) + CHECKSUMS regen 4** | **`5d9db1d`** | **259 (both trees)** | **✅ v4.88 539/539 + v4.89_Release 756/756 + MANIFEST dev 723/0/0/0 + release 727/0/0/0** |

**Trigger**: rc1 (M10.0.10, `d006eef`) retained `docs/00_entry/AI_Game_Dev_OS_v4.88_{Overview,Master_Outline}.md` as "verbatim historical reference". The decision was correct in pure architecture-reference language but conflicted with their position as **Run path step #1** in `START_HERE.md` (the package's onboarding entry). Onboarding cost > historical preservation benefit once RH starts real v4.89 adoption (Task #2 of 2026-05-08).

**Reflow scope (final, after 8-commit chain)**:
- 4 files renamed (dev tree 2 + release tree 2): `v4.88_Overview.md` → `v4.89_Overview.md`; `v4.88_Master_Outline.md` → `v4.89_Master_Outline.md`.
- 4 files rewritten to v4.89 viewpoint (Overview 92 lines / Master_Outline 210 lines).
- 7 reference points updated × 2 trees = 14 LoC: START_HERE L19 / cursor CONTEXT_LOADING L13 / RELEASE_MANIFEST L12+L145+L150 / REQUIRED_CONTENT_CHECKLIST L12 / review_pack_consistency.py L7.
- 1 RELEASE_NOTES.md L176 rewrite (release-only) + §0 RC2 narrative block (release-only) + §7 Reading order add Master_Outline (release-only).
- CHECKSUMS.sha regenerated 4 times across the chain (final 756/756 OK).
- RELEASE_MANIFEST.files[] full regen in rc2.8 (dev 201→723, release 201→727; closes v4.88 RC12 baseline drift inherited through Phase 1-4).
- 5 narrative docs landed: RELEASE_NOTES §0 / CHANGELOG rc2 entry / TAG_NOTE_v4.89-release-rc2.md (release-only) / this MATURITY §3.10 / V4_89_PHASE_4_PLAN §五 RC2 row.

**What is preserved**:
- `AI_Game_Dev_OS_v4.88_Release/` byte-lock SHA `58346b3` (539 files) — unchanged across the entire rc2 chain. Original v4.88 entry docs remain there as canonical historical archive.
- `RELEASE_MANIFEST.json` L3 `base_from` field — preserved as v4.88 RC12 origin trace.
- 1 lineage narrative paragraph in `AI_Game_Dev_OS_v4.89_Master_Outline.md §9` — describes v4.88_Release/ archive, NOT a file reference.
- rc1 tag `v4.89-release-rc1` — kept as historical archive (rc2 is additive).
- 11 permanent contracts / LTM Layer A / 5-profile parity / Phase 1-4 chain — untouched.

**Release tree invariants at rc2.8 tag time** (anchor `5d9db1d`):
- **756 files locked in `CHECKSUMS.sha`** (0 FAILED on self-check).
- **Dev/release byte-equivalent except 5 release-only divergence points** (was 4 pre-rc2; new since rc2.8 = `RELEASE_MANIFEST.json` because each tree's MANIFEST self-describes its own state with different file_count: dev 723 vs release 727): `pytest.ini` / `RELEASE_NOTES.md` / `CHECKSUMS.sha` / `TAG_NOTE_v4.89-release-rc{1,2}.md` / `RELEASE_MANIFEST.json`.
- **MANIFEST self-consistency**: both trees 0 missing on disk / 0 bytes_mismatch / 0 sha_mismatch.

**Plan template lessons captured (3)**:
1. CHECKSUMS regen must be the chain finale; placing it before docs commits guarantees stale (rc2.4 → rc2.6 fixup).
2. Renaming files in `MANIFEST.files[]` requires refreshing `bytes` and `sha256` in the same commit; path-only updates leave hybrid stale state (rc2.7 finding).
3. When entry docs are renamed, full `MANIFEST.files[]` regen is cheaper and safer than partial updates, and also catches accumulated drift from prior baselines (rc2.8 finding: v4.88 RC12 baseline drift survived through Phase 1-4).

**EP manual action pending**: tag `v4.89-release-rc2` anchor `5d9db1d` — see `AI_Game_Dev_OS_v4.89_Release/docs/06_runtime_profiles/TAG_NOTE_v4.89-release-rc2.md`.

## 3.11 v4.89 Phase 4 M10.0.x rc2 → rc3 identity consistency overhaul (2026-05-08)

| Milestone | Commit | Pytest | Byte-lock + Verification |
|---|---|---:|---|
| rc3.1 Phase A — onboarding entry区 (5 docs × 2 trees = 10 files / +32 / -30) | `0b0eb5f` | 259 (both trees) | ✅ v4.88 539/539 |
| rc3.2 Phase B step 1 — USER_GUIDE.md rewrite (2 files / +202 / -100) | `fbb7582` | 259 (both trees) | ✅ v4.88 539/539 |
| rc3.3 Phase B step 2 — USAGE_GUIDE + PHASE_4_TRIAL_GUIDE + V4.89_BACKLOG (6 files / +238 / -156) | `c27b1c8` | 259 (both trees) | ✅ v4.88 539/539 |
| rc3.4 Phase C — governance + architecture + runtime_core + integrations + observability (36 files / +80 / -80) | `113a9e1` | 259 (both trees) | ✅ v4.88 539/539 |
| rc3.5 Phase D — runtime_profiles + starters + beta_sprint (38 files / +52 / -52) | `33e767f` | 259 (both trees) | ✅ v4.88 539/539 |
| **rc3.6 Phase E1 — `.core_os_root` marker + `CURRENT_MAJOR_MINOR` bootstrap-critical fix** (6 files / +14 / -12) | `d90f289` | 259 (both trees) | ✅ v4.88 539/539 + check_core_os_root self-verify PASS / stale=false on both trees |
| rc3.7 Phase E2-E4 — schema + Python + templates + mock (92 files / +114 / -114) | `76a5c29` | 259 (both trees) | ✅ v4.88 539/539 + 11 schema `v4.89_first_tier` validated (no code consumes field) |
| rc3.8 Phase F narrative — RELEASE_NOTES + CHANGELOG + this MATURITY §3.11 + TAG_NOTE_rc3 + V4_89_PHASE_4_PLAN §五 RC3 row | `<this commit>` | 259 (both trees) | ✅ v4.88 539/539 |
| rc3.9 Phase F final regen — RELEASE_MANIFEST.files[] + CHECKSUMS.sha (final state; see CHECKSUMS.sha for current count) | `<next commit>` | 259 (both trees) | ✅ v4.88 539/539 + see CHECKSUMS.sha for current 756-758 OK / 0 FAILED |

**Trigger**: post-rc2 audit (EP-requested 10-dimension consistency check) found 482 `v4.88` string hits across 145 files in `AI_Game_Dev_OS_v4.89_Release/`. After classifying out historical lineage / archive paths / code-coupled strings, ~80 hits were the package self-identifying as v4.88 (e.g. START_HERE "v4.88 release-candidate line", USER_GUIDE "v4.88-stable", schema `"version": "v4.88_first_tier"`, `.core_os_root: v4.88-marker`, `CURRENT_MAJOR_MINOR = "v4.88"`). RC2 had narrowed scope to file references only and missed the version-identity layer.

**Reflow scope (final, after 9-commit chain)**:
- Phase A onboarding entry区: 5 docs (START_HERE / CORE_OS_DIGEST / DOCUMENT_PRIORITY_MAP / EXECUTION_PROFILE_SELECTION / EXECUTION_PROFILE_QUICKSTART)
- Phase B large identity docs: 4 docs (USER_GUIDE / docs/USAGE_GUIDE / docs/PHASE_4_TRIAL_GUIDE / docs/V4.89_BACKLOG)
- Phase C 5 mid-layer doc subdirs: 18 docs (01_architecture × 2 / 02_governance × 7 / 03_runtime_core × 2 / 04_integrations × 3 / 05_observability × 3 / 05_architecture_linter × 1)
- Phase D profile + starters + beta: 19 docs (06_runtime_profiles × 10 + 07_starters × 8 + 09_beta_sprint × 3 minus 2 SKIPPED for archive scope)
- Phase E1 bootstrap-critical: 3 files (.core_os_root marker + check_core_os_root.py + Root_Discovery_Spec.md)
- Phase E2-E4 schema + code + templates + mock: 46 files (11 schema JSON / 12 Python / 9 starter templates / 11 mock files including 10 trial_workspaces run_sprint.py)
- Phase F narrative: 5 docs (RELEASE_NOTES + CHANGELOG + this MATURITY §3.11 + new TAG_NOTE_rc3 + V4_89_PHASE_4_PLAN §五)

**What is preserved (lineage / historical / code-coupled / archive paths)**:
- `AI_Game_Dev_OS_v4.88_Release/` byte-lock (SHA `58346b3`, 539 files) — unchanged across the entire rc3 chain. Verified at every commit via `git log --oneline -1 -- 'AI_Game_Dev_OS_v4.88_Release/'`.
- `RELEASE_MANIFEST.json` L3 `base_from` field — preserved as v4.88 RC12 origin trace.
- `v4.88-release-{scaffold,bplus,stable}` historical tag references in code comments and docs — KEPT.
- `v4.88 RC12` / `v4.88_Revise` lineage citations throughout — KEPT (historical phase narrative).
- `v4.88 Phase 2 Step 3` / `v4.88 Phase 4` historical phase references — KEPT.
- `v4.89-trial-upgrade` upgrade_tag string (code-coupled with `verify_beta_sprint_exit.py` L919) — KEPT for audit-consumer backwards-compat.
- `allowlist_reason: 'v4.88_scaffold'` allowlist key string in `rule_c_file_scale_constraints.py` L128 — KEPT (code-coupled).
- All `v4.88_Release/` literal path strings in code (e.g. `tools/runtime/generate_cold_start_pack.py` L297 byte-lock warning) — KEPT.
- `.workbuddy/reviews/v4.88_release/` archive directory name — KEPT (historical reviews archive).
- Mock baseline data describing v4.88-stable era (S5b runtime_state.json) — KEPT as historical mock evidence.
- 11 permanent contracts / LTM Layer A / 5-profile parity / Phase 1-4 chain — untouched.
- rc1 + rc2 tags kept as historical archives; rc3 is additive.

**Release tree invariants at rc3 tag time** (anchor = rc3.9 commit):
- Final CHECKSUMS / MANIFEST file count: see `CHECKSUMS.sha` for current state.
- Dev/release byte-equivalent except 6 release-only divergence points: `pytest.ini` / `RELEASE_NOTES.md` / `CHECKSUMS.sha` / `TAG_NOTE_v4.89-release-rc{1,2,3}.md` (3) / `RELEASE_MANIFEST.json`.
- MANIFEST self-consistency on both trees (verified by rc3.9): 0 missing / 0 bytes_mismatch / 0 sha_mismatch.

**Plan template lessons captured (4 cumulative)**:
1. CHECKSUMS regen MUST be the chain finale (RC2 lesson; RC3 follows).
2. Renaming files in `MANIFEST.files[]` requires refreshing `bytes` and `sha256` in the same commit (RC2 lesson; RC3 uses full regen instead).
3. When entry docs are renamed, full `MANIFEST.files[]` regen is cheaper and safer than partial updates (RC2 lesson; RC3 follows in rc3.9).
4. **Narratives that quote final state numbers must be the absolute last commit before tag cut.** RC2 burnt one extra cycle (rc2.5 → rc2.9) re-quoting numbers after each fixup. RC3 mitigates by writing this MATURITY §3.11 + RELEASE_NOTES §0.0 + CHANGELOG entry without final numbers, deferring to "see CHECKSUMS.sha for current count" / "see MANIFEST.json for current verification" — only rc3.9 actually regenerates the manifests, after which the final state is already pinned by the tag.

**EP manual action pending**: tag `v4.89-release-rc3` anchor = rc3.9 commit (chain finale) — see `AI_Game_Dev_OS_v4.89_Release/docs/06_runtime_profiles/TAG_NOTE_v4.89-release-rc3.md`.

## 4. How to Update This Matrix

When a script is expanded past a size / behavior threshold, update its row here in the same commit that changes the script. Reviewers use this matrix to prioritize audit effort, so drift between script actual state and matrix label is a documented regression.
