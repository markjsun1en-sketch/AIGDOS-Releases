"""Read-after-write verification skeleton for TAPD sync."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class VerificationReport:
    ok: bool
    mismatches: List[str] = field(default_factory=list)
    observed: Dict = field(default_factory=dict)


def verify_expected_fields(expected: Dict, observed: Dict, keys: List[str]) -> VerificationReport:
    mismatches: List[str] = []
    for key in keys:
        if expected.get(key) != observed.get(key):
            mismatches.append(
                f"Field mismatch for '{key}': expected={expected.get(key)!r}, observed={observed.get(key)!r}"
            )
    return VerificationReport(ok=not mismatches, mismatches=mismatches, observed=observed)
