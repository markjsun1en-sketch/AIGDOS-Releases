"""Parent-child aggregation helpers for TAPD close / rollout flows."""
from __future__ import annotations

from typing import Iterable, Mapping


def should_resolve_parent(child_states: Iterable[str], *, done_states=None) -> bool:
    done_states = set(done_states or {"resolved", "done", "closed"})
    normalized = [state for state in child_states if state is not None]
    return bool(normalized) and all(state in done_states for state in normalized)


def summarize_child_completion(children: Iterable[Mapping[str, str]]) -> dict:
    children = list(children)
    done = sum(1 for child in children if child.get("status") in {"resolved", "done", "closed"})
    return {
        "total": len(children),
        "done": done,
        "all_done": len(children) > 0 and done == len(children),
    }
