"""Validate TAPD status / priority mapping before external writeback."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class ValidationResult:
    ok: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    suggested_mapping: Optional[Dict[str, str]] = None


def validate_mapping(
    *,
    object_type: str,
    internal_state: str,
    mapped_state: str,
    config: Dict,
    mapped_priority: Optional[str] = None,
) -> ValidationResult:
    errors: List[str] = []
    warnings: List[str] = []

    valid_statuses = config.get("tapd_valid_statuses", {})
    object_statuses = valid_statuses.get(object_type)
    if not object_statuses:
        errors.append(f"Unknown object type or missing valid statuses: {object_type}")
    elif mapped_state not in object_statuses:
        errors.append(
            f"Mapped state '{mapped_state}' is not valid for object type '{object_type}'."
        )

    if mapped_priority is not None:
        valid_priorities = config.get("tapd_valid_priorities", {})
        if object_type == "bug":
            allowed = valid_priorities.get("bug", [])
        else:
            allowed = valid_priorities.get("story_and_task", [])
        if mapped_priority not in allowed:
            errors.append(
                f"Mapped priority '{mapped_priority}' is not valid for object type '{object_type}'."
            )

    if internal_state == "archived" and mapped_state not in {"resolved", "done", "closed"}:
        warnings.append("Archived internal state maps to a non-terminal TAPD state.")

    return ValidationResult(
        ok=not errors,
        errors=errors,
        warnings=warnings,
        suggested_mapping=None,
    )
