"""Portable TAPD sync executor skeleton.

This module intentionally leaves API transport to environment/project-specific code.
It focuses on sequencing: validate -> write -> verify -> audit.
"""
from __future__ import annotations

from typing import Callable, Dict

from .status_mapping_validator import validate_mapping
from .read_after_write_verifier import verify_expected_fields


def sync_object(
    *,
    object_type: str,
    internal_state: str,
    mapped_state: str,
    config: Dict,
    payload: Dict,
    write_fn: Callable[[Dict], Dict],
    read_fn: Callable[[Dict], Dict],
    verify_keys=None,
) -> Dict:
    report = validate_mapping(
        object_type=object_type,
        internal_state=internal_state,
        mapped_state=mapped_state,
        config=config,
        mapped_priority=payload.get("priority"),
    )
    if not report.ok:
        return {"ok": False, "stage": "validate", "errors": report.errors, "warnings": report.warnings}

    write_result = write_fn(payload)
    read_result = read_fn(payload)
    verify = verify_expected_fields(payload, read_result, verify_keys or ["status"])

    return {
        "ok": verify.ok,
        "stage": "verify",
        "write_result": write_result,
        "observed": verify.observed,
        "mismatches": verify.mismatches,
        "warnings": report.warnings,
    }
