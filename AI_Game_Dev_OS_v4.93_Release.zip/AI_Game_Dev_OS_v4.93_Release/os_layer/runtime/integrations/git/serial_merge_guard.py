"""Serial merge guard skeleton.

This module can later be extended to lock merge windows or validate that only one
merge operation is active at a time.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class MergeGuardState:
    active_merge_id: str | None = None


def can_start_merge(state: MergeGuardState) -> bool:
    return state.active_merge_id is None


def start_merge(state: MergeGuardState, merge_id: str) -> None:
    if state.active_merge_id is not None:
        raise RuntimeError(f"Merge already in progress: {state.active_merge_id}")
    state.active_merge_id = merge_id


def end_merge(state: MergeGuardState) -> None:
    state.active_merge_id = None
