"""Merged branch cleanup skeleton."""
from __future__ import annotations

import subprocess
from typing import Iterable


def delete_merged_branches(branches: Iterable[str]) -> None:
    for branch in branches:
        subprocess.run(["git", "branch", "-d", branch], check=False)
