"""Helpers for detecting risky merge targets."""
from __future__ import annotations

RISKY_PATH_MARKERS = (
    "registry",
    "task_registry",
    "handoff",
    "runtime_state",
    "sync",
)


def is_state_bearing_path(path: str) -> bool:
    lowered = path.lower()
    return any(marker in lowered for marker in RISKY_PATH_MARKERS)
