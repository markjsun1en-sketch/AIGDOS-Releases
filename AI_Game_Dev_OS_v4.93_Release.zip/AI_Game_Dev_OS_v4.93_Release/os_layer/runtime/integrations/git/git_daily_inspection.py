"""Daily inspection skeleton for Git agent workflows."""
from __future__ import annotations

import subprocess
from typing import Dict, List


def _run(cmd: List[str]) -> str:
    return subprocess.run(cmd, check=False, capture_output=True, text=True).stdout.strip()


def inspect_git_state() -> Dict[str, object]:
    branches = _run(["git", "branch", "--format=%(refname:short)"]).splitlines()
    status = _run(["git", "status", "--short"])
    head = _run(["git", "rev-parse", "--short", "HEAD"])
    return {
        "head": head,
        "branch_count": len([b for b in branches if b]),
        "branches": branches,
        "worktree_status": status.splitlines() if status else [],
    }
