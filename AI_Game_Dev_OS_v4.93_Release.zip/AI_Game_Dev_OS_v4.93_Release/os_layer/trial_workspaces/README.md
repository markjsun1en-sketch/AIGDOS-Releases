# trial_workspaces/ — Test Fixtures (Not User Content)

> **Audience: Release-package consumers** — this directory is **part of
> the v4.89 test suite's fixture set**, not shipped user content. **You
> do not need to enter, edit, copy, or run anything here as part of
> normal v4.89 usage.** A typical user can ignore this directory entirely.
>
> **Audience: Internal contributors / test maintainers** — see the
> sections below for the M6.8 regression reproducibility contract that
> these mirrors enforce.

## What this is, what this is NOT

| | trial_workspaces/ | examples/_mock_baselines/ |
|---|---|---|
| Purpose | Test fixture for unit tests + M6.8 contract assertion | Smoke harness scenarios |
| Audience | Test maintainers | Anyone running the smoke suite |
| Stability contract | mirror_trial_workspace.py output must hash-match these committed trees | scenarios listed in `scripts/run_mock_smoke.sh` |
| User-facing? | **No** | Yes (smoke harness) |

This directory is **not "trial evidence" in the artefact sense** — see
`.workbuddy/reviews/v4.88_release/REAL_TRIAL_REPORT_V1.md` (outside the
Release package) for the actual evidence trail. The trees committed
here exist because:

1. `tests/test_mirror_trial_workspace.py` enforces the M6.8 regression
   reproducibility contract: ``mirror_trial_workspace.py``'s output for
   each profile must be byte-for-byte identical to the committed mirror
   in this directory. Without these committed trees the contract test
   has nothing to compare against.
2. `tests/test_beta_sprint_driver.py` /
   `tests/test_schema_driven_equivalence.py` /
   `tests/test_stage_2_regression_r1.py` use the baseline workspace
   (`rh_sprint_sim_01/`) as a deterministic starting state.

Manifest classification (P1-5, 2026-05-09): files under this directory
are tagged ``test_fixtures`` in `RELEASE_MANIFEST.json` so tooling can
distinguish them from required content vs. optional seeds vs. generated
runtime outputs.

## Directory roster (background — only relevant to test maintainers)

This directory承载 B+ Bridge Hardening 完成后的 **real trial** 工作区（非 mock）。
trial 是真实调用 hardened scripts 跑出来的产物 + 可复跑 driver。

## 目录

| workspace | 日期 | verdict | 状态 | report |
|---|---|---|---|---|
| `rh_sprint_sim_01/` | 2026-05-02 | CONDITIONAL (0 err / 2 warn) | frozen | `REAL_TRIAL_REPORT_V1.md` (workspace-external, see below) |

> **Report path note**: `REAL_TRIAL_REPORT_V1.md` lives in the workspace-root
> `.workbuddy/reviews/v4.88_release/` tree (outside this Release package).
> It is intentionally not shipped inside the Release package; reviewers
> operating on an extracted Release tarball will not see it. Internal
> contributors working in the parent repo can access it at
> `<UPSTREAM_REPO_ROOT>/.workbuddy/reviews/v4.88_release/REAL_TRIAL_REPORT_V1.md`
> (where `<UPSTREAM_REPO_ROOT>` is the WorkBuddy-side dev tree, e.g.
> `~/Documents/AI_DEV_OS_Evolve/`).

## rh_sprint_sim_01 — 如何复跑

```bash
cd <RELEASE_ROOT>          # the directory you extracted AI_Game_Dev_OS_v4.89_Release.zip into

# 1. 清 audit + tapd store（保留 fixture: AGENTS.md / profile / checklist）
WS=trial_workspaces/rh_sprint_sim_01
rm -f $WS/runtime/logs/mcp_audit.jsonl $WS/runtime/state/tapd_local_store.json

# 2. init 真跑
python3 scripts/init_runtime_env.py \
  --project-id rh_sprint_sim_01 \
  --runtime-profile workbuddy_private \
  --output-dir $WS \
  --force

# 3. driver emit 21 events via hardened codepaths
python3 $WS/run_sprint.py

# 4. verify_exit
python3 scripts/verify_beta_sprint_exit.py \
  --workspace $WS \
  --audit-log $WS/runtime/logs/mcp_audit.jsonl \
  --runtime-state $WS/runtime_state.json \
  --sprint-close-checklist $WS/docs/09_beta_sprint/sprint_close_checklist.md \
  --sprint sprint-rh-sim-01 \
  --profile workbuddy_private
```

期望输出：`verdict=CONDITIONAL, error_count=0, warn_count=2, exit=0`

## Fixture 来源

- `AGENTS.md` / `docs/07_starters/workbuddy_private/AGENTS.md.template`：
  从 RH 项目 `policy/AGENTS.md` 复制（40985B，故意 > 32KiB 阈值以触发 B+ C.1
  opaque_blob 兜底）
- `config/profiles/workbuddy_private.json`：从 Release 包 config 复制
- `docs/09_beta_sprint/sprint_close_checklist.md`：从 S5b mock scenario 模板复制
- `.workbuddy/README.md` + `.workbuddy/profile`：overlay sentinel（满足 C.5 非空预检）

## 不入库的动态产出

入库 commit 包含最后一次成功 run 的产物作参考。重新跑前请先清：
- `runtime/logs/mcp_audit.jsonl`（每次 init 重写首条）
- `runtime/state/tapd_local_store.json`（每次 driver 重写）
- `runtime_state.json`（每次 init --force 重写）

## 9 条 v4.89 P0 候选（trial 产出）

见 `REAL_TRIAL_REPORT_V1.md §2.3 / §3`。最紧三条：
1. F3/F4：adapter event-envelope 契约统一
2. P1-3 升 P0：CI/测试 baseline 防契约漂移
3. F6：`append_audit(strict=False)` 静默丢事件要改默认
