#!/usr/bin/env python3
"""Real-trial P2 sprint driver — drives hardened v4.89 Release codepaths (preserves the v4.88-stable trial harness)
against a real RH-shaped workspace (not a pre-baked mock).

Pattern:
  workbuddy_collector.append_audit  — every event goes through this
  workbuddy_collector.wrap_external_record  — v4.89 P0-A A4: adapter
      records (tapd _live_path / git merge_apply+cleanup) are wrapped
      into the canonical envelope here, closing the "adapter returns
      normalized shape but audit log requires envelope" gap called out
      as Real Trial v1 findings F3/F4.
  tapd_adapter_stub.write_event/verify_event  — real file-backed store
  git_adapter_stub.merge_apply/merge_cleanup  — stub pair emission

The goal is NOT to generate a pretty audit — it's to observe where hardened
scripts behave correctly, incorrectly, or surprisingly when given real inputs.
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

PKG = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PKG))

from runtime.observability.runtime_event_collectors import workbuddy_collector as wb
from integrations import tapd_adapter_stub as tapd
from integrations import git_adapter_stub as git

WS = Path(__file__).resolve().parent
SPRINT = "sprint-rh-sim-01"
PROFILE = "workbuddy_private"

# Anchor time so ordering is deterministic but audit has real timestamps
BASE = datetime(2026, 5, 2, 6, 0, 0, tzinfo=timezone.utc)


def ts(mins: int) -> str:
    return (BASE + timedelta(minutes=mins)).strftime("%Y-%m-%dT%H:%M:%SZ")


def emit(event: dict, *, strict: bool = False) -> bool:
    """Push an internally-authored runtime event through append_audit.

    Used for records the driver constructs itself (runtime.create /
    transition / validation / handoff / snapshot / archive /
    trial.check). These are not adapter returns, so they do not need
    the wrap_external_record path.
    """
    # Enrich envelope to satisfy collector validation
    event.setdefault("runtime_profile", PROFILE)
    event.setdefault("sprint_id", SPRINT)
    event.setdefault("actor", "main_session")
    event.setdefault("result", event.get("status", "ok"))
    ok = wb.append_audit(str(WS), event, strict=strict)
    return ok


def emit_wrapped(
    record: dict,
    *,
    source_layer: str,
    event_type: str,
    result: str,
    ts_override: str,
    extra: dict | None = None,
    strict: bool = False,
) -> bool:
    """Wrap an adapter-returned record into the canonical audit envelope
    via workbuddy_collector.wrap_external_record, then append it.

    v4.89 P0-A A4: this is the single path for externally-sourced
    records (tapd live write/verify; git merge apply/cleanup). The
    helper stamps event_id / source_layer / audit_status; the driver
    overrides timestamp with ``ts_override`` to keep E4 monotonic
    (W2 remains Phase 2 work; helper writes real UTC-now but driver
    requires a synthetic anchor for deterministic ordering).

    ``extra`` is merged into ``details`` so all existing consumer keys
    (task_id, object_type, verification_ok, branch_from/to, …) stay in
    the audit JSONL at the same nesting depth as the canonical envelope
    (details.*).

    v4.90 Batch 0 Step 2: the deprecated ``top_level=`` bridge (added
    in v4.89 P0-A A4 so flat-shape consumers stayed green during the
    canonical envelope migration) has been **removed**. All read-side
    consumers must now use envelope-aware lookups
    (``verify_beta_sprint_exit._ev_get`` or equivalent) which traverse
    root → details.* → default. Mirroring queryable keys to envelope
    root is no longer supported.
    """
    payload = dict(record)
    if extra:
        payload.update(extra)
    payload.setdefault("sprint_id", SPRINT)
    envelope = wb.wrap_external_record(
        payload,
        source_layer=source_layer,
        runtime_profile=PROFILE,
        actor="main_session",
        event_type=event_type,
        result=result,
    )
    # Deterministic ordering override (W2 deferred to Phase 2).
    envelope["timestamp"] = ts_override
    return wb.append_audit(str(WS), envelope, strict=strict)


def main() -> int:
    # Load tapd config (hardened: returns {"mode":"stub"} when token null)
    config = tapd.load_config(str(WS))
    print(f"[driver] tapd config mode = {config.get('mode', 'live')}")

    # --- Minimal RH-shaped sprint: 2 tasks + 1 handoff + 2 merge pair + close ---
    events = [
        # T1 creation + transition
        {"event_type": "runtime.create", "timestamp": ts(0), "actor": "orchestrator",
         "source_layer": "runtime_registry", "status": "ok",
         "summary": "created RH-SIM-001", "task_id": "RH-SIM-001"},
        {"event_type": "runtime.create", "timestamp": ts(1), "actor": "orchestrator",
         "source_layer": "runtime_registry", "status": "ok",
         "summary": "created RH-SIM-002", "task_id": "RH-SIM-002"},
        {"event_type": "runtime.transition", "timestamp": ts(5), "actor": "engineering",
         "source_layer": "runtime_registry", "status": "ok",
         "summary": "RH-SIM-001 open->in_progress", "task_id": "RH-SIM-001",
         "from_state": "open", "to_state": "in_progress"},
        {"event_type": "runtime.transition", "timestamp": ts(6), "actor": "content_design",
         "source_layer": "runtime_registry", "status": "ok",
         "summary": "RH-SIM-002 open->in_progress", "task_id": "RH-SIM-002",
         "from_state": "open", "to_state": "in_progress"},
        # Handoff content_design -> engineering
        {"event_type": "runtime.handoff", "timestamp": ts(30), "actor": "content_design",
         "source_layer": "runtime_registry", "status": "ok",
         "summary": "handoff content_design->engineering for RH-SIM-002",
         "task_id": "RH-SIM-002", "handoff_target": "engineering"},
        # Validations + transitions — interleaved per task so audit write
        # order is monotonically increasing (v4.89 P0-B Pre-Z1 W2 fix).
        # T1 validation → T1 transition to done.
        {"event_type": "runtime.validation", "timestamp": ts(45), "actor": "qa_playtest",
         "source_layer": "runtime_registry", "status": "ok",
         "summary": "RH-SIM-001 validation passed", "task_id": "RH-SIM-001",
         "validation_result": "pass"},
        {"event_type": "runtime.transition", "timestamp": ts(46), "actor": "orchestrator",
         "source_layer": "runtime_registry", "status": "ok",
         "summary": "RH-SIM-001 validation_pending->done", "task_id": "RH-SIM-001",
         "from_state": "validation_pending", "to_state": "done"},
        # T2 validation → T2 transition to done.
        {"event_type": "runtime.validation", "timestamp": ts(60), "actor": "qa_playtest",
         "source_layer": "runtime_registry", "status": "ok",
         "summary": "RH-SIM-002 validation passed", "task_id": "RH-SIM-002",
         "validation_result": "pass"},
        {"event_type": "runtime.transition", "timestamp": ts(61), "actor": "orchestrator",
         "source_layer": "runtime_registry", "status": "ok",
         "summary": "RH-SIM-002 validation_pending->done", "task_id": "RH-SIM-002",
         "from_state": "validation_pending", "to_state": "done"},
    ]
    for e in events:
        ok = emit(e)
        if not ok:
            print(f"[driver] emit FAILED: {e.get('event_type')}", file=sys.stderr)
            return 1

    # --- TAPD live path: write+verify for each task via helper ---
    # v4.89 P0-A A4 (closes Real Trial v1 F3): tapd._live_path returns
    # a normalized shape (id/status/event/...). The driver now wraps
    # every record through wb.wrap_external_record() so the envelope
    # carries event_id / source_layer='tapd' / audit_status, replacing
    # the hand-authored envelope that used to live here.
    #
    # v4.89 P0-B Pre-Z1 W2 fix: ts_override now uses task_idx*2 offset
    # so each task's (write, verify) pair lands on a unique minute pair
    # (T1=70,71; T2=72,73) — keeps audit write order monotonic.
    for task_idx, (ext_id, obj_id) in enumerate(
        [("RH-SIM-001", "9001001"), ("RH-SIM-002", "9001002")]
    ):
        payload = {
            "external_id": ext_id,
            "object_type": "story",
            "object_id": obj_id,
            "internal_state": "done",
            "mapped_state": "resolved",
            "_use_live": True,
        }
        write_records = tapd._live_path(payload, config)
        for rec in write_records:
            emit_wrapped(
                rec,
                source_layer="tapd",
                event_type="external.tapd.write",
                result="ok" if rec.get("verification_ok") else "warn",
                ts_override=ts(70 + task_idx * 2),
                extra={
                    "task_id": ext_id,
                    "object_type": "story",
                    "object_id": obj_id,
                    "internal_state": "done",
                    "mapped_state": rec.get("status"),
                    "verification_ok": rec.get("verification_ok", False),
                    "retry_count": rec.get("retries", 0),
                    "auth_errors": rec.get("auth_errors", []),
                    "summary": f"writeback {ext_id} to TAPD (stub)",
                },
            )
        verify = tapd.verify_event(config, ext_id)
        print(f"[driver] tapd verify {ext_id}: {verify}")
        emit_wrapped(
            verify,
            source_layer="tapd",
            event_type="external.tapd.verify",
            result="ok" if verify.get("verification_ok") else "warn",
            ts_override=ts(71 + task_idx * 2),
            extra={
                "task_id": ext_id,
                "object_type": "story",
                "object_id": obj_id,
                "internal_state": "done",
                "mapped_state": "resolved",
                "verification_ok": verify.get("verification_ok", False),
                "retry_count": verify.get("retries", 0),
                "summary": f"verification read for {ext_id}",
            },
        )

    # --- Git merge pair for each task via hardened merge_apply/merge_cleanup ---
    # v4.89 P0-A A4 (closes Real Trial v1 F4): merge_apply/merge_cleanup
    # return a normalized shape with source_layer='git' (A3 annotation);
    # the driver wraps each rec via helper — no more hand-authored
    # envelope. Field is "event" inside details, event_type comes from
    # rec.get("event") via helper's fallback logic.
    #
    # v4.89 P0-B Pre-Z1 W2 fix: ts_override uses task_idx*2 offset so
    # each task's (apply, cleanup) pair lands on a unique minute pair
    # (T1=90,91; T2=92,93) — keeps audit write order monotonic.
    for task_idx, ext_id in enumerate(["RH-SIM-001", "RH-SIM-002"]):
        for kind, minute in [("apply", 90), ("cleanup", 91)]:
            fn = git.merge_apply if kind == "apply" else git.merge_cleanup
            recs = fn({
                "external_id": ext_id,
                "refs": [f"branch/wb/{ext_id}"],
                "branch": "integration",
            })
            for rec in recs:
                emit_wrapped(
                    rec,
                    source_layer=rec.get("source_layer", "git"),
                    event_type=rec.get("event", f"merge.{kind}"),
                    result=rec.get("status", "merged"),
                    ts_override=ts(minute + task_idx * 2),
                    extra={
                        "task_id": ext_id,
                        "branch_from": rec.get("refs", [""])[0] if rec.get("refs") else "",
                        "branch_to": rec.get("branch", "integration"),
                        "merge_strategy": "merge_commit",
                        "summary": f"{kind} {rec.get('refs', [])} -> {rec.get('branch', 'integration')}",
                    },
                )

    # --- Snapshot + archive + trial.check ---
    emit({"event_type": "runtime.snapshot", "timestamp": ts(110), "actor": "orchestrator",
          "source_layer": "runtime_registry", "status": "ok",
          "summary": f"snapshot for {SPRINT}"})
    emit({"event_type": "runtime.archive", "timestamp": ts(120), "actor": "orchestrator",
          "source_layer": "runtime_registry", "status": "ok",
          "summary": f"archived {SPRINT} with 2 tasks done"})
    emit({"event_type": "trial.check", "timestamp": ts(125), "actor": "main_session",
          "source_layer": "runtime_registry", "status": "ok",
          "summary": f"sprint_close_readiness=pass for {SPRINT}",
          "check_result": "pass"})

    # --- Close runtime_state ---
    # v4.89 P0-Z Z1: write to the canonical path under runtime/state/.
    # The workspace-root file is now a pointer shim (C4) — reading or
    # writing it as real state would destroy the shim. Fall back to the
    # root only if the canonical location does not exist (pre-C4 legacy).
    canonical_state = WS / "runtime" / "state" / "runtime_state.json"
    legacy_state = WS / "runtime_state.json"
    if canonical_state.exists():
        state_path = canonical_state
    else:
        state_path = legacy_state
    state = json.loads(state_path.read_text())
    state["closed_at"] = ts(125)
    state["tasks"] = [
        {"task_id": "RH-SIM-001", "state": "done"},
        {"task_id": "RH-SIM-002", "state": "done"},
    ]
    state_path.write_text(json.dumps(state, indent=2))
    print(f"[driver] closed {state_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
