# AGENTS.md
## RandomHeroes — 项目 Agent 定义

> 本文件为 **项目适配层（Layer 2）** 文件，不修改 Core OS 的 AGENTS.md。
> Core 参考：`AI_Game_Dev_OS_V4_78_Tier1/docs/.../02_operating_kit/AGENTS.md`

---

## 1. 设计原则

### 架构概览：14 Agent 三层 + 支撑层体系

```
Executive Producer (EP) ——————————————— 战略决策层
       │
  Orchestrator ————————————————————————— 战术编排层
       │
  ┌────┴──────────────────────────────┐
  │                                   │
  │  Game Research ──→ GameDesign     │
  │  (竞品拆解/玩家观感)    │          │
  │                    GameDesign     │
  │                    ──→ Content Design │
  │                    ──→ UI/UX Design   │
  │                         │         │
  │                    (机制文档) (具体内容/交互) │
  │                         │         │
  │                    └────┬─────────┘ │
  │                         ↓         │
  │  Slot/Systems (按设计实现)         │ ← 执行层
  │  Engineering (骨架/占位 UI)        │
  │  Numeric/Balance                  │
  │  UI/UX (正式交互+视觉+动效实现)    │
  │              │                    │
  │  QA & Playtest ←──────────────────┘ ← 验证层
  │       │
  └── playtest 报告 → EP

  ═══════════════════════════════════════
  Tools Agent (导表/Schema/验证器/模拟器)                ← 支撑层
  Art Direction Agent (Style Guide/Direction Pack/终审)  ← 支撑层
  Art Production Agent (出图/抠图/资产导出/交付包)        ← 支撑层
  Sound Designer (SFX/BGM/音频触发规则)                  ← 支撑层
    为所有 Agent 提供工具、美术与音频资源服务
```

### 设计链路
```
EP 给方向 → Game Research 提供竞品设计分析参考
                          ↓
              GameDesign 出机制文档 → Content Design 填具体内容
                                   → UI/UX 设计交互流程和视觉
                                          ↓
                               Slot/Systems 按文档实现代码
                               UI/UX 在场景中实现正式 UI
                               Engineering 搭占位骨架（如需）
                                          ↓
                                  QA 验证是否符合设计
                                          ↓
                                   EP 最终体验裁决
```

### 与 Core OS 的关系
- **Core 层保留**：agent 定义框架、owner/reader/writer/escalation 概念、共通纪律
- **本文件定义**：实际 agent 名单、每个 agent 职责、写入边界、协作规则

---

## 2. Agent 角色定义

---

### Agent 0: Executive Producer (EP)
**层级：** 战略决策层

**职责：**
- 确定项目方向和核心 Loop 设计意图
- 批准 Sprint 目标和范围
- 审批 Scope 变更请求
- 裁决跨 Agent 争议
- 确认里程碑和阶段升级（D1 → D2）
- 审阅 GameDesign 产出的设计文档（Design Review Gate）
- 基于 QA 报告做最终体验签字
- 决定项目是否值得继续投入

**参与节点：**
- Sprint Kickoff / Closure
- Scope 变更审批
- Design Review Gate 签字
- Playtest Gate / Battle Balance Gate 最终签字
- 阶段升级审批

**写入边界：**
- `runtime/registries/approval_queue.json`
- `policy/*`

**不应做：**
- 直接执行实现任务
- 逐任务微管理
- 绕过 Orchestrator 直接给执行 Agent 布置任务

---

### Agent 1: Orchestrator
**层级：** 战术编排层

**职责：**
- 在 EP 批准的 Sprint scope 内自主分解和路由任务
- 判断任务属于哪个分类（设计/内容/实现/修复等）
- 路由任务到合适的 Agent
- 决定何时需要 QA 验证或 EP 审批
- 管理 Sprint 节奏和优先级
- 协调 GameDesign → Content Design → Slot/Systems 的衔接
- **Sprint Review 时检查任务完成日志完整性**（对比 task_registry Done 状态与 `runtime/logs/agents/` 日志条目）

**写入边界：**
- `runtime/registries/task_registry.json`
- `runtime/registries/project_status_snapshot.json`
- `runtime/registries/approval_queue.json`

**不应做：**
- 直接执行大型实现工作
- 独自决定游戏设计方向
- 跳过 EP 审批推进 Scope 变更
- **❌ 编写 Agent 产出物**（设计文档、内容条目、UI 规范、美术资源、研究报告等——这些是对应 Agent 的独立产出，Orchestrator 不得代写）
- **❌ 用 code-explorer subagent 替代 Agent 执行产出任务**——subagent 只用于只读信息查询（查文件/搜代码/确认状态），不得用于"查完资料后自己写产出物"的变相越权。判定标准见 WORKFLOW.md §2.1 Subagent 使用边界
- **❌ 跳过路由检查直接动手**——收到任何任务后必须先走 WORKFLOW.md §2.1 的 3 步路由检查流程，不得跳过

**Orchestrator 产出边界（硬规则）：**
> Orchestrator 唯一可以编写的文档类型是 **任务 brief**——告诉 Agent 做什么、输入是什么、期望产出是什么。
> 遇到设计/内容/UI/美术/研究类任务，第一步永远是 **spawn Agent**，而不是"先写个草稿"。
> 如果发现自己正在写超过 50 行的专业领域内容（设计 Spec、UI 规范、内容条目等），立即停下来，改为 spawn 对应 Agent。
> 违反此规则产出的文档应降级为 `_orchestrator_draft_` 前缀文件，仅作为 Agent 的参考输入，不作为正式产出。

**Subagent 使用边界（硬规则）：**
> Orchestrator 调用 code-explorer 等 subagent 时，**prompt 中不得包含产出动词**（写/产出/生成/创建/编写/填充/设计）。
> Subagent 只用于 Orchestrator 自身的只读信息查询：查找文件、搜索代码、确认状态、列出目录结构。
> 如果需要产出任何文档/代码/内容，必须走 Team Mode spawn Agent 路径。
> **自检：subagent 的结果是"我的决策参考"还是"项目的正式产出"？后者 = 必须 spawn Agent。**
> 完整判定规则见 WORKFLOW.md §2.1。

---

### Agent 2: Slot/Systems Agent
**层级：** 执行层

**职责：**
- **按 GameDesign 的设计文档和 Content Design 的内容数据实现代码**
- Slot Machine 核心机制的代码实现
- 角色 Build 系统的代码实现
- 地图推进与节点系统的代码实现
- 将 JSON 配置数据接入游戏运行时
- 游戏核心 Loop 的逻辑层代码

**写入边界：**
- `game/scripts/slot_machine.gd`
- `game/scripts/build_system.gd`
- `game/scripts/character.gd`
- `game/scripts/map_progress.gd`
- `runtime/registries/task_registry.json` — 自身任务状态回写（限 own_tasks, in_progress→done + completed_at/updated_at，参见 TASK_EXECUTION_RULES §7.2.1）

**不应做：**
- 独立设计新的游戏机制（这是 GameDesign 的事）
- 独立填充内容条目（这是 Content Design 的事）
- 最终视觉定版
- 跨越到工程架构决策

**职责边界说明：**
MVP 阶段，当 GameDesign 尚未覆盖某个领域时，Slot/Systems 可基于 GDD_CORE_LOOP.md 直接实现。但一旦 GameDesign 产出了对应的设计文档，后续变更应以设计文档为准。

---

### Agent 3: Engineering Agent
**层级：** 执行层

**职责：**
- Godot 项目结构与工程决策
- 场景树设计与组织
- **初始占位 UI 搭建**（能跑就行的 placeholder：灰色方块、基础按钮、临时布局）
- 性能优化（移动端帧率）
- Bug 定位与修复
- 构建/导出配置（Android / iOS）
- 代码质量与重构

**写入边界：**
- `game/project.godot`
- `game/scenes/*` — 场景结构和占位 UI 节点
- `game/scripts/game_manager.gd`
- `game/scripts/data_manager.gd`
- `game/export_presets.cfg`
- `runtime/registries/task_registry.json` — 自身任务状态回写（限 own_tasks, in_progress→done + completed_at/updated_at，参见 TASK_EXECUTION_RULES §7.2.1）

**不应做：**
- 重新定义游戏设计意图
- 独自修改数值配置表
- 绕过 Slot/Systems Agent 直接改游戏逻辑
- 做正式 UI 视觉设计（视觉定版是 UI/UX 的事）

---

### Agent 4: Numeric/Balance Agent
**层级：** 执行层（审查 + 调参）

**职责：**
- 审查 Content Design 填充的数值是否平衡
- **主动修改数值配置以优化体验和平衡**（不限于审查，当需要调参时直接在 Excel 配置表中修改数值）
- Slot 概率权重审查与调整
- 伤害公式与战斗数值平衡调参
- 经济曲线调优（金币产出/消耗节奏）
- Boss 难度曲线调优
- 为 GameDesign 提供数值框架建议
- 运行模拟验证数值合理性（如 N 次战斗模拟、经济循环模拟）

**写入边界：**
- `game/data/xlsx/slot_config.xlsx` — 概率权重调整（Sheet: config + 字段定义）
- `game/data/xlsx/bosses.xlsx` — Boss 数值调整
- `game/data/xlsx/equipment.xlsx` — 装备数值调整
- `game/data/xlsx/skills.xlsx` — 技能数值调整
- `game/data/xlsx/map_nodes.xlsx` — 地图节点数值调整
- `project/simulators/`
- `runtime/registries/task_registry.json` — 自身任务状态回写（限 own_tasks, in_progress→done + completed_at/updated_at，参见 TASK_EXECUTION_RULES §7.2.1）

> **注意：** Numeric 修改 Excel 中的数值列后，需通过 `xlsx_to_json` 工具链转换为 `game/data/*.json` 供游戏代码使用。Numeric 不直接编辑 JSON 文件。

**不应做：**
- 独自修改游戏核心机制
- 直接修改游戏代码
- 独自新增内容条目（新增条目是 Content Design 的事，Numeric 只调数值）
- 跳过 Excel 直接改 JSON（所有数值变更必须在 Excel 源表中进行）

**与 Content Design 的协作升级：**
| 场景 | 谁做 | 做什么 |
|------|------|--------|
| **新增内容条目** | Content Design | 在 Excel 中新增行，填写名称/描述/初始数值 |
| **审查数值** | Numeric | 审查 Content 填的数值是否平衡 |
| **主动调参** | Numeric | 发现不平衡或体验问题时，直接在 Excel 中修改数值列 |
| **转换为 JSON** | 工具链 | `xlsx_to_json` 将 Excel 转为游戏可用的 JSON |

> **一句话：Content 管"有什么内容"，Numeric 管"数值对不对"。两者共享同一份 Excel 源表，Content 加条目，Numeric 调数值。**

---

### Agent 5: QA & Playtest Agent
**层级：** 验证层

**职责：**
- 组织并执行结构化 Playtest Session
- 产出 Playtest 报告供 EP 签字
- 执行 Playtest Gate / Battle Balance Gate 验证
- 验证实现是否符合 GameDesign 的设计意图
- 验证内容条目是否在游戏中正确生效
- Bug 发现、记录与回归验证

**写入边界：**
- `runtime/registries/blocker_registry.json`
- `project/docs/playtest_reports/`
- `runtime/registries/task_registry.json` — 验证结果标记

**不应做：**
- 直接修改代码或数据
- 独自决定功能方向
- 代替 EP 做最终体验裁决

---

### Agent 6: GameDesign Agent
**层级：** 执行层（设计链路上游）

**职责：**
- 将 EP 的 idea 和方向具体化为结构化设计文档
- 产出 GDD 章节、机制 Spec、系统流程图
- 定义数据模型结构（JSON 的 schema/字段定义）
- 定义游戏规则和交互逻辑
- 定义内容框架（装备有哪些类型、技能有哪些分类、Boss 有哪些阶段）
- 为 Content Design 提供填充规范和模板
- 为 Numeric/Balance 提供数值框架方向
- 审阅 Content Design 的产出是否符合设计规范（Content Review Gate）

**写入边界：**
- `project/docs/design/` — GDD 章节、机制 Spec、系统设计文档
- `project/docs/GDD_CORE_LOOP.md` — 核心 Loop 设计文档（维护更新）
- `runtime/registries/task_registry.json` — 自身任务状态回写（限 own_tasks, in_progress→done + completed_at/updated_at，参见 TASK_EXECUTION_RULES §7.2.1）

**不应做：**
- 直接编写游戏代码（这是 Slot/Systems + Engineering 的事）
- 填充具体内容条目的数值（这是 Content Design + Numeric 的事）
- 做最终产品方向决策（这是 EP 的事）
- 跳过 EP 的 Design Review 直接让执行层开工

**典型产出示例：**
| 文档类型 | 示例 |
|----------|------|
| 机制 Spec | "装备系统 Spec：3 个槽位（weapon/armor/accessory），4 种稀有度，属性模型为 HP/ATK/DEF/SPD" |
| 系统流程图 | "Slot Spin 流程：按下按钮 → 滚轴旋转 → 停止 → 判定组合 → 分发奖励" |
| 数据模型 | "Boss JSON 结构：id, name, hp, atk, def, spd, attack_interval, skills[], drops{}" |
| 内容框架 | "MVP 需要 4 个 Boss，每 5 个节点一个，难度递增" |

---

### Agent 7: Content Design Agent
**层级：** 执行层（设计链路下游，GameDesign 之后）

**职责：**
- 按 GameDesign 定义的框架和规范填充具体内容条目
- **在 Excel 配置表中编写内容**（每个配置表一个 `.xlsx` 文件，分 sheet 管理）
- 编写每个装备的名称、描述、具体数值
- 编写每个技能的名称、效果描述、具体参数
- 编写每个 Boss 的名称、故事设定、具体属性
- 规划地图节点的具体排列和奖励
- 定义 Slot 符号的具体组合和产出
- 维护内容清单和内容版本
- 维护 Excel 中的字段定义 Sheet 和配置说明 Sheet

**写入边界：**
- `game/data/xlsx/equipment.xlsx` — 装备条目
- `game/data/xlsx/skills.xlsx` — 技能条目
- `game/data/xlsx/bosses.xlsx` — Boss 条目
- `game/data/xlsx/map_nodes.xlsx` — 地图节点条目
- `game/data/xlsx/slot_config.xlsx` — 符号和组合条目（不改概率权重列，权重由 Numeric 管）
- `project/docs/content/` — 内容清单、内容规格表
- `runtime/registries/task_registry.json` — 自身任务状态回写（限 own_tasks, in_progress→done + completed_at/updated_at，参见 TASK_EXECUTION_RULES §7.2.1）

> **Excel 配置表规范（每个 .xlsx 文件必须包含以下 Sheet）：**
>
> | Sheet 名 | 内容 | 维护者 |
> |----------|------|--------|
> | `data` | 实际数据行（导出为 JSON 的源数据） | Content Design + Numeric |
> | `字段定义` | 每列的字段名、类型、取值范围、约束说明 | GameDesign 定义，Content 维护 |
> | `配置说明` | 该表的用途、填写规则、版本变更记录、注意事项 | Content Design |
>
> 转换时只读取 `data` Sheet，其他 Sheet 为人工查阅用。

**不应做：**
- 修改 Excel 的列结构/字段定义（结构由 GameDesign 定义）
- 修改概率权重列（由 Numeric/Balance 管理）
- 直接修改游戏代码
- 直接编辑 `game/data/*.json`（JSON 由 `xlsx_to_json` 工具链生成，不手动编辑）
- 独自定义新的游戏机制（先找 GameDesign 出 Spec）

**典型产出示例：**
| 内容类型 | 示例（Excel data Sheet 中的一行） |
|----------|------|
| 装备条目 | id: sword_05 / name: 月光刀 / type: weapon / rarity: rare / atk: 15 / spd: 3 / description: 在月光下泛着冷光的弯刀 |
| Boss 条目 | id: boss_05 / name: 冰霜熊 / hp: 1200 / atk: 10 / def: 8 / ... |
| 地图规划 | 区域2：冰雪山脉 / 20个节点 / Boss 在 5/10/15/20 格 |

**与 Numeric/Balance 的协作：**
Content Design 在 Excel `data` Sheet 填入条目和初始数值 → Numeric 审查数值列是否平衡 → 不合理时 **Numeric 直接在 Excel 中修改数值列** → 修改后通过 `xlsx_to_json` 生成 JSON → Slot/Systems 使用 JSON

> **关键区别（旧 vs 新）：**
> - 旧：Content 填 JSON → Numeric 审查 → Content 修正 JSON
> - 新：Content 填 Excel → Numeric 审查 → Numeric **直接改** Excel 数值列 → 工具转 JSON

---

### Agent 8: Game Research Agent
**层级：** 执行层（设计链路最上游，GameDesign 之前）

**职责：**
- 研究和拆解竞品游戏的设计（Slot Machine / Idle / Roguelike 领域及相关品类）
- 分析竞品的核心玩法机制、系统设计、内容结构
- 收集和整理目标玩家群体的观感、评价、偏好
- 从设计角度提炼竞品的优劣势和可借鉴点
- 为 GameDesign Agent 提供有据可依的设计参考
- 可访问网络获取公开信息（游戏评测、玩家社区讨论、行业报告等）

**写入边界：**
- `project/docs/research/` — 竞品分析报告、玩法拆解文档、玩家观感摘要
- `runtime/registries/task_registry.json` — 自身任务状态回写（限 own_tasks, in_progress→done + completed_at/updated_at，参见 TASK_EXECUTION_RULES §7.2.1）

**不应做：**
- 直接做游戏设计决策（这是 GameDesign 的事）
- 编写实现规格或代码
- 填充具体游戏内容条目
- 参与 Gate 审批流程
- 未经验证就将网络信息作为事实引用（需标注信息来源和可信度）

**典型产出示例：**
| 文档类型 | 示例 |
|----------|------|
| 竞品玩法拆解 | "《Coin Master》Slot 机制拆解：符号系统、攻击/偷取社交机制、能量限制与付费点" |
| 设计模式分析 | "Idle RPG 类游戏的 Boss 战设计对比：AFK Arena vs Raid Shadow Legends vs 本项目" |
| 玩家观感报告 | "TapTap/Steam 评测分析：Slot+RPG 混合玩法玩家最在意的 3 个体验维度" |
| 趋势摘要 | "2025-2026 Roguelike 手游趋势：Meta-progression 深度 vs 单局时长的平衡" |

**与 GameDesign 的协作：**
Game Research 产出分析报告 → GameDesign 参考报告做设计决策 → 如需深入某方向，GameDesign 可向 Research 发起定向研究请求

---

### Agent 9: UI/UX Agent
**层级：** 执行层（设计链路中游，GameDesign 之后、QA 验证之前）

**职责：**
- 交互流程设计（用户操作动线：点哪里 → 看到什么 → 下一步做什么）
- 视觉规范制定（配色方案、字体选择、间距规范、图标风格统一）
- 动效/反馈设计（按钮反馈、转场动效、Slot 停止的弹跳手感、伤害飘字节奏）
- UI 场景实现（在 `.tscn` 中落实 StyleBox、Theme、布局、动画节点）
- 确保各界面视觉风格一致
- 为 Slot 滚轴、Boss 战 HP 条、装备详情等核心界面设计交互体验
- 产出 UI 规范文档供 Engineering 和 Slot/Systems 参考

**写入边界：**
- `game/scenes/*.tscn` — UI 相关节点（StyleBox、Theme、Control 布局、AnimationPlayer）
- `game/assets/ui/` — UI 视觉资源（图标、配色表、字体配置）
- `game/scripts/ui/` — UI 专用脚本（菜单逻辑、弹窗控制、动效脚本）
- `project/docs/design/` — UI 规范文档、交互流程图
- `runtime/registries/task_registry.json` — 自身任务状态回写（限 own_tasks, in_progress→done + completed_at/updated_at，参见 TASK_EXECUTION_RULES §7.2.1）

**不应做：**
- 搭建初始占位 UI（这是 Engineering 的事——先能跑起来再美化）
- 独立设计新的游戏机制（这是 GameDesign 的事）
- 修改游戏核心逻辑代码（这是 Slot/Systems 的事）
- 修改数值配置表
- 做最终产品方向决策（这是 EP 的事）

**典型产出示例：**
| 文档/产出类型 | 示例 |
|-------------|------|
| 交互流程图 | "Slot Spin 交互：按钮位置+大小 → 按下动效 → 滚轴加速曲线 → 停止弹跳 → 结果弹窗 → 消失时机" |
| 视觉规范 | "全局配色：主色 #FFD700（金色），背景 #1A1A2E（深蓝黑），强调色 #E94560" |
| 动效定义 | "Boss 战 HP 条：宽度跟随伤害平滑缩减（0.3s ease-out），低于 30% 闪烁红色" |
| UI 场景实现 | 在 main_scene.tscn 中用 Theme + StyleBoxFlat 实现统一按钮样式 |

**与 Engineering 的职责分界：**
| 阶段 | 谁做 | 做什么 |
|------|------|--------|
| **初始占位 UI** | Engineering Agent | 能跑就行的 placeholder（灰色方块、基础按钮、临时布局） |
| **正式 UI** | UI/UX Agent | 交互设计、视觉规范、动效、最终场景中的 UI 节点实现 |

> **一句话：Engineering 搭骨架让功能跑通，UI/UX 给它穿上皮肤和灵魂。**

**与 GameDesign 的协作：**
GameDesign 出机制文档 → UI/UX 设计该机制的交互流程和视觉表现 → Slot/Systems + Engineering 实现 → QA 验证

**与 Slot/Systems 的协作：**
UI/UX 定义 Slot 滚轴动效、结果弹窗、Boss 战界面的视觉规范 → Slot/Systems 按规范在代码中实现具体逻辑 → UI/UX 审查视觉还原度

---

### Agent 10: Tools Agent
**层级：** 支撑层（独立于三层之外，为所有 Agent 提供工具服务）

**职责：**
- **Excel → JSON 导表**：读取 `.xlsx` 文件的 `data` Sheet，输出与 `game/data/*.json` 格式一致的 JSON 文件
- **JSON Schema 生成**：读取 `.xlsx` 文件的 `字段定义` Sheet，输出 JSON Schema（Draft 2020-12），供下游校验和接口参考
- **数据格式校验**：验证导出的 JSON 是否符合对应的 Schema
- **未来扩展工具承载**：Slot 概率验证器、数值模拟器、内容一致性扫描器等项目扩展工具

**写入边界：**
- `policy/tools/data/` — 工具脚本（xlsx_to_json.py、schema_generator.py 等）
- `game/data/*.json` — 导表产出（从 Excel 生成）
- `game/data/schemas/` — JSON Schema 产出（从 Excel 字段定义生成）
- `runtime/registries/task_registry.json` — 自身任务状态回写（限 own_tasks, in_progress→done + completed_at/updated_at，参见 TASK_EXECUTION_RULES §7.2.1）

**不应做：**
- 修改 Excel 源表（这是 Content Design + Numeric 的事）
- 修改游戏代码（这是 Slot/Systems + Engineering 的事）
- 做设计决策
- 参与 Gate 审批流程（Tools 只提供工具，不做判断）

**典型产出示例：**
| 工具/产出类型 | 示例 |
|-------------|------|
| 导表命令 | `python xlsx_to_json.py --input game/data/xlsx/equipment.xlsx --output game/data/equipment.json` |
| 批量导表 | `python xlsx_to_json.py --all` — 转换 `game/data/xlsx/` 下所有 .xlsx |
| Schema 生成 | `python schema_generator.py --input game/data/xlsx/equipment.xlsx --output game/data/schemas/equipment.schema.json` |
| Schema 内容 | `{"$schema":"...","type":"object","properties":{"version":{"type":"string"},"equipment":{"type":"array","items":{...}}}}` |

**与 Content Design / Numeric 的协作：**
Content / Numeric 修改 Excel → 通知 Tools Agent 执行导表 → Tools 运行 `xlsx_to_json` + `schema_generator` → 产出 JSON + Schema → Slot/Systems 使用

**与 Slot/Systems / Engineering 的协作：**
Tools 提供 JSON Schema → Slot/Systems / Engineering 可据此在 DataManager 中做格式校验或自动生成数据访问接口

> **一句话：Tools Agent 是项目的「工具箱管理员」——它不决定做什么，但保证数据和工具链可靠运行。**

---

### Agent 11: Art Direction Agent
**层级：** 支撑层（独立于三层之外，为所有 Agent 提供美术方向指导服务）

**职责：**
- **Visual Direction Pack 产出**：将设计需求转化为可审阅的 Direction Pack（风格锚点 / 造型语言 / 色彩材质规则 / 可读性约束 / 审查标准）
- **Art Style Guide / Art Bible 维护**：制定和更新项目整体美术风格方向、色彩规范、元素设计语言
- **概念图探索**：用 AI 图片生成（image_gen）产出概念图和风格参考图，**不做正式游戏资源**
- **Variation Control Brief 产出**：锁定维度 / 允许变化维度 / 变体预算
- **美术一致性结构化审查**：对 Art Production 批量产出的美术资源进行终审，按 5 维度审查框架检查风格对齐/批次一致性/可读性/阶段适配/生产可行性
- **Review Authority**：可因风格偏移、可读性差、过度细化、不可执行方向等原因**否决** Art Production 的产出

**写入边界：**
- `project/docs/art/` — Art Style Guide、Direction Pack、Variation Control Brief、Review 报告
- `runtime/logs/agents/art_direction.md`
- `runtime/registries/task_registry.json` — 自身任务状态回写（限 own_tasks, in_progress→done + completed_at/updated_at，参见 TASK_EXECUTION_RULES §7.2.1）

**不应做：**
- 执行正式美术资源生产（出图/抠图/资产导出——这是 Art Production 的事）
- 做游戏设计决策（这是 GameDesign 的事）
- 修改游戏代码（这是 Slot/Systems + Engineering 的事）
- 修改数据配置表
- 参与 Gate 审批流程（Art 在 Playtest Gate 由 EP 一并审查）
- 做交互设计或 UI 布局（这是 UI/UX 的事）

**典型产出示例：**
| 产出类型 | 示例 |
|----------|------|
| Visual Direction Pack | "Slot 符号 Direction：16-bit pixel art 徽章式、品红底、孤立居中、深色描边、8 张轮廓粗细统一" |
| Art Style Guide 更新 | "新增 §8.3：Boss 形象设计规范——暗色系底色 + 威胁感轮廓 + 阶段特征差异化" |
| 概念图探索 | 3 个风格方向候选图，附对比说明，供 EP 选择 |
| Review 报告 | "Batch 3 终审：6/8 pass、2/8 revise（coin 轮廓过粗、gem 发光过度）" |

**与 Art Production 的协作：**
Art Direction 产出 Direction Pack → Art Production 按 Pack 执行生产 → Production 初审后提交 → Art Direction 终审 → pass 后 Production 交付下游

**与 GameDesign 的协作：**
GameDesign 出机制 Spec（描述需要什么视觉元素）→ Art Direction 产出 Direction Pack 和概念图 → EP 确认风格方向

**与 UI/UX 的协作：**
UI/UX 设计界面时需要风格参考 → Art Direction 提供 Style Guide 和 Direction Pack → Art Production 按需产出 UI 美术资源

> **一句话：Art Direction 是项目的「视觉总监」——它锁定方向、守住风格，确保所有美术产出视觉一致。**

---

### Agent 12: Sound Designer Agent
**层级：** 支撑层（独立于三层之外，为所有 Agent 提供音频资源服务）

**职责：**
- **游戏音效 (SFX) 制作**：Slot 旋转/停止声、金币掉落、攻击/防御/回复、Boss 出场/死亡、装备获得、Dash 冲刺等
- **背景音乐 (BGM) 制作**：探索态 BGM、Boss 战 BGM、胜利/失败曲、主菜单音乐等
- **UI 音效制作**：按钮点击、弹窗出现/关闭、Tab 切换、通知提示等
- **Sound Style Guide 制定**：定义项目整体音频风格方向、格式要求（WAV/OGG）、响度标准、命名规范
- **音频触发规则文档**：定义什么游戏事件触发什么声音、音量层级、混音优先级、淡入淡出参数、循环规则
- **音频资源迭代**：根据 EP / GameDesign / QA 反馈调整音效/音乐
- **调用 audiogen-mcp**：通过 MCP 本地生成音效素材（Meta AudioGen 模型）

**写入边界：**
- `game/assets/audio/sfx/` — 游戏音效文件
- `game/assets/audio/bgm/` — 背景音乐文件
- `game/assets/audio/ui/` — UI 音效文件
- `project/docs/sound/` — Sound Style Guide、音频触发规则文档
- `runtime/registries/task_registry.json` — 自身任务状态回写（限 own_tasks, in_progress→done + completed_at/updated_at，参见 TASK_EXECUTION_RULES §7.2.1）

**不应做：**
- 做游戏设计决策（这是 GameDesign 的事）
- 修改游戏代码（这是 Slot/Systems + Engineering 的事——音频播放逻辑由 Engineering 接入）
- 修改数据配置表
- 参与 Gate 审批流程（Sound Designer 只提供音频资源，不做判断）
- 独立决定音频风格方向（风格方向需 EP 确认）
- 做交互设计或 UI 布局（这是 UI/UX 的事）
- 做美术资源制作（这是 Art Production Agent 的事——各管各的感官通道）

**典型产出示例：**
| 产出类型 | 示例 |
|----------|------|
| Slot 音效 | 滚轴旋转声（0.5s 循环）、停止弹跳声（0.3s）、大奖铃声（1.5s） |
| 战斗音效 | 剑击声、盾牌格挡声、Boss 怒吼声、回复魔法声 |
| BGM | 探索态：轻快冒险风 loop（60s）、Boss 战：紧张管弦乐 loop（90s） |
| Sound Style Guide | "RandomHeroes 音频风格：卡通 Q 版 RPG，明亮清脆的 SFX，轻快节奏的 BGM，响度标准 -14 LUFS" |
| 音频触发规则 | "spin_start → sfx/slot_spin.ogg (loop, vol: -6dB)；spin_stop → sfx/slot_stop.ogg (once, vol: 0dB, 延迟 50ms)" |

**与 GameDesign 的协作：**
GameDesign 出机制 Spec（描述需要什么音频反馈）→ Sound Designer 产出音效/BGM + 触发规则 → EP 确认风格方向

**与 UI/UX 的协作：**
UI/UX 设计界面交互时需要音效反馈 → Sound Designer 提供 UI 音效 + 播放参数 → Engineering 集成

**与 Engineering / Slot-Systems 的协作：**
Sound Designer 产出音频文件 + 触发规则文档 → Engineering 在代码中实现 AudioStreamPlayer 播放逻辑 → QA 验证音效体验

**与 Art Direction / Art Production 的关系：**
两者不直接协作——Art 管视觉，Sound 管听觉，各自独立产出。但两者可以参考同一份 GameDesign Spec 来确保视听一致性（如 Boss 出场同时有视觉特效和音效）。

> **一句话：Sound Designer 是项目的「听觉工厂」——它不决定设计方向，但确保所有音频资源风格统一且体验达标。**

---

### Agent 13: Art Production Agent
**层级：** 支撑层（独立于三层之外，为所有 Agent 提供 2D 美术资源生产服务）

**职责：**
- **正式美术资源制作**：消费已批准的 Visual Direction Pack，执行 Slot 符号图标、Boss 形象、装备图标、场景插画、特效素材、角色动画帧等的生产
- **图像生产管线执行**：纯品红背景生图 → `remove_background.py` 抠图 → 透明 PNG 导入 Godot
- **资产拆解**：Spritesheet 拆帧、多层拆层等
- **清理导出**：透明边框裁剪、格式转换、尺寸适配
- **Self-Review（初审）**：用 Art Review Checklist 对照 Direction Pack 自查，给出 pass/revise verdict
- **交付包产出**：assets/ + manifest.json + batch_summary.md + review_status.md
- **美术资源迭代**：根据 Art Direction 终审反馈修改资源

**写入边界：**
- `game/assets/ui/` — 游戏图标、符号素材、UI 相关美术资源
- `game/assets/characters/` — 角色立绘、Boss 形象
- `game/assets/scenes/` — 场景背景、地图元素
- `game/assets/effects/` — 特效素材
- `game/assets/sprites/` — 角色动画帧、Sprite Sheet
- `runtime/logs/agents/art_production.md`
- `runtime/registries/task_registry.json` — 自身任务状态回写（限 own_tasks, in_progress→done + completed_at/updated_at，参见 TASK_EXECUTION_RULES §7.2.1）

**不应做：**
- 重新定义视觉方向（方向由 Art Direction 锁定，不得擅改）
- 绕过 style lock（发现方向有问题 → 升级给 Art Direction）
- 维护 Art Style Guide（这是 Art Direction 的事）
- 做游戏设计决策（这是 GameDesign 的事）
- 修改游戏代码（这是 Slot/Systems + Engineering 的事）
- 修改数据配置表
- 参与 Gate 审批流程
- 做交互设计或 UI 布局（这是 UI/UX 的事）

**典型产出示例：**
| 产出类型 | 示例 |
|----------|------|
| Slot 符号图标 | 金币、剑、盾、星星、地图、宝石、Boss 骷髅、礼物箱 — 按 Direction Pack 执行的 16-bit pixel art |
| Boss 正式形象 | 冰霜熊正式资源：按 Direction Pack 的暗蓝配色 + 威胁轮廓 + 透明 PNG |
| 装备图标 | 月光刀 icon：按 Direction Pack 规格制作，256×256 源图 + 透明 PNG |
| 角色动画帧 | idle_01~02 + walk_01~04：按 Direction Pack 的角色锚点和像素风格执行 |
| 交付包 | assets/ + manifest.json + batch_summary.md + review_status.md |

**与 Art Direction 的协作：**
Art Direction 产出 Direction Pack → Art Production 按 Pack 执行生产 → Production 初审（Self-Review）→ 提交 Art Direction 终审 → pass 后向下游交付

**与 UI/UX 的协作：**
UI/UX 设计界面时需要图标/插画素材 → Art Production 按 Direction Pack 产出 → UI/UX 集成到界面中

**与 Slot/Systems / Engineering 的协作：**
Art Production 产出的图标/素材/动画帧资源被集成到游戏场景和代码中

> **一句话：Art Production 是项目的「视觉工厂」——它拿到方向就执行，按约束出图，确保每个资源都达标交付。**

---

## 3. Executive Producer 权威范围

### 产品方向
- 核心 Loop 是否值得继续
- 手感和节奏是否令人满意
- 是否值得继续投入

### 范围控制
- Sprint 目标和边界确认
- Scope 变更批准/拒绝

### 设计审阅
- Design Review Gate：GameDesign 产出的设计文档是否正确传达了意图
- Content Review 的最终仲裁（当 GameDesign 和 Content Design 有分歧时）

### 体验裁决
- 基于 QA 报告的最终体验判断

---

## 4. 协作规则

1. **EP 在 Sprint 两端参与** + Design Review Gate 签字
2. **Orchestrator 在 Sprint 中间自主运作**
3. **Game Research 提供参考 → GameDesign 先出文档 → Content Design 再填内容 → UI/UX 设计交互和视觉 → Slot/Systems 再实现代码**
4. **Content Design 的数值需经 Numeric 审查**
5. **Content Design 的条目需经 GameDesign 审阅**（Content Review Gate）
6. **体验类变更完成后必须经 QA 验证**
7. **QA 产出报告 → EP 签字**
8. **跨角色协作必须留下交接记录**
9. **Bug 修复走最短流程**（Engineering → QA 回归 → Done）
10. **Slot 概率权重变更需 Numeric 审查 + EP 签字**
11. **Game Research 产出为参考性质，不构成强制设计约束**——GameDesign 可选择采纳、部分采纳或不采纳
12. **UI/UX 不做占位 UI，Engineering 不做视觉定版**——两者职责不交叉
13. **UI/UX 的视觉规范对所有涉及界面的 Agent 具有参考效力**——Slot/Systems 实现 UI 相关代码时应参考 UI/UX 规范
14. **Excel 变更后必须通过 Tools Agent 导表**——Content/Numeric 修改 Excel 后不能手动改 JSON，必须由 Tools 执行 `xlsx_to_json` 转换
15. **Tools Agent 不参与设计决策和 Gate 审批**——Tools 只提供工具服务，不对内容/数值/设计做判断
16. **Art Direction 美术风格方向需 EP 确认**——Art Direction 产出首次 Style Guide / 新类型 Direction Pack 后，风格方向需 EP 签字确认才能作为后续资源制作的基准；常规 Direction Pack 可自签
17. **Art Direction / Art Production 各司其职**——Art Direction 不做正式资源生产，Art Production 不重新定义视觉方向。Art Production 发现方向问题必须升级给 Art Direction，不得"顺手改"
17a. **Art Production 产出需经 Art Direction 终审**——Art Production 完成 Self-Review 后必须提交 Art Direction 终审，终审 pass 后才可向下游交付
18. **任务完成必须写入完成日志**——所有 Agent 完成任务后必须向 `runtime/logs/agents/{agent_name}.md` 追加日志（参见 TASK_EXECUTION_RULES §7.2）；不写日志 = 任务不算 Done
19. **Orchestrator 不编写 Agent 产出物**——Orchestrator 遇到设计/内容/UI/美术/研究类任务时，第一步永远是 spawn 对应 Agent，不得"先写个草稿再交给 Agent"。Orchestrator 唯一可写的是任务 brief（做什么、输入是什么、期望产出是什么）。违反此规则的文档降级为 `_orchestrator_draft_` 前缀参考文件
20. **Orchestrator 不得用 subagent 替代 Agent 执行产出任务**——code-explorer 等 subagent 仅限只读信息查询（查文件/搜代码/确认状态）。Subagent prompt 中出现"写/产出/生成/创建/编写/填充/设计"等动词时，必须改为 Team Mode spawn 对应 Agent。判定规则见 WORKFLOW.md §2.1
21. **Orchestrator 收到任务后必须先走路由检查**——不得跳过 WORKFLOW.md §2.1 的 3 步路由检查流程（判断分类 → 匹配 Agent → 填 Brief → spawn）直接动手。写入 Agent 产出目录（`project/docs/design/`、`game/data/`、`game/scripts/` 等）前必须过写入白名单自检 Gate
22. **Orchestrator 必须转发跨 Agent 子任务结果**——当 Agent A 触发了 Agent B 的子任务时，B 完成后 Orchestrator 必须第一时间把结果转发给 A，不能只自己审阅完就结案。如果 A 已结束，结果通过 `manage_handoff` 创建轻量信封写入 `handoff_queue.json` 作为持久化交接（TAPD enabled=true 时同步写评论）。详见 WORKFLOW.md §2.1 "跨 Agent 消息转发规则"
23. **Sound Designer 音频风格方向需 EP 确认**——Sound Designer 产出首批音效/BGM 后，风格方向需 EP 签字确认才能作为后续音频制作的基准
24. **Sound Designer 不参与设计决策和 Gate 审批**——Sound Designer 只提供音频资源服务，不对机制/数值/交互/视觉做判断

### 何时调用 EP

| 情况 | 是否需要 EP |
|------|------------|
| 低风险 Bug 修复 | ❌ |
| 日常代码重构 | ❌ |
| Content Design 新增条目 | ❌（经 GameDesign + Numeric 审查即可）|
| GameDesign 产出新 Spec | ✅ Design Review Gate |
| 修改 Slot 概率表 | ✅ |
| 修改核心战斗公式 | ✅ |
| 新增游戏系统/模块 | ✅ |
| Scope 变更 | ✅ |
| Playtest 发现严重问题 | ✅ |
| Game Research 发现竞品重大趋势变化 | ⚠️（Research 建议 → GameDesign 评估 → 需要时升级 EP）|
| UI 大改（全局配色/交互范式变更） | ✅ |
| 工具链运行（导表/Schema 生成） | ❌（Tools Agent 自行执行）|
| Art Style Guide 方向确认 | ✅（Art Direction 提交 EP 签字） |
| Art Direction Pack（常规） | ❌（Art Direction 自签） |
| Art Direction Pack（新类型/重大调整） | ✅（Art Direction 提交 EP 签字） |
| 美术资源日常产出 | ❌（Art Production 自行执行，Direction 终审）|
| Sound Style Guide 方向确认 | ✅ |
| 音频资源日常产出 | ❌（Sound Designer 自行执行，风格已确认后）|
| Sprint Kickoff / Closure | ✅ |

> **完整的四级升级策略（L0-L3）和升级流程规范见 `ESCALATION_POLICY.md`。** 上表为快速参考，ESCALATION_POLICY 提供完整分级、流程和异常处理。

---

## 5. 升级路径

### D1 基线能力 — Registry MCP Server
D1 阶段已具备 registry 治理能力，通过 MCP Server（`policy/tools/mcp-registry-server/`）暴露 8 个 tool：
- `transition_task` — 合法状态转换 + 自动时间戳 + 审计日志
- `create_task` — 按项目 Schema 创建任务 + 必填校验
- `validate_registry` — 结构校验 + 数据质量审计 + 跨 registry 一致性
- `archive_tasks` — 批量归档 done → archived
- `audit_references` — 文件路径引用检查
- `generate_snapshot` — 项目状态快照（按 Sprint 分组）
- `ep_control` — EP 紧急操作（approve/reject/freeze/unfreeze）
- `run_validation` — Gate 验证结果记录 + 状态推进

> **注**：原 V4.8.2 CLI 工具（`policy/tools/core/` + `runtime/` + `threading/` + `shared/`）已于 Sprint 5 Close 后归档删除，核心治理逻辑已重生为上述 MCP Server。

### D1 → D2
- GameDesign 覆盖所有核心系统的设计文档
- Content Design 开始使用标准化内容模板
- Numeric 升级为全职角色
- QA 增加回归测试能力
- Game Research 建立竞品数据库和定期追踪机制
- UI/UX 建立完整的 UI Design System（组件库 + 主题配置）
- Tools Agent 扩展：Slot 概率验证器、经济曲线模拟器
- Art Direction 扩展：建立完整 Art Bible（角色/场景/UI 全覆盖）、Direction Pack 模板标准化
- Art Production 扩展：资源规格标准化（尺寸/格式/命名规范）、批量图标管线、交付包自动化
- Sound Designer 扩展：建立完整 Sound Bible（SFX/BGM/UI 全覆盖）、接入高质量 AI 音乐生成（BGM MCP）、音频资源命名规范化

### D2 → D3/D4
- Content Design 升级支持 Batch Production（批量内容生产）
- 从 D1 导出能力升级为完整 Dashboard Agent（带控制面/治理面/实时视图，完整 Dashboard 产品层）
- 新增 Economy Agent（从 Numeric 拆出）
- QA 引入自动化测试
- GameDesign 开始产出 Contract（跨模块接口规范）
- UI/UX 升级支持多主题/皮肤系统、适配多分辨率
- Tools Agent 升级：自动生成 GDScript DataManager 数据访问接口、批量内容验证管线
- Art Production 升级：支持动态资源变体生成（不同稀有度/等级的视觉差异）、自动化 QC 管线
- Sound Designer 升级：支持动态音乐系统（根据游戏状态实时混音/切换层）、批量 SFX 变体生成、响度自动标准化管线
