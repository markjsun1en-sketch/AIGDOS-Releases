# ltm/cross_project/ — Cross-Project Memory Domain

> **Scope**: experiences, patterns, and anti-patterns that have been validated
> on **multiple projects** and are explicitly de-projectified. Unlike
> `project/<id>/`, entries here must contain no project-specific IDs, file
> paths, or sprint identifiers.
>
> **Introduced**: v4.90 Batch 8 Step 8.1 (2026-05-13)

---

## Eligibility

An entry lands here only when:

1. It has been observed and fixed on **≥ 2 projects**
2. Both source entries (in `project/<id>/` or `failures/`) are referenced
   via `evidence_ref[]`
3. Human approver signs off via `promote_memory_candidate.py --to cross_project`

## Lifecycle

```
project/<A>/ or failures/  ─┐
project/<B>/ or failures/  ─┴─→ _quarantine/ (candidate)
                                    │
                                    │ approver + evidence_ref ≥ 2
                                    ▼
                            cross_project/  (this dir)
```

## Read path

- `consult(query, domain="cross_project")` — explicit narrow
- Default included in every project scope via "missing ≡ global" semantic
  (see `ltm/INDEX.md` Phase 4 M9.5 Layer A)

## Write path

Only via `scripts/ltm/promote_memory_candidate.py` (v4.90 Batch 8 Step 8.5).
Direct manual writes into this directory are discouraged — they bypass the
cross-domain gate (approver + ≥ 2 evidence_ref).

## Populated in

- v4.90 Batch 8.1 — directory + README only (no entries yet). The
  CLI write path (`ai-dev-os ltm promote --to cross_project`) landed
  in Batch 11; first real entries expected once a multi-project
  promotion workflow exercises it (Batch 12+).
- v4.91 B4 c3 — split into 4 sub-dirs to match Shared LTM v3 routing
  scopes (each .gitkeep documents its sub-scope):
    - `candidates/`        → scope=unapproved_candidates (default-excluded)
    - `approved_patterns/` → scope=approved_cross_project (default-included, boost 0.8)
    - `rejected/`          → scope=rejected (default-excluded; audit only)
    - `superseded/`        → scope=superseded (default-excluded; audit only)
  Files at the top level (not in a sub-dir) continue to map to
  scope=approved_cross_project for backward compatibility.

## Related

- `ltm/INDEX.md` — global index of all 7 domains (8 with v4.91 preflight)
- `ltm/preflight/README.md` — sibling preflight domain (v4.91 B4 c3)
- `docs/15_ltm_v2/MEMORY_DOMAINS_v2.md` — full v2 taxonomy (Batch 8.8)
- `docs/22_ltm_v3/SHARED_LTM_V3_OVERVIEW.md` — v3 read routing (v4.91 B4 c4)
- `docs/15_ltm_v2/PROMOTION_WORKFLOW.md` — promotion pipeline (Batch 8.8)
- `config/memory_retrieval_routing_v2.yaml` — v2 priority routing (Batch 8.7)
- `ltm/retrieval_policy.yaml` — v3 scope-level routing (v4.91 B4 c2)
