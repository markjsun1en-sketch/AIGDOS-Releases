---
captured_at: 2026-05-07T09:05:00Z
actor: ep_phase_4_m9_5_synthesis
gate: passed
evidence_ref: "synthesized seed — Phase 4 M9.5 Layer A cross-project LTM seed; basis = RH sprint review postmortem 2026-03 writeback owner miswire"
project_id: rh
---
# Writeback owner drift — adapter silently claimed orchestrator events

## Symptom

During an RH sprint review the audit log showed every `orchestrator.*`
event carrying `actor="adapter_worker"` instead of the orchestrator
agent name. The verify step never flagged it because the envelope
contract requires `actor` to be non-empty, not to match a specific
layer.

```
"event_type": "orchestrator.task_dispatch",
"source_layer": "orchestrator",
"actor": "adapter_worker",
"audit_status": "ok"
```

The sprint retro could not reconstruct who made dispatch decisions.

## Root Cause

A helper function added in the adapter module —
`emit_through_writeback(event)` — defaulted `actor` to its own process
identity ("adapter_worker") when the caller did not pass one
explicitly. Orchestrator call sites had been added gradually and three
of them forgot to pass `actor=self.agent_id`. The helper silently
adopted its own identity for them, overwriting the caller's implicit
context.

Classic **scope creep** — a helper meant to wrap a single side effect
also took responsibility for a field that should belong to the caller.

## Fix

1. `emit_through_writeback()` stopped defaulting `actor`. Calls that
   fail to pass it now raise `TypeError` instead of silently
   substituting adapter identity.
2. The three orchestrator call sites were updated to pass
   `actor=self.agent_id` in the same commit.
3. A regression test seeds an orchestrator event without `actor`
   and asserts the helper refuses to write it.

## Commit refs

- **Trigger commit**: the adapter helper extraction commit (PR-192).
- **Fix commit**: the orchestrator writeback audit commit (PR-204).
- **Regression test**: `test_writeback_requires_actor` added alongside
  the fix.

## Lesson

Helpers should fail loudly on missing caller context, not paper it
over with their own identity. "Default = your identity" is an
attractive trap because it makes early prototypes work with less
boilerplate; it makes late-stage debugging impossible.

## Related rules

- [helper_scope_boundary](../../os/helper_scope_boundary.md) — the
  general anti-promotion rule this incident instantiates.
- [envelope_9_field_contract](../../os/envelope_9_field_contract.md)
  — the contract says `actor` is required but says nothing about who
  sets it; that gap is where this bug lived.
