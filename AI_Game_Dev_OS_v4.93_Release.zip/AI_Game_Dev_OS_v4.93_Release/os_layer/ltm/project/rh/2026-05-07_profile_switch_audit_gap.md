---
captured_at: 2026-05-07T09:10:00Z
actor: ep_phase_4_m9_5_synthesis
gate: passed
evidence_ref: "synthesized seed — Phase 4 M9.5 Layer A cross-project LTM seed; basis = RH profile migration audit 2026-02 (workbuddy_private → codex dry-run)"
project_id: rh
---
# Profile-switch audit gap — state carried over, profile did not

## Context

During an RH experimental dry-run the project was migrated from the
`workbuddy_private` profile to `codex`. The profile JSON was swapped,
`init_runtime_env.py` was re-run, and the sprint driver started. Two
hours in, the cross-check emitted zero ERROR / zero WARN — which was
impossible given that `coordination_model` expected by the two
profiles differs (`managed_autonomy` vs `direct_orchestration`).

## Root Cause

`init_runtime_env._stub_init` wrote `coordination_model` into the
`runtime_state.json` only when the key was absent. A stale
`runtime_state.json` from the prior profile already contained
`coordination_model="managed_autonomy"`, so the switch to `codex` left
the state file reading the old value — and cross-check compared the
new profile's JSON against the old profile's state, found them
"equal" (because the comparison short-circuited on the stale value),
and stayed silent.

The silent-PASS had two layers:

1. State was stale — init was non-destructive.
2. Cross-check used `if field in state` as a gate — so even a stale
   mismatch was never surfaced.

## Fix

Applied as part of Phase 4 M7.3 "Lift gate" (v4.89 upstream):

1. `_stub_init` canonically writes the full contract surface on every
   init invocation. Stale values get overwritten.
2. Cross-check dropped the `if field in state` short-circuit — the
   field must now exist AND match the profile JSON.

After the fix, the same profile-switch rerun emitted two ERRORs and
blocked the sprint until the EP confirmed the profile change.

## Lesson

Silent-PASS has two independent sources: stale upstream data and
over-defensive downstream gates. Both need closing or the bug hides
in whichever layer still tolerates absence.

## Cross-project relevance

This is tagged to RH because it first surfaced in an RH profile
migration, but the fix lives in the OS runtime — any project using
the OS inherits the hardened init + cross-check. Future projects that
change their profile mid-sprint should not hit this.

## Related rules

- [malformed_audit_fallback](../../os/malformed_audit_fallback.md)
  — the broader anti-silent-drop policy.
- v4.89 `runtime/MATURITY_MATRIX.md` §3.5 "M7.3 lift gate" — the OS
  commit that fixed the downstream layer.
