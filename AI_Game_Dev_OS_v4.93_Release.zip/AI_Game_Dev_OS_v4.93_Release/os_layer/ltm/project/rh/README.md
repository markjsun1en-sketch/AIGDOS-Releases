---
project_id: rh
---
# ltm/project/rh — RandomHeroes Project Experience

Sprint-level handoff patterns, failure postmortems, and concrete
technology lessons surfaced during RandomHeroes sprint operations.

## Inventory

| File | Type | Summary |
|---|---|---|
| `2026-05-07_sprint_close_handoff_pattern.md` | pattern | Six-slot handoff data structure for sprint close → next-thread resume |
| `2026-05-07_writeback_owner_drift.md` | failure | Adapter helper silently claimed orchestrator `actor` when caller omitted it |
| `2026-05-07_profile_switch_audit_gap.md` | failure | Profile migration silent-PASS — stale state + short-circuit gate masked mismatch |
| `2026-05-07_mirror_trial_workspace_cold_start.md` | failure | Mirror manifest staleness from a cache file bridging "copy" and "regenerate" semantics |

## Namespace

Every file in this directory carries `project_id: rh` in its YAML
front-matter (see Phase 4 M9.5 `consult()` / `capture()` semantics).
Entries here are **scoped to RandomHeroes** — a `consult(query,
project_id="rh")` call returns these plus any unscoped (global)
entries from `ltm/os/`, `ltm/pattern/`, `ltm/failures/`. A
`consult(query, project_id="other")` call does NOT return these
entries.

## Capture rule

`capture(domain='project', ..., project_id='rh')` is the only path
that writes into this directory. A capture that omits `project_id`
for `domain='project'` is routed to `ltm/_quarantine/` by Gate rule 5.
This guardrail prevents stray project postmortems from leaking into
the global pool and being mistaken for cross-project wisdom.

## Why these four

They exemplify the four failure-archetypes that RH sprints have
produced so far: a **pattern** that codifies operational discipline
(handoff), a **helper-scope** failure (writeback owner), a
**two-layer silent-PASS** failure (profile switch), and a
**cache-staleness** failure (mirror manifest). Together they seed a
representative project corpus for cross-project LTM consultation
without collapsing into a single failure mode.

## Referenced OS rules

Each entry cross-links to the relevant `ltm/os/*` contract that
either pre-existed the incident or was strengthened because of it.
Those cross-links are the **primary cross-project flow** — RH project
experience feeds back into OS-level hardened rules, which then apply
to every project using the OS runtime.
