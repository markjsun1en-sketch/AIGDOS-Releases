---
captured_at: 2026-05-07T09:00:00Z
actor: ep_phase_4_m9_5_synthesis
gate: passed
evidence_ref: "synthesized seed — Phase 4 M9.5 Layer A cross-project LTM seed; basis = distilled RH sprint-close operational record 2026-04 through 2026-05"
project_id: rh
---
# Sprint-close Handoff Pattern (RH)

## Context

RH project runs ~2-week sprints. At each sprint close the EP hands the
driver state, open blockers, and the next-sprint hypothesis from one
thread to the next. Before this pattern was codified the handoff was
an ad-hoc free-form note, which twice left the incoming thread without
the commit anchor / tag needed to resume.

## Pattern

The handoff payload is a single markdown block with six fixed slots:

1. **Anchor** — `git log --oneline -1` at close time + the most recent
   tag (e.g. `v4.89-phase-4-skills @ 66c8024`).
2. **Pytest baseline** — exact passed count (`251 passed`) and the
   test command used to obtain it.
3. **Byte-lock state** — v4.88_Release SHA verified + file count
   (539 files / 0 FAILED).
4. **Open task IDs** — short list of milestone tokens still pending
   (e.g. `M9.5.3`, `M10.0.1`).
5. **Next-thread first move** — the single command the next thread
   should run first (usually a 5-step baseline verification block).
6. **EP open questions** — any unresolved decisions that block the
   next move, each marked with the date they were raised.

## Why it works

Each slot maps 1-to-1 to a question the incoming thread will ask in
its first minute. Skipping any slot forces an exploratory round-trip
that the EP has already answered; keeping them uniform makes the
handoff greppable across sprints.

## Anti-patterns observed

- **Anchor only, no tag** — the commit hash is ambiguous without the
  tag context; threads spent minutes reconciling which tag was in play.
- **Baseline by prose** — "all tests pass" instead of a number masks
  regressions that landed between sprints.
- **Next-move buried in discussion** — when the first move is phrased
  as "we should probably …" the incoming thread often picks a
  different first move and diverges.

## Evidence

Captured as a cross-project lesson because the same six-slot discipline
applies verbatim to the OS workspace itself (see v4.89 Phase 4
`V4_89_PHASE_4_PLAN.md` §七 handoff checklist — identical structure).
The pattern is project-tagged here because the drive for codifying it
came from an RH sprint-close review; adoption in the OS workspace was
a later copy-over.

## Lesson

A handoff is a data structure, not a narrative. Fix the slots, let
the content vary.
