---
captured_at: 2026-05-07T09:15:00Z
actor: ep_phase_4_m9_5_synthesis
gate: passed
evidence_ref: "synthesized seed — Phase 4 M9.5 Layer A cross-project LTM seed; basis = RH cold-start regression 2026-04 mirror_trial_workspace drift"
project_id: rh
---
# Mirror trial-workspace cold-start drift — registry missed new hook

## Symptom

After the RH project enabled a new sprint-close hook
(`sprint_context_rollup`), cold-start on a fresh mirror workspace
reported a missing manifest entry. The driver raised:

```
RuntimeError: cold_start_manifest is missing entry 'sprint_context_rollup'; declared in registries/hooks_registry.json but absent from manifest
```

A hand-regenerated mirror did not reproduce the issue on the EP's
primary workspace; only the mirror was broken.

## Root Cause

`mirror_trial_workspace.py` copies the registry JSONs byte-for-byte
from the source workspace but regenerates the cold-start manifest
locally (the manifest is a derivation of `(profile JSON, hook
registry, skill pack)` at mirror time). The manifest generator had a
cache file that was stamped with the last source mtime; when the
source advanced past the mirror's cached mtime, the mirror skipped
regeneration and kept the stale manifest.

The source workspace did not reproduce because its cache was the
primary writer of the file — always fresh by construction.

## Fix

1. `mirror_trial_workspace.py` forces manifest regeneration on every
   mirror pass (`--force` semantics became the default for manifests;
   opt-out requires an explicit `--skip-manifest` flag).
2. The cache file was moved from the mirror root into the mirror's
   `.trial_cache/` directory so it is clearly mirror-local and never
   confused with the source.
3. A cold-start smoke test runs on mirrors and fails if the manifest
   is older than any of its input sources.

## Commit refs

- **Trigger**: the sprint_context_rollup hook registration commit
  (RH sprint 12).
- **Fix**: the mirror manifest force-regen commit (RH sprint 12 +2).
- **Regression test**: `test_mirror_manifest_fresh_or_fail` added
  alongside the fix.

## Lesson

"Copy byte-for-byte" and "regenerate locally" are two different
mirror semantics. When a single mirror invocation mixes both, the
cache that bridges them becomes a silent staleness source. The
safe default is to regenerate aggressively and let the user opt
into copy-for-speed.

## Related rules

- [malformed_audit_fallback](../../os/malformed_audit_fallback.md)
  — same anti-silent-drop family; this time applied to manifest
  staleness instead of envelope drops.
- v4.89 `runtime/MATURITY_MATRIX.md` §3.7 "M9.0 cold-start" — the
  OS-level cold-start pack that inherited this lesson.
