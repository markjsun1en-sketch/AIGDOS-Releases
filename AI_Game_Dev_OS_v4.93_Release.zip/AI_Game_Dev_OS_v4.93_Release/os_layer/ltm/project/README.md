# ltm/project — Project Experience domain

Per-project sprint history, handoff patterns, concrete technology choices.

## Write policy

- **Primary author**: project EP / Sprint Close orchestrator.
- **Gate**: `evidence_ref` is **required** (Sprint ID / commit sha / TAPD story ID / audit event_id).
- **Gate (Phase 4 M9.5)**: `project_id` is **required** for any capture into this domain. A missing or blank value routes the payload to `_quarantine/` (Gate rule 5).
- **Directory layout**: `project/<project_id>/<topic>.md`; a new project creates its own subdirectory.
- **`<project_id>`**: lower snake_case, matching the `project_id` field in `runtime_state.json`. The same value appears in the entry's YAML front-matter as `project_id: <id>`.

## Registered projects

- `rh/` — RandomHeroes (touched during Phase 1, Sprint 8+ / Slot + Roguelike + Idle + Extract). Phase 4 M9.5 added four synthesized seed entries — see `rh/README.md`.

## Cross-project inheritance (Phase 4 M9.5 Layer A)

`consult(query, project_id="rh")` — and the equivalent CLI
`python -m runtime.ltm "query" --project rh` — returns:

1. Every hit in `project/rh/` (entries whose `project_id` matches the filter).
2. Every hit in `os/`, `pattern/`, `failures/` that does NOT carry a `project_id` field (treated as **unscoped / global** — the "missing ≡ global" semantic).

Entries explicitly tagged with a *different* `project_id` are excluded
from the result set.

This is the Layer A skeleton. It does NOT auto-merge, auto-rank,
or auto-suggest across projects — those belong to Layer B / C (not in
v4.89 scope). To borrow an entry from another project, run
`consult(..., project_id="other")` explicitly and adapt by hand.

## consult examples

```bash
python -m runtime.ltm "sprint close" --domain project
python -m runtime.ltm "handoff" --project rh
python -m runtime.ltm "writeback owner" --project rh --limit 3
```
