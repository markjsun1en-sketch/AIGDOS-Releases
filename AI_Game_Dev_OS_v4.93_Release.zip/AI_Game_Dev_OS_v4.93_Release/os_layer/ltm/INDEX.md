# LTM (Long-Term Memory) — v4.90

> **Purpose**: the retrievable experience layer of AI Game Dev OS v4.90. Before starting a piece of work, an agent can check "has something similar been done / failed / corrected before?", and after finishing, can lay down the new experience into this layer — **without polluting the main line, without replacing canonical truth, without silently overriding evidence**.
>
> **Introduced in**: v4.89 Phase 2 Stage 1 (from 2026-05-03), tag `v4.89-phase-2-m5`
> **Extended in**: v4.90 Batch 8 Step 8.1 (2026-05-13) — 5 → 7 domains (+`cross_project/`, +`working/`)
> **Policy source**: `config/memory_retrieval_routing_v2.yaml` (v4.90 Batch 8.7) — legacy `config/memory_retrieval_policy.yaml` (v4.89) still loads
> **Engine source**: `runtime/ltm/` (inherited from v4.89)
> **Whitepaper**: `.workbuddy/plans/electric-forging-babbage.md` (Kai, 2026-05-02)

---

## 7 domains (v4.90)

| Domain | Stores | Written by | Example |
|---|---|---|---|
| **os/** | OS-level rules, pitfalls, and best practices that cross generations and projects | OS maintainer / phase-close commit | envelope 9-field contract / pointer shim is a read-side shim |
| **project/\<id\>/** | Per-project sprint history, handoff patterns, concrete technology choices | project EP / sprint close | RH project Sprint 8 added Sound Designer Agent |
| **pattern/** | Reusable design patterns that generalise across projects | whoever discovers, writes it | `_ev_get(event, k, default)` envelope-aware read |
| **failures/** | Concrete error → root cause → fix pairs | postmortem commit | A4 first-run FAIL / root cause: verify read flat root / fix: A5 `_ev_get` |
| **cross_project/** *(v4.90)* | Patterns validated on ≥ 2 projects, de-projectified | `promote_memory_candidate.py --to cross_project` only | "envelope contract works on projects A & B" |
| **working/** *(v4.90)* | Session-local raw notes, pre-validation | any agent, freeform | draft findings before extract |
| **_quarantine/** | Landing zone for candidate payloads before human review; also Gate-rejected entries | extract / promote scripts / Gate rejections | schema-pending ff candidates |

**Lifecycle summary**: `working/` → `_quarantine/` → canonical domain (via `promote_memory_candidate.py` gate).

---

## 3 entry points

### 1. Read — `consult(query, domain=None, limit=10, project_id=None)`

```python
from runtime.ltm import consult

hits = consult("envelope contract")                    # all domains
hits = consult("closed_at", domain="failures")         # narrow
hits = consult("pointer shim", limit=3)                # cap
hits = consult("handoff", project_id="rh")             # Phase 4 M9.5 — namespace filter
```

Each hit: `{"path", "domain", "title", "excerpt", "score"}`.

**Phase 4 M9.5 Layer A — namespace filter (`project_id`)**:

- `None` (default) → pre-M9.5 behaviour; every scored hit returned.
- `"<id>"` → keep entries tagged with the same `project_id` AND untagged entries ("missing ≡ global" semantic). Entries tagged with a *different* project are excluded.

The "missing ≡ global" rule preserves the 19 legacy entries (all untagged) as cross-project OS wisdom, visible under every project-scoped query.

**CLI wrapper**:
```bash
python -m runtime.ltm "envelope contract"
python -m runtime.ltm "closed_at" --domain failures
python -m runtime.ltm "pointer shim" --limit 3 --json
python -m runtime.ltm "handoff" --project rh            # Phase 4 M9.5
```

### 2. Write — `capture(domain, title, content, *, evidence_ref=None, actor="main_session", requires_approval=False, project_id=None)` (gated)

```python
from runtime.ltm import capture

result = capture(
    domain="failures",
    title="A4 dry_run_fail",
    content="... RCA / Fix / Lesson ...",
    evidence_ref="commit 7a72ea6",
)
# result = {"path": "ltm/failures/a4_dry_run_fail.md", "gate": "passed", ...}

# Phase 4 M9.5 — project-domain capture requires project_id
result = capture(
    domain="project",
    title="Sprint 12 retro",
    content="...",
    evidence_ref="commit abc1234",
    project_id="rh",                                    # required for domain='project'
)
# → ltm/project/rh/sprint-12-retro.md
```

**Gate rules** (v4.89, Phase 4 M9.5 adds rule 5):
1. `domain` must be in the policy's `memory_domains` (OS / Project / Pattern_Capability / FailureFix).
2. Non-OS domains must carry `evidence_ref`.
3. `canonical_override_block: true`: OS-domain content that mentions the words "canonical" / "override" triggers a soft WARN but still passes (Phase 3 will tighten this).
4. `requires_approval=True` unconditionally routes the payload to quarantine.
5. **[Phase 4 M9.5]** `domain='project'` without `project_id` routes to quarantine. Non-project domains accept `project_id` as an optional tag.

### 3. Replay — `ltm.replay()` — **Phase 3 Self-Evolution** (not in MVP)

---

## Hard rules

- ❌ **`canonical_override_block: true`** — experience may never silently override canonical truth.
- ❌ No vector search / LLM summary / database dependency.
- ❌ Do not read `.workbuddy/memory/` (that is Kai's private memory, not OS LTM).
- ❌ Do not pollute the main line, do not break the 11 permanent Phase 1 contracts.

---

## Directory map

```
ltm/
├── INDEX.md                 ← this file
├── os/                      ← OS Experience domain (seeded with 10 Phase 1 permanent contracts)
│   └── README.md
├── project/                 ← Project Experience domain
│   ├── README.md
│   └── rh/                  ← RH project (the only project touched during Phase 1)
├── pattern/                 ← Pattern Experience domain
│   └── README.md
├── failures/                ← Failure-Fix Cases domain (seeded with A4 + Z1 postmortems)
│   └── README.md
└── _quarantine/             ← Gate-rejected staging zone (content is reviewed by hand before it moves out)
    └── README.md
```

---

## Engine API quick reference

| Symbol | Location | Purpose |
|---|---|---|
| `consult(query, domain=None, limit=10, project_id=None)` | `runtime.ltm.consult` | Keyword search (Phase 4 M9.5 adds `project_id` filter) |
| `capture(domain, title, content, *, evidence_ref=None, actor="main_session", requires_approval=False, project_id=None)` | `runtime.ltm.capture` | Gated append of experience (Phase 4 M9.5 adds Gate rule 5) |
| `GATE_STATUS_PASSED` / `GATE_STATUS_BLOCKED` | `runtime.ltm` | Result status constants |
| `KNOWN_DOMAINS` | `runtime.ltm` | Domain allowlist loaded from policy |

---

## Cross-project namespace (Phase 4 M9.5 Layer A)

Since 2026-05-07 the LTM runtime supports a lightweight cross-project namespace — the `project_id` YAML front-matter field. Summary:

- **Missing ≡ global** — an entry without `project_id` is visible to every project-scoped query. All 19 pre-M9.5 entries follow this rule.
- **Layer A only** — namespace + cross-ingest skeleton. NOT in scope: vector retrieval, self-evolution, multi-project auto-merge. See `docs/06_runtime_profiles/PHASE_4_M9_5_CROSS_LTM_AUDIT.md` for the Layer A/B/C decision tree.
- **Capture routing** — `capture('project', ..., project_id='<id>')` writes to `ltm/project/<id>/<slug>.md`. Missing `project_id` on `domain='project'` quarantines the payload (Gate rule 5).
- **Registered projects** — `rh/` (4 synthesized seed entries from M9.5.3; see `ltm/project/rh/README.md`).

---

## Life cycle

- **Phase 2 Stage 1 (MVP)**: consult + capture + Gate + seed 12 initial entries. ✅ Shipped at tag `v4.89-phase-2-m5`.
- **Phase 2 Stage 2**: 5-profile parity hardening — appends new pitfalls / patterns discovered per profile. ✅ Shipped at tag `v4.89-phase-2-stage-2-b1` onward.
- **Phase 4 M9.5 Cross-Project LTM Layer A**: namespace + cross-ingest skeleton. ✅ Shipped 2026-05-07 (pending tag `v4.89-phase-4-cross-ltm`). See the "Cross-project namespace" section above.
- **v4.90 Batch 4 (Failure-Fix schema formalisation)**: ✅ Shipped 2026-05-10. Adds Failure-Fix Memory schema (`schemas/ltm/failure_fix_memory.schema.json`) + offline validator (`scripts/ltm/validate_failure_fix_entry.py`) + first v4.90-onward seed entry `ff_2026_001` (cross-version baseline upgrade failure). v4.89-shipped entries grandfathered with WARN-only treatment. Engine in `runtime/ltm/` is FROZEN. See [`docs/15_ltm_v2/`](../docs/15_ltm_v2/) for the schema rules + Layer B FTS5 design.
- **v4.90 Layer B (FTS5 retrieval)**: opt-in SQLite FTS5 ranking on top of substring matcher; API-compatible. See `docs/15_ltm_v2/LAYER_B_OVERVIEW.md`. Implementation in v4.90 Batch 4 Step 4.5.
- **v4.90 Layer C (deferred)**: self-evolution — semi-automatic mining of failure-fix candidates from `audit.jsonl`; `replay()` across multiple projects; auto-promotion of cross-project patterns. Deferred to v4.90 Batch 6.
