---
captured_at: 2026-05-03T22:45:00Z
actor: kai_phase_1_operator
gate: passed
evidence_ref: "MEMORY.md §7.8.3 rule #6 + §7.9 rule #11 / commit 258af9f / commit 978a5fd"
---
# `runtime_state.json` Path Contract (canonical + pointer shim + write-side rule)

## Rule

### 1. Canonical location

`<workspace>/runtime/state/runtime_state.json` — from v4.89 onward the single canonical location, colocated with `tapd_config_instance.json`.

### 2. Root pointer shim

`<workspace>/runtime_state.json` is not real state; it is a **pointer shim**:

```json
{
  "_moved_to": "runtime/state/runtime_state.json",
  "canonical": true,
  "_hint": "v4.89 P0-C C4"
}
```

### 3. Read-side resolver

`scripts/verify_beta_sprint_exit.py::_resolve_state_path(requested) -> Path`:

1. If the requested path is a pointer carrying `_moved_to`, follow it to canonical.
2. If the requested path is `<ws>/runtime/state/runtime_state.json` but the file does not exist AND `<ws>/runtime_state.json` holds real state (pre-C4 legacy workspace), fall back to the root.
3. Otherwise, return the path unchanged.
4. **Never raise** — I/O exceptions silently degrade.

### 4. Write-side rule (v4.89 P0-Z Z1 law / MEMORY §7.9 rule #11)

**Any code path that writes `runtime_state` must target canonical**:

```python
canonical = ws / "runtime/state/runtime_state.json"
legacy = ws / "runtime_state.json"
state_path = canonical if canonical.exists() else legacy  # fallback is for pre-C4 only
state = json.loads(state_path.read_text())
state["closed_at"] = ts(125)
state_path.write_text(json.dumps(state, indent=2))
```

**Forbidden** (this actually happened in Phase 1 Z1):

```python
# ❌ BUG illustration
state_path = ws / "runtime_state.json"  # root is a pointer, not real state!
state = json.loads(state_path.read_text())  # reads pointer JSON
state["closed_at"] = ts(125)                # appends a field to the pointer
state_path.write_text(json.dumps(state))    # overwrites the pointer with real state
# → the pointer shim vanishes, the next verify cannot find canonical, W3 regresses
```

## Principle

> **Pointer shim is read-side compatibility, not a write-side substitute.**
> Reads go through `_resolve_state_path`; writes always target canonical.

## Three workspace shapes

1. **canonical-only**: only `runtime/state/runtime_state.json` exists; root is empty (very rare).
2. **pointer + canonical**: the `init_runtime_env` output (the v4.89 standard shape).
3. **root-only (legacy)**: pre-C4; root holds the real state (`init --force` migrates it).

## Related rules

- [workspace package_root fallback](./workspace_package_root_fallback.md)
- [failures: 2026-05-02_z1_closed_at_null](../failures/2026-05-02_z1_closed_at_null.md) — consequences of violating this rule.
