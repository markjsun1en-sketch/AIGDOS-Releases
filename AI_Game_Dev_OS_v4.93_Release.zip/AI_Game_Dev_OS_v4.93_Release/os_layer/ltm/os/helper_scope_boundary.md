---
captured_at: 2026-05-03T22:45:00Z
actor: kai_phase_1_operator
gate: passed
evidence_ref: "MEMORY.md §7.8.2 rule #5"
---
# Helper Scope Boundary (the contract-creep hard rule)

## Rule

The defensive helpers introduced in Phase 1 (`wrap_external_record` / `_ev_get` / `_resolve_state_path` / `_resolve_checklist_path` / `_handle_failure`) **must not**:

1. ❌ Auto-**promote** fields to envelope root.
   - Example: a helper may not "notice that `task_id` lives in `details` and copy it to root for you".
   - Reason: field location is the caller's contract; if the helper promotes behind the caller's back, the caller can no longer tell where a field really lives → field uniqueness is lost.
2. ❌ Auto-**demote** envelope fields into `details`.
   - Example: a helper may not "tidy up" a root `task_id` by moving it into `details`.
   - Reason: same as above, plus it breaks audit integrity (the same event diffs against itself over time).
3. ❌ Silently **correct** envelope content.
   - Example: a helper may not "notice the timestamp format is off and fix it to ISO for you".
   - Reason: the envelope is the caller's responsibility; corrections must happen explicitly on the caller side.

## What a helper is allowed to do

✅ Read-only parsing (`_ev_get` / `_resolve_*_path`).
✅ Side-channel failure fallback to quarantine / malformed (does not mutate the original envelope).
✅ Producing **new** envelopes (`wrap_external_record` — it is a factory, not a mutator).
✅ Never raise (I/O errors must silently degrade).

## Where this rule comes from

During the Phase 1 A5 discussion, Kai's candidate plan C proposed "let the helper auto-promote queried keys to root" — EP vetoed it. Reason: that would force the helper to know which keys the consumer cares about → responsibility drift → contract creep.

The plan that was eventually adopted (option B, the read-side `_ev_get`) does not trigger promotion and is the concrete fulfilment of this rule.

## Related rules

- [envelope 9-field contract](./envelope_9_field_contract.md)
- [ev_get envelope-aware read](./ev_get_envelope_aware_read.md)
- [top_level deprecation rule](./top_level_deprecation_rule.md)
