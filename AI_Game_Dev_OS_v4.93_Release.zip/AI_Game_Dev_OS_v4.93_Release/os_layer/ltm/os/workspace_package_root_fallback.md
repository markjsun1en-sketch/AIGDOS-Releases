---
captured_at: 2026-05-03T22:45:00Z
actor: kai_phase_1_operator
gate: passed
evidence_ref: "MEMORY.md §7.8.3 rule #8 / commit b36376a / commit 1d080e0"
---
# Workspace → Package Root Fallback Rule

## Rule

A partially-assembled workspace (only `runtime/state/` populated, with `config/` / `docs/` not yet ported) must still be able to find reference assets in the **package root** (i.e. the `AI_Game_Dev_OS_v4.89/` root).

## Fallback sites already implemented

| Asset | Caller | Lookup order |
|---|---|---|
| Profile JSON | `scripts/run_beta_sprint_check.py::check_profile_validity` | `<ws>/config/profiles/<profile>.json` → `<ROOT>/config/profiles/<profile>.json` → error |
| `sprint_close_checklist.md` | `scripts/verify_beta_sprint_exit.py::_resolve_checklist_path` | `<ws>/docs/09_beta_sprint/sprint_close_checklist.md` → `<ws>/runtime/state/sprint_close_checklist.md` → requested path as-is |

## Findings must include a `source` field

When a fallback is hit, the finding must carry a `source` field that names the origin:

```json
{"check": "profile.parse", "source": "workspace", "status": "ok", ...}
{"check": "profile.parse", "source": "package_root", "status": "ok", ...}
```

This lets the operator tell whether the checker is reading the workspace copy or the package copy.

## Not allowed

- ❌ Silent fallback (no log, no source tag).
- ❌ Falling back without recording it — the operator cannot tell whether a workspace override exists.
- ❌ Cross-project fallback for convenience (e.g. borrowing assets from `AI_Game_Dev_OS_v4.88_Release/`) — pre-Phase-4, OS packs do not share.

## Phase 2 Stage 2 evolution

Planned: add a `--require-workspace-assets` CLI flag (default False); in strict mode, package-root fallback is disabled. This lets a "fully assembled" workspace prove its assets are self-contained.

## Related rules

- [runtime_state_path_contract](./runtime_state_path_contract.md)
- [three_workspace_shapes](./three_workspace_shapes.md)
