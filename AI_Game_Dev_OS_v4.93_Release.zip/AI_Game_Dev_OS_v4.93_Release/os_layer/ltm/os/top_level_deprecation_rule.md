---
captured_at: 2026-05-03T22:45:00Z
removed_at: 2026-05-10T12:50:00Z
actor: kai_phase_1_operator
gate: passed
status: REMOVED
evidence_ref: "MEMORY.md §7.8.2 rule #4 / commit 7a72ea6 / commit b08d4bb / v4.90 Batch 0 Step 2 (this commit)"
---
# `top_level=` Soft Deprecation — REMOVED IN v4.90

> **Status as of v4.90 Batch 0 Step 2 (2026-05-10)**: the `top_level=` kwarg
> has been **physically removed** from `emit_wrapped` across all 9
> `trial_workspaces/rh_sprint_sim_01*/run_sprint.py` files plus the
> docstring reference in
> `runtime/observability/runtime_event_collectors/_base.py`. Read-side
> consumers now rely exclusively on `_ev_get` envelope-aware lookup
> (root → details.* → default).

## Original Rule (kept for audit lineage)

The `top_level=` kwarg on `trial_workspaces/rh_sprint_sim_01/run_sprint.py::emit_wrapped` was **soft-deprecated** since v4.89 Phase 1 A5:

```python
def emit_wrapped(record, *, ..., top_level: dict | None = None, ...):
    """
    ...
    top_level: DEPRECATED since v4.89 P0-A A5. Mirrors specified keys
    to envelope root for flat-shape readers. Removed in Phase 2+
    once all consumers are _ev_get-aware.
    """
```

## Why it was kept (during v4.89)

- Parts of the B+ ecosystem still had flat-shape `audit.jsonl` consumers that had not yet moved to `_ev_get`.
- Removing the kwarg would break the verify read path on older trial workspaces.
- The Phase 1 priority was Tier2 Beta hardening, not an immediate tech-debt sweep.

## Why it had to go

- The field got written in two places (root + details) → field-uniqueness ambiguity.
- Consumers had multiple "right answers" for where to read → a bug breeding ground.
- In real cross-project replay, double-writes produced diff noise.

## v4.90 Batch 0 Step 2 — actual removal record

Confirmed before removal:
- `_ev_get` exists at `scripts/verify_beta_sprint_exit.py` L317 with documented fallback chain `root → details.* → default`.
- All `top_level={...}` call-site contents (`task_id` / `object_id` / `verification_ok`) were already mirrored in adjacent `extra={...}` blocks → no field loss.
- 9 `trial_workspaces/.../run_sprint.py` files were byte-identical pre-removal.

Done in this commit:
1. `emit_wrapped` signature: `top_level: dict | None = None` parameter removed.
2. `emit_wrapped` body: `if top_level: for k, v in top_level.items(): envelope[k] = v` block removed.
3. `emit_wrapped` docstring: deprecated section replaced with v4.90 removal note.
4. 3 call sites in master `run_sprint.py`: `top_level={...}` blocks removed.
5. 8 trial workspace duplicates synced via byte-copy from master.
6. `_base.py` docstring `top_level=` retention bullet updated to "removed in v4.90 Batch 0 Step 2".

## Related rules

- [envelope 9-field contract](./envelope_9_field_contract.md)
- [ev_get envelope-aware read](./ev_get_envelope_aware_read.md)
