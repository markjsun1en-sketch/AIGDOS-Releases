---
captured_at: 2026-05-03T22:45:00Z
actor: kai_phase_1_operator
gate: passed
evidence_ref: "MEMORY.md §7.8.3 rule #10 / commit 258af9f / V4_89_PHASE_2_TAKEOVER_PROMPT §8-1"
---
# Three Workspace Shapes

## Rule

From v4.89 onward, `init_runtime_env` and `verify_beta_sprint_exit` must both recognise three workspace shapes, each with a corresponding "detect → handle" rule:

### Shape 1 — canonical-only (clean)

```
<ws>/runtime/state/runtime_state.json   ← real state
<ws>/runtime_state.json                  ← does not exist
```

- **init**: does not support this shape (init always creates a pointer shim and never leaves canonical-only behind).
- **verify**: `_resolve_state_path(canonical_path)` returns the path unchanged.
- **When seen**: very rare; the state after a pointer is manually cleaned up.

### Shape 2 — pointer + canonical (the v4.89 standard)

```
<ws>/runtime/state/runtime_state.json   ← real state
<ws>/runtime_state.json                  ← {"_moved_to": "runtime/state/...", "canonical": true}
```

- **init**: this is the default `init_runtime_env` output.
- **verify**: `_resolve_state_path(pointer_path)` follows to canonical.
- **When seen**: every v4.89 freshly-initialised workspace.

### Shape 3 — root-only (legacy)

```
<ws>/runtime/state/                      ← directory missing or empty
<ws>/runtime_state.json                  ← real state (pre-C4)
```

- **init (no `--force`)**: blocks and prints `re-run with --force to migrate`.
- **init `--force`**: migrates to Shape 2.
- **init (interrupted state)**: even when blocked, preserve the pre-C4 "recovery hint" text (`closed_at=null` / `tasks in_progress` → hint `reconcile_external_state.py`); do not drop it just because C4 tightened the contract.
- **verify**: `_resolve_state_path(canonical_path)` falls back to the root real state.
- **When seen**: v4.88-and-earlier workspaces, or data hand-copied from an older pack.

## Key invariants

1. **init's three-shape dispatch must live in a single function** — `_detect_existing_state(target, force, *, legacy_root=None)` handles all three; callers must not be asked to check separately.
2. **A stale pointer is not "existing"** — when the pointer exists but canonical does not, treat the workspace as "uninitialised" so init is allowed to proceed; otherwise a seeded workspace would be mis-detected as already initialised and never progress.
3. **The legacy interrupted hint must reappear in Case (c)** — C4 must not drop the pre-C4 recovery hint just because the contract was upgraded (otherwise `_smoke_init_runtime_env.py` case 7 breaks).

## Not allowed

- ❌ Recognising only Shapes 1-2 → pre-C4 workspaces cannot verify; backwards compatibility is broken.
- ❌ Recognising only Shapes 2-3 → stale-pointer handling regresses, init gets stuck.
- ❌ New code paths that only target Shape 2 — every code path must handle all three.

## Related rules

- [runtime_state_path_contract](./runtime_state_path_contract.md)
- [workspace_package_root_fallback](./workspace_package_root_fallback.md)
