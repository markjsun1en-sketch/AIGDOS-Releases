---
captured_at: 2026-05-03T22:45:00Z
actor: kai_phase_1_operator
gate: passed
evidence_ref: "MEMORY.md §7.8.2 rule #3 / commit 7a72ea6"
---
# `_ev_get` Envelope-aware Read Contract

## Rule

Every audit-event consumer (`verify_beta_sprint_exit.py`, any future observability tool, any code that reads `mcp_audit.jsonl`) **must** read potentially-nested fields (e.g. `task_id` / `object_id` / `verification_ok`) via
`scripts/verify_beta_sprint_exit.py::_ev_get(event, key, default=None)`.

## `_ev_get` semantics

```python
def _ev_get(event: dict, key: str, default=None):
    # 1. envelope root takes priority (v4.88 B+ flat-shape compatibility)
    if key in event:
        return event.get(key, default)
    # 2. details.* fallback (v4.89 canonical envelope)
    details = event.get("details")
    if isinstance(details, dict) and key in details:
        return details.get(key, default)
    # 3. default
    return default
```

## Key invariants

1. **Root-first**: if root has a value, return it, **even if it is falsy** (`False` / `0` / `""`).
2. **Falsy preserved**: `verification_ok=False` must not be shadowed by `details.verification_ok=True` — this is the exact lesson from the Phase 1 A4/A5 pitfall.
3. **Never raise**: when `details` is a string / `None` / missing, **return default** rather than throwing.

## Not allowed

- ❌ Directly calling `event.get("task_id")` on adapter-sourced events (from v4.89 onward these fields live in `details.task_id`, not root).
- ❌ The opposite: `event["details"]["task_id"]` directly (breaks flat-shape compatibility).
- ❌ "Simplifying" `_ev_get` to raise `KeyError` — `never raise` is a non-negotiable part of the defensive pattern.

## Related rules

- [envelope 9-field contract](./envelope_9_field_contract.md) — the write-side counterpart.
- [failures: 2026-05-02_a4_dry_run_verify_fail](../failures/2026-05-02_a4_dry_run_verify_fail.md) — what happens when `_ev_get` is not used.
