# ltm/os — OS Experience domain

OS-level rules, pitfalls, and best practices that cross generations and projects.

## Write policy

- **Primary author**: OS maintainer (Kai or other OS-level Agents), usually at phase-close commit time.
- **Gate**: `evidence_ref` is not required (but citing `MEMORY.md §x.y` or a commit sha is strongly recommended).
- **`canonical_override_block: true`**: content in this domain **must not** be written to override canonical truth; if canonical must be corrected, the change goes through the OS maintainer's special approval flow.
- **File naming**: `<topic>_<rule_nature>.md` (e.g. `envelope_9_field_contract.md` / `driver_writes_canonical_rule.md`).

## Seed content origin

v4.89 Phase 2 Stage 1 M4.1 ported the 10 Phase 1 permanent contracts from `.workbuddy/memory/MEMORY.md` §7.8.2 / §7.8.3 / §7.9.

## consult examples

```bash
python -m runtime.ltm "envelope" --domain os
python -m runtime.ltm "pointer shim" --domain os
python -m runtime.ltm "profile alias" --domain os
```
