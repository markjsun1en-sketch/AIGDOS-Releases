---
captured_at: 2026-05-03T22:45:00Z
actor: kai_phase_1_operator
gate: passed
evidence_ref: "MEMORY.md §7.8.2 rules #1-#2 / plans/swift-forging-tesla.md §0 / commit addd2d6"
---
# Envelope 9-field Contract

## What is the envelope contract

From v4.89 onward, every audit event (at minimum every adapter-sourced event) must be a **9-field canonical envelope**:

| Field | Required | Source |
|---|---|---|
| `event_id` | yes | `uuid.uuid4()` string (36 chars) |
| `event_type` | yes | adapter's `event` / `event_type`, or the `kwarg` override passed to `wrap_external_record()` |
| `timestamp` | yes | `utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")`, with the trailing `Z` suffix |
| `actor` | yes | the initiator (default `"main_session"`) |
| `runtime_profile` | yes | `workbuddy_private` etc.; must be non-empty |
| `result` | yes | `ok` / `warn` / `fail`, or an adapter `result` / `status` fallback |
| `source_layer` | yes | `tapd` / `git` / `workbuddy` (**allowlist**; illegal values raise `ValueError`) |
| `audit_status` | yes | `pending` (default) / `emitted` / `failed` (silent-fail case) |
| `details` | yes | the full original adapter record, preserved loss-less |

## Not allowed

- ❌ Missing fields.
- ❌ Case variants of the same name (`Event_ID` / `eventID`).
- ❌ `None` / empty-string field values (`runtime_profile: ""` counts as missing).
- ❌ Hand-building an envelope that bypasses `wrap_external_record()` (the root cause of the Phase 1 A4 pitfall).

## Production path

**Single source**: `runtime/observability/runtime_event_collectors/workbuddy_collector.py::wrap_external_record(record, *, source_layer, runtime_profile, ...)`.

Every adapter-sourced event flows: `adapter` → this function → `append_audit()` → on disk.

## Related rules

- [ev_get envelope-aware read](./ev_get_envelope_aware_read.md) — the read-side counterpart.
- [malformed audit fallback](./malformed_audit_fallback.md) — what happens when envelope validation fails.
- [failures: 2026-05-02_a4_dry_run_verify_fail](../failures/2026-05-02_a4_dry_run_verify_fail.md) — consequences of not following this contract.
