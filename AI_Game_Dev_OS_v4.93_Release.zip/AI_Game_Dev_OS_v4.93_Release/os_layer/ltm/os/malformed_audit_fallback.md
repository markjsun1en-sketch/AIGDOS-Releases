---
captured_at: 2026-05-03T22:45:00Z
actor: kai_phase_1_operator
gate: passed
evidence_ref: "MEMORY.md §7.8.3 rule #9 / commit 95316c6"
---
# Malformed Audit Fallback (anti-silent-drop)

## Rule

When `runtime.observability.runtime_event_collectors.workbuddy_collector.append_audit()` runs in **non-strict mode** and hits envelope validation failure / JSON non-serialisable data / a write-side I/O error, it **must** drop the original raw record (annotated with reason + UTC time) into a **parallel sink**:

```
<workspace>/runtime/logs/mcp_audit.malformed.jsonl
```

## Per-record shape

```json
{
  "reason": "event envelope missing required fields: ['actor', 'result']",
  "recorded_at": "2026-05-03T22:45:00Z",
  "raw_record": {the original event, or repr() fallback}
}
```

## Key invariants

### 1. Filename separation
Canonical audit is `mcp_audit.jsonl`; the malformed sink is `mcp_audit.malformed.jsonl`. Different filenames mean `verify_beta_sprint_exit._read_audit_stream` reads only the former and **cannot be polluted** by the malformed sink.

### 2. Anti-loop, never cascade
If `_append_malformed` itself fails to write, it **does not** recurse — it silently degrades to a stderr warn.

### 3. Strict mode still raises
`append_audit(event, strict=True)` still raises `AuditAppendError` on error; it does not go through the malformed sink. The malformed sink covers non-strict mode only.

### 4. Backwards compatible
The new `_handle_failure()` kwargs `workspace` / `raw_record` are both optional — older callers keep working (they simply lose the malformed fallback).

## Not allowed

- ❌ Silently dropping events (the original Real Trial v1 F6 issue).
- ❌ Mixing malformed records into the canonical audit file (consumers cannot tell them apart).
- ❌ "Simplifying" by letting the malformed sink also raise (breaks `append_audit`'s non-strict no-raise contract).

## Human review cadence

`mcp_audit.malformed.jsonl` is a **forensic log**, not a permanent archive:

- Review at every Sprint Close / phase close.
- If it is a bug, fix it → commit.
- If it is a stray record, delete it.
- If it is a data issue, add an `evidence_ref` and promote it into `ltm/failures/`.

## Related rules

- [envelope_9_field_contract](./envelope_9_field_contract.md) — what a well-formed envelope looks like.
- [failures README](../failures/README.md) — postmortems follow a similar fallback philosophy.
