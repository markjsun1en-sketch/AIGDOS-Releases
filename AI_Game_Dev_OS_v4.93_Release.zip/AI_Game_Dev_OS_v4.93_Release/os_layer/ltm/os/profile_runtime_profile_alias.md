---
captured_at: 2026-05-03T22:45:00Z
actor: kai_phase_1_operator
gate: passed
evidence_ref: "MEMORY.md §7.8.3 rule #7 / commit 6f12853"
---
# `profile` ↔ `runtime_profile` Alias Contract

## Rule

The profile field in `runtime_state.json` has two legal names, **semantically identical**:

- `profile` (the short schema name, read by `verify` in v4.88 and earlier).
- `runtime_profile` (written by `init` in v4.88 / the canonical name in v4.89).

## Write side (init)

`scripts/init_runtime_env.py::_stub_init` must write **both**:

```python
runtime_profile = args.runtime_profile or config_data.get("runtime_profile")
state = {
    "runtime_profile": runtime_profile,
    "profile": runtime_profile,  # C2 alias — lock-step with runtime_profile
    ...
}
```

## Read side (verify)

`scripts/verify_beta_sprint_exit.py::_REQUIRED_STATE_FIELDS` is a **tuple of tuples**; each entry holds the set of "any one of these aliases is accepted":

```python
_REQUIRED_STATE_FIELDS: tuple[tuple[str, ...], ...] = (
    ("profile", "runtime_profile"),  # either one present and non-empty is enough
    ("initialized_at",),
)
```

## Not allowed

- ❌ Writing only one of them (the pre-C2 workspace behaviour; triggers a verify WARN "missing required field").
- ❌ The two fields holding different values (lock-step rule — they must match).
- ❌ Auto-derivation: verify must not "copy `runtime_profile` over when `profile` is missing" — the caller must declare explicitly.

## Scope

This rule applies **only** to the profile field in `runtime_state.json`. Other JSON files (profile JSONs / `tapd_config_instance` / snapshots) **do not** use this alias — each has its own canonical field name.

## Related rules

- [runtime_state_path_contract](./runtime_state_path_contract.md)
- [workspace_package_root_fallback](./workspace_package_root_fallback.md)
