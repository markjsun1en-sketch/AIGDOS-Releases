---
captured_at: 2026-05-03T22:45:00Z
actor: kai_phase_2_operator
gate: passed
evidence_ref: "V4_89_PHASE_2_TAKEOVER_PROMPT §8-1 / commit 0b72999 / v4.88-release-stable tag"
---
# `v4.88_Release/` Subrange Immutability Rule

## Rule

`AI_Game_Dev_OS_v4.88_Release/` enforces **subrange immutability**:

### ❌ Strictly forbidden (code-like artifacts)

- `**/*.py` / `**/*.sh`
- `**/*.json` (schema / profile / config / manifest and other technical JSON)
- `**/*.yaml` (policy / workflow)
- `**/*.template` (template files)
- All technical definitions under `game_type_packs/`.
- The entire `scripts/` / `runtime/` / `integrations/` / `config/` / `schemas/` trees.

### ✅ Editable (documentation-like artifacts)

- `docs/**/*.md`
- `README.md` / `ASSEMBLY_GUIDE.md` / other top-level explanatory `.md` files.
- The whole `context_packs/pack_selection_guide/**` tree (explanations + examples).
- `starters/*/TEAM_BOOT_GUIDE.md`
- `trial_workspaces/README.md`

## Required companion actions per documentation edit

After editing `.md` files, you **must**:

1. Tag a new `v4.88-release-*` stable tag (e.g. `v4.88-release-stable`) that captures this doc snapshot.
2. Rebuild the E7 shasum baseline:
   ```bash
   find AI_Game_Dev_OS_v4.88_Release -type f -print0 \
     | xargs -0 shasum -a 256 > /tmp/v488_release_baseline.sha
   ```
3. Run `shasum -a 256 -c /tmp/v488_release_baseline.sha` to self-verify with 0 FAILED.

## Why split into subranges

The original Phase 1 handoff §8-1 said "don't touch any byte". But on 2026-05-03 the v4.88 user guide wrap-up touched 22 existing `.md` files + added 1 new one — this was a **documentation / code alignment** operation that EP performed deliberately, not a stray change.

Keeping "any-byte-forbidden" as the rule would mean:
- Doc wrap-up work would be misclassified as a policy violation.
- The E7 baseline would be wrongly judged as "broken".
- A new thread inheriting the workspace would raise alarms for events that were actually legitimate.

So the rule is split into **two subranges** (code and docs), each with its own independent contract.

## Not allowed (crossing the subrange line)

- ❌ Sneaking edits into `scripts/*.py` under the banner of "documentation changes".
- ❌ Editing `docs/*.md` under the banner of "code changes" without tagging a new stable tag.
- ❌ Editing documentation without tagging a stable tag (baseline drifts untraceably).

## The v4.89 analogue

v4.89 has no matching "subrange immutability" rule — v4.89 is an actively evolving package and every file is expected to move. The only truly immutable area is `v4.88_Release/` (kept as the reference pack).

## Related rules

- [runtime_state_path_contract](./runtime_state_path_contract.md)
- [workspace_package_root_fallback](./workspace_package_root_fallback.md)
