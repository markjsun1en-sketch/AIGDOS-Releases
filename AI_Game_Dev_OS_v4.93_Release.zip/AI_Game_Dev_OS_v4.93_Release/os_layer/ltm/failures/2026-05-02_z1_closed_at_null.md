---
captured_at: 2026-05-03T22:50:00Z
actor: kai_phase_1_operator
gate: passed
evidence_ref: "MEMORY.md §7.9 Z1 key pitfall / trigger commit 258af9f / fix commit 978a5fd"
---
# Z1 verify CONDITIONAL / runtime_state.closed_at is null

## Symptom

On 2026-05-02 during the Phase 1 Z1 step, after running `init --force` per Plan §7.5 and then driver + verify, the expected result was `verdict=PASS / error=0 / warn=0`. Actual:

```
"verdict": "CONDITIONAL"
"error_count": 0
"warn_count": 1
"finding": {
  "category": "close",
  "severity": "WARN",
  "message": "runtime_state.closed_at is null; sprint not closed"
}
```

The driver stdout clearly executed:

```
[driver] closed /Users/.../trial_workspaces/rh_sprint_sim_01/runtime_state.json
```

The driver said "closed"; verify said "not closed". Contradiction.

## Root Cause

After `init --force`, the workspace state is **Shape 2 (pointer + canonical)**:

```
<ws>/runtime/state/runtime_state.json   ← real state, closed_at: null
<ws>/runtime_state.json                  ← pointer shim {"_moved_to": "runtime/state/runtime_state.json", ...}
```

But the close block in driver `run_sprint.py` L297 was still pre-C4 code:

```python
state_path = WS / "runtime_state.json"      # points at the root pointer ❌
state = json.loads(state_path.read_text())  # reads the pointer JSON {"_moved_to": ..., "canonical": true}
state["closed_at"] = ts(125)                # tacks closed_at onto the pointer dict
state["tasks"] = [...]                       # tacks tasks onto the pointer
state_path.write_text(json.dumps(state))    # overwrites the pointer with "pointer + closed_at"
```

Outcome:
1. The pointer is overwritten into a **hybrid mutant**: `{"_moved_to": "...", "canonical": true, "closed_at": "...", "tasks": [...]}`.
2. The real state at the canonical location was never written → `closed_at` remains `null`.
3. verify's `_resolve_state_path()` follows the root pointer → lands on canonical → reads `closed_at: null` from real state → WARN.

**C4's pointer shim is read-side compatibility; the driver's write path must not treat it as real state.**

## Fix

Change the close block in `run_sprint.py` to **canonical-first, legacy-fallback**:

```python
canonical_state = WS / "runtime" / "state" / "runtime_state.json"
legacy_state = WS / "runtime_state.json"
if canonical_state.exists():
    state_path = canonical_state
else:
    state_path = legacy_state   # pre-C4 legacy workspace
state = json.loads(state_path.read_text())
state["closed_at"] = ts(125)
state["tasks"] = [{"task_id": "RH-SIM-001", "state": "done"}, ...]
state_path.write_text(json.dumps(state, indent=2))
```

Restoring the pointer (the workspace that the driver corrupted needs a manual step): re-run `init --force` and the pointer is regenerated.

After the re-run: `verdict=PASS / error=0 / warn=0` ✅.

## Commit Refs

- **Indirect trigger**: `258af9f feat(init/verify): unify runtime_state location to runtime/state/ + root pointer shim` (C4) — C4 introduced the pointer shim but **did not audit** the driver's write path.
- **Root fix**: `978a5fd chore(trial): re-run rh_sprint_sim_01 on v4.89 → verdict=PASS + MEMORY §7.9` (Z1) — fixed the driver close path and laid down rule #11.

## Lesson

**Pointer shim is read-side compatibility, not a write-side substitute.**

Derived rules:
- [runtime_state_path_contract](../os/runtime_state_path_contract.md) — full rule, including the "driver writes canonical" law.
- [three_workspace_shapes](../os/three_workspace_shapes.md) — pointer + canonical is Shape 2, not "root real state".

## Similar situations to watch for

Any contract upgrade that introduces "indirection / symlink / pointer / alias" must **audit every write site** at the same time. Fix checklist:
1. `grep` every read/write site that touches that path.
2. For each site, confirm it goes through the resolver (for reads) or targets canonical (for writes).
3. At least one end-to-end integration test covering the "init → driver write → verify read" loop.
4. When verify reports WARN/ERROR, compare driver stdout against the actual JSON content of state first.

## Candidate derived rule (Phase 2+)

Add a lint: `verify_beta_sprint_exit.py` could detect, under the close-category, the case where the pointer has been overwritten into real state (i.e. the pointer shim carries "non-pointer fields" such as `closed_at`) and report an ERROR. That would **immediately** surface future driver mis-writes. Phase 2 Stage 2 can consider it.
