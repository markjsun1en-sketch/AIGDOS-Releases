---
captured_at: 2026-05-05T20:15:00Z
actor: kai_phase_2_operator
gate: passed
evidence_ref: "MEMORY.md §M6.6 / trigger commit 1c323a3 / fix commit pending-M6.6"
---
# claude_code_agent_teams contract-level parity is not validated by silent PASS

## Symptom

M6.5 closed (commit `1c323a3` on 2026-05-05) with the cursor negative
parity wired up.  Coming into M6.6, the claude_code_agent_teams
profile still presented a clean per-mirror verdict (unchanged through
M6.3 / M6.4 / M6.5 closes):

| profile / workspace                 | SCAFFOLD | GUIDED |
|-------------------------------------|----------|--------|
| claude_code_agent_teams / __claude_code_agent_teams | PASS | PASS |

The M6.4/M6.5 lesson — "parity is the verifier can tell apart the
profile from its negation" — explicitly forecast the same gap on
claude_teams.  Per the recipe in the codex/cursor postmortems,
M6.6 generated a claude_teams negative mirror first:

```bash
$ python3 scripts/mirror_trial_workspace.py \
    --source trial_workspaces/rh_sprint_sim_01 \
    --target trial_workspaces/rh_sprint_sim_01__claude_code_agent_teams_negative \
    --profile claude_code_agent_teams \
    --inject-violation contract_drift
{"profile": "claude_code_agent_teams", "files": 12, "bytes": 111010,
 "injected_violation": "contract_drift",
 "injected_fields": {"coordination_model": "private_coordinated",
                     "writeback_owner": "main_session"}}
```

The injected values contradict the claude_code_agent_teams profile
JSON ground truth (`lead_teammates` / `lead`).  Running verify against
that mirror **before any code change**:

```
$ beta_sprint_driver.py --profile claude_code_agent_teams --maturity GUIDED \
    --workspace trial_workspaces/rh_sprint_sim_01__claude_code_agent_teams_negative
verdict=PASS / error=0 / warn=0 / findings=[]
```

A workspace that explicitly declares the claude_teams contract is
**violated** still produced a clean PASS.  claude_teams's all-PASS
through M6.3–M6.5 was therefore silence, not evidence — the same
blindness M6.4 surfaced for codex and M6.5 confirmed for cursor,
recurring on a third profile.  This is the third consecutive
confirmation that **per-profile cross-checks do not transitively
generalise**.

## Root Cause

The M6.4 codex cross-check and the M6.5 cursor cross-check are both
profile-gated (`declared == "codex"` / `declared == "cursor"`).
Neither block fires on claude_teams state — even when the same
`coordination_model` / `writeback_owner` fields drift in the same
way — because claude_teams's expected values differ
(`lead_teammates` / `lead`, not `parent_subagents` / `parent`, not
`parallel_agents` / `reviewed_apply_owner`).

The verifier's vocabulary at M6.5 close had **two** profile-specific
rules (codex + cursor).  The Stage 2 charter's plan was always to
add per-profile rules incrementally; the M6.6 negative mirror
confirmed the gap exists exactly where M6.4 postmortem §"Similar
situations" predicted it would.

## Fix

Three coordinated changes, single commit (M6.6):

1. **Generator** (`scripts/mirror_trial_workspace.py`):
   `_CONTRACT_DRIFT_FIXTURES` gained a `claude_code_agent_teams`
   entry mirroring the codex / cursor injection values
   (`coordination_model=private_coordinated`,
   `writeback_owner=main_session`).  +5 lines / -0.  Existing codex
   and cursor entries byte-stable.  Default behaviour (no
   `--inject-violation`) unchanged, so the existing six positive
   mirrors regenerate byte-identical.

2. **Verifier** (`scripts/verify_beta_sprint_exit.py`): added a
   claude_teams block to `check_init_integrity`, symmetric to the
   M6.4 codex block and the M6.5 cursor block.  Both rules are
   gated on `runtime_state.profile == "claude_code_agent_teams"`
   and on the contract field being *explicitly declared*.  Both
   fire WARN, not ERROR — divergence detection, not contract
   policing.  +27 lines including docstring (per EP scope-guard
   ≤30, identical bound to M6.4/M6.5).  M6.4 codex block and M6.5
   cursor block byte-stable.

3. **Negative mirror**: generated at
   `trial_workspaces/rh_sprint_sim_01__claude_code_agent_teams_negative/`
   with the `--inject-violation contract_drift` flag.  Post-fix
   verify run:

   ```
   verdict=CONDITIONAL / error=0 / warn=2
   findings:
     - init/WARN coordination_model schema drift
     - init/WARN writeback_owner schema drift
   ```

The negative mirror demonstrates the new checks fire; the
claude_teams positive mirror still passes (clean PASS, 0 findings)
under both SCAFFOLD and GUIDED.  All other M6.3/M6.4/M6.5 verdicts
retain their pre-existing severity (codex/cursor/claude_subagents
PASS; default_beta_codex_tapd_git CONDITIONAL/1 WARN; codex_negative
and cursor_negative each CONDITIONAL/2 WARN).

## Lesson

**Three consecutive profiles, three consecutive silent-PASS
discoveries, three consecutive fixes in identical shape.**  The M6.4
"parity is not all PASS" rule is now empirically a recipe, not just
a slogan.  M6.6 confirmation also tells us:

- The per-profile gate (declared==<profile>) successfully isolates
  blocks; no cross-block interference observed in 138 pytest cases
  across three profiles' cross-check tests + 6 mirrors × 2 maturity
  + 3 negative mirrors regression.
- The injection fixture (`private_coordinated` / `main_session`) is
  correctly a *common contradictor* — it differs from each profile's
  ground truth simultaneously, so it serves as a clean "any non-baseline"
  marker without coupling to any specific profile's vocabulary.

**The corollary discipline**: M6.7 (claude_code_subagents) follows
the same recipe one more time, after which Phase 3 audit unblocks
to consider collapsing the per-profile if-tree into a schema-driven
cross-checker.  Do **NOT** pre-collapse in M6.7.

## Commit Refs

- **Trigger commit** (M6.5 close, prerequisite): `1c323a3`
- **Fix commit** (M6.6): pending — recorded in MEMORY §M6.6
  sub-section

## Similar situations to watch for

M6.7 will encounter the same pattern for `claude_code_subagents`.
Apply the same seven-step recipe (recipe text identical to the
M6.4/M6.5 postmortems; here re-stated for inline reference):

1. Add a fixture entry to `_CONTRACT_DRIFT_FIXTURES` in
   `mirror_trial_workspace.py` for `claude_code_subagents`.
2. Generate `rh_sprint_sim_01__claude_code_subagents_negative/`.
3. Confirm verify *still* PASSes (proves the gap exists).
4. Add narrow cross-check(s) to `check_init_integrity` keyed on
   `declared == "claude_code_subagents"`.
5. Re-run negative mirror — verify must now CONDITIONAL/N WARN.
6. Re-run positive mirror — verify must remain PASS.
7. Append a postmortem in `ltm/failures/` using this file's
   structure.

### claude_subagents-specific dimension reference

Per `config/profiles/claude_code_subagents.json`:
- `coordination_model = parent_subagents` (same as codex)
- `writeback_owner = parent` (same as codex)

This is a **structural collision**: M6.7 cannot reuse
coordination_model / writeback_owner as cross-check dimensions
because the expected values are identical to codex's.  The
declared==<profile> gate keeps the blocks isolated, but a
claude_subagents negative mirror with codex-typical drift values
would also satisfy codex's expected values when the profile field
is rewritten — meaning the cross-check would only be detectable
with *non-codex-shaped* drift.  Decision deferred to M6.7 entry
ASK; candidates include `isolation_unit` (worktree, but already
constrained by L475 P1 block — possible semantic overlap risk),
`audit_collector` (claude_subagents_collector vs cursor_collector
etc., wide range), or `cleanup_owner` (parent across most
profiles, narrow signal).

## Candidate Phase 3 rule (matures with each landed sample)

Three of four samples (codex / cursor / claude_teams) now share
the same cross-check shape.  Phase 3 audit candidates after M6.7:

1. **Schema-driven cross-checker** — read profile JSON contract
   fields → emit WARN per drift, no per-profile if-tree.  Three
   identical blocks (and a fourth structurally distinct M6.7
   block) is the strongest evidence so far that the per-profile
   form is informationally redundant.  Hold the audit until M6.7
   lands so the dissimilar fourth case is in scope.
2. **Lift the gate** from "explicitly declared in state" to "any
   state on a profile contract field must match profile JSON"
   (requires init writing contract fields canonically).


---

## Footer note (added 2026-05-05 / Phase 3 M7.0)

The verdict matrix in this postmortem records `default_beta_codex_tapd_git / GUIDED = CONDITIONAL (1 WARN)` as the live state at the time this postmortem was written.  That finding was triggered by a missing entry in `_VALID_PROFILES` enum in `verify_beta_sprint_exit.py`, plus a missing `context_loading_method` field in the P6 profile JSON.

Phase 3 Lock-A (M7.0) resolved both: enum extended to include `default_beta_codex_tapd_git`, and the P6 JSON gained `context_loading_method=project_docs_plus_selected_files` (matching the codex preset this combo template inherits from).  P6/GUIDED now returns `PASS / 0 / 0` like the other 5 positive mirrors.  See `STAGE_2_MATRIX_INVENTORY.md` §3.2 G-b2 RESOLVED note + the 4 §5 verdict tables (post-M6.3 through post-M6.8) for the live state.

This postmortem itself is preserved as a frozen snapshot of M6.X-time evidence; the verdict line above is intentionally not edited.

---

## Footer note (added 2026-05-05 / Phase 3 M7.2)

The per-profile cross-check `if` block this postmortem describes was **collapsed** in Phase 3 M7.2 (commit pending) into the schema-driven `runtime/schema_driven_check.py` module.  Line-number references (e.g. "L509-580") point to the *pre-M7.2* layout in `scripts/verify_beta_sprint_exit.py`; that range no longer exists in the post-M7.2 source.

The per-profile field choices and per-profile gate semantics this postmortem documents are **fully preserved** in `runtime.schema_driven_check._PROFILE_CHECK_FIELDS`; the M6.X recipe is unchanged in spirit, only the implementation surface relocated.  The four per-profile cross-check tests (`tests/test_verify_*_cross_check.py`) remain byte-stable and continue to pass under the new schema-driven path, witnessing that the per-profile semantics survived collapse.

M7.1 audit established byte-identical equivalence on 16 R1 matrix rows before the collapse landed; see `ltm/pattern/2026-05-05_phase_3_schema_driven_audit.md` for the verdict.

This postmortem itself is preserved as a frozen snapshot of M6.X-time evidence; the verdict line and line-number references above are intentionally not edited.
