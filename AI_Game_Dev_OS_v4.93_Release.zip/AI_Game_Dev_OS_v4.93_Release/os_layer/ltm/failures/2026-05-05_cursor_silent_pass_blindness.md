---
captured_at: 2026-05-05T19:00:00Z
actor: kai_phase_2_operator
gate: passed
evidence_ref: "MEMORY.md §M6.5 / trigger commit dbd809b / fix commit pending-M6.5"
---
# Cursor contract-level parity is not validated by silent PASS

## Symptom

M6.4 closed (commit `dbd809b` on 2026-05-05) with the codex negative
parity wired up (postmortem
`ltm/failures/2026-05-05_codex_silent_pass_blindness.md`).  Coming into
M6.5, the cursor profile still presented a clean per-mirror verdict:

| profile / workspace | SCAFFOLD | GUIDED |
|---|---|---|
| cursor / __cursor   | PASS     | PASS   |

But the M6.4 lesson — "parity is the verifier can tell apart the
profile from its negation" — explicitly forecast the same gap on
cursor.  Per the recipe in M6.4 postmortem §"Similar situations",
M6.5 generated a cursor negative mirror first:

```bash
$ python3 scripts/mirror_trial_workspace.py \
    --source trial_workspaces/rh_sprint_sim_01 \
    --target trial_workspaces/rh_sprint_sim_01__cursor_negative \
    --profile cursor \
    --inject-violation contract_drift
{"profile": "cursor", "files": 12, "bytes": 110595,
 "injected_violation": "contract_drift",
 "injected_fields": {"coordination_model": "private_coordinated",
                     "writeback_owner": "main_session"}}
```

The injected values contradict the cursor profile JSON ground truth
(`parallel_agents` / `reviewed_apply_owner`).  Running verify against
that mirror **before any code change**:

```
$ beta_sprint_driver.py --profile cursor --maturity GUIDED \
    --workspace trial_workspaces/rh_sprint_sim_01__cursor_negative
verdict=PASS / error=0 / warn=0 / findings=[]
```

A workspace that explicitly declares the cursor contract is **violated**
still produced a clean PASS.  Cursor's all-PASS in M6.3 (and
unchanged after M6.4) was therefore silence, not evidence — the same
blindness M6.4 surfaced for codex, recurring on a different profile.

## Root Cause

The M6.4 codex cross-check (`check_init_integrity` L509-527) is
profile-gated by `declared == "codex"`.  By design, that block does
not fire on cursor state — even when the same `coordination_model` /
`writeback_owner` fields drift in the same way — because cursor's
expected values differ (`parallel_agents` / `reviewed_apply_owner`,
not `parent_subagents` / `parent`).  The verifier's vocabulary at
M6.4 close had **one** profile-specific rule (codex), and the Stage
2 charter's plan was always to add per-profile rules incrementally
(M6.5 cursor → M6.6 claude_teams → M6.7 claude_subagents).

The structural problem on entry to M6.5: parity work for cursor was
being measured on a verifier that did not yet have the language to
describe parity violations for any profile other than codex.  The
M6.5 negative mirror confirmed this in 12 lines of stdout.

## Fix

Three coordinated changes, single commit (M6.5):

1. **Generator** (`scripts/mirror_trial_workspace.py`):
   `_CONTRACT_DRIFT_FIXTURES` gained a `cursor` entry mirroring the
   codex injection values (`coordination_model=private_coordinated`,
   `writeback_owner=main_session`).  +4 lines / -0.  Codex entry byte
   diff = 0.  Default behaviour (no `--inject-violation`) unchanged,
   so the existing six positive mirrors regenerate byte-identical.

2. **Verifier** (`scripts/verify_beta_sprint_exit.py`): added a
   cursor block to `check_init_integrity`, symmetric to the M6.4
   codex block.  Both rules are gated on `runtime_state.profile ==
   "cursor"` and on the contract field being *explicitly declared*.
   Both fire WARN, not ERROR — divergence detection, not contract
   policing.  +26 lines including docstring (per EP scope-guard
   ≤30, identical bound to M6.4).  M6.4 codex block (L509-527)
   byte-stable.

3. **Negative mirror**: generated at
   `trial_workspaces/rh_sprint_sim_01__cursor_negative/` with the
   `--inject-violation contract_drift` flag.  Post-fix verify run:

   ```
   verdict=CONDITIONAL / error=0 / warn=2
   findings:
     - init/WARN coordination_model schema drift
     - init/WARN writeback_owner schema drift
   ```

The negative mirror demonstrates the new checks fire; the cursor
positive mirror still passes (clean PASS, 0 findings) under both
SCAFFOLD and GUIDED.  All five other M6.3/M6.4 verdicts retain their
pre-existing severity (codex/claude_teams/claude_subagents PASS;
default_beta_codex_tapd_git CONDITIONAL/1 WARN; codex_negative
CONDITIONAL/2 WARN).

### Test-side ripple (intentional)

The M6.4 codex test helper `_codex_drift_findings` filtered findings
by `contract_field in {coordination_model, writeback_owner}` only.
M6.5 cursor block produces findings with the same `contract_field`
names, so the filter would over-match in cross-profile scenarios.
Fix applied in same commit: pin the filter on `profile=codex`
substring in the message text.  Codex C6 (the prior cross-profile
guard) now also discriminates by message substring.  Cursor's own
test helper `_cursor_drift_findings` mirrors the structure with
`profile=cursor` substring.  This is a 1-line addition per filter,
not a structural revisit.  The codex source code blocks remain
byte-stable; only the test helper's predicate widens.

## Lesson

**Parity is not "all PASS"; parity is "the verifier can tell apart
the profile from its negation."**  M6.5 is the second confirmation
of this rule: the same blindness recurred on a different profile in
the same verifier file, despite the M6.4 fix.  Each per-profile
cross-check is a separate evidence claim; M6.4's codex rule does
not *transitively* prove cursor parity.

A silent PASS on a non-baseline profile is a red flag that probe
coverage is missing, not a green flag that the profile behaves
correctly.  Stage 2 does not measure parity by counting greens — it
measures parity by establishing for each profile that the verifier
*can* fire when the contract is broken, then confirming it *does
not* fire when the contract holds.

The corollary discipline (M6.6 / M6.7): the sequence is
**negative-mirror first, cross-check second, positive verdict
third**.  Inverting that order risks shipping silent PASS again.
M6.5 pulled this off in a single commit.

## Commit Refs

- **Trigger commit** (M6.4 close, prerequisite): `dbd809b`
- **Fix commit** (M6.5): pending — recorded in MEMORY §M6.5
  sub-section

## Similar situations to watch for

M6.6–M6.7 will encounter the same pattern for
`claude_code_agent_teams` / `claude_code_subagents`.  Apply the same
seven-step recipe per profile (recipe text identical to the M6.4
postmortem; here re-stated for inline reference):

1. Add a fixture entry to `_CONTRACT_DRIFT_FIXTURES` in
   `mirror_trial_workspace.py` for the target profile.
2. Generate `rh_sprint_sim_01__<profile>_negative/`.
3. Confirm verify *still* PASSes (proves the gap exists).
4. Add narrow cross-check(s) to `check_init_integrity` keyed on
   `declared == "<profile>"`.
5. Re-run negative mirror — verify must now CONDITIONAL/N WARN.
6. Re-run positive mirror — verify must remain PASS (regression
   guard).
7. Append a postmortem in `ltm/failures/` using this file's structure.

Do **NOT** pre-write checks for the remaining profiles in M6.5.
The evidence chain works only when each profile's negative mirror
is the witness for that profile's check, in its own commit.

### Cursor-specific dimension choice

Cursor cross-check picked `coordination_model` + `writeback_owner`
(symmetric with codex), not cursor-exclusive fields like
`audit_collector` (value range too wide), `rule_loading.entry_file`
(nested dict, awkward read path), or
`rule_loading.supports_hooks` (bool, two-value space too narrow).
Symmetric reuse keeps the per-profile if-tree structurally
predictable for the eventual M6.7-end audit (Phase 3 candidate:
schema-driven cross-checker).

## Candidate Phase 3 rule (unchanged from M6.4)

Once M6.6–M6.7 each carry at least one cross-check, audit whether a
unified schema-driven cross-checker — read profile JSON contract
fields → emit WARN per drift, no per-profile if-tree — can supersede
the explicit per-profile rules.  Phase 3 territory; do not collapse
the per-profile rules in Stage 2 even if they look symmetric, because
the explicit form is what makes the per-commit evidence chain
auditable.

The complementary Phase 3 candidate: lift the gate from
"explicitly declared in state" to "any state on a profile contract
field must match profile JSON".  Today's gate exists to keep the
positive mirrors silent without changing them; once init writes the
contract fields canonically (a Phase 3 init-time decision), the gate
can tighten.


---

## Footer note (added 2026-05-05 / Phase 3 M7.0)

The verdict matrix in this postmortem records `default_beta_codex_tapd_git / GUIDED = CONDITIONAL (1 WARN)` as the live state at the time this postmortem was written.  That finding was triggered by a missing entry in `_VALID_PROFILES` enum in `verify_beta_sprint_exit.py`, plus a missing `context_loading_method` field in the P6 profile JSON.

Phase 3 Lock-A (M7.0) resolved both: enum extended to include `default_beta_codex_tapd_git`, and the P6 JSON gained `context_loading_method=project_docs_plus_selected_files` (matching the codex preset this combo template inherits from).  P6/GUIDED now returns `PASS / 0 / 0` like the other 5 positive mirrors.  See `STAGE_2_MATRIX_INVENTORY.md` §3.2 G-b2 RESOLVED note + the 4 §5 verdict tables (post-M6.3 through post-M6.8) for the live state.

This postmortem itself is preserved as a frozen snapshot of M6.X-time evidence; the verdict line above is intentionally not edited.

---

## Footer note (added 2026-05-05 / Phase 3 M7.2)

The per-profile cross-check `if` block this postmortem describes was **collapsed** in Phase 3 M7.2 (commit pending) into the schema-driven `runtime/schema_driven_check.py` module.  Line-number references (e.g. "L509-580") point to the *pre-M7.2* layout in `scripts/verify_beta_sprint_exit.py`; that range no longer exists in the post-M7.2 source.

The per-profile field choices and per-profile gate semantics this postmortem documents are **fully preserved** in `runtime.schema_driven_check._PROFILE_CHECK_FIELDS`; the M6.X recipe is unchanged in spirit, only the implementation surface relocated.  The four per-profile cross-check tests (`tests/test_verify_*_cross_check.py`) remain byte-stable and continue to pass under the new schema-driven path, witnessing that the per-profile semantics survived collapse.

M7.1 audit established byte-identical equivalence on 16 R1 matrix rows before the collapse landed; see `ltm/pattern/2026-05-05_phase_3_schema_driven_audit.md` for the verdict.

This postmortem itself is preserved as a frozen snapshot of M6.X-time evidence; the verdict line and line-number references above are intentionally not edited.
