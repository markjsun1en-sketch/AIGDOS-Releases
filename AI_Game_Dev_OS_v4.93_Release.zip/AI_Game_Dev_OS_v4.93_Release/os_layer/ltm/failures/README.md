# ltm/failures — Failure-Fix Cases domain

Concrete error → root cause → fix pairs.

## Write policy

- **Primary author**: whoever discovers the issue writes the postmortem (usually at phase-close or when a single commit fixes a bug).
- **Gate**: `evidence_ref` is **required** (both the commit that introduced the failure and the fixing commit).
- **File naming**: `YYYY-MM-DD_<short_slug>.md`.

## Convention: every case contains 5 sections

```markdown
# <Title>

## Symptom
What was observed. Include commands, error messages, exit codes.

## Root Cause
Why it happened. Trace to the specific code / contract / assumption drift.

## Fix
What was changed. **Cite the fix commit sha.**

## Commit Refs
- The commit that introduced the issue (if known)
- The fix commit

## Lesson
The rule to avoid it next time. May be promoted to an `ltm/os/` rule (see "cross-domain promotion").
```

## Cross-domain promotion

A failure-fix that **recurs** (≥2 similar cases) → distilled into an `ltm/os/` rule.
Stage 1 MVP does not promote automatically; a human review makes the call.

## Seed content origin

v4.89 Phase 2 Stage 1 M4.2 ported 2 Phase 1 pitfalls from `.workbuddy/memory/MEMORY.md` §7.8.2 / §7.9 (A4 dry-run fail / Z1 closed_at null bug).

## consult examples

```bash
python -m runtime.ltm "verification_ok false" --domain failures
python -m runtime.ltm "pointer" --domain failures
python -m runtime.ltm "closed_at" --domain failures
```
