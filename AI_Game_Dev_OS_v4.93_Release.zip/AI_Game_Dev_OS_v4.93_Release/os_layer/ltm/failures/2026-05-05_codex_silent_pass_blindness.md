---
captured_at: 2026-05-05T17:30:00Z
actor: kai_phase_2_operator
gate: passed
evidence_ref: "MEMORY.md §7.11 M6.4 / trigger commit 0596a43 / fix commit pending-M6.4"
---
# Codex contract-level parity is not validated by silent PASS

## Symptom

M6.3 closed (commit `0596a43` on 2026-05-05) with a clean per-profile
verdict matrix:

| profile                         | SCAFFOLD | GUIDED                  |
|---------------------------------|----------|-------------------------|
| codex                           | PASS     | PASS                    |
| cursor                          | PASS     | PASS                    |
| claude_code_agent_teams         | PASS     | PASS                    |
| claude_code_subagents           | PASS     | PASS                    |
| default_beta_codex_tapd_git     | PASS     | CONDITIONAL (1 WARN)    |

On M6.4 entry, a deep-probe of `verify_beta_sprint_exit.py` against the
profile JSON contract surface revealed only **one** of the seven
profile-specific contract fields actually had a cross-check rule:
`isolation_unit + dirty_worktree` (init L475, P1-专属 edge case C.2).
The remaining six fields (`coordination_model`, `writeback_owner`,
`cleanup_owner`, `audit_collector`, `merge_mode`, plus non-P1
`isolation_unit`) were profile-blind.

To prove the silence was blindness rather than evidence, we built a
deliberate contract-violating mirror — `rh_sprint_sim_01__codex_negative`
— that injects `coordination_model: private_coordinated` and
`writeback_owner: main_session` into the nested runtime_state.json
(both contradict the codex profile JSON ground truth of
`parent_subagents` / `parent`).  Running verify against that mirror
**before any code change**:

```
$ beta_sprint_driver.py --profile codex --maturity GUIDED \
    --workspace trial_workspaces/rh_sprint_sim_01__codex_negative
verdict=PASS / error=0 / warn=0 / findings=[]
```

A workspace that explicitly declares the codex contract is **violated**
still produced a clean PASS.  Codex's all-PASS in M6.3 was therefore
silence, not evidence.

## Root Cause

`verify_beta_sprint_exit.py` was authored before the 5-profile parity
work began.  Its profile-specific verification was scoped only to the
C.2 dirty-worktree edge case for `workbuddy_private`; every other
runtime contract field declared in `config/profiles/*.json` had no
corresponding rule in `check_init_integrity` (or any other `check_*`).

The M6.3 mirror generator (`scripts/mirror_trial_workspace.py`) does
rewrite `runtime_state.profile` and the `runtime_profile` field in
every audit log line — that is enough to clear the init L451
profile-vs-runtime_type cross-check and the envelope-aware audit
checks.  But it does not, and **could not by itself**, make the other
six contract fields visible to verify, because verify simply does not
read them.

The structural problem: parity work was being measured on a verifier
that did not yet have the language to describe parity violations for
profiles other than P1.

## Fix

Three coordinated changes, single commit:

1. **Generator** (`scripts/mirror_trial_workspace.py`): added an opt-in
   `--inject-violation contract_drift` flag that injects per-profile
   schema-drift fixtures into the nested runtime_state.json.  The flag
   defaults to `None` (no-op), so the existing five M6.3 mirrors
   regenerate byte-identical per the M6.3 idempotency contract.
   Codex fixture: `coordination_model=private_coordinated` +
   `writeback_owner=main_session`.

2. **Verifier** (`scripts/verify_beta_sprint_exit.py`): added two
   narrow cross-check rules to `check_init_integrity`, both gated on
   `runtime_state.profile == "codex"` and on the contract field being
   *explicitly declared* in state.  Both fire WARN, not ERROR — this
   is divergence detection, not contract policing.  The
   gate-by-explicit-declaration is what keeps the five positive
   mirrors green (their runtime_state files do not declare these
   fields, so the new check never triggers).  The whole patch is 29
   line additions including docstring (per EP scope-guard ≤30).

3. **Negative mirror**: generated at
   `trial_workspaces/rh_sprint_sim_01__codex_negative/` with the new
   `--inject-violation contract_drift` flag.  Post-fix verify run:

   ```
   verdict=CONDITIONAL / error=0 / warn=2
   findings:
     - init/WARN coordination_model schema drift
     - init/WARN writeback_owner schema drift
   ```

The negative mirror demonstrates the new checks fire; the positive
codex mirror still passes (clean PASS, 0 findings).  The five M6.3
positive mirrors retain their pre-existing verdicts.

## Lesson

**Parity is not "all PASS"; parity is "the verifier can tell apart
the profile from its negation."**

A silent PASS on a non-baseline profile is a red flag that probe
coverage is missing, not a green flag that the profile behaves
correctly.  Stage 2 does not measure parity by counting greens — it
measures parity by establishing for each profile that the verifier
*can* fire when the contract is broken, then confirming it *does not*
fire when the contract holds.

The corollary discipline: when a new profile dimension is admitted
(M6.5 cursor / M6.6 claude_teams / M6.7 claude_subagents), the
sequence is **negative-mirror first, cross-check second, positive
verdict third**.  Inverting that order risks shipping silent PASS
again.

## Commit Refs

- **Trigger commit** (M6.3 close, surfaced gap): `0596a43`
- **Fix commit** (M6.4): pending — recorded in MEMORY §7.11 sub-section

## Similar situations to watch for

M6.5–M6.7 will encounter the same pattern for cursor /
claude_code_agent_teams / claude_code_subagents.  Apply the same
recipe per profile:

1. Add a fixture entry to `_CONTRACT_DRIFT_FIXTURES` in
   `mirror_trial_workspace.py` for the target profile.
2. Generate `rh_sprint_sim_01__<profile>_negative/`.
3. Confirm verify *still* PASSes (proves the gap exists).
4. Add narrow cross-check(s) to `check_init_integrity` keyed on
   `declared == "<profile>"`.
5. Re-run negative mirror — verify must now CONDITIONAL/N WARN.
6. Re-run positive mirror — verify must remain PASS (regression
   guard).
7. Append a postmortem in `ltm/failures/` using this file's structure.

Do **NOT** pre-write checks for all five profiles in M6.4.  The
evidence chain works only when each profile's negative mirror is the
witness for that profile's check, in its own commit.

## Candidate Phase 3 rule

Once M6.5–M6.7 each carry at least one cross-check, audit whether a
unified schema-driven cross-checker — read profile JSON contract
fields → emit WARN per drift, no per-profile if-tree — can supersede
the explicit per-profile rules.  Phase 3 territory; do not collapse
the per-profile rules in Stage 2 even if they look symmetric, because
the explicit form is what makes the per-commit evidence chain
auditable.

The complementary Phase 3 candidate: lift the gate from
"explicitly declared in state" to "any state on a profile contract
field must match profile JSON".  Today's gate exists to keep the
positive mirrors silent without changing them; once init writes the
contract fields canonically (a Phase 3 init-time decision), the gate
can tighten.


---

## Footer note (added 2026-05-05 / Phase 3 M7.0)

The verdict matrix in this postmortem records `default_beta_codex_tapd_git / GUIDED = CONDITIONAL (1 WARN)` as the live state at the time this postmortem was written.  That finding was triggered by a missing entry in `_VALID_PROFILES` enum in `verify_beta_sprint_exit.py`, plus a missing `context_loading_method` field in the P6 profile JSON.

Phase 3 Lock-A (M7.0) resolved both: enum extended to include `default_beta_codex_tapd_git`, and the P6 JSON gained `context_loading_method=project_docs_plus_selected_files` (matching the codex preset this combo template inherits from).  P6/GUIDED now returns `PASS / 0 / 0` like the other 5 positive mirrors.  See `STAGE_2_MATRIX_INVENTORY.md` §3.2 G-b2 RESOLVED note + the 4 §5 verdict tables (post-M6.3 through post-M6.8) for the live state.

This postmortem itself is preserved as a frozen snapshot of M6.X-time evidence; the verdict line above is intentionally not edited.

---

## Footer note (added 2026-05-05 / Phase 3 M7.2)

The per-profile cross-check `if` block this postmortem describes was **collapsed** in Phase 3 M7.2 (commit pending) into the schema-driven `runtime/schema_driven_check.py` module.  Line-number references (e.g. "L509-580") point to the *pre-M7.2* layout in `scripts/verify_beta_sprint_exit.py`; that range no longer exists in the post-M7.2 source.

The per-profile field choices and per-profile gate semantics this postmortem documents are **fully preserved** in `runtime.schema_driven_check._PROFILE_CHECK_FIELDS`; the M6.X recipe is unchanged in spirit, only the implementation surface relocated.  The four per-profile cross-check tests (`tests/test_verify_*_cross_check.py`) remain byte-stable and continue to pass under the new schema-driven path, witnessing that the per-profile semantics survived collapse.

M7.1 audit established byte-identical equivalence on 16 R1 matrix rows before the collapse landed; see `ltm/pattern/2026-05-05_phase_3_schema_driven_audit.md` for the verdict.

This postmortem itself is preserved as a frozen snapshot of M6.X-time evidence; the verdict line and line-number references above are intentionally not edited.
