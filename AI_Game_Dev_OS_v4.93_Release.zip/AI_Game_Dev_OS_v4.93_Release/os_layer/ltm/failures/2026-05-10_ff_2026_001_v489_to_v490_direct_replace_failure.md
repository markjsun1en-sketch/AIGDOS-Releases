---
captured_at: 2026-05-10T22:30:00Z
actor: kai
gate: passed
evidence_ref: docs/14_state_surface_governance/STATE_SURFACE_MIGRATION_CASE_SP115.md
project_id: null
ff_id: ff_2026_001
failure_pattern: state-surface-bloat-cold-start-balloon
fix_pattern: capability-fingerprint-progressive-adoption-with-three-tier-state-surface-governance
schema_version: 1.0.0
lifecycle_state: active
---
# Direct version replacement (vN to vN+k) without progressive adoption fails for legacy projects

## Symptom

When a project running an older OS Core baseline (e.g. v4.82) attempts a
"flat replacement" upgrade to a much newer baseline (e.g. v4.89 / v4.90),
the following pathologies surface together within a single sprint:

1. Active narrative state surfaces (`sprint_board.md` / `orchestrator_log.md` /
   `logs/agents/*.md`) accumulate three responsibilities — current state +
   index/routing + historical detail — and grow past their active-window
   thresholds. In the recorded Layer 2 case, total active-surface weight
   reached **~2700 lines** before slimming.
2. Cold-start re-entry must read every active surface to recover "what is
   happening now", inflating cold-start cost linearly with project age.
   Pre-slim cold-start in the Layer 2 case pulled the full 1139-line
   orchestrator log + the 611-line EP agent log purely to derive active task.
3. Runtime registries (`task_registry.json` / `handoff_queue.json`) drift
   from the narrative surfaces because the sync tool was written against
   the original full-history schema; feeding it a slimmed current-only
   surface silently truncates registry history.
4. Re-entered agents repeatedly re-derive "current task" from large
   historical logs, increasing both token cost and drift risk.

The pathologies cluster because they share one cause (see Root Cause).

## Root Cause

The flat-replacement upgrade strategy does **not** account for three
mechanisms that the newer baseline depends on:

1. **Capability-level progressive adoption.** Newer baselines introduce
   capabilities (envelope contract / handoff registry / pack activation /
   cold-start manifest / governance node) that older projects neither
   declare nor toggle. Without per-capability fingerprint detection +
   adapter binding, the "upgrade" replaces files but the runtime cannot
   tell which capabilities the project actually has.
2. **State-surface three-tier governance.** Newer baselines assume Tier 1
   surfaces stay short, Tier 2 indexes route, and Tier 3 archives
   preserve detail. Older projects have no Tier 2 / Tier 3, so all
   historical content lives mixed into Tier 1 and the new cold-start
   tooling pulls it by default.
3. **Registry sync guard.** Newer baselines assume the sync tool
   preserves historical rows when the source surface is slimmed. Older
   sync tools silently truncate, breaking the assumption silently.

A flat replacement upgrades file content but leaves all three mechanisms
unsatisfied. The outcome is not a graceful degradation — it is a
combined functional regression that takes one full sprint to detect.

## Fix

v4.90 P0-1 (`docs/13_migration/`) and v4.90 P0-2
(`docs/14_state_surface_governance/`) together replace the flat-
replacement strategy with a **capability-fingerprint progressive
adoption** flow plus a **three-tier state-surface governance**
contract:

1. Run capability-fingerprint scan
   (`scripts/migration/scan_legacy_project.py` — Batch 2 implementation
   pending) to detect which of the 14 v4.82 → v4.89 capabilities the
   project actually has.
2. Build the four OS-minimum index shells
   (`tasks/sprint_index.md` / `tasks/task_index.md` / `logs/agents/index.md` /
   `logs/orchestrator_decision_index.md`) before moving any historical
   content; this satisfies the Tier 2 routing layer required by
   `docs/14_state_surface_governance/INDEX_SURFACE_RULES.md`.
3. Slim Tier 1 surfaces to active-window thresholds defined in
   `docs/14_state_surface_governance/CURRENT_STATE_SURFACE_RULES.md`,
   archiving moved content under the `by_date` or `by_sprint` strategy
   declared in `state_surface_policy.yaml`.
4. Update the runtime registry sync tool to satisfy the seven required
   behaviours in `docs/14_state_surface_governance/RUNTIME_REGISTRY_SYNC_GUARD.md`
   (most importantly: preserve historical rows + multi-version schema
   tolerance + dry-run mode).
5. Reorder the cold-start readset to load the four indexes before
   registry evidence tails
   (`docs/14_state_surface_governance/COLD_START_READSET_RULES.md`).

Empirical outcome from the Layer 2 case (see `evidence_ref`):

| Surface | Pre-slim | Post-slim | Reduction |
|---|---:|---:|---:|
| sprint_board.md | 233 | 55 | -77% |
| EP agent log | 611 | 55 | -91% |
| QA agent log | 440 | 48 | -89% |
| UI agent log | 269 | 48 | -82% |

Cold-start `must_read_files` resolved active task in **19 files**
(versus pulling the multi-thousand-line pre-slim Tier 1 surfaces).
Registry sync preserved **11 historical task rows** while updating
the active sprint row.

## Lesson

> **Cross-version baseline upgrades are not "replace files" — they are
> "fingerprint capabilities, govern state surfaces, then enable
> per-capability adapters". A flat replacement is a strictly weaker
> strategy that combines three regressions into a single visible
> failure, and is detectable only after one sprint of operation.**

Derived rules (Layer 1):
- `docs/13_migration/PROGRESSIVE_ADOPTION_GUIDE.md` — 7-step flow
- `docs/14_state_surface_governance/STATE_SURFACE_LAYERING.md` — three-tier model
- `docs/14_state_surface_governance/RUNTIME_REGISTRY_SYNC_GUARD.md` — seven required behaviours
- `docs/14_state_surface_governance/COLD_START_READSET_RULES.md` — OS minimum 7-item contract

## Commit Refs

- v4.90 Batch 1 (Progressive Adoption / Protocol Core):
  - `291ed53` — 20-file skeleton
  - `f989166` — 14 capability fingerprints
  - `00c475a` — 63 fingerprint regex unit tests
- v4.90 Batch 3 (State Surface Governance):
  - `f41123b` — governance skeleton + Layer 1 lint gate
  - `fa98237` / `3d2cbc9` / `0d87bd7` — five governance validators
  - `16d67ab` — generate_state_surface_index
  - `946aff6` — four schema tightenings + governance node + self-validation tests
- v4.90 Batch 3.5 (Layer 2 case):
  - `53cf4dc` — STATE_SURFACE_MIGRATION_CASE evidence

## Similar situations

Any large-step baseline upgrade (vN → vN+k where k ≥ 2) on a project
older than the source-of-truth governance docs is a candidate for the
same failure shape. Recommended pre-flight checklist:

1. Run `scripts/migration/scan_legacy_project.py` to detect installed
   capabilities (Batch 2).
2. Run `scripts/governance/audit_state_surface_size.py` against the
   project's active surfaces to flag any Tier 1 file already exceeding
   the thresholds in CURRENT_STATE_SURFACE_RULES.md.
3. Verify the project's registry sync tool satisfies all seven behaviours
   in RUNTIME_REGISTRY_SYNC_GUARD.md, especially clause (1) preserve
   historical rows and clause (7) dry-run mode (which the Layer 2 case
   itself flagged as a remaining gap — see case study §6 G1).
4. Verify the project's cold-start readset declaration (typically in
   `runtime/config/context_profiles_manifest.json` or equivalent) is
   shape-compatible with the OS minimum readset contract.

If any of those four pre-flight checks regresses, the project is in the
ff_2026_001 risk zone and should adopt v4.90 P0-1 + P0-2 before
attempting a flat replacement.
