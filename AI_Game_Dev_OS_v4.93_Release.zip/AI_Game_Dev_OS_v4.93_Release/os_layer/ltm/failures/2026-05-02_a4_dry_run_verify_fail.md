---
captured_at: 2026-05-03T22:50:00Z
actor: kai_phase_1_operator
gate: passed
evidence_ref: "MEMORY.md §7.8.2 A4 pitfall / trigger commit b08d4bb / fix commit 7a72ea6"
---
# A4 dry-run verify FAIL / error=1

## Symptom

On 2026-05-02, the first real run of the `rh_sprint_sim_01` trial after the A4 commit:

```bash
python3 AI_Game_Dev_OS_v4.89/trial_workspaces/rh_sprint_sim_01/run_sprint.py
python3 AI_Game_Dev_OS_v4.89/scripts/verify_beta_sprint_exit.py \
  --workspace AI_Game_Dev_OS_v4.89/trial_workspaces/rh_sprint_sim_01 \
  --profile workbuddy_private
```

Result:

```
"verdict": "FAIL"
"error_count": 1
"finding": {
  "category": "external",
  "severity": "ERROR",
  "message": "2 tapd.verify event(s) reported verification_ok=false"
}
```

But the driver's stdout clearly said `verification_ok=True`. Contradiction.

## Root Cause

A4 replaced the driver's `emit()` with `emit_wrapped()`, and the new wrapper moved **every field** returned by the adapter (including `verification_ok`) into the envelope's `details` sub-object:

```json
{
  "event_id": "...", "event_type": "external.tapd.verify",
  "source_layer": "tapd", "audit_status": "pending",
  "details": {"verification_ok": true, "task_id": "RH-SIM-001", ...}
}
```

But the `bad_verifies` check at `verify_beta_sprint_exit.py` L400-L417 was still reading from the **envelope root**:

```python
bad_verifies = [e for e in verifies if not e.get("verification_ok")]
```

In the new envelope, `e.get("verification_ok")` at root is `None`, and `not None` is `True` → every verify event was flagged bad → 2 ERRORs.

**The write-side contract had moved (A1-A4), but the read-side had not.** A one-sided upgrade.

## Fix

Two steps, with a short-lived compatibility bridge:

### Step 1 (A4 commit b08d4bb) — temporary compatibility bridge

`emit_wrapped()` in the driver gained a new `top_level=` kwarg that **mirrors** the 3 "fields that verify reads from root" (`task_id` / `object_id` / `verification_ok`) back to envelope root:

```python
emit_wrapped(..., top_level={
    "task_id": ext_id,
    "object_id": obj_id,
    "verification_ok": verify.get("verification_ok", False),
})
```

This let the A4 commit run green on its own.

### Step 2 (A5 commit 7a72ea6) — the real read-side upgrade

Introduce `_ev_get(event, key, default)` in `verify_beta_sprint_exit.py`:

```python
def _ev_get(event: dict, key: str, default=None):
    if key in event:
        return event.get(key, default)      # root first
    details = event.get("details")
    if isinstance(details, dict) and key in details:
        return details.get(key, default)    # details fallback
    return default
```

4 call sites were converted from `event.get(...)` to `_ev_get(event, ...)`.

At the same time, `run_sprint.py`'s `top_level=` kwarg was marked **deprecated** (not deleted — clean-up deferred to Phase 2 Stage 2).

### Two-shape validation

- **Case 1 (monkey-patch disables `top_level` mirroring)**: adapter events carry only the 9 canonical fields — **no** root mirror — yet verify still reports `verdict=CONDITIONAL / error=0` (`_ev_get` reads from `details`).
- **Case 2 (normal run, bridge active)**: dual-write — verify still reports `verdict=CONDITIONAL / error=0` (root takes priority).

Both shapes work; the contract is truly unified.

## Commit Refs

- **Introduced the bug**: `b08d4bb refactor(trial): rh_sprint_sim_01 driver uses wrap_external_record` (A4).
- **Temporary bridge (same commit)**: the `top_level=` kwarg added in `b08d4bb`'s `emit_wrapped`.
- **Root fix**: `7a72ea6 feat(verify): envelope-aware _ev_get for adapter-sourced fields + driver top_level deprecated` (A5).

## Lesson

**Contract upgrades must be synchronous across read and write.** Moving only the write side (A1-A4) leaves a gap between adapter and verifier; only by also upgrading the read side (A5) does the contract actually unify.

Derived rules:
- [envelope_9_field_contract](../os/envelope_9_field_contract.md) — the write side.
- [ev_get_envelope_aware_read](../os/ev_get_envelope_aware_read.md) — the read side.
- [top_level_deprecation_rule](../os/top_level_deprecation_rule.md) — life cycle of the compatibility bridge.
- [helper_scope_boundary](../os/helper_scope_boundary.md) — why `_ev_get` does not auto-promote in the other direction.

## Similar situations to watch for

Any refactor that "moves fields from a flat shape to a nested shape" risks the same failure. Fix checklist:
1. Before the change, `grep` every read site.
2. After the change, upgrade the read side **in the same commit** as the write side (or an adjacent commit, with an explicit transitional bridge).
3. At least one pytest with the bridge disabled, to prove the read side is self-closing.
