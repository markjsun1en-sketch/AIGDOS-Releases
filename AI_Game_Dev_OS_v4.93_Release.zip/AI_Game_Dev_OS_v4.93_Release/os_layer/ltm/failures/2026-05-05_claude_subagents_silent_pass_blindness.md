---
captured_at: 2026-05-05T20:35:00Z
actor: kai_phase_2_operator
gate: passed
evidence_ref: "MEMORY.md §M6.7 / trigger commit 37db6ed / fix commit pending-M6.7"
---
# claude_code_subagents contract-level parity is not validated by silent PASS

## Symptom

M6.6 closed (commit `37db6ed` on 2026-05-05) with the
claude_code_agent_teams negative parity wired up.  Coming into M6.7,
the claude_code_subagents profile still presented a clean per-mirror
verdict (unchanged through M6.3 / M6.4 / M6.5 / M6.6 closes):

| profile / workspace | SCAFFOLD | GUIDED |
|---------------------|----------|--------|
| claude_code_subagents / __claude_code_subagents | PASS | PASS |

The recurring lesson — "parity is the verifier can tell apart the
profile from its negation" — predicted the same gap for
claude_subagents.  M6.7 entry, however, hit a structural collision
that the prior three milestones never faced:

```
$ diff config/profiles/codex.json config/profiles/claude_code_subagents.json
# coordination_model: BOTH parent_subagents
# writeback_owner:    BOTH parent
# (and isolation_unit, cleanup_owner, merge_mode are also identical)
```

The dimension pair used by M6.4 / M6.5 / M6.6 (coordination_model +
writeback_owner) **cannot be reused** for claude_subagents — the
codex/cursor/claude_teams symmetric drift values
(`private_coordinated` / `main_session`) would fail claude_subagents's
own ground truth check, but the contract semantics get muddled
because both codex and claude_subagents legitimately share
`parent_subagents` / `parent`.  Reusing those dimensions would make
the test logically valid but evidentially weak.

M6.7 picked a different dimension pair: `audit_collector`
(claude_subagents ground truth = `claude_subagents_collector`) +
`context_loading_method` (= `claude_docs_plus_hooks`).  Both are
string-valued and unique per profile.

Negative mirror generated first (per the Step 3 silent-PASS
discipline):

```bash
$ python3 scripts/mirror_trial_workspace.py \
    --source trial_workspaces/rh_sprint_sim_01 \
    --target trial_workspaces/rh_sprint_sim_01__claude_code_subagents_negative \
    --profile claude_code_subagents \
    --inject-violation contract_drift
{"profile": "claude_code_subagents", "files": 12, "bytes": 110965,
 "injected_violation": "contract_drift",
 "injected_fields": {"audit_collector": "legacy_collector",
                     "context_loading_method": "project_docs_plus_selected_files"}}
```

`legacy_collector` is a deliberate non-existent collector identifier
(simulating a stale config carry-over); `project_docs_plus_selected_files`
is codex's value (simulating profile mis-stamping).  Both contradict
claude_subagents's ground truth.

Running verify against the mirror **before any code change**:

```
$ beta_sprint_driver.py --profile claude_code_subagents --maturity GUIDED \
    --workspace trial_workspaces/rh_sprint_sim_01__claude_code_subagents_negative
verdict=PASS / error=0 / warn=0 / findings=[]
```

A workspace that explicitly declares the claude_subagents contract
is **violated** in two newly-instrumented dimensions still produced
a clean PASS.  Fourth consecutive silent-PASS confirmation.

## Root Cause

The same root pattern as M6.4 / M6.5 / M6.6: `verify.py`'s vocabulary
at M6.6 close had three profile-specific rules (codex / cursor /
claude_teams) all keyed on `coordination_model` + `writeback_owner`.
None of them touch `audit_collector` or `context_loading_method`,
nor do they fire on a `claude_code_subagents`-declared state.
Therefore claude_subagents-shaped drift on profile-unique dimensions
goes undetected by design.

The structural twist M6.7 uniquely surfaced: even when a profile is
willing to share another profile's coordination_model /
writeback_owner ground truth (codex ↔ claude_subagents), the parity
tests must use *some* dimension where ground-truth divergence exists.
Otherwise a negative mirror cannot meaningfully diverge.  The fix
forces M6.7 to enumerate the profile JSON to find a dimension pair
where claude_subagents differs from every other profile — not just
from one of them.

## Fix

Three coordinated changes, single commit (M6.7):

1. **Generator** (`scripts/mirror_trial_workspace.py`):
   `_CONTRACT_DRIFT_FIXTURES` gained a `claude_code_subagents`
   entry with `audit_collector=legacy_collector` and
   `context_loading_method=project_docs_plus_selected_files`.
   +13 lines (incl. inline rationale comment) / -0.  Existing
   codex / cursor / claude_teams entries byte-stable.  Default
   behaviour (no `--inject-violation`) unchanged, so the existing
   six positive mirrors regenerate byte-identical.

2. **Verifier** (`scripts/verify_beta_sprint_exit.py`): added a
   claude_subagents block to `check_init_integrity`.  Both rules
   are gated on `runtime_state.profile == "claude_code_subagents"`
   and on the contract field being *explicitly declared*.  Both
   fire WARN, not ERROR.  +28 lines including docstring (per EP
   scope-guard ≤30, identical bound to M6.4-M6.6).  M6.4 codex /
   M6.5 cursor / M6.6 claude_teams blocks byte-stable.

   Notable: this is the **first** cross-check block that uses a
   different `contract_field` set than the prior three, breaking
   the otherwise-symmetric pattern.  This is a deliberate
   signal-shape decision driven by collision avoidance, and it
   strengthens (not weakens) the eventual Phase 3 audit because
   it forces any future schema-driven checker to handle a
   non-uniform contract surface.

3. **Negative mirror**: generated at
   `trial_workspaces/rh_sprint_sim_01__claude_code_subagents_negative/`.
   Post-fix verify run:

   ```
   verdict=CONDITIONAL / error=0 / warn=2
   findings:
     - init/WARN audit_collector schema drift
     - init/WARN context_loading_method schema drift
   ```

The negative mirror demonstrates the new checks fire; the
claude_subagents positive mirror still passes (clean PASS, 0
findings) under both SCAFFOLD and GUIDED.  All other M6.3-M6.6
verdicts retain their pre-existing severity.

## Lesson

**Four consecutive profiles, four consecutive silent-PASS
discoveries, four consecutive fixes.**  But M6.7 also added a
structural twist that the prior three did not surface:

**Symmetric reuse of the same cross-check dimensions is not
load-bearing for the parity claim.**  What is load-bearing is that
the dimension pair chosen for each profile (a) carries a unique
ground truth for that profile and (b) admits a contradiction the
verifier could not previously detect.  M6.4 / M6.5 / M6.6 happened
to share dimensions because their ground truths happened to differ;
M6.7 had to switch dimensions because they happened to coincide.

This is the cleanest evidence yet that **the per-profile if-tree's
informational redundancy is partial, not total** — codex / cursor /
claude_teams are mutually redundant on the
coordination_model+writeback_owner pair, but claude_subagents
contributes orthogonal information on audit_collector +
context_loading_method.  Phase 3 audit must therefore consider not
"can we collapse these blocks" but "can we *generalise* over a
heterogeneous contract surface".  Schema-driven checker must read
each profile JSON's full contract surface, not just the four
fields covered by M6.4-M6.6.

## Commit Refs

- **Trigger commit** (M6.6 close, prerequisite): `37db6ed`
- **Fix commit** (M6.7): pending — recorded in MEMORY §M6.7
  sub-section

## Similar situations to watch for

M6.7 is the last per-profile dry-run in Stage 2.  M6.8 (regression
suite) and M6.9 (charter close) follow.  However, the per-profile
recipe documented across the four postmortems is the canonical
template for any future profile addition — should
`v4.90+ / experimental_profile_X` ever be admitted, apply the same
seven steps in this order, with one structural extension:

0. **(new for M6.7+)** Diff the new profile's JSON contract surface
   against every existing profile.  If `coordination_model +
   writeback_owner` produces a unique ground truth, reuse those
   dimensions.  Otherwise pick the smallest set of fields where
   the new profile is uniquely-valued.

Then steps 1-7 unchanged.

## Candidate Phase 3 rule (now with all four samples in hand)

Three of four samples (codex / cursor / claude_teams) share the
same cross-check shape; the fourth (claude_subagents) does not.
Phase 3 audit candidates after Stage 2 close:

1. **Schema-driven cross-checker** — read profile JSON's full
   contract surface → emit WARN per drift on every declared field
   that mismatches ground truth.  This subsumes both the symmetric
   trio (codex / cursor / claude_teams blocks) and the asymmetric
   M6.7 case.  Recommended path forward.
2. **Lift the gate** from "explicitly declared in state" to "any
   declared profile contract field must match profile JSON"
   (requires init-time canonical write of the full contract
   surface; bigger change, defer pending init refactor).

The four per-profile blocks should remain intact in Stage 2 close;
they are the auditable evidence chain for the schema-driven
collapse to compare against.  Only collapse them when the
generalised checker's behaviour is provably equivalent on every
existing positive + negative mirror.


---

## Footer note (added 2026-05-05 / Phase 3 M7.0)

The verdict matrix in this postmortem records `default_beta_codex_tapd_git / GUIDED = CONDITIONAL (1 WARN)` as the live state at the time this postmortem was written.  That finding was triggered by a missing entry in `_VALID_PROFILES` enum in `verify_beta_sprint_exit.py`, plus a missing `context_loading_method` field in the P6 profile JSON.

Phase 3 Lock-A (M7.0) resolved both: enum extended to include `default_beta_codex_tapd_git`, and the P6 JSON gained `context_loading_method=project_docs_plus_selected_files` (matching the codex preset this combo template inherits from).  P6/GUIDED now returns `PASS / 0 / 0` like the other 5 positive mirrors.  See `STAGE_2_MATRIX_INVENTORY.md` §3.2 G-b2 RESOLVED note + the 4 §5 verdict tables (post-M6.3 through post-M6.8) for the live state.

This postmortem itself is preserved as a frozen snapshot of M6.X-time evidence; the verdict line above is intentionally not edited.

---

## Footer note (added 2026-05-05 / Phase 3 M7.2)

The per-profile cross-check `if` block this postmortem describes was **collapsed** in Phase 3 M7.2 (commit pending) into the schema-driven `runtime/schema_driven_check.py` module.  Line-number references (e.g. "L509-580") point to the *pre-M7.2* layout in `scripts/verify_beta_sprint_exit.py`; that range no longer exists in the post-M7.2 source.

The per-profile field choices and per-profile gate semantics this postmortem documents are **fully preserved** in `runtime.schema_driven_check._PROFILE_CHECK_FIELDS`; the M6.X recipe is unchanged in spirit, only the implementation surface relocated.  The four per-profile cross-check tests (`tests/test_verify_*_cross_check.py`) remain byte-stable and continue to pass under the new schema-driven path, witnessing that the per-profile semantics survived collapse.

M7.1 audit established byte-identical equivalence on 16 R1 matrix rows before the collapse landed; see `ltm/pattern/2026-05-05_phase_3_schema_driven_audit.md` for the verdict.

This postmortem itself is preserved as a frozen snapshot of M6.X-time evidence; the verdict line and line-number references above are intentionally not edited.
