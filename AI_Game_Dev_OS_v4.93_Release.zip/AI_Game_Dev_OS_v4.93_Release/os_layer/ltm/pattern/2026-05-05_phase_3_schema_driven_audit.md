---
captured_at: 2026-05-05T21:30:00Z
actor: kai_phase_3_operator
gate: passed
evidence_ref: "MEMORY.md §7.12 / Lock-A commit 7db4c69 / Lock-B fix commit pending-M7.1"
---
# Phase 3 Lock-B audit — schema-driven cross-checker is byte-identical to the per-profile if-tree

## Question

Stage 2 closed with four per-profile cross-check ``if`` blocks
(M6.4 codex / M6.5 cursor / M6.6 claude_teams / M6.7
claude_subagents) inside
``check_init_integrity``.  Total: 110 lines additions to
``verify_beta_sprint_exit.py``, four blocks of ~27 lines each, all
within the EP scope-guard ≤30 per block.  Three of four blocks
share the same dimension pair (``coordination_model +
writeback_owner``); the fourth uses a different pair
(``audit_collector + context_loading_method``) due to ground-truth
collision with codex.  Per the Stage 2 close commits, the four
blocks form an auditable evidence chain — but they are
*per-profile, hard-coded* and grow O(N profiles).

**Phase 3 audit question**: can a single schema-driven cross-checker
that reads each profile JSON's contract surface produce the same
findings — *byte-identical* — on the 16-row R1 regression matrix?
If yes, the per-profile if-tree is informationally redundant and
can be collapsed in a follow-up milestone.

## Methodology

Three coordinated changes, single audit commit (M7.1):

1. **Prototype** ``runtime/schema_driven_check.py`` (~150 lines incl
   docstring): a single ``schema_driven_init_check(state, state_path)``
   function that
   - reads ``runtime_state.profile`` (or ``runtime_profile``);
   - looks up ``config/profiles/<profile>.json`` for ground truth;
   - iterates a per-profile field allowlist
     (``_PROFILE_CHECK_FIELDS``) which encodes the same field choices
     M6.4-M6.7 made;
   - emits ``_finding(category="init", severity="WARN", ...)`` on
     declared-vs-ground-truth mismatch, using the exact M6.4-M6.7
     message phrasing.

2. **Env switch** in
   ``scripts/verify_beta_sprint_exit.check_init_integrity``: when
   ``STAGE_2_USE_SCHEMA_CHECKER=1``, the per-profile if-tree is
   bypassed and the schema-driven path is invoked instead.  Default
   path (env unset or ``=0``) keeps the M6.4-M6.7 four blocks
   byte-stable.

3. **Equivalence test** ``tests/test_schema_driven_equivalence.py``
   (~150 lines): parametrises over the 16 R1 rows, spawns the driver
   subprocess twice per row (default path then schema-driven path),
   and asserts the stdout JSON envelopes are *byte-identical* string
   equality.  17 cases total: 16 matrix rows + 1 matrix-size lock.

The choice of *byte-identical* (rather than *structurally
equivalent*) is deliberate: a weaker comparison would tolerate
silent semantic drift, and the Stage 2 silent-PASS discipline we
just spent four milestones building is exactly the discipline that
forbids that.

## Findings

**🎯 All 16 matrix rows produce byte-identical envelopes between the
default per-profile if-tree path and the schema-driven prototype
path.**

Empirical evidence:

```
$ pytest tests/test_schema_driven_equivalence.py -v
============================= 17 passed in 1.29s ==============================
```

The 17 cases break down as:
- 12 positive rows (6 mirrors × 2 maturity): all `verdict=PASS / 0
  WARN / 0 ERROR / findings=[]` — schema-driven path emits nothing
  because the gate-by-explicit-declaration is identical.
- 4 negative rows (codex / cursor / claude_teams / claude_subagents
  GUIDED): all `verdict=CONDITIONAL / 2 WARN / 0 ERROR / 2 init/WARN
  findings with the right contract_field set` — schema-driven path
  iterates the per-profile field allowlist in the same order the
  M6.4-M6.7 blocks emit, producing the exact same JSON.
- 1 matrix-size lock: passes structurally.

**Cross-validation against M6.8 R1 regression**: running the full
``test_stage_2_regression_r1.py`` under
``STAGE_2_USE_SCHEMA_CHECKER=1`` also produces 17/17 PASS — i.e.
the schema-driven path satisfies the M6.8 acceptance contract on
its own (verdict / error_count / warn_count / contract_field set
all match the post-M6.7 inventory §5 expectations).

Full pytest suite under default path: 178 passed (= 161 from
post-M6.9 + 17 new equivalence cases).  No prior tests regressed.

## Why byte-identical worked on the first attempt

Three design choices made it work:

1. **Reuse `_finding()`** — the same envelope-builder verify.py uses
   internally.  No risk of key ordering / extra metadata divergence.

2. **Match the message phrasing exactly** — copied the f-string
   verbatim from each per-profile block:
   ``f"profile={p} requires {field}={expected!r}, got {actual!r} —
   schema drift suspected"`` (with ``— `` em-dash exactly as in
   M6.4-M6.7).

3. **Match emit order** — the per-profile blocks emit
   ``coordination_model`` before ``writeback_owner`` (M6.4-M6.6) or
   ``audit_collector`` before ``context_loading_method`` (M6.7).
   The schema-driven path iterates a per-profile tuple in
   ``_PROFILE_CHECK_FIELDS`` keyed in the same order, so emit order
   matches.

A naive schema-driven implementation that scanned all profile JSON
fields blindly would have *failed* this audit — it would emit
findings for ``isolation_unit`` / ``cleanup_owner`` / ``merge_mode``
on profiles where the M6.4-M6.7 blocks don't check those, breaking
byte-identical.  The decision to keep a per-profile field allowlist
(``_PROFILE_CHECK_FIELDS``) is what preserved equivalence.

## Recommendation

**Phase 3 Step 2 — collapse the per-profile if-tree — is supported by
the audit evidence**, with the following caveats:

1. **Keep the per-profile field allowlist** (``_PROFILE_CHECK_FIELDS``).
   Replacing it with "scan all profile JSON fields" would not be
   byte-equivalent — it would surface previously-uncovered fields
   like ``isolation_unit`` which would be a *new* feature, not a
   refactor.  That's a separate decision, not part of this audit.

2. **Preserve the four postmortems**
   (``ltm/failures/2026-05-05_*_silent_pass_blindness.md``) byte-stable.
   They are the auditable evidence chain that *justified* the
   per-profile blocks; they remain valid as the "why we trust this
   contract surface" record after the blocks themselves are
   collapsed.

3. **Preserve the four per-profile cross-check tests** byte-stable
   (``tests/test_verify_*_cross_check.py``).  These tests directly
   call ``check_init_integrity`` (in-process) and assert per-profile
   gate behaviour — they should continue to pass under the
   schema-driven path because the gate semantics are preserved.
   If they fail under the schema-driven path, the audit failed.

4. **The R1 regression test
   (``test_stage_2_regression_r1.py``) and this equivalence test
   (``test_schema_driven_equivalence.py``) become the dual contract
   surface** for any future profile addition: every new profile
   must (a) appear in ``_PROFILE_CHECK_FIELDS`` if it has a
   cross-check, (b) extend the R1 ``_MATRIX``, and (c) pass the
   equivalence test.  This is a stricter contract than the M6.8
   R1-only regression alone provides.

## Decision

EP retains the call.  Two choices:

- **Option A** (audit-only, EP Q1=A, current state after this
  commit): keep the env switch in verify.py and both checker paths
  alive; merge audit report; do nothing else.  Per-profile if-tree
  remains the canonical path; schema-driven prototype is the
  documented alternative.  Lowest risk; preserves Stage 2 evidence
  ladder unchanged.

- **Option B** (collapse, future M7.2 candidate): remove the
  per-profile if-tree (110 lines) and make the schema-driven path
  the default.  Reduce ``check_init_integrity`` by ~110 lines net
  (offset by the schema_driven_check import / setup).  Acceptance
  gate already met (this audit).  Risk: postmortems' "L509-580 byte
  stable" claim no longer holds at the line-number level.  The
  per-profile cross-check tests still pass, and the R1 + equivalence
  tests still pass, so behaviour is preserved — but the historical
  reading of "M6.4 codex block lives at L510" no longer applies.

Recommendation: **Option A for now**, defer Option B to a Phase 3
Step 2 milestone that comes with explicit EP sign-off and a
followup commit that updates the four postmortems' line-number
references.  M7.1 audit produced sufficient evidence to make Option
B safe; the question is whether the evidence-ladder simplification
is worth the historical-reference churn.

## Lesson

**Phase 3 audit-on-evidence is structurally faster than audit-on-prediction.**
The M6.4-M6.7 per-profile silent-PASS recipe took 4 milestones × 1
commit each = 4 commits to establish.  M7.1 audit answered the
"can we collapse?" question in a *single* commit because the
evidence ladder (4 postmortems + 4 cross-check blocks + 16-row R1
matrix) was already in place.  If we'd tried to skip M6.4-M6.7 and
go directly to schema-driven cross-checker, we wouldn't have had
the matrix to test against — we wouldn't have known what
"byte-identical" meant.

The Stage 2 four-fold silent-PASS recipe was its own justification.

## Commit Refs

- **Trigger commit** (M6.9 Stage 2 close): `57e1a80` (tag `v4.89-phase-2-m6`)
- **Lock-A prerequisite** (M7.0 G-b2 fix): `7db4c69`
- **Lock-B audit commit** (M7.1): pending — recorded in MEMORY §7.12
  sub-section

## Phase 3 candidate Step 2 (deferred per Recommendation)

If EP elects Option B in a future milestone:

1. Remove the four per-profile cross-check ``if`` blocks (M6.4-M6.7)
   from ``check_init_integrity``.  Replace with a single call to
   ``schema_driven_init_check(state, state_path)``.
2. Remove the ``STAGE_2_USE_SCHEMA_CHECKER`` env switch (no longer
   needed; default path becomes the only path).
3. Update the four postmortems with a Phase 3 footer noting the
   collapse and pointing to the audit report (this file).
4. Update ``runtime/MATURITY_MATRIX.md`` §3.4 (or §3.3 footer) noting
   the new line count.
5. Run the full equivalence test under the new code path (it should
   still pass — just trivially, since both paths are now the same).
6. Tag ``v4.89-phase-3-collapse``.

Step 2 is a *behaviour-preserving* refactor; the audit-on-evidence
done here makes it safe.

---

## Footer note (added 2026-05-05 / Phase 3 M7.2 collapse executed)

The Phase 3 Step 2 candidate described in this report (Option B —
collapse the four per-profile if blocks into the schema-driven
path) was **executed in M7.2** (commit pending).  Empirical
outcome:

- ``scripts/verify_beta_sprint_exit.py``: -103 net lines
  (124 lines removed across L504-628 covering the env switch +
  4 per-profile blocks; 21 lines added for top-level import +
  inline call site).
- All 178 pytest cases (post-M7.1 baseline) continue to pass
  unchanged.  The 4 per-profile cross-check tests
  (``test_verify_*_cross_check.py``) explicitly validate that the
  per-profile semantics survive the collapse — they remain
  byte-stable and continue to pass.
- The equivalence test
  (``test_schema_driven_equivalence.py``) becomes trivial
  (both paths now invoke the same code) but is **kept** as a
  regression guard for future profile additions; see its
  module docstring for the rationale.
- 4 postmortems in ``ltm/failures/2026-05-05_*_silent_pass_blindness.md``
  gain a Phase 3 M7.2 footer note; their original verdict /
  line-number references are preserved as frozen historical
  snapshots.
- Tag ``v4.89-phase-3-collapse`` cut at the M7.2 commit.

The Phase 3 Step 2 acceptance gate established by this audit
report (16-row byte-identical R1 envelope equivalence) was the
decisive evidence that made the collapse safe in a single commit.
