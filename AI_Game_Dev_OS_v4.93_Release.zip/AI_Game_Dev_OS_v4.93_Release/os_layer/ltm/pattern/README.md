# ltm/pattern — Pattern Experience domain

Design patterns that generalise across projects.

## Write policy

- **Primary author**: whoever discovers it.
- **Gate**: `evidence_ref` is **required** (implementation commit / PR / anchor into `MEMORY.md`).
- **Admission criterion**: a pattern is only admitted once it has been **validated in ≥2 scenarios** (not just "an idea").
- **File naming**: `pat_<pattern_name>.md`.

## Registered pattern candidates (to be ported in Phase 2 Stage 2+)

- `pat_envelope_aware_read.md` (the `_ev_get` style) — pending M4.1 or Stage 2 registration.
- `pat_pointer_shim_with_fallback.md` (the runtime_state path contract) — pending M4.1 or Stage 2 registration.
- `pat_never_raise_resolver.md` (defensive `_resolve_*_path` helper) — pending Stage 2 registration.

## Boundary vs the os domain

- **os/** rules = "in v4.89, do it this way" (concrete API / constant / path).
- **pattern/** = "ideas that apply both inside and outside the OS" (read/write two-sided upgrades / contract drift defence / canonical-pointer layering).

Stage 1 MVP **does not generate patterns proactively** — wait for Stage 2+ to distil them from real experience.
