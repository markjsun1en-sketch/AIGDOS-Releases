---
captured_at: 2026-05-06T00:45:00Z
actor: kai_phase_4_step_1_operator
gate: passed
evidence_ref: "MEMORY.md §7.13 / commits f883ffd→0ecc3e4 / pending tag v4.89-phase-4-lift"
---
# Phase 4 Step 1 — Lift gate seals the silent-PASS second-order residual

## Question

Phase 3 closed with the per-profile cross-check if-tree collapsed
into ``runtime/schema_driven_check.schema_driven_init_check`` (M7.2,
``-103`` net lines).  The 16-row R1 regression matrix, four
per-profile cross-check test files, and the schema-driven
equivalence test all stayed byte-stable.  Audit-on-evidence outcome:
**clean**.

But the parent spec ``V4_89_PHASE_4_PLAN.md`` §0 issue #1 named a
**second-order silent-PASS residual** that the M7.1-M7.2 audit had
explicitly *deferred*: the cross-check was gated on the contract
field being **explicitly declared** in ``runtime_state``.  Concretely:

```python
for field in _PROFILE_CHECK_FIELDS[declared]:
    actual = state.get(field)
    if actual is None:
        # Not explicitly declared in state — gate by-design.
        continue
    ...
```

``init_runtime_env._stub_init`` hard-wrote 6 fields and conditionally
forwarded 5 optional fields from ``config_data``.  It **did not read
the profile JSON at all**.  As a result, the four contract surface
fields the cross-check inspected (``coordination_model`` /
``writeback_owner`` / ``audit_collector`` / ``context_loading_method``)
never appeared in a stock-init runtime state.  ``actual is None``
fired on every positive mirror; the cross-check looked green but
**never ran**.

**Phase 4 Step 1 question**: can we rewire init + the cross-check so
that the contract surface is **canonically written** at init time
and **mandatorily inspected** at verify time, without breaking the
178-test baseline or the immutable v4.88_Release scaffold?

## Methodology

7-commit chain on branch ``revise/phase-1-fork``, single thread, ~2h
session.  Each commit ends with pytest green (one transient window,
documented and explicitly closed in the same chain).

| # | Commit | Theme |
|--:|---|---|
| 1 | ``f883ffd`` | M7.3.1 audit doc — 8 (profile, field) pairs + Q1-Q4 decisions + L202-208 lift target |
| 2 | ``fdba43b`` | M7.3.2a ``_stub_init`` writes 4-field contract surface from profile JSON |
| 3 | ``0e51e61`` | M7.3.2b 14-case regression test for the new producer path |
| 4 | ``6414cac`` | M7.3.3 ``schema_driven_init_check`` lifts ``actual is None`` → ERROR |
| 5 | ``7e0499b`` | M7.3.4a regenerate 11 mirrors + ``mirror_trial_workspace._rewrite_runtime_state`` re-stamps contract surface |
| 6 | ``0ecc3e4`` | M7.3.4b narrow R1 expected back to PASS/CONDITIONAL + close mirror-guided transient |
| 7 | (this commit) | M7.3.5 — postmortem + MATURITY §3.5 + CHANGELOG §M7.3 + parent-spec ✅ |

EP-locked 4 decisions before commit 1:

1. **Q1 = A — strict 4-field surface** (the union of
   ``_PROFILE_CHECK_FIELDS`` across the 4 cross-checked profiles =
   8 (profile, field) pairs; nested structs like ``rule_loading``
   excluded for unambiguity).
2. **Q2 = A — missing field severity = ERROR** (downgrading to WARN
   would tacitly admit init MAY skip, which undoes the lift).
3. **Q3 = A — split into 7 commits** (M7.3.2 init/test split,
   M7.3.4 mirror-content/sha-lock split — diff readability over
   parent-spec's 3-5 estimate).
4. **Q4 = A — wb_private + default_beta_codex_tapd_git: write but
   not check** (producer ≠ consumer; uniform write path, cross-check
   stays at the original 4 profiles).

Source-of-truth alignment across three modules:

```
scripts/init_runtime_env._CONTRACT_SURFACE_FIELDS   (producer)
runtime/schema_driven_check._CONTRACT_FIELDS         (consumer)
scripts/mirror_trial_workspace._CONTRACT_SURFACE_FIELDS (re-stamper)
        ↓ all three list the same 4 primitive strings ↓
   coordination_model / writeback_owner /
   audit_collector / context_loading_method
```

## Findings

**🎯 Silent-PASS second-order residual is sealed.  16-row R1 matrix,
4 per-profile cross-check tests, schema-driven equivalence test all
byte-stable on the new matrix.  pytest 178 → 192 (+14 init tests).**

R1 verdict matrix post-M7.3:

| Row count | profiles | maturity | verdict | err | warn |
|--:|---|---|---|--:|--:|
| 12 | wb_private, codex, cursor, claude_teams, claude_subagents, default_beta | SCAFFOLD or GUIDED | PASS | 0 | 0 |
| 4 | codex_neg, cursor_neg, claude_teams_neg, claude_subagents_neg | GUIDED | CONDITIONAL | 0 | 2 |

E1-E6 acceptance gates met:
- E1 ✅ pytest 192 / 0 regression (target ≥ 183).
- E2 ✅ R1 16-row byte-stable.
- E3 ✅ 4 per-profile cross-check tests byte-stable (24 cases).
- E4 ✅ ``test_schema_driven_equivalence`` byte-stable (17 cases).
- E5 ✅ trial ``rh_sprint_sim_01`` GUIDED → PASS / 0 error / 0 warn.
- E6 ✅ ``v4.88_Release/`` top commit unchanged at ``58346b3``.

E7-E8 closed by this commit + EP hand-stamp:
- E7 ✅ this postmortem + MATURITY §3.5 + CHANGELOG §M7.3 + parent
  spec §一 Step 1 ☑.
- E8 ⏳ EP cuts ``v4.89-phase-4-lift`` tag.

## Pattern: cross-commit transient with explicit open / close

The chain hit one cross-commit transient that is worth recording as
a reusable pattern.  After commit 4 (M7.3.3 lift) flipped the gate
to ERROR, the existing R1 mirror state files predated the contract
surface write — so the 4 GUIDED positive rows produced FAIL/0/2
verdicts.  The mirrors only get fixed in commit 5.

Two paths were available:
- **A.** Let pytest go red between commits 4 and 5.  Each commit
  individually is correct, but the chain has a window where pytest
  is broken.
- **B.** Open and close the transient explicitly in the same chain.
  Commit 4 widens the R1 expected matrix and the mirror-guided
  envelope to *match the transient state*; commit 6 narrows them
  back.  Each commit ends green; the transient state is *named* in
  the matrix.

We chose **B**.  In ``test_stage_2_regression_r1.py`` this looked
like:
- Commit 4 locked 4 GUIDED positive rows to ``FAIL/0/2 +
  {coord, writeback}`` (or ``{audit, ctx}`` for claude_subagents).
- Commit 6 narrowed the same 4 rows to ``PASS/0/0 + frozenset()``.
- The R1 helper renamed ``init_warn_fields → init_contract_fields``
  to union both severities, so the same matrix structure carries
  three generations of the chain (pre-M7.3.3 silent-PASS,
  M7.3.3-transient FAIL, post-M7.3.4b PASS) without further
  refactoring.

In ``test_mirror_trial_workspace.py`` the rc envelope went
``(0, 1) → (0, 1, 2) → (0, 1)``.  Each docstring documents the
window with a "if you see this transient again, do X" note for
future milestones.

The cost is two commits of expected-relock churn instead of one;
the benefit is that ``git bisect`` never lands on a red commit.
For chains where the transient is a single commit window (like
this one), pattern B is the correct trade.

## Anti-pattern caught: producer-only test does not catch consumer regression

When commit 3 added 14 new ``_stub_init`` regression tests, **all of
them passed** even before commit 4 lifted the gate.  The reason:
``_stub_init`` is the producer side; the consumer side
(``schema_driven_init_check``) was the silent-PASS residual.  A
producer-only test cannot catch a consumer-side gate that
short-circuits to PASS.

Lesson: when an audit identifies a producer/consumer pair as the
locus of a residual, the regression suite needs **both** a producer
contract test AND a consumer contract test.  M7.3.2b covered the
producer; M7.3.3 carried both the consumer source change AND the
expected-relock test diffs that would have caught the consumer-side
regression in isolation.

## Files touched (chain summary)

```
docs/06_runtime_profiles/PHASE_4_LIFT_GATE_AUDIT.md   (new, +223)
scripts/init_runtime_env.py                            (+73, -0)
scripts/mirror_trial_workspace.py                      (+66, -3)
runtime/schema_driven_check.py                         (+39, -10)
tests/test_init_writes_contract_surface.py             (new, +265)
tests/test_stage_2_regression_r1.py                    (+44, -45)
tests/test_mirror_trial_workspace.py                   (+25, -19)
tests/test_verify_codex_cross_check.py                 (rewrite, +96)
tests/test_verify_cursor_cross_check.py                (rewrite, +91)
tests/test_verify_claude_teams_cross_check.py          (rewrite, +99)
tests/test_verify_claude_subagents_cross_check.py      (rewrite, +128)
trial_workspaces/rh_sprint_sim_01/runtime/state/runtime_state.json
                                                       (+8, -2)
trial_workspaces/rh_sprint_sim_01__<profile>/runtime/state/runtime_state.json
                                                       (×9, +35, -8)
ltm/pattern/2026-05-06_phase_4_lift_gate.md            (this file)
runtime/MATURITY_MATRIX.md                             (§3.5 added)
CHANGELOG.md                                           (M7.3 section)
V4_89_PHASE_4_PLAN.md                                  (§一 ✅ + §九)
```

## Phase 4 Step 1 outcome

The gate is up.  ``init`` is now contractually obligated to write
the 4 contract surface fields, the cross-check raises the alarm if
they are absent, and the mirror generator keeps the surface in sync
across regenerations.  The chain advances Phase 4 to Step 2 (M8.0
Skills introduction) without leaving behind technical debt — the
transient pattern is captured, the producer-only test anti-pattern
is captured, and the producer/consumer surface is locked in three
modules at once.

EP next step: cut ``v4.89-phase-4-lift`` tag (E8).
