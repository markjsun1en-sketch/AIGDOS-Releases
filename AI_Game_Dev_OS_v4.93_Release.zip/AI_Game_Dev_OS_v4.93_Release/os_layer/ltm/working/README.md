# ltm/working/ — Session Working Memory Domain

> **Scope**: transient, in-session raw notes that have **not** been validated
> yet. This is the landing zone for rough findings before they enter the
> formal promotion pipeline.
>
> **Introduced**: v4.90 Batch 8 Step 8.1 (2026-05-13)

---

## Characteristics

- **Ephemeral**: entries here are not part of the canonical memory truth
- **Pre-validated**: no schema conformance required on write
- **Session-local**: each session/agent may write freely; conflicts are OK
- **Excluded from default `consult()`**: must opt in via `domain="working"`

## Lifecycle

```
working/  (raw note, freeform md)
    │
    │ scripts/ltm/extract_failure_candidates.py  (Batch 8.4)
    ▼
_quarantine/  (memory_candidate envelope, schema-valid)
    │
    │ scripts/ltm/promote_memory_candidate.py    (Batch 8.5)
    │    + approver + evidence_ref + schema gate
    ▼
failures/ | pattern/ | os/ | cross_project/      (canonical)
```

## Retention

- Entries older than **30 days** SHOULD be reviewed by the owning agent
- Review outcomes:
  - Promote to `_quarantine/` via `extract_failure_candidates.py`
  - Delete if the finding did not generalize
- `validate_memory_quality.py` (Batch 8.6) flags expired entries with
  severity `warning` (not `error`).

## Write path

Freeform — any agent may write `ltm/working/<descriptive-name>.md` without
approval. Recommended front-matter:

```yaml
---
title: <short description>
observed_at: 2026-05-13
session_id: <optional>
tags: [ff-candidate | pattern-candidate | note]
---
```

## Read path

Explicit opt-in only:

```python
from runtime.ltm import consult
hits = consult("my query", domain="working")
```

Not included in default or project-scoped consult (see
`config/memory_retrieval_routing_v2.yaml`, Batch 8.7).

## Populated in

- v4.90 Batch 8.1 — directory + README only (no entries yet).

## Related

- `ltm/INDEX.md` — global index of all 7 domains
- `ltm/_quarantine/` — next stage after extract
- `docs/15_ltm_v2/PROMOTION_WORKFLOW.md` — full pipeline (Batch 8.8)
