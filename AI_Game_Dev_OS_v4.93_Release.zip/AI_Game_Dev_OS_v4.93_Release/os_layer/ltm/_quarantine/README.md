# ltm/_quarantine — Gate-rejected staging zone

## When payloads land here

When the Gate rejects a `capture()` write, the payload is not dropped — it lands here so that a **later human review can decide whether to reflow or discard**.

Triggering cases:
- A non-OS domain capture missing `evidence_ref`.
- `requires_approval=True` forcing quarantine.
- (Phase 3) automatic capture flagging suspicious content.

## File naming

`YYYY-MM-DDTHH-MM-SSZ_<domain>_<slug>.quarantined.md`

## Review flow

1. Human review (OS maintainer / EP).
2. Add the missing `evidence_ref` or fix the content.
3. Either call `capture()` again to write the corrected payload into a real domain, or
4. `rm` the file to discard it.

**Stage 1 MVP rule**: no automatic expiry, no automatic deletion — the OS maintainer reviews periodically.

## Not indexed by consult

`consult()` **does not scan** `_quarantine/`. This is a staging zone, not formal LTM content.
