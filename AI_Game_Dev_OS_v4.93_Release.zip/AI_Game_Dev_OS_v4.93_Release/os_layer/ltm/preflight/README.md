# ltm/preflight/ — Preflight Consensus Memory Domain

> **Scope**: per-event preflight cases + their operational metrics.
> Forward-compat for v4.91 M-C B5B (Multi-Agent Preflight Consensus).
>
> **Introduced**: v4.91 B4 c3 (skeleton + .gitkeep × 3); B5B owns the
> first real entries.

---

## Sub-domains

| Sub-dir | Purpose | Scope (v3 router) | Read default |
|---|---|---|---|
| `cases/` | One JSON per preflight invocation (subject + consulted roles + consensus.outcome + decided_by) | (not currently routed) | not retrieved |
| `pattern_candidates/` | Pattern proposals emerging from preflight events; promotion path goes through `cross_project/candidates/` first | (not currently routed) | not retrieved |
| `metrics/` | One JSON per case: elapsed_seconds, consulted_role_count, trigger, outcome | (not currently routed) | not retrieved |

The Shared LTM v3 read router (`scripts/ltm/retrieve_with_routing.py`)
does **not** classify preflight/* into any default retrieval scope.
This is intentional: preflight content is operational, not learning
material. B5B will own its own retrieval surface; the Charter
anti-pattern #11 (preflight is not a gate-pass) prevents it from
being treated as evidence by default.

---

## Schemas

- `schemas/ltm/preflight_case.schema.json` — case envelope (1.0.0).
  Required: case_id, trigger ∈ {major_version_bump,
  cross_project_memory_policy_change, intent_boundary_policy_change,
  protected_invariant_change, tenancy_contract_change} + subject +
  consulted_roles[] + consensus + generated_at.
  Charter shape lock: consensus.decided_by is a SINGLE string (no
  votes[] field — anti-pattern #11/#12).

- `schemas/ltm/preflight_metric.schema.json` — metric envelope (1.0.0).
  Required: metric_id, case_ref, captured_at, elapsed_seconds,
  consulted_role_count.
  Charter shape lock: NO promotion / promote_to / auto_apply field
  (anti-pattern #6).

---

## Trigger taxonomy

The 5 triggers come from `schemas/version/core_update_policy.schema.json`
(v4.91 B3 c1) and stay in lockstep:

| Trigger | Forces preflight when |
|---|---|
| `major_version_bump` | Hub Core OS major version increments |
| `cross_project_memory_policy_change` | retrieval_policy / promotion gate semantics change |
| `intent_boundary_policy_change` | F-T-01 tenancy_contract changes |
| `protected_invariant_change` | runtime/protected_contracts/* changes |
| `tenancy_contract_change` | mount.yaml runtime_namespace.claims[] changes |

---

## What lives here vs `cross_project/`

| Directory | Lifecycle | Routed by v3 read pipeline? |
|---|---|---|
| `preflight/cases/` | per-event consensus record | NO (B5B owns reads) |
| `preflight/pattern_candidates/` | proposal arising from a case | NO (promotion path: → cross_project/candidates/ → cross_project/approved_patterns/) |
| `preflight/metrics/` | operational telemetry | NO (aggregate queries only) |
| `cross_project/candidates/` | candidates from any source (preflight or sprint) | YES — scope=unapproved_candidates, default-excluded |
| `cross_project/approved_patterns/` | gate-cleared patterns | YES — scope=approved_cross_project, default-included with boost 0.8 |

---

## Populated in

- v4.91 B4 c3 — directory + .gitkeep × 3 + this README. No live
  entries until M-C B5B; the schemas are stable enough to consume.

---

## Related

- `docs/22_ltm_v3/SHARED_LTM_V3_OVERVIEW.md` — overall v3 routing model
  (introduced in B4 c4)
- `docs/15_ltm_v2/MEMORY_DOMAINS_v2.md` — v2 taxonomy (preflight is
  a v3-era addition)
- `policies/charter_anti_patterns.md` §#11 #12 — preflight enforcement
  vocabulary
- `policies/core_update_policy.md` — preflight requirement matrix +
  the 5 triggers above
