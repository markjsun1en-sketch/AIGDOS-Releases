# Sprint Board

> **Status**: skeleton template (M9.0.2). v4.89 OS ships this empty board so adopting projects start from the canonical structure expected by `tools/runtime/generate_sprint_context_rollup.py` (see M9.0.4).
> **Maintenance**: human-edited markdown. The cold-start rollup parser reads `## Current Sprint` and `## Previous Sprint` second-level headings; do not rename them.
> **Working language**: English.

This file is the source of truth for sprint metadata. Each sprint section MUST contain the four canonical fields below. Optional fields are listed in §3.

---

## Previous Sprint

- Sprint Name: _none_
- Goal: _none_
- Status: _none_
- Sprint Boundary: _none_

---

## Current Sprint

- Sprint Name: _none_
- Goal: _none_
- Status: _none_
- Sprint Boundary: _none_

---

## 1. Required Fields per Sprint Section

| Field | Format | Notes |
|---|---|---|
| `Sprint Name` | string | Human-friendly name; may include a sprint id suffix matching `runtime/config/task_id_pattern.json::patterns.sprint_id`. |
| `Goal` | one paragraph | Describe what success looks like at sprint end. |
| `Status` | enum | `PROPOSED | IN_PROGRESS | PASS | PASS_WITH_NOTE | DONE | PARTIAL_DONE` (extensible per project). |
| `Sprint Boundary` | numbered list | Constraints that cannot be violated during this sprint. Cold-start rollup truncates the body to ~1600 chars when building summaries. |

## 2. Required Headings

The rollup parser depends on these literal second-level markdown headings:

- `## Current Sprint` — exactly one section.
- `## Previous Sprint` — zero or more sections (most recent first).

Do not rename or add prefixes. New sprints are added by promoting the existing `## Current Sprint` to a new `## Previous Sprint` section above the current one, then filling a fresh `## Current Sprint`.

## 3. Optional Fields

Projects may add freeform fields per sprint section. Common examples:

- `Closure:` — bullet list of evidence at sprint end.
- `Owner:` — sprint coordinator agent name.
- `Cadence:` — start/end dates.

The rollup parser preserves these fields in the per-sprint excerpt but does not require them.

## 4. Adoption Notes

A project adopting v4.89 OS replaces this skeleton in three steps:

1. Set the actual sprint name + goal in the `## Current Sprint` section.
2. Move historical sprints into `## Previous Sprint` sections in reverse-chronological order.
3. Run `tools/runtime/generate_sprint_context_rollup.py --dry-run` to confirm the parser successfully extracts each section.

## 5. References

- Cold-start audit: `docs/06_runtime_profiles/PHASE_4_M9_0_COLDSTART_AUDIT.md`
- Registry README: `runtime/registries/README.md`
- Task ID pattern: `runtime/config/task_id_pattern.json`
