# FIRST_PLAYABLE_DEFINITION

Status: active
Priority: critical
Decision Status: PROPOSED_DEFAULT

## Purpose

This document defines the minimum viable first playable for the narrative-puzzle project.

The goal of the first playable is not breadth.
It is to prove that the project’s core loop works.

## First Playable Must Prove

1. The player can understand and enter the puzzle loop.
2. Narrative context increases motivation rather than confusion.
3. Solving produces a meaningful state change.
4. Knowledge progression can be tracked and reused.
5. Guidance is helpful without destroying discovery.

## First Playable Should Include

- one small playable narrative context
- one tutorial-light puzzle
- one puzzle with a real interpretation step
- one meaningful unlock or reveal
- one basic hint ladder or readability support mechanism
- persistent tracking for at least one story state, one puzzle state, and one knowledge-state change

## First Playable Should Not Yet Depend On

- large chapter count
- heavy branching story complexity
- large hint content libraries
- many puzzle verbs
- complex live systems or meta progression

## Success Criteria

A first playable is successful if:
- the player can finish the loop
- the project's emotional and logical identity is visible
- the team can identify whether confusion comes from narrative, puzzle, or state-tracking causes
