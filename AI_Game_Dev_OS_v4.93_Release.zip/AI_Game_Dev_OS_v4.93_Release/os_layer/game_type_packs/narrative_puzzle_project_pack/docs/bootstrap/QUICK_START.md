# QUICK_START

## Read Order

All new threads or agents attached to this project should read in this order:

1. `README.md`
2. `docs/core/GAME_LOOP_HIERARCHY.md`
3. `docs/core/KNOWLEDGE_STATE_AND_PROGRESS_MAP.md`
4. `docs/specs/MODULE_MAP_AND_THREAD_PLAN.md`

Read the following only when relevant:

- `docs/specs/NARRATIVE_PROGRESS_SPEC.md`
- `docs/specs/PUZZLE_STRUCTURE_SPEC.md`
- `docs/specs/PLAYER_GUIDANCE_AND_HINT_SPEC.md`
- `docs/validation/VALIDATION_FOCUS.md`

## Default Runtime Setup

- Baseline: `v4.89_Release Run Baseline layer`
- Context Profile: `STANDARD`
- Project Pack: `narrative_puzzle_project_pack`
- Full Reference: attach only when needed

## First Alignment Goal

Before implementation starts, confirm:

- what the primary player-facing loop is
- what story progression depends on
- what puzzle progression depends on
- how knowledge state is tracked
- what the player is expected to infer
- what the game is allowed to explain directly

## Immediate First Deliverables

The first project setup pass should produce:

- a stable narrative/puzzle loop hierarchy
- a first-pass knowledge-state map
- a puzzle gating model
- a module ownership map
- a first validation focus list

## Early Anti-Failure Rule

Do not start detailed implementation before loop hierarchy, knowledge state, and progression boundaries are explicitly aligned.

The most dangerous early failure for this project type is building puzzles or story beats locally without a shared progression model.
