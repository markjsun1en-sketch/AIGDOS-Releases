# GAME_LOOP_HIERARCHY

Status: active
Module: project_core
Priority: critical
Decision Status: PROPOSED_DEFAULT

## Purpose

This document defines the canonical loop hierarchy for the project.

The project is built around three tightly linked layers:

- Narrative Progress
- Puzzle Solve Loop
- Knowledge-State Progression

These layers must not be treated as isolated content silos.
They must be arranged into a clear player-facing hierarchy so that the project preserves:

- emotional continuity
- puzzle readability
- meaningful discovery and unlock pacing

## Canonical Loop Hierarchy

### Primary Session Driver: Puzzle Solve Loop

The puzzle layer is the project's main active interaction loop.

It owns:
- observable problem spaces
- hypothesis testing
- interaction feedback
- local success/failure
- short-session agency

### Primary Emotional Continuity Layer: Narrative Progress

Narrative provides:
- motivation
- meaning
- context
- emotional pacing
- consequence framing

Narrative should not suffocate play, but it must justify why the player cares.

### Primary Long-Horizon Progress Layer: Knowledge-State Progression

Knowledge-state progression owns:
- what the player has learned
- what the world has revealed
- what systems are unlocked
- what interpretations become possible
- how prior discoveries reshape future choices

This layer distinguishes simple content consumption from real progression.

## Time Horizon Ownership

### 0–30 seconds
Owned mainly by puzzle interaction and feedback readability.

### 30 seconds–3 minutes
Owned by local puzzle progress plus narrative framing.

### 3–15 minutes
Owned by a chain of puzzle solves, discoveries, and state changes.

### Session-to-session
Owned by knowledge progression, narrative advancement, and remembered discoveries.

## Canonical Value Statement

The intended player-facing interpretation is:

- “I understand what I am trying to solve.”
- “Solving this reveals something or changes what I can do.”
- “The story gives this problem meaning.”
- “What I learn matters beyond this one screen.”

## Core Rules

### Rule 1
Puzzle is the main active layer, not decorative friction.

### Rule 2
Narrative provides context and payoff, not constant interruption.

### Rule 3
Knowledge-state progression must preserve continuity across content beats.

### Rule 4
No single layer may fully invalidate the other two.

### Rule 5
The game should reward insight, not only persistence or brute-force trial.

## Failure Modes

### Failure A — Story Dominance
Too much narrative exposition, too little solving.

### Failure B — Puzzle Isolation
Puzzles are technically functional but emotionally disconnected.

### Failure C — Knowledge Flatness
Solves do not change understanding, access, or future interpretation.

### Failure D — Hint Collapse
The system explains so much that discovery value disappears.

## Locked Proposed Default

For the initial version of the project, the proposed hierarchy is:

- Puzzle = active value
- Narrative = emotional continuity
- Knowledge Progress = long-horizon advancement

Owner confirmation is required before treating this as canonical project truth.
