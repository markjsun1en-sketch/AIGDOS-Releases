# OWNER_DECISION_STATE_MODEL

## Purpose

This file defines how owner-level decisions are tracked in this project pack.

The pack may provide proposed defaults, but final authority for project-defining direction belongs to the project owner.

## Decision States

### HYPOTHESIS
Early idea under exploration. Not yet recommended as working truth.

### PROPOSED_DEFAULT
Current suggested default provided by this pack. Usable for alignment drafts, but not final.

### APPROVED_CURRENT
Explicitly approved by the project owner for current project use.

### LOCKED_FOR_MILESTONE
Approved and treated as frozen for the current milestone unless formally reopened.

### SUPERSEDED
Previously valid, but replaced by a newer decision.

## Use Rule

Core direction should not be treated as canonical until the owner has promoted it to either:
- `APPROVED_CURRENT`
- `LOCKED_FOR_MILESTONE`

## Typical Decision Types

- primary emotional target
- puzzle density target
- hint philosophy
- story delivery mode
- gating severity
- first playable scope

## Review Rule

If a proposal materially changes:
- what the player is supposed to know
- what the player is supposed to infer
- how progression is gated
- how much narrative interrupts play

then it must be escalated to owner review.
