# KNOWLEDGE_STATE_AND_PROGRESS_MAP

Status: active
Module: progression
Priority: critical
Decision Status: PROPOSED_DEFAULT

## Purpose

This document defines how knowledge, story state, and puzzle state relate to progression.

In this project type, progression is not only item-based or level-based.
It is often based on what the player knows, what the game has revealed, and what is now interpretable.

## Canonical Progress Layers

### Layer A — Narrative State
Tracks:
- scenes viewed
- character relationship changes
- revealed backstory
- narrative branch condition state

### Layer B — Puzzle State
Tracks:
- puzzle availability
- current puzzle variables
- solved / failed / reset state
- interaction history where relevant

### Layer C — Knowledge State
Tracks:
- discovered rules
- decoded symbols
- interpreted clues
- unlocked concepts
- remembered cross-area information

### Layer D — Access State
Tracks:
- rooms/chapters unlocked
- tools / verbs unlocked
- new dialogue or clue routes opened

## Core Rules

### Rule 1
Not every puzzle solve should only grant a key or item. It may also advance interpretation.

### Rule 2
Knowledge progression should be represented explicitly in design docs, even if not always surfaced as UI.

### Rule 3
Narrative reveals should not contradict the current knowledge-state model.

### Rule 4
Puzzle progression must be able to reference narrative and knowledge state without becoming unreadable.

## High-Risk Failure Modes

- the player solved something but does not understand what changed
- the player learned something but the game does not track its downstream meaning
- the narrative claims a revelation that the puzzle arc did not earn
- access gates depend on hidden state the player cannot reason about

## First-Pass Questions

- What does the player know at start?
- What kinds of knowledge are persistent?
- Which discoveries are explicit, and which are inferred?
- Which gates are puzzle-solve gates versus knowledge-interpretation gates?
- What is the first “meaningful understanding shift” in the game?
