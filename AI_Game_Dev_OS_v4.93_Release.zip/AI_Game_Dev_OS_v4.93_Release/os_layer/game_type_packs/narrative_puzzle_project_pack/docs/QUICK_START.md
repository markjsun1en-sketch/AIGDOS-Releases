# Narrative Puzzle Pack Quick Start

1. Load `v4.89_Release Run Baseline layer`.
2. Select `standard_context_pack` by default.
3. Attach this pack for narrative+puzzle structure, validation focus, and owner decision templates.
4. Start from `docs/core/` and `docs/specs/`, then use `docs/validation/VALIDATION_FOCUS.md` before acceptance.
