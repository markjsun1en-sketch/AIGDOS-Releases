# NARRATIVE_PROGRESS_SPEC

Status: active
Module: narrative
Priority: high
Decision Status: PROPOSED_DEFAULT

## Purpose

This document defines how narrative is delivered, paced, and integrated into puzzle progression.

## Narrative Role

Narrative should:
- motivate play
- contextualize puzzles
- reward discovery
- deepen emotional connection
- change the meaning of prior and future spaces

Narrative should not:
- over-explain active problem solving
- interrupt every step of play
- replace puzzle clarity with lore density

## Delivery Modes

Possible delivery modes include:
- environmental narrative
- dialogue
- collectible notes / fragments
- triggered scenes
- interpretive recontextualization after a solve

## Core Rules

### Rule 1
Narrative beats must be paced around player agency, not dumped on top of it.

### Rule 2
Every major story beat should either:
- set up a puzzle,
- reframe a puzzle,
- or pay off a solved puzzle.

### Rule 3
Narrative exposition should respect the current knowledge-state model.

### Rule 4
A scene may clarify emotion or consequence, but should not routinely solve the puzzle for the player.

## Proposed Default Posture

- light-to-moderate direct exposition
- strong environmental/contextual storytelling
- story beats clustered around major unlocks or interpretation shifts
- no excessive cutscene dependency in the first playable
