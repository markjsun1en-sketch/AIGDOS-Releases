# PLAYER_GUIDANCE_AND_HINT_SPEC

Status: active
Module: guidance
Priority: high
Decision Status: PROPOSED_DEFAULT

## Purpose

This document defines how the project guides players without collapsing discovery.

## Guidance Philosophy

The project should support the player by improving:
- readability
- orientation
- feedback
- hypothesis formation

It should avoid:
- premature explicit answers
- constant interruption
- flattening all ambiguity into tutorial text

## Hint Ladder

### Level 0 — No direct hint
Use environmental readability and system feedback only.

### Level 1 — Directional nudge
Clarify where or what kind of thing to observe.

### Level 2 — Framing hint
Clarify how to think about the problem.

### Level 3 — Strong hint
Reveal the likely logical relation.

### Level 4 — Near-solution hint
Only when player frustration or accessibility need clearly justifies it.

## Core Rules

- hints should escalate, not jump straight to answers
- hints should preserve the feeling of player ownership where possible
- accessibility and anti-frustration are valid reasons for deeper hint layers
- the first playable should test guidance readability before implementing a large hint system
