# MODULE_MAP_AND_THREAD_PLAN

Status: active
Module: project_structure
Priority: high
Decision Status: PROPOSED_DEFAULT

## Canonical High-Level Modules

### 1. narrative_system
Owns:
- story beats
- dialogue/scenes
- environmental narrative placement
- narrative state transitions

### 2. puzzle_system
Owns:
- puzzle logic
- interaction rules
- failure/reset behavior
- solve state and feedback

### 3. knowledge_progression
Owns:
- clue interpretation model
- concept unlocks
- cross-puzzle understanding state
- reveal dependency tracking

### 4. gating_and_flow
Owns:
- chapter/room unlock logic
- progression conditions
- narrative/puzzle access routing

### 5. hint_and_guidance
Owns:
- guidance layers
- hint escalation logic
- readability support
- accessibility-facing explanation thresholds

### 6. ui_feedback
Owns:
- interaction clarity
- state readability
- clue visibility
- progress surfacing

### 7. save_load
Owns:
- persistent story state
- puzzle solve state
- knowledge-state persistence
- rollback/re-entry integrity

### 8. telemetry_validation
Owns:
- confusion detection signals
- stall metrics
- hint usage diagnostics
- pacing diagnostics

## Recommended Thread Split

### Thread A — Bootstrap / Registry / Governance
### Thread B — Narrative Progress
### Thread C — Puzzle Structure / Logic
### Thread D — Knowledge-State & Gating
### Thread E — Guidance / Hinting / Accessibility
### Thread F — UI Feedback / Readability
### Thread G — Validation / Playtest / Tuning

## Module Boundary Rules

- no module may silently redefine canonical progression state
- puzzle changes that alter gating must be reviewed with knowledge/gating ownership
- narrative changes that alter revealed truths must be reviewed against knowledge-state docs
- guidance changes must not quietly solve puzzles by default
