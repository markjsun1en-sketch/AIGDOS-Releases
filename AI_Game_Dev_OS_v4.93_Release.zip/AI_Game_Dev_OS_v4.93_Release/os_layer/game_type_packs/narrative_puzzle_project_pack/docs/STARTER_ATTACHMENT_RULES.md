# Narrative Puzzle Pack Attachment Rules


> **Baseline alias note (v4.90.2+)**: "v4.89_Release Run Baseline layer"
> mentioned below is preserved as the historical compatible alias of
> "v4.90_Release Run Baseline layer". Both labels resolve to the same
> byte-locked v4.89 reference + active v4.90 runtime; manifest field
> `baseline_versions` carries `["v4.89_Release", "v4.90_Release"]`.

- This pack may add narrative/puzzle design structure, validation focus, and owner-decision templates.
- This pack may not redefine runtime object contracts, state machines, registry authority, or sprint close rules.
- Use Reference only on demand for rationale or archive lookup.
