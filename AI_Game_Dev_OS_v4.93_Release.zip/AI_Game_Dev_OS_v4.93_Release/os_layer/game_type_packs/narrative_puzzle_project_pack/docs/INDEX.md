# narrative_puzzle_project_pack Index

This pack is the **narrative_puzzle_hybrid** adaptation layer.

## Entry docs
- `README.md`
- `docs/INDEX.md`
- `docs/QUICK_START.md`
- `docs/STARTER_ATTACHMENT_RULES.md`

## Additional directories
- `templates/`
- `docs/core/`
- `docs/specs/`
- `docs/validation/`
