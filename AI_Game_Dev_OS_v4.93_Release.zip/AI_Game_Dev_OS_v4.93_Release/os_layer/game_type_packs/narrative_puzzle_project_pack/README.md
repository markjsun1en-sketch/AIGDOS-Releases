# narrative_puzzle_project_pack


> **Baseline alias note (v4.90.2+)**:
> "v4.89_Release Run Baseline layer" referenced below is preserved as the
> historical compatible alias of "v4.90_Release Run Baseline layer". Both
> labels resolve to the byte-locked v4.89 reference + the active v4.90
> runtime. Manifests carry `baseline_versions: ["v4.89_Release",
> "v4.90_Release"]`. New v4.91+ packs should write `v4.90_Release`
> directly.

Status: active
Pack Type: Project Starter Pack
Pack Version: v0.1
Compatible OS Baseline: v4.89_Release (Run Baseline layer)
Recommended Context Profile: STANDARD

## Purpose

This pack defines the project-level starter layer for games built around a hybrid of:

- narrative delivery
- puzzle-solving progression
- gating through story, knowledge, and interaction state

This pack is intended for projects where the core experience depends on the coordination of:

- story beats and emotional pacing
- puzzle structure and logic clarity
- knowledge unlocks and state tracking
- player guidance without over-explaining

## This Pack Defines

- narrative-puzzle loop hierarchy
- story / puzzle / knowledge-state boundaries
- puzzle design role and constraints
- narrative progression role and constraints
- module ownership and recommended thread split
- validation focus for clarity, pacing, and gating integrity

## This Pack Does Not Define

This pack does not replace the OS baseline.

It does not redefine:

- canonical runtime governance
- general handoff / issue / archive policy
- core OS validation model
- shared context pack semantics

These remain owned by `v4.89_Release Run Baseline layer` and the selected Context Pack.

## Default Assembly

Recommended runtime assembly for this project:

- Runtime Baseline: `v4.89_Release Run Baseline layer`
- Context Profile: `STANDARD`
- Project Starter: `narrative_puzzle_project_pack`
- Reference Layer: `v4.89_Release Reference layer` (reference-only, on demand)

## Owner Decision Model

Project-defining directions in this pack are treated as proposed defaults unless explicitly confirmed by the project owner.

Use `docs/core/OWNER_DECISION_STATE_MODEL.md` and the templates under `templates/` to promote decisions into current project truth.

## Placement in v4.89_Release

This pack is a parallel domain starter alongside other project starters.
It should be used when the project's main challenge is aligning narrative pacing, puzzle readability, and knowledge-state progression.
