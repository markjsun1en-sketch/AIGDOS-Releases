# PROJECT_BOOTSTRAP_CHECKLIST

- [ ] `v4.89_Release Run Baseline layer` attached
- [ ] `STANDARD` context selected
- [ ] `narrative_puzzle_project_pack` attached
- [ ] `v4.89_Release Reference layer` set to reference-only
- [ ] loop hierarchy reviewed
- [ ] knowledge-state map reviewed
- [ ] module ownership drafted
- [ ] thread split drafted
- [ ] first validation focus agreed
- [ ] first playable scope constrained
