# OWNER_REVIEW_PROMPT_TEMPLATE

Use this prompt when a core project decision needs owner confirmation.

## Prompt

Please review the following proposed default for the current Narrative + Puzzle project.

- Topic:
- Current Proposed Default:
- Why this is proposed:
- Risks if accepted:
- Risks if rejected:
- What needs to change in project docs if approved:
- Requested owner state:
  - APPROVED_CURRENT
  - LOCKED_FOR_MILESTONE
  - REJECTED / REVISE
