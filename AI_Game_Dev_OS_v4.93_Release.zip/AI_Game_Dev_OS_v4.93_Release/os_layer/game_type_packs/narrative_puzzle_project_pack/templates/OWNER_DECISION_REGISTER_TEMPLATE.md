# OWNER_DECISION_REGISTER_TEMPLATE

## Decision Entry

- ID:
- Topic:
- Current State: HYPOTHESIS / PROPOSED_DEFAULT / APPROVED_CURRENT / LOCKED_FOR_MILESTONE / SUPERSEDED
- Related Docs:
- Current Decision:
- Why:
- What This Enables:
- What This Restrains:
- Revisit Trigger:
- Owner Note:
