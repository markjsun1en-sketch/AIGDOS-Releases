# EXAMPLE_OWNER_DECISION_REGISTER

## Decision Entry

- ID: NP-001
- Topic: Primary active loop ownership
- Current State: APPROVED_CURRENT
- Related Docs:
  - `docs/core/GAME_LOOP_HIERARCHY.md`
  - `docs/specs/PUZZLE_STRUCTURE_SPEC.md`
- Current Decision:
  - Puzzle solving is the primary active loop.
  - Narrative context supports play but does not dominate minute-to-minute interaction.
- Why:
  - The game should feel playable through discovery, not passive story consumption.
- What This Enables:
  - clearer puzzle-first first playable
  - easier validation of clue readability
- What This Restrains:
  - heavy cutscene-first pacing
  - over-explanatory guidance
- Revisit Trigger:
  - if playtests show puzzle motivation is too weak without stronger direct story delivery
- Owner Note:
  - Keep first playable compact and prove the solve/reveal loop before scaling scope.
