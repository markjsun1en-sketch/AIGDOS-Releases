# QUICK_START

## Read Order

All new threads or agents attached to this project should read in this order:

1. `README.md`
2. `docs/core/GAME_LOOP_HIERARCHY.md`
3. `docs/core/CORE_ECONOMY_AND_RESOURCE_MAP.md`
4. `docs/core/MODULE_MAP_AND_THREAD_PLAN.md`

Read the following only when relevant:

- `docs/specs/SPIN_SYSTEM_SPEC.md`
- `docs/specs/RUN_AND_ROGUE_STRUCTURE_SPEC.md`
- `docs/specs/IDLE_META_PROGRESSION_SPEC.md`
- `docs/validation/VALIDATION_FOCUS.md`
- `docs/bootstrap/FIRST_PLAYABLE_DEFINITION.md`

## Default Runtime Setup

- Baseline: `v4.89_Release Run Baseline layer`
- Context Profile: `STANDARD`
- Project Pack: `spin_rogue_idle_project_pack`
- Full Reference: attach only when needed

## First Alignment Goal

Before implementation starts, confirm:

- what the primary player hook is
- what the main decision layer is
- what the long-term progression layer is
- how resources move between the three layers
- which loops are allowed to amplify each other
- which loops are explicitly prevented from replacing each other

## Immediate First Deliverables

The first project setup pass should produce:

- a stable loop hierarchy
- a first-pass resource map
- a module ownership map
- an initial thread split
- a first validation focus list
- a first owner decision register

## Early Anti-Failure Rule

Do not start detailed implementation before loop hierarchy and resource boundaries are explicitly aligned.

The most dangerous early failure for this project type is local implementation without systemic loop alignment.
