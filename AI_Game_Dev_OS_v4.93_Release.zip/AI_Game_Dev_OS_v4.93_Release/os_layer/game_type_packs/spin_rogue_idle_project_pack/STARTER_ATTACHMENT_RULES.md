# STARTER_ATTACHMENT_RULES


> **Baseline alias note (v4.90.2+)**: "v4.89_Release Run Baseline layer"
> mentioned below is preserved as the historical compatible alias of
> "v4.90_Release Run Baseline layer". Both labels resolve to the same
> byte-locked v4.89 reference + active v4.90 runtime; manifest field
> `baseline_versions` carries `["v4.89_Release", "v4.90_Release"]`.

## Required

This project pack must be attached with:

- `v4.89_Release Run Baseline layer`

## Recommended

Default context profile:

- `STANDARD`

## Optional Escalation

Escalate only when required:

- `EXPANDED`

## Reference Layer

Use:

- `v4.89_Release Reference layer`

Reference layer usage mode:

- on demand only
- not part of daily default preload
- do not attach as default working context unless a thread explicitly needs deep reference lookup

## Replaced Starter

For the current project, this pack replaces:

- `card_roguelike_project_starter`

## Interaction with Generic Starter

Generic starter conventions may still be reused for:

- common project bootstrapping
- cross-project checklist patterns
- generic runtime attachment logic

But generic starter docs do not override this pack’s project-specific loop, economy, or module definitions.

## Profile Routing Guidance

Recommended profile usage:

- `LEAN` for narrow implementation or cleanup work
- `STANDARD` for default project work
- `EXPANDED` for systemic design, economy, and multi-loop coordination
- `FULL_REFERENCE` only for deep reference lookup, not default runtime
