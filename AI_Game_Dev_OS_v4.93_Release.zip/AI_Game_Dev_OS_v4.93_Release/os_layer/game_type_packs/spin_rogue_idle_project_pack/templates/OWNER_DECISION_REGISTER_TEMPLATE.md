# OWNER_DECISION_REGISTER_TEMPLATE

Project:
Date:
Owner:
Current Milestone:

| Decision Area | Current State | Current Value | Why | Open Risks | Next Review |
|---|---|---|---|---|---|
| Loop Hierarchy | PROPOSED_DEFAULT | Spin hook / Run active / Idle retention | Starter default | Needs playtest proof | First Playable |
| Active vs Passive Posture | PROPOSED_DEFAULT | Active > Passive for meaningful progression | Preserve engagement | Idle tuning risk | First Playable |
| First Playable Scope | PROPOSED_DEFAULT | Three-loop end-to-end proof | Scope control | Over-expansion risk | First Playable |
| Resource Boundary Model | PROPOSED_DEFAULT | 4-layer model | Prevent pollution | Inflation risk | Prototype 1 |

## State Values
Use one of:
- HYPOTHESIS
- PROPOSED_DEFAULT
- APPROVED_CURRENT
- LOCKED_FOR_MILESTONE
- SUPERSEDED
