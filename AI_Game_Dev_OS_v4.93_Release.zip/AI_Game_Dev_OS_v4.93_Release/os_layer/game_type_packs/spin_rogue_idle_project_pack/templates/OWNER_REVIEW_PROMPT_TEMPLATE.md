# OWNER_REVIEW_PROMPT_TEMPLATE

Use this template when requesting owner confirmation on project direction.

## Review Request

Please review the following proposed defaults:

1. Loop hierarchy
2. Economy boundary model
3. First playable scope
4. Active vs passive progression posture

## For each item, mark one:
- approve as current truth
- revise and approve
- keep as hypothesis
- reject and replace

## Required Output

For each reviewed item, return:
- decision state
- approved wording
- milestone lock status if any
- next review point
