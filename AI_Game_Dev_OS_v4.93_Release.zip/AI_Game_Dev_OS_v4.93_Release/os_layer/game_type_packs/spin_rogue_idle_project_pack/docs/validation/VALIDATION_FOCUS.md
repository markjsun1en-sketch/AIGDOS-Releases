# VALIDATION_FOCUS

Status: active
Module: validation
Priority: critical
Decision State: PROPOSED_DEFAULT
Final Authority: Project Owner / Validation Lead

## Purpose

This file defines the primary validation targets for the project’s first systemic health pass.

The main risk is not feature absence, but loop imbalance.

## Validation Focus Areas

### 1. Spin Dominance Check
Question:
Does spin produce so much value that run and idle become secondary?

Look for:
- players delaying runs too often
- persistent progression driven mainly by spin
- spin loop feeling self-sufficient

Fallback:
- reduce direct permanent outputs
- shift more value into run conversion
- increase run-entry desirability

### 2. Idle Dominance Check
Question:
Does offline/meta progression reduce the value of active play too much?

Look for:
- wait strategy outperforming active play
- claim-and-leave behavior
- low active session urgency

Fallback:
- lower passive top-tier output
- increase active-only rewards
- tighten idle caps or efficiency

### 3. Run Integrity Check
Question:
Does the run layer provide real decision value, or is it only a reward funnel?

Look for:
- choices with no visible impact
- players treating run as mandatory grind
- low perceived run identity

Fallback:
- increase decision impact
- simplify noise choices
- improve run-specific reward meaning

### 4. Resource Explosion Check
Question:
Do loop interactions create runaway positive feedback?

Look for:
- one currency inflating fastest
- self-fueling loops
- unclear sinks

Fallback:
- add sink friction
- reduce conversion efficiency
- cap loopback outputs

### 5. Session Rhythm Check
Question:
Does the player experience a coherent short-session to long-session rhythm?

Look for:
- abrupt dead zones
- too much pre-action waiting
- poor post-claim routing

Fallback:
- strengthen spin-to-run routing
- speed up entry to active play
- clarify next best action

### 6. Return Motivation Check
Question:
Is there a clear reason to come back after leaving the game?

Look for:
- no anticipation
- only passive claim value
- weak next-session setup

Fallback:
- improve idle readability
- add better readiness rewards
- define clearer next-session targets

## First-Pass Validation Standard

A valid early prototype should show:

- spin is exciting but not sufficient alone
- run is meaningful but not too heavy
- idle is rewarding but not dominant
- resources remain understandable
- each loop visibly supports a different time horizon

## Owner Confirmation Fields

- Approved primary risk:
- Approved first metrics to observe:
- Approved fallback priority:
- Approval date:
