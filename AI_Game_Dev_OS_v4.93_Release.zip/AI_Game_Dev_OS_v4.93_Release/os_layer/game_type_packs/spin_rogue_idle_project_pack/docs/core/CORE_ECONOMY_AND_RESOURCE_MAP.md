# CORE_ECONOMY_AND_RESOURCE_MAP

Status: active
Module: economy
Priority: critical
Decision State: PROPOSED_DEFAULT
Final Authority: Project Owner / Creative Direction

## Purpose

This document defines the proposed first-pass canonical economy model for the project.

The goal is to prevent:
- resource pollution
- loop dominance
- runaway positive feedback
- redundant reward design
- progression flattening

## Economy Design Goals

The economy must support three different value horizons:

- immediate excitement
- session-level decisions
- long-term progression

Each horizon should have:
- a distinct reward identity
- at least one distinct sink or routing purpose
- clear conversion rules
- limited dominance over other horizons

## Proposed Canonical Resource Layers

### Layer A — Spin Resources
Examples:
- Spin Coin
- Spin Token
- Bonus Spin Charge
- Streak Meter Charge

### Layer B — Run Resources
Examples:
- Run Ticket
- Run Energy
- Encounter Reroll
- Temporary Blessing

### Layer C — Meta Resources
Examples:
- Idle Gold
- Upgrade Shard
- Prestige Essence

### Layer D — Premium / Event / Sink Resources
Examples:
- Event Ticket
- Rare Fragment
- Limited-Time Currency

## Proposed Conversion Rules

### Allowed Conversion Paths
- Spin -> Run access / setup
- Run -> Meta progress
- Idle -> limited Spin support
- Idle -> bounded Run readiness support

### Restricted Conversion Paths
- Spin -> Meta
- Run -> Spin
- Meta -> Run Power

### Disallowed / High-Risk Paths
- Idle -> dominant permanent power acceleration without active play
- Spin -> top-tier long-term progression at high frequency
- Run -> unlimited idle amplification
- Shared universal currency across all layers

## Resource Identity Rules

1. Every resource must have a primary owner loop.
2. Every persistent resource must have at least one meaningful sink.
3. Every high-frequency reward source must be rate-limited by sink, cost, pacing, rarity, or routing friction.
4. No single resource should efficiently solve all three horizons.
5. Temporary and permanent value must remain visibly different to the player.

## Suggested Early Resource Set

### Spin Layer
- Spin Coin
- Bonus Spin Token
- Lucky Streak Charge

### Run Layer
- Run Ticket
- Run Energy
- Temporary Blessing
- Encounter Reroll

### Meta Layer
- Idle Gold
- Upgrade Shard
- Prestige Essence

### Event / Sink Layer
- Event Ticket
- Rare Fragment

## Locked Early Principles Once Approved

1. Run is the main source of active meaningful progression conversion.
2. Spin is a setup and excitement layer, not the main long-term progression source.
3. Idle supports continuity and return, but does not replace active advancement.
4. Resource count stays intentionally small in the first phase.
5. No universal all-purpose currency will be used across all loops.

## Owner Confirmation Fields

- Approved resource layers:
- Approved high-risk conversions to ban:
- Approved active/passive progression posture:
- First resource to monitor for inflation:
- Approval date:
