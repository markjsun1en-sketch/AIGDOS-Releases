# MODULE_MAP_AND_THREAD_PLAN

Status: active
Module: project_core
Priority: high
Decision State: PROPOSED_DEFAULT
Final Authority: Project Owner / Producer

## Purpose

This document defines the first-pass module ownership model and recommended thread split for the project.

The main goal is to keep spin, run, idle, economy, and feedback work from collapsing into a single mixed workstream.

## Canonical High-Level Modules

### 1. spin_system
Owns:
- spin cadence
- reward table logic
- streaks
- spin presentation hooks
- spin output routing

### 2. run_system
Owns:
- run entry
- encounter structure
- random choices
- temporary upgrades
- run flow and resolution

### 3. idle_meta_system
Owns:
- offline accumulation
- long-term upgrade routing
- return bonuses
- persistent growth pacing

### 4. economy_balance
Owns:
- reward rates
- sink design
- conversion ratios
- progression pacing
- anti-dominance tuning between loops

### 5. reward_pipeline
Owns:
- reward category definitions
- cross-loop reward routing
- output normalization
- reward readability standards

### 6. ui_feedback
Owns:
- session readability
- spin result feedback
- run state clarity
- idle return feedback
- progression display priorities

### 7. content_events
Owns:
- event definitions
- encounter pools
- rare reward content
- run variation content

### 8. save_load
Owns:
- persistent state model
- session state boundaries
- offline accumulation integrity
- account progression persistence

### 9. telemetry_validation
Owns:
- metric hooks
- validation criteria
- loop dominance detection
- reward pacing diagnostics

## Recommended Thread Split

- Thread A — Bootstrap / Registry / Governance
- Thread B — Spin System
- Thread C — Run Structure / Rogue Logic
- Thread D — Idle Meta Progression
- Thread E — Economy & Balance
- Thread F — UI / Feedback
- Thread G — Validation / Playtest / Tuning

## Boundary Rules

1. No single module may redefine the overall loop hierarchy.
2. Cross-loop reward changes must be reviewed with economy ownership.
3. Idle/meta changes that affect active play must be treated as systemic changes.
4. Run changes that materially alter reward conversion must not bypass economy review.
5. UI/feedback may improve clarity, but must not silently redefine systemic value.

## Owner Confirmation Fields

- Approved module ownership exceptions:
- Approved thread split:
- Current module risk hotspot:
- Approval date:
