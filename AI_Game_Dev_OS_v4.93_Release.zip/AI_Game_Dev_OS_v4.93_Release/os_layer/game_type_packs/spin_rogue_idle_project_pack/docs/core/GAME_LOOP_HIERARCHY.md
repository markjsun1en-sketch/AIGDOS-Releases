# GAME_LOOP_HIERARCHY

Status: active
Module: project_core
Priority: critical
Decision State: PROPOSED_DEFAULT
Final Authority: Project Owner / Creative Direction

## Purpose

This document defines the proposed canonical loop hierarchy for the project.

The project is a hybrid game built from three interdependent layers:

- Spin
- Rogue Run
- Idle Meta

These layers must not be treated as equal systems competing for attention.
They should be arranged into a clear functional hierarchy so that the game maintains:

- immediate excitement
- meaningful short-session decisions
- long-term return value

This document becomes canonical project truth only after owner approval.

## Proposed Canonical Loop Hierarchy

### Primary Session Hook: Spin
Spin is the first layer the player emotionally understands.

Spin owns:
- anticipation
- fast reward bursts
- entry motivation
- short-session return behavior
- “just one more spin” pressure

Spin is the game’s front-door interaction layer.
Spin is not the project’s deepest decision layer.

### Primary Active Decision Layer: Rogue Run
Rogue Run is the main source of active gameplay identity.

Run owns:
- short-to-mid session decisions
- build shaping
- session variation
- risk/reward choice
- temporary power expression

Run is where active play earns its legitimacy.
Run is not a cosmetic wrapper around reward delivery.

### Primary Long-Term Retention Layer: Idle Meta
Idle Meta is the continuity layer.

Idle owns:
- offline accumulation
- recovery value between active sessions
- long-term account growth
- daily return motivation
- soft failure buffering

Idle is the project’s retention floor.
Idle is not allowed to become the dominant ceiling of progression.

## Time Horizon Ownership

### 0–10 seconds
Owned mainly by Spin.

### 10–60 seconds
Owned jointly by Spin and Run entry.

### 1–5 minutes
Owned mainly by Rogue Run.

### 1 day and beyond
Owned mainly by Idle Meta.

## Proposed Value Statement

The intended player-facing loop interpretation is:

- “Spin gives me excitement and opens opportunities.”
- “Run gives me agency and session identity.”
- “Idle gives me continuity and return value.”

## Proposed Core Rules

1. Spin is the hook, not the whole economy.
2. Run is the main active value layer.
3. Idle is supportive, not dominant.
4. No loop may fully invalidate another loop.
5. Meta should accelerate engagement, not eliminate it.

## Required Relationship Model

### Spin -> Run
Spin should:
- grant run access
- accelerate run readiness
- alter next-run tempo
- occasionally shape run context

Spin should not:
- fully determine run success
- replace build decisions
- erase run risk

### Run -> Meta
Run should:
- convert session success into persistent value
- unlock future possibilities
- justify active play
- feed long-term growth

### Idle -> Spin / Run
Idle should:
- support re-entry
- provide recovery value
- improve readiness
- create daily return motivation

Idle should not:
- trivialize run tension
- infinitely inflate spin value
- become the only rational progression source

## Session Model

The expected high-level session arc is:

1. return to game
2. collect idle value
3. use spin for excitement / setup
4. convert momentum into a run
5. resolve run and gain meaningful output
6. route gains into long-term account growth
7. leave with future return motivation

## Failure Modes

### Spin Dominance
### Idle Dominance
### Run Isolation
### Loop Flattening

See `docs/validation/VALIDATION_FOCUS.md` for validation interpretation.

## Owner Confirmation Fields

- Approved hierarchy:
- Approved time-horizon emphasis:
- Current weakest loop:
- Current overpowered loop:
- Approval date:
- Milestone lock:
