# IDLE_META_PROGRESSION_SPEC

Status: active
Module: idle_meta_system
Priority: critical
Decision State: PROPOSED_DEFAULT
Final Authority: Project Owner / Creative Direction

## Purpose

This document defines the long-term retention, offline accumulation, and persistent account progression layer for the project.

The Idle / Meta layer exists to:
- preserve continuity between active sessions
- provide recovery value while absent
- create daily return motivation
- support long-term account growth
- reduce hard stagnation and frustration

## Canonical Role of Idle / Meta

Idle / Meta owns:
- continuity
- account persistence
- return value
- soft recovery
- long-term growth pacing
- daily motivation structure

It must not replace active play as the dominant progression path.

## Idle Layer Functions

1. Offline Accumulation
2. Return Readiness
3. Growth Smoothing
4. Long-Term Account Growth

## Meta Growth Ownership

Meta progression may improve:
- base spin readiness
- idle storage cap
- offline efficiency
- run entry readiness
- passive account stats
- unlock pace
- recovery efficiency

Meta progression should not directly eliminate:
- the need for active run choices
- the value of spin tension
- the relevance of short-session engagement

## Constraints

1. No passive dominance.
2. No infinite offline escalation.
3. No challenge deletion.
4. No pure claim-loop identity.
5. No universal value supremacy.

## Recommended First-Pass Structure

- bounded accumulation
- useful but incomplete recovery
- enough return reward to feel good
- not enough value to make absence optimal

## Offline Boundary Rules

1. Idle accumulation must stop or slow after a reasonable limit.
2. The best resources should not be passively generated at top efficiency.
3. Offline gains should improve readiness, not guarantee domination.
4. Return value must be visible and satisfying, but not overwhelmingly large.
5. Meta pacing must preserve reasons to keep playing after collection.

## Early Prototype Targets

1. Returning after absence feels rewarding.
2. Returning after absence also encourages active play.
3. Offline value is useful but not sufficient by itself.
4. Meta upgrades feel meaningful and understandable.
5. Passive growth does not erase active session value.
6. Account growth remains visible across days.

## Owner Confirmation Fields

- Approved offline cap posture:
- Approved active-to-passive progression posture:
- Approved active-only rewards:
- First anti-snowball control:
- Approval date:
