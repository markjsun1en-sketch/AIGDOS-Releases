# RUN_AND_ROGUE_STRUCTURE_SPEC

Status: active
Module: run_system
Priority: critical
Decision State: PROPOSED_DEFAULT
Final Authority: Project Owner / Creative Direction

## Purpose

This document defines the project’s active rogue-style run layer.

The run layer is the project’s primary active decision layer.
Its role is to transform short-session momentum into meaningful player choice, session identity, and persistent progression conversion.

## Canonical Role of the Run Layer

The run layer owns:
- active session value
- temporary build shaping
- encounter variation
- short-session tension
- risk/reward choice
- conversion of active effort into meaningful account progress

The run layer must feel like:
- “I am making choices that matter.”
- “This session is unfolding differently.”
- “I earned something meaningful by playing.”

## Intended Rogue Feel

This project targets a light rogue feel, not a heavy-core roguelike structure.

The intended rogue feeling should come from:
- frequent but readable decisions
- temporary upgrades or traits
- visible short-run build identity
- encounter/event variation
- uncertainty with bounded consequence
- runs that are easy to restart

## Run Session Goals

1. Fast Entry
2. Visible Arc
3. Choice Density
4. Repeatability
5. Persistent Meaning

## Recommended First-Pass Run Shape

- short-to-medium run length
- compact node count
- fast restarts

Recommended first-pass node types:
- combat / challenge node
- reward choice node
- event node
- elite / risk node
- rest / recovery node
- end-of-run payoff node

## Constraints

1. No decorative run layer.
2. No excessive heaviness.
3. No weak reward conversion.
4. No guaranteed solvability from spin.
5. No punishment spiral.

## Failure Handling Rules

Failure should:
- create tension
- preserve re-entry motivation
- preserve some visible retained value

Avoid all-or-nothing loss models in the early design.

## Early Prototype Targets

1. Players can enter a run quickly.
2. Players make several meaningful choices per run.
3. Runs feel different enough to justify replay.
4. Run success or failure has visible consequences.
5. Run outcomes matter to long-term progression.
6. Run does not feel so heavy that it competes with the project’s casual cadence.

## Owner Confirmation Fields

- Approved run length target:
- Approved node types:
- Approved fail posture:
- First build identity source:
- Approval date:
