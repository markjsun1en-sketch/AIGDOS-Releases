# SPIN_SYSTEM_SPEC

Status: active
Module: spin_system
Priority: high
Decision State: PROPOSED_DEFAULT
Final Authority: Project Owner / Creative Direction

## Purpose

This document defines the proposed first-pass design role, constraints, and implementation-facing expectations of the Spin system.

Spin is the project’s primary short-session hook.
Its purpose is to generate anticipation, excitement, repeated entry behavior, and opportunity routing into the wider game loop.

## Core Design Role

Spin must deliver:
- fast readable excitement
- repeatable short-session interaction
- reward suspense
- burst pacing
- route opening into the run layer
- visible support for return behavior

## Canonical Spin Functions

1. Session Entry Hook
2. Momentum Generator
3. Run Setup Layer
4. Surprise Delivery System
5. Return Support Layer

## Output Categories

### Category A — Base Rewards
### Category B — Run Access Rewards
### Category C — Run Modifier Rewards
### Category D — Idle Support Rewards
### Category E — Rare / Jackpot Rewards

## Output Distribution Principles

1. Most spins should give something readable.
2. Not every spin should grant meaningful progression acceleration.
3. Run-supporting rewards should appear often enough to sustain session transition.
4. Jackpot moments must feel rare and emotionally distinct.
5. Idle-support outputs should support return pacing, not dominate account growth.

## Constraints

1. No full progression supremacy.
2. No guaranteed run resolution.
3. No excess permanent reward density.
4. No infinite self-fueling.
5. No readability collapse.

## Spin-to-Run Integration Rules

Allowed:
- grant run entry tickets
- grant light starting buffs
- grant rerolls
- trigger special run conditions

Not allowed:
- guarantee boss clear
- guarantee best build
- fully replace choice quality
- invalidate run tension

## Spin-to-Idle Integration Rules

Allowed:
- temporary idle boosters
- short-duration return bonuses
- cap extension tools

Not allowed:
- dominant permanent passive value
- unlimited offline growth multipliers
- core meta progression bypass

## Early Prototype Targets

1. Players understand it in under one session.
2. Players can see a route from spin to active play.
3. Spin feels rewarding without making other loops irrelevant.
4. Reward categories are readable enough for balance iteration.
5. Spin repetition remains appealing over short repeated sessions.

## Owner Confirmation Fields

- Approved spin role:
- Approved reward categories:
- Approved banned outcomes:
- First anti-infinite-loop control:
- Approval date:
