# OWNER_DECISION_STATE_MODEL

## Purpose

This document defines how project-level owner decisions should be recorded over time.

The goal is to preserve owner authority while giving agents and threads a stable way to interpret
which project decisions are only hypotheses, which are approved, and which are temporarily locked.

## Canonical States

### HYPOTHESIS
A directional assumption used for exploration.
Not canonical.
May guide prototype work, but should be treated as provisional.

### PROPOSED_DEFAULT
A recommended default prepared for owner review.
Not canonical until approved.

### APPROVED_CURRENT
Approved by project owner / creative direction for current project truth.
Canonical until revised.

### LOCKED_FOR_MILESTONE
Approved and intentionally frozen for a named milestone such as:
- First Playable
- MVP
- Vertical Slice

Must not be changed without explicit milestone-level review.

### SUPERSEDED
A previously valid decision that has been replaced.
Kept for project history and auditability.

## Authority Rule

Only the project owner or delegated project decision authority may move a decision into:
- APPROVED_CURRENT
- LOCKED_FOR_MILESTONE

## Agent Rule

Agents may:
- propose
- compare options
- identify conflicts
- recommend changes

Agents may not silently convert a hypothesis or proposed default into canonical project truth.

## Documentation Rule

When a document contains a suggested direction that is not yet approved, it should use wording like:
- Proposed default
- Pending owner confirmation
- Not canonical until approved

## Practical Interpretation

Early project development should expect many decisions to move through:

HYPOTHESIS -> PROPOSED_DEFAULT -> APPROVED_CURRENT -> LOCKED_FOR_MILESTONE

This is expected behavior, not inconsistency.
