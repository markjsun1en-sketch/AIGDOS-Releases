# PROJECT_BOOTSTRAP_STEPS

## Purpose

This document defines the recommended order for bootstrapping this project under AI_Game_Dev_OS v4.89_Release.

## Step 1 — Attach Runtime Baseline
Attach:
- `v4.89_Release Run Baseline layer`

## Step 2 — Select Context
Default:
- `STANDARD`

## Step 3 — Attach Project Pack
Attach:
- `spin_rogue_idle_project_pack`

## Step 4 — Set Reference Layer Mode
Use:
- `v4.89_Release Reference layer` as reference-only, on demand

## Step 5 — Align Core Truth
Review and align:
- `docs/core/GAME_LOOP_HIERARCHY.md`
- `docs/core/CORE_ECONOMY_AND_RESOURCE_MAP.md`
- `docs/core/MODULE_MAP_AND_THREAD_PLAN.md`

## Step 6 — Open Owner Decision Register
Create or update:
- `templates/OWNER_DECISION_REGISTER_TEMPLATE.md`
- project-specific decision register in your project docs

## Step 7 — Confirm First Playable Scope
Review:
- `docs/bootstrap/FIRST_PLAYABLE_DEFINITION.md`

## Step 8 — Start Threads
Recommended initial threads:
- Bootstrap / Registry / Governance
- Spin System
- Run Structure / Rogue Logic
- Idle Meta Progression
- Economy & Balance
- UI / Feedback
- Validation / Playtest / Tuning

## Step 9 — Record First Approved Decisions
At minimum approve current direction for:
- loop hierarchy
- active vs passive posture
- first playable scope
- resource boundary model

## Step 10 — Begin Implementation
Only after steps 1–9 are complete should detailed implementation proceed.
