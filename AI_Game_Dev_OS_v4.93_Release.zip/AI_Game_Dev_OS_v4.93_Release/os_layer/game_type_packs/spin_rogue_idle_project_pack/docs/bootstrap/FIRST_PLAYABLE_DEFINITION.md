# FIRST_PLAYABLE_DEFINITION

Status: active
Module: bootstrap
Priority: critical
Decision State: PROPOSED_DEFAULT
Final Authority: Project Owner / Creative Direction

## Purpose

This document defines the proposed default scope for the project’s First Playable.

This is not a final immutable scope document.
It is a scope control surface that should be approved, revised, and milestone-locked by the project owner.

## First Playable Goal

The First Playable should prove that the three-loop structure works at a basic experiential level.

It should answer:

- Does spin feel like a compelling session hook?
- Does run feel like the main active decision layer?
- Does idle create return value without replacing play?
- Do the three loops connect in a readable and motivating way?

## Proposed Default Inclusions

### Include
- one functional spin loop
- one short functional run loop
- one bounded idle accumulation loop
- one small meta upgrade surface
- one readable reward routing chain between loops
- one basic save/load persistence path
- one minimal validation pass for loop dominance risks

### Exclude for first playable
- deep content variety
- large event pool
- advanced monetization systems
- live ops structure
- complex prestige layering
- large upgrade tree
- high visual polish dependency
- broad enemy / encounter catalog

## Minimum Playable Flow

Proposed default first playable flow:

1. return / enter game
2. receive or use spin access
3. perform spins
4. obtain run access or run-shaping rewards
5. enter a short run
6. make several meaningful decisions
7. receive run outcome
8. convert outcome into persistent growth
9. leave and later return to bounded idle value

If this full loop cannot be completed end-to-end, first playable is not yet achieved.

## Proposed Success Criteria

A first playable should demonstrate:

- spin is understandable and emotionally functional
- run is clearly more decision-rich than spin
- idle gives useful continuity without dominating value
- reward categories are readable
- players can understand what to do next after each layer

## Proposed Anti-Scope Rules

### Rule 1
Do not expand content breadth before loop coherence is proven.

### Rule 2
Do not add additional currencies unless an existing boundary problem forces it.

### Rule 3
Do not solve weak run value by overpaying spin or idle.

### Rule 4
Do not use polish to mask loop confusion.

## Owner Confirmation Fields

- Current milestone target:
- Approved first playable definition:
- Locked exclusions:
- Open scope risks:
- Approval date:
