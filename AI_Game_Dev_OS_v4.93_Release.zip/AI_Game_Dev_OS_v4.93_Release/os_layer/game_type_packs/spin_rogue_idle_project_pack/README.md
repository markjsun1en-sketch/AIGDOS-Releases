# spin_rogue_idle_project_pack


> **Baseline alias note (v4.90.2+)**:
> "v4.89_Release Run Baseline layer" referenced below is preserved as the
> historical compatible alias of "v4.90_Release Run Baseline layer". Both
> labels resolve to the byte-locked v4.89 reference + the active v4.90
> runtime. Manifests carry `baseline_versions: ["v4.89_Release",
> "v4.90_Release"]`. New v4.91+ packs should write `v4.90_Release`
> directly.

Status: active
Pack Type: Project Starter Pack
Pack Version: v0.2
Compatible OS Baseline: v4.89_Release (Run Baseline layer)
Recommended Context Profile: STANDARD

## Purpose

This pack defines the project-level starter layer for games built around a hybrid loop of:

- spin-driven short-session reward bursts
- light rogue-style runs and build variation
- idle/meta progression and offline accumulation

For the current project, this pack replaces `card_roguelike_project_starter` as the canonical project starter.

## What This Pack Adds

- loop hierarchy and ownership
- economy and resource boundaries
- spin / run / idle role definitions
- first playable scope framing
- owner decision state model
- module ownership and recommended thread split
- validation focus for loop balance and systemic coherence
- project bootstrap checklist and templates

## What This Pack Does Not Replace

This pack does not replace the OS baseline. It does not redefine:

- canonical runtime governance
- general handoff / issue / archive policy
- core OS validation model
- shared context pack semantics

Those remain owned by `v4.89_Release Run Baseline layer` and the selected Context Pack.

## Default Assembly

Recommended runtime assembly for this project:

- Runtime Baseline: `v4.89_Release Run Baseline layer`
- Context Profile: `STANDARD`
- Project Starter: `spin_rogue_idle_project_pack`
- Reference Layer: `v4.89_Release Reference layer` (reference-only, on demand)

## Owner Decision Authority

This pack contains proposed defaults and decision templates.

Final project-facing authority remains with:
- Project Owner
- Creative Direction
- Producer authority defined by the current project governance

No proposed default becomes canonical project truth until it is explicitly approved and recorded.

## Starter Layout

- `docs/core/` = core project truth surfaces
- `docs/specs/` = loop-specific specs
- `docs/validation/` = validation focus and health checks
- `docs/bootstrap/` = first playable, bootstrap, and decision process
- `manifests/` = pack manifest and metadata
- `templates/` = owner decision templates
- `checklists/` = bootstrap checklist
- `examples/` = example owner decision register
