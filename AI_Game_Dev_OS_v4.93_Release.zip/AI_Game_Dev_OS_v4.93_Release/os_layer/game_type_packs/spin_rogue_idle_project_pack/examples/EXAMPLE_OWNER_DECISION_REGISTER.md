# EXAMPLE_OWNER_DECISION_REGISTER

Project: Example Spin Rogue Idle Prototype
Date: YYYY-MM-DD
Owner: <name>
Current Milestone: First Playable

| Decision Area | Current State | Current Value | Why | Open Risks | Next Review |
|---|---|---|---|---|---|
| Loop Hierarchy | APPROVED_CURRENT | Spin hook / Run active / Idle retention | Matches project goal | Spin may overpower run | First Playable review |
| Active vs Passive Posture | APPROVED_CURRENT | Active play is strongest meaningful progression route | Preserve game identity | Idle may still over-reward | Prototype tuning |
| First Playable Scope | LOCKED_FOR_MILESTONE | One spin loop + one short run + bounded idle + simple meta | Scope discipline | Content temptation | Milestone completion |
| Resource Boundary Model | APPROVED_CURRENT | 4-layer model, no universal currency | Readability and control | First inflation source unknown | Economy review |

Notes:
- This is an example only.
- Replace with project-specific decisions.
