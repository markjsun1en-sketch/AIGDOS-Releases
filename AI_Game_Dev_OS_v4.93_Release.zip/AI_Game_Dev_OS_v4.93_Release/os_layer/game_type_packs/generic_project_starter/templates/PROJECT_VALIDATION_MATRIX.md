# PROJECT_VALIDATION_MATRIX

## Core Rules
- Code/logic changes require:
- Data/config changes require:
- UI flow changes require:
- Art delivery changes require:
- Design/system changes require:

## Evidence Baseline
- Minimum evidence required:
- Cases that require human review:
- Cases that require playtest:
- Cases that require simulation or automated validation:

## Stage Overrides
- MVP:
- VERTICAL_SLICE:
- PRODUCTION_LIKE:
