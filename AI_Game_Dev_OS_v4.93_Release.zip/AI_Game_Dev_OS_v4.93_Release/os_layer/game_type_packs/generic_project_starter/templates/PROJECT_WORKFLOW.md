# PROJECT_WORKFLOW

## Baseline Task Flow
1. intake
2. routing
3. work in progress
4. validation/review
5. approval when needed
6. closure
7. carry-forward if needed

## Routing Rules
- Design-led work routes through:
- Art-led work routes through:
- UI-led work routes through:
- Engineering-led work routes through:

## Handoff and Delivery Rules
- Runtime handoff object usage:
- Thread handoff pack usage:
- Delivery bundle usage:

## Escalation Rules
- Blockers go to:
- Approval requests go to:
- Policy conflicts go to:
