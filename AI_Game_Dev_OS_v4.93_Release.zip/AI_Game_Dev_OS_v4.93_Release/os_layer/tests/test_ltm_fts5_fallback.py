"""Tests for the v4.90 Layer B FTS5 retrieval engine.

v4.90 Batch 4 Step 4.5.d.

Lives at tests/ (top-level) alongside the 4 v4.89 LTM tests so the
existing pytest invocation picks them up. Tests are guarded with
``pytest.skipif(not _fts5_available, ...)`` for the FTS5-required
subset; the fallback / engine-dispatch tests run unconditionally.
"""
from __future__ import annotations

import importlib
import re
import sqlite3
from pathlib import Path

import pytest

from runtime.ltm import consult
from runtime.ltm import _fts5_index

_fts5_mod = importlib.import_module("runtime.ltm._fts5_index")
_consult_mod = importlib.import_module("runtime.ltm.consult")


# Cached at module level — the probe is reset before each test that
# cares about probe state.
_HAS_FTS5: bool = _fts5_index.probe_fts5_available()


# ---------------------------------------------------------------------
# Test 1: capability probe
# ---------------------------------------------------------------------

def test_fts5_probe_returns_bool():
    """Probe is callable and returns a bool. Cached after first call."""
    _fts5_mod._reset_probe_cache()
    result = _fts5_mod.probe_fts5_available()
    assert isinstance(result, bool)
    # Second call hits cache, must agree.
    assert _fts5_mod.probe_fts5_available() == result


# ---------------------------------------------------------------------
# Test 2: engine='auto' falls back to substring when FTS5 is unavailable
# ---------------------------------------------------------------------

def test_engine_auto_fallback_to_substring_when_fts5_unavailable(
    monkeypatch, tmp_path: Path
):
    """auto engine + FTS5 unavailable → identical to substring path.

    Layer B contract: engine='auto' MUST resolve to substring when
    FTS5 is absent (and per Step 4.5.a, it resolves to substring even
    when FTS5 IS available, for Layer A compatibility).
    """
    # Force the FTS5 probe to report False, regardless of the runtime.
    monkeypatch.setattr(_fts5_mod, "_FTS5_PROBE_CACHE", False)
    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)
    (tmp_path / "os").mkdir()
    (tmp_path / "os" / "a.md").write_text(
        "# A\nthe envelope has canonical form\n", encoding="utf-8"
    )
    auto_hits = consult("envelope", engine="auto")
    sub_hits = consult("envelope", engine="substring")
    assert auto_hits == sub_hits


# ---------------------------------------------------------------------
# Test 3: engine='substring' bypasses FTS5 even when available
# ---------------------------------------------------------------------

def test_engine_substring_explicit_bypasses_fts5(
    monkeypatch, tmp_path: Path
):
    """Explicit substring engine MUST not touch the FTS5 path."""
    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)
    (tmp_path / "os").mkdir()
    (tmp_path / "os" / "a.md").write_text(
        "# A\nenvelope contract content\n", encoding="utf-8"
    )

    # Sentinel: if the FTS5 path were called, it would touch
    # _fts5_index.query. Replace that with a poison pill.
    def _poison(*a, **k):
        raise AssertionError("substring engine MUST NOT invoke FTS5 query")
    monkeypatch.setattr(_fts5_mod, "query", _poison)

    hits = consult("envelope", engine="substring")
    assert any("a.md" in h["path"] for h in hits)


# ---------------------------------------------------------------------
# Test 4: engine='fts5' raises when FTS5 unavailable
# ---------------------------------------------------------------------

def test_engine_fts5_explicit_raises_when_unavailable(monkeypatch):
    """Explicit FTS5 + FTS5 absent → loud RuntimeError."""
    monkeypatch.setattr(_fts5_mod, "_FTS5_PROBE_CACHE", False)
    with pytest.raises(RuntimeError) as exc:
        consult("anything", engine="fts5")
    assert "FTS5 is unavailable" in str(exc.value)


# ---------------------------------------------------------------------
# Test 4b: unknown engine value raises ValueError
# ---------------------------------------------------------------------

def test_engine_unknown_value_raises_value_error():
    """Engine kwarg validation — unknown value surfaces immediately."""
    with pytest.raises(ValueError) as exc:
        consult("anything", engine="bogus")
    msg = str(exc.value)
    assert "bogus" in msg
    assert "auto" in msg
    assert "substring" in msg
    assert "fts5" in msg


# ---------------------------------------------------------------------
# Test 5: index rebuild is idempotent (FTS5-required)
# ---------------------------------------------------------------------

@pytest.mark.skipif(not _HAS_FTS5, reason="FTS5 not available in this Python")
def test_fts5_index_rebuild_idempotent(monkeypatch, tmp_path: Path):
    """Rebuild twice over the same corpus -> identical entry count.

    We don't assert byte-identical sqlite output (sqlite serialises
    auto-allocated rowids in different orders depending on insert
    timing) — only that the entry count and queryable hits are stable.
    """
    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)
    (tmp_path / "os").mkdir()
    for i in range(3):
        (tmp_path / "os" / f"e{i}.md").write_text(
            f"# E{i}\nenvelope sample {i}\n", encoding="utf-8"
        )

    r1 = _fts5_mod.rebuild_index()
    r2 = _fts5_mod.rebuild_index()
    assert r1["entries_indexed"] == r2["entries_indexed"] == 3

    hits1 = _fts5_mod.query("envelope")
    hits2 = _fts5_mod.query("envelope")
    assert {h["path"] for h in hits1} == {h["path"] for h in hits2}


# ---------------------------------------------------------------------
# Test 6: FTS5 ranking — multi-token query, more matches first
# ---------------------------------------------------------------------

@pytest.mark.skipif(not _HAS_FTS5, reason="FTS5 not available in this Python")
def test_fts5_ranking_returns_more_relevant_first(
    monkeypatch, tmp_path: Path
):
    """A 2-token-hit doc should outrank a 1-token-hit doc under BM25."""
    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)
    (tmp_path / "os").mkdir()
    # Two-token doc: contains both 'envelope' and 'canonical'
    (tmp_path / "os" / "two_tokens.md").write_text(
        "# Two\nthe envelope is canonical here\n", encoding="utf-8"
    )
    # One-token doc: contains only 'envelope'
    (tmp_path / "os" / "one_token.md").write_text(
        "# One\nplain envelope reference\n", encoding="utf-8"
    )

    _fts5_mod.rebuild_index()
    hits = _fts5_mod.query("envelope canonical", limit=5)
    paths = [Path(h["path"]).name for h in hits]
    # Both files should match (FTS5 AND), but two_tokens.md wins.
    assert "two_tokens.md" in paths
    assert paths[0] == "two_tokens.md"


# ---------------------------------------------------------------------
# Test 7: index file lives at expected path under monkey-patched root
# ---------------------------------------------------------------------

@pytest.mark.skipif(not _HAS_FTS5, reason="FTS5 not available in this Python")
def test_fts5_index_lives_under_ltm_root(monkeypatch, tmp_path: Path):
    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)
    (tmp_path / "os").mkdir()
    (tmp_path / "os" / "a.md").write_text(
        "# A\nenvelope ok\n", encoding="utf-8"
    )

    _fts5_mod.rebuild_index()
    expected = tmp_path / ".fts_index.sqlite"
    assert expected.exists()
    # Sanity: it really is an sqlite file with our schema.
    conn = sqlite3.connect(str(expected))
    try:
        cur = conn.execute("SELECT count(*) FROM entries")
        assert cur.fetchone()[0] == 1
    finally:
        conn.close()


# ---------------------------------------------------------------------
# Test 8: project_id 'missing == global' semantics in FTS5 query
# ---------------------------------------------------------------------

@pytest.mark.skipif(not _HAS_FTS5, reason="FTS5 not available in this Python")
def test_fts5_query_project_id_missing_equals_global(
    monkeypatch, tmp_path: Path
):
    """An entry without project_id MUST surface under any project filter."""
    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)
    (tmp_path / "os").mkdir()
    (tmp_path / "project").mkdir()
    (tmp_path / "project" / "acme_demo").mkdir()

    # Untagged OS entry — visible to every project.
    (tmp_path / "os" / "global.md").write_text(
        "# Global\nenvelope wisdom\n", encoding="utf-8"
    )
    # Tagged project entry.
    (tmp_path / "project" / "acme_demo" / "tagged.md").write_text(
        "---\nproject_id: acme_demo\n---\n# Tagged\nenvelope local\n",
        encoding="utf-8",
    )

    _fts5_mod.rebuild_index()
    hits = _fts5_mod.query("envelope", project_id="acme_demo")
    paths = {Path(h["path"]).name for h in hits}
    assert "global.md" in paths       # untagged is visible
    assert "tagged.md" in paths       # same-project tagged is visible

    # Switch filter to a different project — global stays, tagged drops.
    hits2 = _fts5_mod.query("envelope", project_id="other_demo")
    paths2 = {Path(h["path"]).name for h in hits2}
    assert "global.md" in paths2
    assert "tagged.md" not in paths2


# ---------------------------------------------------------------------
# Test 9: empty / whitespace query short-circuits to []
# ---------------------------------------------------------------------

def test_engine_fts5_empty_query_returns_empty(monkeypatch):
    """Empty query short-circuits like the substring path does."""
    if not _HAS_FTS5:
        # Even when FTS5 unavailable, empty-query short-circuit happens
        # BEFORE the probe — but we use the substring path here to keep
        # the test runnable on FTS5-less envs.
        assert consult("", engine="substring") == []
        return
    assert consult("", engine="fts5") == []
    assert consult("   ", engine="fts5") == []
