# Mock Legacy Project — Baseline Fixture

> **v4.90 Batch 2.5 Module A — fresh-state baseline**
> Path: `tests/fixtures/mock_legacy_project_baseline/`
> Layer 1 (OS Spec). No project-specific names.

## Role

A **fresh, empty-capability** legacy project tree used as the starting
point for the Batch 2.5 mock harness. The factory
`make_legacy_project_from_baseline()` in `tests/adoption/conftest.py`
copies this directory to a `tmp_path` at test start, then optionally
plants additional `capability_id` evidence on top.

## Contract

- **Generic only**. All identifiers used below are placeholders
  (`acme_demo`, `sample_project`, …). The directory MUST NEVER contain
  a project-specific name — the Layer 1 lint rule enforces this.
- **Fresh baseline = 0 scored capabilities detected**. After
  `scripts/migration/scan_legacy_project.py` scans the copy, exactly
  14 capabilities return with `detection_method=none` and `detected=false`.
- **Shape mirrors the docs/13_migration PROGRESSIVE_ADOPTION_GUIDE
  step-0 assumption**: the project already has a `docs/` dir and a
  `runtime_state_seed/` dir, but none of the 14 capability fingerprints
  light up. This keeps scan/validate on a realistic skeleton.

## Why a static fixture (not purely dynamic)?

Two reasons:

1. **Diff-reviewable**: EP or reviewers can inspect the baseline bytes
   in a normal code review. A runtime-generated tree cannot be audited
   that way.
2. **Reproducibility**: checksum-locked (shasum entries in `CHECKSUMS.sha`)
   means a drift in the baseline is caught as a regression, not a
   silent test-environment change.

Non-fresh scenarios (partial / full / custom spec) still go through
the conftest factory, which clones this baseline and layers plant
operations on top.

## File inventory

| File | Role |
| --- | --- |
| `README.md` (this file) | Baseline contract + fixture role |
| `docs/.gitkeep` | Marks `docs/` as present (fresh dir, no matrix inside) |
| `runtime_state_seed/.gitkeep` | Marks seed dir; empty by design |

No other files. Every scenario beyond "fresh baseline" adds content
via the conftest factory — this file is the single source of truth
for the zero-capability starting state.
