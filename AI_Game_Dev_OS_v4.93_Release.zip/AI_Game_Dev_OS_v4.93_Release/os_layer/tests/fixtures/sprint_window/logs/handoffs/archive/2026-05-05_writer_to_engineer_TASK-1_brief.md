# Writer → Engineer: TASK-1 brief (archived)

Archived handoff carrying the original brief for the greeter module.

Linked task: TASK-1
Sprint window: SPRINT-1
