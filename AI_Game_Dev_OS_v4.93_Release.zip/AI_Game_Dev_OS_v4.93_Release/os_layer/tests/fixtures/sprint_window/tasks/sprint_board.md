# Sprint Board (Fixture)

> Pytest fixture only. Not a real sprint.

## Previous Sprint

- Sprint Name: SPRINT-0 — initial scaffold
- Goal: Stand up the fixture workspace.
- Status: DONE

## Current Sprint

- Sprint Name: SPRINT-1 — greeter feature
- Goal: Implement, test, and document the greeter module within the sprint window.
- Status: IN_PROGRESS
- Sprint Boundary:
  1. Only the greeter module changes; no engine refactors.
  2. All TASK-* live in this sprint window.
  3. Documentation lands together with TASK-3.
