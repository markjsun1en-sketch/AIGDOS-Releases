---
title: "Sample working note for B6 F15 dry-run smoke"
proposed_at: "2026-05-22"
evidence_ref:
  - "tests/fixtures/ltm_evolution_capture/working/sample.md"
promotion_rationale: "Synthetic fixture for B6 c7 F15 fast-gate dry-run smoke. Not a real LTM candidate — exists only to exercise extract_failure_candidates --dry-run --source working_note path inside the fast gate."
---

# Sample note (Layer 1 fixture)

This file is a synthetic working/ note used by the B6 c7 F15
fast-gate dry-run smoke test. It validates that
`extract_failure_candidates.py --source working_note --dry-run`
emits a schema-valid envelope without writing.

Charter: this fixture lives under tests/fixtures/ which is a
test_fixtures tier in RELEASE_MANIFEST (not a Layer 1 root).
