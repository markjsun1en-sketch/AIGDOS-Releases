"""RC release integrity sentinel — v4.90 Batch 13 Step 13.5.

Renamed from ``test_rc1_release_integrity.py`` per EP D-13.5.1=B to
host invariants from both RC1 (Batch 12) and RC2 (Batch 13). New RC
generations (rc3+) should append additional aggregated tests rather
than spawning new files.

Three-test guard:

  1. **RC1 byte-lock** — The ``AI_Game_Dev_OS_v4.89_Release`` tree at
     the workspace root remains byte-locked at SHA
     ``bb48af169f9b4f57c4bb86ab9b82f2ddfef87767``.

  2. **RC1 manifest round-trip** — Every entry in
     ``RELEASE_MANIFEST.json`` carries a sha256 that matches the
     file's actual content (``required_manifest_files`` +
     ``optional_seed_files`` + ``test_fixtures``).

  3. **RC2 CLI surface complete** (Batch 13 Step 13.5, D-13.5.2=A) —
     Each of the 9 new Batch 13 CLI leaves dispatches to its
     underlying script; ``--help`` exits 0 with the underlying
     argparse usage line. Aggregated into a single test to keep the
     §8 trajectory at exactly +1.

These run inside the v4.90 pytest suite so any regression that
mutates the v4.89 tree, drifts the manifest, or breaks one of the
RC2 CLI additions is caught immediately. The byte-lock test is
best-effort: it skips gracefully when the v4.89_Release sibling is
unavailable (e.g. when v4.90 is unpacked standalone) so downstream
packagings don't break.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import subprocess
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

import pytest

V4_90_ROOT = Path(__file__).resolve().parent.parent
WORKSPACE_ROOT = V4_90_ROOT.parent
MANIFEST_PATH = V4_90_ROOT / "RELEASE_MANIFEST.json"

EXPECTED_V489_SHA = "bb48af169f9b4f57c4bb86ab9b82f2ddfef87767"


def _sha256_of_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


# --------------------------------------------------------------------------
# 1. v4.89 byte-lock
# --------------------------------------------------------------------------

def test_v4_89_byte_lock_unchanged():
    """The AI_Game_Dev_OS_v4.89_Release tree at the workspace root MUST
    hash to the canonical SHA. Skips when run from a standalone
    v4.90 unpack where the sibling tree is absent (e.g. distribution
    archives that ship only v4.90)."""
    v489 = WORKSPACE_ROOT / "AI_Game_Dev_OS_v4.89_Release"
    if not v489.is_dir():
        pytest.skip("v4.89_Release sibling not present (standalone unpack)")
    if not (WORKSPACE_ROOT / ".git").exists():
        pytest.skip("workspace not a git checkout (cannot resolve tree SHA)")
    if shutil.which("git") is None:
        pytest.skip("git binary not on PATH")

    proc = subprocess.run(
        ["git", "ls-tree", "HEAD", "AI_Game_Dev_OS_v4.89_Release"],
        cwd=str(WORKSPACE_ROOT),
        capture_output=True, text=True, timeout=10,
    )
    assert proc.returncode == 0, proc.stderr
    parts = proc.stdout.strip().split()
    # Format: <mode> <type> <sha>\t<path>
    assert len(parts) >= 3, f"unexpected ls-tree output: {proc.stdout!r}"
    actual_sha = parts[2]
    assert actual_sha == EXPECTED_V489_SHA, (
        f"v4.89 byte-lock broken: tree SHA changed to {actual_sha!r} "
        f"(expected {EXPECTED_V489_SHA!r})"
    )


# --------------------------------------------------------------------------
# 2. RELEASE_MANIFEST round-trip
# --------------------------------------------------------------------------

def test_release_manifest_round_trip():
    """Every file recorded in RELEASE_MANIFEST.json must hash to its
    declared sha256. Catches drift caused by editing a tracked file
    without rerunning ``scripts/rebuild_release_manifest.py``."""
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    bad: list[tuple[str, str, str]] = []  # (path, declared, actual)
    seen = 0
    for tier in ("required_manifest_files", "optional_seed_files",
                 "test_fixtures"):
        for entry in manifest.get(tier, []):
            rel = entry.get("path")
            declared = entry.get("sha256")
            if not rel or not declared:
                continue
            seen += 1
            full = V4_90_ROOT / rel
            if not full.is_file():
                bad.append((rel, declared, "FILE_MISSING"))
                continue
            actual = _sha256_of_file(full)
            if actual != declared:
                bad.append((rel, declared, actual))
    assert seen > 0, "manifest had no entries to verify"
    assert not bad, (
        "manifest sha256 drift on "
        + str(len(bad)) + " file(s):\n  "
        + "\n  ".join(f"{p}: declared={d[:12]}… actual={a[:12]}…"
                      for p, d, a in bad[:20])
        + ("..." if len(bad) > 20 else "")
    )


# --------------------------------------------------------------------------
# 3. RC2 CLI surface complete — v4.90 Batch 13 Step 13.5 (D-13.5.2=A).
#
# Single aggregated test that walks every CLI leaf added (or de-STUB'd) in
# Batch 13 and asserts that `--help` reaches the underlying argparse, exits
# 0, and prints the underlying usage line. Aggregated into ONE test so the
# §8 trajectory matches exactly +1 (835 -> 836).
# --------------------------------------------------------------------------

# Sentinel substring expected in stdout (case-insensitive). Underlying
# argparse always emits 'usage:' on --help.
_USAGE_SENTINEL = "usage:"

# Each entry is the full argv passed to ai_dev_os.main(). Order matches the
# Batch 13 sub-step order in V4_90_README.md §5.16 for ease of review.
_BATCH_13_CLI_LEAVES: list[list[str]] = [
    # 13.1 — ltm consult de-STUB'd
    ["ltm", "consult", "--help"],
    # 13.4.b — ltm quarantine
    ["ltm", "quarantine", "--help"],
    # 13.4.c — pack agent-library list / activate
    ["pack", "agent-library", "list", "--help"],
    ["pack", "agent-library", "activate", "--help"],
    # 13.4.d — evolve propose
    ["evolve", "propose", "--help"],
    # 13.4.a — migration handshake / plan / verify / report
    ["migration", "handshake", "--help"],
    ["migration", "plan", "--help"],
    ["migration", "verify", "--help"],
    ["migration", "report", "--help"],
]


def test_rc2_cli_surface_complete():
    """All 9 Batch 13 CLI leaves --help reach their underlying script
    with exit 0 and 'usage:' in stdout. Catches accidental wiring
    regressions across all of Step 13.1 / 13.4.a / 13.4.b / 13.4.c /
    13.4.d in a single sentinel."""
    from scripts.cli import ai_dev_os

    failures: list[str] = []
    for argv in _BATCH_13_CLI_LEAVES:
        out_buf, err_buf = io.StringIO(), io.StringIO()
        try:
            with redirect_stdout(out_buf), redirect_stderr(err_buf):
                rc = ai_dev_os.main(list(argv))
        except SystemExit as exc:
            rc = int(exc.code) if exc.code is not None else 0
        out = out_buf.getvalue()
        err = err_buf.getvalue()
        leaf_label = " ".join(argv)
        if rc != 0:
            failures.append(
                f"{leaf_label!r}: rc={rc} (expected 0); "
                f"stderr_head={err[:120]!r}"
            )
            continue
        if _USAGE_SENTINEL not in out.lower() and _USAGE_SENTINEL not in err.lower():
            failures.append(
                f"{leaf_label!r}: 'usage:' missing from --help output; "
                f"stdout_head={out[:200]!r}"
            )
    assert not failures, (
        "Batch 13 CLI surface regression — "
        + str(len(failures)) + " leaf(s) failed:\n  "
        + "\n  ".join(failures)
    )
