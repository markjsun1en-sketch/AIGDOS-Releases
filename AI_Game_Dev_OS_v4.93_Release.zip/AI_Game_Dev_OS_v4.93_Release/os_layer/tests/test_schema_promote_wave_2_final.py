"""Schema Promote Wave 2 — final-version invariants (v4.90 Batch 12 Step 12.1).

This test guards the unify-promote of 8 v4.90 schemas from `-beta` to
final semver (`0.1.0-beta` -> `1.0.0` and `1.1.0-beta` -> `1.1.0`),
plus the D-1=B decision to lift `pack_version` of the 5 seed agent
packs to `1.0.0` on their independent semver track.

v4.90.9 patch (Batch 14.16): project_profile schema bumped to 1.1.0
when game_dev_phase became required (separating game-dev workflow
phase from project lifecycle stage). The PROMOTED_SCHEMAS map below
reflects the post-patch state.

Sentinels enforced:
  a. Each promoted schema's `const` field equals the target final
     version literal.
  b. No schema-internal field VALUE (excluding `description`,
     `_skeleton_notes.tier`, `_skeleton_notes.todo_later`) contains
     a `-beta` literal in any `schemas/**` JSON file.
  c. The 6 Python validator/CLI modules touched by Step 12.1 expose
     SCHEMA_VERSION / REPORT_SCHEMA_VERSION constants whose value
     equals the corresponding schema final version.
  d. The 2 seed entries (ff_2026_001 / evo_2026_001) and the 5 seed
     agent_pack files have front-matter literals matching their
     final versions.
  e. Sentinel doc check: no remaining `Batch 12.2` forward-reference
     phrasing in schema descriptions (was used pre-promote when the
     promote step was still pending; post-promote should read
     `Batch 12 Step 12.1 promoted to ...`).

Layer 1 (OS Spec). No project names. Lives at workspace root tests/.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import pytest

V4_90_ROOT = Path(__file__).resolve().parent.parent

# --------------------------------------------------------------------------
# Promote map: schema_path -> expected final version literal
# --------------------------------------------------------------------------

PROMOTED_SCHEMAS: dict[str, str] = {
    "schemas/adoption/host_profile.schema.json": "1.0.0",
    "schemas/adoption/project_profile.schema.json": "1.1.0",
    "schemas/adoption/active_packs.schema.json": "1.0.0",
    "schemas/ltm/failure_fix_memory.schema.json": "1.0.0",
    "schemas/ltm/memory_candidate.schema.json": "1.0.0",
    "schemas/ltm/memory_quality_report.schema.json": "1.0.0",
    "schemas/ltm/memory_retrieval_routing.schema.json": "1.0.0",
    "schemas/self_evolution/proposal_entry.schema.json": "1.1.0",
}


# --------------------------------------------------------------------------
# (a) const equals final version
# --------------------------------------------------------------------------


@pytest.mark.parametrize("rel,expected", list(PROMOTED_SCHEMAS.items()))
def test_schema_const_promoted_to_final(rel: str, expected: str) -> None:
    schema = json.loads((V4_90_ROOT / rel).read_text(encoding="utf-8"))
    sv = schema["properties"]["schema_version"]
    assert sv.get("const") == expected, (
        f"{rel}: schema_version.const should be '{expected}', "
        f"got {sv.get('const')!r}"
    )


# --------------------------------------------------------------------------
# (b) no -beta in schema field VALUES (descriptions allowed for history)
# --------------------------------------------------------------------------


_BETA_RE = re.compile(r"-beta")
# Keys whose values are allowed to mention "-beta" as historical narration:
_HISTORY_KEYS = {"description", "tier", "todo_later"}


def _walk_violations(node, path: str, violations: list[str]) -> None:
    if isinstance(node, dict):
        for key, value in node.items():
            child_path = f"{path}.{key}"
            if key in _HISTORY_KEYS:
                continue  # narrative fields may keep historical refs
            _walk_violations(value, child_path, violations)
    elif isinstance(node, list):
        for idx, value in enumerate(node):
            _walk_violations(value, f"{path}[{idx}]", violations)
    elif isinstance(node, str):
        if _BETA_RE.search(node):
            violations.append(f"{path}: {node!r}")


def test_no_beta_in_schema_value_fields() -> None:
    violations: list[str] = []
    for rel in PROMOTED_SCHEMAS:
        path = V4_90_ROOT / rel
        data = json.loads(path.read_text(encoding="utf-8"))
        _walk_violations(data, rel, violations)
    assert not violations, (
        "Found -beta literals in non-narrative schema fields:\n  "
        + "\n  ".join(violations)
    )


# --------------------------------------------------------------------------
# (c) Python module SCHEMA_VERSION constants reflect final versions
# --------------------------------------------------------------------------

_PY_CONST_EXPECTATIONS: list[tuple[str, str, str]] = [
    # (module_relpath, constant_name, expected_value)
    ("scripts/ltm/extract_failure_candidates.py", "SCHEMA_VERSION", "1.0.0"),
    ("scripts/ltm/validate_memory_quality.py", "REPORT_SCHEMA_VERSION", "1.0.0"),
    ("scripts/self_evolution/validate_proposal.py", "SCHEMA_VERSION", "1.1.0"),
]


@pytest.mark.parametrize("rel,name,expected", _PY_CONST_EXPECTATIONS)
def test_python_module_constant_reflects_final_version(
    rel: str, name: str, expected: str
) -> None:
    text = (V4_90_ROOT / rel).read_text(encoding="utf-8")
    pattern = re.compile(
        rf'^{re.escape(name)}\s*=\s*"([^"]+)"', re.MULTILINE
    )
    match = pattern.search(text)
    assert match is not None, f"{rel}: constant {name} not found"
    assert match.group(1) == expected, (
        f"{rel}: {name} should equal '{expected}', got '{match.group(1)}'"
    )


# --------------------------------------------------------------------------
# (d) Seed front-matter literals
# --------------------------------------------------------------------------

_SEED_EXPECTATIONS: list[tuple[str, str]] = [
    ("ltm/failures/2026-05-10_ff_2026_001_v489_to_v490_direct_replace_failure.md",
     "1.0.0"),
    ("proposals/evo_2026_001_layer_separation_principle.md", "1.1.0"),
]

_AGENT_PACK_FILES = [
    "agent_packs/ap_2026_001_executive_cluster.md",
    "agent_packs/ap_2026_002_research_and_design_cluster.md",
    "agent_packs/ap_2026_003_implementation_cluster.md",
    "agent_packs/ap_2026_004_validation_cluster.md",
    "agent_packs/ap_2026_005_support_cluster.md",
]


@pytest.mark.parametrize("rel,expected", _SEED_EXPECTATIONS)
def test_seed_schema_version_promoted(rel: str, expected: str) -> None:
    text = (V4_90_ROOT / rel).read_text(encoding="utf-8")
    # Front-matter is the first --- ... --- block.
    fm_match = re.match(r"\A---\n(.*?)\n---\n", text, re.DOTALL)
    assert fm_match is not None, f"{rel}: missing YAML front-matter"
    body = fm_match.group(1)
    sv_match = re.search(r'^schema_version:\s*"?([^"\s]+)"?\s*$',
                         body, re.MULTILINE)
    assert sv_match is not None, f"{rel}: schema_version not in front-matter"
    assert sv_match.group(1) == expected, (
        f"{rel}: schema_version should be '{expected}', "
        f"got '{sv_match.group(1)}'"
    )


@pytest.mark.parametrize("rel", _AGENT_PACK_FILES)
def test_agent_pack_pack_version_promoted(rel: str) -> None:
    """D-1=B: pack_version of seed packs promoted to 1.0.0 (independent
    semver track preserved per agent_pack_entry.schema description)."""
    text = (V4_90_ROOT / rel).read_text(encoding="utf-8")
    pv_match = re.search(r'^pack_version:\s*"([^"]+)"\s*$',
                         text, re.MULTILINE)
    assert pv_match is not None, f"{rel}: pack_version not found"
    assert pv_match.group(1) == "1.0.0", (
        f"{rel}: pack_version should be '1.0.0', got '{pv_match.group(1)}'"
    )


# --------------------------------------------------------------------------
# (e) No remaining "Batch 12.2" forward-reference in promoted schemas
# --------------------------------------------------------------------------


def test_no_batch_12_2_forward_reference_in_promoted_schemas() -> None:
    """Pre-promote, descriptions said 'Batch 12.2 will unify-promote ...'.
    Post-promote, they must read 'Batch 12 Step 12.1 promoted to ...'."""
    leaks: list[str] = []
    for rel in PROMOTED_SCHEMAS:
        text = (V4_90_ROOT / rel).read_text(encoding="utf-8")
        if "Batch 12.2" in text:
            leaks.append(rel)
    assert not leaks, (
        "Promoted schemas still contain 'Batch 12.2' forward-reference:\n  "
        + "\n  ".join(leaks)
    )
