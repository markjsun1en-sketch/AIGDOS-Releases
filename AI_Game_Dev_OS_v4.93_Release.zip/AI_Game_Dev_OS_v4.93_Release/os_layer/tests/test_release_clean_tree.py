"""Tests for ``scripts/governance/verify_release_clean_tree.py``.

v4.90.1 hygiene patch — covers the manifest-driven clean-tree audit:
manifest entries → "expected"; transient_patterns / self_referential /
generated_runtime_outputs → "permitted exclusion"; everything else → violation.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest


_THIS = Path(__file__).resolve()
_REPO = _THIS.parent.parent
_SCRIPT = _REPO / "scripts" / "governance" / "verify_release_clean_tree.py"


# A minimal manifest stub matching v4.90 RELEASE_MANIFEST.json layout
_MANIFEST_STUB = {
    "package_name": "AI_Game_Dev_OS_test",
    "package_root_dir": "AI_Game_Dev_OS_test",
    "manifest_schema_version": "test",
    "exclusions": {
        "self_referential": ["CHECKSUMS.sha", "RELEASE_MANIFEST.json"],
        "transient_patterns": [
            "__pycache__/",
            ".pytest_cache/",
            "*.pyc",
            ".DS_Store",
            "._*",
        ],
        "generated_runtime_outputs": [
            "exports/**  (except exports/.gitignore)",
        ],
    },
    "required_manifest_files": [
        {"path": "README.md", "bytes": 0, "sha256": "x"},
        {"path": "exports/.gitignore", "bytes": 0, "sha256": "x"},
        {"path": "config/marker", "bytes": 0, "sha256": "x"},
    ],
    "optional_seed_files": [],
    "test_fixtures": [],
}


def _make_release_tree(tmp_path: Path, extra_files: dict[str, str] | None = None) -> Path:
    """Create a minimal release tree under tmp_path/release/.

    Returns the release root.
    """
    root = tmp_path / "release"
    root.mkdir()

    # Required manifest files
    (root / "README.md").write_text("# stub readme\n", encoding="utf-8")
    (root / "exports").mkdir()
    (root / "exports" / ".gitignore").write_text("*\n", encoding="utf-8")
    (root / "config").mkdir()
    (root / "config" / "marker").write_text("v4.90-marker\n", encoding="utf-8")

    # Self-referential (allowed, never enumerated in manifest.files)
    (root / "CHECKSUMS.sha").write_text("stub\n", encoding="utf-8")

    # Manifest itself
    (root / "RELEASE_MANIFEST.json").write_text(
        json.dumps(_MANIFEST_STUB, indent=2), encoding="utf-8"
    )

    # Optional extras dictated by the test
    for rel, content in (extra_files or {}).items():
        target = root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")

    return root


def _run(release_root: Path, *extra_args: str) -> tuple[int, str, str]:
    cmd = [
        sys.executable,
        str(_SCRIPT),
        "--project-root",
        str(release_root),
        *extra_args,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    return proc.returncode, proc.stdout, proc.stderr


def test_clean_release_tree_passes(tmp_path: Path) -> None:
    """A tree containing exactly the manifest + self-referential files exits 0."""
    root = _make_release_tree(tmp_path)
    rc, out, err = _run(root)
    assert rc == 0, f"expected EXIT_OK, got {rc}; stdout={out!r}; stderr={err!r}"
    assert "clean" in out


def test_extra_pyc_detected(tmp_path: Path) -> None:
    """A stray .pyc anywhere under root must be reported AND fail."""
    root = _make_release_tree(
        tmp_path, extra_files={"scripts/foo.cpython-313.pyc": "stray\n"}
    )
    rc, out, _ = _run(root)
    assert rc == 1, f"expected EXIT_VIOLATION, got {rc}; stdout={out!r}"
    assert "scripts/foo.cpython-313.pyc" in out
    assert "[transient]" in out


def test_pycache_dir_detected(tmp_path: Path) -> None:
    """Files under any __pycache__/ segment must trigger transient violation."""
    root = _make_release_tree(
        tmp_path,
        extra_files={"runtime/__pycache__/foo.cpython-313.pyc": "stray\n"},
    )
    rc, out, _ = _run(root)
    assert rc == 1
    assert "runtime/__pycache__/foo.cpython-313.pyc" in out
    assert "[transient]" in out


def test_ds_store_detected(tmp_path: Path) -> None:
    """A .DS_Store file at any depth is a transient violation."""
    root = _make_release_tree(tmp_path, extra_files={".DS_Store": ""})
    rc, out, _ = _run(root)
    assert rc == 1
    assert ".DS_Store" in out


def test_missing_manifest_returns_input_missing(tmp_path: Path) -> None:
    """If RELEASE_MANIFEST.json is missing, the script must exit 4."""
    root = tmp_path / "empty"
    root.mkdir()
    (root / "README.md").write_text("orphan\n", encoding="utf-8")
    rc, _, err = _run(root)
    assert rc == 4, f"expected EXIT_INPUT_MISSING, got {rc}; stderr={err!r}"
    assert "manifest not found" in err
