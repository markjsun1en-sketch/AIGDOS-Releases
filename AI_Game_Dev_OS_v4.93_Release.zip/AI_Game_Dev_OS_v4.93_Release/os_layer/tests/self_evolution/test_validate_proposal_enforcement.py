"""test_validate_proposal_enforcement.py — v4.90 Batch 10 Step 10.3.

State-conditional enforcement tests for the new optional fields
introduced by the 1.1.0 minor bump (Step 10.1):
  - validation_plan (required when state==accepted; grandfather WARN
    when missing)
  - sandbox_dir (required when state==implementing; grandfather WARN
    when null for principle-kind proposals)
  - change_candidate.affected_dirs (must be unique non-empty strings
    regardless of state)

6 cases:
  1  accepted + no validation_plan       -> WARN (exit 0)
  2  accepted + empty required[]         -> VIOLATION (exit 1)
  3  accepted + unknown check enum       -> VIOLATION (exit 1)
  4  implementing + no sandbox_dir       -> WARN (exit 0)
  5  implementing + bad sandbox pattern  -> VIOLATION (exit 1)
  6  change_candidate duplicate dirs     -> VIOLATION (exit 1)

Re-uses _minimal_frontmatter helper from tests/self_evolution/
test_validate_proposal.py (same module).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

# Re-use helpers from sibling test module
from tests.self_evolution.test_validate_proposal import (
    VALIDATOR,
    _minimal_frontmatter,
    _run,
)


def _write_and_run(tmp_path: Path, overrides: dict) -> tuple[int, str, str]:
    """Write a proposal entry to tmp_path with overrides and run validator."""
    body = _minimal_frontmatter(overrides)
    proposal_file = tmp_path / "evo_2099_999_test.md"
    proposal_file.write_text(body, encoding="utf-8")
    return _run("--file", str(proposal_file))


# --------------------------------------------------------------------------
# 1. accepted without validation_plan -> WARN, exit 0
# --------------------------------------------------------------------------

def test_accepted_without_validation_plan_warns_not_fails(tmp_path: Path):
    rc, out, err = _write_and_run(tmp_path, {
        "state": '"accepted"',
        "accepted_at": '"2099-01-02T00:00:00Z"',
        "accepted_by": '"reviewer"',
    })
    assert rc == 0, f"expected exit 0, got {rc}\nout: {out}\nerr: {err}"
    assert "WARN:" in out
    assert "grandfather" in out
    assert "0 violation(s)" in out


# --------------------------------------------------------------------------
# 2. accepted + empty required[] -> VIOLATION
# --------------------------------------------------------------------------

def test_accepted_with_empty_required_violates(tmp_path: Path):
    rc, out, _ = _write_and_run(tmp_path, {
        "state": '"accepted"',
        "accepted_at": '"2099-01-02T00:00:00Z"',
        "accepted_by": '"reviewer"',
        "validation_plan": "\n  required: []",
    })
    assert rc == 1, f"expected exit 1, got {rc}\nout: {out}"
    assert "non-empty list" in out


# --------------------------------------------------------------------------
# 3. accepted + unknown check enum -> VIOLATION
# --------------------------------------------------------------------------

def test_accepted_with_unknown_check_violates(tmp_path: Path):
    rc, out, _ = _write_and_run(tmp_path, {
        "state": '"accepted"',
        "accepted_at": '"2099-01-02T00:00:00Z"',
        "accepted_by": '"reviewer"',
        "validation_plan": "\n  required:\n    - totally_invented_check",
    })
    assert rc == 1, f"expected exit 1, got {rc}\nout: {out}"
    assert "unknown checks" in out
    assert "totally_invented_check" in out


# --------------------------------------------------------------------------
# 4. implementing + no sandbox_dir -> WARN
# --------------------------------------------------------------------------

def test_implementing_without_sandbox_dir_warns(tmp_path: Path):
    rc, out, _ = _write_and_run(tmp_path, {
        "state": '"implementing"',
        "accepted_at": '"2099-01-02T00:00:00Z"',
        "accepted_by": '"reviewer"',
    })
    assert rc == 0, f"expected exit 0, got {rc}\nout: {out}"
    assert "WARN:" in out
    assert "sandbox_dir" in out
    assert "principle-kind" in out


# --------------------------------------------------------------------------
# 5. implementing + bad sandbox_dir pattern -> VIOLATION
# --------------------------------------------------------------------------

def test_implementing_bad_sandbox_dir_pattern_violates(tmp_path: Path):
    rc, out, _ = _write_and_run(tmp_path, {
        "state": '"implementing"',
        "accepted_at": '"2099-01-02T00:00:00Z"',
        "accepted_by": '"reviewer"',
        "sandbox_dir": '"/tmp/my_experiment"',
    })
    assert rc == 1, f"expected exit 1, got {rc}\nout: {out}"
    assert "pattern" in out
    assert "sandbox_dir" in out


# --------------------------------------------------------------------------
# 6. change_candidate.affected_dirs duplicate -> VIOLATION
# --------------------------------------------------------------------------

def test_change_candidate_duplicate_affected_dirs_violates(tmp_path: Path):
    rc, out, _ = _write_and_run(tmp_path, {
        "change_candidate": "\n  affected_dirs:\n    - docs/foo\n    - docs/foo",
    })
    assert rc == 1, f"expected exit 1, got {rc}\nout: {out}"
    assert "unique" in out
