"""Shared fixtures for tests/self_evolution/ — v4.90 Batch 6.

Layer 1 (OS Spec). No project names. All test identifiers use generic
placeholders (acme_demo / sample_org / etc.).
"""
from __future__ import annotations

import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS_SELF_EVOLUTION = REPO_ROOT / "scripts" / "self_evolution"
PROPOSALS_DIR = REPO_ROOT / "proposals"
SCHEMAS_SELF_EVOLUTION = REPO_ROOT / "schemas" / "self_evolution"


@dataclass
class ScriptResult:
    exit_code: int
    stdout: str
    stderr: str

    def expect(self, code: int) -> "ScriptResult":
        assert self.exit_code == code, (
            f"expected exit {code}, got {self.exit_code}\n"
            f"stdout: {self.stdout}\nstderr: {self.stderr}"
        )
        return self


@pytest.fixture
def run_self_evolution_script():
    """Subprocess-launch scripts/self_evolution/<name>.py."""
    def _r(script_name: str, *args: str, cwd: Path | None = None) -> ScriptResult:
        script = SCRIPTS_SELF_EVOLUTION / script_name
        assert script.exists(), f"script not found: {script}"
        cmd = [sys.executable, str(script), *args]
        env = dict(os.environ)
        env["PYTHONPATH"] = str(REPO_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
        proc = subprocess.run(
            cmd, cwd=str(cwd) if cwd else None,
            env=env, capture_output=True, text=True, timeout=30,
        )
        return ScriptResult(proc.returncode, proc.stdout, proc.stderr)
    return _r
