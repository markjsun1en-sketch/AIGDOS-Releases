"""test_matrix_row_14_active.py — v4.90 Batch 6 Step 6.7.

Verifies that the Batch 6 matrix-row-14 promotion is durable:
- row 14 `14_self_evolution_proposal` is now `requires_adapter` (not
  `deprecated`).
- The adapter_name field points to the v4.90 self-evolution adapter.
- dependencies includes `07_ltm_capture_consult` (Batch 4 LTM v2 capture).
- required_paths references `proposals/` (not the old `evolution/`).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import sys
from pathlib import Path

PKG_ROOT = Path(__file__).resolve().parents[2]
MATRIX_MD = PKG_ROOT / "docs" / "13_migration" / "CAPABILITY_COMPATIBILITY_MATRIX.md"

sys.path.insert(0, str(PKG_ROOT / "scripts" / "migration"))
from _matrix_parser import parse_capability_blocks, get_capability  # noqa: E402


def test_row_14_is_requires_adapter():
    blocks = parse_capability_blocks(MATRIX_MD)
    row = get_capability(blocks, "14_self_evolution_proposal")
    assert row is not None, "row 14 must exist in the matrix"
    assert row.get("compatibility_status") == "requires_adapter", (
        f"expected 'requires_adapter', got {row.get('compatibility_status')!r}"
    )


def test_row_14_has_v490_adapter_name():
    blocks = parse_capability_blocks(MATRIX_MD)
    row = get_capability(blocks, "14_self_evolution_proposal")
    adapter = (row or {}).get("adapter") or {}
    assert adapter.get("name") == "self_evolution_proposal_directory_v490"


def test_row_14_depends_on_ltm_capture_consult():
    blocks = parse_capability_blocks(MATRIX_MD)
    row = get_capability(blocks, "14_self_evolution_proposal")
    deps = (row or {}).get("dependencies") or []
    assert "07_ltm_capture_consult" in deps


def test_row_14_fingerprint_targets_proposals_dir():
    blocks = parse_capability_blocks(MATRIX_MD)
    row = get_capability(blocks, "14_self_evolution_proposal")
    fp = (row or {}).get("fingerprint") or {}
    required = fp.get("required_paths") or []
    assert "proposals/" in required, required
