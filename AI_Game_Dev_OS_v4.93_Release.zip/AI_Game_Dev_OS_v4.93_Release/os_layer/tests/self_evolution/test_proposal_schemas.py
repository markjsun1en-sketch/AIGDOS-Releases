"""test_proposal_schemas.py — v4.90 Batch 6 Module A.

Self-validation for the 3 proposal schemas:
- schemas/self_evolution/proposal_entry.schema.json
- schemas/self_evolution/proposal_state.schema.json
- schemas/self_evolution/proposal_ledger.schema.json

6 cases:
1. All 3 schemas are themselves valid draft-07 documents.
2. proposal_entry: minimal happy-path instance validates.
3. proposal_entry: missing required field (proposal_id) → rejected.
4. proposal_entry: proposal_kind outside the 6-value enum → rejected.
5. proposal_entry: state=accepted WITHOUT accepted_at → rejected.
6. proposal_state: transition_history item with an invalid transition
   (rejected → accepted) → rejected by the allOf.anyOf whitelist.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = REPO_ROOT / "schemas" / "self_evolution"
ENTRY_PATH = SCHEMA_DIR / "proposal_entry.schema.json"
STATE_PATH = SCHEMA_DIR / "proposal_state.schema.json"
LEDGER_PATH = SCHEMA_DIR / "proposal_ledger.schema.json"


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


def _minimal_entry(state: str = "draft") -> dict:
    return {
        "schema_version": "1.1.0",
        "proposal_id": "evo_2099_999",
        "proposal_kind": "architecture_principle",
        "state": state,
        "title": "Sample proposal",
        "submitted_at": "2099-01-01T00:00:00Z",
        "submitted_by": "os_core_evolution",
        "summary": "A short summary.",
        "references": ["docs/17_self_evolution/README.md"],
    }


# --- Test 1: draft-07 meta-validation -------------------------------------

def test_all_three_schemas_are_valid_draft_07():
    for p in (ENTRY_PATH, STATE_PATH, LEDGER_PATH):
        schema = _load(p)
        jsonschema.Draft7Validator.check_schema(schema)
        assert schema["$schema"] == "http://json-schema.org/draft-07/schema#"


# --- Test 2: minimal proposal_entry valid ---------------------------------

def test_minimal_proposal_entry_valid():
    schema = _load(ENTRY_PATH)
    jsonschema.validate(instance=_minimal_entry(), schema=schema)


# --- Test 3: missing required field rejected ------------------------------

def test_missing_required_proposal_id_rejected():
    schema = _load(ENTRY_PATH)
    inst = _minimal_entry()
    inst.pop("proposal_id")
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=inst, schema=schema)


# --- Test 4: proposal_kind enum violation rejected ------------------------

def test_proposal_kind_enum_violation_rejected():
    schema = _load(ENTRY_PATH)
    inst = _minimal_entry()
    inst["proposal_kind"] = "unknown_kind"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=inst, schema=schema)


# --- Test 5: accepted without accepted_at rejected ------------------------

def test_accepted_without_accepted_at_rejected():
    schema = _load(ENTRY_PATH)
    inst = _minimal_entry(state="accepted")
    # intentionally skip accepted_at + accepted_by
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=inst, schema=schema)


# --- Test 6: invalid transition (rejected→accepted) rejected --------------

def test_proposal_state_invalid_transition_rejected():
    schema = _load(STATE_PATH)
    inst = {
        "proposal_id": "evo_2099_999",
        "state": "accepted",
        "captured_at": "2099-01-01T00:00:00Z",
        "transition_history": [
            {
                "from": "rejected",
                "to": "accepted",
                "at": "2099-01-01T00:00:00Z",
            }
        ],
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=inst, schema=schema)
