"""test_validate_proposal.py — v4.90 Batch 6 Module B.

Validates scripts/self_evolution/validate_proposal.py subprocess behavior.

7 cases:
1. --help renders.
2. --file seed proposal → exit 0; summary shows 0 violations.
3. --dir proposals/ with only the seed → exit 0, ledger shape OK.
4. --file with malformed front-matter → exit 1.
5. --file accepted state but missing accepted_at → exit 1.
6. --file nonexistent path → exit 4.
7. --format json carries a proposal_ledger-shaped top-level block.

Plus 1 bonus case (test_8) verifying the Layer 1 lint regex
exemption accepts an `evo_*.md` filename containing a project-name
substring (simulated via runtime-assembled forbidden tokens) while
the non-exempted sibling file trips the gate. This tests Step 6.2's
regex exemption end-to-end.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
VALIDATOR = PKG_ROOT / "scripts" / "self_evolution" / "validate_proposal.py"
LINT = PKG_ROOT / "scripts" / "governance" / "lint_layer_separation.py"
SEED_PATH = PKG_ROOT / "proposals" / "evo_2026_001_layer_separation_principle.md"
PROPOSALS_DIR = PKG_ROOT / "proposals"


def _run(*args, timeout: int = 20) -> tuple[int, str, str]:
    proc = subprocess.run(
        [sys.executable, str(VALIDATOR), *args],
        capture_output=True, text=True, timeout=timeout,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _minimal_frontmatter(overrides: dict | None = None) -> str:
    """Emit a valid minimal proposal front-matter + stub body."""
    base = {
        "schema_version": '"1.1.0"',
        "proposal_id": '"evo_2099_999"',
        "proposal_kind": '"architecture_principle"',
        "state": '"draft"',
        "title": '"Sample"',
        "submitted_at": '"2099-01-01T00:00:00Z"',
        "submitted_by": '"os_core_evolution"',
        "summary": '"A sample proposal."',
    }
    if overrides:
        for k, v in overrides.items():
            base[k] = v
    lines = ["---"]
    for k, v in base.items():
        lines.append(f"{k}: {v}")
    lines.append("references:")
    lines.append('  - "docs/17_self_evolution/README.md"')
    lines.append("---")
    lines.append("")
    lines.append("# Body")
    lines.append("")
    return "\n".join(lines) + "\n"


def test_1_help_renders():
    rc, out, err = _run("--help")
    assert rc == 0
    assert "validate" in out.lower() and "proposal" in out.lower()


def test_2_file_seed_exits_0():
    rc, out, err = _run("--file", str(SEED_PATH))
    assert rc == 0, err
    assert "evo_2026_001" in out
    assert "0 violation" in out


def test_3_dir_proposals_exits_0():
    rc, out, err = _run("--dir", str(PROPOSALS_DIR))
    assert rc == 0, err
    # v4.91 M-G c0 added evo_2026_002 alongside evo_2026_001;
    # validator now reports 2+ files. Match generic count.
    import re as _re
    m = _re.search(r"Summary:\s+(\d+)\s+file", out) or _re.search(r"(\d+)\s+file\(s\)\s+checked", out)
    assert m is not None, f"could not parse file count from output: {out!r}"
    n = int(m.group(1))
    assert n >= 1, f"expected ≥1 proposal file checked, got {n}"
    assert "0 violation" in out


def test_4_malformed_front_matter_exits_1(tmp_path):
    p = tmp_path / "evo_2099_001_bad.md"
    p.write_text("(no front matter)\n# body\n", encoding="utf-8")
    rc, out, err = _run("--file", str(p))
    assert rc == 1, err
    assert "front-matter" in out.lower() or "front-matter" in err.lower()


def test_5_accepted_without_accepted_at_exits_1(tmp_path):
    p = tmp_path / "evo_2099_002_bad_accept.md"
    p.write_text(
        _minimal_frontmatter({"state": '"accepted"'}),
        encoding="utf-8",
    )
    rc, out, err = _run("--file", str(p))
    assert rc == 1, err
    assert "accepted_at" in out or "accepted_at" in err


def test_6_file_nonexistent_exits_4(tmp_path):
    p = tmp_path / "no_such_proposal.md"
    rc, out, err = _run("--file", str(p))
    assert rc == 4, err


def test_7_json_format_carries_ledger_shape():
    rc, out, err = _run("--dir", str(PROPOSALS_DIR), "--format", "json")
    assert rc == 0, err
    parsed = json.loads(out)
    assert "ledger" in parsed
    ledger = parsed["ledger"]
    assert ledger["schema_version"] == "1.1.0"
    assert ledger["proposal_count"] >= 1
    assert isinstance(ledger["proposals"], list)
    # Every proposal entry has the 5 ledger-required fields.
    for p in ledger["proposals"]:
        assert {"proposal_id", "proposal_kind", "state", "title", "file_path"} <= p.keys()
