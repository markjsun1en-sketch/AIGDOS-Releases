"""test_seed_proposal_backfill.py — v4.90 Batch 10 Step 10.4.

Contract tests for the Step 10.4 backfill of the evo_2026_001 seed:
the 3 new optional fields introduced by the 1.1.0 minor bump
(Step 10.1).

3 cases:
  1  validation_plan.required contains 'human_review' (correct for
     architecture_principle kind: doctrine is approved by EP review,
     not by automated tests)
  2  change_candidate.affected_dirs is a non-empty unique list whose
     entries all point at existing repo-relative directories
     (ref-integrity)
  3  sandbox_dir == None and proposal_kind == 'architecture_principle'
     (locks in the kind-pattern that principle proposals never need
     a sandbox)

Closes the grandfather window opened by Step 10.3: after this
backfill, validator emits 0 violations AND 0 warnings on the seed.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

from pathlib import Path

# Re-use the parser helper from the sibling Batch 6 module.
from tests.self_evolution.test_seed_proposal import (
    SEED_PATH,
    _parse_proposal,
)

PKG_ROOT = Path(__file__).resolve().parents[2]


# --------------------------------------------------------------------------
# 1. validation_plan.required contains 'human_review'
# --------------------------------------------------------------------------

def test_seed_has_validation_plan_with_human_review():
    fm, _ = _parse_proposal(SEED_PATH)
    assert "validation_plan" in fm, "seed must declare validation_plan after Step 10.4"
    vp = fm["validation_plan"]
    assert isinstance(vp, dict)
    req = vp.get("required")
    assert isinstance(req, list) and len(req) >= 1, (
        "validation_plan.required must be a non-empty list"
    )
    assert "human_review" in req, (
        "architecture_principle proposals must list human_review in required[] "
        "(doctrine is approved by EP review, not by automated checks)"
    )


# --------------------------------------------------------------------------
# 2. change_candidate.affected_dirs ref-integrity
# --------------------------------------------------------------------------

def test_seed_change_candidate_affected_dirs_unique_non_empty():
    fm, _ = _parse_proposal(SEED_PATH)
    cc = fm.get("change_candidate")
    assert isinstance(cc, dict), "seed must declare change_candidate after Step 10.4"
    dirs = cc.get("affected_dirs")
    assert isinstance(dirs, list) and len(dirs) >= 1, (
        "change_candidate.affected_dirs must be a non-empty list"
    )
    # uniqueness
    assert len(set(dirs)) == len(dirs), (
        f"change_candidate.affected_dirs must be unique; got {dirs}"
    )
    # ref-integrity: every path must resolve to an existing directory
    for d in dirs:
        target = PKG_ROOT / d
        assert target.is_dir(), (
            f"affected_dirs entry {d!r} does not point at an existing "
            f"directory (resolved to {target})"
        )


# --------------------------------------------------------------------------
# 3. sandbox_dir is null for architecture_principle kind
# --------------------------------------------------------------------------

def test_seed_sandbox_dir_is_null_for_principle_kind():
    fm, _ = _parse_proposal(SEED_PATH)
    assert fm["proposal_kind"] == "architecture_principle"
    # parse_yaml_text renders `sandbox_dir: null` as Python None.
    # The key MUST be present (explicit null) — not absent.
    assert "sandbox_dir" in fm, (
        "seed must declare sandbox_dir explicitly (even if null); "
        "Step 10.3 enforcement treats null as the principle-kind escape path"
    )
    assert fm["sandbox_dir"] is None, (
        f"architecture_principle seed must have sandbox_dir=None, "
        f"got {fm['sandbox_dir']!r}"
    )
