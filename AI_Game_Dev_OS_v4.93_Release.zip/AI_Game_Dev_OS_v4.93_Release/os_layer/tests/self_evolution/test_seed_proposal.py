"""test_seed_proposal.py — v4.90 Batch 6 Module A.

Contract tests for the seed proposal ``proposals/evo_2026_001_*.md``.

3 cases:
1. Seed file exists and can be parsed into YAML front-matter + body.
2. The parsed front-matter validates against
   schemas/self_evolution/proposal_entry.schema.json.
3. state == 'accepted' AND accepted_at is present (the if/then rule
   in the schema is exercised on a real file, not just a synthetic
   fixture).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SEED_PATH = REPO_ROOT / "proposals" / "evo_2026_001_layer_separation_principle.md"
ENTRY_SCHEMA_PATH = REPO_ROOT / "schemas" / "self_evolution" / "proposal_entry.schema.json"

# Reuse the zero-dep YAML parser that already lives in scripts/governance/.
sys.path.insert(0, str(REPO_ROOT / "scripts" / "governance"))
from _yaml_subset import parse_yaml_text  # noqa: E402


_FRONT_MATTER_RE = re.compile(r"^---\n(.*?)\n---\n", re.DOTALL)


def _parse_proposal(path: Path) -> tuple[dict, str]:
    """Return (front_matter_dict, body_text)."""
    text = path.read_text(encoding="utf-8")
    m = _FRONT_MATTER_RE.match(text)
    assert m, f"front-matter block not found at top of {path}"
    fm = parse_yaml_text(m.group(1))
    body = text[m.end():]
    return fm, body


def test_1_seed_file_exists_and_parses():
    assert SEED_PATH.is_file()
    fm, body = _parse_proposal(SEED_PATH)
    assert fm["proposal_id"] == "evo_2026_001"
    assert fm["proposal_kind"] == "architecture_principle"
    assert fm["title"].startswith("Layer 1 / Layer 2 separation")
    # Body has a non-trivial length — not just front-matter.
    assert len(body.strip()) > 500


def test_2_seed_validates_against_entry_schema():
    fm, _ = _parse_proposal(SEED_PATH)
    schema = json.loads(ENTRY_SCHEMA_PATH.read_text(encoding="utf-8"))
    jsonschema.validate(instance=fm, schema=schema)


def test_3_accepted_seed_has_accepted_at():
    fm, _ = _parse_proposal(SEED_PATH)
    assert fm["state"] == "accepted"
    assert "accepted_at" in fm
    assert "accepted_by" in fm
    # Seed is self-accepted by the OS Core evolution channel.
    assert fm["accepted_by"] == "os_core_evolution"
