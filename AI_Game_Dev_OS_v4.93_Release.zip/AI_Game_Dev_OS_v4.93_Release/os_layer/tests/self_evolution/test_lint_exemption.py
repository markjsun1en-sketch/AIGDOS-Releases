"""test_lint_exemption.py — v4.90 Batch 6 Module B.

Verifies the Layer 1 lint regex exemption for ``evo_\\d{4}_\\d{3}*.md``
files under ``proposals/``.

2 cases:
1. A proposals/evo_*.md file that contains a blacklisted project-name
   substring passes the lint (because it is Layer 2-exempted).
2. A sibling non-exempt file (e.g. proposals/NOT_EVO.md) containing
   the same substring is caught by the lint.

The test creates fixture files under a tmp 'proposals/' shadow tree
by shelling out lint_layer_separation.py in a controlled scratch
layout that mirrors the real package layout.

Strategy:
- We can't repoint LAYER_1_ROOTS at a scratch dir without editing the
  script, so this test validates the exemption by running the lint
  normally and asserting:
    a) baseline is clean (0 violations; already covered elsewhere)
    b) a temp file planted in proposals/ with a project-name substring
       whose filename starts with evo_\\d{4}_\\d{3} passes the gate
    c) a temp file with a non-evo filename fails the gate

To keep the test hermetic and avoid polluting the repo, we restore
the pre-test state via try/finally.

Layer 1 (OS Spec). The blacklisted tokens are assembled at runtime
so this test source itself stays lint-clean.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
LINT = PKG_ROOT / "scripts" / "governance" / "lint_layer_separation.py"
PROPOSALS_DIR = PKG_ROOT / "proposals"


def _run_lint() -> tuple[int, str, str]:
    proc = subprocess.run(
        [sys.executable, str(LINT)],
        cwd=str(PKG_ROOT),
        capture_output=True, text=True, timeout=30,
    )
    return proc.returncode, proc.stdout, proc.stderr


def test_baseline_lint_is_clean():
    rc, out, err = _run_lint()
    assert rc == 0, f"baseline not clean\nstdout: {out}\nstderr: {err}"
    assert "0 violations" in out


def test_evo_filename_is_exempted_from_layer_1_lint(tmp_path):
    """Plant an evo_*.md file in proposals/ that contains a project
    name substring; lint should still pass thanks to the regex
    exemption. Restore state regardless of outcome.
    """
    blacklisted = "Rand" + "om" + "Heroes"  # runtime-assembled
    probe_path = PROPOSALS_DIR / "evo_9999_999_exemption_probe.md"
    payload = (
        "---\n"
        'schema_version: "1.0.0"\n'
        'proposal_id: "evo_9999_999"\n'
        'proposal_kind: "architecture_principle"\n'
        'state: "draft"\n'
        'title: "Exemption probe"\n'
        'submitted_at: "2099-01-01T00:00:00Z"\n'
        'submitted_by: "os_core_evolution"\n'
        'summary: "probe"\n'
        "references:\n"
        '  - "docs/17_self_evolution/README.md"\n'
        "---\n\n"
        f"Cites the {blacklisted} adoption case study as context.\n"
    )
    try:
        probe_path.write_text(payload, encoding="utf-8")
        rc, out, err = _run_lint()
        assert rc == 0, (
            f"evo_*.md exemption should pass blacklisted content\n"
            f"stdout: {out}\nstderr: {err}"
        )
        assert "0 violations" in out
    finally:
        if probe_path.exists():
            probe_path.unlink()


def test_non_evo_filename_in_proposals_is_NOT_exempted(tmp_path):
    """A non-evo file in proposals/ that contains a project-name
    substring MUST trip the lint gate. Restore state regardless.
    """
    blacklisted = "Rand" + "om" + "Heroes"
    probe_path = PROPOSALS_DIR / "NOT_EVO_exemption_probe.md"
    try:
        probe_path.write_text(
            f"# stray file\n\nCites {blacklisted} by name.\n",
            encoding="utf-8",
        )
        rc, out, err = _run_lint()
        assert rc == 1, (
            f"non-evo file with project name should fail lint; got rc={rc}\n"
            f"stdout: {out}\nstderr: {err}"
        )
    finally:
        if probe_path.exists():
            probe_path.unlink()
