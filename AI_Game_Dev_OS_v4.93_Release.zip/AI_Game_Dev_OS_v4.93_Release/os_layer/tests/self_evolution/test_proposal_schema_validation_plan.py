"""test_proposal_schema_validation_plan.py — v4.90 Batch 10 Step 10.1.

Tests for the new fields added by the 1.0.0 -> 1.1.0 minor bump:
  - validation_plan (object with required[] enum + optional[] enum + notes)
  - change_candidate (object with affected_dirs[])
  - sandbox_dir (nullable, pattern '^evolution/sandbox/.+')

Schema-level only — the conditional enforcement (validation_plan
required when state==accepted; sandbox_dir required when
state==implementing) lives in scripts/self_evolution/validate_proposal.py
and is covered by Step 10.3's test additions.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = REPO_ROOT / "schemas" / "self_evolution" / "proposal_entry.schema.json"


def _load_schema() -> dict:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def _minimal_accepted_entry() -> dict:
    """Minimal complete entry that exercises the accepted-state allOf branch."""
    return {
        "schema_version": "1.1.0",
        "proposal_id": "evo_2099_999",
        "proposal_kind": "architecture_principle",
        "state": "accepted",
        "title": "Test proposal",
        "submitted_at": "2026-05-13T10:00:00Z",
        "submitted_by": "test_actor",
        "summary": "Synthetic test proposal.",
        "references": ["docs/test.md"],
        "accepted_at": "2026-05-13T10:30:00Z",
        "accepted_by": "test_reviewer",
    }


# --------------------------------------------------------------------------
# 1. schema_version was bumped to 1.1.0
# --------------------------------------------------------------------------

def test_schema_version_bumped_to_1_1_0_beta():
    schema = _load_schema()
    assert schema["properties"]["schema_version"]["const"] == "1.1.0"


# --------------------------------------------------------------------------
# 2. validation_plan with required[]=[pytest] validates
# --------------------------------------------------------------------------

def test_validation_plan_required_pytest_validates():
    schema = _load_schema()
    instance = _minimal_accepted_entry()
    instance["validation_plan"] = {"required": ["pytest"]}
    jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 3. validation_plan.required must be non-empty (minItems=1)
# --------------------------------------------------------------------------

def test_validation_plan_empty_required_rejected():
    schema = _load_schema()
    instance = _minimal_accepted_entry()
    instance["validation_plan"] = {"required": []}
    with pytest.raises(jsonschema.exceptions.ValidationError):
        jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 4. validation_plan.required values must be from the 5-enum
# --------------------------------------------------------------------------

def test_validation_plan_unknown_check_rejected():
    schema = _load_schema()
    instance = _minimal_accepted_entry()
    instance["validation_plan"] = {"required": ["totally_invented_check"]}
    with pytest.raises(jsonschema.exceptions.ValidationError):
        jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 5. validation_plan accepts all 5 enum values together
# --------------------------------------------------------------------------

def test_validation_plan_accepts_all_five_checks():
    schema = _load_schema()
    instance = _minimal_accepted_entry()
    instance["validation_plan"] = {
        "required": ["pytest", "smoke", "manifest_check", "migration_replay", "human_review"],
        "optional": ["pytest"],
        "notes": "Testing the full check matrix.",
    }
    jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 6. change_candidate.affected_dirs accepts a list of strings
# --------------------------------------------------------------------------

def test_change_candidate_affected_dirs_validates():
    schema = _load_schema()
    instance = _minimal_accepted_entry()
    instance["change_candidate"] = {
        "affected_dirs": ["docs/13_migration", "scripts/migration"],
    }
    jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 7. sandbox_dir pattern: must start with evolution/sandbox/
# --------------------------------------------------------------------------

def test_sandbox_dir_pattern_enforced():
    schema = _load_schema()
    instance = _minimal_accepted_entry()
    instance["sandbox_dir"] = "/tmp/my_experiment"  # bad prefix
    with pytest.raises(jsonschema.exceptions.ValidationError):
        jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 8. sandbox_dir == null is allowed (proposals that need no sandbox)
# --------------------------------------------------------------------------

def test_sandbox_dir_null_allowed():
    schema = _load_schema()
    instance = _minimal_accepted_entry()
    instance["sandbox_dir"] = None
    jsonschema.validate(instance=instance, schema=schema)
