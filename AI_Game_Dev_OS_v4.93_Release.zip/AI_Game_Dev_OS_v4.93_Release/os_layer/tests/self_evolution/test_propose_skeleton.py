"""test_propose_skeleton.py — v4.90 Batch 13 Step 13.4.d.

Tests for `scripts/self_evolution/propose_skeleton.py` — the plan §9
字面 `evolve propose` skeleton generator.

Per EP D-13.4.d decisions (all A):
- D-13.4.d.1 = A — NNN auto: max+1 within year (per-year reset)
- D-13.4.d.2 = A — initial state always 'draft'
- D-13.4.d.3 = A — slug strict lower snake_case ^[a-z][a-z0-9_]*$
- D-13.4.d.4 = A — target-exists -> exit 1 INPUT_ERROR (no --force)

4 tests:
1. _next_seq picks max+1 within year (+ empty year + cross-year isolation)
2. propose writes 9 required schema fields + 5 H2 sections
3. invalid slug forms -> EXIT_INPUT_ERROR (3 sub-cases)
4. target-exists -> EXIT_INPUT_ERROR (no overwrite)

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from scripts.self_evolution import propose_skeleton as ps


def _make_evo(dir_path: Path, year: int, seq: int, slug: str = "sample") -> Path:
    """Drop a stub evo file matching the canonical filename shape."""
    name = f"evo_{year:04d}_{seq:03d}_{slug}.md"
    p = dir_path / name
    p.write_text("---\nstub\n---\n", encoding="utf-8")
    return p


# --- Test 1: _next_seq picks max+1 within year ------------------------------

def test_next_seq_picks_max_plus_1_within_year(tmp_path):
    # Empty directory → seq 1 for any year.
    assert ps._next_seq(tmp_path, 2026) == 1
    assert ps._next_seq(tmp_path, 2099) == 1

    # Three entries in 2026: max NNN = 005 -> next = 6.
    _make_evo(tmp_path, 2026, 1)
    _make_evo(tmp_path, 2026, 3)
    _make_evo(tmp_path, 2026, 5)
    assert ps._next_seq(tmp_path, 2026) == 6, (
        f"expected 6 (max 005 + 1); got {ps._next_seq(tmp_path, 2026)}"
    )

    # Cross-year isolation: 2025 entries do not bump 2026 seq, and
    # 2026 entries do not bump a fresh-year (2099) seq.
    _make_evo(tmp_path, 2025, 9)
    assert ps._next_seq(tmp_path, 2026) == 6, (
        "2025 entries must not influence 2026 seq calculation"
    )
    assert ps._next_seq(tmp_path, 2099) == 1, (
        "fresh year (2099) must start at seq 1 regardless of other years"
    )
    assert ps._next_seq(tmp_path, 2025) == 10, (
        "2025 has only NNN=9 so next is 10"
    )

    # Stray non-canonical files must be ignored.
    (tmp_path / "evo_bogus.md").write_text("", encoding="utf-8")
    (tmp_path / "README.md").write_text("", encoding="utf-8")
    assert ps._next_seq(tmp_path, 2026) == 6, (
        "non-matching filenames must not poison seq calculation"
    )


# --- Test 2: propose writes 9 required fields + 5 H2 sections ---------------

def test_propose_writes_full_skeleton_with_required_fields(tmp_path):
    code, message, target_path = ps.propose(
        title="Sample Proposal Title",
        kind="architecture_principle",
        slug="sample_proposal_x",
        proposals_dir=tmp_path,
    )
    assert code == ps.EXIT_OK, (
        f"propose returned {code}: {message!r}"
    )
    assert target_path is not None
    assert target_path.is_file()
    # Filename shape: evo_2026_001_sample_proposal_x.md (year is current,
    # seq is 1 since tmp_path is empty).
    assert target_path.name.startswith("evo_") and target_path.name.endswith(
        "_sample_proposal_x.md"
    )

    text = target_path.read_text(encoding="utf-8")

    # All 9 required front-matter fields present.
    required_field_names = [
        "schema_version:",
        "proposal_id:",
        "proposal_kind:",
        "state:",
        "title:",
        "submitted_at:",
        "submitted_by:",
        "summary:",
        "references:",
    ]
    for field in required_field_names:
        assert field in text, (
            f"required field {field!r} missing from skeleton"
        )

    # schema_version must be 1.1.0; state must be 'draft'; kind matches input.
    assert 'schema_version: "1.1.0"' in text
    assert 'state: "draft"' in text
    assert 'proposal_kind: "architecture_principle"' in text
    assert 'title: "Sample Proposal Title"' in text

    # All 5 body H2 sections present.
    for section in (
        "## Background",
        "## Motivation",
        "## Proposed change",
        "## Validation plan",
        "## Risks & alternatives",
    ):
        assert section in text, f"body H2 section {section!r} missing"

    # H1 with proposal_id + title.
    assert text.count("# evo_") >= 1, (
        "H1 line referencing proposal_id missing"
    )


# --- Test 3: invalid slug forms ---------------------------------------------

def test_propose_invalid_slug_returns_input_error(tmp_path):
    # Sub-case A: uppercase / dash.
    code_a, msg_a, path_a = ps.propose(
        title="t", kind="architecture_principle",
        slug="Bad-Slug-Caps", proposals_dir=tmp_path,
    )
    assert code_a == ps.EXIT_INPUT_ERROR, (
        f"uppercase+dash slug must return INPUT_ERROR; got {code_a}"
    )
    assert path_a is None
    assert "slug" in msg_a.lower()

    # Sub-case B: starts with underscore.
    code_b, _msg_b, _ = ps.propose(
        title="t", kind="architecture_principle",
        slug="_starts_underscore", proposals_dir=tmp_path,
    )
    assert code_b == ps.EXIT_INPUT_ERROR

    # Sub-case C: empty / whitespace.
    code_c, _msg_c, _ = ps.propose(
        title="t", kind="architecture_principle",
        slug="", proposals_dir=tmp_path,
    )
    assert code_c == ps.EXIT_INPUT_ERROR

    # Sub-case D: digit start.
    code_d, _msg_d, _ = ps.propose(
        title="t", kind="architecture_principle",
        slug="9_starts_with_digit", proposals_dir=tmp_path,
    )
    assert code_d == ps.EXIT_INPUT_ERROR

    # Sanity: no file was written for any of the 4 sub-cases.
    assert list(tmp_path.glob("evo_*.md")) == [], (
        "no skeleton should be written when slug fails validation"
    )


# --- Test 4: target-exists -> EXIT_INPUT_ERROR (no overwrite) ---------------

def test_propose_overwrite_refused(tmp_path, monkeypatch):
    # First call: succeeds.
    code1, _msg1, path1 = ps.propose(
        title="First", kind="architecture_principle",
        slug="abc_xyz", proposals_dir=tmp_path,
    )
    assert code1 == ps.EXIT_OK
    assert path1 is not None and path1.is_file()
    original_bytes = path1.read_bytes()

    # Second call same slug+kind: seq auto-bumps so the new file gets
    # a different name; the original file MUST remain untouched.
    code2, _msg2, path2 = ps.propose(
        title="Second", kind="architecture_principle",
        slug="abc_xyz", proposals_dir=tmp_path,
    )
    assert code2 == ps.EXIT_OK, (
        f"second propose with same slug should auto-bump NNN; got {code2}"
    )
    assert path2 is not None and path2 != path1
    assert path1.read_bytes() == original_bytes, (
        "original skeleton must be byte-preserved when seq auto-bumps"
    )

    # Pre-create the EXACT target filename that propose would compute.
    # propose's own _next_seq advances past existing files, so naturally
    # it would never overwrite. To exercise the D-13.4.d.4=A guard we
    # monkeypatch _next_seq to return a fixed value AND pre-create the
    # corresponding target file at that seq.
    year_str = path1.name[4:8]
    fixed_seq = 999
    collision = tmp_path / f"evo_{year_str}_{fixed_seq:03d}_collision_slug.md"
    collision.write_text("pre-existing\n", encoding="utf-8")

    monkeypatch.setattr(ps, "_next_seq", lambda _dir, _year: fixed_seq)

    code3, msg3, path3 = ps.propose(
        title="Collides", kind="architecture_principle",
        slug="collision_slug", proposals_dir=tmp_path,
    )
    assert code3 == ps.EXIT_INPUT_ERROR, (
        f"propose must refuse to overwrite an existing target file "
        f"(D-13.4.d.4=A); got {code3}"
    )
    assert path3 is None
    assert "already exists" in msg3.lower() or "overwrite" in msg3.lower()
    # Sanity: collision file is still untouched (no overwrite).
    assert collision.read_text(encoding="utf-8") == "pre-existing\n"


# Net additions: 4 distinct test functions per §8 trajectory (+4).
# Pre-13.4.d baseline 831 (after 13.4.c). After 13.4.d: 835 expected.
