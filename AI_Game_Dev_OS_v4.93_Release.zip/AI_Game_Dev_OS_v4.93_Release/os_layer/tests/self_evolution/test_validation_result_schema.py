"""validation_result schema — v4.90 Batch 12 Step 12.4 (GAP #3).

Covers:
  1. Schema declares `const: "1.0.0"` + the right required fields.
  2. `validate_proposal --format validation-result` happy path: a
     clean proposal emits overall_status=passed.
  3. Same flag, failure path: a proposal with violations emits
     overall_status=failed + a notes string.
  4. The emitted JSON conforms to the schema (deep validation via
     jsonschema if installed).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = (
    PKG_ROOT
    / "schemas"
    / "self_evolution"
    / "validation_result.schema.json"
)
SCRIPT = PKG_ROOT / "scripts" / "self_evolution" / "validate_proposal.py"
SEED_PROPOSAL = (
    PKG_ROOT / "proposals" / "evo_2026_001_layer_separation_principle.md"
)


def _run(*args, cwd: Path | None = None):
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True, text=True, timeout=20,
        cwd=cwd,
    )
    return proc.returncode, proc.stdout, proc.stderr


# --------------------------------------------------------------------------
# 1. Schema shape sentinel
# --------------------------------------------------------------------------

def test_schema_const_and_required_fields():
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    assert schema["properties"]["schema_version"]["const"] == "1.0.0"
    assert set(schema["required"]) == {
        "schema_version",
        "proposal_id",
        "ran_at",
        "overall_status",
        "checks",
    }
    statuses = schema["properties"]["overall_status"]["enum"]
    assert set(statuses) == {"passed", "failed", "partial"}


# --------------------------------------------------------------------------
# 2. validate_proposal --format validation-result happy path
# --------------------------------------------------------------------------

def test_validation_result_happy_path():
    rc, out, err = _run("--file", str(SEED_PROPOSAL),
                        "--format", "validation-result")
    assert rc == 0, err
    doc = json.loads(out)
    assert doc["schema_version"] == "1.0.0"
    assert doc["proposal_id"] == "evo_2026_001"
    assert doc["overall_status"] == "passed"
    assert doc["checks"][0]["status"] == "passed"
    assert re.match(
        r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$",
        doc["ran_at"],
    )


# --------------------------------------------------------------------------
# 3. validate_proposal --format validation-result failure path
# --------------------------------------------------------------------------

def test_validation_result_failure_path(tmp_path: Path):
    """Synthesise a malformed proposal and run validation-result."""
    bad = tmp_path / "evo_2099_999_broken.md"
    bad.write_text(
        "---\n"
        "schema_version: \"1.1.0\"\n"
        "proposal_id: \"evo_2099_999\"\n"
        "proposal_kind: \"BOGUS_KIND\"\n"  # not in enum -> violation
        "state: \"draft\"\n"
        "title: \"broken\"\n"
        "submitted_at: \"2026-05-14T00:00:00Z\"\n"
        "submitted_by: \"test\"\n"
        "summary: \"intentionally broken\"\n"
        "references: []\n"
        "---\n# body\n",
        encoding="utf-8",
    )
    rc, out, err = _run("--file", str(bad), "--format", "validation-result")
    # exit code reflects the underlying violation total
    assert rc == 1, err
    doc = json.loads(out)
    assert doc["overall_status"] == "failed"
    assert doc["checks"][0]["status"] == "failed"
    assert doc["checks"][0]["notes"]  # non-null/non-empty


# --------------------------------------------------------------------------
# 4. Emitted JSON conforms to the schema (jsonschema deep validate)
# --------------------------------------------------------------------------

def test_emitted_json_conforms_to_schema():
    jsonschema = pytest.importorskip("jsonschema")
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    rc, out, err = _run("--file", str(SEED_PROPOSAL),
                        "--format", "validation-result")
    assert rc == 0, err
    doc = json.loads(out)
    jsonschema.validate(instance=doc, schema=schema)
