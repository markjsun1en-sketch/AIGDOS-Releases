"""Tests for A3 git_adapter_stub source_layer annotation."""
from __future__ import annotations

from integrations.git_adapter_stub import (
    merge_apply,
    merge_cleanup,
    normalize_event,
)


def test_normalize_event_stamps_source_layer():
    recs = normalize_event({"external_id": "pr-42", "event": "pr_merged"})
    assert recs and recs[0].get("source_layer") == "git"


def test_merge_apply_carries_source_layer():
    recs = merge_apply({"external_id": "pr-43", "branch": "feature/x"})
    assert recs and recs[0].get("source_layer") == "git"
    assert recs[0].get("event") == "merge.apply"


def test_merge_cleanup_carries_source_layer():
    recs = merge_cleanup({"external_id": "pr-44"})
    assert recs and recs[0].get("source_layer") == "git"
    assert recs[0].get("event") == "merge.cleanup"
