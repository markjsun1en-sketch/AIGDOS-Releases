"""Tests for M7.3.2a — _stub_init canonically writes contract surface.

Phase 4 Step 1 / M7.3 Lift gate / commit 3 (M7.3.2b) of 7-commit chain.

Verifies the producer side of the lifted gate:
- _CONTRACT_SURFACE_FIELDS is the locked 4-field set (Q1=A)
- _stub_init writes all 4 fields for every _VALID_PROFILES entry from
  the authoritative profile JSON ground truth
- workbuddy_private also gets written (Q4=A — uniform producer path)
- config_data override beats profile JSON ground truth (supports
  negative-mirror fixture injection)
- Missing / unreadable profile JSON degrades gracefully (no raise,
  0 contract fields written; M7.3.3 ERROR path will surface it)

The consumer side (ERROR on missing field) is tested by M7.3.3
changes to ``runtime/schema_driven_check.py``.

Ref: docs/06_runtime_profiles/PHASE_4_LIFT_GATE_AUDIT.md §2 §5
Ref: V4_89_PHASE_4_PLAN.md §二 M7.3.2
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import pytest

from init_runtime_env import (
    _CONTRACT_SURFACE_FIELDS,
    _load_profile_ground_truth,
    _stub_init,
)


_PKG_ROOT = Path(__file__).resolve().parents[1]
_PROFILES_DIR = _PKG_ROOT / "config" / "profiles"


# Expected ground-truth values for the 4 cross-checked profiles plus
# workbuddy_private (Q4=A write-but-not-check).  Hard-coded here so a
# silent edit to the authoritative profile JSONs surfaces as a red
# test, not as a silent drift of the contract.
_EXPECTED_CONTRACT_SURFACE: dict[str, dict[str, str]] = {
    "codex": {
        "coordination_model": "parent_subagents",
        "writeback_owner": "parent",
        "audit_collector": "codex_collector",
        "context_loading_method": "project_docs_plus_selected_files",
    },
    "cursor": {
        "coordination_model": "parallel_agents",
        "writeback_owner": "reviewed_apply_owner",
        "audit_collector": "cursor_collector",
        "context_loading_method": "rules_plus_worktree_context",
    },
    "claude_code_agent_teams": {
        "coordination_model": "lead_teammates",
        "writeback_owner": "lead",
        "audit_collector": "claude_teams_collector",
        "context_loading_method": "lead_team_task_context",
    },
    "claude_code_subagents": {
        "coordination_model": "parent_subagents",
        "writeback_owner": "parent",
        "audit_collector": "claude_subagents_collector",
        "context_loading_method": "claude_docs_plus_hooks",
    },
    "workbuddy_private": {
        "coordination_model": "private_coordinated",
        "writeback_owner": "main_session",
        "audit_collector": "workbuddy_collector",
        "context_loading_method": "project_defined",
    },
}


def _make_args(profile: str | None, project_id: str = "pytest") -> argparse.Namespace:
    return argparse.Namespace(
        project_id=project_id,
        runtime_profile=profile,
        with_demo=False,
    )


# ---------------------------------------------------------------------------
# M7.3.2b.1 — Contract surface constant is exactly the locked 4-field set
# ---------------------------------------------------------------------------


def test_contract_surface_is_locked_4_field_set():
    """Q1=A — guard against silent widening / narrowing of the surface.

    If this test fails, M7.3 scope has changed.  That is a design
    decision, not a test-fixture fix — update PHASE_4_LIFT_GATE_AUDIT
    §2, the 8 (profile, field) pairs table, and the expected matrix
    first, then update this test.
    """
    assert _CONTRACT_SURFACE_FIELDS == (
        "coordination_model",
        "writeback_owner",
        "audit_collector",
        "context_loading_method",
    )


# ---------------------------------------------------------------------------
# M7.3.2b.2 — Per-profile canonical write (4 cross-checked profiles + wb_private)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "profile",
    list(_EXPECTED_CONTRACT_SURFACE.keys()),
)
def test_stub_init_writes_contract_surface_for_profile(profile: str):
    """Q1=A + Q4=A — every _VALID_PROFILES entry gets the full 4-field
    canonical write, matching the authoritative profile JSON."""
    state = _stub_init(_make_args(profile), {})
    expected = _EXPECTED_CONTRACT_SURFACE[profile]
    for field in _CONTRACT_SURFACE_FIELDS:
        assert field in state, (
            f"profile={profile!r}: contract field {field!r} absent from "
            f"_stub_init output — M7.3.2a regression"
        )
        assert state[field] == expected[field], (
            f"profile={profile!r} field={field!r}: "
            f"expected {expected[field]!r}, got {state[field]!r}"
        )


# ---------------------------------------------------------------------------
# M7.3.2b.3 — config_data override wins (supports negative-mirror fixtures)
# ---------------------------------------------------------------------------


def test_config_data_override_wins_over_profile_ground_truth():
    """Mirror_trial_workspace + test_init can inject deliberate drift
    values for negative-mirror scenarios.  M7.3.2a precedence order:
    config_data > profile JSON > absent."""
    args = _make_args("codex")
    drifted = {
        "coordination_model": "DRIFTED_VALUE",
        "writeback_owner": "DRIFTED_OWNER",
        "audit_collector": "legacy_collector",
        "context_loading_method": "rules_plus_worktree_context",  # cursor's value
    }
    state = _stub_init(args, drifted)
    for field, value in drifted.items():
        assert state[field] == value, (
            f"config_data override for {field!r} lost: "
            f"expected {value!r}, got {state[field]!r}"
        )
    # Sanity: the authoritative ground-truth values are NOT in state
    # (they were displaced by the override).
    codex_truth = _EXPECTED_CONTRACT_SURFACE["codex"]
    for field, truth_value in codex_truth.items():
        assert state[field] != truth_value, (
            f"override did not displace ground truth for {field!r}"
        )


# ---------------------------------------------------------------------------
# M7.3.2b.4 — Degraded profile JSON does not raise; contract fields absent
# ---------------------------------------------------------------------------


def test_unknown_profile_leaves_contract_fields_absent():
    """R3 mitigation — _stub_init must not raise on bogus profile; it
    should emit a runtime_state that is structurally valid but missing
    the contract surface, so M7.3.3 cross-check can emit ERROR."""
    state = _stub_init(_make_args("no_such_profile"), {})
    # Core state invariants still hold
    assert state["project_id"] == "pytest"
    assert state["runtime_profile"] == "no_such_profile"
    assert state["profile"] == "no_such_profile"
    # Contract fields are absent (no ground truth to read, no override)
    for field in _CONTRACT_SURFACE_FIELDS:
        assert field not in state, (
            f"{field!r} should be absent for unknown profile, "
            f"got {state[field]!r}"
        )


def test_none_profile_leaves_contract_fields_absent():
    """Defense against callers that pass --runtime-profile=None (e.g.
    dry-run config-data-only invocations).  _load_profile_ground_truth
    short-circuits to None, contract fields are not written."""
    state = _stub_init(_make_args(None), {})
    for field in _CONTRACT_SURFACE_FIELDS:
        assert field not in state, (
            f"{field!r} should be absent for profile=None, "
            f"got {state[field]!r}"
        )


def test_missing_profile_json_on_disk_does_not_raise(tmp_path, monkeypatch):
    """R3 mitigation — if the profile JSON is physically absent from
    config/profiles/, _load_profile_ground_truth falls back to None
    via FileNotFoundError handling.  _stub_init still produces a
    state."""
    pkg_profile = _PROFILES_DIR / "codex.json"
    backup = pkg_profile.with_suffix(".json.m7_3_2b_test_backup")
    os.rename(str(pkg_profile), str(backup))
    try:
        state = _stub_init(_make_args("codex"), {})
        # Core fields still there
        assert state["runtime_profile"] == "codex"
        # Contract fields absent because ground truth unreadable
        for field in _CONTRACT_SURFACE_FIELDS:
            assert field not in state, (
                f"{field!r} should be absent when profile JSON missing, "
                f"got {state[field]!r}"
            )
    finally:
        os.rename(str(backup), str(pkg_profile))


def test_malformed_profile_json_does_not_raise(tmp_path, monkeypatch):
    """R3 mitigation — if the profile JSON is corrupted,
    _load_profile_ground_truth swallows JSONDecodeError and returns
    None.  _stub_init still produces a state."""
    pkg_profile = _PROFILES_DIR / "cursor.json"
    backup = pkg_profile.with_suffix(".json.m7_3_2b_test_backup")
    original = pkg_profile.read_text(encoding="utf-8")
    os.rename(str(pkg_profile), str(backup))
    try:
        pkg_profile.write_text("{ this is not json", encoding="utf-8")
        state = _stub_init(_make_args("cursor"), {})
        assert state["runtime_profile"] == "cursor"
        for field in _CONTRACT_SURFACE_FIELDS:
            assert field not in state, (
                f"{field!r} should be absent for malformed JSON, "
                f"got {state[field]!r}"
            )
    finally:
        pkg_profile.unlink(missing_ok=True)
        os.rename(str(backup), str(pkg_profile))
        # Sanity: original content restored
        assert pkg_profile.read_text(encoding="utf-8") == original


# ---------------------------------------------------------------------------
# M7.3.2b.5 — _load_profile_ground_truth unit surface
# ---------------------------------------------------------------------------


def test_load_profile_ground_truth_returns_dict_for_known_profile():
    gt = _load_profile_ground_truth("codex")
    assert gt is not None
    # Must carry the full contract surface as primitive strings
    for field in _CONTRACT_SURFACE_FIELDS:
        assert field in gt
        assert isinstance(gt[field], str)


def test_load_profile_ground_truth_returns_none_for_missing_profile():
    assert _load_profile_ground_truth("nonexistent_profile") is None


def test_load_profile_ground_truth_returns_none_for_empty_arg():
    # Q1/Q2 boundary — None / empty-string short-circuits
    assert _load_profile_ground_truth(None) is None
    assert _load_profile_ground_truth("") is None


# ---------------------------------------------------------------------------
# M9.0.6 (Phase 4 Step 3, Q6=B) — _stub_init writes sprint_window_state
# from each profile JSON's sprint_cold_start block, additive to the M7.3
# contract surface and NOT joining _CONTRACT_SURFACE_FIELDS (cross-check
# coverage deferred to M9.1).
# ---------------------------------------------------------------------------


from init_runtime_env import (  # noqa: E402
    _SPRINT_COLD_START_KEY,
    _SPRINT_DEFAULT_MODE,
    _SPRINT_WINDOW_STATE_FIELD,
)

_ALL_VALID_PROFILES = (
    "codex",
    "cursor",
    "claude_code_agent_teams",
    "claude_code_subagents",
    "workbuddy_private",
    "default_beta_codex_tapd_git",
)


@pytest.mark.parametrize("profile", _ALL_VALID_PROFILES)
def test_stub_init_writes_sprint_window_state(profile: str):
    """Each of the 6 valid profiles produces a top-level
    ``sprint_window_state`` dict whose ``cold_start_mode`` matches the
    profile JSON's ``sprint_cold_start.mode`` declaration (M9.0.3).
    """
    args = _make_args(profile)
    state = _stub_init(args, config_data={})
    assert _SPRINT_WINDOW_STATE_FIELD in state
    sw = state[_SPRINT_WINDOW_STATE_FIELD]
    assert isinstance(sw, dict)
    assert sw["profile"] == profile

    # Cross-check against the on-disk profile JSON's sprint_cold_start block.
    raw = json.loads((_PROFILES_DIR / f"{profile}.json").read_text(encoding="utf-8"))
    declared_mode = raw.get(_SPRINT_COLD_START_KEY, {}).get("mode") or _SPRINT_DEFAULT_MODE
    assert sw["cold_start_mode"] == declared_mode
    assert sw["sprint_id"] is None
    assert sw["manifest_ref"] == "runtime/config/context_profiles_manifest.json"


def test_stub_init_sprint_window_state_not_in_contract_surface():
    """Q6=B explicit boundary — sprint_window_state is additive and is
    NOT part of _CONTRACT_SURFACE_FIELDS.  Cross-check coverage is
    intentionally deferred to M9.1.  If this test fails, the lift gate
    scope has changed and M9.0 plan §6 R4 needs revisiting.
    """
    assert _SPRINT_WINDOW_STATE_FIELD not in _CONTRACT_SURFACE_FIELDS


def test_stub_init_sprint_window_state_config_override_wins():
    """Caller-supplied sprint_window_state in config_data takes
    precedence over the profile JSON's declaration (mirrors the
    M7.3.2 contract surface override semantics — supports test-
    fixture injection of sprint context).
    """
    override = {
        "profile": "codex",
        "cold_start_mode": "SPRINT_DEEP",
        "manifest_ref": "fixture/manifest.json",
        "sprint_id": "SPRINT-99",
    }
    args = _make_args("codex")
    state = _stub_init(args, config_data={_SPRINT_WINDOW_STATE_FIELD: override})
    assert state[_SPRINT_WINDOW_STATE_FIELD] == override


def test_stub_init_sprint_window_state_falls_back_when_profile_missing(tmp_path, monkeypatch):
    """When the profile JSON cannot be loaded, sprint_window_state still
    materialises with the default mode and a null sprint_id — never
    raises (mirrors the contract-surface graceful-degradation contract).
    """
    monkeypatch.chdir(tmp_path)
    args = _make_args("nonexistent_profile_for_m906")
    state = _stub_init(args, config_data={})
    sw = state[_SPRINT_WINDOW_STATE_FIELD]
    assert sw["profile"] == "nonexistent_profile_for_m906"
    assert sw["cold_start_mode"] == _SPRINT_DEFAULT_MODE
    assert sw["sprint_id"] is None
    assert sw["manifest_ref"] is None


def test_stub_init_sprint_window_state_handles_none_profile():
    """When --runtime-profile is omitted entirely, sprint_window_state
    is still written: profile=None, cold_start_mode defaults,
    sprint_id=None.  This keeps boot_agent_thread.py able to read
    state even on degraded init.
    """
    args = _make_args(None)
    state = _stub_init(args, config_data={})
    sw = state[_SPRINT_WINDOW_STATE_FIELD]
    assert sw["profile"] is None
    assert sw["cold_start_mode"] == _SPRINT_DEFAULT_MODE
    assert sw["sprint_id"] is None


def test_stub_init_sprint_window_state_independent_of_contract_surface():
    """Even with config_data overriding the contract surface fields,
    sprint_window_state is written from a separate code path and not
    affected by contract-surface override.
    """
    args = _make_args("codex")
    config_data = {
        "coordination_model": "drift_value",
        "writeback_owner": "drift_value",
    }
    state = _stub_init(args, config_data=config_data)
    # Contract surface override took effect.
    assert state["coordination_model"] == "drift_value"
    # Sprint window state still came from the profile JSON declaration.
    assert state[_SPRINT_WINDOW_STATE_FIELD]["cold_start_mode"] == "SPRINT_GOVERNED"
    assert state[_SPRINT_WINDOW_STATE_FIELD]["profile"] == "codex"
