from pathlib import Path


OS_LAYER = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = OS_LAYER.parent


def test_os_layer_readme_declares_v493_embedding_boundary():
    readme = (OS_LAYER / "README.md").read_text(encoding="utf-8")

    assert "v4.93 embedding note" in readme
    assert "this directory is" in readme
    assert "the `os_layer/` baseline and promoted OS-layer surface" in readme
    assert "It is not the full" in readme
    assert "v4.93 entrypoint" in readme
    assert "external onboarding should start at the repository root" in readme
    assert "v4.93 onboarding, evaluation, and trial runs enter through the repository" in readme
    assert "../README.md" in readme
    assert "../INDEX.md" in readme
    assert "../MANIFEST.json" in readme
    assert "../OS_PACK_LAYER_MAP.md" in readme


def test_root_manifest_excludes_workspace_meta_from_runtime_payload():
    manifest = (PACKAGE_ROOT / "MANIFEST.json").read_text(encoding="utf-8")

    assert '"inside_version_package": false' in manifest
    assert '"include_workspace_meta_by_default": false' in manifest
    assert '"runtime_must_not_depend_on_workspace_meta": true' in manifest


def test_os_layer_release_history_is_marked_as_baseline_provenance():
    for doc_name in [
        "CHANGELOG.md",
        "RELEASE_NOTES.md",
        "RELEASE_NOTES_v4.90-rc3.md",
    ]:
        text = (OS_LAYER / doc_name).read_text(encoding="utf-8")
        assert "v4.93 embedding note" in text
        assert "historical OS baseline provenance" in text
        assert "not a v4.93 entrypoint" in text
