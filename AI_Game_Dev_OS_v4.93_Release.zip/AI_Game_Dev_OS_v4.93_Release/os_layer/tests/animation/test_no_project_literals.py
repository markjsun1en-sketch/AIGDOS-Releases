"""tests/animation/test_no_project_literals.py — v4.91 M-G c4.

Charter #2 enforcement at the test layer. Verify no project-specific
character / project literals leaked into canonical pack surfaces during
c2/c3 migration.

Allowed grep hits (intentional, documented):
- docs/28_2d_character_animation/CROSS_PROJECT_PROMOTION_LESSONS.md
  (methodology document explains the sanitisation pattern; literal
  appears as meta-reference, not project usage)
- scripts/animation/validate_skill_pack.py (forbidden_tokens guardrail
  list — the validator looks for literals to reject them)

Per evo_2026_001 §Authoring discipline: forbidden token strings are
assembled at runtime so this source file itself stays Layer 1 lint
clean (same pattern as scripts/migration/scan_legacy_project.py).
"""
from __future__ import annotations

import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]

# Surfaces that MUST stay literal-free.
SCAN_PATHS = [
    "skills/_generic_core/animation",
    "skills/_generic_core/qa/animation-qa-auditor",
    "skills/_engine_specific/godot/godot-2d-animation-implementer",
    "schemas/animation",
    "agent_packs/ap_2026_006_creative_cluster.md",
    "proposals/evo_2026_002_creative_cluster_role_aliasing.md",
    "docs/28_2d_character_animation/references",
    "docs/28_2d_character_animation/templates",
    "docs/28_2d_character_animation/examples",
    "docs/28_2d_character_animation/contracts",
    "docs/28_2d_character_animation/README.md",
    "docs/28_2d_character_animation/AGENT_PACK_OVERVIEW.md",
    "docs/28_2d_character_animation/AI_LIMITATIONS_AND_HUMAN_GATE.md",
    "docs/28_2d_character_animation/provenance.yaml",
]

# Documented exceptions — meta-references / guardrails.
ALLOWED_EXCEPTIONS = {
    "docs/28_2d_character_animation/CROSS_PROJECT_PROMOTION_LESSONS.md",
    "scripts/animation/validate_skill_pack.py",
    "tests/animation/test_no_project_literals.py",  # this file
    "tests/animation/test_pack_ledger_consistency.py",  # has FORBIDDEN_TOKENS list
    "tests/animation/test_no_auto_rig_promise.py",
}

# Forbidden tokens assembled at runtime so this source file stays
# Layer 1 lint-clean (per evo_2026_001 §Authoring discipline; mirrors
# scripts/migration/scan_legacy_project.py _sanitize pattern).
_TOK_LOWER = "chi" + "ren"
_TOK_PASCAL = "Chi" + "ren"
_TOK_PROJECT = "lessis" + "more"
FORBIDDEN_TOKENS = [
    r"\b" + _TOK_LOWER + r"\b",
    r"\b" + _TOK_PASCAL + r"\b",
    r"\b" + _TOK_PROJECT + r"\b",
]


def _iter_files_under(rel: str):
    p = REPO_ROOT / rel
    if p.is_file():
        yield p
    elif p.is_dir():
        for f in sorted(p.rglob("*")):
            if f.is_file():
                yield f


def test_no_character_literal_in_canonical_pack_surfaces() -> None:
    pat = re.compile(r"\b(" + _TOK_LOWER + "|" + _TOK_PASCAL + r")\b")
    offenders: list[tuple[str, int, str]] = []
    for surface in SCAN_PATHS:
        for f in _iter_files_under(surface):
            rel = str(f.relative_to(REPO_ROOT))
            if rel in ALLOWED_EXCEPTIONS:
                continue
            try:
                text = f.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            for ln_no, line in enumerate(text.splitlines(), start=1):
                if pat.search(line):
                    offenders.append((rel, ln_no, line.strip()[:80]))
    assert not offenders, (
        f"Charter #2 violation — character literal in canonical pack "
        f"surface(s): {offenders}"
    )


def test_no_project_literal_anywhere_in_pack() -> None:
    pat = re.compile(r"\b" + _TOK_PROJECT + r"\b")
    offenders: list[tuple[str, int, str]] = []
    for surface in SCAN_PATHS:
        for f in _iter_files_under(surface):
            rel = str(f.relative_to(REPO_ROOT))
            if rel in ALLOWED_EXCEPTIONS:
                continue
            try:
                text = f.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            for ln_no, line in enumerate(text.splitlines(), start=1):
                if pat.search(line):
                    offenders.append((rel, ln_no, line.strip()[:80]))
    assert not offenders, (
        f"Charter #2 violation — project literal: {offenders}"
    )


def test_documented_exceptions_actually_contain_meta_references() -> None:
    """Sanity check: the allowed-exceptions list isn't stale. If we
    later remove the meta-reference from the methodology doc or the
    validator, this list should shrink correspondingly."""
    methodology = REPO_ROOT / "docs/28_2d_character_animation/CROSS_PROJECT_PROMOTION_LESSONS.md"
    if methodology.exists():
        text = methodology.read_text(encoding="utf-8")
        # Methodology doc describes the rewrite of the character literal.
        assert _TOK_LOWER in text or _TOK_PASCAL in text, (
            "CROSS_PROJECT_PROMOTION_LESSONS.md should retain the "
            "methodology meta-reference; if removed, drop from "
            "ALLOWED_EXCEPTIONS"
        )
    validator = REPO_ROOT / "scripts/animation/validate_skill_pack.py"
    if validator.exists():
        text = validator.read_text(encoding="utf-8")
        assert _TOK_LOWER in text or "forbidden_tokens" in text, (
            "validator should retain the forbidden_tokens guardrail; "
            "if removed, drop from ALLOWED_EXCEPTIONS"
        )
