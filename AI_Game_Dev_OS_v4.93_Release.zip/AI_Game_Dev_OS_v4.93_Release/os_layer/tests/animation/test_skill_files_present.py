"""tests/animation/test_skill_files_present.py — v4.91 M-G c4.

Verify the 8 SKILL.md files referenced by ap_2026_006_creative_cluster.md
exist at OS-grade locations and meet structural requirements:
- front-matter `name:` matches directory name
- front-matter contains `description:`
- file contains an Acceptance criteria section
- file contains at least one gate-style section (inv_013 must_preserve)
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]

EXPECTED_SKILLS = [
    ("2d-character-motion-designer",
     "skills/_generic_core/animation/2d-character-motion-designer/SKILL.md"),
    ("sprite-sheet-planner",
     "skills/_generic_core/animation/sprite-sheet-planner/SKILL.md"),
    ("character-layer-splitter",
     "skills/_generic_core/animation/character-layer-splitter/SKILL.md"),
    ("rigging-prep-handoff",
     "skills/_generic_core/animation/rigging-prep-handoff/SKILL.md"),
    ("combat-animation-spec",
     "skills/_generic_core/animation/combat-animation-spec/SKILL.md"),
    ("asset-prompt-animation-helper",
     "skills/_generic_core/animation/asset-prompt-animation-helper/SKILL.md"),
    ("animation-qa-auditor",
     "skills/_generic_core/qa/animation-qa-auditor/SKILL.md"),
    ("godot-2d-animation-implementer",
     "skills/_engine_specific/godot/godot-2d-animation-implementer/SKILL.md"),
]

GATE_MARKERS = (
    "## Hard rules",
    "## Hard boundary",
    "## Do not use when",
    "## Required output",
    "## Use when",
)

FRONT_MATTER_RE = re.compile(r"^---\n(.*?)\n---\n", re.DOTALL)


@pytest.mark.parametrize("name,rel", EXPECTED_SKILLS)
def test_skill_file_exists(name: str, rel: str) -> None:
    p = REPO_ROOT / rel
    assert p.is_file(), f"missing skill file: {rel}"


@pytest.mark.parametrize("name,rel", EXPECTED_SKILLS)
def test_skill_front_matter_name_matches_dir(name: str, rel: str) -> None:
    text = (REPO_ROOT / rel).read_text(encoding="utf-8")
    m = FRONT_MATTER_RE.match(text)
    assert m is not None, f"{rel}: missing YAML front matter"
    body = m.group(1)
    assert f"name: {name}" in body, (
        f"{rel}: front matter `name` MUST equal {name!r}"
    )


@pytest.mark.parametrize("name,rel", EXPECTED_SKILLS)
def test_skill_has_description(name: str, rel: str) -> None:
    text = (REPO_ROOT / rel).read_text(encoding="utf-8")
    m = FRONT_MATTER_RE.match(text)
    assert m is not None
    assert "description:" in m.group(1), f"{rel}: missing front-matter description"


@pytest.mark.parametrize("name,rel", EXPECTED_SKILLS)
def test_skill_has_acceptance_criteria(name: str, rel: str) -> None:
    text = (REPO_ROOT / rel).read_text(encoding="utf-8")
    assert "Acceptance criteria" in text or "Acceptance Criteria" in text, (
        f"{rel}: missing Acceptance criteria section"
    )


@pytest.mark.parametrize("name,rel", EXPECTED_SKILLS)
def test_skill_has_gate_style_section(name: str, rel: str) -> None:
    """inv_013 must_preserve: every SKILL.md MUST declare at least
    one gate-style section so the manual-gate discipline is visible
    to the AI consumer."""
    text = (REPO_ROOT / rel).read_text(encoding="utf-8")
    matches = [g for g in GATE_MARKERS if g in text]
    assert matches, (
        f"{rel}: MUST contain at least one gate-style section "
        f"({GATE_MARKERS!r}) — Charter #6 / #11 alignment requirement"
    )
