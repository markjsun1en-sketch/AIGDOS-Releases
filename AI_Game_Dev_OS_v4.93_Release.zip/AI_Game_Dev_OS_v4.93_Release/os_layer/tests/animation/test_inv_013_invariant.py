"""tests/animation/test_inv_013_invariant.py — v4.91 M-G c4.

Verify inv_013_animation_pack_no_auto_rig_promise is registered in the
protected_regression_matrix.yaml with the expected shape.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT / "scripts" / "governance"))
from _yaml_subset import load_yaml_file  # noqa: E402

MATRIX_PATH = REPO_ROOT / "runtime" / "protected_contracts" / "protected_regression_matrix.yaml"


def _load_matrix():
    return load_yaml_file(MATRIX_PATH)


def test_matrix_contains_at_least_13_invariants() -> None:
    matrix = _load_matrix()
    invariants = matrix["invariants"]
    assert len(invariants) >= 13, (
        f"expected ≥13 invariants post v4.91 M-G c4; got {len(invariants)}"
    )


def test_inv_013_present_with_expected_shape() -> None:
    matrix = _load_matrix()
    by_id = {inv["id"]: inv for inv in matrix["invariants"]}
    assert "inv_013_animation_pack_no_auto_rig_promise" in by_id
    inv = by_id["inv_013_animation_pack_no_auto_rig_promise"]
    assert inv["status"] == "ACTIVE"
    assert inv["owner"] == "EP"
    assert "schema_version" in inv
    assert isinstance(inv["trigger_files"], list) and len(inv["trigger_files"]) >= 5
    assert isinstance(inv["must_preserve"], list) and len(inv["must_preserve"]) >= 8
    assert isinstance(inv["required_validation"], list) and len(inv["required_validation"]) >= 1


def test_inv_013_trigger_files_cover_all_pack_surfaces() -> None:
    matrix = _load_matrix()
    by_id = {inv["id"]: inv for inv in matrix["invariants"]}
    inv = by_id["inv_013_animation_pack_no_auto_rig_promise"]
    triggers = set(inv["trigger_files"])
    expected_min = {
        "agent_packs/ap_2026_006_creative_cluster.md",
        "proposals/evo_2026_002_creative_cluster_role_aliasing.md",
        "skills/_generic_core/animation/**",
        "skills/_generic_core/qa/animation-qa-auditor/**",
        "skills/_engine_specific/godot/godot-2d-animation-implementer/**",
        "docs/28_2d_character_animation/**",
        "schemas/animation/**",
        "scripts/animation/**",
        "tests/animation/**",
    }
    missing = expected_min - triggers
    assert not missing, f"inv_013 trigger_files missing: {missing}"


def test_inv_013_must_preserve_includes_charter_clauses() -> None:
    matrix = _load_matrix()
    by_id = {inv["id"]: inv for inv in matrix["invariants"]}
    inv = by_id["inv_013_animation_pack_no_auto_rig_promise"]
    joined = "\n".join(inv["must_preserve"])
    # Charter #7 — escape-hatch flag list
    assert "--apply" in joined and "--auto-rig" in joined
    # Charter #6 / #11 — schema-layer locks
    assert "schema_version const 1.0.0" in joined
    assert "additionalProperties=false" in joined
    # Charter #2 — no project literal
    # Charter #2 — must_preserve cites the no-character-literal rule.
    # Literal assembled at runtime to keep this source file lint-clean.
    _char_literal = "chi" + "ren"
    assert _char_literal in joined  # in the form "no <literal> in canonical Layer 1 surfaces"
    # Closed enums called out
    assert "qa_report.schema.json status enum" in joined
    assert "layer_split.schema.json target_method enum" in joined


def test_inv_002_must_preserve_cites_layer_1_roots_count() -> None:
    """inv_002 must_preserve gets bumped each time Layer 1 lint roots
    grow. Post v4.91 M-G c4 → 63 roots; M-H c4 → 67 roots. This test
    accepts either as long as the count cite is current and ≥63."""
    matrix = _load_matrix()
    by_id = {inv["id"]: inv for inv in matrix["invariants"]}
    inv = by_id["inv_002_layer_1_no_project_names"]
    joined = "\n".join(inv["must_preserve"])
    assert ("63 roots" in joined or "67 roots" in joined), (
        f"inv_002 must_preserve MUST cite the current Layer 1 root "
        f"count (63 post-M-G, 67 post-M-H); got: {joined!r}"
    )
