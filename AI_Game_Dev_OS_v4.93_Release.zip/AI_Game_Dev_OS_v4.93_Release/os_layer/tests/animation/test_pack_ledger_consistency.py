"""tests/animation/test_pack_ledger_consistency.py — v4.91 M-G c4.

Verify ap_2026_006_creative_cluster.md ledger entry references the
8 skills correctly, declares the exemption proposal, and stays
project-name-free.
"""
from __future__ import annotations

import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
PACK_LEDGER = REPO_ROOT / "agent_packs" / "ap_2026_006_creative_cluster.md"
EXEMPTION_PROPOSAL = "proposals/evo_2026_002_creative_cluster_role_aliasing.md"

EXPECTED_SKILL_NAMES = {
    "2d-character-motion-designer",
    "sprite-sheet-planner",
    "character-layer-splitter",
    "rigging-prep-handoff",
    "combat-animation-spec",
    "asset-prompt-animation-helper",
    "godot-2d-animation-implementer",
    "animation-qa-auditor",
}

# Forbidden tokens assembled at runtime so this source file stays
# Layer 1 lint-clean (per evo_2026_001 §Authoring discipline pattern,
# also used by scripts/migration/scan_legacy_project.py _sanitize).
FORBIDDEN_TOKENS = ["chi" + "ren", "lessis" + "more"]


def _load_pack_text() -> str:
    return PACK_LEDGER.read_text(encoding="utf-8")


def test_pack_ledger_file_exists() -> None:
    assert PACK_LEDGER.is_file(), f"missing pack ledger: {PACK_LEDGER}"


def test_pack_ledger_cluster_is_creative_cluster() -> None:
    text = _load_pack_text()
    assert ('cluster: "creative_cluster"' in text
            or "cluster: 'creative_cluster'" in text), (
        "pack ledger MUST declare cluster='creative_cluster'"
    )


def test_pack_ledger_lists_exemption_proposal() -> None:
    """Exemption gate per evo_2026_002 — the proposal id MUST appear in
    references[]; the validator's _CLUSTER_ALIASING_EXEMPTIONS path
    requires it."""
    text = _load_pack_text()
    assert EXEMPTION_PROPOSAL in text, (
        f"pack ledger references[] MUST list {EXEMPTION_PROPOSAL!r}"
    )


def test_pack_ledger_lists_all_8_skills() -> None:
    text = _load_pack_text()
    missing = [s for s in EXPECTED_SKILL_NAMES if s not in text]
    assert not missing, f"pack ledger missing skill references: {missing}"


def test_pack_ledger_no_forbidden_tokens() -> None:
    """Charter #2 — pack ledger body MUST NOT contain project-specific
    tokens. The CROSS_PROJECT_PROMOTION_LESSONS.md and
    validate_skill_pack.py have intentional 'chiren' references; the
    pack ledger itself must not."""
    text = _load_pack_text()
    for tok in FORBIDDEN_TOKENS:
        assert tok not in text, (
            f"pack ledger contains forbidden token {tok!r} (Charter #2)"
        )


def test_pack_ledger_roles_subset_of_design_implementation_validation() -> None:
    """Per evo_2026_002 exemption, creative_cluster packs MAY only declare
    roles from {design, implementation, validation}."""
    text = _load_pack_text()
    m = re.search(r"^roles:\s*\n((?:  - .*\n)+)", text, re.MULTILINE)
    assert m is not None, "pack ledger missing roles: list"
    role_lines = m.group(1)
    declared = set(re.findall(r'^\s+-\s+"([a-z_]+)"', role_lines, re.MULTILINE))
    allowed = {"design", "implementation", "validation"}
    extra = declared - allowed
    assert not extra, (
        f"pack ledger declares roles outside the exemption set: {extra}; "
        f"only {allowed} permitted per evo_2026_002"
    )
    assert declared, "roles list must be non-empty"


def test_provenance_yaml_is_project_name_free() -> None:
    """Charter #2 — provenance.yaml MUST NOT contain project literals.
    Specific adopting-project name lives in workspace MEMORY.md only."""
    p = REPO_ROOT / "docs" / "28_2d_character_animation" / "provenance.yaml"
    assert p.is_file(), "missing provenance.yaml"
    text = p.read_text(encoding="utf-8")
    for tok in FORBIDDEN_TOKENS:
        assert tok not in text, (
            f"provenance.yaml contains forbidden token {tok!r} (Charter #2)"
        )
