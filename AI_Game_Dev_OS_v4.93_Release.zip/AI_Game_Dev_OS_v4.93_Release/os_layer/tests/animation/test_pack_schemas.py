"""tests/animation/test_pack_schemas.py — v4.91 M-G c4.

JSON schema validation for the 3 schemas under schemas/animation/.
inv_013 must_preserve guards the closed enums and schema-const lock.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = REPO_ROOT / "schemas" / "animation"

SCHEMAS = [
    "layer_split.schema.json",
    "combat_animation_spec.schema.json",
    "qa_report.schema.json",
]


@pytest.mark.parametrize("name", SCHEMAS)
def test_schema_loads_and_has_schema_version_const(name: str) -> None:
    schema = json.loads((SCHEMA_DIR / name).read_text(encoding="utf-8"))
    sv = schema["properties"]["schema_version"]
    assert sv.get("const") == "1.0.0", (
        f"{name}: schema_version MUST be const '1.0.0' (Charter #6 schema-layer lock); got {sv!r}"
    )


@pytest.mark.parametrize("name", SCHEMAS)
def test_schema_additional_properties_false_at_root(name: str) -> None:
    schema = json.loads((SCHEMA_DIR / name).read_text(encoding="utf-8"))
    assert schema.get("additionalProperties") is False, (
        f"{name}: additionalProperties MUST be false at root"
    )


@pytest.mark.parametrize("name", SCHEMAS)
def test_schema_uses_draft_07(name: str) -> None:
    schema = json.loads((SCHEMA_DIR / name).read_text(encoding="utf-8"))
    assert schema.get("$schema") == "http://json-schema.org/draft-07/schema#", (
        f"{name}: $schema MUST be draft-07 (consistent with v4.91 OS convention)"
    )


@pytest.mark.parametrize("name", SCHEMAS)
def test_schema_id_uses_canonical_v491_host(name: str) -> None:
    schema = json.loads((SCHEMA_DIR / name).read_text(encoding="utf-8"))
    sid = schema.get("$id", "")
    assert sid.startswith("https://ai-dev-os.local/v4.91/schemas/animation/"), (
        f"{name}: $id MUST use canonical v4.91 host; got {sid!r}"
    )


def test_qa_report_status_enum_closed_4_vocabulary() -> None:
    schema = json.loads((SCHEMA_DIR / "qa_report.schema.json").read_text(encoding="utf-8"))
    enum = schema["properties"]["status"]["enum"]
    expected = {"pass", "pass_with_notes", "rework", "reject"}
    assert set(enum) == expected, (
        f"qa_report.status enum MUST stay closed 4-vocabulary (Charter #11 advisory verdicts only); got {enum!r}"
    )


def test_qa_report_severity_enum_closed_4_vocabulary() -> None:
    schema = json.loads((SCHEMA_DIR / "qa_report.schema.json").read_text(encoding="utf-8"))
    sev = schema["properties"]["issues"]["items"]["properties"]["severity"]["enum"]
    expected = {"blocker", "major", "minor", "polish"}
    assert set(sev) == expected, f"qa_report severity enum drift: {sev!r}"


def test_layer_split_target_method_enum_closed_6_vocabulary() -> None:
    schema = json.loads((SCHEMA_DIR / "layer_split.schema.json").read_text(encoding="utf-8"))
    enum = schema["properties"]["target_method"]["enum"]
    expected = {"sprite_sheet", "cutout", "skeleton2d", "spine_rig", "live2d_rig", "hybrid"}
    assert set(enum) == expected, f"layer_split target_method enum drift: {enum!r}"


def test_layer_split_split_depth_enum_closed_3_vocabulary() -> None:
    schema = json.loads((SCHEMA_DIR / "layer_split.schema.json").read_text(encoding="utf-8"))
    enum = schema["properties"]["split_depth"]["enum"]
    assert set(enum) == {"minimal", "standard", "advanced"}


def test_combat_spec_phase_name_enum_closed() -> None:
    schema = json.loads((SCHEMA_DIR / "combat_animation_spec.schema.json").read_text(encoding="utf-8"))
    enum = schema["properties"]["animations"]["items"]["properties"]["phases"]["items"]["properties"]["name"]["enum"]
    expected = {"anticipation", "active", "impact", "recovery", "return", "hold", "loop"}
    assert set(enum) == expected, f"combat_spec phase enum drift: {enum!r}"


def test_combat_spec_event_kind_enum_closed_10_vocabulary() -> None:
    schema = json.loads((SCHEMA_DIR / "combat_animation_spec.schema.json").read_text(encoding="utf-8"))
    enum = schema["properties"]["animations"]["items"]["properties"]["events"]["items"]["properties"]["kind"]["enum"]
    assert len(enum) == 10, f"combat_spec event kind enum MUST have 10 entries; got {len(enum)}: {enum!r}"
    assert "hit_frame" in enum
    assert "vfx_spawn" in enum
    assert "lockout_start" in enum


def test_combat_spec_event_name_pattern_evt_prefix() -> None:
    schema = json.loads((SCHEMA_DIR / "combat_animation_spec.schema.json").read_text(encoding="utf-8"))
    pat = schema["properties"]["animations"]["items"]["properties"]["events"]["items"]["properties"]["name"]["pattern"]
    assert pat.startswith("^evt_"), f"event name pattern MUST start with ^evt_; got {pat!r}"
