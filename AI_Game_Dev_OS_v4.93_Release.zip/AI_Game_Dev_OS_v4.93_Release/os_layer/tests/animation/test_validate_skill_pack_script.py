"""tests/animation/test_validate_skill_pack_script.py — v4.91 M-G c4.

Smoke-test the read-only validator script under scripts/animation/.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
VALIDATE_SCRIPT = REPO_ROOT / "scripts" / "animation" / "validate_skill_pack.py"
MANIFEST_SCRIPT = REPO_ROOT / "scripts" / "animation" / "make_animation_manifest.py"


def test_validate_skill_pack_script_exists_and_executable() -> None:
    assert VALIDATE_SCRIPT.is_file()


def test_validate_skill_pack_runs_clean() -> None:
    proc = subprocess.run(
        [sys.executable, str(VALIDATE_SCRIPT)],
        capture_output=True, text=True, timeout=30,
    )
    assert proc.returncode == 0, (
        f"validator failed:\nstdout={proc.stdout}\nstderr={proc.stderr}"
    )
    assert "[OK]" in proc.stdout
    assert "8 skills" in proc.stdout
    assert "ledger" in proc.stdout
    assert "provenance" in proc.stdout


def test_make_animation_manifest_runs_and_writes_index() -> None:
    proc = subprocess.run(
        [sys.executable, str(MANIFEST_SCRIPT)],
        capture_output=True, text=True, timeout=30,
    )
    assert proc.returncode == 0, (
        f"manifest generator failed:\nstdout={proc.stdout}\nstderr={proc.stderr}"
    )
    assert "[OK]" in proc.stdout
    out = REPO_ROOT / "docs" / "28_2d_character_animation" / "GENERATED_INDEX.md"
    assert out.is_file()
    text = out.read_text(encoding="utf-8")
    assert "agent_packs/ap_2026_006_creative_cluster.md" in text
    assert "proposals/evo_2026_002_creative_cluster_role_aliasing.md" in text
    # All 8 SKILL.md should appear in the index.
    for skill in [
        "2d-character-motion-designer", "sprite-sheet-planner",
        "character-layer-splitter", "rigging-prep-handoff",
        "combat-animation-spec", "asset-prompt-animation-helper",
        "animation-qa-auditor", "godot-2d-animation-implementer",
    ]:
        assert skill in text, f"GENERATED_INDEX.md missing skill: {skill}"
