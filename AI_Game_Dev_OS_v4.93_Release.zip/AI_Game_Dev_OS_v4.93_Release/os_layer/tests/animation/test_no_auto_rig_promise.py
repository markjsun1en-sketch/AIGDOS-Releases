"""tests/animation/test_no_auto_rig_promise.py — v4.91 M-G c4.

inv_013 compile-time guards. Verify scripts/animation/ remains
read-only with respect to canonical pack assets and that the
schema-layer Charter #6 / #11 locks stay in place.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS_DIR = REPO_ROOT / "scripts" / "animation"
SCHEMA_DIR = REPO_ROOT / "schemas" / "animation"

# Charter #7 — escape-hatch flags forbidden in scripts/animation/.
FORBIDDEN_FLAGS = [
    "--apply",
    "--auto-rig",
    "--auto-bind",
    "--auto-confirm",
    "--override",
    "--override-freeze",
    "--skip-review",
    "--bypass",
    "--allow-extra",
    "--force",
    "--auto-apply",
]

FORBIDDEN_RUNTIME_CALLS = [
    "shutil.rmtree",
    "shutil.move",
    "shutil.copytree",
    "os.system",
    "os.unlink",
    "os.remove",
    "subprocess.run",
    "subprocess.Popen",
    "subprocess.check_call",
    "subprocess.check_output",
]


def _iter_animation_py_files():
    for p in sorted(SCRIPTS_DIR.glob("*.py")):
        # __init__.py is included; it's a valid script file.
        yield p


@pytest.mark.parametrize("flag", FORBIDDEN_FLAGS)
def test_scripts_animation_no_forbidden_argparse_flag(flag: str) -> None:
    offenders = []
    for py in _iter_animation_py_files():
        text = py.read_text(encoding="utf-8")
        # Strip comments to avoid false-positive on doc lines that
        # mention the flag as forbidden.
        non_comment_lines = []
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            non_comment_lines.append(line)
        joined = "\n".join(non_comment_lines)
        # Look for argparse flag declarations only — pattern: `"--<flag>"`
        # or `'--<flag>'`.
        pattern = re.compile(rf'[\'"]({re.escape(flag)})[\'"]')
        if pattern.search(joined):
            offenders.append(str(py.relative_to(REPO_ROOT)))
    assert not offenders, (
        f"Charter #7 violation — scripts/animation/ MUST NOT define "
        f"argparse flag {flag!r}. Offenders: {offenders}"
    )


@pytest.mark.parametrize("call", FORBIDDEN_RUNTIME_CALLS)
def test_scripts_animation_no_destructive_runtime_call(call: str) -> None:
    """scripts/animation/ MUST stay read-only with respect to canonical
    pack assets. Destructive operations (shutil.rmtree, os.system,
    subprocess.*) are forbidden — the only writes permitted are to
    docs/28_2d_character_animation/GENERATED_INDEX.md (regenerable
    output) via Path.write_text."""
    offenders = []
    for py in _iter_animation_py_files():
        text = py.read_text(encoding="utf-8")
        for ln_no, line in enumerate(text.splitlines(), start=1):
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            if call in stripped:
                offenders.append(f"{py.relative_to(REPO_ROOT)}:{ln_no}")
    assert not offenders, (
        f"inv_013 violation — scripts/animation/ uses forbidden runtime "
        f"call {call!r}. Offenders: {offenders}"
    )


def test_qa_report_status_pass_is_advisory_only() -> None:
    """Charter #11 — qa_report.status='pass' is advisory; gameplay
    sign-off is a separate human gate. Schema MUST keep the 4-vocabulary
    closed enum; no 'closure' / 'accepted_for_release' state."""
    import json
    schema = json.loads((SCHEMA_DIR / "qa_report.schema.json").read_text(encoding="utf-8"))
    enum = set(schema["properties"]["status"]["enum"])
    expected = {"pass", "pass_with_notes", "rework", "reject"}
    assert enum == expected, (
        f"qa_report.status enum drift would break Charter #11; "
        f"expected {expected}, got {enum}"
    )


def test_ai_limitations_doc_lists_seven_human_gates() -> None:
    """inv_013 must_preserve: AI_LIMITATIONS_AND_HUMAN_GATE.md MUST
    enumerate ≥7 numbered human gates."""
    p = REPO_ROOT / "docs" / "28_2d_character_animation" / "AI_LIMITATIONS_AND_HUMAN_GATE.md"
    assert p.is_file()
    text = p.read_text(encoding="utf-8")
    # Count numbered entries like "1. ..." through "7. ..." in the
    # required-human-gates section.
    numbered = re.findall(r"^\d+\.\s+\*\*", text, re.MULTILINE)
    assert len(numbered) >= 7, (
        f"AI_LIMITATIONS_AND_HUMAN_GATE.md MUST list ≥7 numbered human "
        f"gates (Charter #11 alignment); found {len(numbered)}"
    )


def test_validate_agent_pack_has_creative_cluster_exemption_registry() -> None:
    """inv_013 must_preserve: the validator's _CLUSTER_ALIASING_EXEMPTIONS
    registry MUST contain the closed-form creative_cluster entry (and
    no --allow-deferred / --skip-exemption / --override flag)."""
    p = REPO_ROOT / "scripts" / "agent_library" / "validate_agent_pack.py"
    text = p.read_text(encoding="utf-8")
    assert "_CLUSTER_ALIASING_EXEMPTIONS" in text
    assert '"creative_cluster"' in text
    assert "evo_2026_002" in text, (
        "validator MUST cite proposals/evo_2026_002 in the exemption registry"
    )
    # No escape flags.
    forbidden_flags = ("--allow-deferred", "--skip-exemption", "--override-cluster")
    for flag in forbidden_flags:
        assert flag not in text, (
            f"Charter #7 violation — validator has escape flag {flag!r}"
        )
