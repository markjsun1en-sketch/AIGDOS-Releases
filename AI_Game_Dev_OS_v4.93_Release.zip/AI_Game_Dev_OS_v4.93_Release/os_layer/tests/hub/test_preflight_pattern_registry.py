"""test_preflight_pattern_registry.py — v4.91 P1-b (RC1-review gap B).

Locks down the Hub-side governance pattern candidate registry:

* schemas/hub/preflight_pattern_registry.schema.json
* hub/preflight/preflight_pattern_registry.json (seed)
* hub/preflight/preflight_metrics.json (seed)
* hub/preflight/preflight_index.jsonl (seed)
* scripts/hub/list_preflight_patterns.py (read-only CLI)

Coverage:
1. Schema meta-validation (valid draft-07).
2. Seed registry accepts against the schema (incl. the anti-pattern
   #11/#12 if/then guard).
3. The guard REJECTS a candidate that tries auto_apply_allowed=true,
   human_approval_required=false, or evidence_boundary drift.
4. Seed integrity: the seeded pattern id + its locked candidate flags.
5. Cross-file consistency: metrics counters match the registry; the
   index has one well-formed line per registered pattern.
6. CLI smoke: --help, --format json round-trips the registry, table
   lists the seeded pattern.

Uses jsonschema as a soft dependency (pytest.importorskip) per the
v4.89 zero-external-dep discipline.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA = REPO_ROOT / "schemas" / "hub" / "preflight_pattern_registry.schema.json"
REGISTRY = REPO_ROOT / "hub" / "preflight" / "preflight_pattern_registry.json"
METRICS = REPO_ROOT / "hub" / "preflight" / "preflight_metrics.json"
INDEX = REPO_ROOT / "hub" / "preflight" / "preflight_index.jsonl"
CLI = REPO_ROOT / "scripts" / "hub" / "list_preflight_patterns.py"

SEED_PATTERN_ID = "gov_pattern_multi_agent_preflight_consensus_v0"


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# 1. Schema meta-validation
# ---------------------------------------------------------------------------

def test_schema_meta_valid():
    jsonschema.Draft7Validator.check_schema(_load(SCHEMA))


# ---------------------------------------------------------------------------
# 2. Seed registry validates
# ---------------------------------------------------------------------------

def test_seed_registry_validates():
    jsonschema.Draft7Validator(_load(SCHEMA)).validate(_load(REGISTRY))


# ---------------------------------------------------------------------------
# 3. Anti-pattern #11/#12 guard rejects unsafe candidate variants
# ---------------------------------------------------------------------------

def _candidate_base() -> dict:
    return {
        "pattern_id": "gov_pattern_test_candidate_v0",
        "title": "Test Candidate",
        "status": "candidate",
        "auto_apply_allowed": False,
        "human_approval_required": True,
        "evidence_boundary": "direction_evidence_only",
        "registered_at": "2026-05-29T00:00:00Z",
    }


def _wrap(pattern: dict) -> dict:
    return {
        "schema_version": "1.0.0",
        "hub_id": "uninitialised_hub",
        "patterns": [pattern],
    }


@pytest.mark.parametrize("mutation", [
    {"auto_apply_allowed": True},
    {"human_approval_required": False},
    {"evidence_boundary": "validated_cross_project"},
])
def test_guard_rejects_unsafe_candidate(mutation):
    """A status=candidate entry MUST keep auto_apply_allowed=false,
    human_approval_required=true, evidence_boundary=direction_evidence_only.
    Any drift must fail validation (Charter anti-pattern #11/#12)."""
    pat = _candidate_base()
    pat.update(mutation)
    validator = jsonschema.Draft7Validator(_load(SCHEMA))
    with pytest.raises(jsonschema.ValidationError):
        validator.validate(_wrap(pat))


def test_guard_allows_safe_candidate():
    """The unmutated safe candidate must pass."""
    jsonschema.Draft7Validator(_load(SCHEMA)).validate(_wrap(_candidate_base()))


# ---------------------------------------------------------------------------
# 4. Seed integrity
# ---------------------------------------------------------------------------

def test_seed_contains_locked_consensus_pattern():
    reg = _load(REGISTRY)
    pats = {p["pattern_id"]: p for p in reg["patterns"]}
    assert SEED_PATTERN_ID in pats, "seed must register the consensus pattern"
    p = pats[SEED_PATTERN_ID]
    assert p["status"] == "candidate"
    assert p["auto_apply_allowed"] is False
    assert p["human_approval_required"] is True
    assert p["evidence_boundary"] == "direction_evidence_only"


# ---------------------------------------------------------------------------
# 5. Cross-file consistency (registry <-> metrics <-> index)
# ---------------------------------------------------------------------------

def test_metrics_match_registry():
    reg = _load(REGISTRY)
    m = _load(METRICS)
    pats = reg["patterns"]
    assert m["totals"]["patterns_total"] == len(pats)
    for status in ("candidate", "approved", "rejected", "superseded"):
        assert m["totals"][status] == sum(1 for p in pats if p["status"] == status)
    for boundary in ("direction_evidence_only", "validated_cross_project"):
        assert m["by_evidence_boundary"][boundary] == sum(
            1 for p in pats if p.get("evidence_boundary") == boundary
        )


def test_index_has_one_line_per_registered_pattern():
    reg = _load(REGISTRY)
    lines = [ln for ln in INDEX.read_text(encoding="utf-8").splitlines() if ln.strip()]
    # Each line must be valid JSON with a pattern_id present in the registry.
    reg_ids = {p["pattern_id"] for p in reg["patterns"]}
    for ln in lines:
        obj = json.loads(ln)
        assert "pattern_id" in obj
        assert "event" in obj and "timestamp" in obj
        assert obj["pattern_id"] in reg_ids
    # At least one 'registered' event for the seeded pattern.
    registered = [json.loads(ln) for ln in lines if json.loads(ln).get("event") == "registered"]
    assert any(o["pattern_id"] == SEED_PATTERN_ID for o in registered)


# ---------------------------------------------------------------------------
# 6. CLI smoke
# ---------------------------------------------------------------------------

def _run_cli(extra: list[str]):
    return subprocess.run(
        [sys.executable, str(CLI), *extra],
        cwd=str(REPO_ROOT),
        capture_output=True,
        text=True,
        timeout=30,
    )


def test_cli_help():
    r = _run_cli(["--help"])
    assert r.returncode == 0
    assert "--format" in r.stdout


def test_cli_json_roundtrips_registry():
    r = _run_cli(["--format", "json"])
    assert r.returncode == 0
    payload = json.loads(r.stdout)
    assert payload == _load(REGISTRY)


def test_cli_table_lists_seed_pattern():
    r = _run_cli([])
    assert r.returncode == 0
    assert SEED_PATTERN_ID in r.stdout
    assert "candidate" in r.stdout
