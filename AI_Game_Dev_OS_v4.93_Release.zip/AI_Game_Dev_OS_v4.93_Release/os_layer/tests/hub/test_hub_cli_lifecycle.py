"""test_hub_cli_lifecycle.py — v4.91 Batch 1 c5.

Integration tests for the 8 Hub CLIs lying in scripts/hub/. Every test
runs against a *throwaway temporary Hub root* — we never touch the
real hub/ directory under the v4.91 working tree. The technique:

  * Build a minimal fake Core layout under tmp_path (hub/, schemas/hub/,
    scripts/hub/, scripts/governance/_tenancy_reader.py, schemas/tenancy/).
  * Symlink each Hub CLI from the v4.91 tree into the tmp Core so
    REPO_ROOT (parents[2] of __file__) resolves to tmp_path.
  * Drive the CLIs via subprocess so the resolution path is identical
    to a user invocation.

Lifecycle covered (one big linear test + targeted small tests):

  init -> link_project (sample_alpha, sample_beta) -> list_projects ->
  inspect_project -> validate_project_mount -> health_all_projects ->
  export_hub_report -> unlink_project (sample_alpha) -> unlink_project
  (sample_beta) -> hub_status drained.

Plus negative cases:

  * link before init -> exit 2
  * link with bad project_id pattern -> exit 2
  * link duplicate -> exit 2
  * unlink unknown -> exit 2
  * init twice -> second exit 2

EP decision (2026-05-19): RH is the canonical first project in the
v4.91 demo path. Inside tests, however, we use generic
``sample_alpha`` and ``sample_beta`` placeholders so the test suite
remains Layer-1-clean (Charter anti-pattern #2: no project names in
non-fixture code).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
HUB_DIR_SRC = REPO_ROOT / "hub"
SCRIPTS_HUB_SRC = REPO_ROOT / "scripts" / "hub"
SCHEMAS_HUB_SRC = REPO_ROOT / "schemas" / "hub"
SCHEMAS_TENANCY_SRC = REPO_ROOT / "schemas" / "tenancy"
GOVERNANCE_SRC = REPO_ROOT / "scripts" / "governance"


def _run(argv: list[str], cwd: Path) -> subprocess.CompletedProcess:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return subprocess.run(
        argv,
        cwd=str(cwd),
        capture_output=True,
        text=True,
        env=env,
        timeout=60,
    )


@pytest.fixture
def fake_core(tmp_path: Path) -> Path:
    """Materialise a minimal Hub-capable fake Core under tmp_path.

    Copies (not symlinks) the necessary source files so a SIGKILL
    midway through a test cannot corrupt the real working tree."""
    core = tmp_path / "fake_core"
    (core / "hub").mkdir(parents=True)
    (core / "hub" / "logs").mkdir()
    (core / "hub" / "reports").mkdir()
    (core / "hub" / "preflight").mkdir()
    (core / "scripts" / "hub").mkdir(parents=True)
    (core / "scripts" / "governance").mkdir()
    (core / "schemas" / "hub").mkdir(parents=True)
    (core / "schemas" / "tenancy").mkdir(parents=True)

    # Copy hub/* skeleton (4 state files + README + .gitkeeps).
    for name in [
        "global_os_config.yaml",
        "projects.index.json",
        "mounts.yaml",
        "hub_state.json",
        "README.md",
    ]:
        shutil.copy(HUB_DIR_SRC / name, core / "hub" / name)
    # logs/ and reports/ are empty dirs pinned by .gitkeep.
    for sub in ("logs", "reports"):
        shutil.copy(HUB_DIR_SRC / sub / ".gitkeep", core / "hub" / sub / ".gitkeep")
    # v4.91 P1-b: hub/preflight/ is a populated registry, not a bare
    # .gitkeep. The hub CLI lifecycle does not consult it, so a minimal
    # README placeholder keeps the fake core's shape faithful.
    shutil.copy(HUB_DIR_SRC / "preflight" / "README.md", core / "hub" / "preflight" / "README.md")

    # Copy scripts/hub/*.py.
    for f in SCRIPTS_HUB_SRC.glob("*.py"):
        shutil.copy(f, core / "scripts" / "hub" / f.name)

    # Copy supporting governance helpers used by hub CLIs.
    for fname in ["_yaml_subset.py", "_tenancy_reader.py"]:
        shutil.copy(GOVERNANCE_SRC / fname, core / "scripts" / "governance" / fname)

    # Copy schemas/hub/*.
    for f in SCHEMAS_HUB_SRC.glob("*.json"):
        shutil.copy(f, core / "schemas" / "hub" / f.name)

    # Copy schemas/tenancy/* (load_project_claims may consult these).
    for f in SCHEMAS_TENANCY_SRC.glob("*.json"):
        shutil.copy(f, core / "schemas" / "tenancy" / f.name)

    # VERSION file so init_hub picks up a real version.
    (core / "VERSION").write_text("4.91-WIP\n", encoding="utf-8")

    return core


def _make_project_dir(root: Path, project_id: str, *, with_runtime_protocol: bool = True) -> Path:
    p = root / project_id
    (p / ".ai_dev_os").mkdir(parents=True)
    if with_runtime_protocol:
        (p / ".ai_dev_os" / "project_runtime_protocol.yaml").write_text(
            "# Minimal runtime protocol for hub CLI lifecycle test.\n"
            'schema_version: "1.0.0"\n'
            f'project_id: "{project_id}"\n'
            "project_profile:\n"
            '  stage: "incubation"\n'
            '  game_dev_phase: "prototype"\n',
            encoding="utf-8",
        )
    return p


# ---------------------------------------------------------------------------
# Happy path: full lifecycle.
# ---------------------------------------------------------------------------

def test_full_lifecycle(fake_core: Path, tmp_path: Path):
    """init -> link 2 projects -> list -> inspect -> validate ->
    health -> export -> unlink both -> drained."""
    proj_a = _make_project_dir(tmp_path / "projects", "sample_alpha")
    proj_b = _make_project_dir(tmp_path / "projects", "sample_beta")

    init = _run([sys.executable, "scripts/hub/init_hub.py",
                 "--hub-id", "test_hub_lc"], fake_core)
    assert init.returncode == 0, init.stderr
    assert "initialised" in init.stdout

    link_a = _run([sys.executable, "scripts/hub/link_project.py",
                   "--project-id", "sample_alpha",
                   "--project-root", str(proj_a)], fake_core)
    assert link_a.returncode == 0, link_a.stderr
    assert "Linked project_id='sample_alpha'" in link_a.stdout

    link_b = _run([sys.executable, "scripts/hub/link_project.py",
                   "--project-id", "sample_beta",
                   "--project-root", str(proj_b)], fake_core)
    assert link_b.returncode == 0, link_b.stderr

    listing = _run([sys.executable, "scripts/hub/list_projects.py",
                    "--format", "json"], fake_core)
    assert listing.returncode == 0
    payload = json.loads(listing.stdout)
    ids = {e["project_id"] for e in payload["projects"]}
    assert ids == {"sample_alpha", "sample_beta"}

    inspect = _run([sys.executable, "scripts/hub/inspect_project.py",
                    "--project-id", "sample_alpha", "--format", "json"], fake_core)
    assert inspect.returncode == 0
    inspected = json.loads(inspect.stdout)
    assert inspected["project_id"] == "sample_alpha"
    assert inspected["mount_record"]["stage"] == "incubation"
    assert inspected["mount_record"]["game_dev_phase"] == "prototype"

    validate = _run([sys.executable, "scripts/hub/validate_project_mount.py",
                     "--project-id", "sample_beta"], fake_core)
    assert validate.returncode == 0
    assert "OK" in validate.stdout

    health = _run([sys.executable, "scripts/hub/health_all_projects.py",
                   "--format", "json"], fake_core)
    assert health.returncode == 0
    h = json.loads(health.stdout)
    assert h["overall"]["project_count"] == 2
    # Either healthy (matching versions) or degraded (warn on
    # core_version_lock if our test core_version_locked default doesn't match).
    assert h["overall"]["status"] in {"healthy", "degraded"}

    export = _run([sys.executable, "scripts/hub/export_hub_report.py",
                   "--format", "json", "--stdout-only"], fake_core)
    assert export.returncode == 0
    e = json.loads(export.stdout)
    assert e["hub_state"]["linked_project_count"] == 2

    unlink_a = _run([sys.executable, "scripts/hub/unlink_project.py",
                     "--project-id", "sample_alpha"], fake_core)
    assert unlink_a.returncode == 0
    unlink_b = _run([sys.executable, "scripts/hub/unlink_project.py",
                     "--project-id", "sample_beta"], fake_core)
    assert unlink_b.returncode == 0

    final_state = json.loads((fake_core / "hub" / "hub_state.json").read_text())
    assert final_state["hub_status"] == "drained"
    assert final_state["linked_project_count"] == 0


# ---------------------------------------------------------------------------
# Negative cases.
# ---------------------------------------------------------------------------

def test_link_before_init_refused(fake_core: Path, tmp_path: Path):
    proj = _make_project_dir(tmp_path / "projects", "sample_alpha")
    r = _run([sys.executable, "scripts/hub/link_project.py",
              "--project-id", "sample_alpha",
              "--project-root", str(proj)], fake_core)
    assert r.returncode == 2
    assert "uninitialised" in r.stderr


def test_init_twice_refused(fake_core: Path):
    r1 = _run([sys.executable, "scripts/hub/init_hub.py",
               "--hub-id", "test_hub_twice"], fake_core)
    assert r1.returncode == 0
    r2 = _run([sys.executable, "scripts/hub/init_hub.py",
               "--hub-id", "test_hub_twice"], fake_core)
    assert r2.returncode == 2
    assert "already initialised" in r2.stderr


def test_link_bad_project_id_pattern(fake_core: Path, tmp_path: Path):
    _run([sys.executable, "scripts/hub/init_hub.py",
          "--hub-id", "test_hub_pat"], fake_core)
    proj = _make_project_dir(tmp_path / "projects", "sample_alpha")
    r = _run([sys.executable, "scripts/hub/link_project.py",
              "--project-id", "Bad-Id",  # uppercase + dash both violate pattern
              "--project-root", str(proj)], fake_core)
    assert r.returncode == 2
    assert "must match" in r.stderr


def test_link_duplicate_refused(fake_core: Path, tmp_path: Path):
    _run([sys.executable, "scripts/hub/init_hub.py",
          "--hub-id", "test_hub_dup"], fake_core)
    proj = _make_project_dir(tmp_path / "projects", "sample_alpha")
    r1 = _run([sys.executable, "scripts/hub/link_project.py",
               "--project-id", "sample_alpha",
               "--project-root", str(proj)], fake_core)
    assert r1.returncode == 0
    r2 = _run([sys.executable, "scripts/hub/link_project.py",
               "--project-id", "sample_alpha",
               "--project-root", str(proj)], fake_core)
    assert r2.returncode == 2
    assert "already linked" in r2.stderr


def test_unlink_unknown_refused(fake_core: Path):
    _run([sys.executable, "scripts/hub/init_hub.py",
          "--hub-id", "test_hub_uu"], fake_core)
    r = _run([sys.executable, "scripts/hub/unlink_project.py",
              "--project-id", "nonexistent_proj"], fake_core)
    assert r.returncode == 2
    assert "not linked" in r.stderr


def test_link_nonexistent_project_root(fake_core: Path, tmp_path: Path):
    _run([sys.executable, "scripts/hub/init_hub.py",
          "--hub-id", "test_hub_nx"], fake_core)
    r = _run([sys.executable, "scripts/hub/link_project.py",
              "--project-id", "sample_alpha",
              "--project-root", str(tmp_path / "no_such_dir")], fake_core)
    assert r.returncode == 2
    assert "does not exist" in r.stderr


# ---------------------------------------------------------------------------
# Atomic write semantics.
# ---------------------------------------------------------------------------

def test_two_phase_commit_keeps_files_consistent(fake_core: Path, tmp_path: Path):
    """After link_project, hub_state.linked_project_count must equal
    len(projects.index.projects), AND mounts.yaml must have the same
    set of project_ids. This is the cross-file invariant the 2PC
    transaction guarantees."""
    proj = _make_project_dir(tmp_path / "projects", "sample_alpha")
    _run([sys.executable, "scripts/hub/init_hub.py",
          "--hub-id", "test_hub_2pc"], fake_core)
    r = _run([sys.executable, "scripts/hub/link_project.py",
              "--project-id", "sample_alpha",
              "--project-root", str(proj)], fake_core)
    assert r.returncode == 0

    state = json.loads((fake_core / "hub" / "hub_state.json").read_text())
    idx = json.loads((fake_core / "hub" / "projects.index.json").read_text())

    # Read mounts.yaml via the package's own subset parser.
    sys.path.insert(0, str(REPO_ROOT / "scripts" / "governance"))
    import _yaml_subset  # type: ignore
    mts = _yaml_subset.parse_yaml_text(
        (fake_core / "hub" / "mounts.yaml").read_text(encoding="utf-8")
    )

    idx_ids = {e["project_id"] for e in idx["projects"]}
    mounts_ids = {r["project_id"] for r in mts["mounts"]}
    assert idx_ids == mounts_ids == {"sample_alpha"}
    assert state["linked_project_count"] == 1
    assert state["hub_status"] == "active"
