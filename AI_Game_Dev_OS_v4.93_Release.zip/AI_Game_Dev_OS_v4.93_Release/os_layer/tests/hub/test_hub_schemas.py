"""test_hub_schemas.py — v4.91 Batch 1 c1.

Validates the 5 Central Runtime Hub schemas:

* hub/global_os_config.schema.json
* hub/projects_index.schema.json
* hub/mounts.schema.json
* hub/hub_state.schema.json
* hub/health_report.schema.json

For each schema:
1. Meta-validation (the schema itself is valid JSON Schema draft-07).
2. Happy-path instance accepts.
3. Rejection cases: additionalProperties=false, missing required,
   const drift, enum violation, project_id pattern violation.

Uses jsonschema as a soft dependency (pytest.importorskip) per the
v4.89 zero-external-dep discipline.

Layer 1 (OS Spec). No project names — fixture project_ids use
generic placeholders (sample_alpha / sample_beta).
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")


REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_HUB = REPO_ROOT / "schemas" / "hub"

GLOBAL_CONFIG = SCHEMA_HUB / "global_os_config.schema.json"
PROJECTS_INDEX = SCHEMA_HUB / "projects_index.schema.json"
MOUNTS = SCHEMA_HUB / "mounts.schema.json"
HUB_STATE = SCHEMA_HUB / "hub_state.schema.json"
HEALTH_REPORT = SCHEMA_HUB / "health_report.schema.json"


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# Meta-validation: the schemas themselves are valid draft-07.
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("path", [
    GLOBAL_CONFIG, PROJECTS_INDEX, MOUNTS, HUB_STATE, HEALTH_REPORT,
])
def test_hub_schema_meta_valid(path):
    schema = _load(path)
    jsonschema.Draft7Validator.check_schema(schema)


# ---------------------------------------------------------------------------
# global_os_config
# ---------------------------------------------------------------------------

def _global_config_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "hub_id": "local_hub_alpha",
        "hub_root": "/abs/path/to/hub",
        "core_os_package": {
            "package_name": "AI_Game_Dev_OS_v4.91",
            "package_root_dir": "/abs/path/to/core",
            "version": "4.91-Release",
        },
        "policies": {
            "mount_default": "external_core",
            "cross_project_default": "isolated",
            "preflight_default": "selective",
            "version_lock_required": True,
        },
    }


def test_global_config_happy_accepts():
    jsonschema.validate(_global_config_happy(), _load(GLOBAL_CONFIG))


def test_global_config_additional_property_rejected():
    inst = _global_config_happy()
    inst["unexpected_top_level"] = "nope"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(GLOBAL_CONFIG))


def test_global_config_schema_version_const_locked():
    inst = _global_config_happy()
    inst["schema_version"] = "1.1.0"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(GLOBAL_CONFIG))


def test_global_config_mount_default_enum_only_link_or_copy():
    inst = _global_config_happy()
    inst["policies"]["mount_default"] = "shadow"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(GLOBAL_CONFIG))


def test_global_config_hub_id_pattern_rejects_uppercase():
    inst = _global_config_happy()
    inst["hub_id"] = "LocalHub"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(GLOBAL_CONFIG))


# ---------------------------------------------------------------------------
# projects_index
# ---------------------------------------------------------------------------

def _projects_index_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "hub_id": "local_hub_alpha",
        "updated_at": "2026-05-19T10:00:00Z",
        "projects": [
            {
                "project_id": "sample_alpha",
                "project_root": "/abs/path/to/sample_alpha",
                "mount_mode": "external_core",
                "core_version_locked": "4.91-Release",
                "linked_at": "2026-05-19T10:00:00Z",
                "last_health": {
                    "status": "unknown",
                    "checked_at": "2026-05-19T10:00:00Z",
                },
            }
        ],
    }


def test_projects_index_happy_accepts():
    jsonschema.validate(_projects_index_happy(), _load(PROJECTS_INDEX))


def test_projects_index_mount_mode_only_link():
    inst = _projects_index_happy()
    inst["projects"][0]["mount_mode"] = "copy"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECTS_INDEX))


def test_projects_index_health_status_enum_locked():
    inst = _projects_index_happy()
    inst["projects"][0]["last_health"]["status"] = "weird"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECTS_INDEX))


def test_projects_index_project_id_pattern_rejects_dash():
    inst = _projects_index_happy()
    inst["projects"][0]["project_id"] = "sample-alpha"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECTS_INDEX))


# ---------------------------------------------------------------------------
# mounts
# ---------------------------------------------------------------------------

def _mounts_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "hub_id": "local_hub_alpha",
        "updated_at": "2026-05-19T10:00:00Z",
        "mounts": [
            {
                "project_id": "sample_alpha",
                "project_root": "/abs/path/to/sample_alpha",
                "mount_mode": "external_core",
                "captured_at": "2026-05-19T10:00:00Z",
                "stage": "incubation",
                "game_dev_phase": "prototype",
            }
        ],
    }


def test_mounts_happy_accepts():
    jsonschema.validate(_mounts_happy(), _load(MOUNTS))


def test_mounts_missing_required_game_dev_phase_rejected():
    inst = _mounts_happy()
    del inst["mounts"][0]["game_dev_phase"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(MOUNTS))


# ---------------------------------------------------------------------------
# hub_state
# ---------------------------------------------------------------------------

def _hub_state_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "hub_id": "local_hub_alpha",
        "hub_status": "initialised",
        "linked_project_count": 0,
        "updated_at": "2026-05-19T10:00:00Z",
    }


def test_hub_state_happy_accepts():
    jsonschema.validate(_hub_state_happy(), _load(HUB_STATE))


def test_hub_state_status_enum_locked():
    inst = _hub_state_happy()
    inst["hub_status"] = "running"  # not in enum
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(HUB_STATE))


def test_hub_state_negative_count_rejected():
    inst = _hub_state_happy()
    inst["linked_project_count"] = -1
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(HUB_STATE))


# ---------------------------------------------------------------------------
# health_report
# ---------------------------------------------------------------------------

def _health_report_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "hub_id": "local_hub_alpha",
        "generated_at": "2026-05-19T10:00:00Z",
        "overall": {
            "status": "healthy",
            "project_count": 1,
            "healthy_count": 1,
            "degraded_count": 0,
            "broken_count": 0,
        },
        "projects": [
            {
                "project_id": "sample_alpha",
                "status": "healthy",
                "checks": [
                    {
                        "name": "mount_schema",
                        "outcome": "pass",
                    }
                ],
            }
        ],
    }


def test_health_report_happy_accepts():
    jsonschema.validate(_health_report_happy(), _load(HEALTH_REPORT))


def test_health_report_check_outcome_enum_locked():
    inst = _health_report_happy()
    inst["projects"][0]["checks"][0]["outcome"] = "weird"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(HEALTH_REPORT))


def test_health_report_overall_status_enum_locked():
    inst = _health_report_happy()
    inst["overall"]["status"] = "ok"  # not in enum (must be healthy/degraded/broken)
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(HEALTH_REPORT))
