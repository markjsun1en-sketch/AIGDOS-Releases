"""test_detect_embedded_release_bundle.py — v4.91 Addendum-A c5.

Tests the detect_embedded_release_bundle.py CLI + module:

  * 5 forbidden paths detection (4 unconditional + 1 conditional)
  * 3-state verdict (clean / sanctioned / violation)
  * mount_mode-aware sanctioning (vendor_snapshot vs others)
  * exit codes (0 safe / 1 violation / 2 pre-condition)

Layer 1. Fixtures live entirely under tmp_path.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
DETECT_CLI = REPO_ROOT / "scripts" / "hub" / "detect_embedded_release_bundle.py"


def _make_project(tmp_path: Path, name: str = "sample_proj") -> Path:
    proj = tmp_path / name
    proj.mkdir()
    (proj / ".ai_dev_os").mkdir()
    return proj


def _run(project_root: Path, *, mount_mode: str = "external_core",
         fmt: str = "text") -> subprocess.CompletedProcess:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return subprocess.run(
        [sys.executable, str(DETECT_CLI),
         "--project-root", str(project_root),
         "--mount-mode", mount_mode,
         "--format", fmt],
        capture_output=True, text=True, env=env, timeout=15,
    )


# ---------------------------------------------------------------------------
# clean projects (no detection)
# ---------------------------------------------------------------------------

def test_clean_project_returns_exit_0(tmp_path):
    proj = _make_project(tmp_path)
    cp = _run(proj)
    assert cp.returncode == 0
    assert "clean" in cp.stdout.lower()


# ---------------------------------------------------------------------------
# unconditional violations (5 forbidden top-level dirs)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "forbidden_dir",
    [
        "v490_release",
        "v491_release",
        "AI_Game_Dev_OS_Core",
    ],
)
def test_unconditional_forbidden_dirs_violate(tmp_path, forbidden_dir):
    proj = _make_project(tmp_path)
    (proj / forbidden_dir).mkdir()
    cp = _run(proj)
    assert cp.returncode == 1
    assert "VIOLATION" in cp.stderr or "violation" in cp.stderr.lower()


def test_glob_pattern_AI_Game_Dev_OS_v_dir_violates(tmp_path):
    """The AI_Game_Dev_OS_v* glob (matches v3 / v4.7 / v4.91 / v5 etc.)."""
    proj = _make_project(tmp_path)
    (proj / "AI_Game_Dev_OS_v4.91").mkdir()
    cp = _run(proj)
    assert cp.returncode == 1


# ---------------------------------------------------------------------------
# conditional path: vendor/ai_dev_os/
# ---------------------------------------------------------------------------

def test_vendor_path_under_external_core_mode_violates(tmp_path):
    proj = _make_project(tmp_path)
    (proj / "vendor" / "ai_dev_os").mkdir(parents=True)
    cp = _run(proj, mount_mode="external_core")
    assert cp.returncode == 1


def test_vendor_path_under_vendor_snapshot_mode_sanctioned(tmp_path):
    proj = _make_project(tmp_path)
    (proj / "vendor" / "ai_dev_os").mkdir(parents=True)
    cp = _run(proj, mount_mode="vendor_snapshot")
    assert cp.returncode == 0
    assert "sanctioned" in cp.stdout.lower()


def test_vendor_path_under_thin_scaffold_mode_violates(tmp_path):
    """vendor/ai_dev_os/ is sanctioned ONLY under vendor_snapshot."""
    proj = _make_project(tmp_path)
    (proj / "vendor" / "ai_dev_os").mkdir(parents=True)
    cp = _run(proj, mount_mode="thin_scaffold")
    assert cp.returncode == 1


# ---------------------------------------------------------------------------
# JSON output structure
# ---------------------------------------------------------------------------

def test_json_output_clean_payload_shape(tmp_path):
    import json as _json
    proj = _make_project(tmp_path)
    cp = _run(proj, fmt="json")
    assert cp.returncode == 0
    payload = _json.loads(cp.stdout)
    assert payload["status"] == "clean"
    assert payload["safe_to_continue"] is True
    assert payload["detected_paths"] == []
    assert payload["conditional_paths"] == []


def test_json_output_violation_payload_shape(tmp_path):
    import json as _json
    proj = _make_project(tmp_path)
    (proj / "v490_release").mkdir()
    cp = _run(proj, fmt="json")
    assert cp.returncode == 1
    payload = _json.loads(cp.stdout)
    assert payload["status"] == "violation"
    assert payload["safe_to_continue"] is False
    assert "v490_release/" in payload["detected_paths"]
    assert payload["recommended_action"] != "none"


# ---------------------------------------------------------------------------
# pre-condition: invalid project_root
# ---------------------------------------------------------------------------

def test_missing_project_root_exit_2(tmp_path):
    cp = _run(tmp_path / "does_not_exist")
    assert cp.returncode == 2


# ---------------------------------------------------------------------------
# Multiple forbidden paths in one project
# ---------------------------------------------------------------------------

def test_multiple_forbidden_dirs_all_reported(tmp_path):
    import json as _json
    proj = _make_project(tmp_path)
    (proj / "v490_release").mkdir()
    (proj / "v491_release").mkdir()
    (proj / "AI_Game_Dev_OS_v4.7").mkdir()
    cp = _run(proj, fmt="json")
    assert cp.returncode == 1
    payload = _json.loads(cp.stdout)
    detected = set(payload["detected_paths"])
    assert "v490_release/" in detected
    assert "v491_release/" in detected
    # AI_Game_Dev_OS_v4.7/ is glob-matched
    assert any(p.startswith("AI_Game_Dev_OS_v") for p in detected)
