"""test_hub_skeleton.py — v4.91 Batch 1 c2.

Validates that the on-disk hub/ skeleton files (shipped pre-init)
satisfy the schemas defined in B1 c1. The skeleton represents the
'uninitialised_hub' state — init_hub.py (B1 c3) will rewrite each
file with real values at first run.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
HUB_DIR = REPO_ROOT / "hub"
SCHEMA_HUB = REPO_ROOT / "schemas" / "hub"


def _load_json(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


def _load_yaml_subset(p: Path) -> dict:
    """Tiny shim: re-parse the skeleton YAML via a YAML library if
    available, else fall back to the project's own _yaml_subset parser
    so this test does not require PyYAML."""
    try:
        import yaml  # noqa: PLC0415
        return yaml.safe_load(p.read_text(encoding="utf-8"))
    except ImportError:
        # Fall back to the package's own subset parser.
        import importlib.util
        import sys

        spec = importlib.util.spec_from_file_location(
            "_yaml_subset_for_hub_skel",
            REPO_ROOT / "scripts" / "governance" / "_yaml_subset.py",
        )
        assert spec is not None and spec.loader is not None
        mod = importlib.util.module_from_spec(spec)
        sys.modules["_yaml_subset_for_hub_skel"] = mod
        spec.loader.exec_module(mod)
        return mod.parse_yaml_text(p.read_text(encoding="utf-8"))


def test_hub_dir_exists_with_required_files():
    """The Hub skeleton ships 4 state files + README + placeholder dirs.

    v4.91 P1-b: hub/preflight/ is no longer a bare .gitkeep placeholder —
    it now ships a populated governance pattern candidate registry
    (README + registry/index/metrics + recommended_patterns/). So
    preflight is validated by its README, while logs/ and reports/
    remain empty dirs held open by .gitkeep.
    """
    assert HUB_DIR.is_dir()
    for name in [
        "global_os_config.yaml",
        "projects.index.json",
        "mounts.yaml",
        "hub_state.json",
        "README.md",
    ]:
        assert (HUB_DIR / name).is_file(), f"missing hub/{name}"
    # Empty placeholder dirs still pinned by .gitkeep.
    for sub in ["logs", "reports"]:
        assert (HUB_DIR / sub).is_dir(), f"missing hub/{sub}/"
        assert (HUB_DIR / sub / ".gitkeep").is_file(), (
            f"missing hub/{sub}/.gitkeep"
        )
    # preflight/ is populated (P1-b) — validated by its README, not a .gitkeep.
    assert (HUB_DIR / "preflight").is_dir(), "missing hub/preflight/"
    assert (HUB_DIR / "preflight" / "README.md").is_file(), (
        "missing hub/preflight/README.md (P1-b populated registry)"
    )


def test_skeleton_global_config_validates():
    schema = _load_json(SCHEMA_HUB / "global_os_config.schema.json")
    inst = _load_yaml_subset(HUB_DIR / "global_os_config.yaml")
    jsonschema.validate(inst, schema)


def test_skeleton_projects_index_validates():
    schema = _load_json(SCHEMA_HUB / "projects_index.schema.json")
    inst = _load_json(HUB_DIR / "projects.index.json")
    jsonschema.validate(inst, schema)
    assert inst["projects"] == [], (
        "skeleton must ship with empty projects[] (uninitialised state)"
    )


def test_skeleton_mounts_validates():
    schema = _load_json(SCHEMA_HUB / "mounts.schema.json")
    inst = _load_yaml_subset(HUB_DIR / "mounts.yaml")
    jsonschema.validate(inst, schema)
    assert inst["mounts"] == []


def test_skeleton_hub_state_starts_uninitialised():
    schema = _load_json(SCHEMA_HUB / "hub_state.schema.json")
    inst = _load_json(HUB_DIR / "hub_state.json")
    jsonschema.validate(inst, schema)
    assert inst["hub_status"] == "uninitialised", (
        "skeleton must ship in 'uninitialised' state until init_hub runs"
    )
    assert inst["linked_project_count"] == 0
