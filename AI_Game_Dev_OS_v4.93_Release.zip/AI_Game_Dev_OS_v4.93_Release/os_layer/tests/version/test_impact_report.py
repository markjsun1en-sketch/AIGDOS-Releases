"""test_impact_report.py — v4.91 B3 c3.

Unit tests for scripts/hub/check_core_update_impact.py — focused on
classification logic and report payload structure. Does not exec the
CLI in subprocess (that path is covered by F10 fast-gate smoke); we
import the helpers directly.

Layer 1. Fixtures use 'sample_alpha' / 'sample_beta'.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT / "scripts" / "hub"))

import check_core_update_impact as cci  # noqa: E402


# ---------------------------------------------------------------------------
# classify_update.
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    ("from_v", "to_v", "expected"),
    [
        ("4.91.0", "4.91.1", "hotfix"),
        ("4.91-WIP", "4.91.0", "hotfix"),
        ("4.91.0", "4.92.0", "minor"),
        ("4.91-WIP", "4.92.0", "minor"),
        ("v4.91.0", "v5.0.0", "major"),
        ("4.91.0-rc1", "5.0.0", "major"),
    ],
)
def test_classify_update_taxonomy(from_v, to_v, expected):
    assert cci.classify_update(from_v, to_v) == expected


# ---------------------------------------------------------------------------
# build_report.
# ---------------------------------------------------------------------------

def _versions_lock_with_two_projects() -> dict:
    return {
        "schema_version": "1.0.0",
        "hub_id": "local_dev_hub",
        "core_os_package": {
            "package_name": "AI_Game_Dev_OS_v4.91",
            "version": "4.91-WIP",
        },
        "locked_at": "2026-05-20T03:00:00Z",
        "project_locks": {
            "sample_alpha": {
                "bound_version": "4.91-WIP",
                "linked_at": "2026-05-20T03:00:00Z",
            },
            "sample_beta": {
                "bound_version": "4.91-WIP",
                "linked_at": "2026-05-20T03:00:00Z",
                "deferred_upgrade_to": "5.0.0",
            },
        },
    }


def test_build_report_minor_marks_compatible_and_deferred():
    report = cci.build_report(
        versions_lock=_versions_lock_with_two_projects(),
        to_version="4.92.0",
        from_version=None,
    )
    assert report["update_class"] == "minor"
    summary = report["summary"]
    assert summary["linked_project_count"] == 2
    assert summary["compatible"] == 1
    assert summary["needs_review"] == 0
    assert summary["deferred"] == 1
    assert summary["blocked"] == 0
    # Sum invariant per schema.
    assert (
        summary["compatible"] + summary["needs_review"] +
        summary["blocked"] + summary["deferred"]
    ) == summary["linked_project_count"]
    # Per-project verdicts.
    by_id = {p["project_id"]: p for p in report["projects"]}
    assert by_id["sample_alpha"]["verdict"] == "compatible"
    assert by_id["sample_beta"]["verdict"] == "deferred"


def test_build_report_major_marks_needs_review_with_preflight():
    report = cci.build_report(
        versions_lock=_versions_lock_with_two_projects(),
        to_version="5.0.0",
        from_version=None,
    )
    assert report["update_class"] == "major"
    summary = report["summary"]
    # sample_alpha -> needs_review (preflight); sample_beta -> deferred (sticks).
    assert summary["needs_review"] == 1
    assert summary["deferred"] == 1
    assert summary["compatible"] == 0
    by_id = {p["project_id"]: p for p in report["projects"]}
    assert by_id["sample_alpha"]["verdict"] == "needs_review"
    assert by_id["sample_alpha"].get("preflight_required") is True
    assert by_id["sample_beta"]["verdict"] == "deferred"
