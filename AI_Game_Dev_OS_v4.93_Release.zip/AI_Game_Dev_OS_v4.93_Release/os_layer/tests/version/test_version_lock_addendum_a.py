"""test_version_lock_addendum_a.py — v4.91 Addendum-A c5.

Tests for the embedded_release_bundle + mount_mode fields added to
version_lock.schema.json in Addendum-A c1.

Layer 1. Fixtures use sample_alpha / local_dev_hub.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
VERSION_LOCK = REPO_ROOT / "schemas" / "version" / "version_lock.schema.json"


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


def _version_lock_minimal() -> dict:
    return {
        "schema_version": "1.1.0",
        "hub_id": "local_dev_hub",
        "core_os_package": {
            "package_name": "AI_Game_Dev_OS_v4.91",
            "version": "4.91-WIP",
        },
        "locked_at": "2026-05-20T03:00:00Z",
        "project_locks": {},
    }


# ---------------------------------------------------------------------------
# mount_mode field (Addendum-A NEW top-level)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "mode",
    ["external_core", "thin_scaffold", "vendor_snapshot"],
)
def test_version_lock_mount_mode_all_three_accepted(mode):
    inst = _version_lock_minimal()
    inst["mount_mode"] = mode
    jsonschema.validate(inst, _load(VERSION_LOCK))


def test_version_lock_mount_mode_unknown_value_rejected():
    inst = _version_lock_minimal()
    inst["mount_mode"] = "bundled"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(VERSION_LOCK))


# ---------------------------------------------------------------------------
# embedded_release_bundle block (Addendum-A NEW top-level)
# ---------------------------------------------------------------------------

def test_version_lock_embedded_bundle_minimal_accepted():
    inst = _version_lock_minimal()
    inst["embedded_release_bundle"] = {
        "detected": False,
        "allowed": False,
    }
    jsonschema.validate(inst, _load(VERSION_LOCK))


def test_version_lock_embedded_bundle_full_block_accepted():
    inst = _version_lock_minimal()
    inst["embedded_release_bundle"] = {
        "detected": True,
        "allowed": True,
        "vendor_snapshot_mode": True,
        "excluded_from_gate_scope": True,
        "excluded_from_ltm_retrieval": True,
    }
    jsonschema.validate(inst, _load(VERSION_LOCK))


def test_version_lock_embedded_bundle_missing_required_detected():
    inst = _version_lock_minimal()
    inst["embedded_release_bundle"] = {
        "allowed": False,
        # 'detected' missing
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(VERSION_LOCK))


def test_version_lock_embedded_bundle_missing_required_allowed():
    inst = _version_lock_minimal()
    inst["embedded_release_bundle"] = {
        "detected": False,
        # 'allowed' missing
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(VERSION_LOCK))


def test_version_lock_embedded_bundle_extra_keys_rejected():
    inst = _version_lock_minimal()
    inst["embedded_release_bundle"] = {
        "detected": False,
        "allowed": False,
        "extra_unknown_key": "value",  # additionalProperties: false
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(VERSION_LOCK))


def test_version_lock_schema_version_const_locked_at_1_1_0():
    inst = _version_lock_minimal()
    inst["schema_version"] = "1.0.0"  # Addendum-A bumped to 1.1.0
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(VERSION_LOCK))
