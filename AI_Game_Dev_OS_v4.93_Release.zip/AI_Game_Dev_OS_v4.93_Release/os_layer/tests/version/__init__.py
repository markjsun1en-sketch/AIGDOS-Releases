"""tests/version/__init__.py — v4.91 B3 c1.

Layer 1 (OS Spec). Hosts schema-validation, lock-CLI, and impact-report
tests for the v4.91 Version Lock & Core Update Policy contracts.

No project names. Fixtures use 'sample_alpha' / 'sample_beta' / 'local_dev_hub'.
"""
