"""test_version_lock_cli.py — v4.91 B3 c3.

Lifecycle integration tests for scripts/hub/lock_core_version.py.

Uses an isolated workspace under tmp_path so the live hub/ tree under
the repo is never touched. Each test:

  1. Creates a fake repo skeleton with hub/ + schemas/version/
  2. Initialises hub_state to 'initialised' with global_os_config
  3. Invokes lock_core_version main() via subprocess
  4. Asserts on stdout / exit code / hub/versions.lock content

Layer 1. Fixtures use 'sample_alpha' / 'local_dev_hub'.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
LOCK_CLI = REPO_ROOT / "scripts" / "hub" / "lock_core_version.py"


@pytest.fixture
def isolated_hub(tmp_path: Path) -> Path:
    """Build a fake repo skeleton under tmp_path with hub state + schemas.

    Returns the fake repo root.
    """
    fake_root = tmp_path / "fake_v491"
    fake_root.mkdir()

    # Mirror the schemas/ tree (we read schema files at validate time).
    schemas_dst = fake_root / "schemas" / "version"
    schemas_dst.mkdir(parents=True)
    src_schemas = REPO_ROOT / "schemas" / "version"
    for sf in src_schemas.glob("*.schema.json"):
        shutil.copy(sf, schemas_dst / sf.name)

    # Mirror scripts/hub (we exec lock_core_version.py from here so its
    # parents[2] == fake_root resolves correctly).
    scripts_dst = fake_root / "scripts" / "hub"
    scripts_dst.mkdir(parents=True)
    src_scripts = REPO_ROOT / "scripts" / "hub"
    for sf in src_scripts.iterdir():
        if sf.is_file():
            shutil.copy(sf, scripts_dst / sf.name)

    # Build hub state files in initialised state.
    hub = fake_root / "hub"
    hub.mkdir()
    (hub / "global_os_config.yaml").write_text(
        "schema_version: 1.0.0\n"
        "hub_id: local_dev_hub\n"
        "hub_root: " + str(fake_root) + "\n"
        "created_at: 2026-05-20T03:00:00Z\n"
        "core_os_package:\n"
        "  package_name: AI_Game_Dev_OS_v4.91\n"
        "  package_root_dir: " + str(fake_root) + "\n"
        "  version: 4.91-WIP\n"
        "policies:\n"
        "  mount_default: link\n"
        "  cross_project_default: isolated\n"
        "  preflight_default: selective\n"
        "  version_lock_required: true\n",
        encoding="utf-8",
    )
    (hub / "hub_state.json").write_text(json.dumps({
        "schema_version": "1.0.0",
        "hub_id": "local_dev_hub",
        "hub_status": "initialised",
        "linked_project_count": 0,
        "updated_at": "2026-05-20T03:00:00Z",
    }, indent=2) + "\n", encoding="utf-8")
    (hub / "projects.index.json").write_text(json.dumps({
        "schema_version": "1.0.0",
        "hub_id": "local_dev_hub",
        "updated_at": "2026-05-20T03:00:00Z",
        "projects": [],
    }, indent=2) + "\n", encoding="utf-8")
    (hub / "mounts.yaml").write_text(
        "schema_version: 1.0.0\n"
        "hub_id: local_dev_hub\n"
        "updated_at: 2026-05-20T03:00:00Z\n"
        "mounts: []\n",
        encoding="utf-8",
    )
    return fake_root


def _run(fake_root: Path, *args: str, env_extra: dict | None = None) -> subprocess.CompletedProcess:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    if env_extra:
        env.update(env_extra)
    cli = fake_root / "scripts" / "hub" / "lock_core_version.py"
    return subprocess.run(
        [sys.executable, str(cli), *args],
        cwd=str(fake_root),
        capture_output=True, text=True, env=env, timeout=30,
    )


def test_lock_refuses_when_no_projects_without_flag(isolated_hub: Path):
    cp = _run(isolated_hub)
    assert cp.returncode == 2, cp.stderr
    assert "0 linked projects" in cp.stderr or "linked projects" in cp.stderr.lower()


def test_lock_writes_versions_lock_with_allow_empty(isolated_hub: Path):
    cp = _run(isolated_hub, "--allow-empty-projects")
    assert cp.returncode == 0, cp.stderr
    versions_lock = isolated_hub / "hub" / "versions.lock"
    assert versions_lock.is_file()
    payload = json.loads(versions_lock.read_text(encoding="utf-8"))
    assert payload["schema_version"] == "1.1.0"
    assert payload["hub_id"] == "local_dev_hub"
    assert payload["core_os_package"]["package_name"] == "AI_Game_Dev_OS_v4.91"
    assert payload["core_os_package"]["version"] == "4.91-WIP"
    assert payload["project_locks"] == {}


def test_lock_refuses_when_uninitialised(isolated_hub: Path):
    """Reset hub_status to uninitialised; lock must refuse with exit 2."""
    state_path = isolated_hub / "hub" / "hub_state.json"
    state = json.loads(state_path.read_text(encoding="utf-8"))
    state["hub_status"] = "uninitialised"
    state_path.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
    cp = _run(isolated_hub, "--allow-empty-projects")
    assert cp.returncode == 2, cp.stderr
    assert "uninitialised" in cp.stderr.lower() or "init_hub" in cp.stderr
