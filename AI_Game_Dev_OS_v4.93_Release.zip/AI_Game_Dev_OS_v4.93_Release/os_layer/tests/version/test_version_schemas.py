"""test_version_schemas.py — v4.91 B3 c1.

Schema-validation tests for the four schemas/version/*.schema.json contracts:

  * schemas/version/version_lock.schema.json
  * schemas/version/update_plan.schema.json
  * schemas/version/impact_report.schema.json
  * schemas/version/core_update_policy.schema.json

Layer 1 (OS Spec). No project names — fixtures use 'sample_alpha'.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = REPO_ROOT / "schemas" / "version"

VERSION_LOCK = SCHEMA_DIR / "version_lock.schema.json"
UPDATE_PLAN = SCHEMA_DIR / "update_plan.schema.json"
IMPACT_REPORT = SCHEMA_DIR / "impact_report.schema.json"
CORE_UPDATE_POLICY = SCHEMA_DIR / "core_update_policy.schema.json"


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# Meta-validation: every schema is a valid Draft-07 schema.
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "path",
    [VERSION_LOCK, UPDATE_PLAN, IMPACT_REPORT, CORE_UPDATE_POLICY],
    ids=lambda p: p.name,
)
def test_version_schema_meta_valid(path):
    jsonschema.Draft7Validator.check_schema(_load(path))


# ---------------------------------------------------------------------------
# Happy-path payloads: every schema accepts a minimal-yet-valid example.
# ---------------------------------------------------------------------------

def _version_lock_happy() -> dict:
    return {
        "schema_version": "1.1.0",
        "hub_id": "local_dev_hub",
        "core_os_package": {
            "package_name": "AI_Game_Dev_OS_v4.91",
            "version": "4.91-WIP",
        },
        "locked_at": "2026-05-20T03:00:00Z",
        "project_locks": {
            "sample_alpha": {
                "bound_version": "4.91-WIP",
                "linked_at": "2026-05-20T03:00:00Z",
            }
        },
    }


def _update_plan_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "plan_id": "plan_sample_alpha_491_to_4920",
        "project_id": "sample_alpha",
        "from_version": "4.91-WIP",
        "to_version": "4.92.0",
        "update_class": "minor",
        "generated_at": "2026-05-20T03:05:00Z",
        "actions": [
            {
                "step_id": "step_01",
                "kind": "review_release_notes",
                "description": "Review v4.92.0 release notes for additive changes.",
            }
        ],
    }


def _impact_report_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "report_id": "impact_491_to_4920_20260520_030500",
        "hub_id": "local_dev_hub",
        "from_version": "4.91-WIP",
        "to_version": "4.92.0",
        "update_class": "minor",
        "generated_at": "2026-05-20T03:05:00Z",
        "summary": {
            "linked_project_count": 1,
            "compatible": 1,
            "needs_review": 0,
            "blocked": 0,
            "deferred": 0,
        },
        "projects": [
            {
                "project_id": "sample_alpha",
                "bound_version": "4.91-WIP",
                "verdict": "compatible",
            }
        ],
    }


def _core_update_policy_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "version_taxonomy": {
            "hotfix": "Z bump within same X.Y.",
            "minor": "Y bump within same X; additive only.",
            "major": "X bump or any breaking change.",
        },
        "require_preflight_for": [
            "major_version_bump",
            "cross_project_memory_policy_change",
            "intent_boundary_policy_change",
            "protected_invariant_change",
            "tenancy_contract_change",
        ],
    }


@pytest.mark.parametrize(
    ("schema_path", "payload_factory"),
    [
        (VERSION_LOCK, _version_lock_happy),
        (UPDATE_PLAN, _update_plan_happy),
        (IMPACT_REPORT, _impact_report_happy),
        (CORE_UPDATE_POLICY, _core_update_policy_happy),
    ],
    ids=["version_lock", "update_plan", "impact_report", "core_update_policy"],
)
def test_version_schema_happy_path(schema_path, payload_factory):
    jsonschema.validate(payload_factory(), _load(schema_path))
