"""test_lock_core_version_preflight_gate.py — v4.91 B5B c5.

Tests for the preflight gate added to scripts/hub/lock_core_version.py
(B5B c3). Each test extends the test_version_lock_cli.py
``isolated_hub`` shape with an LTM tree (preflight cases dir +
policy yaml) so the gate can be exercised end-to-end via subprocess.

Layer 1. Fixtures use 'sample_alpha' / 'local_dev_hub' / 'plan_xyz'.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]


# ----------------------------------------------------------------------
# Fixtures (extends test_version_lock_cli.isolated_hub)
# ----------------------------------------------------------------------


@pytest.fixture
def isolated_hub_with_ltm(tmp_path: Path) -> Path:
    """Build a fake repo skeleton with hub + ltm + schemas + scripts.

    Returns the fake repo root. The hub state is initialised with
    one linked project ('sample_alpha') so lock_core_version's
    pre-condition checks pass.
    """
    fake_root = tmp_path / "fake_v491"
    fake_root.mkdir()

    # Mirror schemas/version (lock_core_version validates against these).
    schemas_dst = fake_root / "schemas" / "version"
    schemas_dst.mkdir(parents=True)
    for sf in (REPO_ROOT / "schemas" / "version").glob("*.schema.json"):
        shutil.copy(sf, schemas_dst / sf.name)
    # Mirror schemas/ltm (preflight_case schema needed when reading cases).
    schemas_ltm_dst = fake_root / "schemas" / "ltm"
    schemas_ltm_dst.mkdir()
    for sf in (REPO_ROOT / "schemas" / "ltm").glob("*.schema.json"):
        shutil.copy(sf, schemas_ltm_dst / sf.name)

    # Mirror scripts/hub + scripts/ltm.
    for sub in ("hub", "ltm"):
        d = fake_root / "scripts" / sub
        d.mkdir(parents=True)
        for sf in (REPO_ROOT / "scripts" / sub).iterdir():
            if sf.is_file():
                shutil.copy(sf, d / sf.name)

    # Hub state: 1 linked project so lock pre-conditions pass.
    hub = fake_root / "hub"
    hub.mkdir()
    (hub / "global_os_config.yaml").write_text(
        "schema_version: 1.0.0\n"
        "hub_id: local_dev_hub\n"
        "hub_root: " + str(fake_root) + "\n"
        "created_at: 2026-05-22T03:00:00Z\n"
        "core_os_package:\n"
        "  package_name: AI_Game_Dev_OS_v4.91\n"
        "  package_root_dir: " + str(fake_root) + "\n"
        "  version: 4.91-WIP\n"
        "policies:\n"
        "  mount_default: external_core\n"
        "  cross_project_default: isolated\n"
        "  preflight_default: selective\n"
        "  version_lock_required: true\n",
        encoding="utf-8",
    )
    (hub / "hub_state.json").write_text(json.dumps({
        "schema_version": "1.0.0",
        "hub_id": "local_dev_hub",
        "hub_status": "initialised",
        "linked_project_count": 1,
        "updated_at": "2026-05-22T03:00:00Z",
    }, indent=2) + "\n", encoding="utf-8")
    (hub / "projects.index.json").write_text(json.dumps({
        "schema_version": "1.0.0",
        "hub_id": "local_dev_hub",
        "updated_at": "2026-05-22T03:00:00Z",
        "projects": [
            {"project_id": "sample_alpha",
             "linked_at": "2026-05-22T03:00:00Z"},
        ],
    }, indent=2) + "\n", encoding="utf-8")
    (hub / "mounts.yaml").write_text(
        "schema_version: 1.0.0\n"
        "hub_id: local_dev_hub\n"
        "updated_at: 2026-05-22T03:00:00Z\n"
        "mounts: []\n",
        encoding="utf-8",
    )
    (hub / "update_plans").mkdir()

    # LTM tree: copy live preflight_policy.yaml, build cases/metrics dirs.
    ltm = fake_root / "ltm"
    (ltm / "preflight" / "cases").mkdir(parents=True)
    (ltm / "preflight" / "metrics").mkdir()
    shutil.copy(
        REPO_ROOT / "ltm" / "preflight_policy.yaml",
        ltm / "preflight_policy.yaml",
    )
    return fake_root


def _write_major_plan(fake_root: Path, plan_id: str = "plan_sample_alpha_v490_to_v500") -> Path:
    plan = {
        "schema_version": "1.0.0",
        "plan_id": plan_id,
        "project_id": "sample_alpha",
        "from_version": "4.90.0",
        "to_version": "5.0.0",
        "update_class": "major",
        "generated_at": "2026-05-22T03:00:00Z",
        "actions": [
            {"step_id": "step_01", "kind": "run_b5b_preflight",
             "description": "run", "blocking": True},
        ],
        "preflight_required": True,
        "preflight_triggers": ["major_version_bump"],
        "deferred": False,
    }
    import yaml  # type: ignore
    p = fake_root / "hub" / "update_plans" / f"{plan_id}.yaml"
    p.write_text(yaml.safe_dump(plan, sort_keys=False), encoding="utf-8")
    return p


def _write_minor_plan(fake_root: Path) -> Path:
    plan = {
        "schema_version": "1.0.0",
        "plan_id": "plan_sample_alpha_minor",
        "project_id": "sample_alpha",
        "from_version": "4.91.0",
        "to_version": "4.91.1",
        "update_class": "hotfix",
        "generated_at": "2026-05-22T03:00:00Z",
        "actions": [
            {"step_id": "step_01", "kind": "refresh_mount_fingerprint",
             "description": "refresh", "blocking": False},
        ],
        "preflight_required": False,
        "preflight_triggers": [],
        "deferred": False,
    }
    import yaml  # type: ignore
    p = fake_root / "hub" / "update_plans" / "plan_sample_alpha_minor.yaml"
    p.write_text(yaml.safe_dump(plan, sort_keys=False), encoding="utf-8")
    return p


def _write_case(fake_root: Path, plan_id: str, *,
                outcome: str, decided_by: str = "ep",
                rationale: str | None = None) -> Path:
    """Write a finalized-shape preflight_case for the given plan_id."""
    import re
    body = re.sub(r"[^a-z0-9_]+", "_", plan_id.lower()).strip("_")
    case_id = f"pf_case_{body}"[:128]
    case = {
        "schema_version": "1.0.0",
        "case_id": case_id,
        "trigger": "major_version_bump",
        "subject": {
            "kind": "core_update_plan",
            "ref": f"hub/update_plans/{plan_id}.yaml",
        },
        "consulted_roles": ["governance_reviewer", "project_owner"],
        "consensus": {
            "outcome": outcome,
            "decided_by": decided_by,
        },
        "generated_at": "2026-05-22T03:01:00Z",
    }
    if rationale:
        case["consensus"]["rationale"] = rationale
    p = fake_root / "ltm" / "preflight" / "cases" / f"{case_id}.json"
    p.write_text(json.dumps(case, indent=2) + "\n", encoding="utf-8")
    return p


def _run_lock(fake_root: Path, *args: str) -> subprocess.CompletedProcess:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    cli = fake_root / "scripts" / "hub" / "lock_core_version.py"
    return subprocess.run(
        [sys.executable, str(cli), *args],
        cwd=str(fake_root),
        capture_output=True, text=True, env=env, timeout=30,
    )


# ----------------------------------------------------------------------
# Gate refusal cases (EXIT_PREFLIGHT_NOT_APPROVED == 5)
# ----------------------------------------------------------------------


def test_lock_refuses_when_preflight_required_but_no_case(isolated_hub_with_ltm):
    _write_major_plan(isolated_hub_with_ltm)
    cp = _run_lock(isolated_hub_with_ltm)
    assert cp.returncode == 5, cp.stderr + cp.stdout
    assert "preflight gate refused" in cp.stderr
    assert "case_missing" in cp.stderr


def test_lock_refuses_when_outcome_deferred(isolated_hub_with_ltm):
    plan_id = "plan_sample_alpha_v490_to_v500"
    _write_major_plan(isolated_hub_with_ltm, plan_id)
    _write_case(isolated_hub_with_ltm, plan_id,
                outcome="deferred", decided_by="pending",
                rationale="awaiting EP")
    cp = _run_lock(isolated_hub_with_ltm)
    assert cp.returncode == 5, cp.stderr + cp.stdout
    assert "outcome='deferred'" in cp.stderr


def test_lock_refuses_when_outcome_rejected(isolated_hub_with_ltm):
    plan_id = "plan_sample_alpha_v490_to_v500"
    _write_major_plan(isolated_hub_with_ltm, plan_id)
    _write_case(isolated_hub_with_ltm, plan_id,
                outcome="rejected", decided_by="ep",
                rationale="protected_invariant change unsafe")
    cp = _run_lock(isolated_hub_with_ltm)
    assert cp.returncode == 5, cp.stderr + cp.stdout
    assert "outcome='rejected'" in cp.stderr


def test_lock_refuses_when_decided_by_pending_with_approved(isolated_hub_with_ltm):
    """Defensive check: outcome=approved + decided_by=pending must also refuse."""
    plan_id = "plan_sample_alpha_v490_to_v500"
    _write_major_plan(isolated_hub_with_ltm, plan_id)
    _write_case(isolated_hub_with_ltm, plan_id,
                outcome="approved", decided_by="pending")
    cp = _run_lock(isolated_hub_with_ltm)
    assert cp.returncode == 5, cp.stderr + cp.stdout
    assert "decided_by" in cp.stderr.lower() or "audit chain" in cp.stderr


def test_lock_refusal_lists_all_unapproved_plans(isolated_hub_with_ltm):
    """When 2 plans both fail, both must be reported."""
    _write_major_plan(isolated_hub_with_ltm, "plan_alpha_to_v500")
    _write_major_plan(isolated_hub_with_ltm, "plan_alpha_to_v600")
    cp = _run_lock(isolated_hub_with_ltm)
    assert cp.returncode == 5
    assert "plan_alpha_to_v500" in cp.stderr
    assert "plan_alpha_to_v600" in cp.stderr


def test_lock_refusal_includes_remediation_hint(isolated_hub_with_ltm):
    _write_major_plan(isolated_hub_with_ltm)
    cp = _run_lock(isolated_hub_with_ltm)
    assert cp.returncode == 5
    assert "run_preflight_consensus.py finalize" in cp.stderr


# ----------------------------------------------------------------------
# Gate-pass cases
# ----------------------------------------------------------------------


def test_lock_passes_when_outcome_approved(isolated_hub_with_ltm):
    plan_id = "plan_sample_alpha_v490_to_v500"
    _write_major_plan(isolated_hub_with_ltm, plan_id)
    _write_case(isolated_hub_with_ltm, plan_id,
                outcome="approved", decided_by="ep",
                rationale="safe.")
    cp = _run_lock(isolated_hub_with_ltm)
    assert cp.returncode == 0, cp.stderr
    assert "preflight gate" in cp.stdout
    assert "1 plan(s) cleared" in cp.stdout
    assert (isolated_hub_with_ltm / "hub" / "versions.lock").is_file()


def test_lock_passes_when_no_update_plans(isolated_hub_with_ltm):
    """No update plans → gate is a no-op; lock proceeds."""
    cp = _run_lock(isolated_hub_with_ltm)
    assert cp.returncode == 0, cp.stderr


def test_lock_passes_when_only_minor_plans(isolated_hub_with_ltm):
    """Plans with preflight_required=false are silently ignored."""
    _write_minor_plan(isolated_hub_with_ltm)
    cp = _run_lock(isolated_hub_with_ltm)
    assert cp.returncode == 0, cp.stderr
    # No "preflight gate" line because no plan was even checked.
    assert "preflight gate refused" not in cp.stderr


def test_lock_passes_when_mixed_minor_and_approved_major(isolated_hub_with_ltm):
    plan_id = "plan_sample_alpha_v490_to_v500"
    _write_major_plan(isolated_hub_with_ltm, plan_id)
    _write_minor_plan(isolated_hub_with_ltm)
    _write_case(isolated_hub_with_ltm, plan_id,
                outcome="approved", decided_by="ep")
    cp = _run_lock(isolated_hub_with_ltm)
    assert cp.returncode == 0, cp.stderr


def test_lock_dry_run_does_not_write_lock_when_gate_passes(isolated_hub_with_ltm):
    plan_id = "plan_sample_alpha_v490_to_v500"
    _write_major_plan(isolated_hub_with_ltm, plan_id)
    _write_case(isolated_hub_with_ltm, plan_id,
                outcome="approved", decided_by="ep")
    cp = _run_lock(isolated_hub_with_ltm, "--dry-run")
    assert cp.returncode == 0, cp.stderr
    assert "[dry-run]" in cp.stdout
    assert not (isolated_hub_with_ltm / "hub" / "versions.lock").is_file()


# ----------------------------------------------------------------------
# Charter anti-pattern enforcement (no escape hatch)
# ----------------------------------------------------------------------


def test_no_skip_preflight_flag_exists(isolated_hub_with_ltm):
    """Charter anti-pattern #7: lock_core_version MUST NOT expose any
    --skip-preflight / --bypass-preflight / --force / --allow-extra
    flag. argparse refuses unknown flags with rc=2."""
    _write_major_plan(isolated_hub_with_ltm)
    for bad in ("--skip-preflight", "--bypass-preflight",
                "--force", "--allow-extra"):
        cp = _run_lock(isolated_hub_with_ltm, bad)
        assert cp.returncode != 0, \
            f"unexpected accept of {bad!r}: {cp.stdout} / {cp.stderr}"


def test_help_documents_exit_5(isolated_hub_with_ltm):
    """The --help output should not promise an --allow-extra escape;
    just sanity check the help still runs after the c3 changes."""
    cp = _run_lock(isolated_hub_with_ltm, "--help")
    assert cp.returncode == 0
    assert "lock_core_version" in cp.stdout
