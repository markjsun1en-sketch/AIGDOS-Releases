"""test_evolution_naming_alias.py — v4.90 Batch 13 Step 13.3 → Batch 14 Step 14.5.

Plan §8.2 字面 alignment: the `evolution/` tree and
`schemas/evolution/` directory are documented as naming aliases for
the canonical `proposals/` (workspace-level) and
`schemas/self_evolution/` (canonical schemas) locations
respectively.

Per EP D-13.3.2=B: these alias entries are documentation-only and
NOT folded into `LAYER_1_ROOTS` — the lint count was 31 at Batch 13;
extended to 33 at Batch 14 Step 14.8 (schemas/contracts +
tests/contracts roots; alias entries still excluded).

Step 14.5 refactor (EP A): the test is now data-driven against
`config/naming_aliases.yaml::domains.directory_aliases`. The
yaml-driven loop replaces previously hard-coded marker lists, so
adding a new alias only requires touching the yaml.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))

from scripts.governance._yaml_subset import load_yaml_file  # noqa: E402

CONFIG_PATH = REPO_ROOT / "config" / "naming_aliases.yaml"
PROPOSALS_DIR = REPO_ROOT / "proposals"
SEED_PROPOSAL = (
    PROPOSALS_DIR / "evo_2026_001_layer_separation_principle.md"
)
EVOLUTION_PROPOSALS_GITKEEP = (
    REPO_ROOT / "evolution" / "proposals" / ".gitkeep"
)


def _dir_alias_entries() -> list[dict]:
    data = load_yaml_file(CONFIG_PATH)
    return list(
        data["domains"]["directory_aliases"]["entries"]
    )


@pytest.mark.parametrize(
    "entry",
    _dir_alias_entries(),
    ids=lambda e: e["alias"],
)
def test_directory_alias_readme_exists_and_contains_markers(entry):
    """Every directory_aliases entry's README must exist and mention
    every declared marker. Replaces the hard-coded marker list of the
    pre-Batch-14.5 implementation."""
    readme_path = REPO_ROOT / entry["readme"]
    assert readme_path.is_file(), (
        f"missing alias README for {entry['alias']!r}: {readme_path}"
    )
    text = readme_path.read_text(encoding="utf-8")
    for marker in entry.get("markers", []):
        assert marker in text, (
            f"alias README {entry['readme']!r} missing required marker "
            f"{marker!r}"
        )


@pytest.mark.parametrize(
    "entry",
    [e for e in _dir_alias_entries() if e.get("canonical_schemas")],
    ids=lambda e: e["alias"],
)
def test_directory_alias_canonical_schemas_present(entry):
    """For aliases that declare canonical_schemas, every listed schema
    must exist under the canonical path."""
    canonical_path = REPO_ROOT / entry["canonical"].rstrip("/")
    for schema_name in entry["canonical_schemas"]:
        assert (canonical_path / schema_name).is_file(), (
            f"alias {entry['alias']!r} declares canonical schema "
            f"{schema_name!r} but file missing under {canonical_path}"
        )


def test_canonical_proposals_data_unchanged_by_alias():
    """The Step 13.3 alias must not move canonical entries.

    The seed proposal evo_2026_001 (created in Batch 6) MUST still
    sit at workspace-root proposals/, AND the alias placeholder
    `evolution/proposals/.gitkeep` MUST exist (so plan §8.2 字面
    path resolves on disk).
    """
    assert SEED_PROPOSAL.is_file(), (
        f"canonical seed proposal moved or deleted: {SEED_PROPOSAL}"
    )
    assert EVOLUTION_PROPOSALS_GITKEEP.is_file(), (
        f"alias placeholder missing: {EVOLUTION_PROPOSALS_GITKEEP}"
    )
    # Sanity: the alias placeholder must NOT be a real proposal file.
    gitkeep_text = EVOLUTION_PROPOSALS_GITKEEP.read_text(encoding="utf-8")
    assert "Alias pointer" in gitkeep_text or "alias" in gitkeep_text.lower(), (
        "evolution/proposals/.gitkeep should announce its alias role"
    )
