"""test_schema_version_const.py — v4.90 Batch 14 Step 14.3.

Consistency audit C-03 fix guard: every schema (except event-stream
schemas like mcp_audit_log) must declare a schema_version property
with a const value AND list it in required[].

EP decisions D-14.3 (S-1 + V-1 + R-1):
- D-14.3.S=S-1: mcp_audit_log is exempt (event-stream design;
  version is anchored at the collector/profile config layer, not
  on every per-event entry).
- D-14.3.V=V-1: const value is "1.0.0" for all 14 schemas (aligned
  with the 13 schemas that already had const "1.0.0" pre-Step 14.3).
- D-14.3.R=R-1: schema_version must be in required[] alongside the
  const, otherwise the const is toothless on missing fields.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

V4_90_ROOT = Path(__file__).resolve().parent.parent
SCHEMAS_DIR = V4_90_ROOT / "schemas"

# 14 schemas that gained schema_version const+required in Step 14.3.
# Sorted lexicographically for stable parametrize ids.
SCHEMAS_WITH_CONST = sorted([
    "agent_library/agent_pack_state.schema.json",
    "external_sync_audit.schema.json",
    "governance/cold_start_readset.schema.json",
    "governance/registry_sync_guard.schema.json",
    "governance/state_surface_policy.schema.json",
    "ltm/sprint_close_capture_input.schema.json",
    "merge_event.schema.json",
    "protocol/capability_adoption_state.schema.json",
    "protocol/compatibility_matrix.schema.json",
    "protocol/legacy_conflict_map.schema.json",
    "protocol/migration_state.schema.json",
    "protocol/project_runtime_protocol.schema.json",
    "runtime_execution_profile.schema.json",
    "self_evolution/proposal_state.schema.json",
])

# Event-stream schemas exempt from schema_version requirement.
SCHEMAS_EXEMPT = ["mcp_audit_log.schema.json"]


@pytest.mark.parametrize("rel", SCHEMAS_WITH_CONST)
def test_schema_has_version_const_and_required(rel: str) -> None:
    """Every Step 14.3 schema must declare schema_version with
    const='1.0.0' AND list it in required[]."""
    path = SCHEMAS_DIR / rel
    assert path.exists(), f"{rel}: schema file missing"
    s = json.loads(path.read_text(encoding="utf-8"))

    sv = s.get("properties", {}).get("schema_version")
    assert sv is not None, (
        f"{rel}: missing schema_version property — Step 14.3 should "
        f"have injected it (consistency audit C-03)"
    )
    assert sv.get("const") == "1.0.0", (
        f"{rel}: schema_version.const must be '1.0.0' (per "
        f"D-14.3.V=V-1), got {sv.get('const')!r}"
    )
    assert "schema_version" in s.get("required", []), (
        f"{rel}: schema_version must be in required[] (per "
        f"D-14.3.R=R-1, otherwise const is toothless)"
    )


def test_event_stream_schemas_explicitly_exempt() -> None:
    """mcp_audit_log is intentionally exempt from schema_version
    requirement (event-stream design). The exemption must be
    documented in its description so future maintainers know this
    is deliberate, not an oversight."""
    path = SCHEMAS_DIR / SCHEMAS_EXEMPT[0]
    assert path.exists(), "mcp_audit_log.schema.json missing"
    s = json.loads(path.read_text(encoding="utf-8"))

    assert "schema_version" not in s.get("required", []), (
        "mcp_audit_log: schema_version must NOT be in required[] "
        "(per D-14.3.S=S-1 — event-stream exemption)"
    )
    desc = s.get("description", "")
    assert "intentionally NOT required" in desc, (
        "mcp_audit_log: description must document schema_version "
        "exemption rationale (Step 14.3 D-14.3.S=S-1)"
    )
