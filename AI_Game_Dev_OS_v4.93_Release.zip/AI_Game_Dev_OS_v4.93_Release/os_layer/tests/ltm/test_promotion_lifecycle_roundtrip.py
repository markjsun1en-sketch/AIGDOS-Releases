"""Tests for the full LTM v3 lifecycle roundtrip — v4.91 B5 c5.

Each test exercises a multi-step state machine path documented in
docs/22_ltm_v3/PROMOTION_LIFECYCLE.md, end-to-end through subprocess
CLIs against an isolated tmp_path workspace.

Covers (5):
  1. quarantine -> promote -> retrieve (v3 reader sees approved_patterns)
  2. quarantine -> promote -> supersede (audit chain promote -> supersede)
  3. quarantine -> reject (terminal, audit retention)
  4. promote -> retrieve hard-isolation (sample_alpha cannot see beta entries)
  5. ledger_id family disjoint (promote_ vs reject_ vs supersede_ never collide)

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.ltm.conftest import run_script


@pytest.fixture
def ltm_root(tmp_path: Path) -> Path:
    root = tmp_path / "ltm"
    for d in (
        "failures",
        "pattern",
        "os",
        "cross_project",
        "cross_project/approved_patterns",
        "cross_project/rejected",
        "cross_project/superseded",
        "_quarantine",
        "project/sample_alpha",
        "project/sample_beta",
    ):
        (root / d).mkdir(parents=True, exist_ok=True)
    (root / "promotion_policy.yaml").write_text(
        "schema_version: \"1.0.0\"\n"
        "version: \"1.0.0-roundtrip\"\n"
        "thresholds:\n"
        "  cross_project_min_evidence_refs: 2\n"
        "approval:\n"
        "  mode: \"strict\"\n"
        "  forbidden_approvers: [auto, system, agent, automation, robot, ci]\n"
        "supersede:\n"
        "  must_reference_replacing_entry: true\n",
        encoding="utf-8",
    )
    (root / "retrieval_policy.yaml").write_text(
        "schema_version: \"1.0.0\"\n"
        "version: \"1.0.0\"\n"
        "default_include:\n"
        "  - current_project\n"
        "  - os\n"
        "  - approved_cross_project\n"
        "  - pattern\n"
        "  - failures\n"
        "default_exclude:\n"
        "  - other_project_private\n"
        "  - quarantine\n"
        "  - rejected\n"
        "  - unapproved_candidates\n"
        "  - superseded\n"
        "tenancy_enforcement:\n"
        "  mode: \"strict\"\n"
        "ranking:\n"
        "  boost_current_project: 1.5\n"
        "  boost_os: 1.0\n"
        "  boost_approved_cross_project: 0.8\n"
        "  max_results: 20\n",
        encoding="utf-8",
    )
    return root


def _write_candidate(
    ltm_root: Path,
    candidate_id: str,
    body: str = "## Symptom\n\nx\n\n## Root Cause\n\ny\n\n## Fix\n\nz\n\n## Lesson\n\nw\n",
) -> Path:
    candidate = {
        "schema_version": "1.0.0",
        "candidate_id": candidate_id,
        "captured_at": "2026-05-21T15:00:00Z",
        "actor": "kai",
        "evidence_ref": ["alpha ref", "beta ref"],
        "target_domain": "cross_project",
        "proposed_entry": {
            "captured_at": "2026-05-21T15:00:00Z",
            "actor": "kai",
            "gate": "passed",
            "evidence_ref": "alpha + beta",
        },
        "proposed_body": body,
    }
    p = ltm_root / "_quarantine" / f"{candidate_id}.json"
    p.write_text(json.dumps(candidate, indent=2) + "\n", encoding="utf-8")
    return p


# --------------------------------------------------------------------------
# 1. quarantine -> promote -> retrieve
# --------------------------------------------------------------------------

def test_lifecycle_quarantine_to_promoted_to_retrieved(ltm_root):
    cand = _write_candidate(
        ltm_root,
        "mc_lc1",
        body="## Symptom\n\nlifecycle smoke\n\n## Root Cause\n\nrt1\n\n## Fix\n\nuse v3 promote\n\n## Lesson\n\ntest verifies full path\n",
    )
    run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand),
        "--to", "cross_project",
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    # File lands in approved_patterns
    approved = list((ltm_root / "cross_project" / "approved_patterns").glob("*.md"))
    assert len(approved) == 1
    # Retrieve from a third-party project POV
    result = run_script(
        "retrieve_with_routing.py",
        "--query", "lifecycle smoke",
        "--project-id", "sample_alpha",
        "--ltm-root", str(ltm_root),
        "--policy", str(ltm_root / "retrieval_policy.yaml"),
    )
    result.expect(0)
    payload = json.loads(result.stdout)
    found_scopes = {r["scope"] for r in payload["ranked_results"]}
    assert "approved_cross_project" in found_scopes


# --------------------------------------------------------------------------
# 2. quarantine -> promote -> supersede with audit chain
# --------------------------------------------------------------------------

def test_lifecycle_promote_then_supersede_audit_chain(ltm_root):
    # Old entry to be superseded
    old = ltm_root / "failures" / "2026-04-01_old_lc2.md"
    old.write_text("# old failure\n", encoding="utf-8")

    cand = _write_candidate(ltm_root, "mc_lc2_replacement")
    run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand),
        "--to", "cross_project",
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    promote_ledger_path = cand.with_suffix(".promoted.json")
    promote_ledger = json.loads(promote_ledger_path.read_text())
    assert promote_ledger["ledger_id"].startswith("promote_")

    # Now supersede the old entry via the new promotion's ledger
    run_script(
        "supersede_memory_candidate.py",
        "--superseded-entry", str(old),
        "--replacing-entry-ledger", str(promote_ledger_path),
        "--superseded-by", "ep",
        "--ltm-root", str(ltm_root),
    ).expect(0)

    sup_files = list((ltm_root / "cross_project" / "superseded").glob("*.superseded.json"))
    assert len(sup_files) == 1
    sup = json.loads(sup_files[0].read_text())
    assert sup["ledger_id"].startswith("supersede_")
    assert sup["replacing_entry_ledger_ref"] == promote_ledger["ledger_id"]


# --------------------------------------------------------------------------
# 3. quarantine -> reject (terminal, audit copy)
# --------------------------------------------------------------------------

def test_lifecycle_reject_terminal_with_audit(ltm_root):
    cand = _write_candidate(ltm_root, "mc_lc3_rej")
    run_script(
        "reject_memory_candidate.py",
        "--candidate", str(cand),
        "--reason", "insufficient_evidence",
        "--rejected-by", "ep",
        "--rationale", "lifecycle test reject",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    # Audit copy in rejected/
    rejected_copies = list((ltm_root / "cross_project" / "rejected").glob("mc_lc3_rej*"))
    assert rejected_copies
    # Source candidate still exists in _quarantine (audit anchor)
    assert cand.exists()
    # Sidecar ledger present
    assert cand.with_suffix(".rejected.json").exists()


# --------------------------------------------------------------------------
# 4. Hard-isolation post-promote
# --------------------------------------------------------------------------

def test_lifecycle_hard_isolation_post_promote(ltm_root):
    # Write a project-private file under sample_beta that mentions our query
    (ltm_root / "project" / "sample_beta" / "private_secret.md").write_text(
        "# secret beta entry\n\nlifecycle isolation marker\n",
        encoding="utf-8",
    )
    # Query as sample_alpha — must NEVER surface beta content
    result = run_script(
        "retrieve_with_routing.py",
        "--query", "lifecycle isolation marker",
        "--project-id", "sample_alpha",
        "--ltm-root", str(ltm_root),
        "--policy", str(ltm_root / "retrieval_policy.yaml"),
    )
    result.expect(0)
    payload = json.loads(result.stdout)
    for r in payload["ranked_results"]:
        assert "sample_beta" not in r["path"], (
            f"Charter #7 violation: alpha sees beta content in results: {r}"
        )
    # And it must appear in skipped_paths with reason=tenancy_reconciliation_failed
    skipped = payload["routing_report"]["skipped_paths"]
    opp_skips = [s for s in skipped if s.get("scope") == "other_project_private"]
    assert any("sample_beta" in s["path"] for s in opp_skips), (
        f"Expected sample_beta files in skipped_paths with scope=other_project_private; got {skipped}"
    )


# --------------------------------------------------------------------------
# 5. ledger_id family disjoint
# --------------------------------------------------------------------------

def test_lifecycle_ledger_id_family_disjoint(ltm_root):
    # Promote
    cand_p = _write_candidate(ltm_root, "mc_lc5_p")
    run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_p),
        "--to", "cross_project",
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    p_ledger = json.loads(cand_p.with_suffix(".promoted.json").read_text())

    # Reject another candidate
    cand_r = _write_candidate(ltm_root, "mc_lc5_r")
    run_script(
        "reject_memory_candidate.py",
        "--candidate", str(cand_r),
        "--reason", "duplicate_of_existing",
        "--rejected-by", "ep",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    r_ledger = json.loads(cand_r.with_suffix(".rejected.json").read_text())

    # Supersede something via the first promotion
    old = ltm_root / "failures" / "2026-04-01_old_lc5.md"
    old.write_text("# old\n", encoding="utf-8")
    run_script(
        "supersede_memory_candidate.py",
        "--superseded-entry", str(old),
        "--replacing-entry-ledger", str(cand_p.with_suffix(".promoted.json")),
        "--superseded-by", "ep",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    s_ledger_files = list((ltm_root / "cross_project" / "superseded").glob("*.superseded.json"))
    s_ledger = json.loads(s_ledger_files[0].read_text())

    # Three families disjoint
    assert p_ledger["ledger_id"].startswith("promote_")
    assert r_ledger["ledger_id"].startswith("reject_")
    assert s_ledger["ledger_id"].startswith("supersede_")
    # Three event_types const-disjoint
    assert {p_ledger["event_type"], r_ledger["event_type"], s_ledger["event_type"]} == {
        "promoted", "rejected", "superseded"
    }
