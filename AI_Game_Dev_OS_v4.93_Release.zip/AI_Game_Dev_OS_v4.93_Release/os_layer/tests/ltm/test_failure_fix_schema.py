"""Tests for scripts/ltm/validate_failure_fix_entry.py — v4.90 Batch 4 Step 4.2."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.ltm.conftest import make_entry, run_script


# --------------------------------------------------------------------------
# Happy path
# --------------------------------------------------------------------------

def test_validator_passes_complete_v490_entry(ltm_failures_dir: Path):
    make_entry(ltm_failures_dir, "complete.md")
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(0)
    assert "0 violation(s)" in result.stdout


def test_validator_passes_v489_legacy_entry_with_warnings(ltm_failures_dir: Path):
    """v4.89-shipped entries lack v4.90-only fields; should be WARN not VIOLATION."""
    make_entry(
        ltm_failures_dir,
        "legacy.md",
        captured_at="2026-05-02T12:00:00Z",
        ff_id=None,
        failure_pattern=None,
        fix_pattern=None,
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(0)
    assert "0 violation(s)" in result.stdout
    assert "warning(s)" in result.stdout
    assert "warning(s), 0" not in result.stdout  # at least one warning


# --------------------------------------------------------------------------
# Required field violations
# --------------------------------------------------------------------------

def test_validator_fails_missing_required_field(ltm_failures_dir: Path):
    make_entry(ltm_failures_dir, "missing_evidence.md", evidence_ref=None)
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(1)
    assert "missing required field: 'evidence_ref'" in result.stdout


def test_validator_fails_missing_v490_only_field_for_post_cutoff(ltm_failures_dir: Path):
    """Post-cutoff entries MUST include all v4.90 fields; missing = violation."""
    make_entry(
        ltm_failures_dir,
        "missing_ff_id.md",
        captured_at="2026-05-10T12:00:00Z",  # post-cutoff
        ff_id=None,
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(1)
    assert "ff_id" in result.stdout


# --------------------------------------------------------------------------
# Type / pattern / const violations
# --------------------------------------------------------------------------

def test_validator_fails_gate_not_passed(ltm_failures_dir: Path):
    make_entry(ltm_failures_dir, "wrong_gate.md", gate="blocked")
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(1)
    assert "gate" in result.stdout
    assert "passed" in result.stdout


def test_validator_fails_invalid_ff_id_pattern(ltm_failures_dir: Path):
    make_entry(ltm_failures_dir, "bad_ff_id.md", ff_id="ff-2026-001")  # hyphens not underscores
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(1)
    assert "ff_id" in result.stdout
    assert "pattern mismatch" in result.stdout


def test_validator_fails_captured_at_wrong_format(ltm_failures_dir: Path):
    make_entry(
        ltm_failures_dir,
        "bad_ts.md",
        captured_at="2026-05-10",  # missing T...Z
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(1)
    assert "captured_at" in result.stdout
    assert "pattern mismatch" in result.stdout


def test_validator_fails_unknown_field(ltm_failures_dir: Path):
    """schema additionalProperties:false rejects stray fields."""
    make_entry(
        ltm_failures_dir,
        "extra.md",
        extra_fm={"random_extra": "nope"},
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(1)
    assert "random_extra" in result.stdout


# --------------------------------------------------------------------------
# Body section violations
# --------------------------------------------------------------------------

def test_validator_fails_missing_required_h2_section(ltm_failures_dir: Path):
    make_entry(
        ltm_failures_dir,
        "missing_lesson.md",
        body_sections=("Symptom", "Root Cause", "Fix"),  # no Lesson
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(1)
    assert "## Lesson" in result.stdout


def test_validator_fails_no_front_matter(ltm_failures_dir: Path):
    make_entry(ltm_failures_dir, "naked.md", no_front_matter=True)
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(1)
    assert "front-matter" in result.stdout


# --------------------------------------------------------------------------
# Single file invocation
# --------------------------------------------------------------------------

def test_validator_single_file_mode(ltm_failures_dir: Path):
    path = make_entry(ltm_failures_dir, "single.md")
    result = run_script(
        "validate_failure_fix_entry.py",
        "--file", str(path),
    )
    result.expect(0)


def test_validator_skips_readme_in_dir_mode(ltm_failures_dir: Path):
    """README.md inside failures/ is not an entry — must be skipped."""
    (ltm_failures_dir / "README.md").write_text(
        "# README\n\nNot a failure entry.\n", encoding="utf-8"
    )
    make_entry(ltm_failures_dir, "real.md")
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(0)
    assert "1 file(s) checked" in result.stdout  # only real.md, not README


# --------------------------------------------------------------------------
# JSON output
# --------------------------------------------------------------------------

def test_validator_json_output_shape(ltm_failures_dir: Path):
    make_entry(ltm_failures_dir, "ok.md")
    make_entry(ltm_failures_dir, "bad.md", evidence_ref=None)
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
        "--format", "json",
    )
    result.expect(1)
    payload = json.loads(result.stdout)
    assert payload["files_checked"] == 2
    assert payload["total_violations"] >= 1
    assert isinstance(payload["results"], list)


# --------------------------------------------------------------------------
# Exit-code error paths
# --------------------------------------------------------------------------

def test_validator_no_args_returns_input_missing(ltm_failures_dir: Path):
    result = run_script("validate_failure_fix_entry.py")
    assert result.exit_code == 4


def test_validator_dir_does_not_exist(tmp_path: Path):
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(tmp_path / "nope"),
    )
    assert result.exit_code == 4


def test_validator_dir_with_no_md_files(tmp_path: Path):
    empty = tmp_path / "empty"
    empty.mkdir()
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(empty),
    )
    assert result.exit_code == 4


# --------------------------------------------------------------------------
# Validate the v4.89-shipped corpus passes (the real ltm/failures/)
# --------------------------------------------------------------------------

def test_validator_v489_shipped_corpus_passes_with_warnings():
    """Run the validator over the real ltm/failures/ — should pass."""
    real_failures = Path(__file__).resolve().parents[2] / "ltm" / "failures"
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(real_failures),
    )
    # All v4.89 entries are pre-cutoff: 0 violations, multiple warnings expected
    result.expect(0)
    assert "0 violation(s)" in result.stdout
