"""test_memory_candidate_schema.py — v4.90 Batch 8 Step 8.3.

Self-validation tests for schemas/ltm/memory_candidate.schema.json:

1. The schema document is itself a valid JSON Schema draft-07 doc.
2. A minimal happy-path instance validates successfully.
3. Missing required top-level key is rejected.
4. candidate_id pattern enforcement (mc_YYYY_NNN).
5. evidence_ref minItems=1 + uniqueItems enforcement.

Mirrors tests/adoption/test_adoption_report_schema.py style. Uses
jsonschema via pytest.importorskip per the v4.89 zero-external-dep rule.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = REPO_ROOT / "schemas" / "ltm" / "memory_candidate.schema.json"


def _load_schema() -> dict:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def _minimal_valid_instance() -> dict:
    return {
        "candidate_id": "mc_2026_001",
        "target_domain": "failures",
        "source_path": "ltm/working/raw_findings.md",
        "evidence_ref": ["commit deadbeef"],
        "promotion_rationale": "Reproducible failure across two test runs.",
        "proposed_entry": {
            "captured_at": "2026-05-13T10:00:00Z",
            "actor": "kai",
        },
        "created_at": "2026-05-13",
        "schema_version": "1.0.0",
    }


# --------------------------------------------------------------------------
# 1. Schema is a valid JSON Schema draft-07
# --------------------------------------------------------------------------

def test_memory_candidate_schema_is_valid_jsonschema():
    schema = _load_schema()
    # draft-07 meta-schema check
    jsonschema.Draft7Validator.check_schema(schema)


# --------------------------------------------------------------------------
# 2. Minimal valid instance passes
# --------------------------------------------------------------------------

def test_minimal_instance_validates():
    schema = _load_schema()
    instance = _minimal_valid_instance()
    jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 3. Missing required field is rejected
# --------------------------------------------------------------------------

def test_missing_required_target_domain_is_rejected():
    schema = _load_schema()
    instance = _minimal_valid_instance()
    del instance["target_domain"]
    with pytest.raises(jsonschema.exceptions.ValidationError):
        jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 4. candidate_id pattern enforcement
# --------------------------------------------------------------------------

def test_candidate_id_pattern_enforced():
    schema = _load_schema()
    instance = _minimal_valid_instance()
    instance["candidate_id"] = "candidate-123"  # wrong shape
    with pytest.raises(jsonschema.exceptions.ValidationError):
        jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 5. evidence_ref minItems and uniqueItems
# --------------------------------------------------------------------------

def test_evidence_ref_must_be_non_empty():
    schema = _load_schema()
    instance = _minimal_valid_instance()
    instance["evidence_ref"] = []
    with pytest.raises(jsonschema.exceptions.ValidationError):
        jsonschema.validate(instance=instance, schema=schema)
