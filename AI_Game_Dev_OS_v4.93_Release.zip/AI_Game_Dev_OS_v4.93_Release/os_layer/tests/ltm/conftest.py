"""Shared fixtures for tests/ltm/ — v4.90 Batch 4.

Layer 1 (OS Spec). No project names. Fixture project IDs use generic
placeholders such as ``acme_demo`` / ``sample_project``.
"""
from __future__ import annotations

import os
import subprocess
import sys
import textwrap
from dataclasses import dataclass
from pathlib import Path

import pytest


SCRIPT_ROOT = Path(__file__).resolve().parents[2] / "scripts" / "ltm"
V4_90_ROOT = Path(__file__).resolve().parents[2]


@dataclass
class ScriptResult:
    exit_code: int
    stdout: str
    stderr: str

    def expect(self, code: int) -> "ScriptResult":
        assert self.exit_code == code, (
            f"expected exit {code}, got {self.exit_code}\n"
            f"stdout: {self.stdout}\nstderr: {self.stderr}"
        )
        return self


def run_script(name: str, *args: str, cwd: Path | None = None) -> ScriptResult:
    """Invoke scripts/ltm/<name> as a subprocess. Mirrors governance pattern."""
    script_path = SCRIPT_ROOT / name
    env = os.environ.copy()
    pkg_root = str(V4_90_ROOT)
    existing_pp = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = (
        f"{pkg_root}{os.pathsep}{existing_pp}" if existing_pp else pkg_root
    )
    proc = subprocess.run(
        [sys.executable, str(script_path), *args],
        capture_output=True,
        text=True,
        env=env,
        cwd=cwd,
    )
    return ScriptResult(
        exit_code=proc.returncode,
        stdout=proc.stdout,
        stderr=proc.stderr,
    )


@pytest.fixture
def ltm_failures_dir(tmp_path: Path) -> Path:
    """Empty failures-shaped directory under tmp_path."""
    d = tmp_path / "failures"
    d.mkdir()
    return d


def make_entry(
    failures_dir: Path,
    name: str,
    *,
    captured_at: str = "2026-05-10T22:30:00Z",
    actor: str = "test_actor",
    gate: str = "passed",
    evidence_ref: str = "commit deadbeef",
    project_id: str | None = None,
    ff_id: str | None = "ff_2026_999",
    failure_pattern: str | None = "test-failure-pattern",
    fix_pattern: str | None = "test-fix-pattern",
    schema_version: str | None = "1.0.0",
    lifecycle_state: str | None = "active",
    superseded_by: str | None = None,
    conflicts_with: list[str] | None = None,
    deprecated_at: str | None = None,
    withdrawn_at: str | None = None,
    extra_fm: dict[str, str] | None = None,
    body_sections: tuple[str, ...] = ("Symptom", "Root Cause", "Fix", "Lesson"),
    body_extra: str = "",
    no_front_matter: bool = False,
    invalid_front_matter_pair: tuple[str, str] | None = None,
) -> Path:
    """Synthesize a Failure-Fix entry on disk and return its path.

    Defaults emit a fully v4.90-compliant entry (all required + optional fields,
    including Batch 8 Step 8.2 schema_version + lifecycle_state).
    Set any field to None to omit it (e.g. ff_id=None to simulate a v4.89 entry;
    schema_version=None + lifecycle_state=None + captured_at pre-cutoff to
    simulate a legacy entry that should WARN rather than VIOLATE).
    """
    fm_lines = ["---"]
    fm_pairs: list[tuple[str, str]] = []
    if captured_at is not None:
        fm_pairs.append(("captured_at", captured_at))
    if actor is not None:
        fm_pairs.append(("actor", actor))
    if gate is not None:
        fm_pairs.append(("gate", gate))
    if evidence_ref is not None:
        fm_pairs.append(("evidence_ref", evidence_ref))
    if project_id is not None:
        fm_pairs.append(("project_id", project_id))
    if ff_id is not None:
        fm_pairs.append(("ff_id", ff_id))
    if failure_pattern is not None:
        fm_pairs.append(("failure_pattern", failure_pattern))
    if fix_pattern is not None:
        fm_pairs.append(("fix_pattern", fix_pattern))
    if schema_version is not None:
        fm_pairs.append(("schema_version", schema_version))
    if lifecycle_state is not None:
        fm_pairs.append(("lifecycle_state", lifecycle_state))
    if superseded_by is not None:
        fm_pairs.append(("superseded_by", superseded_by))
    if conflicts_with is not None:
        # Inline YAML flow sequence: [a, b]
        rendered = "[" + ", ".join(conflicts_with) + "]"
        fm_pairs.append(("conflicts_with", rendered))
    if deprecated_at is not None:
        fm_pairs.append(("deprecated_at", deprecated_at))
    if withdrawn_at is not None:
        fm_pairs.append(("withdrawn_at", withdrawn_at))
    if extra_fm:
        fm_pairs.extend(extra_fm.items())
    if invalid_front_matter_pair:
        fm_pairs.append(invalid_front_matter_pair)

    for k, v in fm_pairs:
        fm_lines.append(f"{k}: {v}")
    fm_lines.append("---")

    body = ["", "# Test Entry", ""]
    for section in body_sections:
        body.extend([f"## {section}", "", f"Filler text for {section}.", ""])
    if body_extra:
        body.append(body_extra)

    if no_front_matter:
        document = "\n".join(body)
    else:
        document = "\n".join(fm_lines + body)
    target = failures_dir / name
    target.write_text(document, encoding="utf-8")
    return target
