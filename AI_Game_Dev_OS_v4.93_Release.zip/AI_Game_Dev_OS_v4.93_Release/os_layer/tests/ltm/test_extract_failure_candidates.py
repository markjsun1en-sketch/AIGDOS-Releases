"""Tests for scripts/ltm/extract_failure_candidates.py — v4.90 Batch 8 Step 8.4.

Covers:
  1. Happy path: a single working/ note with full front-matter -> 1 envelope written
  2. Multiple notes -> sequential mc_YYYY_NNN allocation
  3. No front-matter file still produces an envelope (gate handled at promote)
  4. Default rationale injected when none supplied
  5. evidence_ref coerced from string -> 1-element list
  6. evidence_ref missing -> default "ltm/working source"
  7. README.md is skipped
  8. Empty working/ dir -> exit 4 + "no .md files" message
  9. Missing --from dir -> exit 4
 10. Dry-run mode does NOT write files
 11. Generated envelope conforms to memory_candidate schema (jsonschema check)
 12. JSON output mode emits structured summary

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.ltm.conftest import run_script


# --------------------------------------------------------------------------
# Local fixtures
# --------------------------------------------------------------------------

@pytest.fixture
def working_dir(tmp_path: Path) -> Path:
    d = tmp_path / "working"
    d.mkdir()
    return d


@pytest.fixture
def quarantine_dir(tmp_path: Path) -> Path:
    d = tmp_path / "_quarantine"
    return d  # not pre-created; script should mkdir


def _make_note(working: Path, name: str, *, fm: dict | None, body: str = "Body text\n") -> Path:
    parts: list[str] = []
    if fm is not None:
        parts.append("---")
        for k, v in fm.items():
            if isinstance(v, list):
                rendered = "[" + ", ".join(str(x) for x in v) + "]"
                parts.append(f"{k}: {rendered}")
            else:
                parts.append(f"{k}: {v}")
        parts.append("---")
    parts.append("")
    parts.append(body)
    target = working / name
    target.write_text("\n".join(parts), encoding="utf-8")
    return target


# --------------------------------------------------------------------------
# 1. Happy path
# --------------------------------------------------------------------------

def test_extracts_single_note_with_full_front_matter(working_dir, quarantine_dir):
    _make_note(
        working_dir,
        "raw_note.md",
        fm={
            "captured_at": "2026-05-13T10:00:00Z",
            "actor": "kai",
            "evidence_ref": ["commit abc123", "log/agents/x.md"],
            "promotion_rationale": "Reproducible across two runs.",
        },
    )
    result = run_script(
        "extract_failure_candidates.py",
        "--from", str(working_dir),
        "--out", str(quarantine_dir),
    )
    result.expect(0)
    candidates = list(quarantine_dir.glob("mc_*.json"))
    assert len(candidates) == 1
    env = json.loads(candidates[0].read_text())
    assert env["target_domain"] == "failures"
    assert env["evidence_ref"] == ["commit abc123", "log/agents/x.md"]
    assert env["promotion_rationale"] == "Reproducible across two runs."
    assert env["approver"] is None
    assert env["schema_version"] == "1.0.0"


# --------------------------------------------------------------------------
# 2. Multiple notes -> sequential ids
# --------------------------------------------------------------------------

def test_multiple_notes_get_sequential_candidate_ids(working_dir, quarantine_dir):
    _make_note(working_dir, "a.md", fm={"actor": "kai", "evidence_ref": "x"})
    _make_note(working_dir, "b.md", fm={"actor": "kai", "evidence_ref": "y"})
    _make_note(working_dir, "c.md", fm={"actor": "kai", "evidence_ref": "z"})
    result = run_script(
        "extract_failure_candidates.py",
        "--from", str(working_dir),
        "--out", str(quarantine_dir),
    )
    result.expect(0)
    ids = sorted(p.stem for p in quarantine_dir.glob("mc_*.json"))
    assert len(ids) == 3
    # Sequential within the current year — exact ids depend on year, but
    # the suffix pattern must be _001 / _002 / _003.
    suffixes = sorted(i.split("_")[-1] for i in ids)
    assert suffixes == ["001", "002", "003"]


# --------------------------------------------------------------------------
# 3. Note without front-matter still produces envelope
# --------------------------------------------------------------------------

def test_note_without_front_matter_produces_envelope(working_dir, quarantine_dir):
    _make_note(working_dir, "title_only.md", fm=None, body="Just a free-form note.\n")
    result = run_script(
        "extract_failure_candidates.py",
        "--from", str(working_dir),
        "--out", str(quarantine_dir),
    )
    result.expect(0)
    candidates = list(quarantine_dir.glob("mc_*.json"))
    assert len(candidates) == 1
    env = json.loads(candidates[0].read_text())
    assert env["proposed_entry"] == {}
    # default evidence_ref + default rationale
    assert env["evidence_ref"] == ["ltm/working source"]
    assert "no rationale supplied" in env["promotion_rationale"]


# --------------------------------------------------------------------------
# 4. evidence_ref coerced from string -> list
# --------------------------------------------------------------------------

def test_evidence_ref_string_coerced_to_list(working_dir, quarantine_dir):
    _make_note(
        working_dir,
        "string_evidence.md",
        fm={"actor": "kai", "evidence_ref": "single-citation-string"},
    )
    result = run_script(
        "extract_failure_candidates.py",
        "--from", str(working_dir),
        "--out", str(quarantine_dir),
    )
    result.expect(0)
    env = json.loads(next(quarantine_dir.glob("mc_*.json")).read_text())
    assert env["evidence_ref"] == ["single-citation-string"]


# --------------------------------------------------------------------------
# 5. README.md skipped
# --------------------------------------------------------------------------

def test_readme_md_is_skipped(working_dir, quarantine_dir):
    (working_dir / "README.md").write_text("# Working dir doc\n", encoding="utf-8")
    _make_note(working_dir, "real.md", fm={"actor": "kai", "evidence_ref": "ev"})
    result = run_script(
        "extract_failure_candidates.py",
        "--from", str(working_dir),
        "--out", str(quarantine_dir),
    )
    result.expect(0)
    assert len(list(quarantine_dir.glob("mc_*.json"))) == 1


# --------------------------------------------------------------------------
# 6. Empty working dir -> EXIT_INPUT_MISSING (4)
# --------------------------------------------------------------------------

def test_empty_working_dir_exits_input_missing(working_dir, quarantine_dir):
    result = run_script(
        "extract_failure_candidates.py",
        "--from", str(working_dir),
        "--out", str(quarantine_dir),
    )
    result.expect(4)


# --------------------------------------------------------------------------
# 7. Missing --from dir -> EXIT_INPUT_MISSING (4)
# --------------------------------------------------------------------------

def test_missing_from_dir_exits_input_missing(tmp_path: Path, quarantine_dir):
    bogus = tmp_path / "does_not_exist"
    result = run_script(
        "extract_failure_candidates.py",
        "--from", str(bogus),
        "--out", str(quarantine_dir),
    )
    result.expect(4)


# --------------------------------------------------------------------------
# 8. Dry-run does not write files
# --------------------------------------------------------------------------

def test_dry_run_does_not_write_files(working_dir, quarantine_dir):
    _make_note(working_dir, "a.md", fm={"actor": "kai", "evidence_ref": "x"})
    result = run_script(
        "extract_failure_candidates.py",
        "--from", str(working_dir),
        "--out", str(quarantine_dir),
        "--dry-run",
    )
    result.expect(0)
    assert not quarantine_dir.exists() or not list(quarantine_dir.glob("mc_*.json"))
    assert "would write" in result.stdout


# --------------------------------------------------------------------------
# 9. Generated envelope conforms to memory_candidate schema
# --------------------------------------------------------------------------

def test_generated_envelope_validates_against_schema(working_dir, quarantine_dir):
    jsonschema = pytest.importorskip("jsonschema")
    _make_note(
        working_dir,
        "complete.md",
        fm={
            "captured_at": "2026-05-13T10:00:00Z",
            "actor": "kai",
            "evidence_ref": ["citation-1"],
            "promotion_rationale": "Cross-validated.",
        },
    )
    result = run_script(
        "extract_failure_candidates.py",
        "--from", str(working_dir),
        "--out", str(quarantine_dir),
    )
    result.expect(0)
    schema_path = (
        Path(__file__).resolve().parents[2]
        / "schemas/ltm/memory_candidate.schema.json"
    )
    schema = json.loads(schema_path.read_text())
    env = json.loads(next(quarantine_dir.glob("mc_*.json")).read_text())
    jsonschema.validate(instance=env, schema=schema)


# --------------------------------------------------------------------------
# 10. JSON format mode emits structured summary
# --------------------------------------------------------------------------

def test_json_format_emits_structured_summary(working_dir, quarantine_dir):
    _make_note(working_dir, "a.md", fm={"actor": "kai", "evidence_ref": "x"})
    result = run_script(
        "extract_failure_candidates.py",
        "--from", str(working_dir),
        "--out", str(quarantine_dir),
        "--format", "json",
    )
    result.expect(0)
    payload = json.loads(result.stdout)
    assert "candidates_written" in payload
    assert len(payload["candidates_written"]) == 1
    assert payload["candidates_written"][0].startswith("mc_")
    assert payload["errors"] == []
    assert payload["dry_run"] is False


# ==========================================================================
# v4.91 B6 c5 — capture_source 5-enum coverage
# ==========================================================================

from tests.ltm.conftest import V4_90_ROOT as _B6_REPO_ROOT  # noqa: E402


def _b6_run(*args: str):
    return run_script("extract_failure_candidates.py", *args)


def test_b6_default_capture_source_is_extract_failure_candidates(tmp_path):
    """B6 c2 default: --source omitted yields capture_source='extract_failure_candidates'."""
    src = tmp_path / "working"
    src.mkdir()
    (src / "note.md").write_text(
        "---\nevidence_ref: 'x.py:1'\n---\nbody\n", encoding="utf-8",
    )
    out = tmp_path / "_quarantine"
    r = _b6_run("--from", str(src), "--out", str(out), "--format", "json")
    assert r.exit_code == 0, r.stderr
    cands = list(out.glob("mc_*.json"))
    assert len(cands) == 1
    env = json.loads(cands[0].read_text(encoding="utf-8"))
    assert env["capture_source"] == "extract_failure_candidates"


def test_b6_source_working_note_recorded(tmp_path):
    """B6 c2: --source working_note propagates into envelope."""
    src = tmp_path / "working"
    src.mkdir()
    (src / "note.md").write_text(
        "---\nevidence_ref: 'x.py:1'\n---\nbody\n", encoding="utf-8",
    )
    out = tmp_path / "_quarantine"
    r = _b6_run("--from", str(src), "--out", str(out),
                "--source", "working_note", "--format", "json")
    assert r.exit_code == 0, r.stderr
    env = json.loads(next(out.glob("mc_*.json")).read_text(encoding="utf-8"))
    assert env["capture_source"] == "working_note"


@pytest.mark.parametrize("foreign", [
    "sprint_close_failure", "evolution_proposal", "quarantine_retraction",
])
def test_b6_source_rejects_other_enum_values(tmp_path, foreign):
    """The CLI is authoritative ONLY for 2 of the 5 enum values; the
    other 3 are owned by sibling CLIs and MUST be refused via argparse choice."""
    src = tmp_path / "working"
    src.mkdir()
    out = tmp_path / "_quarantine"
    r = _b6_run("--from", str(src), "--out", str(out), "--source", foreign)
    assert r.exit_code == 2, f"unexpected accept of foreign source {foreign!r}"


def test_b6_envelope_passes_b6_c1_schema(tmp_path):
    """envelope MUST validate against B6 c1 5-enum schema."""
    import jsonschema  # type: ignore

    src = tmp_path / "working"
    src.mkdir()
    (src / "note.md").write_text(
        "---\nevidence_ref: 'x.py:1'\n---\nbody\n", encoding="utf-8",
    )
    out = tmp_path / "_quarantine"
    r = _b6_run("--from", str(src), "--out", str(out),
                "--source", "working_note", "--format", "json")
    assert r.exit_code == 0
    env = json.loads(next(out.glob("mc_*.json")).read_text(encoding="utf-8"))
    schema_path = _B6_REPO_ROOT / "schemas" / "ltm" / "memory_candidate.schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    jsonschema.validate(env, schema)


def test_b6_v4_90_envelope_no_capture_source_still_schema_valid():
    """Backward-compat: a v4.90-era envelope (no capture_source field)
    constructed by hand still validates against the post-B6 schema."""
    import jsonschema  # type: ignore

    schema_path = _B6_REPO_ROOT / "schemas" / "ltm" / "memory_candidate.schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    legacy = {
        "candidate_id": "mc_2024_001",
        "target_domain": "failures",
        "source_path": "ltm/working/old.md",
        "evidence_ref": ["legacy.py:1"],
        "promotion_rationale": "v4.90 envelope, no capture_source field",
        "proposed_entry": {},
        "created_at": "2024-12-31",
        "approver": None,
        "schema_version": "1.0.0",
    }
    jsonschema.validate(legacy, schema)
