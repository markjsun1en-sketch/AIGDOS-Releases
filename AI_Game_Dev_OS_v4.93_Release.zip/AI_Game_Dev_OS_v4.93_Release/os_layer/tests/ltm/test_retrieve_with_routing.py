"""v4.91 B4 c5 — retrieve_with_routing.py end-to-end CLI tests.

Locks the c2 hard-isolation contract end-to-end: a project querying
across the LTM tree NEVER sees other_project_private content in
results[]; those paths appear in skipped_paths[] with reason
=tenancy_reconciliation_failed.

Tests use subprocess + isolated tmp_path workspace mirroring the
schemas/ltm + scripts/ltm + ltm/ tree layout. No mutations to the
main workspace.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]


# ---------------------------------------------------------------------------
# Fixture factory


def _build_fake_workspace(tmp_path: Path) -> Path:
    """Mirror the minimal subset of the workspace retrieve_with_routing
    needs: schemas/ltm + scripts/ltm + ltm/ tree with a couple of
    sample entries per scope."""
    fake = tmp_path / "fake_v491"
    fake.mkdir()

    # Mirror schemas + scripts (read-only consumers)
    for sub in ("schemas/ltm", "scripts/ltm"):
        (fake / sub).mkdir(parents=True)
        for f in (REPO_ROOT / sub).iterdir():
            if f.is_file():
                shutil.copy2(f, fake / sub / f.name)

    # Build a tiny LTM tree
    ltm = fake / "ltm"
    (ltm / "os").mkdir(parents=True)
    (ltm / "failures").mkdir()
    (ltm / "pattern").mkdir()
    (ltm / "cross_project" / "approved_patterns").mkdir(parents=True)
    (ltm / "cross_project" / "candidates").mkdir()
    (ltm / "cross_project" / "rejected").mkdir()
    (ltm / "cross_project" / "superseded").mkdir()
    (ltm / "_quarantine").mkdir()
    (ltm / "project" / "alpha").mkdir(parents=True)
    (ltm / "project" / "beta").mkdir()

    # Each entry contains the search term so scoring picks them up
    term = "loadbearing"
    (ltm / "os" / "rule_a.md").write_text(
        f"---\ngate: passed\n---\n# {term} foundation rule\n", encoding="utf-8")
    (ltm / "failures" / "f1.md").write_text(
        f"---\ngate: passed\n---\n# {term} bug postmortem\n", encoding="utf-8")
    (ltm / "pattern" / "p1.md").write_text(
        f"# {term} pattern\n", encoding="utf-8")
    (ltm / "cross_project" / "approved_patterns" / "ap1.md").write_text(
        f"# {term} approved pattern\n", encoding="utf-8")
    (ltm / "cross_project" / "candidates" / "c1.md").write_text(
        f"# {term} candidate (unapproved)\n", encoding="utf-8")
    (ltm / "cross_project" / "rejected" / "r1.md").write_text(
        f"# {term} rejected\n", encoding="utf-8")
    (ltm / "cross_project" / "superseded" / "s1.md").write_text(
        f"# {term} superseded\n", encoding="utf-8")
    (ltm / "_quarantine" / "q1.md").write_text(
        f"# {term} quarantined\n", encoding="utf-8")
    (ltm / "project" / "alpha" / "a1.md").write_text(
        f"# alpha {term} private\n", encoding="utf-8")
    (ltm / "project" / "beta" / "b1.md").write_text(
        f"# beta {term} private\n", encoding="utf-8")

    # Default policy
    (ltm / "retrieval_policy.yaml").write_text("""schema_version: "1.0.0"
version: "1.0.0"
default_include:
  - current_project
  - os
  - approved_cross_project
  - pattern
  - failures
default_exclude:
  - other_project_private
  - quarantine
  - rejected
  - unapproved_candidates
  - superseded
ranking:
  boost_current_project: 1.5
  boost_os: 1.0
  boost_approved_cross_project: 0.8
  max_results: 20
tenancy_enforcement:
  mode: "strict"
""", encoding="utf-8")

    return fake


def _run_retrieve(fake: Path, project_id: str, query: str = "loadbearing"
                  ) -> tuple[int, dict, str]:
    """Run retrieve_with_routing.py against the fake workspace."""
    r = subprocess.run(
        [sys.executable,
         str(fake / "scripts/ltm/retrieve_with_routing.py"),
         "--query", query,
         "--project-id", project_id,
         "--policy", str(fake / "ltm/retrieval_policy.yaml"),
         "--ltm-root", str(fake / "ltm"),
         "--format", "compact"],
        capture_output=True, text=True, timeout=30,
    )
    if r.returncode != 0:
        return r.returncode, {}, r.stderr
    return r.returncode, json.loads(r.stdout), r.stderr


def _run_dryrun(fake: Path, project_id: str) -> tuple[int, dict, str]:
    r = subprocess.run(
        [sys.executable,
         str(fake / "scripts/ltm/generate_routing_report.py"),
         "--query", "noop",
         "--project-id", project_id,
         "--policy", str(fake / "ltm/retrieval_policy.yaml"),
         "--format", "compact"],
        capture_output=True, text=True, timeout=30,
    )
    if r.returncode != 0:
        return r.returncode, {}, r.stderr
    return r.returncode, json.loads(r.stdout), r.stderr


# ---------------------------------------------------------------------------
# Tests


def test_retrieve_returns_current_project_in_results(tmp_path: Path) -> None:
    fake = _build_fake_workspace(tmp_path)
    rc, out, _ = _run_retrieve(fake, "alpha")
    assert rc == 0
    paths = [r["path"] for r in out["ranked_results"]]
    assert any("project/alpha/" in p for p in paths)


def test_retrieve_hard_isolates_other_project_private(tmp_path: Path) -> None:
    """Charter anti-pattern #7 end-to-end: project alpha querying never
    surfaces project/beta/* in results; beta paths land in skipped_paths
    with reason=tenancy_reconciliation_failed."""
    fake = _build_fake_workspace(tmp_path)
    rc, out, _ = _run_retrieve(fake, "alpha")
    assert rc == 0
    result_paths = [r["path"] for r in out["ranked_results"]]
    assert not any("project/beta/" in p for p in result_paths), \
        "FAIL: beta files leaked into alpha's results — Charter #7 violation"
    skipped = out["routing_report"]["skipped_paths"]
    beta_skipped = [s for s in skipped if "project/beta/" in s["path"]]
    assert len(beta_skipped) >= 1
    for s in beta_skipped:
        assert s["reason"] == "tenancy_reconciliation_failed"


def test_retrieve_excludes_quarantine(tmp_path: Path) -> None:
    fake = _build_fake_workspace(tmp_path)
    rc, out, _ = _run_retrieve(fake, "alpha")
    assert rc == 0
    paths = [r["path"] for r in out["ranked_results"]]
    assert not any("_quarantine/" in p for p in paths)


def test_retrieve_excludes_rejected_and_superseded(tmp_path: Path) -> None:
    fake = _build_fake_workspace(tmp_path)
    rc, out, _ = _run_retrieve(fake, "alpha")
    assert rc == 0
    paths = [r["path"] for r in out["ranked_results"]]
    assert not any("cross_project/rejected/" in p for p in paths)
    assert not any("cross_project/superseded/" in p for p in paths)


def test_retrieve_excludes_unapproved_candidates(tmp_path: Path) -> None:
    fake = _build_fake_workspace(tmp_path)
    rc, out, _ = _run_retrieve(fake, "alpha")
    assert rc == 0
    paths = [r["path"] for r in out["ranked_results"]]
    assert not any("cross_project/candidates/" in p for p in paths)


def test_retrieve_includes_approved_cross_project(tmp_path: Path) -> None:
    fake = _build_fake_workspace(tmp_path)
    rc, out, _ = _run_retrieve(fake, "alpha")
    assert rc == 0
    paths = [r["path"] for r in out["ranked_results"]]
    assert any("cross_project/approved_patterns/" in p for p in paths)


def test_retrieve_current_project_outscores_approved_cross(tmp_path: Path) -> None:
    """Default boost ordering: current_project (1.5) > os (1.0) > approved (0.8)."""
    fake = _build_fake_workspace(tmp_path)
    rc, out, _ = _run_retrieve(fake, "alpha")
    assert rc == 0
    by_scope = {r["scope"]: r["score"] for r in out["ranked_results"]}
    if "current_project" in by_scope and "approved_cross_project" in by_scope:
        assert by_scope["current_project"] >= by_scope["approved_cross_project"]


def test_retrieve_rejects_uppercase_project_id(tmp_path: Path) -> None:
    fake = _build_fake_workspace(tmp_path)
    rc, _, err = _run_retrieve(fake, "Alpha")
    assert rc == 2
    assert "lower_snake_case" in err


def test_retrieve_rejects_missing_policy(tmp_path: Path) -> None:
    fake = _build_fake_workspace(tmp_path)
    (fake / "ltm/retrieval_policy.yaml").unlink()
    rc, _, err = _run_retrieve(fake, "alpha")
    assert rc == 2
    assert "policy" in err.lower()


def test_dryrun_emits_empty_results(tmp_path: Path) -> None:
    fake = _build_fake_workspace(tmp_path)
    rc, out, _ = _run_dryrun(fake, "alpha")
    assert rc == 0
    assert out["results"] == []
    assert out["skipped_paths"] == []
    assert out["calling_project_id"] == "alpha"
    assert "current_project" in out["scopes_included"]


def test_routing_report_skipped_paths_carry_reason_enum(tmp_path: Path) -> None:
    """Audit guarantee: every skipped_paths[] entry has a reason from
    the locked enum (no free-form strings)."""
    fake = _build_fake_workspace(tmp_path)
    rc, out, _ = _run_retrieve(fake, "alpha")
    assert rc == 0
    valid = {"tenancy_reconciliation_failed", "scope_excluded",
             "schema_invalid", "missing_evidence_ref"}
    for s in out["routing_report"]["skipped_paths"]:
        assert s["reason"] in valid


def test_retrieve_help_smoke(tmp_path: Path) -> None:
    """--help must not import-error; smoke for F11/F12-style fast-gate use."""
    fake = _build_fake_workspace(tmp_path)
    r = subprocess.run(
        [sys.executable,
         str(fake / "scripts/ltm/retrieve_with_routing.py"), "--help"],
        capture_output=True, text=True, timeout=10,
    )
    assert r.returncode == 0
    assert "--query" in r.stdout
    assert "--project-id" in r.stdout
