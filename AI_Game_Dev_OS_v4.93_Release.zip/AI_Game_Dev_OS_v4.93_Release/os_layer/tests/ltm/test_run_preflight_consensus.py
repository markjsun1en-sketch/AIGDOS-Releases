"""test_run_preflight_consensus.py — v4.91 B5B c5.

Lifecycle integration tests for scripts/ltm/run_preflight_consensus.py
(both sub-commands: init-stub + finalize). Mirrors the
test_promotion_lifecycle_roundtrip.py shape from B5 c5: tmp_path
fixture + subprocess invocation + 3-artifact assertions.

Layer 1. No project names. Fixtures use 'sample_alpha' / 'plan_xyz'.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
RPC_CLI = REPO_ROOT / "scripts" / "ltm" / "run_preflight_consensus.py"


# ----------------------------------------------------------------------
# Fixtures
# ----------------------------------------------------------------------


@pytest.fixture
def isolated_ltm(tmp_path: Path) -> Path:
    """Build a fake LTM root with preflight skeleton + policy."""
    ltm_root = tmp_path / "ltm"
    (ltm_root / "preflight" / "cases").mkdir(parents=True)
    (ltm_root / "preflight" / "metrics").mkdir()
    (ltm_root / "preflight" / "pattern_candidates").mkdir()
    # Use the live policy file (Layer 1 default).
    shutil.copy(
        REPO_ROOT / "ltm" / "preflight_policy.yaml",
        ltm_root / "preflight_policy.yaml",
    )
    return ltm_root


@pytest.fixture
def major_plan_yaml(tmp_path: Path) -> Path:
    """Write a minimal major-class update_plan YAML to tmp_path/plan.yaml."""
    plan = {
        "schema_version": "1.0.0",
        "plan_id": "plan_sample_alpha_v490_to_v500",
        "project_id": "sample_alpha",
        "from_version": "4.90.0",
        "to_version": "5.0.0",
        "update_class": "major",
        "generated_at": "2026-05-22T03:00:00Z",
        "actions": [
            {"step_id": "step_01", "kind": "run_b5b_preflight",
             "description": "run", "blocking": True},
        ],
        "preflight_required": True,
        "preflight_triggers": ["major_version_bump"],
        "deferred": False,
    }
    import yaml  # type: ignore
    p = tmp_path / "plan.yaml"
    p.write_text(yaml.safe_dump(plan, sort_keys=False), encoding="utf-8")
    return p


@pytest.fixture
def minor_plan_yaml(tmp_path: Path) -> Path:
    """A minor-class plan with preflight_required=false."""
    plan = {
        "schema_version": "1.0.0",
        "plan_id": "plan_sample_alpha_minor",
        "project_id": "sample_alpha",
        "from_version": "4.91.0",
        "to_version": "4.91.1",
        "update_class": "hotfix",
        "generated_at": "2026-05-22T03:00:00Z",
        "actions": [
            {"step_id": "step_01", "kind": "refresh_mount_fingerprint",
             "description": "refresh", "blocking": False},
        ],
        "preflight_required": False,
        "preflight_triggers": [],
        "deferred": False,
    }
    import yaml  # type: ignore
    p = tmp_path / "plan_minor.yaml"
    p.write_text(yaml.safe_dump(plan, sort_keys=False), encoding="utf-8")
    return p


def _run(*args: str) -> subprocess.CompletedProcess:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return subprocess.run(
        [sys.executable, str(RPC_CLI), *args],
        capture_output=True, text=True, env=env, timeout=30,
    )


# ----------------------------------------------------------------------
# init-stub tests
# ----------------------------------------------------------------------


def test_init_stub_writes_deferred_pending_case(isolated_ltm, major_plan_yaml):
    cp = _run("init-stub", "--plan", str(major_plan_yaml),
              "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp.returncode == 0, cp.stderr
    out = json.loads(cp.stdout)
    assert out["status"] == "stub_written"
    assert out["case_id"].startswith("pf_case_plan_sample_alpha_")
    assert out["trigger"] == "major_version_bump"

    cases = list((isolated_ltm / "preflight" / "cases").glob("pf_case_*.json"))
    assert len(cases) == 1
    case = json.loads(cases[0].read_text(encoding="utf-8"))
    assert case["consensus"]["outcome"] == "deferred"
    assert case["consensus"]["decided_by"] == "pending"
    assert case["subject"]["kind"] == "core_update_plan"


def test_init_stub_idempotent_on_existing_case(isolated_ltm, major_plan_yaml):
    cp1 = _run("init-stub", "--plan", str(major_plan_yaml),
               "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp1.returncode == 0
    cp2 = _run("init-stub", "--plan", str(major_plan_yaml),
               "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp2.returncode == 0
    assert json.loads(cp2.stdout)["status"] == "already_stubbed"


def test_init_stub_skips_when_preflight_not_required(isolated_ltm, minor_plan_yaml):
    cp = _run("init-stub", "--plan", str(minor_plan_yaml),
              "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp.returncode == 0
    out = json.loads(cp.stdout)
    assert out["status"] == "no_preflight"
    assert not list((isolated_ltm / "preflight" / "cases").glob("pf_case_*.json"))


def test_init_stub_missing_plan_file_returns_4(isolated_ltm, tmp_path):
    cp = _run("init-stub", "--plan", str(tmp_path / "nonexistent.yaml"),
              "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp.returncode == 4, cp.stderr
    assert "not found" in cp.stderr.lower()


def test_init_stub_missing_cases_dir_returns_2(tmp_path, major_plan_yaml):
    bad_ltm = tmp_path / "ltm_bad"
    bad_ltm.mkdir()
    cp = _run("init-stub", "--plan", str(major_plan_yaml),
              "--ltm-root", str(bad_ltm), "--format", "json")
    assert cp.returncode == 2, cp.stderr
    assert "missing" in cp.stderr.lower()


def test_init_stub_case_id_pattern_matches_schema(isolated_ltm, major_plan_yaml):
    """case_id must match preflight_case.schema.json pattern."""
    import re
    cp = _run("init-stub", "--plan", str(major_plan_yaml),
              "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp.returncode == 0
    case_id = json.loads(cp.stdout)["case_id"]
    assert re.match(r"^pf_case_[a-z0-9_]{3,120}$", case_id), case_id


def test_init_stub_output_validates_against_schema(isolated_ltm, major_plan_yaml):
    """The deferred stub MUST be valid against preflight_case.schema.json."""
    import jsonschema  # type: ignore
    cp = _run("init-stub", "--plan", str(major_plan_yaml),
              "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp.returncode == 0
    case_path = next((isolated_ltm / "preflight" / "cases").glob("pf_case_*.json"))
    case = json.loads(case_path.read_text(encoding="utf-8"))
    schema = json.loads(
        (REPO_ROOT / "schemas" / "ltm" / "preflight_case.schema.json")
        .read_text(encoding="utf-8")
    )
    jsonschema.validate(case, schema)


# ----------------------------------------------------------------------
# finalize gate-violation tests
# ----------------------------------------------------------------------


def _stub(isolated_ltm: Path, major_plan_yaml: Path) -> Path:
    cp = _run("init-stub", "--plan", str(major_plan_yaml),
              "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp.returncode == 0
    return next((isolated_ltm / "preflight" / "cases").glob("pf_case_*.json"))


@pytest.mark.parametrize("forbidden", [
    "auto", "system", "agent", "automation", "robot", "ci",
    "majority", "consensus", "vote", "tally",
])
def test_finalize_refuses_forbidden_decider(isolated_ltm, major_plan_yaml, forbidden):
    case = _stub(isolated_ltm, major_plan_yaml)
    cp = _run("finalize", "--case", str(case),
              "--decided-by", forbidden, "--outcome", "approved",
              "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp.returncode == 1
    out = json.loads(cp.stdout)
    assert out["status"] == "gate_violation"
    assert any("forbidden_deciders" in v for v in out["violations"])


@pytest.mark.parametrize("outcome", ["rejected", "deferred"])
def test_finalize_refuses_missing_rationale_for_non_approved(
    isolated_ltm, major_plan_yaml, outcome
):
    case = _stub(isolated_ltm, major_plan_yaml)
    cp = _run("finalize", "--case", str(case),
              "--decided-by", "ep", "--outcome", outcome,
              "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp.returncode == 1
    out = json.loads(cp.stdout)
    assert any("rationale" in v.lower() for v in out["violations"])


def test_finalize_refuses_decided_by_too_short(isolated_ltm, major_plan_yaml):
    case = _stub(isolated_ltm, major_plan_yaml)
    cp = _run("finalize", "--case", str(case),
              "--decided-by", "e", "--outcome", "approved",
              "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp.returncode == 1
    out = json.loads(cp.stdout)
    assert any("length" in v.lower() or "match" in v.lower()
               for v in out["violations"])


def test_finalize_refuses_decided_by_with_uppercase(isolated_ltm, major_plan_yaml):
    case = _stub(isolated_ltm, major_plan_yaml)
    cp = _run("finalize", "--case", str(case),
              "--decided-by", "EP", "--outcome", "approved",
              "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp.returncode == 1


def test_finalize_missing_case_returns_4(isolated_ltm, tmp_path):
    cp = _run("finalize", "--case", str(tmp_path / "nonexistent.json"),
              "--decided-by", "ep", "--outcome", "approved",
              "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp.returncode == 4


# ----------------------------------------------------------------------
# finalize success path
# ----------------------------------------------------------------------


def test_finalize_approved_writes_three_artifacts(isolated_ltm, major_plan_yaml):
    case = _stub(isolated_ltm, major_plan_yaml)
    cp = _run("finalize", "--case", str(case),
              "--decided-by", "ep", "--outcome", "approved",
              "--rationale", "reviewed.", "--elapsed-seconds", "120.5",
              "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp.returncode == 0, cp.stderr
    out = json.loads(cp.stdout)
    assert out["status"] == "finalized"

    # Case file: outcome / decided_by updated.
    case_data = json.loads(case.read_text(encoding="utf-8"))
    assert case_data["consensus"]["outcome"] == "approved"
    assert case_data["consensus"]["decided_by"] == "ep"
    assert case_data["consensus"]["rationale"] == "reviewed."

    # Metric file written; matches case_ref pattern.
    metrics = list((isolated_ltm / "preflight" / "metrics").glob("pf_metric_*.json"))
    assert len(metrics) == 1
    m = json.loads(metrics[0].read_text(encoding="utf-8"))
    assert m["outcome"] == "approved"
    assert m["elapsed_seconds"] == 120.5
    assert m["consulted_role_count"] >= 1
    assert m["case_ref"].startswith("ltm/preflight/cases/pf_case_")

    # Ledger sidecar written; event_type const-disjoint.
    ledger_path = case.with_name(case.stem + ".consensus.json")
    assert ledger_path.is_file()
    ld = json.loads(ledger_path.read_text(encoding="utf-8"))
    assert ld["event_type"] == "consensus_finalized"
    assert ld["ledger_id"].startswith("preflight_consensus_")
    assert ld["decided_by"] == "ep"


def test_finalize_approved_omits_rationale_in_ledger_when_absent(
    isolated_ltm, major_plan_yaml
):
    case = _stub(isolated_ltm, major_plan_yaml)
    cp = _run("finalize", "--case", str(case),
              "--decided-by", "ep", "--outcome", "approved",
              "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp.returncode == 0
    ledger_path = case.with_name(case.stem + ".consensus.json")
    ld = json.loads(ledger_path.read_text(encoding="utf-8"))
    assert "rationale" not in ld


def test_finalize_idempotent_on_already_finalized(isolated_ltm, major_plan_yaml):
    case = _stub(isolated_ltm, major_plan_yaml)
    cp1 = _run("finalize", "--case", str(case),
               "--decided-by", "ep", "--outcome", "approved",
               "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp1.returncode == 0
    cp2 = _run("finalize", "--case", str(case),
               "--decided-by", "ep", "--outcome", "approved",
               "--ltm-root", str(isolated_ltm), "--format", "json")
    assert cp2.returncode == 0
    assert json.loads(cp2.stdout)["status"] == "already_finalized"


@pytest.mark.parametrize("outcome", ["approved", "rejected", "deferred"])
def test_finalize_all_three_outcomes_produce_valid_artifacts(
    isolated_ltm, major_plan_yaml, outcome, tmp_path
):
    """Every outcome value lands schema-valid case + metric + ledger."""
    import jsonschema  # type: ignore

    case = _stub(isolated_ltm, major_plan_yaml)
    args = ["finalize", "--case", str(case),
            "--decided-by", "ep", "--outcome", outcome,
            "--ltm-root", str(isolated_ltm), "--format", "json"]
    if outcome != "approved":
        args += ["--rationale", "needs more eyes"]
    cp = _run(*args)
    assert cp.returncode == 0, cp.stderr

    # Validate all 3 artifacts.
    for fname, payload_path in [
        ("preflight_case.schema.json", case),
        ("preflight_metric.schema.json",
         next((isolated_ltm / "preflight" / "metrics").glob("pf_metric_*.json"))),
        ("preflight_consensus_event_ledger.schema.json",
         case.with_name(case.stem + ".consensus.json")),
    ]:
        schema = json.loads(
            (REPO_ROOT / "schemas" / "ltm" / fname).read_text(encoding="utf-8")
        )
        payload = json.loads(payload_path.read_text(encoding="utf-8"))
        jsonschema.validate(payload, schema)


# ----------------------------------------------------------------------
# Audit chain tests
# ----------------------------------------------------------------------


def test_ledger_id_family_disjoint_from_b5_family(isolated_ltm, major_plan_yaml):
    """preflight_consensus_* prefix never collides with promote_/reject_/supersede_."""
    case = _stub(isolated_ltm, major_plan_yaml)
    _run("finalize", "--case", str(case),
         "--decided-by", "ep", "--outcome", "approved",
         "--ltm-root", str(isolated_ltm), "--format", "json")
    ledger_path = case.with_name(case.stem + ".consensus.json")
    ld = json.loads(ledger_path.read_text(encoding="utf-8"))
    lid = ld["ledger_id"]
    assert lid.startswith("preflight_consensus_")
    for other_prefix in ("promote_", "reject_", "supersede_"):
        assert not lid.startswith(other_prefix), \
            f"ledger_id family collision: {lid} starts with {other_prefix}"


def test_ledger_event_type_const_disjoint(isolated_ltm, major_plan_yaml):
    case = _stub(isolated_ltm, major_plan_yaml)
    _run("finalize", "--case", str(case),
         "--decided-by", "ep", "--outcome", "approved",
         "--ltm-root", str(isolated_ltm), "--format", "json")
    ledger_path = case.with_name(case.stem + ".consensus.json")
    ld = json.loads(ledger_path.read_text(encoding="utf-8"))
    assert ld["event_type"] == "consensus_finalized"
    for other in ("promoted", "rejected", "superseded"):
        assert ld["event_type"] != other


def test_metric_consulted_role_count_matches_case(isolated_ltm, major_plan_yaml):
    """Charter audit-chain double-check: metric.consulted_role_count
    MUST equal len(case.consulted_roles)."""
    case = _stub(isolated_ltm, major_plan_yaml)
    _run("finalize", "--case", str(case),
         "--decided-by", "ep", "--outcome", "approved",
         "--ltm-root", str(isolated_ltm), "--format", "json")
    case_data = json.loads(case.read_text(encoding="utf-8"))
    metrics = list((isolated_ltm / "preflight" / "metrics").glob("pf_metric_*.json"))
    m = json.loads(metrics[0].read_text(encoding="utf-8"))
    assert m["consulted_role_count"] == len(case_data["consulted_roles"])


def test_ledger_policy_version_matches_yaml(isolated_ltm, major_plan_yaml):
    case = _stub(isolated_ltm, major_plan_yaml)
    _run("finalize", "--case", str(case),
         "--decided-by", "ep", "--outcome", "approved",
         "--ltm-root", str(isolated_ltm), "--format", "json")
    ledger_path = case.with_name(case.stem + ".consensus.json")
    ld = json.loads(ledger_path.read_text(encoding="utf-8"))
    # Live policy is version=1.0.0 per ltm/preflight_policy.yaml
    assert ld["policy_version"] == "1.0.0"
