"""test_capture_sprint_close.py — v4.90 Batch 5.5 Step 5.5.1.

Tests scripts/ltm/capture_sprint_close.py (GUIDED tier).

10 cases:
1. --help renders.
2. minimal happy-path input (with evidence_index) -> exit 0 + LTM entry written.
3. missing required field (project_id) -> exit 1.
4. project_id uppercase (regex violation) -> exit 1.
5. outcome enum violation -> exit 1.
6. captured_at format violation -> exit 1.
7. --dry-run renders body without writing capture.
8. extra_evidence rendered as YAML block in body.
9. --input - reads JSON from stdin.
10. nonexistent --input file -> exit 4.

Layer 1 (OS Spec). No project names. Generic placeholders only.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest


PKG_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = PKG_ROOT / "scripts" / "ltm" / "capture_sprint_close.py"


def _run(*args: str, stdin: str | None = None) -> tuple[int, str, str]:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(PKG_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        input=stdin,
        capture_output=True,
        text=True,
        env=env,
        timeout=30,
    )
    return proc.returncode, proc.stdout, proc.stderr


@pytest.fixture
def cleanup_acme_demo():
    """Real capture() writes to runtime.ltm._LTM_ROOT (ltm/project/<id>/).

    Tests that actually hit the engine MUST clean up after themselves
    so the test side-effects don't pollute the package tree.
    """
    target_dir = PKG_ROOT / "ltm" / "project" / "acme_demo"
    yield target_dir
    if target_dir.exists():
        import shutil

        shutil.rmtree(target_dir)


def _envelope(**overrides) -> dict:
    base = {
        "sprint_id": "sprint-12",
        "project_id": "acme_demo",
        "outcome": "PASS",
        "captured_at": "2026-05-12T10:30:00Z",
        "evidence_index": ["commit deadbeef"],
        "lessons": ["lesson A"],
    }
    base.update(overrides)
    return base


def _write_envelope(tmp_path: Path, env: dict, name: str = "closure.json") -> Path:
    p = tmp_path / name
    p.write_text(json.dumps(env), encoding="utf-8")
    return p


# --------------------------------------------------------------------------
# Case 1: --help renders
# --------------------------------------------------------------------------


def test_1_help_renders():
    rc, out, err = _run("--help")
    assert rc == 0
    assert "sprint_close" in out.lower() or "sprint-close" in out.lower()
    assert "--input" in out
    assert "--dry-run" in out


# --------------------------------------------------------------------------
# Case 2: minimal happy-path -> exit 0 + entry written
# --------------------------------------------------------------------------


def test_2_minimal_happy_path_writes_entry(tmp_path, cleanup_acme_demo):
    env_file = _write_envelope(tmp_path, _envelope())
    rc, out, err = _run("--input", str(env_file))
    assert rc == 0, f"stdout={out}\nstderr={err}"
    # capture() prints JSON result to stdout
    payload = json.loads(out)
    assert payload["gate"] == "passed"
    assert "captured_at" in payload
    # written file lands under ltm/project/acme_demo/<slug>.md
    assert cleanup_acme_demo.is_dir(), (
        f"expected {cleanup_acme_demo} to exist after capture"
    )
    files = list(cleanup_acme_demo.glob("*.md"))
    assert files, f"no .md written under {cleanup_acme_demo}"
    # Body contains the rendered sections.
    body = files[0].read_text(encoding="utf-8")
    assert "## Outcome" in body
    assert "PASS" in body
    assert "## Lessons" in body
    assert "lesson A" in body


# --------------------------------------------------------------------------
# Case 3: missing required field -> exit 1
# --------------------------------------------------------------------------


def test_3_missing_required_project_id(tmp_path):
    env = _envelope()
    env.pop("project_id")
    env_file = _write_envelope(tmp_path, env)
    rc, out, err = _run("--input", str(env_file))
    assert rc == 1, err
    assert "project_id" in err or "missing" in err.lower()


# --------------------------------------------------------------------------
# Case 4: project_id regex violation (uppercase)
# --------------------------------------------------------------------------


def test_4_project_id_uppercase_rejected(tmp_path):
    env_file = _write_envelope(tmp_path, _envelope(project_id="Acme_Demo"))
    rc, out, err = _run("--input", str(env_file))
    assert rc == 1, err
    assert "project_id" in err


# --------------------------------------------------------------------------
# Case 5: outcome enum violation
# --------------------------------------------------------------------------


def test_5_outcome_enum_violation(tmp_path):
    env_file = _write_envelope(tmp_path, _envelope(outcome="MAGIC_OK"))
    rc, out, err = _run("--input", str(env_file))
    assert rc == 1, err
    assert "outcome" in err


# --------------------------------------------------------------------------
# Case 6: captured_at format violation
# --------------------------------------------------------------------------


def test_6_captured_at_format_violation(tmp_path):
    env_file = _write_envelope(
        tmp_path,
        _envelope(captured_at="2026-05-12 10:30:00"),
    )
    rc, out, err = _run("--input", str(env_file))
    assert rc == 1, err
    assert "captured_at" in err


# --------------------------------------------------------------------------
# Case 7: --dry-run renders body, does NOT write capture
# --------------------------------------------------------------------------


def test_7_dry_run_renders_only(tmp_path):
    env_file = _write_envelope(tmp_path, _envelope(sprint_id="sprint-dry"))
    rc, out, err = _run("--input", str(env_file), "--dry-run")
    assert rc == 0, err
    assert "# Sprint sprint-dry closure" in out
    assert "## Outcome" in out
    # Nothing should be written into ltm/project/acme_demo for the dry-run
    # sprint-dry slug.
    written = PKG_ROOT / "ltm" / "project" / "acme_demo" / "sprint-sprint-dry-closure.md"
    assert not written.exists(), f"dry-run leaked: {written}"


# --------------------------------------------------------------------------
# Case 8: extra_evidence rendered as YAML block
# --------------------------------------------------------------------------


def test_8_extra_evidence_yaml_block(tmp_path):
    env = _envelope(extra_evidence={"velocity": 12, "burndown_pct": 95})
    env_file = _write_envelope(tmp_path, env)
    rc, out, err = _run("--input", str(env_file), "--dry-run")
    assert rc == 0, err
    assert "## Extra" in out
    assert "```yaml" in out
    assert "velocity: 12" in out
    assert "burndown_pct: 95" in out


# --------------------------------------------------------------------------
# Case 9: --input - reads from stdin
# --------------------------------------------------------------------------


def test_9_stdin_input_dry_run():
    payload = json.dumps(_envelope(sprint_id="sprint-stdin"))
    rc, out, err = _run("--input", "-", "--dry-run", stdin=payload)
    assert rc == 0, err
    assert "# Sprint sprint-stdin closure" in out


# --------------------------------------------------------------------------
# Case 10: nonexistent --input file -> exit 4
# --------------------------------------------------------------------------


def test_10_nonexistent_input_exits_4(tmp_path):
    missing = tmp_path / "no_such_closure.json"
    rc, out, err = _run("--input", str(missing))
    assert rc == 4, err
    assert "not found" in err.lower() or "no such" in err.lower()


# ==========================================================================
# v4.91 B6 c3/c5 — gate-blocked auto-emit candidate
# ==========================================================================


@pytest.fixture
def cleanup_b6_quarantine():
    """Track + clean candidates that B6 c3 auto-emit may produce."""
    qdir = PKG_ROOT / "ltm" / "_quarantine"
    before = set(qdir.glob("mc_*.json")) if qdir.is_dir() else set()
    # Also track *.quarantined.md side-effects from runtime.ltm.capture
    before_md = set(qdir.glob("*.quarantined.md")) if qdir.is_dir() else set()
    yield
    if qdir.is_dir():
        for f in (set(qdir.glob("mc_*.json")) - before):
            f.unlink()
        for f in (set(qdir.glob("*.quarantined.md")) - before_md):
            f.unlink()


def _b6_blocked_envelope() -> dict:
    """Sprint-close envelope WITHOUT evidence -> forces gate=blocked."""
    return {
        "sprint_id": "sprint-b6c5-blocked",
        "project_id": "acme_demo",
        "outcome": "FAIL",
        "captured_at": "2026-05-22T08:00:00Z",
        # NO evidence_index, NO closure_report_path
    }


def test_b6_gate_blocked_emits_candidate(tmp_path, cleanup_b6_quarantine):
    """B6 c3: gate=blocked path auto-emits memory_candidate envelope."""
    inp = _write_envelope(tmp_path, _b6_blocked_envelope())
    rc, out, err = _run("--input", str(inp))
    assert rc == 2, err  # EXIT_GATE_BLOCKED preserved
    assert "AUTO-EMIT: candidate" in err
    qdir = PKG_ROOT / "ltm" / "_quarantine"
    cand_files = list(qdir.glob("mc_*.json"))
    # at least one candidate matching this sprint marker
    matching = [
        f for f in cand_files
        if "sprint_close:acme_demo:sprint-b6c5-blocked"
        in f.read_text(encoding="utf-8")
    ]
    assert matching, "expected a candidate with sprint_close:acme_demo marker"


def test_b6_gate_blocked_candidate_has_correct_capture_source(
    tmp_path, cleanup_b6_quarantine
):
    inp = _write_envelope(tmp_path, _b6_blocked_envelope())
    _run("--input", str(inp))
    qdir = PKG_ROOT / "ltm" / "_quarantine"
    matching = [
        f for f in qdir.glob("mc_*.json")
        if "sprint_close:acme_demo:sprint-b6c5-blocked"
        in f.read_text(encoding="utf-8")
    ]
    assert matching
    env = json.loads(matching[0].read_text(encoding="utf-8"))
    assert env["capture_source"] == "sprint_close_failure"
    assert env["target_domain"] == "project"
    assert env["approver"] is None
    assert env["schema_version"] == "1.0.0"


def test_b6_gate_blocked_emit_idempotent(tmp_path, cleanup_b6_quarantine):
    """Re-running the same blocked sprint must NOT create another candidate."""
    inp = _write_envelope(tmp_path, _b6_blocked_envelope())
    _run("--input", str(inp))
    qdir = PKG_ROOT / "ltm" / "_quarantine"
    after_first = {
        f for f in qdir.glob("mc_*.json")
        if "sprint_close:acme_demo:sprint-b6c5-blocked"
        in f.read_text(encoding="utf-8")
    }
    _run("--input", str(inp))
    after_second = {
        f for f in qdir.glob("mc_*.json")
        if "sprint_close:acme_demo:sprint-b6c5-blocked"
        in f.read_text(encoding="utf-8")
    }
    assert after_first == after_second  # same set, no new candidate created


def test_b6_gate_blocked_envelope_passes_b6_c1_schema(
    tmp_path, cleanup_b6_quarantine
):
    """B6 c3 emitted envelope MUST validate against memory_candidate.schema.json."""
    import jsonschema  # type: ignore

    inp = _write_envelope(tmp_path, _b6_blocked_envelope())
    _run("--input", str(inp))
    qdir = PKG_ROOT / "ltm" / "_quarantine"
    matching = [
        f for f in qdir.glob("mc_*.json")
        if "sprint_close:acme_demo:sprint-b6c5-blocked"
        in f.read_text(encoding="utf-8")
    ]
    assert matching
    env = json.loads(matching[0].read_text(encoding="utf-8"))
    schema_path = PKG_ROOT / "schemas" / "ltm" / "memory_candidate.schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    jsonschema.validate(env, schema)


def test_b6_gate_passed_does_not_emit_candidate(
    tmp_path, cleanup_acme_demo, cleanup_b6_quarantine
):
    """When gate=passed, the auto-emit hook must NOT fire."""
    qdir = PKG_ROOT / "ltm" / "_quarantine"
    before = set(qdir.glob("mc_*.json")) if qdir.is_dir() else set()
    inp = _write_envelope(tmp_path, _envelope())  # has evidence_index
    rc, _, _ = _run("--input", str(inp))
    assert rc == 0
    after = set(qdir.glob("mc_*.json")) if qdir.is_dir() else set()
    assert after == before  # no new candidate from this sprint
