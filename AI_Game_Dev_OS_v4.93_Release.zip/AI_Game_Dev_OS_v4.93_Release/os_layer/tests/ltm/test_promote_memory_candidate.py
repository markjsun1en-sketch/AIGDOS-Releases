"""Tests for scripts/ltm/promote_memory_candidate.py — v4.90 Batch 8 Step 8.5.

Covers (12):
  1. Happy path: promote a complete failures candidate
  2. Approver missing -> gate violation (exit 1)
  3. evidence_ref empty -> gate violation
  4. Schema mismatch in proposed_entry -> gate violation
  5. proposed_body missing for failures domain -> gate violation
  6. proposed_body missing required H2 section -> gate violation
  7. Target domain dir missing -> exit 2
  8. Idempotent: re-running on already-promoted candidate is no-op exit 0
  9. cross_project requires >= 2 evidence_ref entries
 10. cross_project with 2 evidence_ref entries succeeds (no body required)
 11. candidate.target_domain mismatch with --to -> gate violation
 12. --format json emits structured payload on success

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.ltm.conftest import run_script


# --------------------------------------------------------------------------
# Fixtures
# --------------------------------------------------------------------------

@pytest.fixture
def ltm_root(tmp_path: Path) -> Path:
    """Create a synthetic LTM root with the 5 canonical domain dirs."""
    root = tmp_path / "ltm"
    for d in ("failures", "pattern", "os", "cross_project", "_quarantine"):
        (root / d).mkdir(parents=True)
    return root


def _full_failures_proposed_entry() -> dict:
    return {
        "captured_at": "2026-05-13T10:00:00Z",
        "actor": "kai",
        "gate": "passed",
        "evidence_ref": "commit deadbeef",
        "ff_id": "ff_2026_777",
        "failure_pattern": "test-failure-pattern",
        "fix_pattern": "test-fix-pattern",
        "schema_version": "1.0.0",
        "lifecycle_state": "active",
    }


def _full_body() -> str:
    return (
        "## Symptom\n\nSomething broke.\n\n"
        "## Root Cause\n\nA happened.\n\n"
        "## Fix\n\nDo B.\n\n"
        "## Lesson\n\nNote C.\n"
    )


def _write_candidate(
    quarantine: Path,
    candidate_id: str = "mc_2026_500",
    *,
    target_domain: str = "failures",
    evidence_ref: list[str] | None = None,
    proposed_entry: dict | None = None,
    proposed_body: str | None = None,
    approver=None,
) -> Path:
    body_default = _full_body() if target_domain == "failures" else ""
    candidate = {
        "candidate_id": candidate_id,
        "target_domain": target_domain,
        "source_path": "ltm/working/raw.md",
        "evidence_ref": evidence_ref if evidence_ref is not None else ["commit deadbeef"],
        "promotion_rationale": "Validated.",
        "proposed_entry": proposed_entry if proposed_entry is not None else _full_failures_proposed_entry(),
        "proposed_body": body_default if proposed_body is None else proposed_body,
        "created_at": "2026-05-13",
        "approver": approver,
        "schema_version": "1.0.0",
    }
    path = quarantine / f"{candidate_id}.json"
    path.write_text(json.dumps(candidate, indent=2) + "\n", encoding="utf-8")
    return path


# --------------------------------------------------------------------------
# 1. Happy path: failures
# --------------------------------------------------------------------------

def test_failures_happy_path(ltm_root):
    quarantine = ltm_root / "_quarantine"
    cand_path = _write_candidate(quarantine)
    result = run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_path),
        "--to", "failures",
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
    )
    result.expect(0)
    canonical = list((ltm_root / "failures").glob("*.md"))
    assert len(canonical) == 1
    content = canonical[0].read_text()
    assert "captured_at: 2026-05-13T10:00:00Z" in content
    assert "## Symptom" in content
    # ledger written
    assert (quarantine / "mc_2026_500.promoted.json").exists()
    # approver stamped on candidate
    cand = json.loads(cand_path.read_text())
    assert cand["approver"] == "kai"


# --------------------------------------------------------------------------
# 2. Approver missing
# --------------------------------------------------------------------------

def test_empty_approver_is_gate_violation(ltm_root):
    quarantine = ltm_root / "_quarantine"
    cand_path = _write_candidate(quarantine)
    result = run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_path),
        "--to", "failures",
        "--approver", "",
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)
    assert "approver" in result.stderr.lower()


# --------------------------------------------------------------------------
# 3. evidence_ref empty
# --------------------------------------------------------------------------

def test_empty_evidence_ref_is_gate_violation(ltm_root):
    quarantine = ltm_root / "_quarantine"
    cand_path = _write_candidate(quarantine, evidence_ref=[])
    result = run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_path),
        "--to", "failures",
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)
    assert "evidence_ref" in result.stderr


# --------------------------------------------------------------------------
# 4. Schema mismatch in proposed_entry
# --------------------------------------------------------------------------

def test_proposed_entry_schema_mismatch_blocks(ltm_root):
    quarantine = ltm_root / "_quarantine"
    bad_pe = _full_failures_proposed_entry()
    bad_pe["ff_id"] = "not_a_valid_id"  # pattern violation
    cand_path = _write_candidate(quarantine, proposed_entry=bad_pe)
    result = run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_path),
        "--to", "failures",
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)
    assert "ff_id" in result.stderr
    assert "pattern" in result.stderr


# --------------------------------------------------------------------------
# 5. proposed_body missing for failures
# --------------------------------------------------------------------------

def test_failures_requires_proposed_body(ltm_root):
    quarantine = ltm_root / "_quarantine"
    cand_path = _write_candidate(quarantine, proposed_body="")
    result = run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_path),
        "--to", "failures",
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)
    assert "proposed_body" in result.stderr


# --------------------------------------------------------------------------
# 6. proposed_body missing required H2 section
# --------------------------------------------------------------------------

def test_failures_body_missing_h2_blocks(ltm_root):
    quarantine = ltm_root / "_quarantine"
    bad_body = "## Symptom\n\nx\n\n## Fix\n\ny\n"  # missing Root Cause + Lesson
    cand_path = _write_candidate(quarantine, proposed_body=bad_body)
    result = run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_path),
        "--to", "failures",
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)
    assert "Root Cause" in result.stderr or "Lesson" in result.stderr


# --------------------------------------------------------------------------
# 7. Target domain dir missing -> exit 2
# --------------------------------------------------------------------------

def test_missing_target_domain_dir(ltm_root, tmp_path):
    quarantine = ltm_root / "_quarantine"
    cand_path = _write_candidate(quarantine)
    # Promote to a fresh ltm root that lacks the failures/ dir
    fresh_root = tmp_path / "fresh_ltm"
    fresh_root.mkdir()
    result = run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_path),
        "--to", "failures",
        "--approver", "kai",
        "--ltm-root", str(fresh_root),
    )
    result.expect(2)


# --------------------------------------------------------------------------
# 8. Idempotency: already-promoted candidate is no-op
# --------------------------------------------------------------------------

def test_idempotent_already_promoted(ltm_root):
    quarantine = ltm_root / "_quarantine"
    cand_path = _write_candidate(quarantine, approver="kai")
    result = run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_path),
        "--to", "failures",
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
    )
    result.expect(0)
    assert "already promoted" in result.stdout
    # No canonical entry should be written
    assert list((ltm_root / "failures").glob("*.md")) == []


# --------------------------------------------------------------------------
# 9. cross_project requires >= 2 evidence_ref entries
# --------------------------------------------------------------------------

def test_cross_project_single_evidence_blocks(ltm_root):
    quarantine = ltm_root / "_quarantine"
    cand_path = _write_candidate(
        quarantine,
        target_domain="cross_project",
        evidence_ref=["only-one"],
        proposed_body="",
    )
    result = run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_path),
        "--to", "cross_project",
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)
    assert "cross_project" in result.stderr
    assert "2 unique" in result.stderr


# --------------------------------------------------------------------------
# 10. cross_project with 2 evidence_ref entries succeeds
# --------------------------------------------------------------------------

def test_cross_project_multi_evidence_succeeds(ltm_root):
    quarantine = ltm_root / "_quarantine"
    cand_path = _write_candidate(
        quarantine,
        candidate_id="mc_2026_501",
        target_domain="cross_project",
        evidence_ref=["proj-A-citation", "proj-B-citation"],
        # proposed_entry for cross_project has no strict schema check
        proposed_entry={"title": "shared pattern", "schema_version": "1.0.0"},
        proposed_body="",
    )
    result = run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_path),
        "--to", "cross_project",
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
    )
    result.expect(0)
    # v4.91 B5 c2: cross_project promotions auto-migrate to the v3
    # approved_patterns/ sub-dir per EP Q1=A. The reader's backward
    # compatibility (B4 c3) classifies top-level cross_project/*.md as
    # scope=approved_cross_project, so existing v4.90 entries continue
    # to retrieve; new promotions land in the canonical sub-dir.
    assert list((ltm_root / "cross_project" / "approved_patterns").glob("*.md"))
    # And the legacy top-level path is empty for new promotions.
    assert not list((ltm_root / "cross_project").glob("*.md"))


# --------------------------------------------------------------------------
# 11. candidate.target_domain != --to
# --------------------------------------------------------------------------

def test_target_domain_mismatch_blocks(ltm_root):
    quarantine = ltm_root / "_quarantine"
    cand_path = _write_candidate(quarantine)  # target_domain=failures
    result = run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_path),
        "--to", "pattern",  # mismatch
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)
    assert "target_domain" in result.stderr


# --------------------------------------------------------------------------
# 12. --format json on success
# --------------------------------------------------------------------------

def test_json_format_success_payload(ltm_root):
    quarantine = ltm_root / "_quarantine"
    cand_path = _write_candidate(quarantine, candidate_id="mc_2026_502")
    result = run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_path),
        "--to", "failures",
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
        "--format", "json",
    )
    result.expect(0)
    payload = json.loads(result.stdout)
    assert payload["status"] == "promoted"
    assert payload["candidate_id"] == "mc_2026_502"
    assert payload["approver"] == "kai"
    assert "canonical_path" in payload
