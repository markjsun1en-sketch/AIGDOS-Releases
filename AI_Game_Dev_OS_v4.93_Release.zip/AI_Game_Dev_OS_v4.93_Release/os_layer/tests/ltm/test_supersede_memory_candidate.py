"""Tests for scripts/ltm/supersede_memory_candidate.py — v4.91 B5 c3.

Covers (12):
  1. Happy path: full supersede chain (promote then supersede)
  2. Forbidden approver 'ci' -> gate violation
  3. Empty superseded-by -> gate violation
  4. Missing superseded-entry -> exit 4
  5. Missing replacing-entry-ledger -> exit 4
  6. Replacing ledger event_type != 'promoted' -> exit 1 (audit chain lock)
  7. Replacing ledger ledger_id missing 'promote_' prefix -> exit 1
  8. Idempotent: re-run is no-op exit 0
  9. Audit retention: superseded entry lands in cross_project/superseded/
 10. Ledger ledger_id starts with 'supersede_' + cross-ref intact
 11. Ledger event_type const = 'superseded'
 12. --format json emits structured payload

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.ltm.conftest import run_script


# --------------------------------------------------------------------------
# Fixtures
# --------------------------------------------------------------------------

@pytest.fixture
def ltm_root(tmp_path: Path) -> Path:
    root = tmp_path / "ltm"
    for d in (
        "failures",
        "pattern",
        "os",
        "cross_project",
        "cross_project/approved_patterns",
        "cross_project/rejected",
        "cross_project/superseded",
        "_quarantine",
    ):
        (root / d).mkdir(parents=True, exist_ok=True)
    (root / "promotion_policy.yaml").write_text(
        "schema_version: \"1.0.0\"\n"
        "version: \"1.0.0-test\"\n"
        "thresholds:\n"
        "  cross_project_min_evidence_refs: 2\n"
        "approval:\n"
        "  mode: \"strict\"\n"
        "  forbidden_approvers: [auto, system, agent, automation, robot, ci]\n"
        "supersede:\n"
        "  must_reference_replacing_entry: true\n",
        encoding="utf-8",
    )
    return root


def _make_promote_ledger(ltm_root: Path, candidate_id: str = "mc_supersede_seed") -> Path:
    """Create a candidate, promote it, return path to .promoted.json ledger."""
    quarantine = ltm_root / "_quarantine"
    candidate = {
        "schema_version": "1.0.0",
        "candidate_id": candidate_id,
        "captured_at": "2026-05-21T15:00:00Z",
        "actor": "kai",
        "evidence_ref": ["alpha ref", "beta ref"],
        "target_domain": "cross_project",
        "proposed_entry": {
            "captured_at": "2026-05-21T15:00:00Z",
            "actor": "kai",
            "gate": "passed",
            "evidence_ref": "alpha + beta",
        },
        "proposed_body": (
            "## Symptom\n\nx\n\n## Root Cause\n\ny\n\n## Fix\n\nz\n\n## Lesson\n\nw\n"
        ),
    }
    cand_path = quarantine / f"{candidate_id}.json"
    cand_path.write_text(json.dumps(candidate, indent=2) + "\n", encoding="utf-8")
    run_script(
        "promote_memory_candidate.py",
        "--candidate", str(cand_path),
        "--to", "cross_project",
        "--approver", "kai",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    return cand_path.with_suffix(".promoted.json")


def _make_old_entry(ltm_root: Path, name: str = "2026-04-01_old.md") -> Path:
    p = ltm_root / "failures" / name
    p.write_text("# old failure entry\n", encoding="utf-8")
    return p


# --------------------------------------------------------------------------
# 1. Happy path
# --------------------------------------------------------------------------

def test_supersede_happy_path(ltm_root):
    promote_ledger = _make_promote_ledger(ltm_root)
    old = _make_old_entry(ltm_root)
    result = run_script(
        "supersede_memory_candidate.py",
        "--superseded-entry", str(old),
        "--replacing-entry-ledger", str(promote_ledger),
        "--superseded-by", "ep",
        "--rationale", "newer evidence 2026-05",
        "--ltm-root", str(ltm_root),
    )
    result.expect(0)
    superseded_dir = ltm_root / "cross_project" / "superseded"
    moved = list(superseded_dir.glob("*.md"))
    assert len(moved) == 1, f"expected 1 superseded md, got {moved}"
    ledger_files = list(superseded_dir.glob("*.superseded.json"))
    assert len(ledger_files) == 1
    ledger = json.loads(ledger_files[0].read_text())
    assert ledger["event_type"] == "superseded"
    assert ledger["ledger_id"].startswith("supersede_")
    assert ledger["replacing_entry_ledger_ref"].startswith("promote_")
    assert ledger["rationale"] == "newer evidence 2026-05"


# --------------------------------------------------------------------------
# 2. Forbidden approver
# --------------------------------------------------------------------------

@pytest.mark.parametrize("forbidden", ["auto", "ci", "automation"])
def test_supersede_forbidden_approver(ltm_root, forbidden):
    promote_ledger = _make_promote_ledger(ltm_root, f"mc_fb_{forbidden}_seed")
    old = _make_old_entry(ltm_root, f"2026-04-01_old_{forbidden}.md")
    result = run_script(
        "supersede_memory_candidate.py",
        "--superseded-entry", str(old),
        "--replacing-entry-ledger", str(promote_ledger),
        "--superseded-by", forbidden,
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)
    assert "forbidden" in result.stderr.lower()


# --------------------------------------------------------------------------
# 3. Empty superseded-by
# --------------------------------------------------------------------------

def test_supersede_empty_by(ltm_root):
    promote_ledger = _make_promote_ledger(ltm_root, "mc_empty_by_seed")
    old = _make_old_entry(ltm_root, "2026-04-01_old_empty.md")
    result = run_script(
        "supersede_memory_candidate.py",
        "--superseded-entry", str(old),
        "--replacing-entry-ledger", str(promote_ledger),
        "--superseded-by", "",
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)


# --------------------------------------------------------------------------
# 4. Missing superseded-entry
# --------------------------------------------------------------------------

def test_supersede_missing_superseded_entry(ltm_root):
    promote_ledger = _make_promote_ledger(ltm_root, "mc_missing_seed")
    result = run_script(
        "supersede_memory_candidate.py",
        "--superseded-entry", str(ltm_root / "failures" / "nope.md"),
        "--replacing-entry-ledger", str(promote_ledger),
        "--superseded-by", "ep",
        "--ltm-root", str(ltm_root),
    )
    # CLI returns non-zero on missing input file
    assert result.exit_code != 0
    assert "not found" in result.stderr.lower()


# --------------------------------------------------------------------------
# 5. Missing replacing ledger
# --------------------------------------------------------------------------

def test_supersede_missing_replacing_ledger(ltm_root):
    old = _make_old_entry(ltm_root, "2026-04-01_old_missing.md")
    result = run_script(
        "supersede_memory_candidate.py",
        "--superseded-entry", str(old),
        "--replacing-entry-ledger", str(ltm_root / "_quarantine" / "nope.promoted.json"),
        "--superseded-by", "ep",
        "--ltm-root", str(ltm_root),
    )
    assert result.exit_code != 0
    assert "not found" in result.stderr.lower()


# --------------------------------------------------------------------------
# 6. Replacing ledger event_type != 'promoted'
# --------------------------------------------------------------------------

def test_supersede_replacing_ledger_wrong_event_type(ltm_root):
    bogus = ltm_root / "_quarantine" / "bogus.promoted.json"
    bogus.write_text(json.dumps({
        "schema_version": "1.0.0",
        "ledger_id": "promote_bogus_20260521_000000",
        "candidate_id": "bogus",
        "event_type": "rejected",  # wrong
        "promoted_at": "2026-05-21T15:00:00Z",
        "promoted_by": "ep",
        "promoted_to_domain": "cross_project",
        "promoted_to_path": "/tmp/x.md",
        "policy_version": "1.0.0",
    }), encoding="utf-8")
    old = _make_old_entry(ltm_root, "2026-04-01_old_wrongtype.md")
    result = run_script(
        "supersede_memory_candidate.py",
        "--superseded-entry", str(old),
        "--replacing-entry-ledger", str(bogus),
        "--superseded-by", "ep",
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)


# --------------------------------------------------------------------------
# 7. Replacing ledger ledger_id wrong prefix
# --------------------------------------------------------------------------

def test_supersede_replacing_ledger_wrong_id_prefix(ltm_root):
    bogus = ltm_root / "_quarantine" / "bad_prefix.promoted.json"
    bogus.write_text(json.dumps({
        "schema_version": "1.0.0",
        "ledger_id": "reject_oops_20260521_000000",  # wrong prefix
        "candidate_id": "bogus2",
        "event_type": "promoted",
        "promoted_at": "2026-05-21T15:00:00Z",
        "promoted_by": "ep",
        "promoted_to_domain": "cross_project",
        "promoted_to_path": "/tmp/x.md",
        "policy_version": "1.0.0",
    }), encoding="utf-8")
    old = _make_old_entry(ltm_root, "2026-04-01_old_badprefix.md")
    result = run_script(
        "supersede_memory_candidate.py",
        "--superseded-entry", str(old),
        "--replacing-entry-ledger", str(bogus),
        "--superseded-by", "ep",
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)


# --------------------------------------------------------------------------
# 8. Idempotency
# --------------------------------------------------------------------------

def test_supersede_idempotent(ltm_root):
    promote_ledger = _make_promote_ledger(ltm_root, "mc_idem_seed")
    old = _make_old_entry(ltm_root, "2026-04-01_old_idem.md")
    args = [
        "supersede_memory_candidate.py",
        "--superseded-entry", str(old),
        "--replacing-entry-ledger", str(promote_ledger),
        "--superseded-by", "ep",
        "--ltm-root", str(ltm_root),
    ]
    run_script(*args).expect(0)
    # Second run: target already moved
    result = run_script(*args)
    result.expect(0)


# --------------------------------------------------------------------------
# 9. Audit retention
# --------------------------------------------------------------------------

def test_supersede_audit_retention(ltm_root):
    promote_ledger = _make_promote_ledger(ltm_root, "mc_audit_seed")
    old = _make_old_entry(ltm_root, "2026-04-01_old_audit.md")
    run_script(
        "supersede_memory_candidate.py",
        "--superseded-entry", str(old),
        "--replacing-entry-ledger", str(promote_ledger),
        "--superseded-by", "ep",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    superseded_dir = ltm_root / "cross_project" / "superseded"
    assert (superseded_dir / "2026-04-01_old_audit.md").exists()
    # Original location empty (moved, not copied)
    assert not old.exists()


# --------------------------------------------------------------------------
# 10. Cross-ref audit chain intact
# --------------------------------------------------------------------------

def test_supersede_cross_ref_audit_chain(ltm_root):
    promote_ledger_path = _make_promote_ledger(ltm_root, "mc_xref_seed")
    promote_ledger = json.loads(promote_ledger_path.read_text())
    old = _make_old_entry(ltm_root, "2026-04-01_old_xref.md")
    run_script(
        "supersede_memory_candidate.py",
        "--superseded-entry", str(old),
        "--replacing-entry-ledger", str(promote_ledger_path),
        "--superseded-by", "ep",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    superseded_dir = ltm_root / "cross_project" / "superseded"
    ledger_files = list(superseded_dir.glob("*.superseded.json"))
    assert ledger_files
    sup_ledger = json.loads(ledger_files[0].read_text())
    assert sup_ledger["replacing_entry_ledger_ref"] == promote_ledger["ledger_id"]


# --------------------------------------------------------------------------
# 11. event_type const
# --------------------------------------------------------------------------

def test_supersede_event_type_const(ltm_root):
    promote_ledger = _make_promote_ledger(ltm_root, "mc_etype_seed")
    old = _make_old_entry(ltm_root, "2026-04-01_old_etype.md")
    run_script(
        "supersede_memory_candidate.py",
        "--superseded-entry", str(old),
        "--replacing-entry-ledger", str(promote_ledger),
        "--superseded-by", "ep",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    superseded_dir = ltm_root / "cross_project" / "superseded"
    sup = json.loads(list(superseded_dir.glob("*.superseded.json"))[0].read_text())
    assert sup["event_type"] == "superseded"


# --------------------------------------------------------------------------
# 12. JSON format
# --------------------------------------------------------------------------

def test_supersede_json_format(ltm_root):
    promote_ledger = _make_promote_ledger(ltm_root, "mc_json_seed")
    old = _make_old_entry(ltm_root, "2026-04-01_old_json.md")
    result = run_script(
        "supersede_memory_candidate.py",
        "--superseded-entry", str(old),
        "--replacing-entry-ledger", str(promote_ledger),
        "--superseded-by", "ep",
        "--format", "json",
        "--ltm-root", str(ltm_root),
    )
    result.expect(0)
    payload = json.loads(result.stdout)
    assert payload.get("status") in ("superseded", "ok", "success")
