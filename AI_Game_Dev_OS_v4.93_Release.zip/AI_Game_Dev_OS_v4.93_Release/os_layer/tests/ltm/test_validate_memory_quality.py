"""Tests for scripts/ltm/validate_memory_quality.py — v4.90 Batch 8 Step 8.6.

Covers (10):
  1. failures/ all-clean -> 0 failed, 0 issues, exit 0
  2. failures/ entry missing evidence_ref -> error issue, exit 1
  3. failures/ entry with bad ff schema (e.g. bad ff_id pattern) -> schema_invalid
  4. lifecycle_state invalid -> lifecycle_invalid issue
  5. lifecycle_state=superseded but no superseded_by -> lifecycle_companion_missing
  6. working/ entry older than threshold -> age_expired warning, but exit 0 (warning != error)
  7. working/ entry younger than threshold -> no age issue
  8. Empty dir -> exit 0 with clean report
  9. Missing dir -> exit 4
 10. JSON output validates against memory_quality_report schema

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from datetime import date, datetime, timedelta
from pathlib import Path

import pytest

from tests.ltm.conftest import run_script


def _write_fm(path: Path, fm: dict, body: str = ""):
    parts = ["---"]
    for k, v in fm.items():
        if isinstance(v, list):
            rendered = "[" + ", ".join(str(x) for x in v) + "]"
            parts.append(f"{k}: {rendered}")
        else:
            parts.append(f"{k}: {v}")
    parts.append("---")
    parts.append("")
    parts.append(body)
    path.write_text("\n".join(parts), encoding="utf-8")


def _full_failures_fm() -> dict:
    return {
        "captured_at": "2026-05-13T10:00:00Z",
        "actor": "kai",
        "gate": "passed",
        "evidence_ref": "commit deadbeef",
        "ff_id": "ff_2026_888",
        "failure_pattern": "test-pattern",
        "fix_pattern": "test-fix",
        "schema_version": "1.0.0",
        "lifecycle_state": "active",
    }


def _full_failures_body() -> str:
    return (
        "## Symptom\n\nx\n\n"
        "## Root Cause\n\ny\n\n"
        "## Fix\n\nz\n\n"
        "## Lesson\n\nw\n"
    )


# --------------------------------------------------------------------------
# 1. failures/ all clean
# --------------------------------------------------------------------------

def test_failures_all_clean(tmp_path: Path):
    target = tmp_path / "failures"
    target.mkdir()
    _write_fm(target / "2026-05-13_ok.md", _full_failures_fm(), _full_failures_body())
    result = run_script(
        "validate_memory_quality.py",
        "--dir", str(target),
        "--format", "json",
    )
    result.expect(0)
    payload = json.loads(result.stdout)
    assert payload["failed"] == 0
    assert payload["passed"] == 1
    assert payload["issues"] == []


# --------------------------------------------------------------------------
# 2. evidence_ref missing
# --------------------------------------------------------------------------

def test_evidence_ref_missing_is_error(tmp_path: Path):
    target = tmp_path / "failures"
    target.mkdir()
    fm = _full_failures_fm()
    fm.pop("evidence_ref")
    _write_fm(target / "no_evidence.md", fm, _full_failures_body())
    result = run_script(
        "validate_memory_quality.py",
        "--dir", str(target),
        "--format", "json",
    )
    result.expect(1)
    payload = json.loads(result.stdout)
    rules = {i["rule"] for i in payload["issues"]}
    assert "evidence_ref_missing" in rules


# --------------------------------------------------------------------------
# 3. failures/ ff schema invalid
# --------------------------------------------------------------------------

def test_failures_schema_invalid_flagged(tmp_path: Path):
    target = tmp_path / "failures"
    target.mkdir()
    fm = _full_failures_fm()
    fm["ff_id"] = "bogus_id"  # pattern violation
    _write_fm(target / "bad_ff_id.md", fm, _full_failures_body())
    result = run_script(
        "validate_memory_quality.py",
        "--dir", str(target),
        "--format", "json",
    )
    result.expect(1)
    payload = json.loads(result.stdout)
    rules = [i["rule"] for i in payload["issues"]]
    assert "schema_invalid" in rules


# --------------------------------------------------------------------------
# 4. lifecycle_state invalid
# --------------------------------------------------------------------------

def test_invalid_lifecycle_state_flagged(tmp_path: Path):
    target = tmp_path / "pattern"
    target.mkdir()
    _write_fm(
        target / "x.md",
        {
            "captured_at": "2026-05-13T10:00:00Z",
            "evidence_ref": "ev",
            "lifecycle_state": "rolled-back",  # invalid
        },
    )
    result = run_script(
        "validate_memory_quality.py",
        "--dir", str(target),
        "--format", "json",
    )
    result.expect(1)
    payload = json.loads(result.stdout)
    rules = [i["rule"] for i in payload["issues"]]
    assert "lifecycle_invalid" in rules


# --------------------------------------------------------------------------
# 5. lifecycle companion missing
# --------------------------------------------------------------------------

def test_lifecycle_companion_missing_flagged(tmp_path: Path):
    target = tmp_path / "pattern"
    target.mkdir()
    _write_fm(
        target / "x.md",
        {
            "captured_at": "2026-05-13T10:00:00Z",
            "evidence_ref": "ev",
            "lifecycle_state": "superseded",
            # superseded_by missing
        },
    )
    result = run_script(
        "validate_memory_quality.py",
        "--dir", str(target),
        "--format", "json",
    )
    result.expect(1)
    payload = json.loads(result.stdout)
    rules = [i["rule"] for i in payload["issues"]]
    assert "lifecycle_companion_missing" in rules


# --------------------------------------------------------------------------
# 6. working/ age_expired -> warning, exit 0
# --------------------------------------------------------------------------

def test_working_age_expired_warns(tmp_path: Path):
    target = tmp_path / "working"
    target.mkdir()
    old_date = date.today() - timedelta(days=45)
    _write_fm(
        target / "old.md",
        {
            "captured_at": f"{old_date.isoformat()}T00:00:00Z",
            "evidence_ref": "ev",
        },
    )
    result = run_script(
        "validate_memory_quality.py",
        "--dir", str(target),
        "--working-age-days", "30",
        "--format", "json",
    )
    result.expect(0)  # warning != error
    payload = json.loads(result.stdout)
    issues = payload["issues"]
    assert any(i["rule"] == "age_expired" and i["severity"] == "warning" for i in issues)
    # passed should still equal total because severity is warning not error
    assert payload["failed"] == 0


# --------------------------------------------------------------------------
# 7. working/ within threshold -> no age issue
# --------------------------------------------------------------------------

def test_working_within_age_threshold_clean(tmp_path: Path):
    target = tmp_path / "working"
    target.mkdir()
    fresh_date = date.today() - timedelta(days=5)
    _write_fm(
        target / "fresh.md",
        {
            "captured_at": f"{fresh_date.isoformat()}T00:00:00Z",
            "evidence_ref": "ev",
        },
    )
    result = run_script(
        "validate_memory_quality.py",
        "--dir", str(target),
        "--working-age-days", "30",
        "--format", "json",
    )
    result.expect(0)
    payload = json.loads(result.stdout)
    rules = [i["rule"] for i in payload["issues"]]
    assert "age_expired" not in rules


# --------------------------------------------------------------------------
# 8. Empty dir
# --------------------------------------------------------------------------

def test_empty_dir_clean_report(tmp_path: Path):
    target = tmp_path / "failures"
    target.mkdir()
    result = run_script(
        "validate_memory_quality.py",
        "--dir", str(target),
        "--format", "json",
    )
    result.expect(0)
    payload = json.loads(result.stdout)
    assert payload["total_entries"] == 0
    assert payload["passed"] == 0
    assert payload["failed"] == 0


# --------------------------------------------------------------------------
# 9. Missing dir
# --------------------------------------------------------------------------

def test_missing_dir_exits_input_missing(tmp_path: Path):
    bogus = tmp_path / "nope"
    result = run_script(
        "validate_memory_quality.py",
        "--dir", str(bogus),
        "--format", "json",
    )
    result.expect(4)


# --------------------------------------------------------------------------
# 10. Output validates against memory_quality_report schema
# --------------------------------------------------------------------------

def test_output_validates_against_report_schema(tmp_path: Path):
    jsonschema = pytest.importorskip("jsonschema")
    target = tmp_path / "failures"
    target.mkdir()
    _write_fm(target / "ok.md", _full_failures_fm(), _full_failures_body())
    result = run_script(
        "validate_memory_quality.py",
        "--dir", str(target),
        "--format", "json",
    )
    result.expect(0)
    payload = json.loads(result.stdout)
    schema_path = (
        Path(__file__).resolve().parents[2]
        / "schemas/ltm/memory_quality_report.schema.json"
    )
    schema = json.loads(schema_path.read_text())
    jsonschema.validate(instance=payload, schema=schema)
