"""test_capture_evolution_proposal.py — v4.91 B6 c5.

Lifecycle integration tests for scripts/ltm/capture_evolution_proposal.py
(both rails: --proposal markdown / --proposal-id state.json).
Mirrors test_run_preflight_consensus.py shape from B5B c5: tmp_path
fixture + subprocess invocation + 3-artifact assertions.

Layer 1. No project names. Fixtures use 'evo_2026_999_*' / proposal_kind='architecture_principle'.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
CEP_CLI = REPO_ROOT / "scripts" / "ltm" / "capture_evolution_proposal.py"
SCHEMA_PATH = REPO_ROOT / "schemas" / "ltm" / "memory_candidate.schema.json"


@pytest.fixture
def isolated_quarantine(tmp_path: Path) -> Path:
    out_dir = tmp_path / "_quarantine"
    out_dir.mkdir(parents=True)
    return out_dir


@pytest.fixture
def proposal_md(tmp_path: Path) -> Path:
    """Synthetic proposal markdown matching the v4.91 evo_*.md shape."""
    p = tmp_path / "evo_2026_999_synthetic_test_principle.md"
    p.write_text(
        "---\n"
        'schema_version: "1.1.0"\n'
        'proposal_id: "evo_2026_999"\n'
        'proposal_kind: "architecture_principle"\n'
        'state: "accepted"\n'
        'title: "Synthetic test principle for B6 c5"\n'
        'submitted_at: "2026-05-22T03:00:00Z"\n'
        'submitted_by: "test_actor"\n'
        'summary: "A synthetic principle used by the B6 c5 test suite."\n'
        "references:\n"
        "  - \"docs/22_ltm_v3/EVOLUTION_CAPTURE.md\"\n"
        "  - \"schemas/ltm/memory_candidate.schema.json\"\n"
        "---\n\n"
        "# Body\n\nSynthetic body.\n",
        encoding="utf-8",
    )
    return p


def _run(*args: str) -> subprocess.CompletedProcess:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return subprocess.run(
        [sys.executable, str(CEP_CLI), *args],
        capture_output=True, text=True, env=env, timeout=30,
    )


# ----------------------------------------------------------------------
# Rail A — --proposal <path>
# ----------------------------------------------------------------------


def test_rail_a_writes_envelope(isolated_quarantine, proposal_md):
    cp = _run("--proposal", str(proposal_md),
              "--out", str(isolated_quarantine), "--format", "json")
    assert cp.returncode == 0, cp.stderr
    out = json.loads(cp.stdout)
    assert out["status"] == "captured"
    assert out["capture_source"] == "evolution_proposal"
    assert out["target_domain"] == "pattern"
    files = list(isolated_quarantine.glob("mc_*.json"))
    assert len(files) == 1
    env = json.loads(files[0].read_text(encoding="utf-8"))
    assert env["capture_source"] == "evolution_proposal"
    assert env["target_domain"] == "pattern"
    # references[] propagated into evidence_ref
    assert "docs/22_ltm_v3/EVOLUTION_CAPTURE.md" in env["evidence_ref"]
    assert "schemas/ltm/memory_candidate.schema.json" in env["evidence_ref"]


def test_rail_a_envelope_passes_schema(isolated_quarantine, proposal_md):
    """The emitted envelope MUST validate against memory_candidate.schema.json (B6 c1)."""
    import jsonschema  # type: ignore

    _run("--proposal", str(proposal_md),
         "--out", str(isolated_quarantine), "--format", "json")
    env = json.loads(next(isolated_quarantine.glob("mc_*.json")).read_text(encoding="utf-8"))
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    jsonschema.validate(env, schema)


def test_rail_a_dry_run_writes_nothing(isolated_quarantine, proposal_md):
    cp = _run("--proposal", str(proposal_md),
              "--out", str(isolated_quarantine),
              "--dry-run", "--format", "json")
    assert cp.returncode == 0
    out = json.loads(cp.stdout)
    assert out["dry_run"] is True
    assert not list(isolated_quarantine.glob("mc_*.json"))


def test_rail_a_target_domain_override(isolated_quarantine, proposal_md):
    cp = _run("--proposal", str(proposal_md),
              "--out", str(isolated_quarantine),
              "--target-domain", "os", "--format", "json")
    assert cp.returncode == 0
    env = json.loads(next(isolated_quarantine.glob("mc_*.json")).read_text(encoding="utf-8"))
    assert env["target_domain"] == "os"


def test_rail_a_missing_proposal_id_returns_1(isolated_quarantine, tmp_path):
    bad_md = tmp_path / "no_id.md"
    bad_md.write_text(
        "---\ntitle: \"missing proposal_id\"\n---\nbody\n",
        encoding="utf-8",
    )
    cp = _run("--proposal", str(bad_md),
              "--out", str(isolated_quarantine), "--format", "json")
    assert cp.returncode == 1
    assert "proposal_id" in cp.stderr


def test_rail_a_malformed_proposal_id_returns_1(isolated_quarantine, tmp_path):
    bad_md = tmp_path / "bad_id.md"
    bad_md.write_text(
        "---\nproposal_id: \"NOT_AN_EVO_ID\"\ntitle: \"x\"\n---\nbody\n",
        encoding="utf-8",
    )
    cp = _run("--proposal", str(bad_md),
              "--out", str(isolated_quarantine), "--format", "json")
    assert cp.returncode == 1


def test_rail_a_nonexistent_path_returns_4(isolated_quarantine, tmp_path):
    cp = _run("--proposal", str(tmp_path / "nope.md"),
              "--out", str(isolated_quarantine), "--format", "json")
    assert cp.returncode == 4


# ----------------------------------------------------------------------
# Rail B — --proposal-id <evo_id> (forward-compat)
# ----------------------------------------------------------------------


def test_rail_b_state_json_missing_returns_4(isolated_quarantine):
    """Forward-compat: v4.91 doesn't ship proposal_state.json; rail B
    should fail gracefully with EXIT_INPUT_MISSING + remediation hint."""
    cp = _run("--proposal-id", "evo_2026_998",
              "--out", str(isolated_quarantine), "--format", "json")
    assert cp.returncode == 4
    assert "state.json not found" in cp.stderr
    assert "--proposal" in cp.stderr  # remediation hint pointing at Rail A


def test_rail_b_bad_pattern_returns_1(isolated_quarantine):
    cp = _run("--proposal-id", "bad_id_format",
              "--out", str(isolated_quarantine), "--format", "json")
    assert cp.returncode == 1


# ----------------------------------------------------------------------
# Mutex group enforcement
# ----------------------------------------------------------------------


def test_mutex_group_rejects_both_rails(isolated_quarantine, proposal_md):
    """argparse mutex group should refuse --proposal + --proposal-id together."""
    cp = _run("--proposal", str(proposal_md),
              "--proposal-id", "evo_2026_999",
              "--out", str(isolated_quarantine))
    assert cp.returncode == 2  # argparse usage error


def test_mutex_group_requires_one_rail(isolated_quarantine):
    cp = _run("--out", str(isolated_quarantine))
    assert cp.returncode == 2  # argparse: required mutex


# ----------------------------------------------------------------------
# Charter alignment (#7 — no escape hatch)
# ----------------------------------------------------------------------


@pytest.mark.parametrize("bad_flag", [
    "--force", "--allow-extra", "--skip-validation",
    "--no-schema-check", "--bypass",
])
def test_no_escape_hatch_flags_exist(isolated_quarantine, proposal_md, bad_flag):
    """Charter anti-pattern #7 — capture_evolution_proposal MUST NOT
    expose any --force / --skip-* / --allow-* flag."""
    cp = _run("--proposal", str(proposal_md),
              "--out", str(isolated_quarantine), bad_flag)
    assert cp.returncode != 0  # argparse rejects unknown flag


# ----------------------------------------------------------------------
# Capture source / target domain enum tests
# ----------------------------------------------------------------------


def test_capture_source_is_locked_to_evolution_proposal(
    isolated_quarantine, proposal_md
):
    """The CLI must NOT accept any user override for capture_source —
    it's hardcoded to 'evolution_proposal'."""
    _run("--proposal", str(proposal_md),
         "--out", str(isolated_quarantine), "--format", "json")
    env = json.loads(next(isolated_quarantine.glob("mc_*.json")).read_text(encoding="utf-8"))
    assert env["capture_source"] == "evolution_proposal"


@pytest.mark.parametrize("domain", [
    "failures", "pattern", "os", "cross_project", "project",
])
def test_target_domain_all_5_values_accepted(
    isolated_quarantine, proposal_md, domain
):
    cp = _run("--proposal", str(proposal_md),
              "--out", str(isolated_quarantine),
              "--target-domain", domain, "--format", "json")
    assert cp.returncode == 0, cp.stderr
    env = json.loads(next(isolated_quarantine.glob("mc_*.json")).read_text(encoding="utf-8"))
    assert env["target_domain"] == domain


def test_target_domain_invalid_rejected_by_argparse(
    isolated_quarantine, proposal_md
):
    cp = _run("--proposal", str(proposal_md),
              "--out", str(isolated_quarantine),
              "--target-domain", "made_up_domain")
    assert cp.returncode == 2  # argparse choice violation
