"""v4.91 B4 c5 — Shared LTM v3 schema + retrieval_policy validation.

Locks the schema-level contract for the 4 NEW v3 schemas (1.0.0):
retrieval_policy / routing_report / preflight_case / preflight_metric.
"""

from __future__ import annotations

import json
from pathlib import Path

import jsonschema
import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMAS = REPO_ROOT / "schemas" / "ltm"


def _load(name: str) -> dict:
    return json.loads((SCHEMAS / name).read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# 4 schemas: meta validation


@pytest.mark.parametrize("name", [
    "retrieval_policy.schema.json",
    "routing_report.schema.json",
    "preflight_case.schema.json",
    "preflight_metric.schema.json",
])
def test_v3_schema_meta_valid(name: str) -> None:
    """Each new v3 schema is a well-formed Draft-07 JSON Schema."""
    s = _load(name)
    jsonschema.Draft7Validator.check_schema(s)
    assert s["properties"]["schema_version"]["const"] == "1.0.0"


# ---------------------------------------------------------------------------
# retrieval_policy: enum locks + tenancy_enforcement strict


def _policy_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "version": "1.0.0",
        "default_include": ["current_project", "os", "approved_cross_project",
                            "pattern", "failures"],
        "default_exclude": ["other_project_private", "quarantine", "rejected",
                            "unapproved_candidates", "superseded"],
        "ranking": {
            "boost_current_project": 1.5,
            "boost_os": 1.0,
            "boost_approved_cross_project": 0.8,
            "max_results": 20,
        },
        "tenancy_enforcement": {"mode": "strict"},
    }


def test_retrieval_policy_happy_path_validates() -> None:
    s = _load("retrieval_policy.schema.json")
    jsonschema.validate(_policy_happy(), s)


def test_retrieval_policy_rejects_other_project_private_in_include() -> None:
    """Charter anti-pattern #7: other_project_private MUST NOT appear in
    default_include[] (schema enum reject)."""
    s = _load("retrieval_policy.schema.json")
    inst = _policy_happy()
    inst["default_include"] = ["other_project_private"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, s)


def test_retrieval_policy_rejects_lenient_tenancy_mode() -> None:
    """tenancy_enforcement.mode is enum-locked to 'strict'."""
    s = _load("retrieval_policy.schema.json")
    inst = _policy_happy()
    inst["tenancy_enforcement"]["mode"] = "lenient"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, s)


def test_retrieval_policy_rejects_extra_top_level_key() -> None:
    """Charter anti-pattern #7: no override_* / allow_* fields permitted."""
    s = _load("retrieval_policy.schema.json")
    inst = _policy_happy()
    inst["override_other_project_private"] = True
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, s)


def test_retrieval_policy_rejects_negative_boost() -> None:
    s = _load("retrieval_policy.schema.json")
    inst = _policy_happy()
    inst["ranking"]["boost_current_project"] = -0.1
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, s)


# ---------------------------------------------------------------------------
# routing_report: skipped_paths reason enum + 2-char project_id compat


def _report_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "report_id": "routing_test_alpha_2026_05_21t000000z",
        "query": "writeback owner drift",
        "calling_project_id": "rh",
        "generated_at": "2026-05-21T00:00:00Z",
        "policy_version": "1.0.0",
        "scopes_included": ["current_project", "os"],
        "scopes_excluded": ["other_project_private"],
        "results": [
            {"path": "project/rh/2026-05-07_writeback.md", "score": 13.5,
             "scope": "current_project"},
        ],
        "skipped_paths": [
            {"path": "project/sample_alpha/something.md",
             "scope": "other_project_private",
             "reason": "tenancy_reconciliation_failed"},
        ],
    }


def test_routing_report_happy_path_validates() -> None:
    s = _load("routing_report.schema.json")
    jsonschema.validate(_report_happy(), s)


def test_routing_report_accepts_two_char_project_id() -> None:
    """v4.91 B4 c2 fix: short historic project_ids like 'rh' must validate."""
    s = _load("routing_report.schema.json")
    inst = _report_happy()
    inst["calling_project_id"] = "rh"
    jsonschema.validate(inst, s)


def test_routing_report_rejects_unknown_skip_reason() -> None:
    s = _load("routing_report.schema.json")
    inst = _report_happy()
    inst["skipped_paths"][0]["reason"] = "i_just_didnt_feel_like_it"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, s)


def test_routing_report_rejects_uppercase_in_report_id() -> None:
    s = _load("routing_report.schema.json")
    inst = _report_happy()
    inst["report_id"] = "routing_BAD_UPPERCASE"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, s)


def test_routing_report_allows_empty_results() -> None:
    """Auditable no-match outcome — empty results[] is legal."""
    s = _load("routing_report.schema.json")
    inst = _report_happy()
    inst["results"] = []
    jsonschema.validate(inst, s)


# ---------------------------------------------------------------------------
# preflight_case: charter #11/#12 schema shape


def _case_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "case_id": "pf_case_2026_05_21_001",
        "trigger": "major_version_bump",
        "subject": {
            "kind": "core_update_plan",
            "ref": "hub/update_plans/plan_v491_to_v500.yaml",
        },
        "consulted_roles": ["sre", "engineering"],
        "consensus": {
            "outcome": "approved",
            "decided_by": "ep",
        },
        "generated_at": "2026-05-21T00:00:00Z",
    }


def test_preflight_case_happy_path_validates() -> None:
    s = _load("preflight_case.schema.json")
    jsonschema.validate(_case_happy(), s)


def test_preflight_case_decided_by_must_be_string_not_list() -> None:
    """Charter anti-pattern #12: decided_by is a single string. A list
    indicates vote-aggregation thinking and the schema rejects it."""
    s = _load("preflight_case.schema.json")
    inst = _case_happy()
    inst["consensus"]["decided_by"] = ["ep", "sre"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, s)


def test_preflight_case_rejects_votes_field() -> None:
    """Charter anti-pattern #12: there is no votes[] surface."""
    s = _load("preflight_case.schema.json")
    inst = _case_happy()
    inst["consensus"]["votes"] = [{"role": "sre", "vote": "yes"}]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, s)


def test_preflight_case_rejects_unknown_trigger() -> None:
    """Trigger enum mirrors core_update_policy.schema.json
    require_preflight_for[] (B3 c1)."""
    s = _load("preflight_case.schema.json")
    inst = _case_happy()
    inst["trigger"] = "ad_hoc_consult"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, s)


def test_preflight_case_rejects_unknown_outcome() -> None:
    s = _load("preflight_case.schema.json")
    inst = _case_happy()
    inst["consensus"]["outcome"] = "auto_promoted"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, s)


# ---------------------------------------------------------------------------
# preflight_metric: charter #6 schema shape (no promotion field)


def _metric_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "metric_id": "pf_metric_2026_05_21_001",
        "case_ref": "ltm/preflight/cases/pf_case_2026_05_21_001.json",
        "captured_at": "2026-05-21T00:00:00Z",
        "elapsed_seconds": 4.2,
        "consulted_role_count": 2,
    }


def test_preflight_metric_happy_path_validates() -> None:
    s = _load("preflight_metric.schema.json")
    jsonschema.validate(_metric_happy(), s)


def test_preflight_metric_rejects_promotion_field() -> None:
    """Charter anti-pattern #6: no auto-promote; metric carries no
    promotion-related field."""
    s = _load("preflight_metric.schema.json")
    inst = _metric_happy()
    inst["promote_to"] = "approved_cross_project"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, s)


def test_preflight_metric_rejects_negative_elapsed() -> None:
    s = _load("preflight_metric.schema.json")
    inst = _metric_happy()
    inst["elapsed_seconds"] = -1.0
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, s)


def test_preflight_metric_rejects_zero_consulted_role_count() -> None:
    s = _load("preflight_metric.schema.json")
    inst = _metric_happy()
    inst["consulted_role_count"] = 0
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, s)
