"""test_quarantine_entry.py — v4.90 Batch 13 Step 13.4.b.

Tests for `scripts/ltm/quarantine_entry.py` — the plan §9 字面
reverse-of-extract operation: move a canonical ``ltm/<domain>/<file>.md``
entry to ``ltm/_quarantine/<timestamp>_<domain>_<slug>.quarantined.md``
with an HTML-comment metadata header.

Per EP decision 2026-05-15 11:11:
- D-13.4.b.1 = A (mv semantic, not cp+stamp)
- D-13.4.b.2 = A (--reason required, governance discipline)
- D-13.4.b.3 = A (UTC ISO timestamp ``YYYY-MM-DDTHH-MM-SSZ``)

5 tests:
1. Move semantics: source disappears, target appears with body+metadata
2. Metadata header carries quarantined_at / original_path / reason / batch
3. Missing --reason -> exit 1 INPUT_ERROR
4. Path not in ltm/<domain>/ -> exit 1 INPUT_ERROR
5. Path does not exist -> exit 4 INPUT_MISSING

Layer 1 (OS Spec). No project names; placeholder ``ap_*`` style ids.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from scripts.ltm import quarantine_entry as qe


def _setup_ltm_tree(tmp_path: Path) -> Path:
    """Build a minimal ltm/ tree under tmp_path with a sample entry.

    Returns the ltm root. The sample entry lives at
    ltm/failures/sample_entry.md with deterministic body content.
    """
    ltm_root = tmp_path / "ltm"
    (ltm_root / "failures").mkdir(parents=True)
    (ltm_root / "_quarantine").mkdir(parents=True)
    sample = ltm_root / "failures" / "sample_entry.md"
    sample.write_text(
        "---\n"
        "captured_at: 2099-01-01\n"
        "actor: tester\n"
        "gate: closed\n"
        "evidence_ref:\n"
        "  - notes/test.md\n"
        "---\n"
        "\n"
        "# Sample failure entry\n"
        "\n"
        "This is the original body that must be preserved verbatim.\n",
        encoding="utf-8",
    )
    return ltm_root


# --- Test 1: move semantics --------------------------------------------------

def test_quarantine_moves_failure_entry_to_quarantine(tmp_path):
    """Source disappears, target appears under _quarantine/ with the
    expected name shape and body preserved verbatim."""
    ltm_root = _setup_ltm_tree(tmp_path)
    src = ltm_root / "failures" / "sample_entry.md"
    original_body_marker = "This is the original body that must be preserved"

    code, message = qe.quarantine(src, reason="testing mv semantic",
                                   ltm_root=ltm_root)

    assert code == qe.EXIT_OK, f"expected EXIT_OK; got {code} ({message!r})"
    # Source must be gone (mv, not cp).
    assert not src.exists(), (
        f"D-13.4.b.1=A requires mv semantic; source still exists: {src}"
    )
    # Target must exist with the expected name shape.
    quarantine_dir = ltm_root / "_quarantine"
    matches = list(quarantine_dir.glob("*_failures_sample_entry.quarantined.md"))
    assert len(matches) == 1, (
        f"expected exactly 1 quarantined target; got {matches!r}"
    )
    target = matches[0]
    text = target.read_text(encoding="utf-8")
    assert original_body_marker in text, (
        f"original body must be preserved verbatim in quarantined file"
    )


# --- Test 2: metadata header -------------------------------------------------

def test_quarantine_metadata_header_carries_reason_and_origin(tmp_path):
    """The quarantined file must start with an HTML-comment block
    containing quarantined_at / original_path / reason / batch."""
    ltm_root = _setup_ltm_tree(tmp_path)
    src = ltm_root / "failures" / "sample_entry.md"

    code, _msg = qe.quarantine(
        src,
        reason="superseded by ff_2099_999 — see review note",
        ltm_root=ltm_root,
    )
    assert code == qe.EXIT_OK

    target = next(
        (ltm_root / "_quarantine").glob("*_failures_sample_entry.quarantined.md")
    )
    text = target.read_text(encoding="utf-8")

    # The header must be the first thing in the file.
    assert text.startswith("<!--\n"), (
        f"quarantine target must start with HTML-comment metadata block; "
        f"got: {text[:50]!r}"
    )

    # All 4 required metadata keys must appear inside the comment block.
    header_end = text.find("-->")
    assert header_end != -1, "metadata block missing closing '-->'"
    header_text = text[:header_end]
    for key in (
        "quarantined_at:",
        "original_path:",
        "reason:",
        "batch:",
    ):
        assert key in header_text, (
            f"metadata header missing key {key!r}; header={header_text!r}"
        )

    # Reason text and original-path tail must be present.
    assert "superseded by ff_2099_999" in header_text
    assert "ltm/failures/sample_entry.md" in header_text
    # D-13.4.b.3=A timestamp: YYYY-MM-DDTHH-MM-SSZ pattern.
    import re
    assert re.search(
        r"quarantined_at:\s*\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}Z",
        header_text,
    ), f"timestamp shape mismatch in header: {header_text!r}"


# --- Test 3: --reason required (D-13.4.b.2 = A) -----------------------------

def test_quarantine_missing_reason_returns_input_error(tmp_path):
    """Empty / blank --reason must surface as EXIT_INPUT_ERROR."""
    ltm_root = _setup_ltm_tree(tmp_path)
    src = ltm_root / "failures" / "sample_entry.md"

    code, message = qe.quarantine(src, reason="", ltm_root=ltm_root)
    assert code == qe.EXIT_INPUT_ERROR, (
        f"empty --reason must return INPUT_ERROR; got {code}"
    )
    assert "reason" in message.lower(), (
        f"diagnostic must mention reason; got {message!r}"
    )

    # Whitespace-only also fails.
    code2, message2 = qe.quarantine(src, reason="   \t\n  ", ltm_root=ltm_root)
    assert code2 == qe.EXIT_INPUT_ERROR
    # Source must be untouched (no partial move).
    assert src.exists(), (
        f"source must be untouched on INPUT_ERROR; missing: {src}"
    )


# --- Test 4: path not in ltm/<domain>/ --------------------------------------

def test_quarantine_path_not_in_ltm_returns_input_error(tmp_path):
    """Paths outside ltm/<domain>/ must be rejected:
       - top-level files (ltm/foo.md without a domain subdir)
       - paths already in ltm/_quarantine/
       - paths entirely outside ltm/
    """
    ltm_root = _setup_ltm_tree(tmp_path)

    # Case A: outside ltm/ entirely.
    outside = tmp_path / "random_file.md"
    outside.write_text("not an ltm entry\n", encoding="utf-8")
    code_a, msg_a = qe.quarantine(outside, reason="x", ltm_root=ltm_root)
    assert code_a == qe.EXIT_INPUT_ERROR, (
        f"outside-ltm path must return INPUT_ERROR; got {code_a}"
    )
    assert "ltm/<domain>" in msg_a or "_quarantine" in msg_a, (
        f"diagnostic must explain rejection; got {msg_a!r}"
    )

    # Case B: already in _quarantine/.
    already_q = ltm_root / "_quarantine" / "preexisting.md"
    already_q.write_text("already quarantined\n", encoding="utf-8")
    code_b, _msg_b = qe.quarantine(already_q, reason="x", ltm_root=ltm_root)
    assert code_b == qe.EXIT_INPUT_ERROR, (
        f"already-quarantined path must return INPUT_ERROR; got {code_b}"
    )

    # Case C: top-level ltm/<file>.md (no domain dir).
    top_level = ltm_root / "stray.md"
    top_level.write_text("stray\n", encoding="utf-8")
    code_c, _msg_c = qe.quarantine(top_level, reason="x", ltm_root=ltm_root)
    assert code_c == qe.EXIT_INPUT_ERROR


# --- Test 5: nonexistent path -----------------------------------------------

def test_quarantine_nonexistent_path_returns_input_missing(tmp_path):
    """Nonexistent path must return EXIT_INPUT_MISSING (not INPUT_ERROR)."""
    ltm_root = _setup_ltm_tree(tmp_path)
    ghost = ltm_root / "failures" / "does_not_exist.md"
    code, message = qe.quarantine(ghost, reason="x", ltm_root=ltm_root)
    assert code == qe.EXIT_INPUT_MISSING, (
        f"missing path must return INPUT_MISSING; got {code}"
    )
    assert "not found" in message.lower(), (
        f"diagnostic must mention 'not found'; got {message!r}"
    )


# Net additions: 5 distinct test functions.
# Pre-13.4.b baseline 820 (after 13.4.a). After 13.4.b: 825 expected.
