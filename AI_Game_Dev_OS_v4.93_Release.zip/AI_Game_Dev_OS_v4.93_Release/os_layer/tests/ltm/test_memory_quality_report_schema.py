"""test_memory_quality_report_schema.py — v4.90 Batch 8 Step 8.3.

Self-validation tests for schemas/ltm/memory_quality_report.schema.json:

1. The schema document is itself a valid JSON Schema draft-07 doc.
2. A minimal happy-path instance validates (zero issues).
3. An instance with one error issue validates.
4. issue.rule must be from the documented enum.
5. issue.severity must be from the documented enum.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = REPO_ROOT / "schemas" / "ltm" / "memory_quality_report.schema.json"


def _load_schema() -> dict:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def _empty_report() -> dict:
    return {
        "report_id": "mqr_2026_05_13",
        "scanned_dir": "ltm/failures",
        "total_entries": 0,
        "passed": 0,
        "failed": 0,
        "issues": [],
        "generated_at": "2026-05-13T10:00:00Z",
        "schema_version": "1.0.0",
    }


# --------------------------------------------------------------------------
# 1. Schema is a valid JSON Schema draft-07
# --------------------------------------------------------------------------

def test_memory_quality_report_schema_is_valid_jsonschema():
    schema = _load_schema()
    jsonschema.Draft7Validator.check_schema(schema)


# --------------------------------------------------------------------------
# 2. Empty report validates
# --------------------------------------------------------------------------

def test_empty_report_validates():
    schema = _load_schema()
    instance = _empty_report()
    jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 3. Report with one error issue validates
# --------------------------------------------------------------------------

def test_report_with_error_issue_validates():
    schema = _load_schema()
    instance = _empty_report()
    instance["report_id"] = "mqr_2026_05_13_failures"  # exercise slug suffix
    instance["total_entries"] = 1
    instance["passed"] = 0
    instance["failed"] = 1
    instance["issues"] = [
        {
            "path": "ltm/failures/2026-05-10_x.md",
            "rule": "evidence_ref_missing",
            "severity": "error",
            "message": "evidence_ref is empty",
        }
    ]
    jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 4. Unknown rule is rejected
# --------------------------------------------------------------------------

def test_unknown_issue_rule_is_rejected():
    schema = _load_schema()
    instance = _empty_report()
    instance["total_entries"] = 1
    instance["failed"] = 1
    instance["issues"] = [
        {
            "path": "ltm/failures/x.md",
            "rule": "totally_invented_rule",
            "severity": "error",
            "message": "boom",
        }
    ]
    with pytest.raises(jsonschema.exceptions.ValidationError):
        jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 5. Unknown severity is rejected
# --------------------------------------------------------------------------

def test_unknown_severity_is_rejected():
    schema = _load_schema()
    instance = _empty_report()
    instance["total_entries"] = 1
    instance["failed"] = 1
    instance["issues"] = [
        {
            "path": "ltm/failures/x.md",
            "rule": "evidence_ref_missing",
            "severity": "fatal",  # not in enum
            "message": "boom",
        }
    ]
    with pytest.raises(jsonschema.exceptions.ValidationError):
        jsonschema.validate(instance=instance, schema=schema)
