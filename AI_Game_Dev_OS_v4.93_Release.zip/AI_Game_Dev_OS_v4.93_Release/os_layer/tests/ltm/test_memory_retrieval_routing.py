"""Tests for config/memory_retrieval_routing_v2.yaml — v4.90 Batch 8 Step 8.7.

Covers (7):
  1. Schema is a valid JSON Schema draft-07
  2. The shipped routing yaml parses (zero-dep _yaml_subset) and
     validates against the schema (jsonschema if available)
  3. priority_matrix priorities are unique
  4. priority_matrix domains span all 7 v4.90 LTM domains
  5. default_excluded covers working/ and _quarantine/
  6. priority_matrix sorted ascending by priority gives the documented
     order (os < pattern < cross_project < failures < project < working
     < _quarantine)
  7. namespace enum coverage: every supported namespace appears at least
     once

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = REPO_ROOT / "schemas" / "ltm" / "memory_retrieval_routing.schema.json"
YAML_PATH = REPO_ROOT / "config" / "memory_retrieval_routing_v2.yaml"


def _load_schema() -> dict:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def _load_yaml() -> dict:
    # Use the project's zero-dep parser to avoid PyYAML dependency.
    import sys
    sys.path.insert(0, str(REPO_ROOT))
    from scripts.governance._yaml_subset import parse_yaml_text
    return parse_yaml_text(YAML_PATH.read_text(encoding="utf-8"))


# --------------------------------------------------------------------------
# 1. Schema is valid draft-07
# --------------------------------------------------------------------------

def test_routing_schema_is_valid_jsonschema():
    jsonschema = pytest.importorskip("jsonschema")
    schema = _load_schema()
    jsonschema.Draft7Validator.check_schema(schema)


# --------------------------------------------------------------------------
# 2. Shipped yaml parses + validates against schema
# --------------------------------------------------------------------------

def test_shipped_routing_yaml_validates_against_schema():
    jsonschema = pytest.importorskip("jsonschema")
    schema = _load_schema()
    instance = _load_yaml()
    jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 3. Unique priorities
# --------------------------------------------------------------------------

def test_priority_matrix_priorities_are_unique():
    instance = _load_yaml()
    priorities = [row["priority"] for row in instance["priority_matrix"]]
    assert len(priorities) == len(set(priorities)), (
        f"duplicate priorities in {priorities}"
    )


# --------------------------------------------------------------------------
# 4. All 7 domains covered
# --------------------------------------------------------------------------

def test_priority_matrix_covers_all_seven_domains():
    instance = _load_yaml()
    domains = {row["domain"] for row in instance["priority_matrix"]}
    assert domains == {
        "os", "pattern", "cross_project", "failures",
        "project", "working", "_quarantine",
    }


# --------------------------------------------------------------------------
# 5. default_excluded covers working/ and _quarantine/
# --------------------------------------------------------------------------

def test_default_excluded_covers_working_and_quarantine():
    instance = _load_yaml()
    excluded = set(instance["default_excluded"])
    assert "working" in excluded
    assert "_quarantine" in excluded


# --------------------------------------------------------------------------
# 6. Documented priority order
# --------------------------------------------------------------------------

def test_priority_order_matches_documented_default():
    """OS Core takes precedence over project-local memory."""
    instance = _load_yaml()
    rows = sorted(instance["priority_matrix"], key=lambda r: r["priority"])
    ordered_domains = [r["domain"] for r in rows]
    assert ordered_domains == [
        "os",
        "pattern",
        "cross_project",
        "failures",
        "project",
        "working",
        "_quarantine",
    ]


# --------------------------------------------------------------------------
# 7. Namespace enum coverage
# --------------------------------------------------------------------------

def test_namespace_enum_coverage():
    instance = _load_yaml()
    namespaces = {row["namespace"] for row in instance["priority_matrix"]}
    # Every supported namespace value must appear at least once in the
    # shipped config so the parser + schema enum exercise is non-trivial.
    assert namespaces == {
        "global",
        "per_project",
        "per_project_or_global",
        "session_local",
    }
