"""Tests for scripts/ltm/reject_memory_candidate.py — v4.91 B5 c3.

Covers (15):
  1. Happy path with rationale -> ledger schema 1.0.0
  2. Happy path without rationale (rationale optional)
  3. Forbidden approver 'auto' -> gate violation exit 1
  4. Forbidden approver 'ci' (case sensitive lowercase) -> reject
  5. Forbidden approver 'AUTO' (uppercase normalised) -> reject
  6. Bad reason value -> argparse choice reject (exit 2)
  7. Empty rejected-by -> gate violation
  8. Missing candidate file -> exit 4
  9. Idempotent: re-run on already-rejected candidate -> exit 0 no-op
 10. Audit retention: rejected candidate copy lands in cross_project/rejected/
 11. Ledger ledger_id matches '^reject_' pattern + has policy_version
 12. Ledger event_type const = 'rejected'
 13. Schema_version const refuses ledger sidecar tampering
 14. --format json emits structured payload
 15. Each of 7 reasons accepted parametrised

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.ltm.conftest import run_script


# --------------------------------------------------------------------------
# Fixtures
# --------------------------------------------------------------------------

@pytest.fixture
def ltm_root(tmp_path: Path) -> Path:
    root = tmp_path / "ltm"
    for d in (
        "failures",
        "pattern",
        "os",
        "cross_project",
        "cross_project/approved_patterns",
        "cross_project/rejected",
        "cross_project/superseded",
        "_quarantine",
    ):
        (root / d).mkdir(parents=True, exist_ok=True)
    # Default policy
    (root / "promotion_policy.yaml").write_text(
        "schema_version: \"1.0.0\"\n"
        "version: \"1.0.0-test\"\n"
        "thresholds:\n"
        "  cross_project_min_evidence_refs: 2\n"
        "approval:\n"
        "  mode: \"strict\"\n"
        "  forbidden_approvers: [auto, system, agent, automation, robot, ci]\n"
        "supersede:\n"
        "  must_reference_replacing_entry: true\n",
        encoding="utf-8",
    )
    return root


def _write_candidate(quarantine: Path, candidate_id: str = "mc_b5_reject_001") -> Path:
    candidate = {
        "schema_version": "1.0.0",
        "candidate_id": candidate_id,
        "captured_at": "2026-05-21T15:00:00Z",
        "actor": "kai",
        "evidence_ref": ["one synthesized ref"],
        "target_domain": "cross_project",
        "proposed_entry": {"captured_at": "2026-05-21T15:00:00Z"},
        "proposed_body": "",
    }
    p = quarantine / f"{candidate_id}.json"
    p.write_text(json.dumps(candidate, indent=2) + "\n", encoding="utf-8")
    return p


# --------------------------------------------------------------------------
# 1. Happy with rationale
# --------------------------------------------------------------------------

def test_reject_happy_with_rationale(ltm_root):
    cand = _write_candidate(ltm_root / "_quarantine")
    result = run_script(
        "reject_memory_candidate.py",
        "--candidate", str(cand),
        "--reason", "insufficient_evidence",
        "--rejected-by", "ep",
        "--rationale", "single evidence_ref insufficient for cross_project",
        "--ltm-root", str(ltm_root),
    )
    result.expect(0)
    ledger_path = cand.with_suffix(".rejected.json")
    assert ledger_path.exists()
    ledger = json.loads(ledger_path.read_text())
    assert ledger["schema_version"] == "1.0.0"
    assert ledger["event_type"] == "rejected"
    assert ledger["rejection_reason"] == "insufficient_evidence"
    assert ledger["rationale"] == "single evidence_ref insufficient for cross_project"


# --------------------------------------------------------------------------
# 2. Happy without rationale
# --------------------------------------------------------------------------

def test_reject_happy_without_rationale(ltm_root):
    cand = _write_candidate(ltm_root / "_quarantine", "mc_no_rat")
    result = run_script(
        "reject_memory_candidate.py",
        "--candidate", str(cand),
        "--reason", "low_quality",
        "--rejected-by", "ep",
        "--ltm-root", str(ltm_root),
    )
    result.expect(0)
    ledger = json.loads(cand.with_suffix(".rejected.json").read_text())
    assert "rationale" not in ledger or not ledger.get("rationale")


# --------------------------------------------------------------------------
# 3-5. Forbidden approver enforcement (Charter #11/#12)
# --------------------------------------------------------------------------

@pytest.mark.parametrize("forbidden", ["auto", "system", "agent", "automation", "robot", "ci"])
def test_reject_forbidden_approver_lowercase(ltm_root, forbidden):
    cand = _write_candidate(ltm_root / "_quarantine", f"mc_fb_{forbidden}")
    result = run_script(
        "reject_memory_candidate.py",
        "--candidate", str(cand),
        "--reason", "insufficient_evidence",
        "--rejected-by", forbidden,
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)
    assert "forbidden" in result.stderr.lower()


def test_reject_forbidden_approver_case_insensitive(ltm_root):
    cand = _write_candidate(ltm_root / "_quarantine", "mc_fb_upper")
    result = run_script(
        "reject_memory_candidate.py",
        "--candidate", str(cand),
        "--reason", "insufficient_evidence",
        "--rejected-by", "AUTO",
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)


# --------------------------------------------------------------------------
# 6. Bad reason value
# --------------------------------------------------------------------------

def test_reject_bad_reason_argparse_reject(ltm_root):
    cand = _write_candidate(ltm_root / "_quarantine", "mc_bad_reason")
    result = run_script(
        "reject_memory_candidate.py",
        "--candidate", str(cand),
        "--reason", "i_dont_like_it",
        "--rejected-by", "ep",
        "--ltm-root", str(ltm_root),
    )
    assert result.exit_code == 2  # argparse choice violation


# --------------------------------------------------------------------------
# 7. Empty rejected-by
# --------------------------------------------------------------------------

def test_reject_empty_rejected_by(ltm_root):
    cand = _write_candidate(ltm_root / "_quarantine", "mc_empty_by")
    result = run_script(
        "reject_memory_candidate.py",
        "--candidate", str(cand),
        "--reason", "insufficient_evidence",
        "--rejected-by", "",
        "--ltm-root", str(ltm_root),
    )
    result.expect(1)


# --------------------------------------------------------------------------
# 8. Missing candidate file
# --------------------------------------------------------------------------

def test_reject_missing_candidate_file(ltm_root):
    result = run_script(
        "reject_memory_candidate.py",
        "--candidate", str(ltm_root / "_quarantine" / "missing.json"),
        "--reason", "insufficient_evidence",
        "--rejected-by", "ep",
        "--ltm-root", str(ltm_root),
    )
    assert result.exit_code == 4


# --------------------------------------------------------------------------
# 9. Idempotency
# --------------------------------------------------------------------------

def test_reject_idempotent(ltm_root):
    cand = _write_candidate(ltm_root / "_quarantine", "mc_idem")
    args = [
        "reject_memory_candidate.py",
        "--candidate", str(cand),
        "--reason", "insufficient_evidence",
        "--rejected-by", "ep",
        "--ltm-root", str(ltm_root),
    ]
    run_script(*args).expect(0)
    # Second run: ledger already exists -> no-op exit 0
    result = run_script(*args)
    result.expect(0)


# --------------------------------------------------------------------------
# 10. Audit retention to cross_project/rejected/
# --------------------------------------------------------------------------

def test_reject_audit_copy_lands_in_rejected_dir(ltm_root):
    cand = _write_candidate(ltm_root / "_quarantine", "mc_audit")
    run_script(
        "reject_memory_candidate.py",
        "--candidate", str(cand),
        "--reason", "duplicate_of_existing",
        "--rejected-by", "ep",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    rejected_dir = ltm_root / "cross_project" / "rejected"
    copies = list(rejected_dir.glob("mc_audit*"))
    assert copies, f"expected audit copy under {rejected_dir}, got nothing"


# --------------------------------------------------------------------------
# 11. Ledger ledger_id pattern + policy_version
# --------------------------------------------------------------------------

def test_reject_ledger_id_pattern_and_policy_version(ltm_root):
    cand = _write_candidate(ltm_root / "_quarantine", "mc_ledger")
    run_script(
        "reject_memory_candidate.py",
        "--candidate", str(cand),
        "--reason", "out_of_scope",
        "--rejected-by", "ep",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    ledger = json.loads(cand.with_suffix(".rejected.json").read_text())
    assert ledger["ledger_id"].startswith("reject_")
    assert ledger["policy_version"] == "1.0.0-test"


# --------------------------------------------------------------------------
# 12-13. Schema lock
# --------------------------------------------------------------------------

def test_reject_event_type_const_rejected(ltm_root):
    cand = _write_candidate(ltm_root / "_quarantine", "mc_etype")
    run_script(
        "reject_memory_candidate.py",
        "--candidate", str(cand),
        "--reason", "policy_violation",
        "--rejected-by", "ep",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    ledger = json.loads(cand.with_suffix(".rejected.json").read_text())
    assert ledger["event_type"] == "rejected"


# --------------------------------------------------------------------------
# 14. JSON output
# --------------------------------------------------------------------------

def test_reject_json_format(ltm_root):
    cand = _write_candidate(ltm_root / "_quarantine", "mc_json")
    result = run_script(
        "reject_memory_candidate.py",
        "--candidate", str(cand),
        "--reason", "schema_invalid",
        "--rejected-by", "ep",
        "--format", "json",
        "--ltm-root", str(ltm_root),
    )
    result.expect(0)
    payload = json.loads(result.stdout)
    assert payload["status"] in ("rejected", "ok", "success")


# --------------------------------------------------------------------------
# 15. All 7 reason enum values accepted
# --------------------------------------------------------------------------

@pytest.mark.parametrize("reason", [
    "insufficient_evidence",
    "tenancy_violation",
    "schema_invalid",
    "duplicate_of_existing",
    "out_of_scope",
    "low_quality",
    "policy_violation",
])
def test_reject_all_reasons_accepted(ltm_root, reason):
    cand = _write_candidate(ltm_root / "_quarantine", f"mc_reason_{reason}")
    run_script(
        "reject_memory_candidate.py",
        "--candidate", str(cand),
        "--reason", reason,
        "--rejected-by", "ep",
        "--ltm-root", str(ltm_root),
    ).expect(0)
    ledger = json.loads(cand.with_suffix(".rejected.json").read_text())
    assert ledger["rejection_reason"] == reason
