"""ff cross-entry referent integrity — v4.90 Batch 12 Step 12.3 (GAP #2).

Covers the cross-entry integrity check that
``scripts/ltm/validate_failure_fix_entry.py`` performs in --dir mode:
when an entry declares ``superseded_by: ff_X`` or
``conflicts_with: [ff_Y, ff_Z]``, every referenced ff_id MUST be
present in the scanned directory; a missing referent is a VIOLATION.

The shape-only (--file) contract is preserved: the same payload that
fails in --dir mode passes in --file mode (because a single entry
cannot see the global ff_id set).

Lives alongside test_ff_schema_lifecycle.py which covers single-entry
shape (lifecycle enum + conditional companions). This file is
specifically GAP #2 referent-integrity coverage.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

from pathlib import Path

from tests.ltm.conftest import make_entry, run_script


# --------------------------------------------------------------------------
# 1. superseded_by referent exists
# --------------------------------------------------------------------------

def test_superseded_by_referent_exists_passes(ltm_failures_dir: Path):
    """Two entries: A active + B superseded_by A. A's ff_id matches
    B's superseded_by literal, so the directory passes clean."""
    make_entry(
        ltm_failures_dir,
        "a_active.md",
        ff_id="ff_2026_010",
        lifecycle_state="active",
    )
    make_entry(
        ltm_failures_dir,
        "b_superseded.md",
        ff_id="ff_2026_011",
        lifecycle_state="superseded",
        superseded_by="ff_2026_010",
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(0)


# --------------------------------------------------------------------------
# 2. superseded_by referent missing
# --------------------------------------------------------------------------

def test_superseded_by_referent_missing_fails(ltm_failures_dir: Path):
    """B superseded_by ff_2099_999 which is absent -> exit 1 with
    a violation message naming the missing ff_id."""
    make_entry(
        ltm_failures_dir,
        "b_orphaned_superseded.md",
        ff_id="ff_2026_012",
        lifecycle_state="superseded",
        superseded_by="ff_2099_999",
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(1)
    assert "superseded_by" in result.stdout
    assert "ff_2099_999" in result.stdout


# --------------------------------------------------------------------------
# 3. conflicts_with all referents exist
# --------------------------------------------------------------------------

def test_conflicts_with_referent_exists_passes(ltm_failures_dir: Path):
    """conflicts_with [ff_X, ff_Y] both present -> clean."""
    make_entry(
        ltm_failures_dir,
        "x.md",
        ff_id="ff_2026_020",
    )
    make_entry(
        ltm_failures_dir,
        "y.md",
        ff_id="ff_2026_021",
    )
    make_entry(
        ltm_failures_dir,
        "z_conflicts.md",
        ff_id="ff_2026_022",
        conflicts_with=["ff_2026_020", "ff_2026_021"],
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(0)


# --------------------------------------------------------------------------
# 4. conflicts_with partial missing
# --------------------------------------------------------------------------

def test_conflicts_with_partial_missing_fails(ltm_failures_dir: Path):
    """conflicts_with [ff_X, ff_Y] where only ff_X exists -> exit 1
    with a violation naming ff_Y specifically."""
    make_entry(
        ltm_failures_dir,
        "x.md",
        ff_id="ff_2026_030",
    )
    make_entry(
        ltm_failures_dir,
        "z_partial.md",
        ff_id="ff_2026_031",
        conflicts_with=["ff_2026_030", "ff_2099_999"],
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(1)
    assert "conflicts_with" in result.stdout
    assert "ff_2099_999" in result.stdout
    # ff_2026_030 must NOT be reported (it does exist).
    assert "ff_2026_030" not in result.stdout.split("VIOLATION")[1] \
        if "VIOLATION" in result.stdout else True


# --------------------------------------------------------------------------
# 5. conflicts_with all missing -> multiple violations
# --------------------------------------------------------------------------

def test_conflicts_with_all_missing_fails(ltm_failures_dir: Path):
    """conflicts_with with two non-existent referents reports each
    individually so the operator can fix them one by one."""
    make_entry(
        ltm_failures_dir,
        "z_all_missing.md",
        ff_id="ff_2026_040",
        conflicts_with=["ff_2099_001", "ff_2099_002"],
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(1)
    assert "ff_2099_001" in result.stdout
    assert "ff_2099_002" in result.stdout


# --------------------------------------------------------------------------
# 6. combined superseded_by + conflicts_with -> clean when all exist
# --------------------------------------------------------------------------

def test_combined_superseded_and_conflicts_with_passes(ltm_failures_dir: Path):
    """An entry can carry both superseded_by AND conflicts_with; if
    every referent is present, no violation fires."""
    make_entry(
        ltm_failures_dir,
        "a.md",
        ff_id="ff_2026_050",
    )
    make_entry(
        ltm_failures_dir,
        "b.md",
        ff_id="ff_2026_051",
    )
    make_entry(
        ltm_failures_dir,
        "c.md",
        ff_id="ff_2026_052",
        lifecycle_state="superseded",
        superseded_by="ff_2026_050",
        conflicts_with=["ff_2026_051"],
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(0)


# --------------------------------------------------------------------------
# 7. --file mode does NOT enforce referent integrity (shape-only)
# --------------------------------------------------------------------------

def test_referent_integrity_only_in_dir_mode(ltm_failures_dir: Path):
    """A single-entry --file run does not have visibility of the
    global ff_id set, so referent integrity intentionally is not
    enforced. The same payload that would fail in --dir mode passes
    in --file mode."""
    entry = make_entry(
        ltm_failures_dir,
        "lone.md",
        ff_id="ff_2026_060",
        lifecycle_state="superseded",
        superseded_by="ff_2099_999",  # would fail in --dir
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--file", str(entry),
    )
    result.expect(0)


# --------------------------------------------------------------------------
# 8. v4.89 grandfather entries cannot be referenced (no ff_id)
# --------------------------------------------------------------------------

def test_legacy_v489_entry_no_lifecycle_no_referent_check(
    ltm_failures_dir: Path,
):
    """A legacy v4.89-shipped entry (captured pre-cutoff, no ff_id /
    schema_version / lifecycle_state) is grandfathered with WARNINGs
    and does not contribute to the ff_id set. It also does not
    declare any referent fields, so cross-entry integrity ignores it
    entirely. The directory passes clean."""
    make_entry(
        ltm_failures_dir,
        "legacy_2026_05_03.md",
        captured_at="2026-05-03T12:00:00Z",
        ff_id=None,
        failure_pattern=None,
        fix_pattern=None,
        schema_version=None,
        lifecycle_state=None,
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(0)
    # Sanity: warnings should be present (grandfather signal).
    assert "WARN" in result.stdout


# --------------------------------------------------------------------------
# 9. deprecated_at conditional companion + clean referent set
# --------------------------------------------------------------------------

def test_deprecated_with_deprecated_at_passes_clean(ltm_failures_dir: Path):
    """Sentinel that the existing conditional-companion machinery
    (lifecycle_state=deprecated requires deprecated_at) still works
    after the Step 12.3 changes — and that an entry that does NOT
    declare any referent fields short-circuits the new check."""
    make_entry(
        ltm_failures_dir,
        "deprecated.md",
        ff_id="ff_2026_070",
        lifecycle_state="deprecated",
        deprecated_at="2026-05-14",
    )
    result = run_script(
        "validate_failure_fix_entry.py",
        "--dir", str(ltm_failures_dir),
    )
    result.expect(0)
