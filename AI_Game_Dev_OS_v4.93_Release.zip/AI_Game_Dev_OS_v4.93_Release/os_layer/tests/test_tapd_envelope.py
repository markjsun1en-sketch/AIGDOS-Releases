"""Tests for A2 tapd_adapter_stub._emit_silent_failure_audit routing
through wrap_external_record."""
from __future__ import annotations

import json
from pathlib import Path

from integrations.tapd_adapter_stub import _emit_silent_failure_audit


def test_silent_failure_produces_canonical_envelope(workspace: Path):
    _emit_silent_failure_audit(
        workspace=workspace,
        config={"runtime_profile": "workbuddy_private"},
        external_id="story-1024",
        auth_errors=["stub_auth_failed"],
        verify={"retries": 3, "reason": "mismatch"},
    )
    audit = (workspace / "runtime" / "logs" / "mcp_audit.jsonl").read_text().strip()
    rec = json.loads(audit)
    required = {
        "event_id", "event_type", "timestamp", "actor",
        "runtime_profile", "result", "source_layer", "audit_status",
        "details",
    }
    assert required.issubset(rec)


def test_silent_failure_carries_failed_audit_status(workspace: Path):
    _emit_silent_failure_audit(
        workspace=workspace,
        config={"runtime_profile": "workbuddy_private"},
        external_id="story-2048",
        auth_errors=[],
        verify={"retries": 0, "reason": "ok_stub"},
    )
    rec = json.loads(
        (workspace / "runtime" / "logs" / "mcp_audit.jsonl").read_text().strip()
    )
    assert rec["source_layer"] == "tapd"
    assert rec["audit_status"] == "failed"
    assert rec["event_type"] == "external.tapd.verify"
    assert rec["result"] == "warn"
