"""Tests for verify_beta_sprint_exit.check_init_integrity
claude_code_subagents schema cross-check
(v4.89 Phase 2 Stage 2 / M6.7 · updated Phase 4 / M7.3.3).

Contract surface
----------------
The cross-check fires when ``runtime_state.profile ==
"claude_code_subagents"``:

    audit_collector         must equal "claude_subagents_collector"
    context_loading_method  must equal "claude_docs_plus_hooks"

Two severities, different semantics:

- **ERROR** (M7.3.3 lift) — field absent from runtime_state.  Contract
  violation: post-M7.3.2 ``_stub_init`` must canonically write these
  fields from the profile JSON.
- **WARN** (M6.7 semantics, preserved) — field present but value
  contradicts ground truth.  Schema drift, non-fatal.

M6.7 dimension choice (preserved from pre-M7.3 era)
---------------------------------------------------
Unlike M6.4-M6.6 (which all used coordination_model + writeback_owner),
M6.7 picks audit_collector + context_loading_method.  Reason:
``claude_code_subagents.json`` ground truth declares
``coordination_model = parent_subagents`` and ``writeback_owner =
parent`` — *identical* to codex.  Reusing those dimensions would
make a claude_subagents negative mirror with codex-style drift values
satisfy claude_subagents's own ground truth.  audit_collector /
context_loading_method are unique per profile, so no such collision.

The structurally distinct fourth case is also the strongest input
for the Phase 3 / Phase 4 schema-driven cross-checker collapse + lift.

See ltm/failures/2026-05-05_claude_subagents_silent_pass_blindness.md
and docs/06_runtime_profiles/PHASE_4_LIFT_GATE_AUDIT.md §1 §4.
"""
from __future__ import annotations

import json
from pathlib import Path

from verify_beta_sprint_exit import VerifyContext, check_init_integrity


def _make_state(workspace: Path, **fields) -> Path:
    rs_dir = workspace / "runtime" / "state"
    rs_dir.mkdir(parents=True, exist_ok=True)
    rs = rs_dir / "runtime_state.json"
    base = {
        "project_id": "rh_sprint_sim_01",
        "runtime_profile": "workbuddy_private",
        "profile": "workbuddy_private",
        "initialized_at": "2026-05-02T12:00:00Z",
    }
    base.update(fields)
    rs.write_text(json.dumps(base, indent=2) + "\n", encoding="utf-8")
    return rs


def _ctx(workspace: Path, runtime_state: Path) -> VerifyContext:
    return VerifyContext(
        workspace=workspace,
        audit_log=workspace / "runtime" / "logs" / "mcp_audit.jsonl",
        runtime_state=runtime_state,
        sprint_close_checklist=(
            workspace / "runtime" / "state" / "sprint_close_checklist.md"
        ),
    )


def _claude_subagents_drift_findings(findings: list[dict]) -> list[dict]:
    """Filter to M6.7 claude_subagents schema drift findings (WARN).

    The contract_field set (audit_collector / context_loading_method)
    is disjoint from M6.4-M6.6, so the profile=claude_code_subagents
    message pin is technically redundant; kept for stylistic symmetry.
    """
    return [
        f for f in findings
        if f.get("category") == "init"
        and f.get("severity") == "WARN"
        and f.get("contract_field") in {"audit_collector", "context_loading_method"}
        and "profile=claude_code_subagents" in f.get("message", "")
    ]


def _claude_subagents_missing_findings(findings: list[dict]) -> list[dict]:
    """Filter to M7.3.3 claude_subagents missing-contract-field ERRORs."""
    return [
        f for f in findings
        if f.get("category") == "init"
        and f.get("severity") == "ERROR"
        and f.get("contract_field") in {"audit_collector", "context_loading_method"}
        and "profile=claude_code_subagents" in f.get("message", "")
        and "missing contract field" in f.get("message", "")
    ]


# C1 — P1 baseline unaffected --------------------------------------------------


def test_p1_baseline_unaffected_by_claude_subagents_check(workspace: Path):
    """workbuddy_private state → 0 claude_subagents findings."""
    rs = _make_state(workspace)
    findings = check_init_integrity(_ctx(workspace, rs))
    assert _claude_subagents_drift_findings(findings) == []
    assert _claude_subagents_missing_findings(findings) == []


# C2 — claude_subagents positive (clean) mirror — M7.3.3 flips to 2 ERROR -----


def test_claude_subagents_positive_mirror_clean(workspace: Path):
    """profile=claude_code_subagents + NO contract fields → M7.3.3:
    2 ERROR (audit_collector + context_loading_method), 0 WARN."""
    rs = _make_state(
        workspace,
        profile="claude_code_subagents",
        runtime_profile="claude_code_subagents",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    assert _claude_subagents_drift_findings(findings) == []
    missing = _claude_subagents_missing_findings(findings)
    assert len(missing) == 2
    assert {f["contract_field"] for f in missing} == {
        "audit_collector",
        "context_loading_method",
    }


# C3 — audit_collector drift ---------------------------------------------------


def test_claude_subagents_negative_audit_collector_drift(workspace: Path):
    """profile=claude_code_subagents + audit_collector=legacy_collector +
    context_loading_method=claude_docs_plus_hooks (correct) → 1 WARN / 0 ERROR."""
    rs = _make_state(
        workspace,
        profile="claude_code_subagents",
        runtime_profile="claude_code_subagents",
        audit_collector="legacy_collector",
        context_loading_method="claude_docs_plus_hooks",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    drift = _claude_subagents_drift_findings(findings)
    assert len(drift) == 1
    assert drift[0]["contract_field"] == "audit_collector"
    assert "claude_subagents_collector" in drift[0]["message"]
    assert "legacy_collector" in drift[0]["message"]
    assert _claude_subagents_missing_findings(findings) == []


# C4 — context_loading_method drift --------------------------------------------


def test_claude_subagents_negative_context_method_drift(workspace: Path):
    """profile=claude_code_subagents + audit_collector=claude_subagents_collector
    (correct) + context_loading_method=project_docs_plus_selected_files →
    1 WARN / 0 ERROR."""
    rs = _make_state(
        workspace,
        profile="claude_code_subagents",
        runtime_profile="claude_code_subagents",
        audit_collector="claude_subagents_collector",
        context_loading_method="project_docs_plus_selected_files",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    drift = _claude_subagents_drift_findings(findings)
    assert len(drift) == 1
    assert drift[0]["contract_field"] == "context_loading_method"
    assert "claude_docs_plus_hooks" in drift[0]["message"]
    assert "project_docs_plus_selected_files" in drift[0]["message"]
    assert _claude_subagents_missing_findings(findings) == []


# C5 — combined drift (both fields) --------------------------------------------


def test_claude_subagents_negative_combined_drift(workspace: Path):
    """Both contract fields present but drifted → exactly 2 WARN,
    mirroring rh_sprint_sim_01__claude_code_subagents_negative."""
    rs = _make_state(
        workspace,
        profile="claude_code_subagents",
        runtime_profile="claude_code_subagents",
        audit_collector="legacy_collector",
        context_loading_method="project_docs_plus_selected_files",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    drift = _claude_subagents_drift_findings(findings)
    fields_seen = {f["contract_field"] for f in drift}
    assert fields_seen == {"audit_collector", "context_loading_method"}
    assert all(f["severity"] == "WARN" for f in drift)
    assert all(f["category"] == "init" for f in drift)
    assert _claude_subagents_missing_findings(findings) == []


# C6 — cross-profile gate guard ------------------------------------------------


def test_codex_profile_with_claude_subagents_drift_does_not_trigger(
    workspace: Path,
):
    """Defensive: a codex profile that declares claude_subagents's
    contract fields must NOT trigger the M6.7 claude_subagents block.
    Codex has no rule on audit_collector / context_loading_method
    (M6.4 codex block targets coordination_model / writeback_owner
    only), so the claude_subagents filter returns empty.

    M7.3.3 side observation: because this state declares NEITHER
    coordination_model NOR writeback_owner (codex's contract surface),
    the codex profile will emit 2 missing-contract-field ERRORs.  We
    assert that too, since it is M7.3.3's raison d'etre.
    """
    rs = _make_state(
        workspace,
        profile="codex",
        runtime_profile="codex",
        audit_collector="legacy_collector",
        context_loading_method="project_docs_plus_selected_files",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    # claude_subagents block should stay silent — it is gated by
    # profile=claude_code_subagents which this state does not declare.
    assert _claude_subagents_drift_findings(findings) == []
    assert _claude_subagents_missing_findings(findings) == []
    # No codex WARN drift — neither coordination_model nor writeback_owner
    # is declared in state, so there is no wrong value to emit.
    codex_drift = [
        f for f in findings
        if f.get("category") == "init"
        and f.get("severity") == "WARN"
        and "profile=codex" in f.get("message", "")
    ]
    assert codex_drift == []
    # But M7.3.3 does emit 2 codex ERRORs (missing contract surface).
    codex_missing = [
        f for f in findings
        if f.get("category") == "init"
        and f.get("severity") == "ERROR"
        and "profile=codex" in f.get("message", "")
        and "missing contract field" in f.get("message", "")
    ]
    assert len(codex_missing) == 2
    assert {f["contract_field"] for f in codex_missing} == {
        "coordination_model",
        "writeback_owner",
    }
