"""Tests for verify_beta_sprint_exit.check_init_integrity codex
schema cross-check (v4.89 Phase 2 Stage 2 / M6.4 · updated Phase 4 / M7.3.3).

Contract surface
----------------
The cross-check fires when ``runtime_state.profile == "codex"``:

    coordination_model must equal "parent_subagents"
    writeback_owner    must equal "parent"

Two severities, different semantics:

- **ERROR** (M7.3.3 lift) — field absent from runtime_state.  Post-M7.3.2
  ``_stub_init`` is contractually required to write these fields from the
  authoritative profile JSON, so an absent field means init either never
  ran, ran with profile JSON degraded, or a caller hand-edited the state
  and dropped the field.  All three are contract violations.
- **WARN** (M6.4 semantics, preserved) — field present but value
  contradicts the codex ground truth.  Schema drift, non-fatal.

The gate-by-explicit-declaration that kept the 5 positive mirrors green
pre-M7.3 was the silent-PASS residual.  Post-lift, a positive mirror
whose state predates M7.3.2 emits 2 ERROR (one per contract field).
See ltm/failures/2026-05-05_codex_silent_pass_blindness.md and
docs/06_runtime_profiles/PHASE_4_LIFT_GATE_AUDIT.md §1 §4.
"""
from __future__ import annotations

import json
from pathlib import Path

from verify_beta_sprint_exit import VerifyContext, check_init_integrity


def _make_state(workspace: Path, **fields) -> Path:
    """Materialise a runtime_state.json under the canonical location.

    ``fields`` are merged on top of a minimal valid baseline (project_id,
    initialized_at, profile/runtime_profile defaulting to workbuddy_private)
    so individual tests only specify what they want to override.
    """
    rs_dir = workspace / "runtime" / "state"
    rs_dir.mkdir(parents=True, exist_ok=True)
    rs = rs_dir / "runtime_state.json"
    base = {
        "project_id": "rh_sprint_sim_01",
        "runtime_profile": "workbuddy_private",
        "profile": "workbuddy_private",
        "initialized_at": "2026-05-02T12:00:00Z",
    }
    base.update(fields)
    rs.write_text(json.dumps(base, indent=2) + "\n", encoding="utf-8")
    return rs


def _ctx(workspace: Path, runtime_state: Path) -> VerifyContext:
    return VerifyContext(
        workspace=workspace,
        audit_log=workspace / "runtime" / "logs" / "mcp_audit.jsonl",
        runtime_state=runtime_state,
        sprint_close_checklist=(
            workspace / "runtime" / "state" / "sprint_close_checklist.md"
        ),
    )


def _codex_drift_findings(findings: list[dict]) -> list[dict]:
    """Filter to the M6.4 codex schema drift findings (WARN only — value
    mismatch against ground truth).

    M6.5 note: cursor cross-check shares the contract_field names
    (coordination_model / writeback_owner), so the filter additionally
    pins on ``profile=codex`` substring in the message to keep this
    helper codex-specific.
    """
    return [
        f for f in findings
        if f.get("category") == "init"
        and f.get("severity") == "WARN"
        and f.get("contract_field") in {"coordination_model", "writeback_owner"}
        and "profile=codex" in f.get("message", "")
    ]


def _codex_missing_findings(findings: list[dict]) -> list[dict]:
    """Filter to the M7.3.3 codex missing-contract-field ERRORs.

    Paired with ``_codex_drift_findings`` so tests can distinguish
    "state is silent on the field" (ERROR) from "state has a wrong
    value" (WARN)."""
    return [
        f for f in findings
        if f.get("category") == "init"
        and f.get("severity") == "ERROR"
        and f.get("contract_field") in {"coordination_model", "writeback_owner"}
        and "profile=codex" in f.get("message", "")
        and "missing contract field" in f.get("message", "")
    ]


# C1 — P1 baseline unaffected --------------------------------------------------


def test_p1_baseline_unaffected_by_codex_check(workspace: Path):
    """workbuddy_private state → 0 codex findings (both WARN and ERROR
    filters).  The codex cross-check is gated on ``profile == codex``;
    wb_private state must not trip it regardless of which contract
    fields are or are not present."""
    rs = _make_state(workspace)  # profile=workbuddy_private by default
    findings = check_init_integrity(_ctx(workspace, rs))
    assert _codex_drift_findings(findings) == []
    assert _codex_missing_findings(findings) == []


# C2 — codex positive (clean) mirror — M7.3.3 flips this from 0 to 2 ERROR ---


def test_codex_positive_mirror_clean(workspace: Path):
    """profile=codex + NO contract fields declared.

    Pre-M7.3.3: the gate-by-explicit-declaration let this pass silently
    with 0 findings — the M7.3 silent-PASS residual.
    Post-M7.3.3: the schema checker emits ``ERROR(missing contract
    field)`` for each absent field (``coordination_model``,
    ``writeback_owner``).  There are still 0 WARN findings because
    WARN requires an explicit wrong value, which is not present here.
    """
    rs = _make_state(workspace, profile="codex", runtime_profile="codex")
    findings = check_init_integrity(_ctx(workspace, rs))
    assert _codex_drift_findings(findings) == []
    missing = _codex_missing_findings(findings)
    assert len(missing) == 2, (
        f"expected 2 missing-contract-field ERRORs, got {len(missing)}: {missing}"
    )
    assert {f["contract_field"] for f in missing} == {
        "coordination_model",
        "writeback_owner",
    }


# C3 — coordination_model drift ------------------------------------------------


def test_codex_negative_coordination_drift(workspace: Path):
    """profile=codex + coordination_model=private_coordinated +
    writeback_owner=parent (correct).  M7.3.3 semantics: 1 WARN on
    coordination_model (wrong value), 0 ERROR (both fields are present)."""
    rs = _make_state(
        workspace,
        profile="codex",
        runtime_profile="codex",
        coordination_model="private_coordinated",
        writeback_owner="parent",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    drift = _codex_drift_findings(findings)
    assert len(drift) == 1
    assert drift[0]["contract_field"] == "coordination_model"
    assert "parent_subagents" in drift[0]["message"]
    assert "private_coordinated" in drift[0]["message"]
    # No missing-field ERRORs — both contract fields are present.
    assert _codex_missing_findings(findings) == []


# C4 — writeback_owner drift ---------------------------------------------------


def test_codex_negative_writeback_drift(workspace: Path):
    """profile=codex + coordination_model=parent_subagents (correct) +
    writeback_owner=main_session.  M7.3.3 semantics: 1 WARN on
    writeback_owner, 0 ERROR."""
    rs = _make_state(
        workspace,
        profile="codex",
        runtime_profile="codex",
        coordination_model="parent_subagents",
        writeback_owner="main_session",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    drift = _codex_drift_findings(findings)
    assert len(drift) == 1
    assert drift[0]["contract_field"] == "writeback_owner"
    assert "parent" in drift[0]["message"]
    assert "main_session" in drift[0]["message"]
    assert _codex_missing_findings(findings) == []


# C5 — combined drift (both fields) --------------------------------------------


def test_codex_negative_combined_drift(workspace: Path):
    """Both contract fields present but both drifted → exactly 2 WARN.
    This mirrors the rh_sprint_sim_01__codex_negative trial workspace
    shape (contract fields injected with wrong values)."""
    rs = _make_state(
        workspace,
        profile="codex",
        runtime_profile="codex",
        coordination_model="private_coordinated",
        writeback_owner="main_session",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    drift = _codex_drift_findings(findings)
    fields_seen = {f["contract_field"] for f in drift}
    assert fields_seen == {"coordination_model", "writeback_owner"}
    assert all(f["severity"] == "WARN" for f in drift)
    assert all(f["category"] == "init" for f in drift)
    # Both fields present — no missing-field ERRORs.
    assert _codex_missing_findings(findings) == []


# Bonus guard — non-codex profiles never trigger even with drift fields --------


def test_non_codex_profile_with_codex_fields_does_not_trigger(workspace: Path):
    """Defensive: a cursor / claude_* profile that happens to declare
    coordination_model / writeback_owner must NOT be evaluated against
    the codex contract.  The cross-check is codex-gated by design;
    M6.5+ owns symmetric checks for the other profiles."""
    rs = _make_state(
        workspace,
        profile="cursor",
        runtime_profile="cursor",
        coordination_model="private_coordinated",
        writeback_owner="main_session",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    assert _codex_drift_findings(findings) == []
    assert _codex_missing_findings(findings) == []
