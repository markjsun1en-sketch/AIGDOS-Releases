"""M6.3 per-profile trial workspace mirror contract tests — v4.89.

Covers the mirror generator (scripts/mirror_trial_workspace.py) and
the 5 committed mirror trees under trial_workspaces/.  The generator
is part of the M6.8 regression reproducibility contract; these tests
ensure the contract holds now and prevents silent drift later.
"""
from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

import pytest

# conftest.py has already prepended scripts/ to sys.path.
from beta_sprint_driver import main as driver_main  # noqa: E402
from mirror_trial_workspace import main as mirror_main  # noqa: E402


_PKG_ROOT = Path(__file__).resolve().parents[1]
_BASELINE = _PKG_ROOT / "trial_workspaces" / "rh_sprint_sim_01"

_MIRRORED_PROFILES = (
    "codex",
    "cursor",
    "claude_code_agent_teams",
    "claude_code_subagents",
    "default_beta_codex_tapd_git",
)


def _mirror_dir(profile: str) -> Path:
    return _PKG_ROOT / "trial_workspaces" / f"rh_sprint_sim_01__{profile}"


def _hash_tree(root: Path) -> str:
    """Stable content hash of a directory tree — used for idempotency."""
    h = hashlib.sha256()
    for f in sorted(root.rglob("*")):
        if not f.is_file():
            continue
        rel = f.relative_to(root).as_posix()
        h.update(rel.encode("utf-8"))
        h.update(b"\x00")
        h.update(f.read_bytes())
        h.update(b"\x00")
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Structural tests on the committed 5 mirrors
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("profile", _MIRRORED_PROFILES)
def test_all_five_mirrors_exist(profile):
    m = _mirror_dir(profile)
    assert m.is_dir(), f"mirror missing: {m}"
    assert (m / "runtime_state.json").is_file()
    assert (m / "runtime" / "state" / "runtime_state.json").is_file()
    assert (m / "config" / "profiles" / f"{profile}.json").is_file()
    assert (m / "runtime" / "logs" / "mcp_audit.jsonl").is_file()


@pytest.mark.parametrize("profile", _MIRRORED_PROFILES)
def test_mirror_runtime_state_profile_correct(profile):
    """Both runtime_state.json copies (root shim + canonical nested)
    must carry the mirror's profile.  Root shim only has the
    ``_moved_to`` hint and is exempt from profile fields."""
    nested = _mirror_dir(profile) / "runtime" / "state" / "runtime_state.json"
    data = json.loads(nested.read_text(encoding="utf-8"))
    assert data["profile"] == profile
    assert data["runtime_profile"] == profile


@pytest.mark.parametrize("profile", _MIRRORED_PROFILES)
def test_mirror_config_profile_file_correct(profile):
    cfg = _mirror_dir(profile) / "config" / "profiles"
    jsons = list(cfg.glob("*.json"))
    assert len(jsons) == 1, f"expected single json, got {[j.name for j in jsons]}"
    assert jsons[0].stem == profile


@pytest.mark.parametrize("profile", _MIRRORED_PROFILES)
def test_mirror_audit_log_events_carry_mirror_profile(profile):
    """Every audit event line must have runtime_profile == mirror's
    profile (otherwise verify.py's source_layer/profile cross-checks
    can surface false-positive mismatches in downstream milestones)."""
    log = _mirror_dir(profile) / "runtime" / "logs" / "mcp_audit.jsonl"
    lines = [ln for ln in log.read_text(encoding="utf-8").splitlines() if ln.strip()]
    assert lines, f"audit log unexpectedly empty: {log}"
    for ln in lines:
        evt = json.loads(ln)
        if "runtime_profile" in evt:
            assert evt["runtime_profile"] == profile, (
                f"{log}: event runtime_profile={evt['runtime_profile']!r} "
                f"does not match mirror profile {profile!r}"
            )


@pytest.mark.parametrize("profile", _MIRRORED_PROFILES)
def test_mirror_disk_footprint_within_budget(profile):
    """Plan §九 risk: mirror size should stay small (~150 KB baseline);
    anything > 250 KB is a drift signal (e.g. pycache leaked back in)."""
    m = _mirror_dir(profile)
    total = sum(p.stat().st_size for p in m.rglob("*") if p.is_file())
    assert total < 250 * 1024, f"{profile} mirror too big: {total} bytes"


# ---------------------------------------------------------------------------
# Generator CLI contract tests (run against tmp_path, never touches the
# committed mirrors — safe under pytest --forked / pytest-xdist)
# ---------------------------------------------------------------------------


def test_generator_idempotent(tmp_path):
    """Running the generator twice on the same target must produce
    identical contents (the 2nd run requires --force)."""
    target = tmp_path / "iter1"
    rc1 = mirror_main([
        "--source", str(_BASELINE),
        "--target", str(target),
        "--profile", "codex",
    ])
    assert rc1 == 0
    h1 = _hash_tree(target)

    rc2 = mirror_main([
        "--source", str(_BASELINE),
        "--target", str(target),
        "--profile", "codex",
        "--force",
    ])
    assert rc2 == 0
    h2 = _hash_tree(target)
    assert h1 == h2, "generator is not idempotent"


def test_generator_rejects_unknown_profile(tmp_path, capsys):
    target = tmp_path / "bogus"
    rc = mirror_main([
        "--source", str(_BASELINE),
        "--target", str(target),
        "--profile", "not_a_real_profile_xyz",
    ])
    err = capsys.readouterr().err
    assert rc == 2
    assert "unknown profile" in err


def test_generator_rejects_missing_source(tmp_path, capsys):
    target = tmp_path / "will_not_exist"
    rc = mirror_main([
        "--source", str(tmp_path / "nope" / "here"),
        "--target", str(target),
        "--profile", "codex",
    ])
    err = capsys.readouterr().err
    assert rc == 2
    assert "source not found" in err


def test_generator_target_exists_no_force(tmp_path, capsys):
    target = tmp_path / "existing"
    target.mkdir()
    rc = mirror_main([
        "--source", str(_BASELINE),
        "--target", str(target),
        "--profile", "codex",
    ])
    err = capsys.readouterr().err
    assert rc == 1
    assert "target exists" in err
    assert "--force" in err


def test_generator_preserves_source(tmp_path):
    """Plan §九 risk: mirror generation must never mutate the source.
    We hash the baseline before and after a generator run."""
    before = _hash_tree(_BASELINE)
    target = tmp_path / "mirror"
    rc = mirror_main([
        "--source", str(_BASELINE),
        "--target", str(target),
        "--profile", "cursor",
    ])
    assert rc == 0
    after = _hash_tree(_BASELINE)
    assert before == after, "generator mutated its own source tree"


# ---------------------------------------------------------------------------
# End-to-end: driver against the committed mirrors
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("profile", _MIRRORED_PROFILES)
def test_driver_against_mirror_scaffold_passes(profile, capsys):
    """SCAFFOLD maturity (execution + external) is profile-agnostic in
    v4.89; every mirror must PASS at SCAFFOLD.  Anything else signals
    either a mirror bug (G-c2 territory) or a verify.py regression."""
    rc = driver_main([
        "--profile", profile,
        "--maturity", "SCAFFOLD",
        "--workspace", str(_mirror_dir(profile)),
    ])
    capsys.readouterr()
    assert rc == 0, f"{profile} SCAFFOLD exit={rc}, expected 0 (PASS)"


@pytest.mark.parametrize("profile", _MIRRORED_PROFILES)
def test_driver_against_mirror_guided_not_fail(profile, capsys):
    """GUIDED maturity (all 5 categories) is the probe surface for
    M6.4-M6.7.  This test enforces only "no FAIL / no INTERNAL_ERROR"
    — any real findings are handed off to M6.4-M6.7 / M6.8.

    Known P6 signal: default_beta_codex_tapd_git hits a WARN because
    verify.py's init-check hard-codes the 5-core-profile enum. That
    was inventory §3.2 G-b2 territory; **RESOLVED in M7.0** (Phase 3
    Lock-A): _VALID_PROFILES extended to include the 6th profile +
    profile JSON gained context_loading_method. P6/GUIDED now PASSes
    cleanly; this test's `rc in (0, 1)` envelope still accepts both
    PASS and CONDITIONAL outcomes for forward-compat.

    M7.3.3 transient note (resolved in M7.3.4b / commit 7e0499b →
    commit 6): during the lift gate rollout the envelope was
    temporarily widened to ``rc in (0, 1, 2)`` because the old mirror
    state files predated the M7.3.2 contract-surface write.  After
    M7.3.4a regenerated the mirrors, the envelope narrows back to
    the original ``rc in (0, 1)``.  If a future milestone re-triggers
    a transient like this, widen the envelope in the same commit
    that introduces the transient and narrow it again once the
    mirrors are regenerated.
    """
    rc = driver_main([
        "--profile", profile,
        "--maturity", "GUIDED",
        "--workspace", str(_mirror_dir(profile)),
    ])
    capsys.readouterr()
    assert rc in (0, 1), (
        f"{profile} GUIDED exit={rc}; expected 0 (PASS) or 1 (CONDITIONAL), "
        f"not 2 (FAIL) or 3 (INTERNAL_ERROR). M6.3 contract: mirrors produce "
        f"probe-ready workspaces; FAIL/INTERNAL_ERROR indicates a mirror bug."
    )
