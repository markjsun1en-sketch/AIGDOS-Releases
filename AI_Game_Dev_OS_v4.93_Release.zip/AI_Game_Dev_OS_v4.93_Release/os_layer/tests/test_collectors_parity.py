"""5-profile collector parity test (v4.89 Phase 2 Stage 2 B1).

Validates that the five runtime-profile collectors (workbuddy_private /
codex / cursor / claude_code_agent_teams / claude_code_subagents) expose
the *exact same* hardened audit surface after the B1 ``_base`` extraction.

What this test guards (per Stage 2 charter §3.1 parity claim):

1. Each collector re-exports the public audit API:
   ``wrap_external_record`` / ``append_audit`` / ``AuditAppendError`` /
   ``AUDIT_STATUS_*`` / ``AUDIT_RELATIVE_PATH`` /
   ``MALFORMED_AUDIT_RELATIVE``.
2. All five point to the *same* underlying object (identity-equal)
   because they re-export from ``._base`` — this is the contract
   guarantee that "helper scope overrun" cannot drift between profiles.
3. Each collector has a ``normalize_event(raw_event: dict) -> dict``
   callable with the same signature shape, and its return value carries
   the canonical keys (``event_type`` / ``timestamp`` / ``actor`` /
   ``runtime_profile`` / ``result`` / ``details``).
4. ``wrap_external_record`` + ``append_audit`` compose correctly from
   each collector, producing a 9-field envelope and a JSONL audit line.

What this test does NOT claim (deferred to S2.4~S2.7 dry-run):

- That the concrete ``normalize_event`` projection is semantically
  identical across profiles. Profile-specific refinement is expected
  later; this test only guards the contract shape.
- That ``isolation_unit`` / ``cleanup_owner`` / sink destination are
  identical — Stage 2 charter §3 explicitly allows these to differ.
"""
from __future__ import annotations

import importlib
import json

import pytest


# Ordered per config/profiles/*.json canonical roster (Stage 2 handoff §2).
PROFILE_MODULES = [
    ("workbuddy_private", "workbuddy_collector"),
    ("codex", "codex_collector"),
    ("cursor", "cursor_collector"),
    ("claude_code_agent_teams", "claude_teams_collector"),
    ("claude_code_subagents", "claude_subagents_collector"),
]


# ---------------------------------------------------------------------------
# Per-profile surface parity
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("profile,module_name", PROFILE_MODULES)
def test_collector_re_exports_audit_surface(profile, module_name):
    """Every collector exposes the full audit surface with the right names."""
    module = importlib.import_module(
        f"runtime.observability.runtime_event_collectors.{module_name}"
    )
    expected_names = [
        "AUDIT_RELATIVE_PATH",
        "MALFORMED_AUDIT_RELATIVE",
        "AUDIT_STATUS_PENDING",
        "AUDIT_STATUS_EMITTED",
        "AUDIT_STATUS_FAILED",
        "AuditAppendError",
        "wrap_external_record",
        "append_audit",
        "normalize_event",
    ]
    missing = [name for name in expected_names if not hasattr(module, name)]
    assert not missing, (
        f"{module_name} missing audit surface names: {missing}"
    )


@pytest.mark.parametrize("profile,module_name", PROFILE_MODULES)
def test_collector_reexport_is_identical_to_base(profile, module_name):
    """Re-exported audit helpers must be the same object as in ``_base``.

    Identity (not mere equality) is the key invariant — otherwise
    monkeypatching one collector in a test could drift from what
    another collector actually runs, producing false-parity illusions.
    """
    base = importlib.import_module(
        "runtime.observability.runtime_event_collectors._base"
    )
    module = importlib.import_module(
        f"runtime.observability.runtime_event_collectors.{module_name}"
    )
    for name in (
        "wrap_external_record",
        "append_audit",
        "AuditAppendError",
        "AUDIT_RELATIVE_PATH",
        "MALFORMED_AUDIT_RELATIVE",
        "AUDIT_STATUS_PENDING",
        "AUDIT_STATUS_EMITTED",
        "AUDIT_STATUS_FAILED",
        "_ALLOWED_SOURCE_LAYERS",
        "_REQUIRED_ENVELOPE_FIELDS",
    ):
        assert getattr(module, name) is getattr(base, name), (
            f"{module_name}.{name} is not the same object as _base.{name} — "
            "re-export has drifted"
        )


@pytest.mark.parametrize("profile,module_name", PROFILE_MODULES)
def test_normalize_event_contract_shape(profile, module_name):
    """Every collector's ``normalize_event`` returns the canonical dict shape."""
    module = importlib.import_module(
        f"runtime.observability.runtime_event_collectors.{module_name}"
    )
    raw = {
        "event_type": "runtime.test",
        "timestamp": "2026-05-04T12:00:00Z",
        "actor": "parity_test",
        "runtime_profile": profile,
        "result": "ok",
    }
    out = module.normalize_event(raw)
    assert isinstance(out, dict)
    for key in (
        "event_type", "timestamp", "actor", "runtime_profile",
        "result", "details",
    ):
        assert key in out, f"{module_name}.normalize_event missing key {key!r}"
    assert out["event_type"] == "runtime.test"
    assert out["runtime_profile"] == profile
    assert out["details"] == raw


# ---------------------------------------------------------------------------
# End-to-end parity: wrap → append via each collector
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("profile,module_name", PROFILE_MODULES)
def test_wrap_and_append_compose_per_collector(profile, module_name, tmp_path):
    """Driving the audit pipeline through each collector produces a valid
    envelope and a JSONL line at the canonical audit path."""
    module = importlib.import_module(
        f"runtime.observability.runtime_event_collectors.{module_name}"
    )
    raw_record = {
        "id": "parity-42",
        "event": "sprint.exit",
        "status": "pass",
    }
    envelope = module.wrap_external_record(
        raw_record,
        source_layer="tapd",
        runtime_profile=profile,
        actor="parity_test",
    )
    # Envelope shape (9 canonical keys).
    for key in (
        "event_id", "event_type", "timestamp", "actor", "runtime_profile",
        "result", "source_layer", "audit_status", "details",
    ):
        assert key in envelope, f"{module_name} envelope missing {key!r}"
    assert envelope["runtime_profile"] == profile
    assert envelope["source_layer"] == "tapd"
    assert envelope["audit_status"] == module.AUDIT_STATUS_PENDING

    # Append to isolated workspace, then read back.
    ok = module.append_audit(tmp_path, envelope, strict=True)
    assert ok is True
    log_path = tmp_path / module.AUDIT_RELATIVE_PATH
    assert log_path.exists(), f"{module_name} did not create audit log"
    lines = log_path.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1
    parsed = json.loads(lines[0])
    assert parsed["runtime_profile"] == profile
    assert parsed["event_id"] == envelope["event_id"]
