"""Tests for runtime.ltm.consult (v4.89 P2 M2.2)."""
from __future__ import annotations

import importlib
from pathlib import Path

import pytest

from runtime.ltm import consult, KNOWN_DOMAINS

# Import the module object (not the re-exported ``consult`` function)
# so monkeypatching _LTM_ROOT on the module works. ``runtime.ltm``
# re-exports consult in its __init__, shadowing the submodule name
# for a bare attribute lookup.
__consult_mod = importlib.import_module("runtime.ltm.consult")
# Alias so tests below reference the non-mangled name.
_consult_mod = __consult_mod


def _seed_corpus(root: Path, files: dict[str, str]) -> None:
    """Write the given {relative_path: body} dict under ``root``."""
    for rel, body in files.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(body, encoding="utf-8")


def test_empty_query_returns_empty():
    """Empty / whitespace-only query must short-circuit to []."""
    assert consult("") == []
    assert consult("   ") == []
    assert consult("\t\n") == []


def test_unknown_domain_raises_value_error():
    """Programmer-side bug (unknown domain) should surface; contrast
    with I/O errors which are silently defended."""
    with pytest.raises(ValueError) as exc:
        consult("envelope", domain="bogus")
    msg = str(exc.value)
    assert "bogus" in msg
    # Full allowlist in message helps debug typos.
    for d in KNOWN_DOMAINS:
        assert d in msg


def test_known_domains_all_searchable(monkeypatch, tmp_path: Path):
    """Every KNOWN_DOMAINS entry must be accepted without error."""
    # Redirect the LTM root at the module level so we don't pollute the
    # real corpus. This also proves the matcher walks the right dir.

    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)
    _seed_corpus(tmp_path, {
        "os/foo.md": "# Foo\nenvelope contract content\n",
        "project/rh/bar.md": "# Bar\nenvelope line\n",
        "pattern/baz.md": "# Baz\nenvelope mention\n",
        "failures/qux.md": "# Qux\nenvelope-related bug\n",
    })
    for dom in KNOWN_DOMAINS:
        hits = consult("envelope", domain=dom)
        assert len(hits) == 1, f"domain={dom} hits={hits}"
        assert hits[0]["domain"] == dom


def test_score_ranking_and_tie_break(monkeypatch, tmp_path: Path):
    """Higher-score hits come first; ties break by path ASC."""

    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)
    _seed_corpus(tmp_path, {
        # 2 tokens hit (envelope + canonical) → score 2
        "os/a_two_tokens.md": "# A\nthe envelope has canonical form\n",
        # 1 token hit → score 1
        "os/b_one_token.md": "# B\nonly envelope here\n",
        # 1 token hit, same as B → tie, sorted by path → b before c
        "os/c_one_token.md": "# C\nonly envelope also\n",
        # 0 tokens → excluded
        "os/d_no_match.md": "# D\nnothing relevant\n",
    })
    hits = consult("envelope canonical", limit=10)
    assert [h["path"].split("/")[-1] for h in hits] == [
        "a_two_tokens.md",  # score 2, wins
        "b_one_token.md",   # score 1, alphabetically before c
        "c_one_token.md",   # score 1
    ]
    assert hits[0]["score"] == 2
    assert hits[1]["score"] == 1


def test_quarantine_is_skipped(monkeypatch, tmp_path: Path):
    """_quarantine/ is staging, not content — consult() must ignore it."""

    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)
    _seed_corpus(tmp_path, {
        "os/legit.md": "# Legit\nenvelope match here\n",
        "_quarantine/rejected.md": "# Rejected\nenvelope match but quarantined\n",
    })
    hits = consult("envelope")
    # Only the legit file should match. Check by filename rather than
    # substring on the full path — tmp_path's own directory name can
    # contain the literal '_quarantine' when the test is parametrised,
    # which would false-positive a simple substring check.
    filenames = {Path(h["path"]).name for h in hits}
    assert filenames == {"legit.md"}, hits


def test_unreadable_file_does_not_crash(monkeypatch, tmp_path: Path):
    """Non-UTF8 file must score 0 without raising (I/O defensive)."""

    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)

    bad = tmp_path / "os" / "binary.md"
    bad.parent.mkdir(parents=True)
    # Write bytes that are NOT valid UTF-8 (lone continuation byte).
    bad.write_bytes(b"\xff\xfe\xfd invalid utf-8 envelope bytes\n")

    # Also seed a legitimate match so we can assert the binary one was
    # skipped silently, not that consult bailed out entirely.
    (tmp_path / "os" / "valid.md").write_text(
        "# Valid\nenvelope is real here\n", encoding="utf-8",
    )

    hits = consult("envelope")
    paths = {h["path"] for h in hits}
    assert any("valid.md" in p for p in paths), hits
    assert not any("binary.md" in p for p in paths), hits
