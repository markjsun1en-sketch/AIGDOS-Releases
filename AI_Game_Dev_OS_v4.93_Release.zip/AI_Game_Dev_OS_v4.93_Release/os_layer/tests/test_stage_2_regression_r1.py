"""Stage 2 5-profile cross R1 regression matrix
(v4.89 Phase 2 Stage 2 / M6.8).

Purpose
-------
End-to-end regression that locks the 16-verdict matrix produced
across M6.3-M6.7 onto the live driver + mirror tree.  Every test
case spawns ``scripts/beta_sprint_driver.py`` as a subprocess
(matching how a developer or CI invokes the verifier), reads the
JSON envelope from stdout, and asserts on the four signal fields
the postmortems committed to: ``verdict`` / ``error_count`` /
``warn_count`` / ``findings[*].contract_field``.

Why end-to-end and not unit
---------------------------
The four per-profile cross-check tests
(test_verify_codex_cross_check / cursor / claude_teams /
claude_subagents) already cover ``check_init_integrity`` at the
unit layer.  M6.8 adds the *integration* layer: the driver CLI
contract (M6.2 Q5=A), the mirror tree (M6.3 Q2=B), the
``--inject-violation`` opt-in (M6.4 generator), the four
per-profile blocks (M6.4-M6.7), and the SCAFFOLD/GUIDED maturity
gate (M6.0b → M6.2) all wire up here for the first time in a
single suite.  If any of those layers regresses, this test fires
before the 4 unit suites notice — that is the M6.8 reproducibility
contract Q2 promised.

Why subprocess and not in-process
---------------------------------
The driver is a CLI entry point (`if __name__ == "__main__"` at
the bottom of `beta_sprint_driver.py`); the production usage is
``python3 scripts/beta_sprint_driver.py …``.  A subprocess call
exercises argparse, sys.path discovery, JSON serialisation, and
exit code handling — all of which an in-process call to
``main()`` skips.  M6.8 is the gate that catches CLI-level
regressions before M6.9 closes Stage 2.

Matrix (16 rows)
----------------
6 positive mirrors × 2 maturity (SCAFFOLD, GUIDED) = 12
4 negative mirrors × 1 maturity (GUIDED only)      = 4
Total                                                = 16

SCAFFOLD on negative mirrors is intentionally **not** parametrised:
SCAFFOLD floor skips the ``init`` category entirely (M6.4-M6.7
postmortems §"by design" footnote), so all four would assert PASS,
duplicating the positive-SCAFFOLD signal without adding coverage.
The 4 postmortems carry that footnote; this test treats the
positive matrix as the definitive SCAFFOLD coverage.

Failure shapes (what to look at when a case fails)
--------------------------------------------------
The pytest assertion message includes:
  - the full driver stdout JSON envelope (reproducibility)
  - the (profile, maturity, mirror) triple
  - which of {verdict, error_count, warn_count, contract_fields}
    diverged from the expected matrix entry

Cross-check this test against the post-M6.7 verdict matrix in
``docs/06_runtime_profiles/STAGE_2_MATRIX_INVENTORY.md`` §5
post-M6.7 — the two sources must stay in sync.  When inventory §5
adds a row for v4.90+, this test's MATRIX must add a parallel row
in the same commit.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest


# Repo-anchored paths.  ``conftest.py`` already prepends the v4.89
# package root and scripts dir to ``sys.path``; here we only need
# the package root so we can resolve the driver and mirror paths.
_PKG_ROOT = Path(__file__).resolve().parents[1]
_DRIVER = _PKG_ROOT / "scripts" / "beta_sprint_driver.py"
_TRIAL_ROOT = _PKG_ROOT / "trial_workspaces"


# 16-row matrix.  Each tuple:
#   (profile, maturity, mirror_dirname,
#    expected_verdict, expected_warn, expected_error,
#    expected_contract_fields)
#
# expected_contract_fields:
#   - frozenset() means "no contract_field findings expected"
#   - non-empty frozenset means "the init/WARN findings must
#     have exactly these contract_field values, no more no less"
_MATRIX: list[tuple[str, str, str, str, int, int, frozenset[str]]] = [
    # --- 6 positive mirrors × 2 maturity = 12 rows ---------------------
    # P1 baseline (workbuddy_private) — not in _CHECKED_PROFILES, so
    # M7.3.3 lift has no effect here; stays PASS.
    ("workbuddy_private", "SCAFFOLD", "rh_sprint_sim_01",
     "PASS", 0, 0, frozenset()),
    ("workbuddy_private", "GUIDED", "rh_sprint_sim_01",
     "PASS", 0, 0, frozenset()),
    # P2 codex — M7.3 post-regeneration (commit 7e0499b): mirror state
    # now carries the full contract surface (M7.3.4a), so the lifted
    # cross-check finds everything it needs and PASSes with 0 findings.
    ("codex", "SCAFFOLD", "rh_sprint_sim_01__codex",
     "PASS", 0, 0, frozenset()),
    ("codex", "GUIDED", "rh_sprint_sim_01__codex",
     "PASS", 0, 0, frozenset()),
    # P3 cursor — same pattern as P2.
    ("cursor", "SCAFFOLD", "rh_sprint_sim_01__cursor",
     "PASS", 0, 0, frozenset()),
    ("cursor", "GUIDED", "rh_sprint_sim_01__cursor",
     "PASS", 0, 0, frozenset()),
    # P4 claude_code_agent_teams — same pattern.
    ("claude_code_agent_teams", "SCAFFOLD",
     "rh_sprint_sim_01__claude_code_agent_teams",
     "PASS", 0, 0, frozenset()),
    ("claude_code_agent_teams", "GUIDED",
     "rh_sprint_sim_01__claude_code_agent_teams",
     "PASS", 0, 0, frozenset()),
    # P5 claude_code_subagents — same pattern; asymmetric dimensions
    # (audit_collector + context_loading_method) covered by the mirror
    # generator's uniform contract-surface stamp.
    ("claude_code_subagents", "SCAFFOLD",
     "rh_sprint_sim_01__claude_code_subagents",
     "PASS", 0, 0, frozenset()),
    ("claude_code_subagents", "GUIDED",
     "rh_sprint_sim_01__claude_code_subagents",
     "PASS", 0, 0, frozenset()),
    # P6 default_beta_codex_tapd_git — G-b2 RESOLVED in M7.0 (Phase 3
    # Lock-A): _VALID_PROFILES enum extended to include this profile
    # AND profile JSON gained context_loading_method field. P6/GUIDED
    # now matches the other 5 positive mirrors at PASS/0/0.
    #
    # M7.3.3 note: default_beta is NOT in _CHECKED_PROFILES
    # (runtime/schema_driven_check.py), so the lift does not touch it.
    ("default_beta_codex_tapd_git", "SCAFFOLD",
     "rh_sprint_sim_01__default_beta_codex_tapd_git",
     "PASS", 0, 0, frozenset()),
    ("default_beta_codex_tapd_git", "GUIDED",
     "rh_sprint_sim_01__default_beta_codex_tapd_git",
     "PASS", 0, 0, frozenset()),
    # --- 4 negative mirrors × GUIDED = 4 rows --------------------------
    # Negative mirrors carry the contract surface (M7.3.4a) AND the
    # drift injection (_inject_contract_drift overrides 2 fields),
    # so M7.3.3 finds 2 WARN per row on the drifted fields and no
    # ERROR on the remaining correct fields.
    # M6.4 codex_negative — coordination_model + writeback_owner drift
    ("codex", "GUIDED", "rh_sprint_sim_01__codex_negative",
     "CONDITIONAL", 2, 0,
     frozenset({"coordination_model", "writeback_owner"})),
    # M6.5 cursor_negative — coordination_model + writeback_owner drift
    ("cursor", "GUIDED", "rh_sprint_sim_01__cursor_negative",
     "CONDITIONAL", 2, 0,
     frozenset({"coordination_model", "writeback_owner"})),
    # M6.6 claude_teams_negative — coordination_model + writeback_owner drift
    ("claude_code_agent_teams", "GUIDED",
     "rh_sprint_sim_01__claude_code_agent_teams_negative",
     "CONDITIONAL", 2, 0,
     frozenset({"coordination_model", "writeback_owner"})),
    # M6.7 claude_subagents_negative — DIFFERENT dimensions
    # (audit_collector + context_loading_method) due to
    # codex contract collision; see postmortem
    ("claude_code_subagents", "GUIDED",
     "rh_sprint_sim_01__claude_code_subagents_negative",
     "CONDITIONAL", 2, 0,
     frozenset({"audit_collector", "context_loading_method"})),
]


def _run_driver(profile: str, maturity: str, workspace: Path) -> dict:
    """Spawn the driver as a subprocess and return the parsed JSON
    envelope.  Mirrors how a developer invokes verify from a terminal
    and how CI is intended to invoke it.

    Stderr is captured but not returned; on a non-JSON stdout the
    test fails with both streams in the assertion message so the
    failure is debuggable without re-running by hand.
    """
    proc = subprocess.run(
        [
            sys.executable,
            str(_DRIVER),
            "--profile", profile,
            "--maturity", maturity,
            "--workspace", str(workspace),
        ],
        capture_output=True,
        text=True,
        check=False,  # CONDITIONAL/FAIL exit non-zero; we read stdout
        timeout=60,
    )
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise AssertionError(
            f"driver did not emit valid JSON.\n"
            f"  exit={proc.returncode}\n"
            f"  stdout={proc.stdout!r}\n"
            f"  stderr={proc.stderr!r}\n"
            f"  json error={exc}"
        ) from None


def _matrix_id(case: tuple) -> str:
    """Compact pytest id: profile/maturity/mirror_tail."""
    profile, maturity, mirror, *_ = case
    tail = mirror.replace("rh_sprint_sim_01", "P1")
    return f"{profile}/{maturity}/{tail}"


@pytest.mark.parametrize("case", _MATRIX, ids=_matrix_id)
def test_stage_2_r1_regression(case: tuple):
    """End-to-end regression for one matrix row.

    Asserts (in order, fail-fast):
      1. driver exited cleanly (JSON envelope decodable).
      2. verdict matches the post-M6.7 inventory §5 row.
      3. error_count matches (must be 0 on every M6.4-M6.7 row;
         locking it here catches accidental escalation from WARN
         to ERROR if a Phase 3 attempt collapses the if-tree).
      4. warn_count matches.
      5. contract_field set on init/WARN findings is exactly the
         expected frozenset (catches M6.7-style asymmetric blocks
         being merged into M6.4-M6.6 symmetric form by mistake).
    """
    profile, maturity, mirror, exp_verdict, exp_warn, exp_err, exp_fields = case
    workspace = _TRIAL_ROOT / mirror

    assert workspace.is_dir(), (
        f"matrix references missing mirror: {workspace}\n"
        f"  regenerate via scripts/mirror_trial_workspace.py"
    )

    envelope = _run_driver(profile, maturity, workspace)

    # Build a single failure message that includes the whole
    # envelope so a fail can be diagnosed without re-running.
    diag = json.dumps(envelope, ensure_ascii=False, indent=2)

    assert envelope["verdict"] == exp_verdict, (
        f"verdict mismatch on {profile}/{maturity}/{mirror}:\n"
        f"  expected={exp_verdict!r} got={envelope['verdict']!r}\n"
        f"  envelope={diag}"
    )
    assert envelope["error_count"] == exp_err, (
        f"error_count mismatch on {profile}/{maturity}/{mirror}:\n"
        f"  expected={exp_err} got={envelope['error_count']}\n"
        f"  envelope={diag}"
    )
    assert envelope["warn_count"] == exp_warn, (
        f"warn_count mismatch on {profile}/{maturity}/{mirror}:\n"
        f"  expected={exp_warn} got={envelope['warn_count']}\n"
        f"  envelope={diag}"
    )

    # init-category findings (WARN from schema drift, ERROR from
    # M7.3.3 missing-contract-field) carry a contract_field attribute;
    # other categories may emit findings without one (G-b2 on
    # default_beta_codex_tapd_git is one such case).  The matrix's
    # expected_contract_fields column is the union across both
    # severities, so the R1 guard fires correctly for:
    #   - pre-M7.3.3 WARN-only schema drift rows (M6.4-M6.7 negative)
    #   - post-M7.3.3 missing-contract ERROR rows
    #     (M7.3.3 transient: positive mirrors pre-M7.3.4a)
    #   - post-M7.3.4b PASS rows (expected empty set)
    init_contract_fields = frozenset(
        f["contract_field"]
        for f in envelope["findings"]
        if f.get("category") == "init"
        and f.get("severity") in {"WARN", "ERROR"}
        and "contract_field" in f
    )
    assert init_contract_fields == exp_fields, (
        f"init contract_field set mismatch on "
        f"{profile}/{maturity}/{mirror}:\n"
        f"  expected={sorted(exp_fields)}\n"
        f"  got     ={sorted(init_contract_fields)}\n"
        f"  envelope={diag}"
    )


def test_matrix_size_locked():
    """Sanity: the matrix has exactly 16 rows.  Adding a row without
    updating this assertion is intentional friction — Stage 2 closure
    treats the matrix as a contract surface, not a parameter bag."""
    assert len(_MATRIX) == 16, (
        f"_MATRIX length changed unexpectedly to {len(_MATRIX)}; "
        f"if this is intentional (v4.90+ adds a profile or mirror), "
        f"update both this assertion and inventory §5 verdict table"
    )
