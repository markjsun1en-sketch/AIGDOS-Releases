"""test_preflight_schemas.py — v4.91 P1-c (RC1-review gap C).

Locks down the project-level multi-agent preflight workflow (S3
hybrid: single event-stream ledger + three typed details schemas).

Coverage:
1. The 4 schemas/preflight/*.schema.json are valid draft-07 (jsonschema
   importorskip — soft dependency per v4.89 discipline).
2. The envelope's event_type -> details $ref dispatch accepts a
   happy-path event of each kind (jsonschema with a local RefResolver).
3. The consensus allOf guard: evidence_boundary='validated' without a
   validation_plan is rejected by jsonschema.
4. The zero-dependency validator (validate_preflight_reviews.py) agrees
   with the schemas on a valid 3-event sequence and catches the
   semantic negatives (result!=recorded, execution_mode mismatch,
   unresolved request_id, role_notes dangling, validated-missing-plan).
5. The canonical ledger on disk validates clean (empty seed).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = REPO_ROOT / "schemas" / "preflight"
VALIDATOR = REPO_ROOT / "scripts" / "governance" / "validate_preflight_reviews.py"
LEDGER = REPO_ROOT / "runtime" / "registries" / "preflight_review_ledger.jsonl"

ENVELOPE = "preflight_review_event.schema.json"
DETAIL_SCHEMAS = (
    "preflight_request.schema.json",
    "preflight_agent_note.schema.json",
    "preflight_consensus.schema.json",
)


def _load(name: str) -> dict:
    return json.loads((SCHEMA_DIR / name).read_text(encoding="utf-8"))


def _envelope(event_type: str, details: dict, event_id: str = "pf_00000001") -> dict:
    return {
        "schema_version": "1.0.0",
        "event_id": event_id,
        "event_type": event_type,
        "timestamp": "2026-05-30T00:00:00Z",
        "actor": "orch",
        "runtime_profile": "workbuddy",
        "result": "recorded",
        "source_layer": "L1",
        "audit_status": "recorded",
        "details": details,
    }


# ---------------------------------------------------------------------------
# 1. Schema meta-validation
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", (ENVELOPE, *DETAIL_SCHEMAS))
def test_schema_meta_valid(name):
    jsonschema = pytest.importorskip("jsonschema")
    jsonschema.Draft7Validator.check_schema(_load(name))


# ---------------------------------------------------------------------------
# 2-3. Envelope $ref dispatch + consensus allOf guard (jsonschema)
# ---------------------------------------------------------------------------

def _build_validator():
    jsonschema = pytest.importorskip("jsonschema")
    from jsonschema import Draft7Validator
    try:
        from jsonschema.validators import RefResolver  # type: ignore
    except Exception:  # pragma: no cover
        from jsonschema import RefResolver  # type: ignore
    store = {}
    env = None
    for name in (ENVELOPE, *DETAIL_SCHEMAS):
        s = _load(name)
        if s.get("$id"):
            store[s["$id"]] = s
        store[name] = s
        if name == ENVELOPE:
            env = s
    resolver = RefResolver(base_uri=env.get("$id", ""), referrer=env, store=store)
    return Draft7Validator(env, resolver=resolver), jsonschema


def test_envelope_accepts_each_event_type():
    v, _ = _build_validator()
    req = _envelope("preflight_request", {
        "request_id": "pfr_0000aaaa", "task": "t", "risk_surface": ["schema"],
        "candidate_participants": ["agent_governance"],
        "execution_mode": "single_agent_multi_lens",
    })
    note = _envelope("preflight_agent_note", {
        "note_id": "pfn_0000bbbb", "request_id": "pfr_0000aaaa",
        "role": "agent_governance", "fallback_used": True, "findings": "ok",
    }, event_id="pf_00000002")
    cons = _envelope("preflight_consensus", {
        "consensus_id": "pfc_0000cccc", "request_id": "pfr_0000aaaa",
        "decision": "engage_completed", "decided_by": "ep",
        "execution_mode": "single_agent_multi_lens",
        "evidence_boundary": "direction_evidence_only",
    }, event_id="pf_00000003")
    for ev in (req, note, cons):
        v.validate(ev)  # raises on failure


def test_consensus_validated_requires_validation_plan():
    v, jsonschema = _build_validator()
    bad = _envelope("preflight_consensus", {
        "consensus_id": "pfc_0000cccc", "request_id": "pfr_0000aaaa",
        "decision": "engage_completed", "decided_by": "ep",
        "execution_mode": "manual_notes",
        "evidence_boundary": "validated",  # no validation_plan -> must fail
    })
    with pytest.raises(jsonschema.ValidationError):
        v.validate(bad)


def test_envelope_rejects_non_recorded_result():
    v, jsonschema = _build_validator()
    bad = _envelope("preflight_request", {
        "request_id": "pfr_0000aaaa", "task": "t", "risk_surface": [],
        "candidate_participants": ["agent_governance"],
        "execution_mode": "manual_notes",
    })
    bad["result"] = "pass"
    with pytest.raises(jsonschema.ValidationError):
        v.validate(bad)


# ---------------------------------------------------------------------------
# 4. Zero-dependency validator agreement
# ---------------------------------------------------------------------------

def _run_validator(ledger: Path):
    return subprocess.run(
        [sys.executable, str(VALIDATOR), "--ledger", str(ledger), "--json"],
        cwd=str(REPO_ROOT), capture_output=True, text=True, timeout=30,
    )


def test_validator_accepts_valid_sequence(tmp_path):
    led = tmp_path / "ok.jsonl"
    led.write_text("\n".join(json.dumps(e) for e in [
        _envelope("preflight_request", {
            "request_id": "pfr_0000aaaa", "task": "t", "risk_surface": ["schema"],
            "candidate_participants": ["agent_governance"],
            "execution_mode": "single_agent_multi_lens"}, "pf_00000001"),
        _envelope("preflight_agent_note", {
            "note_id": "pfn_0000bbbb", "request_id": "pfr_0000aaaa",
            "role": "agent_governance", "fallback_used": True, "findings": "ok"}, "pf_00000002"),
        _envelope("preflight_consensus", {
            "consensus_id": "pfc_0000cccc", "request_id": "pfr_0000aaaa",
            "decision": "engage_completed", "decided_by": "ep",
            "execution_mode": "single_agent_multi_lens",
            "evidence_boundary": "direction_evidence_only",
            "role_notes": ["pfn_0000bbbb"], "production_brief": "go"}, "pf_00000003"),
    ]) + "\n", encoding="utf-8")
    r = _run_validator(led)
    assert r.returncode == 0, r.stdout + r.stderr
    assert json.loads(r.stdout)["ok"] is True


@pytest.mark.parametrize("line,expect_rule", [
    # execution_mode mismatch between request and consensus
    (
        [
            {"_t": "preflight_request", "execution_mode": "real_subagents"},
            {"_t": "preflight_consensus", "execution_mode": "manual_notes"},
        ],
        "consensus.execution_mode.mismatch",
    ),
])
def test_validator_catches_execution_mode_mismatch(tmp_path, line, expect_rule):
    led = tmp_path / "bad.jsonl"
    req = _envelope("preflight_request", {
        "request_id": "pfr_0000aaaa", "task": "t", "risk_surface": [],
        "candidate_participants": ["agent_governance"],
        "execution_mode": "real_subagents"}, "pf_00000001")
    cons = _envelope("preflight_consensus", {
        "consensus_id": "pfc_0000cccc", "request_id": "pfr_0000aaaa",
        "decision": "skip", "decided_by": "ep",
        "execution_mode": "manual_notes",
        "evidence_boundary": "direction_evidence_only"}, "pf_00000002")
    led.write_text(json.dumps(req) + "\n" + json.dumps(cons) + "\n", encoding="utf-8")
    r = _run_validator(led)
    assert r.returncode == 1
    rules = {v["rule"] for v in json.loads(r.stdout)["violations"]}
    assert expect_rule in rules


def test_validator_catches_unresolved_request_id(tmp_path):
    led = tmp_path / "bad2.jsonl"
    note = _envelope("preflight_agent_note", {
        "note_id": "pfn_0000bbbb", "request_id": "pfr_dddddddd",
        "role": "agent_governance", "fallback_used": False, "findings": "x"}, "pf_00000001")
    led.write_text(json.dumps(note) + "\n", encoding="utf-8")
    r = _run_validator(led)
    assert r.returncode == 1
    rules = {v["rule"] for v in json.loads(r.stdout)["violations"]}
    assert "agent_note.request_id.unresolved" in rules


# ---------------------------------------------------------------------------
# 5. Canonical ledger on disk validates clean
# ---------------------------------------------------------------------------

def test_canonical_ledger_is_clean():
    r = subprocess.run(
        [sys.executable, str(VALIDATOR), "--json"],
        cwd=str(REPO_ROOT), capture_output=True, text=True, timeout=30,
    )
    assert r.returncode == 0, r.stdout + r.stderr
    assert json.loads(r.stdout)["ok"] is True
