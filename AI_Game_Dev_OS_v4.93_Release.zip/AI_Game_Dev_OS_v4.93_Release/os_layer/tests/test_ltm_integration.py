"""Integration tests for LTM — real corpus (v4.89 P2 M4.3).

Unlike test_ltm_consult / test_ltm_capture (which monkey-patch
_LTM_ROOT to tmp_path for isolation), these tests hit the REAL
ltm/ corpus seeded by M1 (scaffolding + READMEs), M4.1 (10 OS
contracts), and M4.2 (2 failure cases). They're the MVP Stage 1
§11 exit-criteria validation in code form.

If any of these fails, it means:
  - the ltm/ corpus was renamed / removed, OR
  - consult()'s scoring/sort behaviour regressed, OR
  - one of the M4 content files was moved to a different domain.
"""
from __future__ import annotations

from pathlib import Path

from runtime.ltm import consult


def test_consult_envelope_hits_os_domain():
    """MVP exit criterion: consult('envelope') returns >=3 hits from
    ltm/os/ (plans/swift-nebula-babbage.md §11)."""
    hits = consult("envelope", limit=20)
    os_hits = [h for h in hits if h["domain"] == "os"]
    # Stricter than the §11 floor of 3 — we know M4.1 shipped 6 files
    # that mention 'envelope' (direct or via cross-links).
    assert len(os_hits) >= 3, {
        "all_hits": hits,
        "os_hits_count": len(os_hits),
    }

    # Every hit path should be relative to package root (not absolute,
    # not './ltm/...').
    for h in os_hits:
        assert h["path"].startswith("ltm/os/"), h


def test_consult_failures_covers_phase1_postmortems():
    """consult('verification_ok') should surface A4 failure case;
    consult('pointer shim') should surface Z1 failure case."""
    verify_hits = consult("verification_ok", domain="failures")
    assert any(
        "a4_dry_run_verify_fail" in h["path"] for h in verify_hits
    ), verify_hits

    pointer_hits = consult("pointer shim", domain="failures")
    assert any(
        "z1_closed_at_null" in h["path"] for h in pointer_hits
    ), pointer_hits
