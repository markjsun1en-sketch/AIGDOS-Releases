"""test_execution_mode_required.py — v4.91 M-C B5C c3.

Pins the multi-agent-preflight-review skill skeleton (added in c2) to
its declared shape: SKILL.md exists with valid YAML front-matter,
REFERENCES.md cross-links the host profiles, and the skill's text
asserts its advisory (non-enforcement) posture so future drift into
gate territory is caught at test time.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import re
from pathlib import Path

PKG_ROOT = Path(__file__).resolve().parents[2]
SKILL_DIR = (
    PKG_ROOT
    / "skills"
    / "_generic_core"
    / "orchestrator"
    / "multi-agent-preflight-review"
)
SKILL_MD = SKILL_DIR / "SKILL.md"
REFERENCES_MD = SKILL_DIR / "REFERENCES.md"


def _front_matter(text: str) -> dict[str, str]:
    """Parse YAML front-matter delimited by ``---`` markers.

    Returns a dict of top-level scalar keys. The skill front-matter
    only carries ``name`` and ``description``, so a minimal parser
    suffices (no nesting / no lists).
    """
    if not text.startswith("---\n"):
        raise AssertionError("SKILL.md must open with '---' front-matter delimiter")
    end = text.find("\n---\n", 4)
    if end == -1:
        raise AssertionError("SKILL.md front-matter is not closed by '---'")
    body = text[4:end]
    out: dict[str, str] = {}
    current_key: str | None = None
    for raw in body.splitlines():
        if not raw.strip():
            continue
        m = re.match(r"^(\w+):\s*(.*)$", raw)
        if m:
            current_key = m.group(1)
            value = m.group(2).strip()
            out[current_key] = value
        elif current_key is not None and raw.startswith(("  ", "\t")):
            # continuation line for the previous key (folded scalar)
            out[current_key] = (out[current_key] + " " + raw.strip()).strip()
    return out


def test_skill_dir_present_with_skill_md() -> None:
    """Test 6 — SKILL.md exists and parses with the canonical front-matter
    (name + description) defined for v4.91 orchestrator-cluster skills."""
    assert SKILL_DIR.is_dir(), f"skill directory missing: {SKILL_DIR}"
    assert SKILL_MD.is_file(), f"SKILL.md missing at {SKILL_MD}"
    text = SKILL_MD.read_text(encoding="utf-8")
    fm = _front_matter(text)
    assert fm.get("name") == "multi-agent-preflight-review", (
        f"SKILL.md front-matter name must be "
        f"'multi-agent-preflight-review'; got {fm.get('name')!r}"
    )
    desc = fm.get("description", "")
    assert desc, "SKILL.md front-matter description must be non-empty"
    # Description must mention the opt-in / advisory posture so the
    # skill cannot be confused with the structural preflight gate.
    assert "opt-in" in desc.lower() or "advisory" in desc.lower(), (
        f"SKILL.md description must surface the opt-in / advisory "
        f"posture; got {desc!r}"
    )


def test_skill_references_host_profiles() -> None:
    """Test 7 — REFERENCES.md cross-links at least 3 of the 4 host
    profile yaml paths, anchoring the c1 sweep at the documentation
    layer."""
    assert REFERENCES_MD.is_file(), f"REFERENCES.md missing at {REFERENCES_MD}"
    text = REFERENCES_MD.read_text(encoding="utf-8")
    hosts_referenced = sum(
        1
        for host in ("codex", "cursor", "claude_code", "workbuddy")
        if f"profiles/{host}/host_profile.yaml" in text
    )
    assert hosts_referenced >= 3, (
        f"REFERENCES.md must cross-link at least 3 host_profile.yaml "
        f"paths; got {hosts_referenced} of 4"
    )


def test_skill_advisory_not_gate() -> None:
    """Test 8 — SKILL.md text must explicitly disclaim closure-gate /
    enforcement semantics (Charter anti-pattern #11). Drift catcher: if
    a future edit accidentally promotes this skill to gate territory,
    this assertion fails."""
    text = SKILL_MD.read_text(encoding="utf-8")
    lower = text.lower()
    # Must declare itself advisory.
    assert "advisory" in lower, (
        "SKILL.md must use the word 'advisory' so the non-enforcement "
        "posture is bright"
    )
    # Must explicitly NOT substitute for the structural preflight gate.
    assert (
        "never substitute" in lower
        or "not a substitute" in lower
        or "never substitutes" in lower
    ), (
        "SKILL.md must explicitly disclaim substituting for the "
        "structural preflight gate (run_preflight_consensus.py / B5B)"
    )
    # Must surface the explicit-user-trigger discipline.
    assert "explicit" in lower and "trigger" in lower, (
        "SKILL.md must surface the explicit-user-trigger requirement "
        "(Charter anti-pattern #13)"
    )
