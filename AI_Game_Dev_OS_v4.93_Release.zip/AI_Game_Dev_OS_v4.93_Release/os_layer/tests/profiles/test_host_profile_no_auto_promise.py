"""test_host_profile_no_auto_promise.py — v4.91 M-C B5C c3.

Pins the four host_profile.yaml files (codex / cursor / claude_code /
workbuddy) to Charter anti-pattern #13 (No host auto multi-agent
default) + #14 (No Full Release Copy by Default) discipline.

Layer 1 (OS Spec). No project names; tests reference only the four
generic host tool names sanctioned by Addendum-A's host profile
surface.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

from scripts.governance._yaml_subset import load_yaml_file

PKG_ROOT = Path(__file__).resolve().parents[2]
PROFILES_ROOT = PKG_ROOT / "profiles"

HOSTS = ("codex", "cursor", "claude_code", "workbuddy")

REQUIRED_FORBIDDEN_DEFAULT_ACTIONS = (
    "copy_full_release_to_project_root",
    "treat_release_bundle_as_project_truth",
    "patch_embedded_release_bundle",
    "include_release_bundle_in_runtime_scan",
    "include_release_bundle_in_ltm_retrieval",
    "include_release_bundle_in_gate_scope",
    "generate_project_state_inside_release_bundle",
)


def _load_host(host: str) -> dict:
    return load_yaml_file(PROFILES_ROOT / host / "host_profile.yaml")


@pytest.mark.parametrize("host", HOSTS)
def test_all_4_hosts_disable_auto_subagent(host: str) -> None:
    """Test 1 — every host_profile must declare auto-subagent default OFF."""
    profile = _load_host(host)
    caps = profile["capabilities"]
    assert caps["auto_subagent_without_explicit_request"] is False, (
        f"host {host!r}: auto_subagent_without_explicit_request must be "
        f"false (Charter anti-pattern #13)"
    )


@pytest.mark.parametrize("host", HOSTS)
def test_all_4_hosts_no_auto_team_default(host: str) -> None:
    """Test 2 — supports_team_mode must NOT be hardcoded true (must be
    conditional / profile_dependent / environment_dependent / false)."""
    profile = _load_host(host)
    caps = profile["capabilities"]
    value = caps["supports_team_mode"]
    assert value is not True, (
        f"host {host!r}: supports_team_mode must not be unconditional "
        f"true (Charter anti-pattern #13). Got {value!r}."
    )
    # Must be a string token from the conditional family, OR explicit false.
    if value is not False:
        assert isinstance(value, str), (
            f"host {host!r}: supports_team_mode must be a conditional "
            f"string token or false; got {type(value).__name__}"
        )
        assert value in {"conditional", "profile_dependent", "environment_dependent"}, (
            f"host {host!r}: supports_team_mode {value!r} not in the "
            f"conditional vocabulary"
        )


@pytest.mark.parametrize("host", HOSTS)
def test_all_4_hosts_recommended_mode_explicit(host: str) -> None:
    """Test 3 — recommended_mode must contain 'explicit' as a substring,
    encoding the no-auto-default discipline at the recommendation layer."""
    profile = _load_host(host)
    mode = profile["recommended_mode"]
    assert isinstance(mode, str) and mode, (
        f"host {host!r}: recommended_mode must be a non-empty string"
    )
    assert "explicit" in mode.lower(), (
        f"host {host!r}: recommended_mode {mode!r} must contain 'explicit' "
        f"so the no-auto-multi-agent posture is visible at the rec layer"
    )


@pytest.mark.parametrize("host", HOSTS)
def test_all_4_hosts_carry_forbidden_default_actions(host: str) -> None:
    """Test 4 — every host_profile must list ALL 7 forbidden_default_actions
    items defined by Addendum-A (Charter anti-pattern #14 enforcement)."""
    profile = _load_host(host)
    forbidden = profile.get("forbidden_default_actions") or []
    missing = [a for a in REQUIRED_FORBIDDEN_DEFAULT_ACTIONS if a not in forbidden]
    assert not missing, (
        f"host {host!r}: forbidden_default_actions missing required "
        f"entries: {missing}"
    )


def test_no_host_advertises_auto_multi_agent() -> None:
    """Test 5 — compile-time guard: no host_profile.yaml file may
    contain a key matching ``auto_(subagent|team|multi_agent)_*: true``.

    Implementation:
      - Read each yaml as raw text.
      - Find any line that defines a key whose name starts with one
        of the three forbidden prefixes AND whose value parses to a
        truthy YAML scalar.
      - The legitimate ``auto_subagent_without_explicit_request:
        false`` line is fine because the value is ``false``.

    The regex is deliberately scoped to anti-pattern #13 prefixes to
    avoid false positives on unrelated future fields like
    ``auto_scaffold_target`` or ``auto_create_*``.
    """
    pattern = re.compile(
        r"^\s*"
        r"(auto_(?:subagent|team|multi_agent)\w*)"
        r"\s*:\s*"
        r"(\S+)",
        re.MULTILINE,
    )
    truthy_tokens = {"true", "True", "TRUE", "yes", "Yes", "YES", "on", "On", "ON"}
    violations = []
    for host in HOSTS:
        path = PROFILES_ROOT / host / "host_profile.yaml"
        text = path.read_text(encoding="utf-8")
        for m in pattern.finditer(text):
            key, value = m.group(1), m.group(2).rstrip(",;")
            if value in truthy_tokens:
                violations.append((host, key, value))
    assert not violations, (
        f"Charter anti-pattern #13 violation — host_profile yaml(s) "
        f"declare auto-multi-agent capability as truthy: {violations}"
    )
