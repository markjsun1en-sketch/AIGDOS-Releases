"""tests/cli/test_cli_skeleton.py — v4.90 Batch 11 Step 11.1.

Validates the CLI wrapper skeleton:
- entry import + main() callable
- 4 namespaces registered (migration / ltm / pack / evolve)
- top-level --help renders without importing any business logic
- unknown subcommand → exit 2 (USAGE)
- no-args → exit 2 (USAGE)
- placeholder namespace dispatch returns exit 3 (NOT_YET_WIRED)
- exit code constants match the shared 0/1/2/3/4 contract
- help tree latency is fast (no business import)

Layer 1 (OS Spec). No project names in source.
"""
from __future__ import annotations

import io
import sys
import time
from contextlib import redirect_stderr, redirect_stdout

import pytest


# ---------------------------------------------------------------------------
# 1. Module import + main() callable
# ---------------------------------------------------------------------------

def test_cli_module_importable():
    """Wrapper module imports cleanly via package path."""
    from scripts.cli import ai_dev_os
    assert callable(ai_dev_os.main)
    # main must accept argv list and return an int (mirroring underlying scripts).
    # Annotation may be the type or a stringified PEP 604 form; accept either.
    return_ann = ai_dev_os.main.__annotations__.get("return")
    assert return_ann in (int, "int"), f"unexpected return annotation: {return_ann!r}"


# ---------------------------------------------------------------------------
# 2. Exit code constants pinned to shared contract
# ---------------------------------------------------------------------------

def test_exit_code_constants_match_contract():
    from scripts.cli import ai_dev_os
    assert ai_dev_os.EXIT_OK == 0
    assert ai_dev_os.EXIT_VIOLATION == 1
    assert ai_dev_os.EXIT_USAGE == 2
    assert ai_dev_os.EXIT_INTERNAL_ERROR == 3
    assert ai_dev_os.EXIT_INPUT_MISSING == 4


# ---------------------------------------------------------------------------
# 3. Top-level --help renders all 4 namespaces
# ---------------------------------------------------------------------------

def test_top_level_help_renders_four_namespaces():
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["--help"])
    # main() catches argparse's SystemExit and returns its code (0 for --help).
    assert rc == ai_dev_os.EXIT_OK
    out = buf.getvalue()
    for ns in ("migration", "ltm", "pack", "evolve"):
        assert ns in out, f"namespace {ns!r} missing from --help output"


# ---------------------------------------------------------------------------
# 4. No args → exit 2 (USAGE) and prints help to stderr
# ---------------------------------------------------------------------------

def test_no_args_returns_usage_error():
    from scripts.cli import ai_dev_os
    err_buf = io.StringIO()
    with redirect_stderr(err_buf):
        rc = ai_dev_os.main([])
    assert rc == ai_dev_os.EXIT_USAGE
    assert "namespace" in err_buf.getvalue() or "ai-dev-os" in err_buf.getvalue()


# ---------------------------------------------------------------------------
# 5. Unknown subcommand → exit 2 (argparse convention)
# ---------------------------------------------------------------------------

def test_unknown_subcommand_returns_usage_error():
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["bogus-namespace-name"])
    assert rc == ai_dev_os.EXIT_USAGE


# ---------------------------------------------------------------------------
# 6. Placeholder namespace dispatch returns exit 3 (Step 11.1 only)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("namespace", [])
def test_placeholder_namespace_returns_internal_error(namespace):
    """All namespaces are wired by Step 11.5; this parametrize set is
    intentionally empty. Kept as a tombstone so the regression suite
    explicitly records that the placeholder concept has retired.
    Step 11.6 may delete this entirely.
    """
    pytest.skip("All namespaces wired; placeholder set retired in Step 11.5")
    from scripts.cli import ai_dev_os
    err_buf = io.StringIO()
    with redirect_stderr(err_buf):
        rc = ai_dev_os.main([namespace])
    assert rc == ai_dev_os.EXIT_INTERNAL_ERROR
    assert "not yet wired" in err_buf.getvalue() or "Batch 11" in err_buf.getvalue()


def test_wired_namespace_without_leaf_returns_usage():
    """A wired namespace called without a leaf prints help + returns USAGE."""
    from scripts.cli import ai_dev_os
    err_buf = io.StringIO()
    with redirect_stderr(err_buf):
        rc = ai_dev_os.main(["migration"])
    assert rc == ai_dev_os.EXIT_USAGE
    assert "migration" in err_buf.getvalue()


# ---------------------------------------------------------------------------
# 7. Help tree renders fast (no business logic loaded at parse time)
# ---------------------------------------------------------------------------

def test_help_tree_latency_under_500ms():
    """Sanity: --help must not pull in any underlying scripts/<ns>/<module>.

    Conservative budget: 500 ms (target 100 ms; 500 ms catches gross
    regressions from accidental top-level business imports).
    """
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    start = time.perf_counter()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["--help"])
    elapsed = time.perf_counter() - start
    assert rc == ai_dev_os.EXIT_OK
    assert elapsed < 0.5, f"--help took {elapsed*1000:.1f} ms (budget 500 ms)"


# ---------------------------------------------------------------------------
# 8. No business script is imported at top level of ai_dev_os.py
# ---------------------------------------------------------------------------

def test_no_business_imports_at_module_level():
    """Top-level imports of ai_dev_os.py MUST be limited to stdlib +
    typing helpers. Business script imports (scripts.migration.*,
    scripts.ltm.*, scripts.adoption.*, scripts.agent_library.*,
    scripts.self_evolution.*) MUST be lazy (inside dispatch functions),
    so help tree latency stays low and a missing/broken business
    module doesn't break the whole CLI.
    """
    from pathlib import Path
    src = Path(__file__).resolve().parents[2] / "scripts" / "cli" / "ai_dev_os.py"
    text = src.read_text(encoding="utf-8")
    # Lines starting with `import scripts.` or `from scripts.` at column 0
    # would indicate top-level imports of business namespaces.
    for line in text.splitlines():
        stripped = line.lstrip()
        # Allow indented (lazy / inside-function) imports.
        if line.startswith("import scripts.") or line.startswith("from scripts."):
            pytest.fail(
                f"top-level business import in ai_dev_os.py: {line!r}\n"
                f"All scripts.<ns>.<module> imports MUST be lazy "
                f"(inside dispatch functions)."
            )
        # Sanity on common business namespaces (defensive).
        for ns in ("scripts.migration", "scripts.ltm", "scripts.adoption",
                   "scripts.agent_library", "scripts.self_evolution"):
            if (line.startswith(f"import {ns}") or
                    line.startswith(f"from {ns}")):
                pytest.fail(f"top-level business import: {line!r}")
