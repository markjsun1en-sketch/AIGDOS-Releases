"""tests/cli/test_cli_evolve.py — v4.90 Batch 11 Step 11.5.

Validates the `evolve` namespace wiring (1 leaf) plus a true
end-to-end dispatch test that invokes the real seed proposal
validator from CLI.

Layer 1 (OS Spec). No project names in source.
"""
from __future__ import annotations

import io
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path


def test_evolve_help_lists_validate_leaf():
    """`ai-dev-os evolve --help` enumerates the single `validate` leaf."""
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["evolve", "--help"])
    assert rc == ai_dev_os.EXIT_OK
    assert "validate" in buf.getvalue()


def test_evolve_validate_help_forwards_to_underlying():
    """`ai-dev-os evolve validate --help` forwards to underlying script."""
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["evolve", "validate", "--help"])
    assert rc == ai_dev_os.EXIT_OK
    assert "usage:" in buf.getvalue().lower()


def test_evolve_validate_e2e_against_seed_proposal():
    """End-to-end smoke: invoke `ai-dev-os evolve validate --dir proposals/`.

    The seed proposal evo_2026_001_layer_separation_principle.md was
    backfilled with validation_plan in Step 10.4, so the real
    validator must return exit 0 (OK) when run via the CLI dispatcher.
    This test catches any regression where:
    - dispatch chain breaks
    - argv translation drift
    - the validator's lazy import fails from package context
    """
    from scripts.cli import ai_dev_os
    # Locate the proposals/ dir relative to the v4.90 package root.
    pkg_root = Path(__file__).resolve().parents[2]
    proposals_dir = pkg_root / "proposals"
    assert proposals_dir.is_dir(), f"proposals dir missing: {proposals_dir}"

    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["evolve", "validate", "--dir", str(proposals_dir)])
    assert rc == ai_dev_os.EXIT_OK, (
        f"evolve validate --dir proposals/ returned {rc}; "
        f"output: {buf.getvalue()[:500]}"
    )
    out = buf.getvalue()
    # Underlying validator emits a 'Summary:' line in text mode.
    assert "Summary" in out, f"expected validator Summary line, got: {out[:300]}"


def test_evolve_no_leaf_returns_usage():
    """`ai-dev-os evolve` without a leaf → exit 2."""
    from scripts.cli import ai_dev_os
    err_buf = io.StringIO()
    with redirect_stderr(err_buf):
        rc = ai_dev_os.main(["evolve"])
    assert rc == ai_dev_os.EXIT_USAGE


# Total tests: 1 (help) + 1 (leaf help) + 1 (e2e) + 1 (no-leaf) = 4 tests.
# Net pytest 737 -> 741 expected (handoff projection +4).
