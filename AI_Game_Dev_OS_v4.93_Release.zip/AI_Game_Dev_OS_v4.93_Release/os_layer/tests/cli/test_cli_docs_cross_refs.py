"""tests/cli/test_cli_docs_cross_refs.py — v4.90 Batch 11 Step 11.6.

Cross-reference integrity tests. The forward-ref docs (Batch 8/9/10)
that referenced the future ai-dev-os CLI must now match the actually
wired subcommand tree from Steps 11.2-11.5. If the subcommand tree
changes in a future batch, these tests fail loudly so the docs are
updated in lock-step.

Layer 1 (OS Spec). No project names in source.
"""
from __future__ import annotations

from pathlib import Path

# Resolve v4.90 package root once.
PKG_ROOT = Path(__file__).resolve().parents[2]


def _read(rel_path: str) -> str:
    return (PKG_ROOT / rel_path).read_text(encoding="utf-8")


def test_project_init_guide_uses_full_pack_adoption_path():
    """PROJECT_INIT_GUIDE.md must use `ai-dev-os pack adoption validate`,
    not the abbreviated `ai-dev-os adoption validate` from Batch 9.
    """
    text = _read("docs/13_migration/PROJECT_INIT_GUIDE.md")
    assert "ai-dev-os pack adoption validate" in text, (
        "PROJECT_INIT_GUIDE.md must reference the full nested path "
        "`ai-dev-os pack adoption validate` (the `pack` group was "
        "introduced in Batch 11 Step 11.4)"
    )
    assert "ai-dev-os adoption validate" not in text, (
        "abbreviated `ai-dev-os adoption validate` must be removed "
        "from PROJECT_INIT_GUIDE.md (replaced by `ai-dev-os pack "
        "adoption validate` in Step 11.6)"
    )


def test_proposal_validation_plan_marks_evolve_validate_as_landed():
    """PROPOSAL_VALIDATION_PLAN.md should reflect that
    `ai-dev-os evolve validate` is now landed (no longer a future ref).
    """
    text = _read("docs/17_self_evolution/PROPOSAL_VALIDATION_PLAN.md")
    assert "ai-dev-os evolve validate" in text
    # The line that previously said 'Batch 11.' (forward-ref) must now
    # say 'landed in v4.90 Batch 11.' or similar past-tense phrasing.
    assert "landed in v4.90 Batch 11" in text, (
        "PROPOSAL_VALIDATION_PLAN.md must mark evolve validate as "
        "landed (Step 11.6 closure)"
    )


def test_retrieval_routing_v2_marks_consult_as_stub():
    """RETRIEVAL_ROUTING_v2.md must explicitly mark `ai-dev-os ltm
    consult` as a STUB (Batch 11 Step 11.3 wired it as a stub).
    """
    text = _read("docs/15_ltm_v2/RETRIEVAL_ROUTING_v2.md")
    assert "STUB" in text, (
        "RETRIEVAL_ROUTING_v2.md must mark `ai-dev-os ltm consult` "
        "as a STUB (real impl deferred to Batch 12 / v4.91)"
    )


def test_promotion_workflow_uses_landed_phrasing_for_ltm_leaves():
    """PROMOTION_WORKFLOW.md must use landed-phrasing for `ai-dev-os
    ltm extract|promote|quality` (not 'Batch 11 will collapse' future ref).
    """
    text = _read("docs/15_ltm_v2/PROMOTION_WORKFLOW.md")
    assert "ai-dev-os ltm extract" in text
    assert "ai-dev-os ltm promote" in text
    assert "ai-dev-os ltm quality" in text
    # The future-ref sentinel must be gone.
    assert "Batch 11 will collapse" not in text, (
        "PROMOTION_WORKFLOW.md still has the pre-Batch-11 future-ref "
        "phrasing; rewrite per Step 11.6"
    )
