"""test_cli_module_invocation_metadata.py — v4.90 Batch 14.9 (v4.90.2 patch)
+ Batch 14.10 (v4.90.3 polish): STUB-label sweep for the `ltm consult` leaf.

Keeps docs/18_cli/README.md honest about where the CLI actually is, and
confirms the canonical `python3 -m scripts.cli.ai_dev_os` invocation
form remains reachable. After v4.90.3 the README claims 22 leaves
wired / 0 STUB — `ltm consult` was fully wired in Batch 13.1 and
`ltm quarantine` + `evolve propose` were added since the Batch 11
freeze.

4 tests:

    1. docs/18_cli/README.md no longer claims "Status: skeleton" or
       the legacy "17 leaves wired + 1 STUB" shape; the status line
       declares the post-v4.90.3 "22 leaves wired / 0 STUB" shape.
    2. ``python3 -m scripts.cli.ai_dev_os --help`` exits 0 and lists
       all four namespaces (migration / ltm / pack / evolve).
    3. v4.90.3: docs/18_cli/README.md and CLI_USAGE_GUIDE.md no
       longer carry the user-facing "[STUB]" label for `ltm consult`
       (only historical / explanatory mentions remain).
    4. v4.90.3: `python3 -m scripts.cli.ai_dev_os ltm consult` smoke
       call returns exit 0 with at least one valid JSON line on
       stdout. Confirms the leaf is wired end-to-end and not
       returning the legacy STUB exit-3.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1].parent
README = REPO_ROOT / "docs" / "18_cli" / "README.md"
USAGE_GUIDE = REPO_ROOT / "docs" / "18_cli" / "CLI_USAGE_GUIDE.md"


def test_cli_readme_status_reflects_post_v4_90_3_reality():
    text = README.read_text(encoding="utf-8")
    # The legacy "Status: skeleton" line must still be gone (v4.90.2
    # removed it; v4.90.3 keeps it gone).
    assert "**Status**: skeleton" not in text, (
        "docs/18_cli/README.md still claims Status: skeleton."
    )
    # The legacy v4.90.2 "17 leaves wired + 1 STUB" line must be gone
    # too (v4.90.3 swept it because consult is wired).
    assert "17 leaves wired + 1 STUB" not in text, (
        "docs/18_cli/README.md still carries the v4.90.2 17-leaves+1-STUB "
        "status; expected 22 leaves / 0 STUB after v4.90.3 sweep."
    )
    # The new post-v4.90.3 status string must be present.
    assert (
        "22 leaves wired / 0 STUB" in text
    ), "expected post-v4.90.3 status line '22 leaves wired / 0 STUB' missing"
    # Documents-in-this-directory table must drop the v4.90.0 placeholder
    # wording.
    assert "skeleton (sections placeholder until 11.2-11.6)" not in text


def test_module_invocation_help_lists_four_namespaces():
    res = subprocess.run(
        [sys.executable, "-m", "scripts.cli.ai_dev_os", "--help"],
        capture_output=True,
        text=True,
        cwd=str(REPO_ROOT),
        check=False,
    )
    assert res.returncode == 0, res.stdout + res.stderr
    out = res.stdout
    for ns in ("migration", "ltm", "pack", "evolve"):
        assert ns in out, f"namespace {ns!r} missing from --help output"


def test_no_user_facing_consult_stub_label_in_cli_docs():
    """v4.90.3 sweep: user-facing labels should not call consult [STUB].

    The phrase "[STUB] returns exit 3 in v4.90 Batch 11" was the v4.90.0
    marker on the `ltm consult` leaf inside CLI_USAGE_GUIDE.md and is
    the kind of legacy label that confuses cold-start agents. Likewise
    README.md's "1 STUB (`ltm consult`, exit 3)" stanza was a v4.90.2
    residue. Both must be cleared by v4.90.3.

    Historical / explanatory mentions (e.g. "previously also `ltm
    consult` STUB before Batch 13.1 wired it") are allowed because they
    document the transition rather than describing current state.
    """
    readme_text = README.read_text(encoding="utf-8")
    usage_text = USAGE_GUIDE.read_text(encoding="utf-8")

    # README must not carry the v4.90.2 "1 STUB (`ltm consult`, exit 3)"
    # total-row stanza any more.
    assert "1 STUB (`ltm consult`, exit 3)" not in readme_text
    assert "leaves wired + 1 STUB" not in readme_text

    # USAGE GUIDE must not carry the "[STUB] returns exit 3 in v4.90
    # Batch 11" inline annotation any more.
    assert "[STUB] returns exit 3 in v4.90 Batch 11" not in usage_text
    # The "is intentionally a STUB" framing also must be gone.
    assert "is intentionally a STUB" not in usage_text


def test_ltm_consult_cli_smoke_returns_zero_with_json_output():
    """Hard end-to-end check: consult is wired and returns retrievable
    output, not a STUB exit-3.

    Runs ``python3 -m scripts.cli.ai_dev_os ltm consult progressive
    --limit 1 --format json`` from REPO_ROOT and asserts:
      - exit code 0
      - at least one stdout line parses as a JSON object
    """
    res = subprocess.run(
        [
            sys.executable,
            "-m",
            "scripts.cli.ai_dev_os",
            "ltm",
            "consult",
            "progressive",
            "--limit",
            "1",
            "--format",
            "json",
        ],
        capture_output=True,
        text=True,
        cwd=str(REPO_ROOT),
        check=False,
    )
    assert res.returncode == 0, (
        f"ltm consult exited {res.returncode} (expected 0; the v4.90.0 "
        f"STUB returned 3). stdout={res.stdout!r} stderr={res.stderr!r}"
    )
    # First non-empty stdout line should be valid JSON (object or array).
    first = next(
        (line for line in res.stdout.splitlines() if line.strip()), None
    )
    assert first is not None, "ltm consult produced no stdout"
    parsed = json.loads(first)
    assert isinstance(parsed, (dict, list)), (
        f"first stdout line is not a JSON object/array: {first!r}"
    )
