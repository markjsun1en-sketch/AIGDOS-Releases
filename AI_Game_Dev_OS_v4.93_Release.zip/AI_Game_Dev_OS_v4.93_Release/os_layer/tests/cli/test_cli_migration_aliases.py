"""test_cli_migration_aliases.py — v4.90 Batch 13 Step 13.4.a.

Plan §9 字面 alias leaves under the `migration` namespace:
- handshake — chains detect-protocol then validate-protocol
- plan      — generate-queue with --format=markdown
- verify    — 1:1 alias of validate-capability
- report    — 1:1 alias of generate-report

Per EP decision 2026-05-15 10:25 (D-13.4.a.1=A handshake真实串联;
D-13.4.a.2=B RFC-style markdown).

4 tests:
1. handshake chains detect+validate; short-circuits on first failure
2. plan emits RFC-style markdown (H1/H2 sections + tables)
3. verify --help reaches validate-capability's underlying parser
4. report --help reaches generate-report's underlying parser

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import io
from contextlib import redirect_stderr, redirect_stdout
from unittest import mock


def _run_cli(*argv: str) -> tuple[int, str, str]:
    """Invoke ai_dev_os.main(argv) and capture stdout/stderr."""
    from scripts.cli import ai_dev_os
    out_buf, err_buf = io.StringIO(), io.StringIO()
    with redirect_stdout(out_buf), redirect_stderr(err_buf):
        rc = ai_dev_os.main(list(argv))
    return rc, out_buf.getvalue(), err_buf.getvalue()


# --- Test 1: handshake chains detect + validate, short-circuits ----------

def test_migration_handshake_chains_detect_then_validate():
    """`migration handshake` must call detect-protocol THEN
    validate-protocol; if detect-protocol returns non-zero, the chain
    must short-circuit before validate-protocol runs.
    """
    from scripts.cli import ai_dev_os

    # Mock _dispatch_leaf to record which leaves got dispatched and
    # what they returned. We control the return values to exercise
    # both the OK path and the short-circuit path.
    call_log: list[str] = []

    def _fake_leaf(import_path: str):
        call_log.append(f"wired:{import_path}")
        def _dispatch(remaining_argv: list[str]) -> int:  # noqa: ARG001
            call_log.append(f"called:{import_path}")
            # Both 'detect' and 'validate' succeed.
            return 0
        return _dispatch

    with mock.patch.object(ai_dev_os, "_dispatch_leaf", _fake_leaf):
        rc, _out, err = _run_cli("migration", "handshake", "/tmp/proj")

    assert rc == 0, f"handshake should exit 0 when both legs pass; rc={rc}"
    called = [e.split(":", 1)[1] for e in call_log if e.startswith("called:")]
    assert called == [
        "scripts.migration.detect_project_protocol",
        "scripts.migration.validate_protocol_compatibility",
    ], f"unexpected call order: {called!r}"
    # User-facing trace lines must mention 'step 1 of 2' and 'step 2 of 2'.
    assert "step 1 of 2" in err and "step 2 of 2" in err, (
        f"handshake stderr trace missing step markers; err={err!r}"
    )

    # --- short-circuit path: detect-protocol returns non-zero ---
    call_log.clear()

    def _fake_leaf_fail(import_path: str):
        call_log.append(f"wired:{import_path}")
        def _dispatch(remaining_argv: list[str]) -> int:  # noqa: ARG001
            call_log.append(f"called:{import_path}")
            # detect-protocol fails -> 4 (INPUT_MISSING)
            if "detect_project_protocol" in import_path:
                return 4
            return 0  # validate-protocol would pass, but should not run
        return _dispatch

    with mock.patch.object(ai_dev_os, "_dispatch_leaf", _fake_leaf_fail):
        rc2, _out2, err2 = _run_cli("migration", "handshake", "/tmp/proj")

    called2 = [e.split(":", 1)[1] for e in call_log if e.startswith("called:")]
    assert rc2 == 4, f"handshake should forward detect-protocol's rc=4; got {rc2}"
    assert called2 == [
        "scripts.migration.detect_project_protocol",
    ], f"validate-protocol should not run after detect failed; calls={called2!r}"
    assert "aborting before validate-protocol" in err2, (
        f"short-circuit must announce the abort; err={err2!r}"
    )


# --- Test 2: plan emits RFC-style markdown (+ caller format override) ----

def test_migration_plan_emits_rfc_style_markdown():
    """`migration plan` injects --format=markdown into generate-queue.
    Output must be RFC-style markdown: H1 title + H2 sections + table.

    Additionally validates the 'has_format' override guard: if the
    caller passes `--format json` explicitly, plan must NOT override
    to markdown.
    """
    rc, out, _err = _run_cli("migration", "plan")
    assert rc == 0, f"migration plan returned {rc}; expected 0"
    # RFC structure markers per D-13.4.a.2=B:
    expected_markers = [
        "# Capability Adoption Plan",       # H1
        "## 1. Summary",                    # H2 #1
        "## 2. Capabilities",               # H2 #2
        "## 3. Dependencies graph",         # H2 #3
        "**Total capabilities**",           # summary bullet
        "priority 0",                       # at least one priority entry
    ]
    for marker in expected_markers:
        assert marker in out, (
            f"plan output missing RFC marker {marker!r}; "
            f"first 400 chars: {out[:400]!r}"
        )

    # --- Caller --format json override must win over the alias's
    # auto-injected --format markdown (validates _dispatch_alias_plan's
    # has_format guard).
    rc2, out2, _err2 = _run_cli("migration", "plan", "--format", "json")
    assert rc2 == 0, f"plan --format json returned {rc2}"
    assert out2.lstrip().startswith("{"), (
        f"plan --format json should emit JSON; got first chars: "
        f"{out2[:80]!r}"
    )
    assert "# Capability Adoption Plan" not in out2, (
        "json mode must not include markdown H1 marker"
    )


# --- Test 3: verify alias dispatches to validate-capability -------------

def test_migration_verify_alias_reaches_validate_capability():
    """`migration verify --help` must reach validate_capability_adoption's
    argparse and show its flags (e.g. --evidence-out)."""
    rc, out, _err = _run_cli("migration", "verify", "--help")
    assert rc == 0
    # validate_capability_adoption has these distinctive flags:
    for marker in ("capability_id", "--evidence-out"):
        assert marker in out, (
            f"verify --help missing validate-capability marker "
            f"{marker!r}; out[:300]={out[:300]!r}"
        )


# --- Test 4: report alias dispatches to generate-report ------------------

def test_migration_report_alias_reaches_generate_report():
    """`migration report --help` must reach generate_migration_report's
    argparse and show its flags (e.g. --adoption, --transitions)."""
    rc, out, _err = _run_cli("migration", "report", "--help")
    assert rc == 0
    # generate_migration_report has these distinctive flags:
    for marker in ("--adoption", "--transitions"):
        assert marker in out, (
            f"report --help missing generate-report marker "
            f"{marker!r}; out[:300]={out[:300]!r}"
        )


# Net additions: 4 distinct test functions per §8 trajectory (+4).
# Pre-13.4.a baseline 816 (after 13.3). After 13.4.a: 820 expected.
# (Test 2 covers both markdown emission AND --format json override
# guard in a single function to keep count at exactly 4.)
