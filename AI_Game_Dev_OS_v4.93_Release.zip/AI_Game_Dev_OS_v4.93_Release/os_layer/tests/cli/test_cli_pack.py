"""tests/cli/test_cli_pack.py — v4.90 Batch 11 Step 11.4.

Validates the `pack` namespace wiring with nested sub-groups:
- pack agent-library validate
- pack adoption init / harness / validate

Layer 1 (OS Spec). No project names in source.
"""
from __future__ import annotations

import io
from contextlib import redirect_stderr, redirect_stdout

import pytest


PACK_LEAVES = [
    # (group, leaf, target_module)
    ("agent-library", "validate", "scripts.agent_library.validate_agent_pack"),
    ("adoption", "init", "scripts.adoption.init_project_runtime"),
    ("adoption", "harness", "scripts.adoption.run_mock_harness"),
    ("adoption", "validate", "scripts.adoption.validate_adoption"),
]


def test_pack_help_lists_two_groups():
    """`ai-dev-os pack --help` enumerates the two sub-groups."""
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["pack", "--help"])
    assert rc == ai_dev_os.EXIT_OK
    out = buf.getvalue()
    assert "agent-library" in out, "agent-library sub-group missing from pack --help"
    assert "adoption" in out, "adoption sub-group missing from pack --help"


def test_pack_adoption_group_help_lists_three_leaves():
    """`ai-dev-os pack adoption --help` enumerates 3 leaves (init/harness/validate)."""
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["pack", "adoption", "--help"])
    assert rc == ai_dev_os.EXIT_OK
    out = buf.getvalue()
    for leaf in ("init", "harness", "validate"):
        assert leaf in out, f"adoption leaf {leaf!r} missing"


def test_pack_agent_library_group_help_lists_validate():
    """`ai-dev-os pack agent-library --help` shows the single `validate` leaf."""
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["pack", "agent-library", "--help"])
    assert rc == ai_dev_os.EXIT_OK
    assert "validate" in buf.getvalue()


@pytest.mark.parametrize("group,leaf,target", PACK_LEAVES)
def test_pack_leaf_forwards_help_to_underlying(group, leaf, target):
    """All 4 nested leaves' --help forwards to underlying script."""
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["pack", group, leaf, "--help"])
    assert rc == ai_dev_os.EXIT_OK, f"pack {group} {leaf} --help returned {rc}"
    assert "usage:" in buf.getvalue().lower(), (
        f"pack {group} {leaf} did not produce argparse usage; "
        f"target {target!r}"
    )


def test_pack_no_group_returns_usage():
    """`ai-dev-os pack` without a group → exit 2."""
    from scripts.cli import ai_dev_os
    err_buf = io.StringIO()
    with redirect_stderr(err_buf):
        rc = ai_dev_os.main(["pack"])
    assert rc == ai_dev_os.EXIT_USAGE


def test_pack_adoption_no_leaf_returns_usage():
    """`ai-dev-os pack adoption` without a leaf → exit 2."""
    from scripts.cli import ai_dev_os
    err_buf = io.StringIO()
    with redirect_stderr(err_buf):
        rc = ai_dev_os.main(["pack", "adoption"])
    assert rc == ai_dev_os.EXIT_USAGE


# Total tests: 1 (pack help) + 1 (adoption help) + 1 (agent-library help)
#  + 4 (parametrize over leaves) + 1 (pack no group) + 1 (adoption no leaf)
#  = 9 tests. Handoff projection +7; nested structure justifies 2 extra
# group-level help-tree tests. Net pytest 729 -> 738 expected.
