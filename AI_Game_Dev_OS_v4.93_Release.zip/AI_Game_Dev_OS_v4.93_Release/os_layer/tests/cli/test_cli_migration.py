"""tests/cli/test_cli_migration.py — v4.90 Batch 11 Step 11.2.

Validates the `migration` namespace wiring. 7 leaves are dispatched
to scripts/migration/<module>.py via the shared _dispatch_leaf helper.

Tests focus on:
- namespace help tree lists all 7 leaves
- each leaf forwards `--help` into the underlying script (exit 0)
- each leaf's import path matches the audited target
- unknown leaves exit 2 (USAGE)
- one true e2e dispatch path (validate-protocol with a missing matrix
  file → underlying script exits 4 INPUT_MISSING; verify exit code is
  forwarded verbatim)

Layer 1 (OS Spec). No project names in source.
"""
from __future__ import annotations

import io
from contextlib import redirect_stderr, redirect_stdout

import pytest


# All 7 leaves wired by Step 11.2. Each tuple: (leaf-name, target-module-path).
MIGRATION_LEAVES = [
    ("scan", "scripts.migration.scan_legacy_project"),
    ("detect-protocol", "scripts.migration.detect_project_protocol"),
    ("adopt", "scripts.migration.adopt_capability"),
    ("generate-queue", "scripts.migration.generate_capability_queue"),
    ("generate-report", "scripts.migration.generate_migration_report"),
    ("validate-capability", "scripts.migration.validate_capability_adoption"),
    ("validate-protocol", "scripts.migration.validate_protocol_compatibility"),
]


def test_migration_help_lists_all_seven_leaves():
    """`ai-dev-os migration --help` enumerates all 7 wired leaves."""
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["migration", "--help"])
    assert rc == ai_dev_os.EXIT_OK
    out = buf.getvalue()
    for leaf, _target in MIGRATION_LEAVES:
        assert leaf in out, f"leaf {leaf!r} missing from migration --help"


@pytest.mark.parametrize("leaf,target", MIGRATION_LEAVES)
def test_migration_leaf_forwards_help_to_underlying(leaf, target):
    """`ai-dev-os migration <leaf> --help` exits 0 and the help text comes
    from the underlying script (the underlying script's own --help body
    is printed, not the wrapper's). We check exit 0 + presence of at
    least one underlying-script signature line.
    """
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["migration", leaf, "--help"])
    assert rc == ai_dev_os.EXIT_OK, f"leaf {leaf!r} --help returned {rc}"
    out = buf.getvalue()
    # Underlying scripts use argparse, so their --help always begins with
    # 'usage:' on the first non-empty line.
    assert "usage:" in out.lower(), (
        f"leaf {leaf!r} --help did not produce an argparse usage line; "
        f"either dispatch failed or target {target!r} is wrong"
    )


def test_migration_unknown_leaf_returns_usage():
    """Unknown leaf under migration namespace → exit 2 (argparse default)."""
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["migration", "bogus-leaf"])
    assert rc == ai_dev_os.EXIT_USAGE


def test_migration_e2e_exit_code_forwarding():
    """True end-to-end dispatch test: invoke validate-protocol with a
    nonexistent --matrix path so the underlying script must return
    EXIT_INPUT_MISSING (4). Verifying that exit code 4 is forwarded
    verbatim proves the dispatch chain has zero translation layer.
    """
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main([
            "migration", "validate-protocol",
            "--matrix", "/nonexistent/path/to/matrix.md",
        ])
    # Underlying script returns 4 INPUT_MISSING when the matrix file is missing.
    assert rc == ai_dev_os.EXIT_INPUT_MISSING


# Total tests in this file:
# 1 (help-lists-all) + 7 (parametrize over leaves) + 1 (unknown leaf) + 1 (e2e)
#  = 10 tests. Handoff projection was +9; e2e test is the conservative
# extra. Net pytest 712 -> 722 expected.
