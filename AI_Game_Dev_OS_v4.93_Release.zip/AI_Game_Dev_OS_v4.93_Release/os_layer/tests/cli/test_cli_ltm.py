"""tests/cli/test_cli_ltm.py — v4.90 Batch 11 Step 11.3 + Batch 13 Step 13.1.

Validates the `ltm` namespace wiring. 6 leaves dispatch to their
underlying modules via _dispatch_leaf:
  - 5 forward to scripts/ltm/<module>
  - 1 (consult) forwards to runtime/ltm/__main__.py — wired in
    Step 13.1 (was a STUB in Step 11.3).

The Step 13.1 wiring aligns CLI flags + exit codes with plan §9 字面:
  --format text|json (with --json as DEPRECATED alias)
  exit 0 / 1 / 3 / 4 (OK / INPUT_ERROR / INTERNAL / INPUT_MISSING)

Layer 1 (OS Spec). No project names in source.
"""
from __future__ import annotations

import io
import json
from contextlib import redirect_stderr, redirect_stdout

import pytest


# 5 leaves forwarding into scripts.ltm.* (real script-level main()).
LTM_REAL_LEAVES = [
    ("capture", "scripts.ltm.capture_sprint_close"),
    ("extract", "scripts.ltm.extract_failure_candidates"),
    ("promote", "scripts.ltm.promote_memory_candidate"),
    ("quality", "scripts.ltm.validate_memory_quality"),
    ("validate-ff", "scripts.ltm.validate_failure_fix_entry"),
]


def test_ltm_help_lists_six_commands():
    """`ai-dev-os ltm --help` enumerates 5 scripts.ltm leaves + consult."""
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["ltm", "--help"])
    assert rc == ai_dev_os.EXIT_OK
    out = buf.getvalue()
    for leaf, _target in LTM_REAL_LEAVES:
        assert leaf in out, f"leaf {leaf!r} missing from ltm --help"
    assert "consult" in out, "consult leaf missing from ltm --help"
    # Step 13.1 — STUB markers removed; consult is now real.
    assert "STUB" not in out, (
        "namespace help still mentions STUB; expected Step 13.1 to remove it"
    )


@pytest.mark.parametrize("leaf,target", LTM_REAL_LEAVES)
def test_ltm_leaf_forwards_help_to_underlying(leaf, target):
    """Real leaves' --help forwards to underlying script (exit 0 + 'usage:')."""
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["ltm", leaf, "--help"])
    assert rc == ai_dev_os.EXIT_OK, f"leaf {leaf!r} --help returned {rc}"
    assert "usage:" in buf.getvalue().lower(), (
        f"leaf {leaf!r} did not produce argparse usage; target {target!r}"
    )


def test_ltm_consult_dispatches_to_runtime():
    """Step 13.1 — `ai-dev-os ltm consult --help` reaches runtime.ltm.__main__.

    The replacement of _dispatch_stub with _dispatch_leaf("runtime.ltm.__main__")
    means --help should render the runtime wrapper's argparse usage line,
    NOT a STUB diagnostic on stderr.
    """
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["ltm", "consult", "--help"])
    assert rc == ai_dev_os.EXIT_OK, (
        f"consult --help returned {rc}; expected 0 (was STUB returning 3 pre-13.1)"
    )
    out = buf.getvalue()
    assert "python -m runtime.ltm" in out, (
        "consult --help did not render runtime.ltm prog header — "
        "dispatcher may still be the STUB"
    )
    assert "STUB" not in out, "consult --help still contains STUB marker"


def test_ltm_unknown_leaf_returns_usage():
    """Unknown leaf under ltm namespace → exit 2."""
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["ltm", "bogus-leaf"])
    assert rc == ai_dev_os.EXIT_USAGE


# ---------------------------------------------------------------------
# Step 13.1 — 5 new tests for the real consult dispatcher.
# Plan §9 字面 alignment: --format text|json + exit 0/1/3/4.
# ---------------------------------------------------------------------


def test_consult_help_lists_all_flags():
    """Step 13.1 — `ltm consult --help` lists all 6 flags from plan §9.

    Required flags (per V4_90_RC2_REMEDIATION_HANDOFF.md §3.2):
      --domain --limit --project --format --engine --rebuild-index
    """
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main(["ltm", "consult", "--help"])
    assert rc == ai_dev_os.EXIT_OK
    out = buf.getvalue()
    expected_flags = ["--domain", "--limit", "--project",
                      "--format", "--engine", "--rebuild-index"]
    for flag in expected_flags:
        assert flag in out, (
            f"flag {flag!r} missing from `ltm consult --help`; "
            f"plan §9 字面 requires all 6 flags"
        )


def test_consult_no_hits_returns_zero():
    """Step 13.1 — empty-result query → exit 0 (legitimate empty result)."""
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main([
            "ltm", "consult", "zzz_no_match_xyz_unique_token",
            "--format", "json",
        ])
    assert rc == ai_dev_os.EXIT_OK, (
        f"no-hits query returned {rc}; plan §9 says exit 0 for empty results"
    )
    # JSON mode: stdout should be empty (no hit lines emitted).
    out = buf.getvalue()
    # stdout in 'json' mode emits NDJSON; with 0 hits, there should be no
    # JSON lines (the "(no hits)" diagnostic only fires in text mode).
    json_lines = [
        line for line in out.splitlines()
        if line.strip().startswith("{")
    ]
    assert json_lines == [], (
        f"no-hits query emitted JSON lines: {json_lines!r}"
    )


def test_consult_unknown_domain_returns_input_error():
    """Step 13.1 — `--domain bogus` → exit 1 (EXIT_INPUT_ERROR per plan §9).

    Pre-13.1 behaviour was exit 2 (argparse default). The Step 13.1
    main() maps argparse non-zero codes → EXIT_INPUT_ERROR=1.
    """
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main([
            "ltm", "consult", "anything", "--domain", "bogus",
        ])
    # Plan §9 字面: exit 1 = INPUT_ERROR. ai_dev_os.EXIT_VIOLATION == 1.
    assert rc == ai_dev_os.EXIT_VIOLATION, (
        f"unknown-domain rc={rc}; expected 1 (EXIT_INPUT_ERROR per plan §9)"
    )


def test_consult_format_json_parses():
    """Step 13.1 — `--format json` emits NDJSON parseable per line.

    Uses a query likely to hit at least one corpus entry. We assert
    each non-empty stdout line round-trips through json.loads with the
    expected hit fields.
    """
    from scripts.cli import ai_dev_os
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(buf):
        rc = ai_dev_os.main([
            "ltm", "consult", "failure", "--format", "json", "--limit", "3",
        ])
    assert rc == ai_dev_os.EXIT_OK
    out = buf.getvalue()
    json_lines = [line for line in out.splitlines() if line.strip()]
    assert json_lines, (
        "expected at least one NDJSON line for query='failure'; got empty stdout"
    )
    for line in json_lines:
        hit = json.loads(line)
        # consult() hit shape: path/domain/title/excerpt/score.
        for key in ("path", "domain", "title", "excerpt", "score"):
            assert key in hit, (
                f"hit missing key {key!r}; got {hit!r}"
            )


def test_consult_json_alias_still_works():
    """Step 13.1 — `--json` (DEPRECATED) is equivalent to `--format json`.

    Backward compat for v4.89-era invocations. We compare the JSON
    output sets — they should be identical given identical query.
    """
    from scripts.cli import ai_dev_os

    def _run(extra_args: list[str]) -> str:
        buf = io.StringIO()
        with redirect_stdout(buf), redirect_stderr(buf):
            rc = ai_dev_os.main(
                ["ltm", "consult", "failure", "--limit", "3"] + extra_args,
            )
        assert rc == ai_dev_os.EXIT_OK, (
            f"args={extra_args!r} returned {rc}"
        )
        return buf.getvalue()

    out_format = _run(["--format", "json"])
    out_alias = _run(["--json"])

    # Both should be NDJSON. Compare the parsed list of dicts (not raw
    # text) since stderr ordering relative to stdout could differ.
    def _parse(s: str) -> list[dict]:
        return [
            json.loads(line) for line in s.splitlines()
            if line.strip().startswith("{")
        ]

    assert _parse(out_format) == _parse(out_alias), (
        "--json alias output differs from --format json — alias broken"
    )


# Total tests: 1 namespace help + 5 parametrize + 1 dispatch + 1 unknown
# leaf + 5 new = 13. (Pre-13.1 was 8; net +5 per Step 13.1 plan.)
