"""test_cli_aliases_yaml_driven.py — v4.90 Batch 14 Step 14.5.

Data-driven CLI alias guard. Loads
`config/naming_aliases.yaml::domains.cli_aliases` and asserts that
every declared alias is registered in the runtime CLI parser
(`scripts/cli/ai_dev_os.py`). Complements
`tests/cli/test_cli_migration_aliases.py` (which exercises real
chain/preset behaviour) by ensuring the yaml catalog stays in sync
with what the CLI actually exposes.

Two tests:
1. every yaml-declared alias is reachable via the CLI parser
2. cli_aliases yaml count matches the count of registered
   `migration *` aliases observed via `--help`

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import io
import sys
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from unittest import mock

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))

from scripts.governance._yaml_subset import load_yaml_file  # noqa: E402

CONFIG_PATH = REPO_ROOT / "config" / "naming_aliases.yaml"


def _cli_alias_entries() -> list[dict]:
    data = load_yaml_file(CONFIG_PATH)
    return list(data["domains"]["cli_aliases"]["entries"])


def _run_cli(*argv: str) -> tuple[int, str, str]:
    from scripts.cli import ai_dev_os
    out_buf, err_buf = io.StringIO(), io.StringIO()
    with redirect_stdout(out_buf), redirect_stderr(err_buf):
        try:
            rc = ai_dev_os.main(list(argv))
        except SystemExit as exc:
            rc = exc.code if isinstance(exc.code, int) else 1
    return rc, out_buf.getvalue(), err_buf.getvalue()


@pytest.mark.parametrize(
    "entry",
    _cli_alias_entries(),
    ids=lambda e: e["alias"],
)
def test_yaml_declared_cli_alias_is_reachable(entry):
    """Every alias listed in the yaml must have a working --help path
    under the migration namespace.

    rc==0 from `<alias> --help` is the canonical reach proof: if the
    alias were not registered, argparse would exit non-zero with
    `invalid choice` before reaching the help formatter. We do NOT
    assert against help-text content because 1:1 aliases forward
    straight to the canonical command's argparse, which keeps its
    own prog/usage banner.
    """
    parts = entry["alias"].split()
    rc, out, err = _run_cli(*parts, "--help")
    assert rc == 0, (
        f"alias {entry['alias']!r} --help failed (rc={rc}):\n"
        f"stdout:\n{out}\nstderr:\n{err}"
    )
    # Help body must be non-trivial (argparse always prints `usage:`).
    assert "usage:" in out.lower(), (
        f"alias {entry['alias']!r} --help did not produce a usage banner; "
        f"stdout was:\n{out[:400]}"
    )


def test_yaml_cli_alias_count_matches_migration_help():
    """Number of yaml cli_aliases entries should match the number of
    `migration *` subcommands surfaced by `migration --help`. This
    is a drift detector: if a new alias lands in argparse without a
    yaml entry (or vice-versa), the count diverges."""
    rc, out, err = _run_cli("migration", "--help")
    assert rc == 0, f"migration --help failed:\n{out}\n{err}"
    declared_aliases = {e["alias"] for e in _cli_alias_entries()}
    surfaced = sum(
        1 for alias in declared_aliases
        if alias.split()[-1] in out
    )
    assert surfaced == len(declared_aliases), (
        f"yaml declares {len(declared_aliases)} aliases but only "
        f"{surfaced} appear in `migration --help`. Aliases: "
        f"{sorted(declared_aliases)}"
    )
