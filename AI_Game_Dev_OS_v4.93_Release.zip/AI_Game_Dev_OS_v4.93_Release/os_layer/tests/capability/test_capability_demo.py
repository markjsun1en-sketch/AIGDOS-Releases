"""End-to-end test for the v4.92 Capability Foundation demo (Batch 8).

Runs scripts/capability/run_capability_demo.py and asserts the full chain
(B5 fix / B2 governance / B3 adoption / B6 evidence) reaches DEMO_OK, including
a bare-interpreter run that proves the demo works without jsonschema.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

_PKG_ROOT = Path(__file__).resolve().parents[2]
_DEMO = _PKG_ROOT / "scripts" / "capability" / "run_capability_demo.py"
_MANAGED_PY = Path(
    "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"
)


def _run(interpreter: str, *args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [interpreter, str(_DEMO), *args],
        capture_output=True, text=True,
    )


def test_demo_exists():
    assert _DEMO.exists(), "run_capability_demo.py must exist"


def test_demo_reaches_demo_ok():
    res = _run(sys.executable)
    assert res.returncode == 0, f"demo failed (rc={res.returncode}):\n{res.stdout}\n{res.stderr}"
    assert "DEMO_OK" in res.stdout
    # Every labelled step must report PASS, none FAIL.
    assert "FAIL" not in res.stdout, res.stdout
    for step in ("STEP 1", "STEP 2", "STEP 3", "STEP 4", "STEP 5"):
        assert step in res.stdout, f"missing {step} in demo output"


def test_demo_json_summary():
    res = _run(sys.executable, "--json")
    assert res.returncode == 0, res.stderr
    # Last non-empty stdout line is the JSON summary.
    line = [ln for ln in res.stdout.splitlines() if ln.strip()][-1]
    payload = json.loads(line)
    assert payload["ok"] is True
    assert payload["verdict"] == "DEMO_OK"
    assert payload["steps_done"] == ["array_injection", "governance", "adoption", "evidence"]


def test_demo_runs_under_bare_managed_python():
    """The demo must work under the managed interpreter, which has no
    jsonschema — proving the whole chained stack is zero-dependency."""
    if not _MANAGED_PY.exists():
        import pytest
        pytest.skip("managed python3 not present")
    # Confirm the interpreter genuinely lacks jsonschema.
    probe = subprocess.run(
        [str(_MANAGED_PY), "-c", "import jsonschema"],
        capture_output=True, text=True,
    )
    assert probe.returncode != 0, "managed python unexpectedly has jsonschema"

    res = _run(str(_MANAGED_PY))
    assert res.returncode == 0, f"demo failed under bare python:\n{res.stdout}\n{res.stderr}"
    assert "DEMO_OK" in res.stdout
