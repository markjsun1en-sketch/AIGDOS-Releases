"""test_practicality_gate.py — v4.92 Batch 2 (P0-4 self-test).

Verifies scripts/capability/run_practicality_gate.py:
    - a concrete skill PASSes (exit 0)
    - a vague skill is DRAFT_ONLY (exit 1) and the expected rules fire
    - the gate runs under a bare interpreter WITHOUT jsonschema
      (zero-dependency discipline, MEMORY lesson)

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
GATE = REPO_ROOT / "scripts" / "capability" / "run_practicality_gate.py"
FIX = Path(__file__).resolve().parent / "fixtures"

sys.path.insert(0, str(REPO_ROOT))
from scripts.capability import run_practicality_gate as gate  # noqa: E402


def test_good_skill_passes():
    rep = gate.evaluate_skill(FIX / "skill_good.json")
    assert rep.verdict == "PASS", [v.render() for v in rep.violations]


def test_vague_skill_is_draft_only():
    rep = gate.evaluate_skill(FIX / "skill_vague.json")
    assert rep.verdict == "DRAFT_ONLY"
    rules = {v.rule for v in rep.violations}
    # vague phrase without action clause
    assert "vague_phrase" in rules
    # validation prose, no command token
    assert "validation.trivial" in rules
    # placeholder example
    assert "example_task.placeholder" in rules
    # placeholder non-completion
    assert "non_completion.empty" in rules


def test_cli_exit_codes(tmp_path):
    # good -> 0
    r0 = subprocess.run(
        [sys.executable, str(GATE), str(FIX / "skill_good.json")],
        capture_output=True, text=True,
    )
    assert r0.returncode == 0, r0.stdout + r0.stderr
    # vague -> 1
    r1 = subprocess.run(
        [sys.executable, str(GATE), str(FIX / "skill_vague.json")],
        capture_output=True, text=True,
    )
    assert r1.returncode == 1


def test_cli_json_output():
    r = subprocess.run(
        [sys.executable, str(GATE), "--json", str(FIX / "skill_good.json")],
        capture_output=True, text=True,
    )
    payload = json.loads(r.stdout)
    assert payload["ok"] is True
    assert payload["reports"][0]["verdict"] == "PASS"


def test_missing_file_exit_4():
    r = subprocess.run(
        [sys.executable, str(GATE), str(FIX / "does_not_exist.json")],
        capture_output=True, text=True,
    )
    assert r.returncode == 4


@pytest.mark.skipif(
    not Path(
        "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"
    ).exists(),
    reason="managed bare interpreter not present on this host",
)
def test_runs_under_bare_interpreter_without_jsonschema():
    """The gate MUST run under the managed python3 that has no jsonschema."""
    bare = "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"
    # confirm the interpreter truly lacks jsonschema
    probe = subprocess.run(
        [bare, "-c", "import jsonschema"], capture_output=True, text=True,
    )
    assert probe.returncode != 0, "expected bare interpreter to lack jsonschema"
    # gate still works
    r = subprocess.run(
        [bare, str(GATE), str(FIX / "skill_good.json")],
        capture_output=True, text=True,
    )
    assert r.returncode == 0, r.stdout + r.stderr
