"""test_pack_binding.py — v4.92 reopen B1 (Pack Binding/Adaptation layer).

Verifies the project-adaptation binding layer added to the capability
pack system: the pack-side `bindings` declaration, the project-side
value file (capability_bindings.json), and adopt_pack's resolve step
that pins resolved values into the pack lock.

Covers:
    - capability_pack.schema.json accepts a manifest WITH bindings and
      still accepts the existing bindings-less packs (backward compatible)
    - capability_pack_lock.schema.json accepts resolved_bindings and is
      draft-07 valid
    - resolve: an unresolved REQUIRED binding blocks lock (FAIL)
    - resolve: a boundary-crossing value blocks lock (absolute path / ..)
    - resolve: correct values lock OK; resolved_bindings written + lock
      conforms to the lock schema
    - resolve: OPTIONAL binding falls back to its declared default
    - the whole adopt->lock chain with bindings runs under bare managed
      python3 (no jsonschema)

Layer 1 (OS Spec). No project literals (generic project-id).
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import jsonschema
import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
ADOPT = REPO_ROOT / "scripts" / "capability" / "adopt_pack.py"
FIX = Path(__file__).resolve().parent / "fixtures"
PACK_SCHEMA = REPO_ROOT / "capability_protocols" / "capability_pack.schema.json"
LOCK_SCHEMA = REPO_ROOT / "schemas" / "adoption" / "capability_pack_lock.schema.json"
PACK_BINDINGS = FIX / "pack_with_bindings.json"
PACK_CLEAN = FIX / "pack_clean.json"
BARE = "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"


def _load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def _run(action, pack, project_dir, project_id="binding_proj"):
    cmd = [sys.executable, str(ADOPT), action, str(pack),
           "--project-dir", str(project_dir), "--project-id", project_id,
           "--json"]
    return subprocess.run(cmd, capture_output=True, text=True)


def _write_binding_values(project_dir: Path, pack_id: str, values: dict):
    project_dir.mkdir(parents=True, exist_ok=True)
    (project_dir / "capability_bindings.json").write_text(
        json.dumps({"bindings": {pack_id: values}}, ensure_ascii=False),
        encoding="utf-8")


def _advance_to_adopted(pack, project_dir):
    for action in ("recommend", "adopt", "validate"):
        _run(action, pack, project_dir)


# --------------------------------------------------------------------------
# schema-level
# --------------------------------------------------------------------------
def test_pack_schema_accepts_bindings():
    jsonschema.validate(_load(PACK_BINDINGS), _load(PACK_SCHEMA))


def test_pack_schema_backward_compatible_without_bindings():
    # the bindings-less fixture must still validate (bindings is optional)
    jsonschema.validate(_load(PACK_CLEAN), _load(PACK_SCHEMA))


def test_lock_schema_draft07_valid_with_resolved_bindings():
    schema = _load(LOCK_SCHEMA)
    jsonschema.Draft7Validator.check_schema(schema)
    sample = {
        "schema_version": "1.0.0",
        "pack_id": "binding_demo_pack",
        "locked_version": "0.1.0",
        "locked_at": "2026-06-01T00:00:00Z",
        "manifest_sha256": "a" * 64,
        "validation_evidence": ["x.json"],
        "resolved_bindings": {"source_tables_dir": "game/data/xlsx"},
    }
    jsonschema.validate(sample, schema)


def test_lock_schema_rejects_non_string_binding_value():
    schema = _load(LOCK_SCHEMA)
    bad = {
        "schema_version": "1.0.0",
        "pack_id": "binding_demo_pack",
        "locked_version": "0.1.0",
        "locked_at": "2026-06-01T00:00:00Z",
        "manifest_sha256": "a" * 64,
        "validation_evidence": ["x.json"],
        "resolved_bindings": {"source_tables_dir": 123},
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


# --------------------------------------------------------------------------
# resolve behaviour (the teeth)
# --------------------------------------------------------------------------
def test_lock_fails_on_unresolved_required_binding(tmp_path):
    _advance_to_adopted(PACK_BINDINGS, tmp_path)
    # no capability_bindings.json written -> required binding missing
    res = _run("lock", PACK_BINDINGS, tmp_path)
    assert res.returncode == 1, res.stdout + res.stderr
    payload = json.loads(res.stdout)
    assert payload["ok"] is False
    assert any("unresolved required binding" in e
               and "source_tables_dir" in e
               for e in payload["binding_errors"])
    assert not (tmp_path / "pack_locks" / "binding_demo_pack.lock.json").exists()


def test_lock_fails_on_boundary_crossing_absolute_path(tmp_path):
    _advance_to_adopted(PACK_BINDINGS, tmp_path)
    _write_binding_values(tmp_path, "binding_demo_pack",
                          {"source_tables_dir": "/etc/passwd"})
    res = _run("lock", PACK_BINDINGS, tmp_path)
    assert res.returncode == 1
    payload = json.loads(res.stdout)
    assert any("crosses project boundary" in e for e in payload["binding_errors"])


def test_lock_fails_on_parent_escape_path(tmp_path):
    _advance_to_adopted(PACK_BINDINGS, tmp_path)
    _write_binding_values(tmp_path, "binding_demo_pack",
                          {"source_tables_dir": "../../outside/data"})
    res = _run("lock", PACK_BINDINGS, tmp_path)
    assert res.returncode == 1
    payload = json.loads(res.stdout)
    assert any("crosses project boundary" in e for e in payload["binding_errors"])


def test_lock_ok_writes_resolved_bindings(tmp_path):
    _advance_to_adopted(PACK_BINDINGS, tmp_path)
    _write_binding_values(tmp_path, "binding_demo_pack",
                          {"source_tables_dir": "game/data/xlsx"})
    res = _run("lock", PACK_BINDINGS, tmp_path)
    assert res.returncode == 0, res.stdout + res.stderr
    lock = _load(tmp_path / "pack_locks" / "binding_demo_pack.lock.json")
    rb = lock["resolved_bindings"]
    # required value is pinned
    assert rb["source_tables_dir"] == "game/data/xlsx"
    # optional binding falls back to its declared default
    assert rb["convert_cmd"] == "python3 tools/data/run.py --all"
    # the produced lock conforms to the lock schema
    jsonschema.validate(lock, _load(LOCK_SCHEMA))


def test_optional_binding_uses_supplied_value_over_default(tmp_path):
    _advance_to_adopted(PACK_BINDINGS, tmp_path)
    _write_binding_values(tmp_path, "binding_demo_pack",
                          {"source_tables_dir": "game/data/xlsx",
                           "convert_cmd": "python3 custom/run.py"})
    res = _run("lock", PACK_BINDINGS, tmp_path)
    assert res.returncode == 0
    lock = _load(tmp_path / "pack_locks" / "binding_demo_pack.lock.json")
    assert lock["resolved_bindings"]["convert_cmd"] == "python3 custom/run.py"


# --------------------------------------------------------------------------
# zero-dependency proof
# --------------------------------------------------------------------------
def test_full_binding_chain_under_bare_interpreter(tmp_path):
    """The adopt->lock chain with binding resolution must run under bare
    managed python3 (jsonschema-absent), per the governance zero-dep rule."""
    pd = tmp_path / "proj"
    pd.mkdir(parents=True)
    _write_binding_values(pd, "binding_demo_pack",
                          {"source_tables_dir": "game/data/xlsx"})
    for action in ("recommend", "adopt", "validate", "lock"):
        r = subprocess.run(
            [BARE, str(ADOPT), action, str(PACK_BINDINGS),
             "--project-dir", str(pd), "--project-id", "binding_proj"],
            capture_output=True, text=True)
        assert r.returncode == 0, f"{action}: {r.stdout}{r.stderr}"
    lock = _load(pd / "pack_locks" / "binding_demo_pack.lock.json")
    assert lock["resolved_bindings"]["source_tables_dir"] == "game/data/xlsx"
