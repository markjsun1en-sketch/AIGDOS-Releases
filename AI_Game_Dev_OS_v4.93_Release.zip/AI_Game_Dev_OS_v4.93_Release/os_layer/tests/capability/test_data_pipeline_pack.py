"""test_data_pipeline_pack.py — v4.92 Batch 5 (P0-9 self-test).

Verifies the data_pipeline capability pack AND its core reference
implementation (the $key array-element injection that fixes the
composite heroes-style set_nested_value defect).

Sections:
    - pack contracts pass Batch 1 schema, Batch 2 linter + gate
    - validate_data_pipeline_pack.py reports coherent (bare interpreter)
    - nested_set: plain path, $key array injection (heroes shape), errors
    - schema_check: type/required/enum/range + id-conflict detection
    - pity_gate: pass/fail sentinel interpretation

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import jsonschema
import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
PACK_DIR = REPO_ROOT / "packs" / "game_system_packs" / "data_pipeline"
MANIFEST = PACK_DIR / "capability_pack.json"
AGENT = PACK_DIR / "agents" / "data_pipeline_engineer.json"
SKILLS = sorted((PACK_DIR / "skills").glob("*.json"))
PROTO = REPO_ROOT / "capability_protocols"
VALIDATOR = REPO_ROOT / "scripts" / "capability" / "validate_data_pipeline_pack.py"
BARE = "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"

sys.path.insert(0, str(REPO_ROOT))


def _load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def _ref(name):
    p = PACK_DIR / "reference" / name
    spec = importlib.util.spec_from_file_location(p.stem, p)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# --------------------------------------------------------------------------
# pack contracts
# --------------------------------------------------------------------------
def test_contracts_schema_valid():
    jsonschema.validate(_load(MANIFEST), _load(PROTO / "capability_pack.schema.json"))
    jsonschema.validate(_load(AGENT), _load(PROTO / "agent_contract.schema.json"))
    sk_schema = _load(PROTO / "skill_contract.schema.json")
    for s in SKILLS:
        jsonschema.validate(_load(s), sk_schema)


def test_boundary_linter_clean():
    from scripts.capability import run_boundary_linter as linter
    rep = linter.lint([MANIFEST, AGENT, *SKILLS])
    assert rep.is_clean(), [v.render() for v in rep.violations]


def test_skills_pass_practicality_gate():
    from scripts.capability import run_practicality_gate as gate
    for s in SKILLS:
        rep = gate.evaluate_skill(s)
        assert rep.verdict == "PASS", [v.render() for v in rep.violations]


def test_pack_validator_coherent():
    r = subprocess.run([sys.executable, str(VALIDATOR), str(MANIFEST)],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
    assert "coherent" in r.stdout


@pytest.mark.skipif(not Path(BARE).exists(), reason="bare interpreter absent")
def test_validator_runs_under_bare_interpreter():
    probe = subprocess.run([BARE, "-c", "import jsonschema"],
                           capture_output=True, text=True)
    assert probe.returncode != 0
    r = subprocess.run([BARE, str(VALIDATOR), str(MANIFEST)],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr


# --------------------------------------------------------------------------
# nested_set — the core fix
# --------------------------------------------------------------------------
def test_nested_set_plain_path():
    ns = _ref("nested_set.py")
    c = {}
    ns.set_nested_value(c, ["heroes"], [{"hero_id": "hero_01"}])
    assert c["heroes"] == [{"hero_id": "hero_01"}]


def test_nested_set_array_injection_heroes_shape():
    """Reproduces a composite per-entity table: a stats sheet builds the array,
    animation / sfx sheets inject per-entity sub-records keyed by state."""
    ns = _ref("nested_set.py")
    payload = {}
    # hero_stats -> heroes array
    ns.set_nested_value(payload, ["heroes"], [
        {"hero_id": "hero_01", "name": "Explorer"},
        {"hero_id": "hero_02", "name": "Knight"},
    ])
    # hero_animations -> [heroes, $hero_id, animations], grouped by hero_id,
    # indexed by state
    ns.set_nested_value(payload, ["heroes", "$hero_id", "animations"], [
        {"hero_id": "hero_01", "state": "idle", "single_path": "a/idle.png"},
        {"hero_id": "hero_01", "state": "walk", "single_path": "a/walk.png"},
        {"hero_id": "hero_02", "state": "idle", "single_path": "b/idle.png"},
    ])
    h1 = next(h for h in payload["heroes"] if h["hero_id"] == "hero_01")
    h2 = next(h for h in payload["heroes"] if h["hero_id"] == "hero_02")
    assert set(h1["animations"].keys()) == {"idle", "walk"}
    assert h1["animations"]["idle"]["single_path"] == "a/idle.png"
    assert set(h2["animations"].keys()) == {"idle"}


def test_nested_set_unmatched_key_raises():
    ns = _ref("nested_set.py")
    payload = {}
    ns.set_nested_value(payload, ["heroes"], [{"hero_id": "hero_01"}])
    with pytest.raises(ns.NestedInjectionError):
        ns.set_nested_value(payload, ["heroes", "$hero_id", "animations"], [
            {"hero_id": "ghost_99", "state": "idle"},
        ])


def test_nested_set_missing_match_field_raises():
    ns = _ref("nested_set.py")
    payload = {"heroes": [{"hero_id": "hero_01"}]}
    with pytest.raises(ns.NestedInjectionError):
        ns.set_nested_value(payload, ["heroes", "$hero_id", "animations"], [
            {"state": "idle"},  # no hero_id
        ])


# --------------------------------------------------------------------------
# schema_check
# --------------------------------------------------------------------------
def test_schema_check_valid_and_invalid():
    sc = _ref("schema_check.py")
    schema = {
        "type": "object",
        "required": ["id", "hp"],
        "properties": {
            "id": {"type": "string"},
            "hp": {"type": "integer", "minimum": 1},
        },
    }
    assert sc.validate({"id": "a", "hp": 100}, schema) == []
    errs = sc.validate({"hp": 0}, schema)
    assert any("missing required property 'id'" in e for e in errs)
    assert any("minimum" in e for e in errs)


def test_schema_check_id_conflicts():
    sc = _ref("schema_check.py")
    items = [{"id": "a"}, {"id": "b"}, {"id": "a"}]
    errs = sc.detect_id_conflicts(items, "id", "heroes")
    assert any("duplicate" in e for e in errs)


# --------------------------------------------------------------------------
# pity_gate
# --------------------------------------------------------------------------
def test_pity_gate_pass_sentinel(tmp_path):
    sim = tmp_path / "sim.py"
    sim.write_text("print('ALL_CHECKS_PASS')\n", encoding="utf-8")
    pg = _ref("pity_gate.py")
    code, reason = pg.run_gate(sim, sys.executable, [], "ALL_CHECKS_PASS", None)
    assert code == pg.EXIT_OK


def test_pity_gate_fail_sentinel(tmp_path):
    sim = tmp_path / "sim.py"
    sim.write_text("print('CHECK_FAILED: V1')\n", encoding="utf-8")
    pg = _ref("pity_gate.py")
    code, reason = pg.run_gate(sim, sys.executable, [], "ALL_CHECKS_PASS",
                               "CHECK_FAILED")
    assert code == pg.EXIT_FAIL
