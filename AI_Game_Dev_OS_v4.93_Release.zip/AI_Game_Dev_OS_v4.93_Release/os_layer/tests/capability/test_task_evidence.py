"""test_task_evidence.py — v4.92 Batch 6 (P0-10 self-test).

Verifies the production-task three-piece set: the three schemas and the
record_task_evidence.py generate/verify tool.

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import jsonschema
import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
PROTO = REPO_ROOT / "capability_protocols"
REC = REPO_ROOT / "scripts" / "capability" / "record_task_evidence.py"
HANDOFF_SCHEMA = PROTO / "production_handoff.schema.json"
ROLLBACK_SCHEMA = PROTO / "rollback_note.schema.json"
EVIDENCE_SCHEMA = PROTO / "validation_evidence.schema.json"
BARE = "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"


def _load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def _run(project_dir, *args):
    return subprocess.run(
        [sys.executable, str(REC), "--project-dir", str(project_dir), *args],
        capture_output=True, text=True)


# --- schemas ---------------------------------------------------------------
def test_schemas_draft07_valid():
    for s in (HANDOFF_SCHEMA, ROLLBACK_SCHEMA, EVIDENCE_SCHEMA):
        jsonschema.Draft7Validator.check_schema(_load(s))


def test_evidence_rejects_bad_outcome():
    bad = {
        "schema_version": "1.0.0", "evidence_id": "ev_00000000",
        "created_at": "2026-05-31T00:00:00Z", "pack_id": "data_pipeline_pack",
        "task_id": "t", "commands_run": [{"command": "x", "outcome": "maybe"}],
        "verdict": "pass",
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(EVIDENCE_SCHEMA))


def test_rollback_requires_files_and_steps():
    bad = {
        "schema_version": "1.0.0", "rollback_id": "rb_00000000",
        "created_at": "2026-05-31T00:00:00Z", "pack_id": "p", "task_id": "t",
        "files_touched": [], "revert_steps": [],
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(ROLLBACK_SCHEMA))


# --- full flow -------------------------------------------------------------
def test_three_piece_flow_and_schema(tmp_path):
    pd = tmp_path / "proj"
    assert _run(pd, "handoff", "--pack", "data_pipeline_pack",
                "--from", "data_pipeline_engineer",
                "--reason", "needs a new column", "--blocking").returncode == 0
    assert _run(pd, "rollback", "--pack", "data_pipeline_pack", "--task", "t1",
                "--file", "game/data/heroes.json",
                "--revert", "restore backup").returncode == 0
    assert _run(pd, "evidence", "--pack", "data_pipeline_pack", "--task", "t1",
                "--cmd", "validate=pass").returncode == 0

    base = pd / ".ai_dev_os" / "local_handoffs"
    jsonschema.validate(
        _load(next((base / "handoffs").glob("*.json"))), _load(HANDOFF_SCHEMA))
    jsonschema.validate(
        _load(next((base / "rollback_notes").glob("*.json"))), _load(ROLLBACK_SCHEMA))
    jsonschema.validate(
        _load(next((base / "evidence").glob("*.json"))), _load(EVIDENCE_SCHEMA))


def test_verify_passes_complete_set(tmp_path):
    pd = tmp_path / "proj"
    _run(pd, "rollback", "--pack", "p", "--task", "t1",
         "--file", "a.json", "--revert", "restore")
    _run(pd, "evidence", "--pack", "p", "--task", "t1", "--cmd", "v=pass")
    r = _run(pd, "verify", "--task", "t1", "--require-rollback")
    assert r.returncode == 0, r.stdout


def test_verify_flags_missing_evidence(tmp_path):
    pd = tmp_path / "proj"
    # only a rollback, no evidence
    _run(pd, "rollback", "--pack", "p", "--task", "t2",
         "--file", "a.json", "--revert", "restore")
    r = _run(pd, "verify", "--task", "t2")
    assert r.returncode == 1
    assert "no validation evidence" in r.stdout


def test_verify_flags_missing_rollback_when_required(tmp_path):
    pd = tmp_path / "proj"
    _run(pd, "evidence", "--pack", "p", "--task", "t3", "--cmd", "v=pass")
    r = _run(pd, "verify", "--task", "t3", "--require-rollback")
    assert r.returncode == 1
    assert "no rollback note" in r.stdout


def test_evidence_verdict_fail_on_failed_cmd(tmp_path):
    pd = tmp_path / "proj"
    r = _run(pd, "--json", "evidence", "--pack", "p", "--task", "t4",
             "--cmd", "a=pass", "--cmd", "b=fail")
    payload = json.loads(r.stdout)
    assert payload["verdict"] == "fail"


@pytest.mark.skipif(not Path(BARE).exists(), reason="bare interpreter absent")
def test_runs_under_bare_interpreter(tmp_path):
    probe = subprocess.run([BARE, "-c", "import jsonschema"],
                           capture_output=True, text=True)
    assert probe.returncode != 0
    pd = tmp_path / "proj"
    r = subprocess.run(
        [BARE, str(REC), "--project-dir", str(pd), "evidence",
         "--pack", "p", "--task", "t", "--cmd", "v=pass"],
        capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
