"""test_minimal_hooks.py — v4.92 Batch 7 (R7 hooks).

Verifies the five minimal hooks reserved for v4.93+ mainlines:
    - all five stub schemas exist and are draft-07 valid
    - each declares additionalProperties:false (no silent sprawl)
    - each carries a _deferred marker (since v4.92, implement v4.93+)
    - the hooks README lists all five

These are interface stubs ONLY — v4.92 ships no implementation, so the test
asserts reservation, not behaviour.

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import json
from pathlib import Path

import jsonschema
import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
HOOKS = REPO_ROOT / "capability_protocols" / "hooks"

STUBS = [
    "truth_map.stub.schema.json",
    "architecture_scan.stub.schema.json",
    "event_trace.stub.schema.json",
    "owner_approval.stub.schema.json",
    "pack_evidence_metadata.stub.schema.json",
]


def _load(name):
    return json.loads((HOOKS / name).read_text(encoding="utf-8"))


@pytest.mark.parametrize("name", STUBS)
def test_stub_is_draft07_valid(name):
    jsonschema.Draft7Validator.check_schema(_load(name))


@pytest.mark.parametrize("name", STUBS)
def test_stub_no_sprawl_and_deferred(name):
    s = _load(name)
    assert s["additionalProperties"] is False
    assert s["properties"]["schema_version"]["const"] == "0.0.1-stub"
    assert "_deferred" in s
    assert s["_deferred"]["since"] == "v4.92"
    assert s["_deferred"]["implement_in"].startswith("v4.93")
    assert s["_deferred"]["mainline"]


def test_all_five_present():
    for name in STUBS:
        assert (HOOKS / name).exists(), f"missing hook stub {name}"


def test_readme_lists_all_hooks():
    txt = (HOOKS / "README.md").read_text(encoding="utf-8")
    for name in STUBS:
        assert name in txt, f"README does not list {name}"
