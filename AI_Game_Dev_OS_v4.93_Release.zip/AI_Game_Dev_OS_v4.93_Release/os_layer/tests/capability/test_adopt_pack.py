"""test_adopt_pack.py — v4.92 Batch 3 (P0-6/7 self-test).

Verifies scripts/capability/adopt_pack.py and the two Batch 3 schemas:
    - capability_pack_adoption_state.schema.json
    - capability_pack_lock.schema.json

Covers:
    - full flow recommend -> adopt -> validate -> lock for a clean beta pack
    - draft pack is refused at recommend AND adopt
    - illegal transition (lock before adopt) refused
    - project-id with a project proper-name is rejected (usage exit 2)
    - emitted project-side files conform to their schemas
    - the two schemas are draft-07 valid and reject malformed instances
    - runs under bare managed python3 without jsonschema

Layer 1 (OS Spec). No project literals (generic project-id).
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import jsonschema
import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
ADOPT = REPO_ROOT / "scripts" / "capability" / "adopt_pack.py"
FIX = Path(__file__).resolve().parent / "fixtures"
SCHEMA_DIR = REPO_ROOT / "schemas" / "adoption"
STATE_SCHEMA = SCHEMA_DIR / "capability_pack_adoption_state.schema.json"
LOCK_SCHEMA = SCHEMA_DIR / "capability_pack_lock.schema.json"
PACK_CLEAN = FIX / "pack_clean.json"
PACK_DRAFT = FIX / "pack_draft.json"
BARE = "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"


def _run(action, pack, project_dir, project_id="demo_proj", extra=None):
    cmd = [sys.executable, str(ADOPT), action, str(pack),
           "--project-dir", str(project_dir), "--project-id", project_id]
    if extra:
        cmd += extra
    return subprocess.run(cmd, capture_output=True, text=True)


def _load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


# --------------------------------------------------------------------------
# schema self-tests
# --------------------------------------------------------------------------
def test_schemas_draft07_valid():
    jsonschema.Draft7Validator.check_schema(_load(STATE_SCHEMA))
    jsonschema.Draft7Validator.check_schema(_load(LOCK_SCHEMA))


def test_verified_state_requires_lock_and_evidence():
    schema = _load(STATE_SCHEMA)
    bad = {
        "schema_version": "1.0.0",
        "active_capability_packs": [
            {"pack_id": "data_pipeline_pack", "version": "0.1.0",
             "adoption_status": "verified",
             "adopted_at": "2026-05-31T00:00:00Z"}
        ],
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_lock_requires_validation_evidence():
    schema = _load(LOCK_SCHEMA)
    bad = {
        "schema_version": "1.0.0",
        "pack_id": "data_pipeline_pack",
        "locked_version": "0.1.0",
        "locked_at": "2026-05-31T00:00:00Z",
        "manifest_sha256": "0" * 64,
        "validation_evidence": [],
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


# --------------------------------------------------------------------------
# flow tests
# --------------------------------------------------------------------------
def test_full_flow_and_files_conform(tmp_path):
    pd = tmp_path / "proj"
    assert _run("recommend", PACK_CLEAN, pd).returncode == 0
    assert _run("adopt", PACK_CLEAN, pd).returncode == 0
    assert _run("validate", PACK_CLEAN, pd).returncode == 0
    assert _run("lock", PACK_CLEAN, pd).returncode == 0

    state = _load(pd / "capability_active_packs.json")
    jsonschema.validate(state, _load(STATE_SCHEMA))
    entry = state["active_capability_packs"][0]
    assert entry["adoption_status"] == "verified"

    lock = _load(pd / "pack_locks" / "data_pipeline_pack.lock.json")
    jsonschema.validate(lock, _load(LOCK_SCHEMA))
    assert len(lock["manifest_sha256"]) == 64


def test_draft_pack_refused_recommend(tmp_path):
    r = _run("recommend", PACK_DRAFT, tmp_path / "p")
    assert r.returncode == 1
    assert "draft" in r.stdout.lower()


def test_draft_pack_refused_adopt(tmp_path):
    r = _run("adopt", PACK_DRAFT, tmp_path / "p")
    assert r.returncode == 1


def test_lock_before_adopt_refused(tmp_path):
    # lock without prior adopt/validate -> refused
    r = _run("lock", PACK_CLEAN, tmp_path / "p")
    assert r.returncode == 1
    assert "adopted" in r.stdout.lower()


def test_validate_before_adopt_is_illegal_transition(tmp_path):
    # validate from absent state: lint passes but transition None->adopted illegal
    r = _run("validate", PACK_CLEAN, tmp_path / "p")
    assert r.returncode == 1


def test_project_id_blacklist_rejected(tmp_path):
    r = _run("recommend", PACK_CLEAN, tmp_path / "p", project_id="rh-sprint")
    assert r.returncode == 2  # argparse usage error


@pytest.mark.skipif(not Path(BARE).exists(),
                    reason="managed bare interpreter not present")
def test_runs_under_bare_interpreter_without_jsonschema(tmp_path):
    probe = subprocess.run([BARE, "-c", "import jsonschema"],
                           capture_output=True, text=True)
    assert probe.returncode != 0
    pd = tmp_path / "proj"
    r = subprocess.run(
        [BARE, str(ADOPT), "recommend", str(PACK_CLEAN),
         "--project-dir", str(pd), "--project-id", "demo_proj"],
        capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
