"""test_output_adapter.py — v4.92 Batch 5.5 (P0-9 closure self-test).

Verifies the OutputAdapter abstraction and its first concrete implementation:
    packs/game_system_packs/data_pipeline/reference/output_adapter.py
    packs/game_system_packs/data_pipeline/reference/adapter_contract.py
    packs/game_system_packs/data_pipeline/reference/json_adapter.py

Covers:
    - JsonAdapter passes the universal adapter contract (check_adapter)
    - JsonAdapter satisfies the runtime_checkable OutputAdapter protocol
    - runtime serialization conventions: indent=2, ensure_ascii=False,
      trailing newline, source-order preserved
    - AdapterResult shape (ok / path / bytes_written / verdict / adapter)
    - determinism: same payload -> byte-identical artifact
    - round-trip equivalence via reparse
    - a deliberately non-compliant adapter is *caught* by the contract
      (proving the contract has teeth — the "true abstraction" guarantee)
    - the whole chain runs under bare managed python3 (no jsonschema)

Layer 1 (OS Spec). No project literals (generic heroes-style fixture).
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
REFERENCE = (REPO_ROOT / "packs" / "game_system_packs" / "data_pipeline"
             / "reference")
BARE = "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"


@pytest.fixture(autouse=True)
def _on_path():
    """Make the pack reference modules importable (they're vendor-style)."""
    sys.path.insert(0, str(REFERENCE))
    try:
        yield
    finally:
        # drop our entry and any cached reference modules so other tests
        # importing same-named modules are unaffected.
        try:
            sys.path.remove(str(REFERENCE))
        except ValueError:
            pass
        for m in ("output_adapter", "json_adapter", "adapter_contract"):
            sys.modules.pop(m, None)


SAMPLE = {
    "version": 1,
    "heroes": [
        {"id": "h_01", "base_stats": {"hp": 150}, "label": "勇者"},
        {"id": "h_02", "base_stats": {"hp": 90}},
    ],
    "battle_formula": "hp * 1.5",
}


def test_json_adapter_passes_contract():
    from json_adapter import JsonAdapter, reparse
    from adapter_contract import check_adapter
    errs = check_adapter(JsonAdapter(), SAMPLE, reparse)
    assert errs == [], f"contract violations: {errs}"


def test_json_adapter_is_output_adapter_protocol():
    from json_adapter import JsonAdapter
    from output_adapter import OutputAdapter
    a = JsonAdapter()
    assert isinstance(a, OutputAdapter)  # runtime_checkable duck check
    assert a.name == "json"
    assert a.target_extension == ".json"


def test_runtime_serialization_conventions(tmp_path):
    from json_adapter import JsonAdapter
    out = tmp_path / "heroes.json"
    res = JsonAdapter().write(SAMPLE, out)
    text = out.read_text(encoding="utf-8")
    # indent=2: nested keys are indented by multiples of two spaces
    assert '\n  "heroes"' in text
    # ensure_ascii=False: non-ASCII written verbatim, not \uXXXX-escaped
    assert "勇者" in text and "\\u" not in text
    # trailing newline
    assert text.endswith("}\n")
    # source order preserved (version before heroes before battle_formula)
    assert text.index('"version"') < text.index('"heroes"') < text.index('"battle_formula"')
    # result accounting
    assert res.ok and res.verdict == "WRITE_OK" and res.adapter == "json"
    assert res.bytes_written == out.stat().st_size


def test_determinism_byte_identical(tmp_path):
    from json_adapter import JsonAdapter
    a = JsonAdapter()
    p1, p2 = tmp_path / "a.json", tmp_path / "b.json"
    a.write(SAMPLE, p1)
    a.write(SAMPLE, p2)
    assert p1.read_bytes() == p2.read_bytes()


def test_round_trip_equivalent(tmp_path):
    from json_adapter import JsonAdapter, reparse
    out = tmp_path / "heroes.json"
    JsonAdapter().write(SAMPLE, out)
    assert reparse(out) == SAMPLE


def test_sort_keys_option_changes_order(tmp_path):
    from json_adapter import JsonAdapter
    out = tmp_path / "sorted.json"
    JsonAdapter(sort_keys=True).write(SAMPLE, out)
    text = out.read_text(encoding="utf-8")
    # sorted: battle_formula < heroes < version
    assert text.index('"battle_formula"') < text.index('"heroes"') < text.index('"version"')


def test_contract_catches_a_noncompliant_adapter():
    """The contract must reject a broken adapter — proving it has teeth.

    A real abstraction needs a verifiable bar; if check_adapter passed
    everything, 'add an adapter, pass the contract' would be meaningless.
    """
    from adapter_contract import check_adapter
    from output_adapter import AdapterResult, VERDICT_OK

    class BrokenAdapter:
        # writes nothing to disk, lies about success.
        name = "broken"
        target_extension = ".json"

        def write(self, payload, out_path, *, meta=None):
            return AdapterResult(
                ok=True, path=str(out_path), bytes_written=999,
                verdict=VERDICT_OK, adapter=self.name)

    errs = check_adapter(BrokenAdapter(), SAMPLE, lambda p: None)
    assert errs, "contract must flag an adapter that doesn't write a file"


def test_contract_catches_bad_extension():
    from adapter_contract import check_adapter
    from json_adapter import JsonAdapter, reparse

    class NoDotExt(JsonAdapter):
        target_extension = "json"  # missing leading dot

    errs = check_adapter(NoDotExt(), SAMPLE, reparse)
    assert any("leading dot" in e for e in errs)


@pytest.mark.skipif(not Path(BARE).exists(),
                    reason="managed bare interpreter not present")
def test_runs_under_bare_interpreter_without_jsonschema():
    # confirm the managed interpreter truly lacks jsonschema
    probe = subprocess.run([BARE, "-c", "import jsonschema"],
                           capture_output=True, text=True)
    assert probe.returncode != 0

    script = (
        "import sys; sys.path.insert(0, r'%s')\n"
        "from json_adapter import JsonAdapter, reparse\n"
        "from adapter_contract import check_adapter\n"
        "errs = check_adapter(JsonAdapter(), {'version': 1, 'x': [1, 2]}, reparse)\n"
        "print('VIOLATIONS' if errs else 'CONTRACT_OK')\n"
    ) % str(REFERENCE)
    r = subprocess.run([BARE, "-c", script], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
    assert "CONTRACT_OK" in r.stdout
