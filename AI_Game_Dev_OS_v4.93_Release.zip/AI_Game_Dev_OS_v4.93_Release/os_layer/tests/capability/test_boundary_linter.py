"""test_boundary_linter.py — v4.92 Batch 2 (P0-5 self-test).

Verifies scripts/capability/run_boundary_linter.py:
    - a clean pack+agent set PASSes
    - a conflicting set fires the expected boundary rules
      (over-broad write, writes-core, core-not-forbidden, dual owns,
       shared path without policy, dependency cycle)
    - runs under a bare interpreter without jsonschema

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
LINT = REPO_ROOT / "scripts" / "capability" / "run_boundary_linter.py"
FIX = Path(__file__).resolve().parent / "fixtures"

sys.path.insert(0, str(REPO_ROOT))
from scripts.capability import run_boundary_linter as linter  # noqa: E402


def _rules(paths):
    rep = linter.lint([Path(p) for p in paths])
    return rep, {v.rule for v in rep.violations}


def test_clean_set_passes():
    rep, rules = _rules([
        FIX / "pack_clean.json",
        FIX / "agent_clean.json",
        FIX / "skill_good.json",
    ])
    assert rep.is_clean(), [v.render() for v in rep.violations]


def test_over_broad_and_core_write_flagged():
    rep, rules = _rules([FIX / "pack_greedy.json"])
    assert "B1_over_broad_write" in rules
    assert "B6_writes_core" in rules


def test_dual_owns_flagged():
    rep, rules = _rules([FIX / "agent_one.json", FIX / "agent_two.json"])
    assert "B2_dual_owns" in rules


def test_shared_path_without_policy_flagged():
    # agent_one and agent_two both can_modify game/scripts/shared/**
    rep, rules = _rules([FIX / "agent_one.json", FIX / "agent_two.json"])
    assert "B5_shared_path_no_policy" in rules


def test_allow_forbid_overlap_flagged():
    # agent_one: can_modify game/scripts/shared/** vs must_not_modify
    # game/scripts/shared/core/**  -> overlap
    rep, rules = _rules([FIX / "agent_one.json"])
    assert "B4_allow_forbid_overlap" in rules


def test_dependency_cycle_flagged():
    rep, rules = _rules([FIX / "pack_greedy.json", FIX / "pack_greedy_b.json"])
    assert "B7_dependency_cycle" in rules


def test_cli_exit_codes():
    r0 = subprocess.run(
        [sys.executable, str(LINT), str(FIX / "pack_clean.json"),
         str(FIX / "agent_clean.json")],
        capture_output=True, text=True,
    )
    assert r0.returncode == 0, r0.stdout + r0.stderr
    r1 = subprocess.run(
        [sys.executable, str(LINT), str(FIX / "pack_greedy.json")],
        capture_output=True, text=True,
    )
    assert r1.returncode == 1


def test_cli_json_output():
    r = subprocess.run(
        [sys.executable, str(LINT), "--json", str(FIX / "pack_clean.json")],
        capture_output=True, text=True,
    )
    payload = json.loads(r.stdout)
    assert payload["ok"] is True


@pytest.mark.skipif(
    not Path(
        "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"
    ).exists(),
    reason="managed bare interpreter not present on this host",
)
def test_runs_under_bare_interpreter_without_jsonschema():
    bare = "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"
    probe = subprocess.run(
        [bare, "-c", "import jsonschema"], capture_output=True, text=True,
    )
    assert probe.returncode != 0
    r = subprocess.run(
        [bare, str(LINT), str(FIX / "pack_clean.json")],
        capture_output=True, text=True,
    )
    assert r.returncode == 0, r.stdout + r.stderr
