"""test_pack_adoption_tools.py — v4.92 Batch 5.5 (§25 Phase 4 self-test).

Verifies the three Phase 4 project-adoption tools that complement
adopt_pack.py (Batch 3):
    scripts/capability/list_available_packs.py
    scripts/capability/validate_active_packs.py
    scripts/capability/export_pack_report.py

Covers:
    - list discovers both shipped packs and marks them eligible
    - list --eligible-only and --json
    - validate_active reports 'consistent' for a clean adopt->lock flow
    - validate_active catches an orphan (active entry, no shipped pack)
    - validate_active catches a verified entry missing its lock_ref
    - export_pack_report joins available + active with correct adoption_state
    - report exit code reflects consistency (0 clean / 1 with issues)
    - all three run under bare managed python3 (no jsonschema)

Layer 1 (OS Spec). No project literals (generic project-id).
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
CAP = REPO_ROOT / "scripts" / "capability"
ADOPT = CAP / "adopt_pack.py"
LIST = CAP / "list_available_packs.py"
VALIDATE = CAP / "validate_active_packs.py"
REPORT = CAP / "export_pack_report.py"
DP_PACK = (REPO_ROOT / "packs" / "game_system_packs" / "data_pipeline"
           / "capability_pack.json")
BARE = "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"


def _run(script, *args, interp=None):
    cmd = [interp or sys.executable, str(script), *args]
    return subprocess.run(cmd, capture_output=True, text=True)


def _adopt_flow(project_dir: Path, project_id="demo_proj"):
    common = ["--project-dir", str(project_dir), "--project-id", project_id]
    # v4.92 reopen B1: data_pipeline_pack declares required bindings; the
    # project must supply values before lock (else lock correctly refuses).
    project_dir.mkdir(parents=True, exist_ok=True)
    (project_dir / "capability_bindings.json").write_text(
        json.dumps({"bindings": {"data_pipeline_pack": {
            "source_tables_dir": "game/data/xlsx",
            "runtime_data_dir": "game/data",
        }}}), encoding="utf-8")
    for action in ("recommend", "adopt", "validate", "lock"):
        r = _run(ADOPT, action, str(DP_PACK), *common)
        assert r.returncode == 0, f"{action}: {r.stdout}\n{r.stderr}"


# ── list_available_packs ─────────────────────────────────────────────────────

def test_list_discovers_shipped_packs():
    r = _run(LIST, "--json")
    assert r.returncode == 0, r.stderr
    data = json.loads(r.stdout)
    ids = {p["pack_id"] for p in data["packs"]}
    assert {"data_pipeline_pack", "godot_2d_adapter"} <= ids
    by_id = {p["pack_id"]: p for p in data["packs"]}
    # the two shipped beta packs are adoption-eligible.
    assert by_id["data_pipeline_pack"]["eligible"]
    assert by_id["godot_2d_adapter"]["eligible"]
    # B7 skeleton packs are draft -> intentionally NOT eligible until built out.
    for draft_pack in ("design_data_pack", "art_asset_pack", "qa_validation_pack"):
        if draft_pack in by_id:
            assert not by_id[draft_pack]["eligible"], \
                f"{draft_pack} is a draft skeleton and must not be adoption-eligible"


def test_list_eligible_only_and_human_readable():
    r = _run(LIST, "--eligible-only")
    assert r.returncode == 0
    assert "data_pipeline_pack" in r.stdout
    assert "total:" in r.stdout


def test_list_missing_packs_dir():
    r = _run(LIST, "--packs-dir", "/nonexistent/packs")
    assert r.returncode == 4


# ── validate_active_packs ────────────────────────────────────────────────────

def test_validate_active_consistent_after_flow(tmp_path):
    pd = tmp_path / "proj"
    _adopt_flow(pd)
    r = _run(VALIDATE, "--project-dir", str(pd))
    assert r.returncode == 0, r.stdout + r.stderr
    assert "consistent" in r.stdout


def test_validate_active_missing_file(tmp_path):
    pd = tmp_path / "empty_proj"
    pd.mkdir()
    r = _run(VALIDATE, "--project-dir", str(pd))
    assert r.returncode == 4


def test_validate_active_catches_orphan(tmp_path):
    pd = tmp_path / "proj"
    pd.mkdir()
    # an active entry for a pack that does not ship under packs/
    (pd / "capability_active_packs.json").write_text(json.dumps({
        "schema_version": "1.0.0",
        "active_capability_packs": [
            {"pack_id": "ghost_pack", "version": "9.9.9",
             "adoption_status": "adopting"}
        ],
    }), encoding="utf-8")
    r = _run(VALIDATE, "--project-dir", str(pd), "--json")
    assert r.returncode == 1
    data = json.loads(r.stdout)
    assert any(i["kind"] == "orphan" for i in data["issues"])


def test_validate_active_catches_incomplete_verified(tmp_path):
    pd = tmp_path / "proj"
    pd.mkdir()
    # verified with no lock_ref / evidence -> incomplete
    (pd / "capability_active_packs.json").write_text(json.dumps({
        "schema_version": "1.0.0",
        "active_capability_packs": [
            {"pack_id": "data_pipeline_pack", "version": "0.1.0",
             "adoption_status": "verified"}
        ],
    }), encoding="utf-8")
    r = _run(VALIDATE, "--project-dir", str(pd), "--json")
    assert r.returncode == 1
    data = json.loads(r.stdout)
    assert any(i["kind"] == "incomplete_verified" for i in data["issues"])


def test_validate_active_catches_version_drift(tmp_path):
    pd = tmp_path / "proj"
    pd.mkdir()
    (pd / "capability_active_packs.json").write_text(json.dumps({
        "schema_version": "1.0.0",
        "active_capability_packs": [
            {"pack_id": "data_pipeline_pack", "version": "0.0.1",
             "adoption_status": "adopting"}
        ],
    }), encoding="utf-8")
    r = _run(VALIDATE, "--project-dir", str(pd), "--json")
    assert r.returncode == 1
    data = json.loads(r.stdout)
    assert any(i["kind"] == "version_drift" for i in data["issues"])


# ── export_pack_report ───────────────────────────────────────────────────────

def test_report_packs_only_catalog():
    r = _run(REPORT)
    assert r.returncode == 0, r.stderr
    data = json.loads(r.stdout)
    assert data["available_count"] >= 2
    assert data["project"] is None
    assert data["consistent"] is True


def test_report_joins_available_and_active(tmp_path):
    pd = tmp_path / "proj"
    _adopt_flow(pd)
    r = _run(REPORT, "--project-dir", str(pd))
    assert r.returncode == 0, r.stdout + r.stderr
    data = json.loads(r.stdout)
    rows = {row["pack_id"]: row for row in data["project"]["rows"]}
    assert rows["data_pipeline_pack"]["adoption_state"] == "verified"
    assert rows["data_pipeline_pack"]["lock_ref"]
    assert rows["godot_2d_adapter"]["adoption_state"] == "not_adopted"
    assert data["consistent"] is True


def test_report_out_file_and_markdown(tmp_path):
    pd = tmp_path / "proj"
    _adopt_flow(pd)
    out = tmp_path / "report.json"
    r = _run(REPORT, "--project-dir", str(pd), "--out", str(out))
    assert r.returncode == 0
    assert out.exists()
    json.loads(out.read_text(encoding="utf-8"))  # valid JSON
    md = _run(REPORT, "--project-dir", str(pd), "--markdown")
    assert md.returncode == 0
    assert "# Capability Pack Status Report" in md.stdout


def test_report_nonzero_on_inconsistency(tmp_path):
    pd = tmp_path / "proj"
    pd.mkdir()
    (pd / "capability_active_packs.json").write_text(json.dumps({
        "schema_version": "1.0.0",
        "active_capability_packs": [
            {"pack_id": "ghost_pack", "version": "9.9.9",
             "adoption_status": "adopting"}
        ],
    }), encoding="utf-8")
    r = _run(REPORT, "--project-dir", str(pd))
    assert r.returncode == 1
    data = json.loads(r.stdout)
    assert data["consistent"] is False


# ── zero-dependency proof ────────────────────────────────────────────────────

@pytest.mark.skipif(not Path(BARE).exists(),
                    reason="managed bare interpreter not present")
def test_tools_run_under_bare_interpreter(tmp_path):
    probe = subprocess.run([BARE, "-c", "import jsonschema"],
                           capture_output=True, text=True)
    assert probe.returncode != 0
    pd = tmp_path / "proj"
    # full flow under bare interpreter
    pd.mkdir(parents=True, exist_ok=True)
    (pd / "capability_bindings.json").write_text(
        json.dumps({"bindings": {"data_pipeline_pack": {
            "source_tables_dir": "game/data/xlsx",
            "runtime_data_dir": "game/data",
        }}}), encoding="utf-8")
    common = ["--project-dir", str(pd), "--project-id", "bare_proj"]
    for action in ("recommend", "adopt", "validate", "lock"):
        r = _run(ADOPT, action, str(DP_PACK), *common, interp=BARE)
        assert r.returncode == 0, r.stdout + r.stderr
    for script in (LIST, VALIDATE, REPORT):
        extra = ["--project-dir", str(pd)] if script is not LIST else []
        r = _run(script, *extra, interp=BARE)
        assert r.returncode == 0, f"{script.name}: {r.stdout}\n{r.stderr}"
