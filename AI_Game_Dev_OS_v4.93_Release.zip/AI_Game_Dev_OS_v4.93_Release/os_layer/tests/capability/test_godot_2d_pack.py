"""test_godot_2d_pack.py — v4.92 Batch 4 (P0-8 self-test).

Verifies the godot_2d_adapter capability pack scaffold:
    - pack manifest + agent + skills are schema-valid (Batch 1 contracts)
    - the full instance set passes the boundary linter (Batch 2)
    - both skills pass the Practicality Gate (Batch 2)
    - validate_godot_2d_pack.py reports the pack coherent
    - adopt_pack.py can recommend (Batch 3 flow) this pack
    - the pack validator runs under bare managed python3 without jsonschema

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import jsonschema
import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
PACK_DIR = REPO_ROOT / "packs" / "engine_adapters" / "godot_2d"
MANIFEST = PACK_DIR / "capability_pack.json"
AGENT = PACK_DIR / "agents" / "godot_2d_engineer.json"
SKILLS = [
    PACK_DIR / "skills" / "gdscript_write_skill.json",
    PACK_DIR / "skills" / "scene_resource_write_skill.json",
]
PROTO = REPO_ROOT / "capability_protocols"
VALIDATOR = REPO_ROOT / "scripts" / "capability" / "validate_godot_2d_pack.py"
ADOPT = REPO_ROOT / "scripts" / "capability" / "adopt_pack.py"
GATE = REPO_ROOT / "scripts" / "capability" / "run_practicality_gate.py"
BARE = "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"

sys.path.insert(0, str(REPO_ROOT))


def _load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def test_manifest_and_contracts_schema_valid():
    jsonschema.validate(_load(MANIFEST), _load(PROTO / "capability_pack.schema.json"))
    jsonschema.validate(_load(AGENT), _load(PROTO / "agent_contract.schema.json"))
    sk_schema = _load(PROTO / "skill_contract.schema.json")
    for s in SKILLS:
        jsonschema.validate(_load(s), sk_schema)


def test_boundary_linter_clean():
    from scripts.capability import run_boundary_linter as linter
    rep = linter.lint([MANIFEST, AGENT, *SKILLS])
    assert rep.is_clean(), [v.render() for v in rep.violations]


def test_skills_pass_practicality_gate():
    from scripts.capability import run_practicality_gate as gate
    for s in SKILLS:
        rep = gate.evaluate_skill(s)
        assert rep.verdict == "PASS", [v.render() for v in rep.violations]


def test_pack_validator_coherent():
    r = subprocess.run(
        [sys.executable, str(VALIDATOR), str(MANIFEST)],
        capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
    assert "coherent" in r.stdout


def test_adopt_recommend_eligible(tmp_path):
    r = subprocess.run(
        [sys.executable, str(ADOPT), "recommend", str(MANIFEST),
         "--project-dir", str(tmp_path), "--project-id", "demo_proj"],
        capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
    assert "eligible" in r.stdout


def test_required_templates_exist():
    for rel in ("templates/GDSCRIPT_CONVENTIONS.md",
                "templates/SCENE_RESOURCE_RULES.md",
                "templates/HEADLESS_SMOKE_CONTRACT.md",
                "templates/headless_smoke_template.gd"):
        assert (PACK_DIR / rel).exists(), f"missing {rel}"


def test_smoke_template_extends_scenetree():
    txt = (PACK_DIR / "templates" / "headless_smoke_template.gd").read_text(
        encoding="utf-8")
    assert "extends SceneTree" in txt
    assert "SMOKE_OK" in txt and "SMOKE_FAIL" in txt


@pytest.mark.skipif(not Path(BARE).exists(),
                    reason="managed bare interpreter not present")
def test_validator_runs_under_bare_interpreter():
    probe = subprocess.run([BARE, "-c", "import jsonschema"],
                           capture_output=True, text=True)
    assert probe.returncode != 0
    r = subprocess.run([BARE, str(VALIDATOR), str(MANIFEST)],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
