"""Tests for M9.0.5 — generate_cold_start_pack.py.

Phase 4 Step 3 / M9.0 Sprint+Agent cold-start / commit 7 (M9.0.7) of
8-commit chain.

Covers:
- Pack schema: the 16-key cold_start_pack.v1 envelope is stable
  across empty + populated fixtures.
- Manifest consistency: context_files / on_demand_files /
  load_width_policy come from the 3-profile manifest (M9.0.3) and
  differ across SPRINT_GOVERNED / SPRINT_DEEP / ARCHIVE_LOOKUP.
- Task discovery precedence: explicit --task-id > agent-owner >
  issue-blocker matching; sprint-rollup sprint_ids bias the
  candidate sort.
- Confidence levels: empty / low / medium / high resolve per the
  primary+secondary signature.
- Suggested next-step heuristic: resolves to one of
  {blocker / validation / handoff / continue / start / null-prompt}.
- CLI contract: requires at least one of --agent / --thread /
  --task-id / --issue-id; --repo-root works.

Working language: English (permanent contract §11).
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import pytest

from _runtime_common import RuntimeContext
from generate_cold_start_pack import (
    build_pack,
    confidence_level,
    latest_handoff_for_task,
    sort_candidates,
    suggest_next_step,
    task_reset_warning,
)


_PKG_ROOT = Path(__file__).resolve().parents[1]
_FIXTURE = _PKG_ROOT / "tests" / "fixtures" / "sprint_window"
_PACK_SCRIPT = _PKG_ROOT / "tools" / "runtime" / "generate_cold_start_pack.py"


def _make_args(**overrides) -> argparse.Namespace:
    base = dict(
        agent=None, thread=None, task_id=None, issue_id=None,
        profile=None, repo_root=None,
    )
    base.update(overrides)
    return argparse.Namespace(**base)


# ---------------------------------------------------------------------------
# Schema stability — empty + populated
# ---------------------------------------------------------------------------


_EXPECTED_TOP_KEYS = {
    "schema_version",
    "generated_at",
    "project",
    "profile",
    "load_width_policy",
    "primary_task",
    "secondary_candidate_tasks",
    "open_blockers",
    "latest_handoff",
    "context_files",
    "dynamic_context",
    "on_demand_files",
    "must_read_files",
    "sprint_window_ids",
    "recent_orchestrator_log_entries",
    "suggested_next_step",
    "not_in_scope",
    "confidence",
    "task_reset_warning",
    "auto_escalate_to_on_demand",
}


def test_pack_schema_keys_stable_on_empty_package():
    ctx = RuntimeContext(repo_root=_PKG_ROOT)
    pack = build_pack(ctx, _make_args(agent="test"))
    assert set(pack.keys()) == _EXPECTED_TOP_KEYS
    assert pack["schema_version"] == "cold_start_pack.v1"
    assert pack["project"] == "v4.89_os"
    assert pack["primary_task"] is None
    assert pack["confidence"] == "empty"


def test_pack_schema_keys_stable_on_fixture():
    ctx = RuntimeContext(repo_root=_FIXTURE)
    pack = build_pack(ctx, _make_args(agent="engineer"))
    assert set(pack.keys()) == _EXPECTED_TOP_KEYS


# ---------------------------------------------------------------------------
# Manifest consistency across 3 profiles
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "profile, expected_policy",
    [
        ("SPRINT_GOVERNED", "sprint_governed_default"),
        ("SPRINT_DEEP", "sprint_deep_manual"),
        ("ARCHIVE_LOOKUP", "archive_lookup_manual"),
    ],
)
def test_profile_load_width_policy_matches_manifest(profile, expected_policy):
    ctx = RuntimeContext(repo_root=_FIXTURE)
    pack = build_pack(ctx, _make_args(agent="engineer", profile=profile))
    assert pack["profile"] == profile
    assert pack["load_width_policy"] == expected_policy


def test_sprint_deep_includes_orchestrator_log_in_context_files():
    ctx = RuntimeContext(repo_root=_FIXTURE)
    pack = build_pack(ctx, _make_args(agent="engineer", profile="SPRINT_DEEP"))
    assert "logs/orchestrator_log.md" in pack["context_files"]


def test_archive_lookup_narrows_context_to_index_only():
    ctx = RuntimeContext(repo_root=_FIXTURE)
    pack = build_pack(ctx, _make_args(agent="engineer", profile="ARCHIVE_LOOKUP"))
    assert pack["context_files"] == ["runtime/registries/archive_index.json"]


# ---------------------------------------------------------------------------
# Task discovery precedence
# ---------------------------------------------------------------------------


def test_agent_owner_resolves_primary_task():
    ctx = RuntimeContext(repo_root=_FIXTURE)
    pack = build_pack(ctx, _make_args(agent="engineer"))
    assert pack["primary_task"] is not None
    assert pack["primary_task"]["task_id"] == "TASK-1"
    assert pack["primary_task"]["owner_agent"] == "engineer"


def test_explicit_task_id_overrides_agent_owner():
    ctx = RuntimeContext(repo_root=_FIXTURE)
    pack = build_pack(ctx, _make_args(agent="engineer", task_id="TASK-3"))
    # Explicit TASK-3 ranks first; TASK-1 (engineer-owned) is the secondary.
    assert pack["primary_task"]["task_id"] == "TASK-3"


def test_issue_id_resolves_task_via_blocker_link():
    ctx = RuntimeContext(repo_root=_FIXTURE)
    pack = build_pack(ctx, _make_args(issue_id="BLOCK-1"))
    assert pack["primary_task"] is not None
    assert pack["primary_task"]["task_id"] == "TASK-2"


def test_unknown_agent_returns_null_primary():
    ctx = RuntimeContext(repo_root=_FIXTURE)
    pack = build_pack(ctx, _make_args(agent="nonexistent_agent"))
    assert pack["primary_task"] is None
    assert pack["confidence"] == "empty"


# ---------------------------------------------------------------------------
# Confidence scoring
# ---------------------------------------------------------------------------


def test_confidence_high_on_explicit_task_id():
    assert confidence_level({"task_id": "T-1"}, [], "T-1") == "high"


def test_confidence_high_on_single_candidate():
    assert confidence_level({"task_id": "T-1"}, [], None) == "high"


def test_confidence_medium_on_two_candidates():
    assert confidence_level({"task_id": "T-1"}, [{"task_id": "T-2"}], None) == "medium"


def test_confidence_low_on_many_candidates():
    secondaries = [{"task_id": f"T-{i}"} for i in range(4)]
    assert confidence_level({"task_id": "T-0"}, secondaries, None) == "low"


def test_confidence_empty_on_no_candidates():
    assert confidence_level(None, [], None) == "empty"


# ---------------------------------------------------------------------------
# Task reset warning
# ---------------------------------------------------------------------------


def test_task_reset_warning_triggers_on_many_secondaries():
    primary = {"task_id": "T-1"}
    secondaries = [{"task_id": f"T-{i}"} for i in range(3)]
    warning = task_reset_warning(primary, secondaries)
    assert warning is not None
    assert "T-1" in warning


def test_task_reset_warning_silent_when_confident():
    assert task_reset_warning({"task_id": "T-1"}, []) is None


# ---------------------------------------------------------------------------
# Suggested next-step heuristic
# ---------------------------------------------------------------------------


def test_suggest_next_step_prompts_when_no_primary():
    msg = suggest_next_step(None, [], None)
    assert "sprint board" in msg.lower()


def test_suggest_next_step_prioritises_open_blockers():
    primary = {"task_id": "T-1", "status": "in_progress"}
    blockers = [{"blocker_id": "B-1"}]
    msg = suggest_next_step(primary, blockers, None)
    assert "blocker" in msg.lower()
    assert "B-1" in msg


def test_suggest_next_step_runs_validation_when_pending():
    primary = {"task_id": "T-1", "status": "validation_pending"}
    msg = suggest_next_step(primary, [], None)
    assert "validation" in msg.lower()


def test_suggest_next_step_picks_up_latest_handoff():
    primary = {"task_id": "T-1", "status": "in_progress"}
    handoff = {"handoff_id": "H-9"}
    msg = suggest_next_step(primary, [], handoff)
    assert "H-9" in msg
    assert "handoff" in msg.lower()


# ---------------------------------------------------------------------------
# Helper unit tests
# ---------------------------------------------------------------------------


def test_sort_candidates_prefers_sprint_window_ids():
    tasks = [
        {"task_id": "TASK-3"},
        {"task_id": "TASK-1"},
        {"task_id": "TASK-2"},
    ]
    sorted_tasks = sort_candidates(tasks, ["TASK-2"])
    assert sorted_tasks[0]["task_id"] == "TASK-2"


def test_latest_handoff_for_task_picks_newest():
    handoffs = [
        {"handoff_id": "H-1", "file_path": "logs/handoffs/TASK-1_old.md",
         "created_at": "2026-05-01T00:00:00Z"},
        {"handoff_id": "H-2", "file_path": "logs/handoffs/TASK-1_new.md",
         "created_at": "2026-05-05T00:00:00Z"},
    ]
    result = latest_handoff_for_task(handoffs, "TASK-1")
    assert result["handoff_id"] == "H-2"


# ---------------------------------------------------------------------------
# CLI contract
# ---------------------------------------------------------------------------


def test_cli_requires_at_least_one_selector():
    cmd = [sys.executable, str(_PACK_SCRIPT)]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert result.returncode != 0
    assert "required" in (result.stderr + result.stdout).lower()


def test_cli_emits_valid_json_on_fixture():
    cmd = [
        sys.executable,
        str(_PACK_SCRIPT),
        "--repo-root",
        str(_FIXTURE),
        "--agent",
        "engineer",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["primary_task"]["task_id"] == "TASK-1"
