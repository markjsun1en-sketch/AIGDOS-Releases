"""test_host_profile_schema.py — v4.90 Batch 9 Step 9.1.

Self-validation tests for schemas/adoption/host_profile.schema.json:
  1. The schema document is itself a valid JSON Schema draft-07 doc.
  2. A minimal happy-path instance validates.
  3. An unknown primary_host enum value is rejected.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = REPO_ROOT / "schemas" / "adoption" / "host_profile.schema.json"


def _load_schema() -> dict:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def _minimal_instance() -> dict:
    return {
        "schema_version": "1.0.0",
        "primary_host": "claude_code",
    }


def test_host_profile_schema_is_valid_jsonschema():
    schema = _load_schema()
    jsonschema.Draft7Validator.check_schema(schema)


def test_minimal_host_profile_validates():
    schema = _load_schema()
    jsonschema.validate(instance=_minimal_instance(), schema=schema)


def test_unknown_primary_host_rejected():
    schema = _load_schema()
    instance = _minimal_instance()
    instance["primary_host"] = "totally_invented_host"
    with pytest.raises(jsonschema.exceptions.ValidationError):
        jsonschema.validate(instance=instance, schema=schema)
