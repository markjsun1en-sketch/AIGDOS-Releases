"""test_capability_adoption_state_schema.py — v4.90 Batch 2.5 Module B.

Self-validation for schemas/protocol/capability_adoption_state.schema.json
after its Batch 2.5 tightening:

1. Draft-07 meta-validation (the schema is itself a valid JSON Schema).
2. Minimal happy-path (not_present state) validates.
3. adoption_status=blocked WITHOUT blocked_reason → rejected.
4. adoption_status=verified WITHOUT verification_evidence_refs → rejected.
5. adoption_status=verified WITH empty verification_evidence_refs → rejected.
6. Invalid transition (verified → adopted, verified is terminal) → rejected.
7. Allowed transition (not_present → detected_legacy) → accepted.
8. capability_id enum lock — unknown id is rejected.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = REPO_ROOT / "schemas" / "protocol" / "capability_adoption_state.schema.json"


def _schema() -> dict:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def _base(status: str = "not_present") -> dict:
    return {
        "schema_version": "1.0.0",
        "capability_id": "01_runtime_core",
        "adoption_status": status,
        "captured_at": "2026-05-11T10:00:00Z",
    }


def test_schema_is_valid_draft_07():
    s = _schema()
    jsonschema.Draft7Validator.check_schema(s)


def test_minimal_not_present_is_valid():
    jsonschema.validate(instance=_base("not_present"), schema=_schema())


def test_blocked_without_reason_rejected():
    inst = _base("blocked")
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=inst, schema=_schema())


def test_verified_without_evidence_rejected():
    inst = _base("verified")
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=inst, schema=_schema())


def test_verified_with_empty_evidence_rejected():
    inst = _base("verified")
    inst["verification_evidence_refs"] = []
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=inst, schema=_schema())


def test_invalid_transition_verified_to_adopted_rejected():
    inst = _base("verified")
    inst["verification_evidence_refs"] = ["evidence/x.yaml"]
    inst["transition_history"] = [{
        "from": "verified",
        "to": "adopted",
        "at": "2026-05-11T10:00:00Z",
    }]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=inst, schema=_schema())


def test_allowed_transition_accepted():
    inst = _base("detected_legacy")
    inst["transition_history"] = [{
        "from": "not_present",
        "to": "detected_legacy",
        "at": "2026-05-11T10:00:00Z",
    }]
    jsonschema.validate(instance=inst, schema=_schema())


def test_unknown_capability_id_rejected():
    inst = _base()
    inst["capability_id"] = "99_made_up"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=inst, schema=_schema())
