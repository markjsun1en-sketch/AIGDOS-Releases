"""test_init_stage_aliases.py — v4.90.9 game-dev phase split.

v4.90.9 Batch 14.16 closes the "stage vocabulary mismatch" gap:
the project lifecycle stage (incubation/alpha/beta/...) is the
v4.82 canonical enum and stays unchanged, while the v4.90.9
game-dev phase (prototype/mvp/vertical_slice/...) lives in a new
required field. The init CLI auto-derives a sensible default for
game_dev_phase from --stage when the explicit flag is omitted, so
every pre-v4.90.9 caller keeps working.

This suite covers six contracts:

    1. Explicit happy path: --stage beta + --game-dev-phase mvp
       writes both fields verbatim into 02_project_profile.yaml.

    2. Default derivation: --stage beta (no --game-dev-phase)
       fills game_dev_phase=mvp via DEFAULT_PHASE_FOR_STAGE.

    3. Cross-stage coverage: spot-check three other stages
       (incubation→prototype, release_candidate→vertical_slice,
       maintenance→post_launch) so the mapping table cannot
       drift silently.

    4. Bad --game-dev-phase still EXIT_INPUT_MISSING (4) — the
       new field has the same gating as --stage.

    5. Generated yaml must validate against project_profile 1.1.0
       (game_dev_phase required, enum-bound).

    6. Schema_version literal in the emitted yaml is "1.1.0"
       (sentinel against silent template drift after the patch).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

PKG_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = PKG_ROOT / "scripts" / "adoption" / "init_project_runtime.py"
SCHEMA_PATH = PKG_ROOT / "schemas" / "adoption" / "project_profile.schema.json"


def _run(*args: str) -> tuple[int, str, str]:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(PKG_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True, text=True, env=env, timeout=30,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _base_args(out: Path) -> list[str]:
    return [
        "--out", str(out),
        "--project-id", "acme_demo",
        "--project-name", "Acme Demo",
        "--primary-host", "claude_code",
    ]


def _load_yaml(path: Path) -> dict:
    sys.path.insert(0, str(PKG_ROOT))
    from scripts.governance._yaml_subset import parse_yaml_text
    return parse_yaml_text(path.read_text(encoding="utf-8"))


# --------------------------------------------------------------------------
# 1. Explicit happy path
# --------------------------------------------------------------------------


def test_explicit_stage_and_phase_written_verbatim(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    code, _, stderr = _run(
        *_base_args(out), "--stage", "beta", "--game-dev-phase", "mvp",
    )
    assert code == 0, stderr
    profile = _load_yaml(out / "02_project_profile.yaml")
    assert profile["stage"] == "beta"
    assert profile["game_dev_phase"] == "mvp"


# --------------------------------------------------------------------------
# 2. Default derivation
# --------------------------------------------------------------------------


def test_phase_derives_from_stage_when_omitted(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    code, _, stderr = _run(*_base_args(out), "--stage", "beta")
    assert code == 0, stderr
    profile = _load_yaml(out / "02_project_profile.yaml")
    assert profile["stage"] == "beta"
    # beta → mvp per DEFAULT_PHASE_FOR_STAGE.
    assert profile["game_dev_phase"] == "mvp"


# --------------------------------------------------------------------------
# 3. Cross-stage coverage of the derivation map
# --------------------------------------------------------------------------


@pytest.mark.parametrize("stage,expected_phase", [
    ("incubation",        "prototype"),
    ("release_candidate", "vertical_slice"),
    ("maintenance",       "post_launch"),
])
def test_phase_derivation_covers_industry_terms(
    tmp_path: Path, stage: str, expected_phase: str
):
    out = tmp_path / f".ai_dev_os_{stage}"
    code, _, stderr = _run(*_base_args(out), "--stage", stage)
    assert code == 0, stderr
    profile = _load_yaml(out / "02_project_profile.yaml")
    assert profile["stage"] == stage
    assert profile["game_dev_phase"] == expected_phase


# --------------------------------------------------------------------------
# 4. Bad --game-dev-phase rejected
# --------------------------------------------------------------------------


def test_bad_game_dev_phase_rejected(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    code, _, stderr = _run(
        *_base_args(out), "--stage", "beta", "--game-dev-phase", "supernova",
    )
    assert code == 4
    assert "game-dev-phase" in stderr.lower() or "game_dev_phase" in stderr.lower()
    assert not out.exists()


# --------------------------------------------------------------------------
# 5. Generated yaml validates against schema 1.1.0
# --------------------------------------------------------------------------


def test_generated_yaml_validates_against_v1_1_0_schema(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    code, _, stderr = _run(*_base_args(out), "--stage", "alpha")
    assert code == 0, stderr
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    instance = _load_yaml(out / "02_project_profile.yaml")
    jsonschema.validate(instance=instance, schema=schema)
    assert instance["schema_version"] == "1.1.0"


# --------------------------------------------------------------------------
# 6. Sentinel: schema_version literal in emitted yaml
# --------------------------------------------------------------------------


def test_emitted_schema_version_literal(tmp_path: Path):
    """Lock the on-disk literal so a future template edit cannot bump
    schema_version without updating the schema file in lockstep."""
    out = tmp_path / ".ai_dev_os"
    code, _, _ = _run(*_base_args(out), "--stage", "production")
    assert code == 0
    text = (out / "02_project_profile.yaml").read_text(encoding="utf-8")
    assert 'schema_version: "1.1.0"' in text
    assert "game_dev_phase:" in text
