"""test_project_profile_schema.py — v4.90 Batch 9 Step 9.1.

Self-validation tests for schemas/adoption/project_profile.schema.json:
  1. The schema document is itself a valid JSON Schema draft-07 doc.
  2. A minimal happy-path instance validates (with engine + tags).
  3. project_id pattern enforcement (must match ^[a-z0-9_-]+$).
  4. v4.90.9: game_dev_phase is required and enum-bound.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = REPO_ROOT / "schemas" / "adoption" / "project_profile.schema.json"


def _load_schema() -> dict:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def _minimal_instance() -> dict:
    return {
        "schema_version": "1.1.0",
        "project_id": "acme_demo",
        "name": "Acme Demo",
        "stage": "alpha",
        "game_dev_phase": "alpha_build",
    }


def test_project_profile_schema_is_valid_jsonschema():
    schema = _load_schema()
    jsonschema.Draft7Validator.check_schema(schema)


def test_full_project_profile_validates():
    schema = _load_schema()
    instance = _minimal_instance()
    instance["engine"] = {"name": "godot", "version": "4.4"}
    instance["tags"] = ["game", "mobile"]
    jsonschema.validate(instance=instance, schema=schema)


def test_uppercase_project_id_rejected():
    schema = _load_schema()
    instance = _minimal_instance()
    instance["project_id"] = "Acme-Demo"  # contains uppercase A — pattern violation
    with pytest.raises(jsonschema.exceptions.ValidationError):
        jsonschema.validate(instance=instance, schema=schema)


def test_game_dev_phase_required_v4_90_9():
    """v4.90.9: game_dev_phase must be present (required field)."""
    schema = _load_schema()
    instance = _minimal_instance()
    del instance["game_dev_phase"]
    with pytest.raises(jsonschema.exceptions.ValidationError):
        jsonschema.validate(instance=instance, schema=schema)


def test_game_dev_phase_enum_enforced():
    """v4.90.9: only the 7 enum values are accepted."""
    schema = _load_schema()
    instance = _minimal_instance()
    instance["game_dev_phase"] = "Production"  # capitalised — not in enum
    with pytest.raises(jsonschema.exceptions.ValidationError):
        jsonschema.validate(instance=instance, schema=schema)


def test_schema_version_locked_to_1_1_0():
    """Sentinel: schema_version is a const of 1.1.0 after the v4.90.9
    patch. If this test fails, the schema was bumped without updating
    the cross-cutting wave-2 promote test or USER_GUIDE narrative."""
    schema = _load_schema()
    assert schema["properties"]["schema_version"]["const"] == "1.1.0"
