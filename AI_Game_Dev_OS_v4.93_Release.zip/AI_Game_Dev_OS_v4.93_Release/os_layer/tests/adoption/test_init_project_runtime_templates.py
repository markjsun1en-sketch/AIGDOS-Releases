"""Tests for external template loading — v4.90 Batch 9 Step 9.3.

Covers the loader contract added on top of the Step 9.2 scaffold:
  1. External template at templates/project_runtime/ is preferred over
     the inline fallback (verified by patching TEMPLATE_DIR and emitting
     a sentinel string).
  2. Missing external template falls back to the inline string (no
     crash, scaffold still works).
  3. Unknown placeholder tokens in a template are left literal (forward-
     compatible behaviour — the substitute() helper does not raise).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = PKG_ROOT / "scripts" / "adoption" / "init_project_runtime.py"


def _run(*args: str) -> tuple[int, str, str]:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(PKG_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True,
        text=True,
        env=env,
        timeout=30,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _ok_args(out_dir: Path) -> list[str]:
    return [
        "--out", str(out_dir),
        "--project-id", "acme_demo",
        "--project-name", "Acme Demo",
        "--stage", "alpha",
        "--primary-host", "claude_code",
    ]


# --------------------------------------------------------------------------
# 1. Module-level: external template takes precedence over inline fallback
# --------------------------------------------------------------------------

def test_external_template_preferred_over_inline(monkeypatch, tmp_path: Path):
    """Patch TEMPLATE_DIR to a tmp dir containing a sentinel template and
    verify the rendered output reflects the override."""
    sys.path.insert(0, str(PKG_ROOT))
    from scripts.adoption import init_project_runtime as mod

    fake_dir = tmp_path / "fake_templates"
    fake_dir.mkdir()
    (fake_dir / "03_host_profile.yaml.tmpl").write_text(
        '# SENTINEL EXTERNAL TEMPLATE\nschema_version: "1.0.0"\nprimary_host: {{PRIMARY_HOST}}\n',
        encoding="utf-8",
    )
    monkeypatch.setattr(mod, "TEMPLATE_DIR", fake_dir)

    import argparse
    ns = argparse.Namespace(
        primary_host="cursor",
        project_id="x", project_name="x", stage="alpha",
        legacy_version="4.82", target_version="4.90",
    )
    rendered = mod._render_host_profile(ns)
    assert "SENTINEL EXTERNAL TEMPLATE" in rendered
    assert "primary_host: cursor" in rendered


# --------------------------------------------------------------------------
# 2. Missing external template -> inline fallback still works
# --------------------------------------------------------------------------

def test_missing_external_template_falls_back_to_inline(monkeypatch, tmp_path: Path):
    sys.path.insert(0, str(PKG_ROOT))
    from scripts.adoption import init_project_runtime as mod

    empty_dir = tmp_path / "no_templates_here"
    empty_dir.mkdir()
    monkeypatch.setattr(mod, "TEMPLATE_DIR", empty_dir)

    import argparse
    ns = argparse.Namespace(
        primary_host="claude_code",
        project_id="x", project_name="x", stage="alpha",
        legacy_version="4.82", target_version="4.90",
    )
    rendered = mod._render_host_profile(ns)
    # Inline fallback contains the same shape; just confirm output is
    # non-empty and contains the substituted primary_host.
    assert "primary_host: claude_code" in rendered
    assert rendered.strip() != ""


# --------------------------------------------------------------------------
# 3. Unknown placeholder tokens are left literal
# --------------------------------------------------------------------------

def test_unknown_placeholder_left_literal(monkeypatch, tmp_path: Path):
    sys.path.insert(0, str(PKG_ROOT))
    from scripts.adoption import init_project_runtime as mod

    fake_dir = tmp_path / "fake_templates"
    fake_dir.mkdir()
    (fake_dir / "03_host_profile.yaml.tmpl").write_text(
        '# Template with unknown token {{INVENTED_TOKEN}}\nprimary_host: {{PRIMARY_HOST}}\n',
        encoding="utf-8",
    )
    monkeypatch.setattr(mod, "TEMPLATE_DIR", fake_dir)

    import argparse
    ns = argparse.Namespace(
        primary_host="codex",
        project_id="x", project_name="x", stage="alpha",
        legacy_version="4.82", target_version="4.90",
    )
    rendered = mod._render_host_profile(ns)
    assert "{{INVENTED_TOKEN}}" in rendered  # left literal
    assert "primary_host: codex" in rendered  # known token still substituted
