"""test_run_mock_harness_workbuddy_private.py

v4.90 Batch 5.5 Step 5.5.4 — end-to-end fixture test for the
``--fixture workbuddy_private`` preset of run_mock_harness.py.

The preset plants 11 of the 14 capability rows (01-06 + 09-13) and
leaves rows 07, 08, 14 absent. This mirrors the
host_profile=workbuddy_private adoption shape captured in
docs/14_state_surface_governance/STATE_SURFACE_MIGRATION_CASE_WORKBUDDY_PRIVATE.md
(5 starter files + 4 runtime docs cover rows 01-06 + 09-13; rows 07
and 08 lack starter mapping; row 14 self_evolution_proposal needs an
EP-approved gate).

5 cases:
1. CLI --help advertises ``workbuddy_private`` in the choices.
2. Subprocess run with default JSON out → exit 0, score = 78.6,
   phase = rollout, summary.detected_count = 11, plants=11 in stderr.
3. Findings absent set is exactly {07_ltm_capture_consult,
   08_failure_fix_memory, 14_self_evolution_proposal}.
4. Findings present set includes the Batch 5 D1-promoted rows
   09_agent_library and 10_pack_activation (this is what makes the
   workbuddy_private preset distinct from ``partial`` which slices
   the first 7 scored rows and would NOT include 09 or 10).
5. Findings present set includes 13_adapter_bridge — another row
   beyond the partial-7-prefix that the workbuddy_private preset
   exercises end-to-end.

Layer 1 (OS Spec) test file: ``workbuddy`` is a registered host_profile
identifier in scripts/migration/detect_project_protocol.py KNOWN_HOSTS
and not a project name. The Layer 2 case file referenced above is
exempt from project-name lint via the
STATE_SURFACE_MIGRATION_CASE_*.md regex.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
HARNESS = PKG_ROOT / "scripts" / "adoption" / "run_mock_harness.py"

EXPECTED_PRESENT = {
    "01_runtime_core",
    "02_project_profile",
    "03_host_profile",
    "04_handoff_registry",
    "05_validation_evidence",
    "06_context_governance",
    "09_agent_library",
    "10_pack_activation",
    "11_profile_parity",
    "12_dashboard_exports",
    "13_adapter_bridge",
}
EXPECTED_ABSENT = {
    "07_ltm_capture_consult",
    "08_failure_fix_memory",
    "14_self_evolution_proposal",
}


def _run(*args) -> tuple[int, str, str]:
    proc = subprocess.run(
        [sys.executable, str(HARNESS), *args],
        capture_output=True, text=True, timeout=45,
    )
    return proc.returncode, proc.stdout, proc.stderr


@pytest.fixture(scope="module")
def report(tmp_path_factory) -> dict:
    """Run the workbuddy_private fixture once and share the report."""
    out = tmp_path_factory.mktemp("wbp") / "report.json"
    rc, _, stderr = _run(
        "--fixture", "workbuddy_private",
        "--project-id", "mock_demo",
        "--out", str(out),
    )
    assert rc == 0, stderr
    assert "plants=11" in stderr, stderr
    return json.loads(out.read_text(encoding="utf-8"))


def test_help_lists_workbuddy_private_choice():
    rc, out, _ = _run("--help")
    assert rc == 0
    # argparse renders choices in --fixture help line
    assert "workbuddy_private" in out


def test_workbuddy_private_score_and_phase(report):
    # 11/14 * 100 = 78.5714... → rounded to 78.6
    assert report["score"] == 78.6
    assert report["adoption_phase"] == "rollout"
    assert report["summary"]["detected_count"] == 11
    assert report["summary"]["total_scored"] == 14


def test_workbuddy_private_absent_rows_exact(report):
    findings = report.get("findings") or []
    assert findings, "report must include findings[]"
    by_id = {f["capability_id"]: f for f in findings}
    actual_absent = {
        cid for cid, f in by_id.items()
        if f.get("status") in ("absent", "missing", "not_present")
    }
    assert actual_absent == EXPECTED_ABSENT, (
        f"absent set drift — expected {sorted(EXPECTED_ABSENT)}, "
        f"got {sorted(actual_absent)}"
    )


def test_workbuddy_private_includes_promoted_rows_09_and_10(report):
    """Rows 09 and 10 are Batch 5 D1-promoted scored rows.

    The ``partial`` preset (first 7 scored) ends at row 07 and does
    NOT exercise 09/10. The workbuddy_private preset MUST include
    them — this is the central architectural promise of the Layer 2
    case (14-agent roster maps onto the 5 cluster seed packs).
    """
    findings = report.get("findings") or []
    by_id = {f["capability_id"]: f for f in findings}
    for cap_id in ("09_agent_library", "10_pack_activation"):
        assert cap_id in by_id, f"row {cap_id} missing from findings"
        status = by_id[cap_id].get("status")
        assert status in ("present", "detected", "found"), (
            f"row {cap_id} expected present/detected/found, got {status!r}"
        )


def test_workbuddy_private_includes_adapter_bridge_row_13(report):
    """Row 13_adapter_bridge sits beyond the partial-7 prefix and is
    a workbuddy_private-specific signal that the preset exercises the
    full 11-row plant list, not just the first N rows."""
    findings = report.get("findings") or []
    by_id = {f["capability_id"]: f for f in findings}
    assert "13_adapter_bridge" in by_id
    status = by_id["13_adapter_bridge"].get("status")
    assert status in ("present", "detected", "found"), (
        f"row 13_adapter_bridge expected present, got {status!r}"
    )
