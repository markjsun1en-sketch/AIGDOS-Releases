"""test_e2e_scan_validate.py — v4.90 Batch 2 Step 2.5.

End-to-end: scan_legacy_project.py → validate_adoption.py → adoption_report

3 cases:
1. Fresh empty project → score == 0.0 / phase == discovery
2. Partial project — 7 of 14 scored capabilities have at least one
   required_path planted → score == 50.0 / phase == discovery
3. Full project — all 14 scored capabilities have at least one
   required_path planted → score == 100.0 / phase == consolidation

Batch 6 Step 6.7 promoted row 14 (self_evolution_proposal) from
deprecated to requires_adapter (denominator went 11 -> 12). Batch 5
Step 5.6 then promoted rows 09 (agent_library) and 10
(pack_activation), driving the denominator from 12 to 14. The
deprecated set is empty after Batch 5; the informational[] block in
adoption_report is nullable optional (D1a=C) and omitted by the
validator when empty.

The test does NOT depend on any specific fingerprint internals; it
re-parses the matrix to derive each capability's first required_path
and uses that to plant evidence. This keeps the test resilient to
matrix tweaks.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
SCAN = PKG_ROOT / "scripts" / "migration" / "scan_legacy_project.py"
VALIDATE = PKG_ROOT / "scripts" / "adoption" / "validate_adoption.py"
MATRIX_MD = PKG_ROOT / "docs" / "13_migration" / "CAPABILITY_COMPATIBILITY_MATRIX.md"

# Make scripts/migration importable so we can re-use the matrix parser
# inside the test (purely as a fixture helper).
sys.path.insert(0, str(PKG_ROOT / "scripts" / "migration"))
from _matrix_parser import parse_capability_blocks  # noqa: E402


def _matrix_split() -> tuple[list[dict], list[dict]]:
    blocks = parse_capability_blocks(MATRIX_MD)
    scored, deprecated = [], []
    for b in blocks:
        if b.get("compatibility_status") == "deprecated":
            deprecated.append(b)
        else:
            scored.append(b)
    return scored, deprecated


def _plant_capability(project_root: Path, block: dict) -> None:
    """Create the FIRST required_path of `block` under project_root.

    If the path ends with '/' or has no extension we treat as directory;
    else we touch a single file with empty content. Glob patterns are
    expanded to a literal candidate by replacing `*` and `?` with `x`.
    """
    fp = block.get("fingerprint") or {}
    required = fp.get("required_paths") or []
    if not required:
        return
    rel = required[0]
    if not isinstance(rel, str) or not rel:
        return
    rel = rel.replace("*", "x").replace("?", "x")
    target = project_root / rel
    if rel.endswith("/"):
        target.mkdir(parents=True, exist_ok=True)
        # plant a placeholder file so glob('exports/') matches a real dir
        (target / "_placeholder").write_text("", encoding="utf-8")
        return
    # Could be either dir or file; check if extension
    if "." not in target.name:
        target.mkdir(parents=True, exist_ok=True)
        (target / "_placeholder").write_text("", encoding="utf-8")
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("", encoding="utf-8")


def _run_pipeline(project_root: Path, tmp_path: Path) -> dict:
    scan_out = tmp_path / "scan.json"
    rc1 = subprocess.run(
        [sys.executable, str(SCAN), str(project_root),
         "--matrix", str(MATRIX_MD),
         "--project-id", "demo",
         "--out", str(scan_out)],
        capture_output=True, text=True, timeout=30,
    )
    assert rc1.returncode == 0, f"scan exit {rc1.returncode}\n{rc1.stderr}"
    rc2 = subprocess.run(
        [sys.executable, str(VALIDATE),
         "--scan-input", str(scan_out),
         "--matrix-path", str(MATRIX_MD),
         "--project-id", "demo"],
        capture_output=True, text=True, timeout=30,
    )
    assert rc2.returncode == 0, f"validate exit {rc2.returncode}\n{rc2.stderr}"
    return json.loads(rc2.stdout)


# ---------- 1: fresh empty project ----------------------------------------

def test_e2e_fresh_empty_project(tmp_path):
    proj = tmp_path / "legacy_project"
    proj.mkdir()
    report = _run_pipeline(proj, tmp_path)
    assert report["score"] == 0.0
    assert report["adoption_phase"] == "discovery"
    assert report["summary"]["detected_count"] == 0
    assert report["summary"]["absent_count"] == 14
    assert len(report["findings"]) == 14
    # informational is empty (and omitted) after Batch 5 (D1a=C).
    assert report.get("informational", []) == []


# ---------- 2: partial — 7 / 14 scored detected ---------------------------

def test_e2e_partial_seven_of_fourteen(tmp_path):
    proj = tmp_path / "legacy_project"
    proj.mkdir()
    scored, _ = _matrix_split()
    # Plant 7 of the 14 scored capabilities.
    for b in scored[:7]:
        _plant_capability(proj, b)
    report = _run_pipeline(proj, tmp_path)
    # Detection of glob-only paths is sensitive to the matrix's specific
    # required_paths; we assert the detected_count is exactly 7 (since
    # every planted path satisfies at least the glob check).
    assert report["summary"]["detected_count"] == 7, report["summary"]
    assert report["score"] == 50.0
    assert report["adoption_phase"] == "discovery"


# ---------- 3: full — 14 / 14 scored detected -----------------------------

def test_e2e_full_fourteen_of_fourteen(tmp_path):
    proj = tmp_path / "legacy_project"
    proj.mkdir()
    scored, _ = _matrix_split()
    for b in scored:
        _plant_capability(proj, b)
    report = _run_pipeline(proj, tmp_path)
    assert report["summary"]["detected_count"] == 14, report["summary"]
    assert report["score"] == 100.0
    assert report["adoption_phase"] == "consolidation"
