"""test_active_packs_schema.py — v4.90 Batch 9 Step 9.1.

Self-validation tests for schemas/adoption/active_packs.schema.json:
  1. The schema document is itself a valid JSON Schema draft-07 doc.
  2. An empty active_packs list validates (required field is the
     array; it may be empty).
  3. pack_id pattern enforcement (must match ^ap_[0-9]{4}_[0-9]{3}$).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = REPO_ROOT / "schemas" / "adoption" / "active_packs.schema.json"


def _load_schema() -> dict:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def test_active_packs_schema_is_valid_jsonschema():
    schema = _load_schema()
    jsonschema.Draft7Validator.check_schema(schema)


def test_empty_active_packs_list_validates():
    schema = _load_schema()
    instance = {
        "schema_version": "1.0.0",
        "active_packs": [],
    }
    jsonschema.validate(instance=instance, schema=schema)


def test_bad_pack_id_pattern_rejected():
    schema = _load_schema()
    instance = {
        "schema_version": "1.0.0",
        "active_packs": [
            {
                "pack_id": "pack-without-prefix",  # missing ap_ prefix
                "activation_date": "2026-05-13",
            }
        ],
    }
    with pytest.raises(jsonschema.exceptions.ValidationError):
        jsonschema.validate(instance=instance, schema=schema)
