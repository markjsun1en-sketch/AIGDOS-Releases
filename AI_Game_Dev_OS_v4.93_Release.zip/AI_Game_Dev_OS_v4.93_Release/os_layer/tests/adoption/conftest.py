"""Shared fixtures for tests/adoption/ — v4.90 Batch 2 + Batch 2.5.

Layer 1 (OS Spec). No project names. All fixture project IDs use
generic placeholders such as ``acme_demo`` / ``sample_project``.

Batch 2.5 additions (Module A — Mock Legacy Project Harness):
- ``MOCK_BASELINE_DIR`` — path constant pointing to the static
  `tests/fixtures/mock_legacy_project_baseline/` tree.
- ``make_legacy_project_from_baseline`` fixture — clone the baseline
  into tmp_path, optionally plant capability evidence on top.
- ``plant_capability`` helper — canonical plant primitive reused by
  the harness and the e2e test.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS_ADOPTION = REPO_ROOT / "scripts" / "adoption"
SCRIPTS_MIGRATION = REPO_ROOT / "scripts" / "migration"
MOCK_BASELINE_DIR = REPO_ROOT / "tests" / "fixtures" / "mock_legacy_project_baseline"


@dataclass
class ScriptResult:
    exit_code: int
    stdout: str
    stderr: str

    def expect(self, code: int) -> "ScriptResult":
        assert self.exit_code == code, (
            f"expected exit {code}, got {self.exit_code}\n"
            f"stdout: {self.stdout}\nstderr: {self.stderr}"
        )
        return self


def _run(script_path: Path, *args: str, cwd: Path | None = None) -> ScriptResult:
    cmd = [sys.executable, str(script_path), *args]
    env = dict(os.environ)
    env["PYTHONPATH"] = str(REPO_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.run(
        cmd, cwd=str(cwd) if cwd else None,
        env=env, capture_output=True, text=True, timeout=30,
    )
    return ScriptResult(proc.returncode, proc.stdout, proc.stderr)


@pytest.fixture
def run_adoption_script():
    """Subprocess-launch scripts/adoption/<name>.py."""
    def _r(script_name: str, *args: str, cwd: Path | None = None) -> ScriptResult:
        script = SCRIPTS_ADOPTION / script_name
        assert script.exists(), f"script not found: {script}"
        return _run(script, *args, cwd=cwd)
    return _r


@pytest.fixture
def run_migration_script():
    """Subprocess-launch scripts/migration/<name>.py."""
    def _r(script_name: str, *args: str, cwd: Path | None = None) -> ScriptResult:
        script = SCRIPTS_MIGRATION / script_name
        assert script.exists(), f"script not found: {script}"
        return _run(script, *args, cwd=cwd)
    return _r


# ---------------------------------------------------------------------------
# Batch 2.5 — Mock Legacy Project Harness helpers
# ---------------------------------------------------------------------------

def plant_capability(project_root: Path, block: dict) -> None:
    """Plant the FIRST required_path of a capability block under project_root.

    Canonical primitive for tests and the harness CLI. Rules:
    - A glob-style path (contains * or ?) is rewritten with 'x' in place.
    - A trailing '/' or a segment without a dot creates a directory and
      drops a `_placeholder` file so glob('dir/') matches a real tree.
    - A path with an extension creates an empty file; parent dirs are
      created on demand.

    Idempotent: planting the same capability twice is a no-op on top of
    the first plant (mkdir with exist_ok=True, write_text overwrites
    with identical bytes).
    """
    fp = block.get("fingerprint") or {}
    required = fp.get("required_paths") or []
    if not required:
        return
    rel = required[0]
    if not isinstance(rel, str) or not rel:
        return
    rel = rel.replace("*", "x").replace("?", "x")
    target = project_root / rel
    if rel.endswith("/"):
        target.mkdir(parents=True, exist_ok=True)
        (target / "_placeholder").write_text("", encoding="utf-8")
        return
    if "." not in target.name:
        target.mkdir(parents=True, exist_ok=True)
        (target / "_placeholder").write_text("", encoding="utf-8")
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            target.write_text("", encoding="utf-8")


@pytest.fixture
def make_legacy_project_from_baseline(tmp_path):
    """Clone the static mock_legacy_project_baseline/ into tmp_path.

    Usage::

        def test_x(make_legacy_project_from_baseline, matrix_blocks):
            proj = make_legacy_project_from_baseline()
            # → proj is a Path inside tmp_path with the baseline contents
            for b in matrix_blocks[:3]:
                plant_capability(proj, b)

    Optional args:
    - ``name``: subdirectory name inside tmp_path (default ``"legacy_project"``).
    - ``plant_blocks``: list of capability blocks to plant after clone.
    """
    def _make(name: str = "legacy_project", plant_blocks=None) -> Path:
        assert MOCK_BASELINE_DIR.exists(), (
            f"baseline fixture missing: {MOCK_BASELINE_DIR}"
        )
        dest = tmp_path / name
        shutil.copytree(MOCK_BASELINE_DIR, dest)
        # Strip .gitkeep markers — the scan should see real empty dirs,
        # not an artifact of the git tracking.
        for g in list(dest.rglob(".gitkeep")):
            try:
                g.unlink()
            except OSError:
                pass
        for b in (plant_blocks or []):
            plant_capability(dest, b)
        return dest
    return _make


@pytest.fixture
def matrix_blocks():
    """Lazy-load the 14 capability blocks from the v4.90 matrix."""
    sys.path.insert(0, str(SCRIPTS_MIGRATION))
    from _matrix_parser import parse_capability_blocks  # noqa: E402

    return parse_capability_blocks(
        REPO_ROOT / "docs" / "13_migration" / "CAPABILITY_COMPATIBILITY_MATRIX.md"
    )


@pytest.fixture
def matrix_split(matrix_blocks):
    """Return (scored, deprecated) split of the matrix (11/3 invariant)."""
    scored, deprecated = [], []
    for b in matrix_blocks:
        if b.get("compatibility_status") == "deprecated":
            deprecated.append(b)
        else:
            scored.append(b)
    return scored, deprecated
