"""Tests for scripts/adoption/init_project_runtime.py — v4.90 Batch 9 Step 9.2.

Covers (15):
  1. Happy path: empty out dir produces 10 expected files
  2. Generated 02_project_profile.yaml validates against schema
  3. Generated 03_host_profile.yaml validates against schema
  4. Generated 04_active_packs.yaml validates against schema
  5. Generated 01_project_runtime_protocol.yaml parses and matches CLI flags
  6. Generated 05_governance.yaml has state_surface_governance.enabled=true
  7. Generated 06_adoption_state.yaml lists all 14 capability ids
  8. 4 dir READMEs + .gitkeeps land
  9. --dry-run does not write
 10. --force overwrites a non-empty dir
 11. Refusal: non-empty dir without --force exits 1
 12. Bad project-id (uppercase) -> exit 4 usage error
 13. Unknown primary-host -> exit 4 usage error
 14. Unknown stage -> exit 4 usage error
 15. --format json on success emits structured payload

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest


PKG_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = PKG_ROOT / "scripts" / "adoption" / "init_project_runtime.py"


def _run(*args: str) -> tuple[int, str, str]:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(PKG_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True,
        text=True,
        env=env,
        timeout=30,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _ok_args(out_dir: Path, **overrides) -> list[str]:
    defaults = {
        "--out": str(out_dir),
        "--project-id": "acme_demo",
        "--project-name": "Acme Demo",
        "--stage": "alpha",
        "--primary-host": "claude_code",
    }
    defaults.update({f"--{k.replace('_','-')}": v for k, v in overrides.items()})
    args = []
    for k, v in defaults.items():
        args.extend([k, v])
    return args


def _load_yaml(path: Path) -> dict:
    sys.path.insert(0, str(PKG_ROOT))
    from scripts.governance._yaml_subset import parse_yaml_text
    return parse_yaml_text(path.read_text(encoding="utf-8"))


# --------------------------------------------------------------------------
# 1. Happy path
# --------------------------------------------------------------------------

def test_happy_path_writes_expected_files(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    code, _, _ = _run(*_ok_args(out))
    assert code == 0
    yamls = sorted(p.name for p in out.glob("0?_*.yaml"))
    assert yamls == [
        "01_project_runtime_protocol.yaml",
        "02_project_profile.yaml",
        "03_host_profile.yaml",
        "04_active_packs.yaml",
        "05_governance.yaml",
        "06_adoption_state.yaml",
    ]
    for sub in ("ltm", "evidence", "reports", "archive"):
        assert (out / sub / "README.md").exists()
        assert (out / sub / ".gitkeep").exists()


# --------------------------------------------------------------------------
# 2-4. Schema conformance of generated yaml
# --------------------------------------------------------------------------

def test_generated_project_profile_validates(tmp_path: Path):
    jsonschema = pytest.importorskip("jsonschema")
    out = tmp_path / ".ai_dev_os"
    code, _, _ = _run(*_ok_args(out))
    assert code == 0
    schema = json.loads(
        (PKG_ROOT / "schemas/adoption/project_profile.schema.json").read_text()
    )
    instance = _load_yaml(out / "02_project_profile.yaml")
    jsonschema.validate(instance=instance, schema=schema)


def test_generated_host_profile_validates(tmp_path: Path):
    jsonschema = pytest.importorskip("jsonschema")
    out = tmp_path / ".ai_dev_os"
    _run(*_ok_args(out))
    schema = json.loads(
        (PKG_ROOT / "schemas/adoption/host_profile.schema.json").read_text()
    )
    instance = _load_yaml(out / "03_host_profile.yaml")
    jsonschema.validate(instance=instance, schema=schema)


def test_generated_active_packs_validates(tmp_path: Path):
    jsonschema = pytest.importorskip("jsonschema")
    out = tmp_path / ".ai_dev_os"
    _run(*_ok_args(out))
    schema = json.loads(
        (PKG_ROOT / "schemas/adoption/active_packs.schema.json").read_text()
    )
    instance = _load_yaml(out / "04_active_packs.yaml")
    jsonschema.validate(instance=instance, schema=schema)


# --------------------------------------------------------------------------
# 5. Protocol yaml reflects CLI flags
# --------------------------------------------------------------------------

def test_generated_protocol_reflects_cli_flags(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    code, _, _ = _run(
        "--out", str(out),
        "--project-id", "acme_demo",
        "--project-name", "Acme Demo",
        "--stage", "beta",
        "--primary-host", "cursor",
        "--legacy-version", "4.78",
        "--target-version", "4.90",
    )
    assert code == 0
    proto = _load_yaml(out / "01_project_runtime_protocol.yaml")
    inner = proto["project_runtime_protocol"]
    assert inner["legacy_project_version"] == "4.78"
    assert inner["target_protocol_version"] == "4.90"


# --------------------------------------------------------------------------
# 6. governance yaml has enabled flag
# --------------------------------------------------------------------------

def test_generated_governance_enabled(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    _run(*_ok_args(out))
    gov = _load_yaml(out / "05_governance.yaml")
    assert gov["governance"]["state_surface_governance"]["enabled"] is True


# --------------------------------------------------------------------------
# 7. adoption_state lists 14 capabilities
# --------------------------------------------------------------------------

def test_generated_adoption_state_has_14_capabilities(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    _run(*_ok_args(out))
    state = _load_yaml(out / "06_adoption_state.yaml")
    caps = state["capabilities"]
    assert len(caps) == 14
    assert "01_runtime_core" in caps
    assert "14_self_evolution_proposal" in caps
    for v in caps.values():
        assert v["adoption_status"] == "not_present"


# --------------------------------------------------------------------------
# 8. Dir READMEs present (this is already covered by test 1; second-pass
#    asserts content fingerprints to catch silent template drift).
# --------------------------------------------------------------------------

def test_dir_readmes_have_expected_content(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    _run(*_ok_args(out))
    for sub, fingerprint in (
        ("ltm", "Project-side Long-Term Memory"),
        ("evidence", "evidence_ref drop zone"),
        ("reports", "generated runtime reports"),
        ("archive", "sprint close-out archives"),
    ):
        assert fingerprint in (out / sub / "README.md").read_text()


# --------------------------------------------------------------------------
# 9. Dry-run
# --------------------------------------------------------------------------

def test_dry_run_does_not_write(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    code, stdout, _ = _run(*_ok_args(out), "--dry-run")
    assert code == 0
    assert not out.exists()
    assert "DRY-RUN" in stdout or "would" in stdout


# --------------------------------------------------------------------------
# 10. --force overwrites
# --------------------------------------------------------------------------

def test_force_overwrites_non_empty(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    out.mkdir()
    (out / "preexisting.txt").write_text("old content", encoding="utf-8")
    code, _, _ = _run(*_ok_args(out), "--force")
    assert code == 0
    assert (out / "01_project_runtime_protocol.yaml").exists()


# --------------------------------------------------------------------------
# 11. Refusal without --force
# --------------------------------------------------------------------------

def test_refuses_existing_non_empty(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    out.mkdir()
    (out / "preexisting.txt").write_text("old", encoding="utf-8")
    code, _, _ = _run(*_ok_args(out))
    assert code == 1


# --------------------------------------------------------------------------
# 12-14. Usage errors
# --------------------------------------------------------------------------

def test_bad_project_id_rejected(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    code, _, stderr = _run(
        "--out", str(out),
        "--project-id", "Acme-Demo",  # uppercase
        "--project-name", "Acme Demo",
        "--stage", "alpha",
        "--primary-host", "claude_code",
    )
    assert code == 4
    assert "project-id" in stderr.lower() or "project_id" in stderr.lower()
    assert not out.exists()


def test_unknown_primary_host_rejected(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    code, _, stderr = _run(
        "--out", str(out),
        "--project-id", "acme_demo",
        "--project-name", "Acme Demo",
        "--stage", "alpha",
        "--primary-host", "totally_invented",
    )
    assert code == 4
    assert "primary-host" in stderr.lower() or "primary_host" in stderr.lower()


def test_unknown_stage_rejected(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    code, _, stderr = _run(
        "--out", str(out),
        "--project-id", "acme_demo",
        "--project-name", "Acme Demo",
        "--stage", "supernova",
        "--primary-host", "claude_code",
    )
    assert code == 4
    assert "stage" in stderr.lower()


# --------------------------------------------------------------------------
# 15. JSON output mode
# --------------------------------------------------------------------------

def test_json_format_success_payload(tmp_path: Path):
    out = tmp_path / ".ai_dev_os"
    code, stdout, _ = _run(*_ok_args(out), "--format", "json")
    assert code == 0
    payload = json.loads(stdout)
    assert payload["status"] == "scaffolded"
    assert payload["out_dir"].endswith(".ai_dev_os")
    assert "01_project_runtime_protocol.yaml" in payload["written"]
