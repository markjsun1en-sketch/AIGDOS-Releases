"""test_schema_io_chain.py — v4.90 Batch 2.5 Module C.

Verifies the schema-shape guards added to:
- scripts/migration/scan_legacy_project.py (output validated before emit)
- scripts/adoption/validate_adoption.py (input validated on load AND
  output validated before emit)

5 cases:
1. validate_adoption: malformed scan_input (missing 'capabilities') →
   exit 1 VIOLATION with a shape-error message on stderr.
2. validate_adoption: capabilities count mismatch (12 instead of 14
   after Batch 5 — was 12/2 before, now 14/0) → exit 1 VIOLATION.
3. validate_adoption: capability.detection_method outside the allowed
   enum → exit 1 VIOLATION.
4. validate_adoption: happy-path scan input → success, and emitted
   report passes the report shape guard (implicit via exit 0).
5. scan_legacy_project: end-to-end against the mock baseline — output
   is self-consistent with the legacy_scan_result schema (invariants
   checked directly: schema_version, 14 caps, all detection_method
   values valid, 'none' paired with detected=False).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
VALIDATE = PKG_ROOT / "scripts" / "adoption" / "validate_adoption.py"
SCAN = PKG_ROOT / "scripts" / "migration" / "scan_legacy_project.py"
MATRIX_MD = PKG_ROOT / "docs" / "13_migration" / "CAPABILITY_COMPATIBILITY_MATRIX.md"

CAPABILITY_IDS = [
    "01_runtime_core", "02_project_profile", "03_host_profile",
    "04_handoff_registry", "05_validation_evidence", "06_context_governance",
    "07_ltm_capture_consult", "08_failure_fix_memory", "09_agent_library",
    "10_pack_activation", "11_profile_parity", "12_dashboard_exports",
    "13_adapter_bridge", "14_self_evolution_proposal",
]


def _well_formed_scan(overrides: dict | None = None) -> dict:
    caps = [
        {
            "capability_id": cid,
            "detected": False,
            "detection_method": "none",
            "evidence_paths": [],
        }
        for cid in CAPABILITY_IDS
    ]
    base = {
        "schema_version": "1.0.0",
        "project_id": "demo",
        "scanned_at": "2026-05-11T10:00:00Z",
        "source_version": "4.82",
        "target_version": "4.90",
        "matrix_path": "docs/13_migration/CAPABILITY_COMPATIBILITY_MATRIX.md",
        "capabilities": caps,
    }
    if overrides:
        base.update(overrides)
    return base


def _run_validate(scan_path: Path):
    proc = subprocess.run(
        [sys.executable, str(VALIDATE),
         "--scan-input", str(scan_path),
         "--matrix-path", str(MATRIX_MD),
         "--project-id", "demo"],
        capture_output=True, text=True, timeout=20,
    )
    return proc.returncode, proc.stdout, proc.stderr


def test_1_scan_input_missing_capabilities_rejected(tmp_path):
    bad = _well_formed_scan()
    bad.pop("capabilities")
    p = tmp_path / "scan.json"
    p.write_text(json.dumps(bad), encoding="utf-8")
    rc, _, err = _run_validate(p)
    assert rc == 1, err
    assert "shape invalid" in err or "missing" in err


def test_2_scan_input_capability_count_mismatch_rejected(tmp_path):
    bad = _well_formed_scan()
    bad["capabilities"] = bad["capabilities"][:12]  # only 12
    p = tmp_path / "scan.json"
    p.write_text(json.dumps(bad), encoding="utf-8")
    rc, _, err = _run_validate(p)
    assert rc == 1, err


def test_3_scan_input_bad_detection_method_rejected(tmp_path):
    bad = _well_formed_scan()
    bad["capabilities"][0]["detection_method"] = "magic_guess"
    p = tmp_path / "scan.json"
    p.write_text(json.dumps(bad), encoding="utf-8")
    rc, _, err = _run_validate(p)
    assert rc == 1, err
    assert "detection_method" in err or "invalid" in err


def test_4_well_formed_scan_input_passes(tmp_path):
    good = _well_formed_scan()
    p = tmp_path / "scan.json"
    p.write_text(json.dumps(good), encoding="utf-8")
    rc, out, err = _run_validate(p)
    assert rc == 0, err
    report = json.loads(out)
    assert report["score"] == 0.0
    assert report["summary"]["total_scored"] == 14
    assert report["summary"]["deprecated_count"] == 0


def test_5_scan_output_self_consistent(make_legacy_project_from_baseline, tmp_path):
    proj = make_legacy_project_from_baseline()
    scan_path = tmp_path / "scan.json"
    proc = subprocess.run(
        [sys.executable, str(SCAN), str(proj),
         "--matrix", str(MATRIX_MD),
         "--project-id", "demo",
         "--out", str(scan_path)],
        capture_output=True, text=True, timeout=30,
    )
    assert proc.returncode == 0, proc.stderr
    data = json.loads(scan_path.read_text(encoding="utf-8"))
    # Invariants matching legacy_scan_result.schema.json.
    assert data["schema_version"] == "1.0.0"
    assert len(data["capabilities"]) == 14
    allowed = {"glob_exists", "grep_match", "none"}
    for c in data["capabilities"]:
        assert c["detection_method"] in allowed, c
        assert isinstance(c["detected"], bool), c
        if c["detection_method"] == "none":
            assert c["detected"] is False, c
        assert isinstance(c["evidence_paths"], list), c
