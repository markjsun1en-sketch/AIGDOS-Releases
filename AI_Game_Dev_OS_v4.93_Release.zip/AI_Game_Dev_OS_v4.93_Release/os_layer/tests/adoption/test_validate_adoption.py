"""test_validate_adoption.py — v4.90 Batch 2 Step 2.4.

Tests scripts/adoption/validate_adoption.py (GUIDED tier).

10 cases:
1. Unit — score=0.0 (all 14 absent)
2. Unit — score=100.0 (all 14 detected)
3. Unit — score=50.0 (7/14 detected) → discovery
4. Unit — deprecated set is empty after Batch 5 (informational=[],
   key absent / nullable; D1a=C)
5. Integration — happy path, --format json (default), default stdout
6. Integration — happy path, --format yaml; YAML round-trips back to
   the same dict via the bundled _yaml_emit / pyyaml-equivalent parser.
7. Never-raise — matrix path missing → exit 4
8. Never-raise — scan input JSON malformed → exit 1
9. Self-validation — emitted JSON validates against
   schemas/adoption/adoption_report.schema.json (jsonschema importorskip)
10. Layer 1 lint — running scripts/governance/lint_layer_separation.py
    after this batch's edits returns clean.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
VALIDATE = PKG_ROOT / "scripts" / "adoption" / "validate_adoption.py"
SCAN = PKG_ROOT / "scripts" / "migration" / "scan_legacy_project.py"
MATRIX_MD = PKG_ROOT / "docs" / "13_migration" / "CAPABILITY_COMPATIBILITY_MATRIX.md"
LINT = PKG_ROOT / "scripts" / "governance" / "lint_layer_separation.py"
ADOPT_SCHEMA = PKG_ROOT / "schemas" / "adoption" / "adoption_report.schema.json"


# Canonical IDs (from PROJECT_RUNTIME_PROTOCOL.md / matrix order)
CAPABILITY_IDS = [
    "01_runtime_core", "02_project_profile", "03_host_profile",
    "04_handoff_registry", "05_validation_evidence", "06_context_governance",
    "07_ltm_capture_consult", "08_failure_fix_memory", "09_agent_library",
    "10_pack_activation", "11_profile_parity", "12_dashboard_exports",
    "13_adapter_bridge", "14_self_evolution_proposal",
]
DEPRECATED_IDS: set[str] = set()  # empty after Batch 5 (rows 09/10 promoted)
SCORED_IDS = [c for c in CAPABILITY_IDS if c not in DEPRECATED_IDS]
assert len(SCORED_IDS) == 14


def _build_scan(detected_ids: set[str], project_id: str = "demo") -> dict:
    """Construct a synthetic scan_input.json for the 14-capability matrix."""
    caps = []
    for cid in CAPABILITY_IDS:
        is_det = cid in detected_ids
        caps.append({
            "capability_id": cid,
            "detected": is_det,
            "detection_method": "glob_exists" if is_det else "none",
            "evidence_paths": [f"path/{cid}/dummy"] if is_det else [],
        })
    return {
        "schema_version": "1.0.0",
        "project_id": project_id,
        "scanned_at": "2026-05-11T00:00:00Z",
        "source_version": "4.82",
        "target_version": "4.90",
        "matrix_path": "docs/13_migration/CAPABILITY_COMPATIBILITY_MATRIX.md",
        "capabilities": caps,
    }


def _run(args, cwd=None):
    proc = subprocess.run(
        [sys.executable, str(VALIDATE), *args],
        cwd=str(cwd) if cwd else None,
        capture_output=True, text=True, timeout=20,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _write_scan(tmp_path: Path, detected_ids: set[str]) -> Path:
    p = tmp_path / "scan.json"
    p.write_text(json.dumps(_build_scan(detected_ids)), encoding="utf-8")
    return p


def _validate_ok(tmp_path, detected_ids):
    scan = _write_scan(tmp_path, detected_ids)
    rc, out, err = _run([
        "--scan-input", str(scan),
        "--matrix-path", str(MATRIX_MD),
        "--project-id", "demo",
    ])
    assert rc == 0, f"exit {rc}\nstdout: {out}\nstderr: {err}"
    return json.loads(out)


# ---------- 1-3: scoring formula ------------------------------------------

def test_1_score_zero_all_absent(tmp_path):
    report = _validate_ok(tmp_path, set())
    assert report["score"] == 0.0
    assert report["adoption_phase"] == "discovery"
    assert report["summary"]["detected_count"] == 0
    assert report["summary"]["absent_count"] == 14


def test_2_score_hundred_all_detected(tmp_path):
    report = _validate_ok(tmp_path, set(SCORED_IDS))
    assert report["score"] == 100.0
    assert report["adoption_phase"] == "consolidation"
    assert report["summary"]["detected_count"] == 14


def test_3_score_partial_seven_of_fourteen(tmp_path):
    detected = set(SCORED_IDS[:7])  # exactly 7 of 14 -> 50.0
    report = _validate_ok(tmp_path, detected)
    assert report["score"] == 50.0
    assert report["adoption_phase"] == "discovery"
    assert report["summary"]["detected_count"] == 7


# ---------- 4: deprecated set is empty (D1a=C) ---------------------------

def test_4_deprecated_set_empty_after_batch_5(tmp_path):
    """After Batch 5, no capability is deprecated. The informational
    block is nullable optional (D1a=C) and absent when empty."""
    report = _validate_ok(tmp_path, set())
    assert report["summary"]["deprecated_count"] == 0
    assert report["summary"]["total_scored"] == 14
    assert len(report["findings"]) == 14
    # informational is omitted entirely when empty (validator
    # conditionally attaches only when non-empty).
    if "informational" in report:
        assert report["informational"] == []
    finding_ids = {x["capability_id"] for x in report["findings"]}
    # Every capability id surfaces in findings; no deprecated set.
    assert finding_ids == set(CAPABILITY_IDS)


# ---------- 5-6: integration JSON / YAML ----------------------------------

def test_5_integration_json_default(tmp_path):
    scan = _write_scan(tmp_path, set(SCORED_IDS[:3]))
    rc, out, err = _run([
        "--scan-input", str(scan),
        "--matrix-path", str(MATRIX_MD),
        "--project-id", "demo",
        "--format", "json",
    ])
    assert rc == 0
    parsed = json.loads(out)
    assert parsed["score"] == round(3 / 14 * 100, 1)


def test_6_integration_yaml_format(tmp_path):
    scan = _write_scan(tmp_path, set(SCORED_IDS[:3]))
    rc, out, err = _run([
        "--scan-input", str(scan),
        "--matrix-path", str(MATRIX_MD),
        "--project-id", "demo",
        "--format", "yaml",
    ])
    assert rc == 0
    # We don't depend on PyYAML; sanity-check the textual shape.
    assert 'schema_version: "1.0.0"' in out
    assert "score: " in out
    assert "findings:" in out
    # informational is omitted when empty (D1a=C after Batch 5).
    # Every of the 14 capability records (14 findings + 0 informational)
    # opens with "- capability_id:" — count those exactly.
    cap_starts = [
        line for line in out.splitlines()
        if line.lstrip().startswith("- capability_id:")
    ]
    assert len(cap_starts) == 14, cap_starts


# ---------- 7-8: never-raise ----------------------------------------------

def test_7_matrix_missing_exits_4(tmp_path):
    scan = _write_scan(tmp_path, set())
    rc, out, err = _run([
        "--scan-input", str(scan),
        "--matrix-path", str(tmp_path / "no_such_matrix.md"),
        "--project-id", "demo",
    ])
    assert rc == 4, f"want 4, got {rc}; stderr: {err}"


def test_8_scan_json_malformed_exits_1(tmp_path):
    bad = tmp_path / "bad.json"
    bad.write_text("{not: valid json", encoding="utf-8")
    rc, out, err = _run([
        "--scan-input", str(bad),
        "--matrix-path", str(MATRIX_MD),
        "--project-id", "demo",
    ])
    assert rc == 1, f"want 1, got {rc}; stderr: {err}"


# ---------- 9: schema self-validation -------------------------------------

def test_9_emitted_report_validates_against_schema(tmp_path):
    jsonschema = pytest.importorskip("jsonschema")
    detected = set(SCORED_IDS[:5])
    report = _validate_ok(tmp_path, detected)
    schema = json.loads(ADOPT_SCHEMA.read_text(encoding="utf-8"))
    jsonschema.validate(instance=report, schema=schema)


# ---------- 10: Layer 1 lint clean ---------------------------------------

def test_10_layer_1_lint_remains_clean():
    proc = subprocess.run(
        [sys.executable, str(LINT)],
        cwd=str(PKG_ROOT),
        capture_output=True, text=True, timeout=30,
    )
    assert proc.returncode == 0, (
        f"lint exit {proc.returncode}\nstdout: {proc.stdout}\nstderr: {proc.stderr}"
    )
    assert "0 violations" in proc.stdout


# ---------- 11-13: --project-id blacklist (Step 2.6) ----------------------

# Build blacklisted project IDs at runtime so this source file remains
# Layer 1 clean. Each variant exercises a different match path:
#   11: substring match (rand+om+heroes)
#   12: substring match (less+ism+ore) at different case
#   13: regex match     (sp-NNN sprint id)

def _bad_project_id_attempt(tmp_path: Path, project_id: str) -> tuple[int, str, str]:
    """Try to run validate_adoption with the given --project-id; return rc/out/err."""
    scan = _write_scan(tmp_path, set())
    return _run([
        "--scan-input", str(scan),
        "--matrix-path", str(MATRIX_MD),
        "--project-id", project_id,
    ])


def test_11_blacklist_substring_lowercase_rejected(tmp_path):
    pid = "rand" + "om" + "heroes_demo"
    rc, out, err = _bad_project_id_attempt(tmp_path, pid)
    # argparse type-error → SystemExit(2) → our wrapper preserves code 2
    assert rc == 2, f"want 2, got {rc}; stderr: {err}"


def test_12_blacklist_substring_mixed_case_rejected(tmp_path):
    # argparse pattern guard runs FIRST and rejects uppercase letters
    # before the blacklist check (project IDs are lowercase-only). To
    # actually exercise the blacklist on a substring, we use the
    # lowercase form of the second blacklisted name.
    pid = "less" + "ism" + "ore_x"
    rc, out, err = _bad_project_id_attempt(tmp_path, pid)
    assert rc == 2, f"want 2, got {rc}; stderr: {err}"


def test_13_blacklist_sprint_id_regex_rejected(tmp_path):
    pid = "sp" + "-" + "115_x"
    rc, out, err = _bad_project_id_attempt(tmp_path, pid)
    assert rc == 2, f"want 2, got {rc}; stderr: {err}"
