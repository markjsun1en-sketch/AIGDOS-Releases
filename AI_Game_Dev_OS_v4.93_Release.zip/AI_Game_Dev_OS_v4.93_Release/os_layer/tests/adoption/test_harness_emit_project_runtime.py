"""Tests for run_mock_harness.py --emit-full-project-runtime — v4.90 Batch 9 Step 9.4.

Covers the end-stage scaffold integration (harness -> init_project_runtime):
  1. Happy path: harness emits 10-file .ai_dev_os/ tree after a successful
     baseline fixture run
  2. The emitted 02_project_profile.yaml carries the harness --project-id
  3. --emit-primary-host flag threads through to the scaffolded host profile
  4. --emit-stage flag threads through to the scaffolded project profile
  5. Omitting --emit-full-project-runtime runs the existing harness flow
     without scaffolding (back-compat)

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path


PKG_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = PKG_ROOT / "scripts" / "adoption" / "run_mock_harness.py"


def _run(*args: str, timeout: int = 60) -> tuple[int, str, str]:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(PKG_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True,
        text=True,
        env=env,
        timeout=timeout,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _load_yaml(path: Path) -> dict:
    sys.path.insert(0, str(PKG_ROOT))
    from scripts.governance._yaml_subset import parse_yaml_text
    return parse_yaml_text(path.read_text(encoding="utf-8"))


# --------------------------------------------------------------------------
# 1. Happy path
# --------------------------------------------------------------------------

def test_harness_emits_full_project_runtime(tmp_path: Path):
    ai_dev_os = tmp_path / ".ai_dev_os"
    report = tmp_path / "report.json"
    code, _, stderr = _run(
        "--fixture", "baseline",
        "--project-id", "acme_demo",
        "--emit-full-project-runtime", str(ai_dev_os),
        "--out", str(report),
    )
    assert code == 0, stderr
    assert ai_dev_os.is_dir()
    yamls = sorted(p.name for p in ai_dev_os.glob("0?_*.yaml"))
    assert yamls == [
        "01_project_runtime_protocol.yaml",
        "02_project_profile.yaml",
        "03_host_profile.yaml",
        "04_active_packs.yaml",
        "05_governance.yaml",
        "06_adoption_state.yaml",
    ]
    for sub in ("ltm", "evidence", "reports", "archive"):
        assert (ai_dev_os / sub / "README.md").is_file()
    assert "scaffolded" in stderr.lower()


# --------------------------------------------------------------------------
# 2. project-id threads through
# --------------------------------------------------------------------------

def test_emit_carries_project_id(tmp_path: Path):
    ai_dev_os = tmp_path / ".ai_dev_os"
    code, _, _ = _run(
        "--fixture", "baseline",
        "--project-id", "widget_co",
        "--emit-full-project-runtime", str(ai_dev_os),
    )
    assert code == 0
    profile = _load_yaml(ai_dev_os / "02_project_profile.yaml")
    assert profile["project_id"] == "widget_co"


# --------------------------------------------------------------------------
# 3. --emit-primary-host threads through
# --------------------------------------------------------------------------

def test_emit_primary_host_flag(tmp_path: Path):
    ai_dev_os = tmp_path / ".ai_dev_os"
    code, _, _ = _run(
        "--fixture", "baseline",
        "--project-id", "acme_demo",
        "--emit-full-project-runtime", str(ai_dev_os),
        "--emit-primary-host", "cursor",
    )
    assert code == 0
    host = _load_yaml(ai_dev_os / "03_host_profile.yaml")
    assert host["primary_host"] == "cursor"


# --------------------------------------------------------------------------
# 4. --emit-stage threads through
# --------------------------------------------------------------------------

def test_emit_stage_flag(tmp_path: Path):
    ai_dev_os = tmp_path / ".ai_dev_os"
    code, _, _ = _run(
        "--fixture", "baseline",
        "--project-id", "acme_demo",
        "--emit-full-project-runtime", str(ai_dev_os),
        "--emit-stage", "beta",
    )
    assert code == 0
    profile = _load_yaml(ai_dev_os / "02_project_profile.yaml")
    assert profile["stage"] == "beta"


# --------------------------------------------------------------------------
# 5. Back-compat: omitting the flag leaves the harness flow unchanged
# --------------------------------------------------------------------------

def test_omitting_emit_flag_leaves_harness_unchanged(tmp_path: Path):
    report = tmp_path / "report.json"
    code, _, _ = _run(
        "--fixture", "baseline",
        "--project-id", "acme_demo",
        "--out", str(report),
    )
    assert code == 0
    # A stale .ai_dev_os/ dir must NOT exist because we didn't ask for it.
    assert not (tmp_path / ".ai_dev_os").exists()
    # The report is present (harness still runs to completion).
    assert report.is_file()
    payload = json.loads(report.read_text())
    assert "score" in payload
