"""test_init_workbuddy_private_e2e.py — v4.90 Batch 9 Step 9.5.

End-to-end revalidation that the Step 9.2 init_project_runtime.py
scaffold and the Step 9.4 harness --emit-full-project-runtime path
produce field-equivalent .ai_dev_os/ trees for the workbuddy_private
profile case.

The Step 9.2 scaffold takes its inputs purely from CLI flags. The
Step 9.4 harness path runs scan+validate first and then hands the
fixture summary to scaffold(). For workbuddy_private both flows must
emit the same 10 files and the yaml fields that we care about
(schema_version, project_id, primary_host, stage) must match.

This is a real-project adoption rehearsal — it consumes the
v4.89_Release-shipped workbuddy_private fixture (byte-locked tree SHA
bb48af16...) and confirms the v4.90 adoption toolkit is sufficient to
produce a complete .ai_dev_os/ tree from that fixture.

Layer 1 (OS Spec). The fixture id 'workbuddy_private' is a host_profile
identifier (not a project name) per scripts/migration/detect_project_protocol.py
KNOWN_HOSTS. The Layer 2 evidence document
docs/14_state_surface_governance/STATE_SURFACE_MIGRATION_CASE_WORKBUDDY_PRIVATE.md
remains the only place project-specific narrative may live.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest


PKG_ROOT = Path(__file__).resolve().parents[2]
INIT_SCRIPT = PKG_ROOT / "scripts" / "adoption" / "init_project_runtime.py"
HARNESS_SCRIPT = PKG_ROOT / "scripts" / "adoption" / "run_mock_harness.py"
LAYER_2_CASE = (
    PKG_ROOT
    / "docs/14_state_surface_governance"
    / "STATE_SURFACE_MIGRATION_CASE_WORKBUDDY_PRIVATE.md"
)


def _run(script: Path, *args: str, timeout: int = 60) -> tuple[int, str, str]:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(PKG_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.run(
        [sys.executable, str(script), *args],
        capture_output=True,
        text=True,
        env=env,
        timeout=timeout,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _load_yaml(path: Path) -> dict:
    sys.path.insert(0, str(PKG_ROOT))
    from scripts.governance._yaml_subset import parse_yaml_text
    return parse_yaml_text(path.read_text(encoding="utf-8"))


# --------------------------------------------------------------------------
# 1. Layer 2 case file is present (precondition for the rehearsal)
# --------------------------------------------------------------------------

def test_layer_2_case_doc_present():
    assert LAYER_2_CASE.is_file(), (
        "workbuddy_private Layer 2 evidence doc must be present "
        "before Step 9.5 can claim a revalidation pass"
    )
    text = LAYER_2_CASE.read_text(encoding="utf-8")
    assert "workbuddy_private" in text
    assert "Layer 2" in text


# --------------------------------------------------------------------------
# 2. init scaffold produces a workbuddy_private .ai_dev_os/ tree
# --------------------------------------------------------------------------

def test_init_scaffold_for_workbuddy_private(tmp_path: Path):
    out = tmp_path / "init_only" / ".ai_dev_os"
    code, _, stderr = _run(
        INIT_SCRIPT,
        "--out", str(out),
        "--project-id", "wb_private_demo",
        "--project-name", "Workbuddy Private Demo",
        "--stage", "alpha",
        "--primary-host", "workbuddy",
    )
    assert code == 0, stderr
    assert (out / "03_host_profile.yaml").is_file()
    host = _load_yaml(out / "03_host_profile.yaml")
    assert host["primary_host"] == "workbuddy"


# --------------------------------------------------------------------------
# 3. harness with workbuddy_private fixture emits a .ai_dev_os/ tree
# --------------------------------------------------------------------------

def test_harness_fixture_emits_workbuddy_private(tmp_path: Path):
    out = tmp_path / "harness" / ".ai_dev_os"
    report = tmp_path / "harness" / "report.json"
    code, _, stderr = _run(
        HARNESS_SCRIPT,
        "--fixture", "workbuddy_private",
        "--project-id", "wb_private_demo",
        "--emit-full-project-runtime", str(out),
        "--emit-primary-host", "workbuddy",
        "--out", str(report),
    )
    assert code == 0, stderr
    assert (out / "03_host_profile.yaml").is_file()
    host = _load_yaml(out / "03_host_profile.yaml")
    assert host["primary_host"] == "workbuddy"


# --------------------------------------------------------------------------
# 4. Fingerprint equivalence: both flows produce the same file set
# --------------------------------------------------------------------------

def test_init_and_harness_produce_same_file_set(tmp_path: Path):
    init_out = tmp_path / "init_only" / ".ai_dev_os"
    harness_out = tmp_path / "harness" / ".ai_dev_os"

    _run(
        INIT_SCRIPT,
        "--out", str(init_out),
        "--project-id", "wb_private_demo",
        "--project-name", "WB Private Demo",
        "--stage", "alpha",
        "--primary-host", "workbuddy",
    )
    _run(
        HARNESS_SCRIPT,
        "--fixture", "workbuddy_private",
        "--project-id", "wb_private_demo",
        "--emit-full-project-runtime", str(harness_out),
        "--emit-primary-host", "workbuddy",
        "--emit-stage", "alpha",
    )

    def _relset(root: Path) -> set:
        out: set = set()
        for p in root.rglob("*"):
            if p.is_file() and ".gitkeep" not in p.name:
                out.add(p.relative_to(root).as_posix())
        return out

    init_files = _relset(init_out)
    harness_files = _relset(harness_out)
    assert init_files == harness_files, (
        f"file-set drift:\n  only in init: {init_files - harness_files}\n"
        f"  only in harness: {harness_files - init_files}"
    )


# --------------------------------------------------------------------------
# 5. Field-level equivalence on host_profile
# --------------------------------------------------------------------------

def test_host_profile_field_equivalence(tmp_path: Path):
    init_out = tmp_path / "init_only" / ".ai_dev_os"
    harness_out = tmp_path / "harness" / ".ai_dev_os"

    _run(
        INIT_SCRIPT,
        "--out", str(init_out),
        "--project-id", "wb_private_demo",
        "--project-name", "WB Private Demo",
        "--stage", "alpha",
        "--primary-host", "workbuddy",
    )
    _run(
        HARNESS_SCRIPT,
        "--fixture", "workbuddy_private",
        "--project-id", "wb_private_demo",
        "--emit-full-project-runtime", str(harness_out),
        "--emit-primary-host", "workbuddy",
        "--emit-stage", "alpha",
    )
    init_host = _load_yaml(init_out / "03_host_profile.yaml")
    harness_host = _load_yaml(harness_out / "03_host_profile.yaml")
    assert init_host["schema_version"] == harness_host["schema_version"]
    assert init_host["primary_host"] == harness_host["primary_host"]


# --------------------------------------------------------------------------
# 6. Field-level equivalence on project_profile (stage + project_id)
# --------------------------------------------------------------------------

def test_project_profile_field_equivalence(tmp_path: Path):
    init_out = tmp_path / "init_only" / ".ai_dev_os"
    harness_out = tmp_path / "harness" / ".ai_dev_os"

    _run(
        INIT_SCRIPT,
        "--out", str(init_out),
        "--project-id", "wb_private_demo",
        "--project-name", "WB Private Demo",
        "--stage", "alpha",
        "--primary-host", "workbuddy",
    )
    _run(
        HARNESS_SCRIPT,
        "--fixture", "workbuddy_private",
        "--project-id", "wb_private_demo",
        "--emit-full-project-runtime", str(harness_out),
        "--emit-primary-host", "workbuddy",
        "--emit-stage", "alpha",
    )
    init_p = _load_yaml(init_out / "02_project_profile.yaml")
    harness_p = _load_yaml(harness_out / "02_project_profile.yaml")
    assert init_p["project_id"] == harness_p["project_id"] == "wb_private_demo"
    assert init_p["stage"] == harness_p["stage"] == "alpha"
    assert init_p["schema_version"] == harness_p["schema_version"]


# --------------------------------------------------------------------------
# 7. Adoption snapshot retains all 14 capabilities in both flows
# --------------------------------------------------------------------------

def test_adoption_snapshot_14_capabilities_both_flows(tmp_path: Path):
    init_out = tmp_path / "init_only" / ".ai_dev_os"
    harness_out = tmp_path / "harness" / ".ai_dev_os"

    _run(
        INIT_SCRIPT,
        "--out", str(init_out),
        "--project-id", "wb_private_demo",
        "--project-name", "WB Private Demo",
        "--stage", "alpha",
        "--primary-host", "workbuddy",
    )
    _run(
        HARNESS_SCRIPT,
        "--fixture", "workbuddy_private",
        "--project-id", "wb_private_demo",
        "--emit-full-project-runtime", str(harness_out),
        "--emit-primary-host", "workbuddy",
        "--emit-stage", "alpha",
    )
    init_state = _load_yaml(init_out / "06_adoption_state.yaml")
    harness_state = _load_yaml(harness_out / "06_adoption_state.yaml")
    assert len(init_state["capabilities"]) == 14
    assert len(harness_state["capabilities"]) == 14
    # Both should list the same capability id keys
    assert set(init_state["capabilities"].keys()) == set(harness_state["capabilities"].keys())


# --------------------------------------------------------------------------
# 8. Emitted yaml validates against the Step 9.1 schemas (harness path)
# --------------------------------------------------------------------------

def test_harness_emitted_yaml_validates_schemas(tmp_path: Path):
    jsonschema = pytest.importorskip("jsonschema")
    out = tmp_path / "harness" / ".ai_dev_os"
    _run(
        HARNESS_SCRIPT,
        "--fixture", "workbuddy_private",
        "--project-id", "wb_private_demo",
        "--emit-full-project-runtime", str(out),
        "--emit-primary-host", "workbuddy",
        "--emit-stage", "alpha",
    )
    schemas = {
        "02_project_profile.yaml": "project_profile.schema.json",
        "03_host_profile.yaml": "host_profile.schema.json",
        "04_active_packs.yaml": "active_packs.schema.json",
    }
    for yaml_name, schema_name in schemas.items():
        schema = json.loads(
            (PKG_ROOT / "schemas/adoption" / schema_name).read_text()
        )
        instance = _load_yaml(out / yaml_name)
        jsonschema.validate(instance=instance, schema=schema)
