"""test_mock_baseline_fixture.py — v4.90 Batch 2.5 Step 2.5.1.

Contract tests for the static mock_legacy_project_baseline/ fixture and
the conftest factory that clones it.

4 cases:
1. Baseline exists and its shape is the documented minimum (docs/,
   runtime_state_seed/, README.md).
2. make_legacy_project_from_baseline() clones it cleanly and strips
   .gitkeep markers.
3. plant_capability() is idempotent (calling twice is a no-op).
4. matrix_split() honours the 11/3 invariant (no matrix drift).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

from pathlib import Path

from tests.adoption.conftest import (  # type: ignore[import-not-found]
    MOCK_BASELINE_DIR,
    plant_capability,
)


def test_baseline_shape_is_documented():
    assert MOCK_BASELINE_DIR.is_dir()
    assert (MOCK_BASELINE_DIR / "README.md").is_file()
    assert (MOCK_BASELINE_DIR / "docs").is_dir()
    assert (MOCK_BASELINE_DIR / "runtime_state_seed").is_dir()
    # No nested directories beyond these two — keeps baseline small.
    top = {p.name for p in MOCK_BASELINE_DIR.iterdir() if p.is_dir()}
    assert top == {"docs", "runtime_state_seed"}


def test_factory_clones_and_strips_gitkeep(make_legacy_project_from_baseline):
    proj: Path = make_legacy_project_from_baseline()
    assert proj.is_dir()
    assert (proj / "docs").is_dir()
    assert (proj / "runtime_state_seed").is_dir()
    # .gitkeep markers stripped so the scan sees a pure empty skeleton.
    assert list(proj.rglob(".gitkeep")) == []
    # README.md is copied verbatim (Layer 1 contract doc).
    assert (proj / "README.md").is_file()


def test_plant_capability_is_idempotent(tmp_path, matrix_blocks):
    proj = tmp_path / "legacy_project"
    proj.mkdir()
    block = matrix_blocks[0]  # 01_runtime_core
    plant_capability(proj, block)
    before = sorted(p.relative_to(proj).as_posix() for p in proj.rglob("*"))
    plant_capability(proj, block)  # second call
    after = sorted(p.relative_to(proj).as_posix() for p in proj.rglob("*"))
    assert before == after, (before, after)


def test_matrix_split_invariant_14_0(matrix_split):
    scored, deprecated = matrix_split
    assert len(scored) == 14
    assert len(deprecated) == 0
    # After Batch 5 Step 5.6 promoted rows 09 + 10 to requires_adapter
    # (and Batch 6 promoted row 14), the matrix contains zero
    # deprecated rows. The previous assertion that
    # {09_agent_library, 10_pack_activation} were deprecated is now
    # historically true only — see V4_90_README §5.9.
