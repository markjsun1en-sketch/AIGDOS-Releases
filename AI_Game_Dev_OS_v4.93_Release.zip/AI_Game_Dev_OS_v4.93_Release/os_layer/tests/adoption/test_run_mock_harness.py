"""test_run_mock_harness.py — v4.90 Batch 2.5 Module A (CLI tests).

Validates scripts/adoption/run_mock_harness.py subprocess behavior.

8 cases:
1. --help renders.
2. fixture=baseline → score 0.0 / phase discovery / plants=0.
3. fixture=partial  → score 50.0 / phase discovery / plants=7
                      (7/14 after Batch 5 promoted rows 09 + 10).
4. fixture=full     → score 100.0 / phase consolidation / plants=14.
5. fixture=custom + spec yaml → score matches len(plant_ids)/14×100.
6. fixture=custom WITHOUT --spec → exit 2 USAGE.
7. --spec missing file → exit 4 INPUT_MISSING.
8. --project-id containing a blacklisted form → exit 2 USAGE.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
HARNESS = PKG_ROOT / "scripts" / "adoption" / "run_mock_harness.py"


def _run(*args) -> tuple[int, str, str]:
    proc = subprocess.run(
        [sys.executable, str(HARNESS), *args],
        capture_output=True, text=True, timeout=45,
    )
    return proc.returncode, proc.stdout, proc.stderr


def test_help_renders():
    rc, out, err = _run("--help")
    assert rc == 0
    assert "mock legacy project baseline" in out.lower()


def test_fixture_baseline(tmp_path):
    out = tmp_path / "report.json"
    rc, stdout, stderr = _run(
        "--fixture", "baseline",
        "--project-id", "mock_demo",
        "--out", str(out),
    )
    assert rc == 0, stderr
    report = json.loads(out.read_text(encoding="utf-8"))
    assert report["score"] == 0.0
    assert report["adoption_phase"] == "discovery"
    assert report["summary"]["detected_count"] == 0
    # harness summary line to stderr
    assert "plants=0" in stderr


def test_fixture_partial(tmp_path):
    out = tmp_path / "report.json"
    rc, _, stderr = _run(
        "--fixture", "partial",
        "--project-id", "mock_demo",
        "--out", str(out),
    )
    assert rc == 0, stderr
    report = json.loads(out.read_text(encoding="utf-8"))
    assert report["score"] == 50.0
    assert report["adoption_phase"] == "discovery"
    assert report["summary"]["detected_count"] == 7
    assert "plants=7" in stderr


def test_fixture_full(tmp_path):
    out = tmp_path / "report.json"
    rc, _, stderr = _run(
        "--fixture", "full",
        "--project-id", "mock_demo",
        "--out", str(out),
    )
    assert rc == 0, stderr
    report = json.loads(out.read_text(encoding="utf-8"))
    assert report["score"] == 100.0
    assert report["adoption_phase"] == "consolidation"
    assert report["summary"]["detected_count"] == 14
    assert "plants=14" in stderr


def test_fixture_custom_with_spec(tmp_path):
    spec = tmp_path / "spec.yaml"
    spec.write_text(
        'plant_ids:\n'
        '  - "01_runtime_core"\n'
        '  - "02_project_profile"\n'
        '  - "12_dashboard_exports"\n',
        encoding="utf-8",
    )
    out = tmp_path / "report.json"
    rc, _, stderr = _run(
        "--fixture", "custom",
        "--spec", str(spec),
        "--project-id", "mock_demo",
        "--out", str(out),
    )
    assert rc == 0, stderr
    report = json.loads(out.read_text(encoding="utf-8"))
    # 3 plants out of 14 → 3/14 * 100 = 21.4 (rounded)
    assert report["summary"]["detected_count"] == 3
    assert report["score"] == round(3 / 14 * 100, 1)


def test_fixture_custom_without_spec_exits_2(tmp_path):
    rc, _, stderr = _run(
        "--fixture", "custom",
        "--project-id", "mock_demo",
    )
    assert rc == 2, stderr


def test_spec_file_missing_exits_4(tmp_path):
    missing_spec = tmp_path / "no_such_spec.yaml"
    rc, _, stderr = _run(
        "--fixture", "custom",
        "--spec", str(missing_spec),
        "--project-id", "mock_demo",
    )
    assert rc == 4, stderr


def test_blacklisted_project_id_exits_2(tmp_path):
    # Runtime-assemble the blacklisted form so this file stays Layer 1 clean.
    pid = "rand" + "om" + "heroes_trial"
    rc, _, stderr = _run(
        "--fixture", "baseline",
        "--project-id", pid,
    )
    assert rc == 2, stderr
