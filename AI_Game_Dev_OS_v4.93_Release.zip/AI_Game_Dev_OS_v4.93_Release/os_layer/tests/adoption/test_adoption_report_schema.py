"""test_adoption_report_schema.py — v4.90 Batch 2 Step 2.2.

Self-validation tests for schemas/adoption/adoption_report.schema.json:
1. The schema document is itself a valid JSON Schema draft-07 doc.
2. A minimal happy-path instance validates successfully.
3. An instance missing a required top-level key is rejected.
4. An instance whose findings[].capability_id violates the regex pattern
   is rejected.

Mirrors tests/governance/test_schema_self_validation.py style. Uses
jsonschema via pytest.importorskip per the v4.89 zero-external-dep rule.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = REPO_ROOT / "schemas" / "adoption" / "adoption_report.schema.json"


def _load_schema() -> dict:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def _minimal_valid_instance() -> dict:
    """A minimal-yet-complete instance that satisfies every required field.

    14 findings (one per scored capability) + 0 informational entries.
    capability_ids use generic 2-digit prefixes 01..14, matching the
    docs/13_migration matrix layout. Batch 5 Step 5.6 promoted rows
    09 and 10 from deprecated to requires_adapter; row 14 was
    promoted in Batch 6 (evo_2026_001). After Batch 5,
    deprecated_count is locked at 0 and informational is a nullable
    optional field (D1a=C).
    """
    findings = [
        {
            "capability_id": f"{i:02d}_capability_{i:02d}",
            "status": "absent",
            "risk_level": "low",
            "source_version": "4.82",
            "target_version": "4.90",
            "detection_method": "none",
            "evidence_paths": [],
        }
        for i in range(1, 15)  # 14 scored after Batch 5
    ]
    return {
        "schema_version": "1.0.0",
        "generated_at": "2026-05-11T10:00:00Z",
        "project_id": "acme_demo",
        "source_version": "4.82",
        "target_version": "4.90",
        "score": 0.0,
        "adoption_phase": "discovery",
        "summary": {
            "detected_count": 0,
            "absent_count": 14,
            "total_scored": 14,
            "deprecated_count": 0,
        },
        "findings": findings,
        # informational: omitted (D1a=C nullable optional after Batch 5)
    }


# --------- Test 1: meta-validation -------------------------------------

def test_schema_is_valid_draft_07():
    schema = _load_schema()
    # Raises if the schema document itself is not a valid draft-07 schema.
    jsonschema.Draft7Validator.check_schema(schema)
    assert schema["$schema"] == "http://json-schema.org/draft-07/schema#"
    assert schema["title"].startswith("Adoption Report")


# --------- Test 2: happy-path validation -------------------------------

def test_minimal_valid_instance_accepted():
    schema = _load_schema()
    instance = _minimal_valid_instance()
    # Raises ValidationError on failure, which would surface as test fail.
    jsonschema.validate(instance=instance, schema=schema)


# --------- Test 3: missing required top-level key ----------------------

def test_missing_required_score_rejected():
    schema = _load_schema()
    instance = _minimal_valid_instance()
    instance.pop("score")
    with pytest.raises(jsonschema.ValidationError) as exc:
        jsonschema.validate(instance=instance, schema=schema)
    assert "score" in str(exc.value).lower() or "required" in str(exc.value).lower()


# --------- Test 4: capability_id pattern violation ---------------------

def test_finding_capability_id_pattern_rejected():
    schema = _load_schema()
    instance = _minimal_valid_instance()
    bad = copy.deepcopy(instance)
    # Single-digit prefix violates the ^[0-9]{2}_... pattern.
    bad["findings"][0]["capability_id"] = "1_bad"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=bad, schema=schema)
