"""Tests for verify_beta_sprint_exit output report v4.90_status field
(v4.90 Batch 0.5 Step 0.5.3).

The v4.90_status field is an additive informational block that documents
the verifier's tier upgrade state to new audit consumers. Old consumers
ignore unknown keys; verdict / error_count / warn_count semantics are
unchanged.

Audit-consumer contract requires:
  - upgrade_tag: 'v4.89-trial-upgrade' string KEPT (legacy compat)
  - v4.90_status: present alongside, never replacing
"""
from __future__ import annotations

import io
import json
import sys
from contextlib import redirect_stdout
from pathlib import Path

V4_90_ROOT = Path(__file__).resolve().parents[1]
S1_DIR = V4_90_ROOT / "examples" / "_mock_baselines" / "trial_scenarios" / "S1_codex_tapd_git"

import verify_beta_sprint_exit


def _run_verifier_in_process() -> dict:
    """Invoke main() in-process (no subprocess) and capture the JSON report."""
    argv_backup = sys.argv[:]
    sys.argv = [
        "verify_beta_sprint_exit.py",
        "--workspace", str(S1_DIR),
        "--audit-log", str(S1_DIR / "sample_audit.jsonl"),
        "--runtime-state", str(S1_DIR / "runtime_state.json"),
        "--sprint-close-checklist", str(S1_DIR / "sprint_close_checklist.md"),
        "--sprint", "sprint-s1",
        "--profile", "codex",
    ]
    buf = io.StringIO()
    try:
        with redirect_stdout(buf):
            exit_code = verify_beta_sprint_exit.main()
    finally:
        sys.argv = argv_backup
    assert exit_code in (0, 1), exit_code  # PASS or CONDITIONAL acceptable
    return json.loads(buf.getvalue())


def test_v4_90_status_present():
    report = _run_verifier_in_process()
    assert "v4.90_status" in report


def test_v4_90_status_shape():
    report = _run_verifier_in_process()
    status = report["v4.90_status"]
    assert isinstance(status, dict)
    for required_key in (
        "batch_0_5_closed",
        "guided_checks",
        "scaffold_checks",
        "deep_cross_validation",
    ):
        assert required_key in status, (required_key, status)


def test_v4_90_status_all_five_checks_guided():
    report = _run_verifier_in_process()
    guided = report["v4.90_status"]["guided_checks"]
    scaffold = report["v4.90_status"]["scaffold_checks"]
    assert set(guided) == {"init", "execution", "external", "evidence", "close"}
    assert scaffold == []
    assert report["v4.90_status"]["batch_0_5_closed"] is True
    assert report["v4.90_status"]["deep_cross_validation"] == "enabled"


def test_legacy_upgrade_tag_preserved():
    """audit-consumer contract — the v4.89 string MUST stay."""
    report = _run_verifier_in_process()
    assert report["upgrade_tag"] == "v4.89-trial-upgrade"


def test_v4_90_status_does_not_alter_verdict():
    """S1 PASS verdict + 0 errors + 0 warns must hold despite new field."""
    report = _run_verifier_in_process()
    assert report["verdict"] == "PASS"
    assert report["error_count"] == 0
    assert report["warn_count"] == 0
