"""Phase 3 Lock-B / M7.1 — schema-driven cross-checker equivalence test.

This test is the **acceptance contract** for any future Phase 3 Step 2
collapse of the per-profile if-tree (M6.4-M6.7's four blocks in
``check_init_integrity``).  Concretely: it parametrises over the
16-row R1 regression matrix (same source as
``test_stage_2_regression_r1.py::_MATRIX``) and, for each row, runs
the verifier twice — once on the default path
(``STAGE_2_USE_SCHEMA_CHECKER=0``, the M6.4-M6.7 per-profile if-tree)
and once on the schema-driven path
(``STAGE_2_USE_SCHEMA_CHECKER=1``, the prototype in
``runtime/schema_driven_check.py``).  The driver's stdout JSON
envelope must be **byte-identical** between the two paths on every
row.

If this test passes for all 16 rows, it constitutes the empirical
evidence that the schema-driven prototype is behaviourally
equivalent to the per-profile if-tree on the entire R1 surface, and
the per-profile if-tree may be safely collapsed in a follow-up
milestone (M7.2 candidate; not in M7.1 scope per EP Q1=A
"audit-only").

**Post-M7.2 note (2026-05-05)**: The per-profile if-tree was
collapsed in M7.2; ``STAGE_2_USE_SCHEMA_CHECKER`` env switch was
removed (default and "schema" paths now both invoke
``schema_driven_init_check``).  This test therefore now produces
**trivial** byte-identity (both runs invoke the same code), but is
intentionally **kept** because:

1. It serves as the regression guard for any *future* profile
   addition (v4.90+): adding a row to ``_MATRIX`` and the matching
   ``_PROFILE_CHECK_FIELDS`` entry in
   ``runtime/schema_driven_check.py`` is what new-profile parity
   onboarding looks like; this test catches forgotten rows.
2. It documents the M7.1 acceptance contract that justified the
   collapse — without it, the audit-on-evidence trail is harder to
   reconstruct.
3. The ~1.3s pytest cost is acceptable for the Phase 3 acceptance
   gate it represents.

If a future milestone re-introduces a divergent per-profile path
(unlikely but possible if Phase 4 lifts the cross-check gate), this
test instantly becomes non-trivial again and serves its original
purpose without any change to the test code itself.

Why byte-identical (and not "structurally equivalent")
------------------------------------------------------
The 4 postmortems in ``ltm/failures/`` and the cumulative metric
``+110 lines verify.py / 0 deletions`` make the per-profile blocks
auditable evidence.  Replacing them is justifiable only if the
replacement produces *the same JSON envelopes any consumer would
receive*.  Anything weaker — same verdict but different message
wording, same warn_count but different ordering — leaves room for
silent semantic drift that would defeat the M6.4-M6.7 silent-PASS
discipline.

Subprocess-based, like the M6.8 R1 regression
---------------------------------------------
We invoke the driver as a subprocess (matching production / CI
usage) so this test exercises the full env-switch path through
argparse / sys.path resolution / JSON serialisation / exit code,
not just the in-process ``check_init_integrity`` callable.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest


_PKG_ROOT = Path(__file__).resolve().parents[1]
_DRIVER = _PKG_ROOT / "scripts" / "beta_sprint_driver.py"
_TRIAL_ROOT = _PKG_ROOT / "trial_workspaces"


# Mirror of test_stage_2_regression_r1._MATRIX — 16 rows.  Kept in sync
# manually because importing across test files muddies pytest collection.
# See `test_matrix_size_locked` in the R1 file which guards size.
_MATRIX: list[tuple[str, str, str]] = [
    # 6 positive × 2 maturity = 12 rows
    ("workbuddy_private", "SCAFFOLD", "rh_sprint_sim_01"),
    ("workbuddy_private", "GUIDED", "rh_sprint_sim_01"),
    ("codex", "SCAFFOLD", "rh_sprint_sim_01__codex"),
    ("codex", "GUIDED", "rh_sprint_sim_01__codex"),
    ("cursor", "SCAFFOLD", "rh_sprint_sim_01__cursor"),
    ("cursor", "GUIDED", "rh_sprint_sim_01__cursor"),
    ("claude_code_agent_teams", "SCAFFOLD",
     "rh_sprint_sim_01__claude_code_agent_teams"),
    ("claude_code_agent_teams", "GUIDED",
     "rh_sprint_sim_01__claude_code_agent_teams"),
    ("claude_code_subagents", "SCAFFOLD",
     "rh_sprint_sim_01__claude_code_subagents"),
    ("claude_code_subagents", "GUIDED",
     "rh_sprint_sim_01__claude_code_subagents"),
    ("default_beta_codex_tapd_git", "SCAFFOLD",
     "rh_sprint_sim_01__default_beta_codex_tapd_git"),
    ("default_beta_codex_tapd_git", "GUIDED",
     "rh_sprint_sim_01__default_beta_codex_tapd_git"),
    # 4 negative × GUIDED = 4 rows
    ("codex", "GUIDED", "rh_sprint_sim_01__codex_negative"),
    ("cursor", "GUIDED", "rh_sprint_sim_01__cursor_negative"),
    ("claude_code_agent_teams", "GUIDED",
     "rh_sprint_sim_01__claude_code_agent_teams_negative"),
    ("claude_code_subagents", "GUIDED",
     "rh_sprint_sim_01__claude_code_subagents_negative"),
]


def _run_driver(profile: str, maturity: str, workspace: Path,
                use_schema: bool) -> str:
    """Spawn the driver as a subprocess; return raw stdout text.

    ``use_schema`` switches the ``STAGE_2_USE_SCHEMA_CHECKER`` env
    variable, controlling which path ``check_init_integrity`` takes.
    Stderr is captured but not returned; on a non-zero exit the test
    still proceeds (CONDITIONAL = exit 1 is expected for negative
    mirrors).
    """
    env = os.environ.copy()
    env["STAGE_2_USE_SCHEMA_CHECKER"] = "1" if use_schema else "0"
    proc = subprocess.run(
        [
            sys.executable,
            str(_DRIVER),
            "--profile", profile,
            "--maturity", maturity,
            "--workspace", str(workspace),
        ],
        capture_output=True,
        text=True,
        check=False,
        timeout=60,
        env=env,
    )
    return proc.stdout


def _matrix_id(case: tuple) -> str:
    profile, maturity, mirror = case
    tail = mirror.replace("rh_sprint_sim_01", "P1")
    return f"{profile}/{maturity}/{tail}"


@pytest.mark.parametrize("case", _MATRIX, ids=_matrix_id)
def test_schema_driven_byte_identical(case: tuple):
    """For one matrix row, default path stdout MUST equal schema-driven
    path stdout, byte-for-byte.

    On mismatch the assertion message includes both envelopes so the
    failure is debuggable without re-running.
    """
    profile, maturity, mirror = case
    workspace = _TRIAL_ROOT / mirror
    assert workspace.is_dir(), f"matrix references missing mirror: {workspace}"

    default_out = _run_driver(profile, maturity, workspace, use_schema=False)
    schema_out = _run_driver(profile, maturity, workspace, use_schema=True)

    if default_out == schema_out:
        return  # byte-identical, test passes

    # On mismatch, show structural diff for human eyes.
    try:
        default_env = json.loads(default_out)
    except json.JSONDecodeError:
        default_env = {"_raw": default_out}
    try:
        schema_env = json.loads(schema_out)
    except json.JSONDecodeError:
        schema_env = {"_raw": schema_out}

    diag_default = json.dumps(default_env, ensure_ascii=False, indent=2)
    diag_schema = json.dumps(schema_env, ensure_ascii=False, indent=2)

    raise AssertionError(
        f"schema-driven path NOT byte-identical to default path on "
        f"{profile}/{maturity}/{mirror}:\n"
        f"--- default (M6.4-M6.7 if-tree) ---\n{diag_default}\n"
        f"--- schema-driven (M7.1 prototype) ---\n{diag_schema}\n"
        f"--- raw stdout diff ---\n"
        f"default len={len(default_out)} bytes\n"
        f"schema  len={len(schema_out)} bytes"
    )


def test_matrix_size_locked():
    """Sanity: this matrix has 16 rows, mirroring R1.  If R1 grows
    (v4.90+ adds a row), this test must grow in the same commit."""
    assert len(_MATRIX) == 16, (
        f"_MATRIX length changed unexpectedly to {len(_MATRIX)}; "
        f"if R1's matrix grew, mirror that growth here in the same commit "
        f"(see test_stage_2_regression_r1::_MATRIX for the source of truth)"
    )
