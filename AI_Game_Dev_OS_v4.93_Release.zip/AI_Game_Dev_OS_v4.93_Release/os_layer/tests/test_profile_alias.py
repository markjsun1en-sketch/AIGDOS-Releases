"""Tests for C2 profile/runtime_profile alias (init + verify)."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


_PKG_ROOT = Path(__file__).resolve().parents[1]
_INIT = _PKG_ROOT / "scripts" / "init_runtime_env.py"
_VERIFY = _PKG_ROOT / "scripts" / "verify_beta_sprint_exit.py"


def _run_verify(workspace: Path) -> dict:
    r = subprocess.run(
        [sys.executable, str(_VERIFY),
         "--workspace", str(workspace), "--profile", "workbuddy_private"],
        capture_output=True, text=True, check=False,
    )
    out = r.stdout
    for i, line in enumerate(out.splitlines()):
        if line.strip() == "{":
            idx = sum(len(l) + 1 for l in out.splitlines()[:i])
            return json.loads(out[idx:])
    raise RuntimeError(f"verify did not produce JSON: stderr={r.stderr[:200]}")


def _prep_mini_workspace(workspace: Path, state: dict) -> None:
    (workspace / "runtime" / "state").mkdir(parents=True)
    (workspace / "runtime" / "state" / "runtime_state.json").write_text(
        json.dumps(state)
    )
    (workspace / "runtime" / "logs").mkdir(parents=True)
    (workspace / "runtime" / "logs" / "mcp_audit.jsonl").touch()


def test_init_writes_both_profile_aliases(workspace: Path):
    r = subprocess.run(
        [sys.executable, str(_INIT),
         "--output-dir", str(workspace),
         "--project-id", "test",
         "--runtime-profile", "workbuddy_private",
         "--dry-run"],
        capture_output=True, text=True, check=False,
    )
    assert r.returncode == 0
    # dry-run emits the state json then the DRY_RUN marker.
    state_json = r.stdout.split("init_runtime_env:")[0].strip()
    state = json.loads(state_json)
    assert state.get("profile") == "workbuddy_private"
    assert state.get("runtime_profile") == "workbuddy_private"


def test_verify_accepts_legacy_profile_only(workspace: Path):
    _prep_mini_workspace(workspace, {
        "profile": "workbuddy_private",
        "initialized_at": "2026-05-02T00:00:00Z",
        "runtime_type": "workbuddy_private",
        "project_id": "t",
    })
    result = _run_verify(workspace)
    missing = [f for f in result["findings"] if "required field" in f["message"]]
    assert not missing, missing


def test_verify_accepts_new_runtime_profile_only(workspace: Path):
    _prep_mini_workspace(workspace, {
        "runtime_profile": "workbuddy_private",
        "initialized_at": "2026-05-02T00:00:00Z",
        "runtime_type": "workbuddy_private",
        "project_id": "t",
    })
    result = _run_verify(workspace)
    missing = [f for f in result["findings"] if "required field" in f["message"]]
    assert not missing, missing
