"""test_manifest_schema_notes_consistency.py — v4.90 Batch 14 Step 14.7.

Cross-reference guard between:
    AI_Game_Dev_OS_v4.90/RELEASE_MANIFEST.json::manifest_schema_notes
    AI_Game_Dev_OS_v4.90/docs/MANIFEST_HISTORY.md

Mandate (333 plan §5):
The manifest schema_notes array and the long-form changelog must
stay in lockstep. Whenever a new schema-shape entry is appended to
the array, the changelog gets a matching section, and vice versa.
This test is the gate that enforces that contract.

What's checked (single test, multiple assertions):
    1. manifest_schema_notes is a list (not the legacy single string)
    2. >= 5 entries (v2.0/v2.1 history + 12.1a + 12.1b + 14.3 + 14.8)
    3. each entry is a non-empty string
    4. MANIFEST_HISTORY.md exists at docs/MANIFEST_HISTORY.md
    5. each non-historical entry's batch id keyword appears in
       MANIFEST_HISTORY.md (so the long-form doc covers every short
       blurb)

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = REPO_ROOT / "RELEASE_MANIFEST.json"
HISTORY_PATH = REPO_ROOT / "docs" / "MANIFEST_HISTORY.md"


def _batch_keywords_in_entry(entry: str) -> list[str]:
    """Pull all 'Batch X.Y' tokens (and the historical 'v2.0' / 'v2.1') from
    one schema_notes entry so we can check coverage in the long-form doc."""
    keywords = set()
    # Batch keywords: 'Batch 12.1a', 'Batch 14.3', 'Batch 14.8' ...
    for m in re.finditer(r"Batch\s+(\d+(?:\.\d+)?[a-z]?)", entry):
        keywords.add(f"Batch {m.group(1)}")
    # Historical version markers
    for ver in ("v2.0", "v2.1"):
        if ver in entry:
            keywords.add(ver)
    return sorted(keywords)


def test_manifest_schema_notes_array_and_history_consistency():
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    notes = manifest.get("manifest_schema_notes")

    # 1. Array shape
    assert isinstance(notes, list), (
        f"manifest_schema_notes must be a list (was {type(notes).__name__}); "
        "v4.90 Batch 14.7 promoted it from single-string to chronological array"
    )

    # 2. At least 5 entries
    assert len(notes) >= 5, (
        f"manifest_schema_notes must have >= 5 entries "
        f"(v2.0/v2.1 history + Batch 12.1a + 12.1b + 14.3 + 14.8); "
        f"got {len(notes)}"
    )

    # 3. Each entry is a non-empty string
    for i, entry in enumerate(notes):
        assert isinstance(entry, str), (
            f"manifest_schema_notes[{i}] must be a string; got {type(entry).__name__}"
        )
        assert entry.strip(), f"manifest_schema_notes[{i}] is empty"

    # 4. History doc exists
    assert HISTORY_PATH.is_file(), (
        f"MANIFEST_HISTORY.md missing at {HISTORY_PATH}; required since "
        "Batch 14.7 to back the manifest_schema_notes array with long-form rationale"
    )
    history_text = HISTORY_PATH.read_text(encoding="utf-8")

    # 5. Every batch keyword in the array entries must appear in the long-form doc
    all_keywords = set()
    for entry in notes:
        all_keywords.update(_batch_keywords_in_entry(entry))
    # Sanity: we must have extracted at least 4 modern batch markers
    modern_batches = {k for k in all_keywords if k.startswith("Batch ")}
    assert len(modern_batches) >= 4, (
        f"expected >= 4 modern Batch X.Y markers in notes; got {modern_batches}"
    )
    missing = sorted(k for k in all_keywords if k not in history_text)
    assert not missing, (
        f"MANIFEST_HISTORY.md missing references to: {missing}. "
        "Append a section per missing keyword to keep the doc and array in lockstep."
    )
