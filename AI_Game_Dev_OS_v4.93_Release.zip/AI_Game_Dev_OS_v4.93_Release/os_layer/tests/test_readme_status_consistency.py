"""test_readme_status_consistency.py — v4.90 Batch 14 Step 14.2.

Consistency audit C-02 fix guard: V4_90_README.md must reflect
post-RC2 state, not the initial fork (Batch 0) snapshot.

Two stale labels removed in Step 14.2:
1. "状态：working tree（未发布）" — replaced with RC2-cut status
2. "当前批次：Batch 0（v4.89 Roll-up）" — replaced with current
   Batch 14 pointer

Per EP D-14.1.T=T-3: tag stays `v4.90-rc3` at Batch 14 closure.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
README_PATH = REPO_ROOT / "V4_90_README.md"


@pytest.fixture(scope="module")
def readme_text() -> str:
    assert README_PATH.exists(), (
        f"V4_90_README.md missing at {README_PATH}"
    )
    return README_PATH.read_text(encoding="utf-8")


def test_readme_no_stale_working_tree_label(readme_text: str) -> None:
    """Top status card must not still claim "working tree（未发布）".

    The label was correct at Batch 0 (initial fork snapshot) but
    became stale once v4.90-rc1 / v4.90-rc2 were cut. Step 14.2
    replaces it with the post-RC2 status line.
    """
    assert "working tree（未发布）" not in readme_text, (
        "V4_90_README header still labels package as "
        "'working tree（未发布）' — Batch 14 Step 14.2 should "
        "have replaced it with the post-RC2 status line"
    )


def test_readme_batch_pointer_post_batch_13(readme_text: str) -> None:
    """Top status card must not still point at Batch 0.

    The pointer "当前批次：Batch 0（v4.89 Roll-up）" was correct at
    fork time but stayed unchanged across Batch 1..13. Step 14.2
    advances the pointer to Batch 14 (consistency audit).
    """
    assert "当前批次：Batch 0" not in readme_text, (
        "V4_90_README header still points at 'Batch 0' — Batch 14 "
        "Step 14.2 should have advanced the pointer to Batch 14"
    )
