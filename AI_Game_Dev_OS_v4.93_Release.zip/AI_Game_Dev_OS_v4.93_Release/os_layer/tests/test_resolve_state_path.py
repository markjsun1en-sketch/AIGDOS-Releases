"""Tests for verify_beta_sprint_exit._resolve_state_path + _resolve_checklist_path
(v4.89 P0-C C4 + P0-B Pre-Z1)."""
from __future__ import annotations

import json
from pathlib import Path

from verify_beta_sprint_exit import (
    _resolve_checklist_path,
    _resolve_state_path,
)


def test_non_existent_path_returned_unchanged(tmp_path: Path):
    p = tmp_path / "runtime" / "state" / "runtime_state.json"
    # Does not exist, no fallback — path returned as-is.
    assert _resolve_state_path(p) == p


def test_pointer_shim_is_followed(workspace: Path):
    # Create pointer at workspace root.
    (workspace / "runtime_state.json").write_text(json.dumps({
        "_moved_to": "runtime/state/runtime_state.json",
        "canonical": True,
    }))
    canonical = workspace / "runtime" / "state" / "runtime_state.json"
    canonical.parent.mkdir(parents=True)
    canonical.write_text(json.dumps({"runtime_profile": "workbuddy_private"}))

    # Query root pointer path → resolved to canonical.
    resolved = _resolve_state_path(workspace / "runtime_state.json")
    assert resolved.resolve() == canonical.resolve()


def test_legacy_root_fallback_when_canonical_absent(workspace: Path):
    # Pre-C4 workspace: only root has a real state, canonical directory
    # doesn't even exist.
    (workspace / "runtime_state.json").write_text(json.dumps({
        "runtime_profile": "workbuddy_private",
    }))

    # Querying the canonical 3-level path falls back to root.
    resolved = _resolve_state_path(
        workspace / "runtime" / "state" / "runtime_state.json"
    )
    assert resolved.resolve() == (workspace / "runtime_state.json").resolve()


def test_checklist_fallback_docs_to_runtime_state(workspace: Path):
    # Assembled-workspace shape: checklist at docs/09_beta_sprint/.
    docs_checklist = workspace / "docs" / "09_beta_sprint" / "sprint_close_checklist.md"
    docs_checklist.parent.mkdir(parents=True)
    docs_checklist.write_text("# Sprint close checklist\n- [x] test\n")

    # Query the v4.89 default (runtime/state/) — fallback finds docs copy.
    resolved = _resolve_checklist_path(
        workspace / "runtime" / "state" / "sprint_close_checklist.md"
    )
    assert resolved.resolve() == docs_checklist.resolve()
