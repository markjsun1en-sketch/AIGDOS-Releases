"""test_runtime_layer_lint.py — v4.91 F-V-01.

Tests for the runtime-tree leak detection added to
``scripts/governance/lint_layer_separation.py``.

The linter ships TWO independent passes:

  - LAYER 1 content scan (existing): refuses project-name patterns
    inside Layer 1 source/doc/schema files.
  - RUNTIME TREE path scan (new): for each file under
    RUNTIME_TREE_ROOTS, verifies the path segment matches a manifest
    tenant_runtime template AND is bidirectionally claimed by an
    adopting project.

This file covers the runtime-tree pass only — the layer-1 pass is
covered by other tests in this directory.

Coverage matrix (TL1–TL6 from the F-V-01 plan):

  TL1  fixture release tree + acme_demo claim covers the file
       → lint clean.

  TL2  same but yaml lacks runtime_namespace block
       → runtime_tree_leak (no_claim_match).

  TL3  fixture release tree contains a layer-1 source file with
       a project-name literal — even when an adopting project has
       claimed something else, the LAYER 1 PASS still triggers.
       (Runtime tree is not an escape hatch for content scanning.)
       The leak literal is constructed at runtime from a
       non-pattern-matching prefix to keep this source file
       layer-1-clean.

  TL4  README.md / INDEX.md / .keep under runtime tree are exempt
       even when no project claims the directory.

  TL5  vanilla v4.91 tree (no --adopting-project-root) → lint clean.
       Pre-F-V-01 behaviour preserved when no oracle is supplied.

  TL6  cross-tenant squat: project acme_demo claims its own ns,
       file path is under sample_project's ns → runtime_tree_leak.

Layer 1 (OS Spec). No project names — fixture project ids are the
generic placeholders 'acme_demo' / 'sample_project'. The TL3 leak
literal is built at runtime by string concatenation so this source
file itself contains zero project-name patterns.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

_THIS = Path(__file__).resolve()
_REPO = _THIS.parents[2]
_SCRIPT = _REPO / "scripts" / "governance" / "lint_layer_separation.py"

ACME = "acme_demo"
SAMPLE = "sample_project"


# ---------------------------------------------------------------------------
# Fixture builders
# ---------------------------------------------------------------------------


def _minimal_manifest_with_tenant_entry() -> dict:
    return {
        "package_name": "lint_runtime_test",
        "package_root_dir": "lint_runtime_test",
        "manifest_schema_version": "test",
        "exclusions": {
            "self_referential": ["CHECKSUMS.sha", "RELEASE_MANIFEST.json"],
            "transient_patterns": [
                "__pycache__/", ".pytest_cache/", "*.pyc",
                ".DS_Store", "._*",
            ],
            "generated_runtime_outputs": ["exports/**"],
        },
        "classification_rules": {
            "tenant_runtime": "Tenant runtime declarations.",
        },
        "tenant_runtime_entries": [
            {
                "path_template": "ltm/project/<project_id>/**",
                "owning_authority": "adopting_project",
                "purpose": "test",
                "promotion_target": True,
            }
        ],
        "required_manifest_files": [],
        "optional_seed_files": [],
        "test_fixtures": [],
    }


def _build_repo_tree(tmp_path: Path, *,
                     manifest: dict | None = None,
                     runtime_files: dict[str, str] | None = None) -> Path:
    """Create a synthetic repo root with RELEASE_MANIFEST.json plus the
    requested runtime-tree files. The Layer-1 pass will find the
    standard LAYER_1_ROOTS missing under tmp_path (no violations from
    that pass) — this isolates the runtime-tree pass for testing.
    """
    root = tmp_path / "repo"
    root.mkdir(parents=True, exist_ok=True)
    if manifest is not None:
        (root / "RELEASE_MANIFEST.json").write_text(
            json.dumps(manifest, indent=2), encoding="utf-8"
        )
    for rel, content in (runtime_files or {}).items():
        target = root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    return root


def _build_project_yaml(tmp_path: Path, *, project_id: str,
                        claims: list[dict] | None) -> Path:
    root = tmp_path / project_id
    (root / ".ai_dev_os").mkdir(parents=True, exist_ok=True)
    lines = [f"project_id: {project_id}"]
    if claims is not None:
        lines.append("runtime_namespace:")
        lines.append("  claims:")
        for c in claims:
            lines.append(f"    - path_glob: {c['path_glob']}")
            if c.get("matches_template"):
                lines.append(f"      matches_template: {c['matches_template']}")
            if c.get("rationale"):
                lines.append(f"      rationale: {c['rationale']}")
    (root / ".ai_dev_os" / "project_runtime_protocol.yaml").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    return root


def _run_lint(repo_root: Path, *extra_args: str) -> tuple[int, str, str]:
    cmd = [
        sys.executable,
        str(_SCRIPT),
        "--root", str(repo_root),
        *extra_args,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    return proc.returncode, proc.stdout, proc.stderr


# ---------------------------------------------------------------------------
# TL1 — happy path: claimed file, lint clean
# ---------------------------------------------------------------------------


def test_tl1_claimed_runtime_file_is_clean(tmp_path: Path) -> None:
    manifest = _minimal_manifest_with_tenant_entry()
    repo = _build_repo_tree(tmp_path, manifest=manifest, runtime_files={
        f"ltm/project/{ACME}/note.md": "tenant note\n",
    })
    proj = _build_project_yaml(tmp_path, project_id=ACME, claims=[
        {"path_glob": f"ltm/project/{ACME}/**",
         "matches_template": "ltm/project/<project_id>/**",
         "rationale": "test"},
    ])
    rc, out, err = _run_lint(repo, "--adopting-project-root", str(proj))
    assert rc == 0, f"unexpected rc={rc}; out={out!r}; err={err!r}"
    assert "clean" in out


# ---------------------------------------------------------------------------
# TL2 — yaml lacks runtime_namespace → leak
# ---------------------------------------------------------------------------


def test_tl2_unclaimed_runtime_file_leaks(tmp_path: Path) -> None:
    manifest = _minimal_manifest_with_tenant_entry()
    repo = _build_repo_tree(tmp_path, manifest=manifest, runtime_files={
        f"ltm/project/{ACME}/note.md": "unclaimed tenant data\n",
    })
    proj = _build_project_yaml(tmp_path, project_id=ACME, claims=None)
    rc, _, err = _run_lint(repo, "--adopting-project-root", str(proj))
    assert rc == 1
    assert "runtime_tree_leak" in err
    assert f"ltm/project/{ACME}/note.md" in err


# ---------------------------------------------------------------------------
# TL3 — layer-1 content scan still fires inside runtime tree
# ---------------------------------------------------------------------------


def test_tl3_layer_1_content_scan_unaffected_by_runtime_tree_pass(
    tmp_path: Path,
) -> None:
    """The runtime-tree pass operates on PATHS, not content. A layer-1
    content pattern in a layer-1 source file must still be flagged even
    when the linter is invoked with adopting-project-root.

    This test seeds a synthetic layer-1 file under docs/19_tenancy/
    (one of the LAYER_1_ROOTS) containing a project-name literal that
    is in PROJECT_NAME_PATTERNS but not in SELF_REFERENCE_ALLOWLIST;
    the linter must catch it.

    Implementation detail: the leak literal is built at runtime by
    string concatenation so this test source file remains layer-1
    clean (no actual project-name pattern in this .py file).
    """
    # Build the project-name literal at runtime to avoid leaking into
    # this source file. The pattern matched by the linter is exactly
    # the camel-case literal; we assemble it from two halves.
    leak_literal = "Random" + "Heroes"
    manifest = _minimal_manifest_with_tenant_entry()
    repo = _build_repo_tree(tmp_path, manifest=manifest, runtime_files={
        # Place a synthetic layer-1 doc with a real project-name leak.
        # The tenancy case-study exemption pattern is
        # TENANCY_CASE_<UPPER>.md so a plain .md filename without that
        # prefix is NOT exempt.
        "docs/19_tenancy/leak_in_doc.md": (
            f"This doc accidentally mentions {leak_literal} by name.\n"
        ),
    })
    proj = _build_project_yaml(tmp_path, project_id=ACME, claims=[
        {"path_glob": f"ltm/project/{ACME}/**",
         "matches_template": "ltm/project/<project_id>/**",
         "rationale": "test"},
    ])
    rc, _, err = _run_lint(repo, "--adopting-project-root", str(proj))
    assert rc == 1
    assert "docs/19_tenancy/leak_in_doc.md" in err
    # Confirm the layer-1 label fires (not the runtime-tree label).
    assert "project name" in err.lower() or leak_literal in err


# ---------------------------------------------------------------------------
# TL4 — generic scaffolding files exempt
# ---------------------------------------------------------------------------


def test_tl4_generic_scaffolding_files_are_exempt(tmp_path: Path) -> None:
    """README.md / INDEX.md / .keep under runtime tree are generic
    Core-shipped scaffolding; they must not trigger leaks even when no
    project claims the directory."""
    manifest = _minimal_manifest_with_tenant_entry()
    repo = _build_repo_tree(tmp_path, manifest=manifest, runtime_files={
        "ltm/project/README.md": "# generic readme\n",
        "ltm/project/INDEX.md": "# generic index\n",
        f"ltm/project/{ACME}/.keep": "",
    })
    proj = _build_project_yaml(tmp_path, project_id=ACME, claims=[
        {"path_glob": f"ltm/project/{ACME}/**",
         "matches_template": "ltm/project/<project_id>/**",
         "rationale": "test"},
    ])
    rc, out, err = _run_lint(repo, "--adopting-project-root", str(proj))
    assert rc == 0, f"unexpected rc={rc}; out={out!r}; err={err!r}"


# ---------------------------------------------------------------------------
# TL5 — vanilla tree, no oracle → clean (pre-F-V-01 behaviour)
# ---------------------------------------------------------------------------


def test_tl5_no_adopting_root_no_violations(tmp_path: Path) -> None:
    """Without --adopting-project-root and with no trial_workspaces/*
    yaml in scope, the runtime-tree pass must short-circuit. Even
    paths that would otherwise leak remain unflagged."""
    manifest = _minimal_manifest_with_tenant_entry()
    repo = _build_repo_tree(tmp_path, manifest=manifest, runtime_files={
        f"ltm/project/{ACME}/note.md": "would leak with oracle\n",
    })
    rc, out, err = _run_lint(repo)
    assert rc == 0, f"unexpected rc={rc}; out={out!r}; err={err!r}"
    assert "clean" in out
    assert "runtime tree root" in out  # confirms F-V-01 banner


# ---------------------------------------------------------------------------
# TL6 — cross-tenant squat
# ---------------------------------------------------------------------------


def test_tl6_cross_tenant_squat_leaks(tmp_path: Path) -> None:
    """File path uses project A's ns but only project B has a yaml +
    claim. reconcile_path returns CROSS_TENANT_SQUAT (B's claim covers
    a path whose substituted pid is A) → leak."""
    manifest = _minimal_manifest_with_tenant_entry()
    repo = _build_repo_tree(tmp_path, manifest=manifest, runtime_files={
        f"ltm/project/{ACME}/squatted.md": "squat\n",
    })
    # Only sample_project supplies a yaml — and it claims acme_demo's ns.
    proj = _build_project_yaml(tmp_path, project_id=SAMPLE, claims=[
        {"path_glob": f"ltm/project/{ACME}/**",
         "matches_template": "ltm/project/<project_id>/**",
         "rationale": "squat attempt"},
    ])
    rc, _, err = _run_lint(repo, "--adopting-project-root", str(proj))
    assert rc == 1
    assert f"ltm/project/{ACME}/squatted.md" in err
    assert "runtime_tree_leak" in err
    assert "cross_tenant_squat" in err


# ---------------------------------------------------------------------------
# Anti-pattern guard — no --allow-extra / --skip-tenant flags
# ---------------------------------------------------------------------------


def test_no_escape_hatch_flags_on_lint(tmp_path: Path) -> None:
    """The linter must reject --allow-extra / --skip-tenant flags."""
    manifest = _minimal_manifest_with_tenant_entry()
    repo = _build_repo_tree(tmp_path, manifest=manifest)
    for forbidden in ("--allow-extra", "--skip-tenant"):
        proc = subprocess.run(
            [sys.executable, str(_SCRIPT), "--root", str(repo), forbidden],
            capture_output=True, text=True, timeout=10,
        )
        assert proc.returncode != 0, (
            f"linter accepted forbidden flag: {forbidden}"
        )
