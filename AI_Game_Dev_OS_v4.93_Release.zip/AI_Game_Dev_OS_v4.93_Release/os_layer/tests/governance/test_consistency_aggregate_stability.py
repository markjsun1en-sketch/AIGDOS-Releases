"""test_consistency_aggregate_stability.py — v4.90 Batch 14.14 (v4.90.7 patch).

External-sandbox replay revealed the C8 consistency-aggregate could
hang in environments where (a) the regressions router was scheduled
before the schema-self-validation pytest sub-suite, and (b) external
pytest plugins (coverage trackers, distributed runners, third-party
hooks) were installed workspace-wide and got auto-loaded into the
sub-suite via PYTEST_PLUGIN_AUTOLOAD's default. The v4.90.7 patch
addressed both: reorder schema_self_validation ahead of
required_regressions, and inject PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
into the schema-self-validation subprocess. It also added a
`--timeout SECS` CLI flag so closure-gate consumers can lift the
per-check budget without source-patching.

3 tests:

    1. test_check_order_schema_before_regressions: the CHECKS list
       in scripts/governance/check_consistency_aggregate.py has
       schema_self_validation at index 4 (zero-based) and
       required_regressions at index 5. Guards against future re-
       reorderings that would re-introduce the hang.
    2. test_aggregate_advertises_timeout_flag: --help output
       advertises the new --timeout flag with default 180.
    3. test_isolated_pytest_names_includes_schema_self_validation:
       the ISOLATED_PYTEST_NAMES marker set is non-empty and at
       minimum contains 'schema_self_validation' so
       PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 is set when that subprocess
       runs.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import importlib.util
import sys
import tempfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1].parent
SCRIPT = REPO_ROOT / "scripts" / "governance" / "check_consistency_aggregate.py"

if str(REPO_ROOT / "scripts" / "governance") not in sys.path:
    sys.path.insert(0, str(REPO_ROOT / "scripts" / "governance"))

from _process_runner import run_pg_safe_to_file_v2  # noqa: E402


def _load_module():
    spec = importlib.util.spec_from_file_location(
        "check_consistency_aggregate", str(SCRIPT)
    )
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def test_check_order_schema_before_regressions():
    """Guard against re-introducing the v4.90.6-era hang ordering.

    Pre-v4.90.7 ordering placed `required_regressions` at index 4
    and `schema_self_validation` at index 5. External sandbox
    replays showed this could deadlock under workspace-wide pytest
    plugins. v4.90.7 swapped the two so the pure-pytest sub-suite
    flushes the plugin-load cache cleanly before the regressions
    router runs.
    """
    mod = _load_module()
    names = [c[0] for c in mod.CHECKS]
    assert "schema_self_validation" in names
    assert "required_regressions" in names
    assert names.index("schema_self_validation") < names.index(
        "required_regressions"
    ), (
        "schema_self_validation must run before required_regressions "
        "post v4.90.7 — see scripts/governance/check_consistency_"
        "aggregate.py docstring."
    )


def test_aggregate_advertises_timeout_flag():
    cmd = [sys.executable, str(SCRIPT), "--help"]
    with tempfile.TemporaryDirectory(prefix="agg_stab_") as td:
        tmp = Path(td)
        r = run_pg_safe_to_file_v2(
            cmd,
            cwd=str(REPO_ROOT),
            timeout=30,
            stdout_path=tmp / "stdout",
            stderr_path=tmp / "stderr",
            cleanup_process_group_on_exit=True,
        )
    assert r.rc == 0, r.stdout + r.stderr
    out = r.stdout
    assert "--timeout" in out, "aggregate --help missing --timeout flag"
    assert "default 180" in out, (
        "aggregate --help should document the default 180s per-check "
        "timeout"
    )


def test_isolated_pytest_names_includes_schema_self_validation():
    """Guard against forgetting the PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
    isolation for the pytest-driven sub-check.

    Without this isolation the schema-self-validation subprocess
    inherits any workspace-wide pytest plugins and can hang in
    environments where coverage / distributed / third-party hooks
    are present. ISOLATED_PYTEST_NAMES is the marker set
    aggregate() consults to decide which subprocesses get the
    disable-autoload env var.
    """
    mod = _load_module()
    assert hasattr(mod, "ISOLATED_PYTEST_NAMES"), (
        "ISOLATED_PYTEST_NAMES marker set missing from "
        "check_consistency_aggregate.py"
    )
    assert "schema_self_validation" in mod.ISOLATED_PYTEST_NAMES
