"""test_schema_self_validation.py — v4.90 Batch 3 Step 3.

Validates that the 4 governance + protocol schemas:
1. Are themselves valid JSON Schema draft-07 documents (meta-validation).
2. Accept a happy-path fixture instance.
3. Reject specific invalid variants (additionalProperties false, missing
   required, const mismatch, enum violation).

Uses jsonschema as a soft dependency via pytest.importorskip — projects
without the lib auto-skip rather than failing CI. Aligns with the
v4.89 zero-external-dep discipline.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")


REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_GOVERNANCE = REPO_ROOT / "schemas" / "governance"
SCHEMA_PROTOCOL = REPO_ROOT / "schemas" / "protocol"


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


# --------- Meta-validation (schemas are themselves valid) ----------------

@pytest.mark.parametrize("rel", [
    "governance/state_surface_policy.schema.json",
    "governance/cold_start_readset.schema.json",
    "governance/registry_sync_guard.schema.json",
    "protocol/project_runtime_protocol.schema.json",
])
def test_schema_meta_valid(rel):
    schema = _load(REPO_ROOT / "schemas" / rel)
    # raises SchemaError on bad meta
    jsonschema.Draft7Validator.check_schema(schema)


# --------- state_surface_policy.schema.json ------------------------------

def _state_surface_policy_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "surfaces": [
            {
                "surface_kind": "sprint_board",
                "tier": 1,
                "path": "tasks/sprint_board.md",
                "line_count_policy": "standard",
            }
        ],
        "archive_strategy": "by_sprint",
        "indexes": {
            "sprint_index": "tasks/sprint_index.md",
            "task_index": "tasks/task_index.md",
            "agents_index": "logs/agents/index.md",
            "orchestrator_decision_index": "logs/orchestrator_decision_index.md",
        },
    }


def test_state_surface_policy_happy_validates():
    schema = _load(SCHEMA_GOVERNANCE / "state_surface_policy.schema.json")
    jsonschema.validate(_state_surface_policy_happy(), schema)


def test_state_surface_policy_indexes_minimum_4key_required():
    schema = _load(SCHEMA_GOVERNANCE / "state_surface_policy.schema.json")
    instance = _state_surface_policy_happy()
    # remove sprint_index
    del instance["indexes"]["sprint_index"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance, schema)


def test_state_surface_policy_extra_root_property_rejected():
    schema = _load(SCHEMA_GOVERNANCE / "state_surface_policy.schema.json")
    instance = _state_surface_policy_happy()
    instance["unexpected_root_key"] = "boom"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance, schema)


# --------- cold_start_readset.schema.json --------------------------------

def _cold_start_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "enabled": True,
        "os_minimum_paths": [
            ".ai_dev_os/project_runtime_protocol.yaml",
            "logs/agents/index.md",
            "tasks/sprint_board.md",
            "tasks/sprint_index.md",
            "tasks/task_index.md",
            "logs/orchestrator_log.md",
            "logs/open_issues.md",
        ],
    }


def test_cold_start_happy_validates():
    schema = _load(SCHEMA_GOVERNANCE / "cold_start_readset.schema.json")
    jsonschema.validate(_cold_start_happy(), schema)


def test_cold_start_const_mismatch_rejected():
    """Reordering os_minimum_paths breaks the const array contract."""
    schema = _load(SCHEMA_GOVERNANCE / "cold_start_readset.schema.json")
    instance = _cold_start_happy()
    # swap first two entries — same items, wrong order
    instance["os_minimum_paths"][0], instance["os_minimum_paths"][1] = (
        instance["os_minimum_paths"][1], instance["os_minimum_paths"][0],
    )
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance, schema)


def test_cold_start_extra_property_rejected():
    schema = _load(SCHEMA_GOVERNANCE / "cold_start_readset.schema.json")
    instance = _cold_start_happy()
    instance["unknown_field"] = 123
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance, schema)


# --------- registry_sync_guard.schema.json -------------------------------

def _sync_guard_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "preserve_historical_rows": True,
        "strip_markdown_markers": True,
        "refuse_silent_deletion": True,
        "dry_run_supported": True,
    }


def test_sync_guard_happy_validates():
    schema = _load(SCHEMA_GOVERNANCE / "registry_sync_guard.schema.json")
    jsonschema.validate(_sync_guard_happy(), schema)


def test_sync_guard_const_violation():
    schema = _load(SCHEMA_GOVERNANCE / "registry_sync_guard.schema.json")
    instance = _sync_guard_happy()
    instance["preserve_historical_rows"] = False
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance, schema)


# --------- project_runtime_protocol.schema.json --------------------------

def _protocol_happy() -> dict:
    return {
        "schema_version": "1.0.0",
        "project_id": "acme_demo",
        "project_name": "Acme Demo",
        "project_runtime_protocol": {
            "legacy_project_version": "4.82",
            "mounted_core_version": "4.89",
            "target_protocol_version": "4.90",
            "compatibility_mode": "progressive_adoption",
        },
        "host": {"primary_host": "claude_code"},
        "governance": {
            "state_surface_governance": {
                "enabled": True,
                "line_count_policy": "standard",
                "archive_strategy": "by_sprint",
                "cold_start_minimum_contract": "enabled",
            },
        },
    }


def test_protocol_happy_validates():
    schema = _load(SCHEMA_PROTOCOL / "project_runtime_protocol.schema.json")
    jsonschema.validate(_protocol_happy(), schema)


def test_protocol_governance_invalid_enum_rejected():
    schema = _load(SCHEMA_PROTOCOL / "project_runtime_protocol.schema.json")
    instance = _protocol_happy()
    instance["governance"]["state_surface_governance"]["line_count_policy"] = "ultra"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance, schema)


def test_protocol_root_additional_property_rejected():
    schema = _load(SCHEMA_PROTOCOL / "project_runtime_protocol.schema.json")
    instance = _protocol_happy()
    instance["unexpected_root"] = "boom"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance, schema)


def test_protocol_governance_node_missing_enabled_rejected():
    schema = _load(SCHEMA_PROTOCOL / "project_runtime_protocol.schema.json")
    instance = _protocol_happy()
    del instance["governance"]["state_surface_governance"]["enabled"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance, schema)
