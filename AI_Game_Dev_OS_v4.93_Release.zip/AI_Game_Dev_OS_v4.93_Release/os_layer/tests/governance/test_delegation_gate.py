"""test_delegation_gate.py — v4.91 Addendum-C c3.

Covers scripts/governance/validate_delegation_decisions.py contract:
envelope shape, LOCAL enum binding, cross-line uniqueness, amends
referential integrity. Layer 1 (OS Spec). No project names; fixture
event_ids use opaque placeholders (dd_aaaaaaaa, dd_bbbbbbbb, ...).

These tests assert the *shape* of decision-record entries only — they
never treat a passing validator run as evidence that any task has been
completed (Charter anti-pattern #11 compliant).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

V491_ROOT = Path(__file__).resolve().parent.parent.parent
if str(V491_ROOT) not in sys.path:
    sys.path.insert(0, str(V491_ROOT))

from scripts.governance.validate_delegation_decisions import (  # noqa: E402
    EXIT_OK,
    EXIT_VIOLATION,
    validate_ledger,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _envelope(
    event_id: str,
    result: str,
    audit_status: str,
    *,
    reason_code: str | None = None,
    amends: str | None = None,
    required_evidence=("ev_smoke",),
) -> dict:
    """Build a minimal valid 9-field envelope dict for fixture lines."""
    details: dict = {
        "parent": "agent_alpha",
        "owner": "agent_beta",
        "subtask": "smoke decision",
        "allowed_write_set": ["scratch.md"],
        "expected_output": "patch",
        "required_evidence": list(required_evidence),
        "writeback_target": "logs/orchestrator_log.md",
    }
    if reason_code is not None:
        details["reason_code"] = reason_code
    if amends is not None:
        details["amends"] = amends
    return {
        "schema_version": "1.0.0",
        "event_id": event_id,
        "event_type": "delegation_decision",
        "timestamp": "2026-05-25T03:00:00Z",
        "actor": "orchestrator",
        "runtime_profile": "default",
        "result": result,
        "source_layer": "L1",
        "audit_status": audit_status,
        "details": details,
    }


def _write_ledger(tmp_path: Path, *entries: dict) -> Path:
    p = tmp_path / "ledger.jsonl"
    if entries:
        body = "\n".join(json.dumps(e) for e in entries) + "\n"
    else:
        body = ""
    p.write_text(body, encoding="utf-8")
    return p


def _rules(report) -> list[str]:
    return [v.rule for v in report.violations]


# ---------------------------------------------------------------------------
# 1. Empty ledger
# ---------------------------------------------------------------------------


def test_empty_ledger_passes(tmp_path):
    ledger = _write_ledger(tmp_path)  # no entries → empty file
    report = validate_ledger(ledger)
    assert report.is_clean(), report.violations
    assert report.n_entries == 0
    assert report.n_lines == 0


# ---------------------------------------------------------------------------
# 2. Happy path: SPAWN_SUBAGENT recorded
# ---------------------------------------------------------------------------


def test_valid_spawn_subagent_recorded_entry(tmp_path):
    entry = _envelope("dd_aaaaaaaa", "SPAWN_SUBAGENT", "recorded")
    ledger = _write_ledger(tmp_path, entry)
    report = validate_ledger(ledger)
    assert report.is_clean(), report.violations
    assert report.n_entries == 1


# ---------------------------------------------------------------------------
# 3. LOCAL with reason_code (closed enum, happy path)
# ---------------------------------------------------------------------------


def test_valid_local_with_reason_code_passes(tmp_path):
    entry = _envelope(
        "dd_bbbbbbbb", "LOCAL", "recorded", reason_code="LOCAL_TINY"
    )
    ledger = _write_ledger(tmp_path, entry)
    report = validate_ledger(ledger)
    assert report.is_clean(), report.violations


# ---------------------------------------------------------------------------
# 4. ESCALATE may carry empty required_evidence
# ---------------------------------------------------------------------------


def test_escalate_allows_empty_required_evidence(tmp_path):
    entry = _envelope(
        "dd_cccccccc", "ESCALATE", "recorded", required_evidence=()
    )
    ledger = _write_ledger(tmp_path, entry)
    report = validate_ledger(ledger)
    assert report.is_clean(), report.violations


# ---------------------------------------------------------------------------
# 5. LOCAL missing reason_code → reason_code.required_for_LOCAL
# ---------------------------------------------------------------------------


def test_local_missing_reason_code_fails(tmp_path):
    entry = _envelope("dd_dddddddd", "LOCAL", "recorded")  # no reason_code
    ledger = _write_ledger(tmp_path, entry)
    report = validate_ledger(ledger)
    assert not report.is_clean()
    assert "details.reason_code.required_for_LOCAL" in _rules(report)


# ---------------------------------------------------------------------------
# 6. LOCAL with unknown reason_code → enum violation
# ---------------------------------------------------------------------------


def test_local_with_unknown_reason_code_fails(tmp_path):
    entry = _envelope(
        "dd_eeeeeeee",
        "LOCAL",
        "recorded",
        reason_code="LOCAL_OTHER",  # not in 5-element enum
    )
    ledger = _write_ledger(tmp_path, entry)
    report = validate_ledger(ledger)
    assert not report.is_clean()
    assert "details.reason_code.enum" in _rules(report)


# ---------------------------------------------------------------------------
# 7. event_id pattern violation
# ---------------------------------------------------------------------------


def test_invalid_event_id_pattern_fails(tmp_path):
    # Wrong prefix + uppercase hex → pattern fail
    entry = _envelope("xx_AAAAAAAA", "SPAWN_SUBAGENT", "recorded")
    ledger = _write_ledger(tmp_path, entry)
    report = validate_ledger(ledger)
    assert not report.is_clean()
    assert "event_id.pattern" in _rules(report)


# ---------------------------------------------------------------------------
# 8. Duplicate event_id across recorded lines
# ---------------------------------------------------------------------------


def test_duplicate_event_id_across_lines_fails(tmp_path):
    e1 = _envelope("dd_ffffffff", "SPAWN_SUBAGENT", "recorded")
    e2 = _envelope("dd_ffffffff", "ESCALATE", "recorded")  # same event_id
    ledger = _write_ledger(tmp_path, e1, e2)
    report = validate_ledger(ledger)
    assert not report.is_clean()
    assert "event_id.unique" in _rules(report)


# ---------------------------------------------------------------------------
# 9. Amends referencing an event_id that never appeared earlier
# ---------------------------------------------------------------------------


def test_amends_unresolved_reference_fails(tmp_path):
    # Single-line ledger with audit_status=amended pointing at an
    # event_id that does not exist anywhere in this ledger.
    entry = _envelope(
        "dd_11111111",
        "SPAWN_SUBAGENT",
        "amended",
        amends="dd_99999999",
    )
    ledger = _write_ledger(tmp_path, entry)
    report = validate_ledger(ledger)
    assert not report.is_clean()
    assert "details.amends.unresolved" in _rules(report)


# ---------------------------------------------------------------------------
# 10. amends required iff audit_status ∈ {amended, withdrawn};
#     forbidden when audit_status == "recorded".  Two negative
#     branches asserted in one test body.
# ---------------------------------------------------------------------------


def test_amends_required_iff_amended_branches(tmp_path):
    # Branch A: recorded MUST NOT carry amends.
    bad_recorded = _envelope(
        "dd_22222222",
        "SPAWN_SUBAGENT",
        "recorded",
        amends="dd_33333333",
    )
    ledger_a = tmp_path / "a.jsonl"
    ledger_a.write_text(json.dumps(bad_recorded) + "\n", encoding="utf-8")
    report_a = validate_ledger(ledger_a)
    assert not report_a.is_clean()
    assert "details.amends.forbidden" in _rules(report_a)

    # Branch B: amended MUST carry amends.  Use a genuine prior recorded
    # line so the only failing rule is the missing amends on line 2.
    prior = _envelope("dd_44444444", "SPAWN_SUBAGENT", "recorded")
    bad_amended = _envelope("dd_55555555", "SPAWN_SUBAGENT", "amended")
    # No amends key set → required violation expected.
    ledger_b = tmp_path / "b.jsonl"
    ledger_b.write_text(
        json.dumps(prior) + "\n" + json.dumps(bad_amended) + "\n",
        encoding="utf-8",
    )
    report_b = validate_ledger(ledger_b)
    assert not report_b.is_clean()
    assert "details.amends.required" in _rules(report_b)


# ---------------------------------------------------------------------------
# 11. CLI smoke: exit 0 on empty ledger, exit 1 on synthetic FAIL ledger
# ---------------------------------------------------------------------------


def test_cli_exit_codes(tmp_path, run_script):
    # 11a — empty ledger → EXIT_OK (0)
    empty = tmp_path / "empty.jsonl"
    empty.write_text("", encoding="utf-8")
    res_ok = run_script(
        "validate_delegation_decisions.py",
        "--ledger",
        str(empty),
    )
    res_ok.expect(EXIT_OK)

    # 11b — LOCAL missing reason_code → EXIT_VIOLATION (1)
    bad = _envelope("dd_66666666", "LOCAL", "recorded")  # no reason_code
    bad_ledger = tmp_path / "bad.jsonl"
    bad_ledger.write_text(json.dumps(bad) + "\n", encoding="utf-8")
    res_fail = run_script(
        "validate_delegation_decisions.py",
        "--ledger",
        str(bad_ledger),
    )
    res_fail.expect(EXIT_VIOLATION)
    assert "reason_code" in (res_fail.stdout + res_fail.stderr)
