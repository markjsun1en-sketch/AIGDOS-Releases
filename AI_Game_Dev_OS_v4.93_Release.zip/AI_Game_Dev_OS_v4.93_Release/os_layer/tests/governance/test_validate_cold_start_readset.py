"""test_validate_cold_start_readset.py — v4.90 Batch 3 Step 2.

Validates the readset checker: 7-canonical contract, file existence,
size cap, archive marker, forbidden patterns, project_extensions.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import textwrap


SCRIPT = "validate_cold_start_readset.py"


def test_happy_seven_canonical_paths(make_project, run_script):
    root = make_project()
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(0)
    assert "valid" in res.stdout


def test_count_other_than_seven(make_project, run_script):
    bad = textwrap.dedent("""\
        enabled: true
        os_minimum_paths:
          - .ai_dev_os/project_runtime_protocol.yaml
          - logs/agents/index.md
          - tasks/sprint_board.md
        """)
    root = make_project(custom_readset_yaml=bad)
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "exactly 7" in res.stderr


def test_canonical_value_mismatch(make_project, run_script):
    # swap order to break value-equality contract
    bad = textwrap.dedent("""\
        enabled: true
        os_minimum_paths:
          - logs/agents/index.md
          - .ai_dev_os/project_runtime_protocol.yaml
          - tasks/sprint_board.md
          - tasks/sprint_index.md
          - tasks/task_index.md
          - logs/orchestrator_log.md
          - logs/open_issues.md
        """)
    root = make_project(custom_readset_yaml=bad)
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "contract_value" in res.stderr


def test_missing_file_violation(make_project, run_script):
    root = make_project()
    # delete a canonical file
    (root / "logs" / "open_issues.md").unlink()
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "logs/open_issues.md" in res.stderr
    assert "not_found" in res.stderr


def test_archive_marker_violation(make_project, run_script):
    root = make_project()
    (root / "tasks" / "sprint_board.md").write_text(
        "DO NOT LOAD BY DEFAULT — archived\n", encoding="utf-8",
    )
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "archive_marker" in res.stderr


def test_oversize_violation(make_project, run_script):
    root = make_project()
    big = "x" * (60 * 1024)
    (root / "tasks" / "sprint_board.md").write_text(big, encoding="utf-8")
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "oversize" in res.stderr


def test_forbidden_path_pattern(make_project, run_script):
    bad = textwrap.dedent("""\
        enabled: true
        os_minimum_paths:
          - .ai_dev_os/project_runtime_protocol.yaml
          - logs/agents/index.md
          - tasks/sprint_board.md
          - tasks/sprint_index.md
          - tasks/task_index.md
          - logs/orchestrator_log.md
          - logs/open_issues.md
        project_extensions:
          - exports/cached_summary.md
        """)
    root = make_project(custom_readset_yaml=bad)
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "forbidden_path" in res.stderr


def test_project_extension_existence_checked(make_project, run_script):
    # project extension that doesn't exist
    bad = textwrap.dedent("""\
        enabled: true
        os_minimum_paths:
          - .ai_dev_os/project_runtime_protocol.yaml
          - logs/agents/index.md
          - tasks/sprint_board.md
          - tasks/sprint_index.md
          - tasks/task_index.md
          - logs/orchestrator_log.md
          - logs/open_issues.md
        project_extensions:
          - tasks/summaries/active.md
        """)
    root = make_project(custom_readset_yaml=bad)
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "tasks/summaries/active.md" in res.stderr
    assert "not_found" in res.stderr


def test_missing_readset_returns_4(tmp_path, run_script):
    res = run_script(SCRIPT, "--project-root", str(tmp_path))
    res.expect(4)
    assert "readset not found" in res.stderr
