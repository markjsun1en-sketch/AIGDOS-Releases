"""test_v4_92_successor_overlay.py — v4.92 successor baseline + deliverables.

Lock down the dispatcher's v4.92 successor layer that wraps the frozen
RC3 closure gate. The C1/C2 baseline override applies ONLY to the JSON
output path of `--profile full`; the C9-C13 deliverable overlay applies
only when `--skip-deliverables` is not set.

v4.91 P9' c1 (RC2, 2026-05-29) bumped the override constants
1401/2/55 → 1733/4/67 to reflect the post M-H + Hygiene-1 baseline.
RC2 c3 (2026-05-30) bumped the pytest count 1735 → **1762** after the
P0/P1 additions (+27 tests) and the RC2 c1/c2 test alignments.
RC2-FC2 P0-2 (2026-05-30) bumped 1762 → **1763** after adding the
second-level legacy-wrapper killpg regression (the 3rd-review F6 leak).
v4.92-Capability_Foundation (Batch 9, 2026-05-31, EP-approved) re-based
1763/2/67 → **1874/2/72** to absorb the v4.92 capability stack
(B1–B8 + B5.5 = +111 tests; B7 added packs/ lint roots = +5 roots).
v4.92 B12 re-based 1874/2/72 → **1946/2/72** to absorb B10/B11/B11.5
and B12 evidence-gate hardening. B13 adds v4.92-specific release-dir
deliverable checks for C9-C13 so the dispatcher can no longer accept the
old RC3 v4.90 release artifacts as final v4.92 closure evidence, lifting
the focused baseline to **1949/2/72**.

Layer 1 (OS Spec). No project names; opaque envelopes only.
"""
from __future__ import annotations

import importlib.util
import json
import sys
import types
from pathlib import Path
from unittest.mock import patch

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
DISPATCHER = REPO_ROOT / "scripts" / "governance" / "run_release_closure_gate.py"


@pytest.fixture(scope="module")
def dispatcher():
    spec = importlib.util.spec_from_file_location("_dispatcher_t", DISPATCHER)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["_dispatcher_t"] = mod
    spec.loader.exec_module(mod)
    return mod


def _make_rc3_stub(payload: dict):
    """Return a fake RC3 module whose main() prints `payload` as JSON."""
    stub = types.ModuleType("_rc3_stub")

    def fake_main(argv=None):
        print(json.dumps(payload))
        return 0 if payload.get("overall") == 0 else 1

    stub.main = fake_main
    return stub


def _run_full(
    dispatcher_mod,
    rc3_payload,
    *,
    format: str = "json",
    skip_deliverables: bool = True,
) -> tuple[int, dict]:
    """Run dispatcher.run_full with a stubbed RC3 and capture the result."""
    import io
    import contextlib

    stub = _make_rc3_stub(rc3_payload)

    args = type("A", (), {"format": format, "skip_deliverables": skip_deliverables})()

    with patch.object(dispatcher_mod, "_load_rc3_gate", return_value=stub):
        captured = io.StringIO()
        with contextlib.redirect_stdout(captured):
            rc = dispatcher_mod.run_full(args, [])
    text = captured.getvalue()
    if format == "json":
        # Strip the banner that _print_banner emits before the JSON.
        # The override emits a single JSON object on stdout.
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            # banner + json
            import re
            m = re.search(r"\n\{", text)
            data = json.loads(text[m.start():]) if m else {}
        return rc, data
    return rc, {}


# ---------------------------------------------------------------------------
# 1. Successor constants reflect the current v4.92 baseline.
# ---------------------------------------------------------------------------


def test_baseline_constants_reflect_v4_92(dispatcher):
    assert dispatcher.EXPECTED_PYTEST_V4_92 == 1949
    assert dispatcher.EXPECTED_PYTEST_SKIPPED_V4_92 == 2
    assert dispatcher.EXPECTED_LAYER1_ROOTS_V4_92 == 72


# ---------------------------------------------------------------------------
# 2. C1 fail with v4.92 expected count is upgraded to PASS.
# ---------------------------------------------------------------------------


def test_c1_fail_with_v4_92_count_lifts_to_pass(dispatcher):
    payload = {
        "overall": 1,
        "results": [
            {"id": "C1", "label": "pytest", "ok": False,
             "summary": "got 1949/2 (expected 953/2)"},
            {"id": "C2", "label": "lint", "ok": True, "summary": "got 33 roots / 0 violations"},
        ],
    }
    rc, env = _run_full(dispatcher, payload)
    c1 = next(r for r in env["results"] if r["id"] == "C1")
    assert c1["ok"] is True
    assert "v4.92 baseline" in c1["summary"]
    assert "RC3 v4.90 baseline superseded" in c1["summary"]
    assert "C1" in env["v4_92_overrides"]


# ---------------------------------------------------------------------------
# 3. C2 fail with v4.92 expected roots is upgraded to PASS.
# ---------------------------------------------------------------------------


def test_c2_fail_with_v4_92_roots_lifts_to_pass(dispatcher):
    payload = {
        "overall": 1,
        "results": [
            {"id": "C1", "label": "pytest", "ok": True, "summary": "got 953/2 (expected 953/2)"},
            {"id": "C2", "label": "lint", "ok": False, "summary": "got 72 roots / 0 violations (expected 33/0)"},
        ],
    }
    rc, env = _run_full(dispatcher, payload)
    c2 = next(r for r in env["results"] if r["id"] == "C2")
    assert c2["ok"] is True
    assert "v4.92 baseline" in c2["summary"]
    assert "C2" in env["v4_92_overrides"]


# ---------------------------------------------------------------------------
# 4. C1 fail with NON-v4.92 count flows through unchanged.
# ---------------------------------------------------------------------------


def test_c1_fail_with_non_v4_92_count_flows_through(dispatcher):
    payload = {
        "overall": 1,
        "results": [
            {"id": "C1", "label": "pytest", "ok": False,
             "summary": "got 999/0 (expected 953/2)"},
        ],
    }
    rc, env = _run_full(dispatcher, payload)
    c1 = env["results"][0]
    assert c1["ok"] is False
    assert "RC3" not in c1["summary"]
    assert "C1" not in env.get("v4_92_overrides", [])


# ---------------------------------------------------------------------------
# 5. Both override + recompute overall to 0 on full match.
# ---------------------------------------------------------------------------


def test_overall_recomputes_to_pass_when_only_overridable_fails(dispatcher):
    payload = {
        "overall": 1,
        "results": [
            {"id": "C1", "label": "pytest", "ok": False,
             "summary": "got 1949/2 (expected 953/2)"},
            {"id": "C2", "label": "lint", "ok": False,
             "summary": "got 72 roots / 0 violations (expected 33/0)"},
            {"id": "C3", "label": "byte-lock", "ok": True, "summary": "ok"},
        ],
    }
    rc, env = _run_full(dispatcher, payload)
    assert env["overall"] == 0
    assert sorted(env["v4_92_overrides"]) == ["C1", "C2"]
    assert rc == 0


# ---------------------------------------------------------------------------
# 6. Non-overridable fail keeps overall=1 even with C1/C2 lifted.
# ---------------------------------------------------------------------------


def test_non_c1_c2_fail_keeps_overall_failed(dispatcher):
    payload = {
        "overall": 1,
        "results": [
            {"id": "C1", "label": "pytest", "ok": False,
             "summary": "got 1949/2 (expected 953/2)"},
            {"id": "C5", "label": "v4.89 audit", "ok": False, "summary": "Class C: 7"},
        ],
    }
    rc, env = _run_full(dispatcher, payload)
    assert env["overall"] == 1
    # C1 still gets lifted (override applies independently of overall result)
    c1 = next(r for r in env["results"] if r["id"] == "C1")
    assert c1["ok"] is True
    # C5 stays failed (not in override set)
    c5 = next(r for r in env["results"] if r["id"] == "C5")
    assert c5["ok"] is False
    assert rc == 1


# ---------------------------------------------------------------------------
# 7. Skipped (ok=None) entries (e.g. --skip-deliverables) are treated
# as not-failing for overall recomputation.
# ---------------------------------------------------------------------------


def test_skipped_entries_do_not_fail_overall(dispatcher):
    payload = {
        "overall": 0,
        "results": [
            {"id": "C9", "label": "deliverable", "ok": None, "summary": "SKIPPED"},
            {"id": "C10", "label": "deliverable", "ok": None, "summary": "SKIPPED"},
        ],
    }
    rc, env = _run_full(dispatcher, payload)
    assert env["overall"] == 0
    assert env["v4_92_deliverable_overlay"] == []
    assert rc == 0


# ---------------------------------------------------------------------------
# 8. Without --skip-deliverables, C9-C13 are v4.92 release-dir checks.
# ---------------------------------------------------------------------------


def test_v4_92_deliverable_overlay_rejects_missing_release_dir(dispatcher, tmp_path):
    payload = {
        "overall": 0,
        "results": [
            {"id": "C9", "label": "old release notes", "ok": True, "summary": "old ok"},
            {"id": "C10", "label": "old changelog", "ok": True, "summary": "old ok"},
            {"id": "C11", "label": "old readme", "ok": True, "summary": "old ok"},
            {"id": "C12", "label": "old tag", "ok": True, "summary": "old ok"},
            {"id": "C13", "label": "old daily log", "ok": True, "summary": "old ok"},
        ],
    }

    with patch.object(dispatcher, "WORKSPACE_ROOT", tmp_path), \
         patch.object(dispatcher, "REPO_ROOT", tmp_path / "AI_Game_Dev_OS_v4.92"):
        rc, env = _run_full(dispatcher, payload, skip_deliverables=False)

    assert rc == 1
    assert env["overall"] == 1
    assert env["v4_92_deliverable_overlay"] == ["C9", "C10", "C11", "C12", "C13"]
    for cid in ["C9", "C10", "C11", "C13"]:
        row = next(r for r in env["results"] if r["id"] == cid)
        assert row["ok"] is False
        assert "AI_Game_Dev_OS_v4.92_Release missing" in row["summary"]


# ---------------------------------------------------------------------------
# 9. C13 cleans gate-generated transients before verifying release hygiene.
# ---------------------------------------------------------------------------


def test_v4_92_release_rehearsal_cleans_before_verify(dispatcher, tmp_path):
    root = tmp_path / "AI_Game_Dev_OS_v4.92_Release"
    scripts = root / "scripts" / "governance"
    scripts.mkdir(parents=True)
    (scripts / "clean_transients.py").write_text("# cleaner\n", encoding="utf-8")
    (scripts / "verify_release_clean_tree.py").write_text("# verifier\n", encoding="utf-8")
    (tmp_path / "v4.92_release_rehearsal_report.md").write_text(
        "AI_Game_Dev_OS_v4.92_Release.zip\nsha256\n",
        encoding="utf-8",
    )

    calls: list[list[str]] = []

    def fake_runner(cmd, **kwargs):
        calls.append(cmd)
        return types.SimpleNamespace(rc=0, stdout="ok\n", stderr="")

    with patch.object(dispatcher, "WORKSPACE_ROOT", tmp_path), \
         patch.object(dispatcher, "_runner_imports", return_value=(fake_runner, None)):
        ok, summary = dispatcher._check_v492_release_rehearsal(root)

    assert ok is True
    assert "clean release tree" in summary
    assert calls[0][1:] == ["scripts/governance/clean_transients.py", "--quiet"]
    assert calls[1][1:3] == ["scripts/governance/verify_release_clean_tree.py", "--project-root"]


# ---------------------------------------------------------------------------
# 10. skip-deliverables preserves the development-time C9-C13 skip band.
# ---------------------------------------------------------------------------


def test_skip_deliverables_does_not_apply_v4_92_overlay(dispatcher, tmp_path):
    payload = {
        "overall": 0,
        "results": [
            {"id": "C9", "label": "deliverable", "ok": None, "summary": "SKIPPED"},
            {"id": "C10", "label": "deliverable", "ok": None, "summary": "SKIPPED"},
        ],
    }
    with patch.object(dispatcher, "WORKSPACE_ROOT", tmp_path), \
         patch.object(dispatcher, "REPO_ROOT", tmp_path / "AI_Game_Dev_OS_v4.92"):
        rc, env = _run_full(dispatcher, payload, skip_deliverables=True)
    assert rc == 0
    assert env["overall"] == 0
    assert env["v4_92_deliverable_overlay"] == []
    assert all(r["summary"] == "SKIPPED" for r in env["results"])
