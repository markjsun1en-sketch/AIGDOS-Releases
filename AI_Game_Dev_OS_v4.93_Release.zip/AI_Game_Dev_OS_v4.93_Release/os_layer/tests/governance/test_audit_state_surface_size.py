"""test_audit_state_surface_size.py — v4.90 Batch 3 Step 2.

Validates the line-count audit governance script across happy path,
threshold tiers, missing inputs, JSON format, and ``--report-only``.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import textwrap


SCRIPT = "audit_state_surface_size.py"


def test_happy_standard_under_threshold(make_project, run_script):
    root = make_project(
        sprint_board_lines=50,   # standard sprint_board threshold = 80
        agent_log_lines=120,     # standard agent_log threshold = 150
        orchestrator_log_lines=180,  # standard orchestrator threshold = 200
        line_policy="standard",
    )
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(0)
    assert "clean" in res.stdout


def test_violation_sprint_board_over_standard(make_project, run_script):
    root = make_project(
        sprint_board_lines=120,  # > 80
        agent_log_lines=50,
        orchestrator_log_lines=50,
        line_policy="standard",
    )
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "tasks/sprint_board.md" in res.stderr
    assert "over_by" in res.stderr


def test_strict_threshold_tighter_than_standard(make_project, run_script):
    # strict sprint_board threshold = 50; 60 lines should violate
    root = make_project(
        sprint_board_lines=60,
        agent_log_lines=50,
        orchestrator_log_lines=50,
        line_policy="strict",
    )
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "strict" in res.stderr


def test_lenient_threshold_more_permissive(make_project, run_script):
    # lenient sprint_board threshold = 200; 120 lines OK
    root = make_project(
        sprint_board_lines=120,
        agent_log_lines=50,
        orchestrator_log_lines=50,
        line_policy="lenient",
    )
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(0)


def test_custom_surface_kind_uses_custom_threshold(make_project, run_script):
    custom_yaml = textwrap.dedent("""\
        surfaces:
          - surface_kind: custom
            tier: 1
            path: notes/scratch.md
            line_count_policy: strict
        archive_strategy: by_date
        """)
    root = make_project(custom_policy_yaml=custom_yaml)
    (root / "notes").mkdir()
    # custom strict threshold = 120; 200 lines violates
    (root / "notes" / "scratch.md").write_text(
        "\n".join(f"line {i}" for i in range(200)) + "\n",
        encoding="utf-8",
    )
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "custom/strict" in res.stderr


def test_missing_policy_returns_4(tmp_path, run_script):
    res = run_script(SCRIPT, "--project-root", str(tmp_path))
    res.expect(4)
    assert "policy not found" in res.stderr


def test_report_only_returns_0_with_violations(make_project, run_script):
    root = make_project(
        sprint_board_lines=300,  # way over standard
        agent_log_lines=50,
        orchestrator_log_lines=50,
    )
    res = run_script(SCRIPT, "--project-root", str(root), "--report-only")
    res.expect(0)
    # violations are still listed on stderr
    assert "1 violation" in res.stderr


def test_json_format_emits_parseable_payload(make_project, run_script):
    root = make_project(
        sprint_board_lines=200,
        agent_log_lines=50,
        orchestrator_log_lines=50,
    )
    res = run_script(SCRIPT, "--project-root", str(root), "--format", "json")
    # exit is non-zero (violations) but json still prints to stdout
    assert res.exit_code == 1
    payload = json.loads(res.stdout)
    assert payload["violation_count"] == 1
    v = payload["violations"][0]
    assert v["path"] == "tasks/sprint_board.md"
    assert v["surface_kind"] == "sprint_board"
    assert v["line_count_policy"] == "standard"
    assert v["actual_lines"] == 200
    assert v["threshold"] == 80
    assert v["over_by"] == 120


def test_multiple_violations_accumulate(make_project, run_script):
    root = make_project(
        sprint_board_lines=300,
        agent_log_lines=400,
        orchestrator_log_lines=500,
        line_policy="standard",
    )
    res = run_script(SCRIPT, "--project-root", str(root), "--format", "json")
    assert res.exit_code == 1
    payload = json.loads(res.stdout)
    assert payload["violation_count"] == 3


def test_missing_surface_file_listed_as_missing(make_project, run_script):
    root = make_project()
    # delete one surface file
    (root / "logs" / "agents" / "eng.md").unlink()
    res = run_script(SCRIPT, "--project-root", str(root), "--format", "json")
    assert res.exit_code == 1
    payload = json.loads(res.stdout)
    assert any(v["actual_lines"] == -1 for v in payload["violations"])
