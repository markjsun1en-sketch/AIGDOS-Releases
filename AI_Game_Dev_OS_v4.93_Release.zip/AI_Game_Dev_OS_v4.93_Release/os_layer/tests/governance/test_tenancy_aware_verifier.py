"""test_tenancy_aware_verifier.py — v4.91 F-V-01.

Tests for the tenancy-aware behaviour of
``scripts/governance/verify_release_clean_tree.py``.

Coverage matrix (V4–V7 from the F-V-01 plan, plus shape-of-output):

  TV1  default v4.91 tree, no --adopting-project-root flag
       → tenant_accepted == [], existing extras-detection unchanged.
       (Pre-F-V-01 behaviour preserved when no oracle is supplied.)

  TV2  mini release tree + acme_demo project root + claim covers
       ltm/project/acme_demo/x.md + manifest declares
       'ltm/project/<project_id>/**' → file is tenant_accepted.

  TV3  mini release tree + acme_demo project_root WITHOUT
       runtime_namespace block → file remains extra (V5 case).

  TV4  mini release tree + acme_demo project_root + claim, but the
       file's parent dir is NOT under any manifest path_template
       → file remains extra (V6 case).

  TV5  cross-tenant squat: project acme_demo claims
       ``ltm/project/acme_demo/**`` but the actual file is
       ``ltm/project/other_id/x.md`` → file remains extra (V7 case).

  TV6  two adopting-project roots (acme_demo + sample_project), each
       claims its own subtree → both subtrees tenant_accepted, no
       cross-contamination.

  TV7  claim's path_glob does not cover the actual file → file
       remains extra. (Schema permits any path_glob shape; runtime
       coverage is still required.)

  TV8  --report-tenant-accepted text output includes the path,
       project_id, manifest template, and project_root for each
       accepted entry.

  TV9  --format json output exposes tenant_accepted_count and a
       tenant_accepted[] array of dicts with the expected keys.

Layer 1 (OS Spec). No project names — fixture project ids are the
generic placeholders 'acme_demo' / 'sample_project' / 'other_id'.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

_THIS = Path(__file__).resolve()
_REPO = _THIS.parents[2]
_SCRIPT = _REPO / "scripts" / "governance" / "verify_release_clean_tree.py"

# Generic fixture identifiers — never hard-code real project ids here.
ACME = "acme_demo"
SAMPLE = "sample_project"


# ---------------------------------------------------------------------------
# Fixture builders (self-contained — do not depend on the heavy make_project
# fixture from tests/governance/conftest.py).
# ---------------------------------------------------------------------------


def _minimal_manifest(*, with_tenant_entry: bool = True) -> dict:
    m: dict = {
        "package_name": "tenancy_aware_test",
        "package_root_dir": "tenancy_aware_test",
        "manifest_schema_version": "test",
        "exclusions": {
            "self_referential": ["CHECKSUMS.sha", "RELEASE_MANIFEST.json"],
            "transient_patterns": [
                "__pycache__/", ".pytest_cache/", "*.pyc",
                ".DS_Store", "._*",
            ],
            "generated_runtime_outputs": ["exports/**"],
        },
        "required_manifest_files": [
            {"path": "README.md", "bytes": 0, "sha256": "x"},
        ],
        "optional_seed_files": [],
        "test_fixtures": [],
    }
    if with_tenant_entry:
        m["classification_rules"] = {
            "tenant_runtime": "Tenant runtime declarations.",
        }
        m["tenant_runtime_entries"] = [
            {
                "path_template": "ltm/project/<project_id>/**",
                "owning_authority": "adopting_project",
                "purpose": "test",
                "promotion_target": True,
            }
        ]
    return m


def _build_release_tree(tmp_path: Path, *, manifest: dict,
                        files: dict[str, str]) -> Path:
    """Create a minimal release artifact tree at tmp_path/release/."""
    root = tmp_path / "release"
    root.mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text("# stub\n", encoding="utf-8")
    (root / "CHECKSUMS.sha").write_text("stub\n", encoding="utf-8")
    (root / "RELEASE_MANIFEST.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    for rel, content in files.items():
        target = root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    return root


def _build_project_yaml(tmp_path: Path, *, project_id: str,
                        claims: list[dict] | None) -> Path:
    """Create <tmp>/<project_id>/.ai_dev_os/project_runtime_protocol.yaml.

    The yaml uses only the subset supported by _yaml_subset (no | block
    scalars, list-of-mappings with key on the dash line, scalars without
    embedded ':').
    """
    root = tmp_path / project_id
    (root / ".ai_dev_os").mkdir(parents=True, exist_ok=True)
    lines = [f"project_id: {project_id}"]
    if claims is not None:
        lines.append("runtime_namespace:")
        lines.append("  claims:")
        for c in claims:
            lines.append(f"    - path_glob: {c['path_glob']}")
            if c.get("matches_template"):
                lines.append(f"      matches_template: {c['matches_template']}")
            if c.get("rationale"):
                lines.append(f"      rationale: {c['rationale']}")
    (root / ".ai_dev_os" / "project_runtime_protocol.yaml").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    return root


def _run(release_root: Path, *extra_args: str) -> tuple[int, str, str]:
    cmd = [
        sys.executable,
        str(_SCRIPT),
        "--project-root", str(release_root),
        *extra_args,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    return proc.returncode, proc.stdout, proc.stderr


# ---------------------------------------------------------------------------
# TV1 — default tree, no oracle
# ---------------------------------------------------------------------------


def test_tv1_default_v4_91_tree_pretends_no_oracle_when_no_yaml(
    tmp_path: Path,
) -> None:
    """With manifest declaring tenant entries but no adopting-project
    yaml in scope, the verifier should treat the world exactly as
    pre-F-V-01: no tenant_accepted, plain extras for any non-manifest
    files.
    """
    manifest = _minimal_manifest(with_tenant_entry=True)
    root = _build_release_tree(tmp_path, manifest=manifest, files={})
    rc, out, _ = _run(root, "--format", "json")
    assert rc == 0, f"unexpected rc={rc}; out={out!r}"
    payload = json.loads(out)
    assert payload["tenant_accepted_count"] == 0
    assert payload["tenant_accepted"] == []
    assert payload["clean"] is True


# ---------------------------------------------------------------------------
# TV2 — happy path
# ---------------------------------------------------------------------------


def test_tv2_acme_demo_claim_accepted(tmp_path: Path) -> None:
    """Manifest declares the template, project declares the matching
    claim, file lives under that claim → tenant_accepted."""
    manifest = _minimal_manifest()
    files = {f"ltm/project/{ACME}/x.md": "tenant data\n"}
    release = _build_release_tree(tmp_path, manifest=manifest, files=files)
    proj = _build_project_yaml(tmp_path, project_id=ACME, claims=[
        {"path_glob": f"ltm/project/{ACME}/**",
         "matches_template": "ltm/project/<project_id>/**",
         "rationale": "test"},
    ])
    rc, out, _ = _run(release, "--adopting-project-root", str(proj),
                       "--format", "json")
    assert rc == 0
    payload = json.loads(out)
    assert payload["clean"] is True
    assert payload["tenant_accepted_count"] == 1
    accepted = payload["tenant_accepted"][0]
    assert accepted["path"] == f"ltm/project/{ACME}/x.md"
    assert accepted["project_id"] == ACME
    assert accepted["template"] == "ltm/project/<project_id>/**"


# ---------------------------------------------------------------------------
# TV3 — yaml lacks runtime_namespace block (V5)
# ---------------------------------------------------------------------------


def test_tv3_no_runtime_namespace_block_keeps_file_extra(
    tmp_path: Path,
) -> None:
    manifest = _minimal_manifest()
    files = {f"ltm/project/{ACME}/x.md": "orphan tenant data\n"}
    release = _build_release_tree(tmp_path, manifest=manifest, files=files)
    proj = _build_project_yaml(tmp_path, project_id=ACME, claims=None)
    rc, out, _ = _run(release, "--adopting-project-root", str(proj),
                       "--format", "json")
    assert rc == 1
    payload = json.loads(out)
    assert payload["clean"] is False
    assert f"ltm/project/{ACME}/x.md" in payload["extras"]
    assert payload["tenant_accepted_count"] == 0


# ---------------------------------------------------------------------------
# TV4 — manifest lacks the path_template (V6)
# ---------------------------------------------------------------------------


def test_tv4_manifest_without_tenant_entry_keeps_file_extra(
    tmp_path: Path,
) -> None:
    manifest = _minimal_manifest(with_tenant_entry=False)
    files = {f"ltm/project/{ACME}/x.md": "tenant data without manifest entry\n"}
    release = _build_release_tree(tmp_path, manifest=manifest, files=files)
    proj = _build_project_yaml(tmp_path, project_id=ACME, claims=[
        {"path_glob": f"ltm/project/{ACME}/**",
         "matches_template": "ltm/project/<project_id>/**",
         "rationale": "test"},
    ])
    rc, out, _ = _run(release, "--adopting-project-root", str(proj),
                       "--format", "json")
    assert rc == 1
    payload = json.loads(out)
    assert f"ltm/project/{ACME}/x.md" in payload["extras"]
    assert payload["tenant_accepted_count"] == 0


# ---------------------------------------------------------------------------
# TV5 — cross-tenant squat (V7)
# ---------------------------------------------------------------------------


def test_tv5_cross_tenant_squat_keeps_file_extra(tmp_path: Path) -> None:
    """Project acme_demo claims its own ns, file path uses 'other_id'
    → reconcile yields CROSS_TENANT_SQUAT (no claim has project_id ==
    'other_id'), file remains extra."""
    manifest = _minimal_manifest()
    files = {"ltm/project/other_id/x.md": "squat\n"}
    release = _build_release_tree(tmp_path, manifest=manifest, files=files)
    proj = _build_project_yaml(tmp_path, project_id=ACME, claims=[
        {"path_glob": f"ltm/project/{ACME}/**",
         "matches_template": "ltm/project/<project_id>/**",
         "rationale": "test"},
    ])
    rc, out, _ = _run(release, "--adopting-project-root", str(proj),
                       "--format", "json")
    assert rc == 1
    payload = json.loads(out)
    assert "ltm/project/other_id/x.md" in payload["extras"]
    assert payload["tenant_accepted_count"] == 0


# ---------------------------------------------------------------------------
# TV6 — two project roots, both accepted independently
# ---------------------------------------------------------------------------


def test_tv6_two_project_roots_both_accepted(tmp_path: Path) -> None:
    manifest = _minimal_manifest()
    files = {
        f"ltm/project/{ACME}/a.md": "acme data\n",
        f"ltm/project/{SAMPLE}/b.md": "sample data\n",
    }
    release = _build_release_tree(tmp_path, manifest=manifest, files=files)
    proj_a = _build_project_yaml(tmp_path, project_id=ACME, claims=[
        {"path_glob": f"ltm/project/{ACME}/**",
         "matches_template": "ltm/project/<project_id>/**",
         "rationale": "test"},
    ])
    proj_b = _build_project_yaml(tmp_path, project_id=SAMPLE, claims=[
        {"path_glob": f"ltm/project/{SAMPLE}/**",
         "matches_template": "ltm/project/<project_id>/**",
         "rationale": "test"},
    ])
    rc, out, _ = _run(
        release,
        "--adopting-project-root", str(proj_a),
        "--adopting-project-root", str(proj_b),
        "--format", "json",
    )
    assert rc == 0
    payload = json.loads(out)
    assert payload["clean"] is True
    assert payload["tenant_accepted_count"] == 2
    pids = sorted(e["project_id"] for e in payload["tenant_accepted"])
    assert pids == [ACME, SAMPLE]


# ---------------------------------------------------------------------------
# TV7 — claim path_glob does not cover the actual file
# ---------------------------------------------------------------------------


def test_tv7_claim_glob_outside_actual_file_keeps_extra(tmp_path: Path) -> None:
    """Project claims a sibling subdir; actual file is elsewhere under
    the same template → no claim covers it → extra."""
    manifest = _minimal_manifest()
    files = {f"ltm/project/{ACME}/x.md": "real file\n"}
    release = _build_release_tree(tmp_path, manifest=manifest, files=files)
    # Claim points at a subpath that does NOT cover x.md.
    proj = _build_project_yaml(tmp_path, project_id=ACME, claims=[
        {"path_glob": f"ltm/project/{ACME}/handoffs/**",
         "matches_template": "ltm/project/<project_id>/**",
         "rationale": "test"},
    ])
    rc, out, _ = _run(release, "--adopting-project-root", str(proj),
                       "--format", "json")
    assert rc == 1
    payload = json.loads(out)
    assert f"ltm/project/{ACME}/x.md" in payload["extras"]
    assert payload["tenant_accepted_count"] == 0


# ---------------------------------------------------------------------------
# TV8 — --report-tenant-accepted shape
# ---------------------------------------------------------------------------


def test_tv8_report_tenant_accepted_lists_each_path(tmp_path: Path) -> None:
    manifest = _minimal_manifest()
    files = {f"ltm/project/{ACME}/x.md": "tenant data\n"}
    release = _build_release_tree(tmp_path, manifest=manifest, files=files)
    proj = _build_project_yaml(tmp_path, project_id=ACME, claims=[
        {"path_glob": f"ltm/project/{ACME}/**",
         "matches_template": "ltm/project/<project_id>/**",
         "rationale": "test"},
    ])
    rc, out, _ = _run(release, "--adopting-project-root", str(proj),
                       "--report-tenant-accepted")
    assert rc == 0
    assert "1 tenant runtime files accepted" in out
    assert f"+ ltm/project/{ACME}/x.md" in out
    assert f"project_id={ACME}" in out
    assert "template=ltm/project/<project_id>/**" in out


# ---------------------------------------------------------------------------
# TV9 — JSON shape
# ---------------------------------------------------------------------------


def test_tv9_json_shape_exposes_tenant_fields(tmp_path: Path) -> None:
    manifest = _minimal_manifest()
    release = _build_release_tree(tmp_path, manifest=manifest, files={})
    rc, out, _ = _run(release, "--format", "json")
    assert rc == 0
    payload = json.loads(out)
    for key in ("clean", "extra_count", "extras", "transient_count",
                "transients", "tenant_accepted_count", "tenant_accepted"):
        assert key in payload, f"missing JSON field: {key}"
    assert payload["tenant_accepted"] == []


# ---------------------------------------------------------------------------
# Anti-pattern guards (compile-time): no escape-hatch flags exist
# ---------------------------------------------------------------------------


def test_no_allow_extra_or_skip_tenant_flags(tmp_path: Path) -> None:
    """Verify the verifier refuses unknown --allow-extra / --skip-tenant
    options. These flags MUST NOT exist by F-V-01 charter."""
    manifest = _minimal_manifest()
    release = _build_release_tree(tmp_path, manifest=manifest, files={})
    for forbidden in ("--allow-extra", "--skip-tenant"):
        proc = subprocess.run(
            [sys.executable, str(_SCRIPT), "--project-root", str(release),
             forbidden],
            capture_output=True, text=True, timeout=10,
        )
        assert proc.returncode != 0, (
            f"verifier accepted forbidden flag: {forbidden}"
        )
        assert "unrecognized arguments" in proc.stderr.lower() or \
               "error:" in proc.stderr.lower()
