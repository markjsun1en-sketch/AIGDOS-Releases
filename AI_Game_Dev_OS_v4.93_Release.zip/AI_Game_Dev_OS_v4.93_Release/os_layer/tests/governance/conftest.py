"""Shared fixtures for tests/governance/ — v4.90 Batch 3 Step 2.

v4.91 Batch 14.19 — ``run_script`` migrated from plain
``subprocess.run`` to ``run_pg_safe_to_file_v2`` (process-group-safe
+ file capture + cleanup_process_group_on_exit). The original
``subprocess.run(..., capture_output=True, timeout=15)`` could
deadlock if a script ever fan-outs grandchildren that share its
stdout/stderr; switching to file capture removes the 64 KB
PIPE-buffer back-pressure path entirely, and the on-exit PG cleanup
ensures no test leaks long-lived descendants between cases.

Layer 1 (OS Spec). No project names. Fixture project IDs use generic
placeholders such as ``acme_demo`` / ``sample_project``.
"""
from __future__ import annotations

import os
import sys
import tempfile
import textwrap
from dataclasses import dataclass
from pathlib import Path

import pytest

SCRIPT_ROOT = Path(__file__).resolve().parents[2] / "scripts" / "governance"
# Ensure ``_process_runner`` is importable. tests/conftest.py adds
# ``scripts/`` to sys.path; we additionally want the governance
# directory itself so ``from _process_runner import ...`` works.
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

from _process_runner import run_pg_safe_to_file_v2  # noqa: E402


@dataclass
class ScriptResult:
    exit_code: int
    stdout: str
    stderr: str

    def expect(self, code: int) -> "ScriptResult":
        assert self.exit_code == code, (
            f"expected exit {code}, got {self.exit_code}\n"
            f"stdout: {self.stdout}\nstderr: {self.stderr}"
        )
        return self


@pytest.fixture
def run_script():
    """Subprocess-launch a governance script (v4.91 PG-safe variant).

    Uses ``run_pg_safe_to_file_v2`` so the helper:
      - captures stdout/stderr to files (no PIPE 64 KB back-pressure),
      - reaps the child's process group on exit (catches any forked
        grandchild),
      - escalates SIGTERM → SIGKILL on timeout.

    Cwd defaults to None (script's own dir). Timeout is 15s; raise
    via the ``timeout`` kwarg if a specific test needs longer.
    """
    def _run(script_name: str, *args: str, cwd: Path | None = None,
             timeout: int = 15) -> ScriptResult:
        script = SCRIPT_ROOT / script_name
        assert script.exists(), f"script not found: {script}"
        cmd = [sys.executable, str(script), *args]
        env_extra = {}
        # Make the project repo importable so the scripts can do
        # ``from scripts.governance._yaml_subset import ...``
        repo_root = SCRIPT_ROOT.parents[1]
        env_extra["PYTHONPATH"] = (
            str(repo_root) + os.pathsep + os.environ.get("PYTHONPATH", "")
        )
        with tempfile.TemporaryDirectory(prefix="run_script_") as td:
            tmp = Path(td)
            r = run_pg_safe_to_file_v2(
                cmd,
                cwd=str(cwd) if cwd else str(SCRIPT_ROOT),
                timeout=timeout,
                stdout_path=tmp / "stdout",
                stderr_path=tmp / "stderr",
                extra_env=env_extra,
                cleanup_process_group_on_exit=True,
            )
        return ScriptResult(
            exit_code=r.rc,
            stdout=r.stdout,
            stderr=r.stderr,
        )
    return _run


@pytest.fixture
def make_project(tmp_path: Path):
    """Build a synthetic project directory with sane defaults.

    Returns a callable that accepts overrides and yields the project root.
    Generic project name is ``acme_demo`` — never use real project IDs.
    """
    def _make(
        *,
        sprint_board_lines: int = 50,
        agent_log_lines: int = 100,
        orchestrator_log_lines: int = 150,
        sprint_board_kind: str = "sprint_board",
        agent_log_kind: str = "agent_log",
        orchestrator_kind: str = "orchestrator_log",
        line_policy: str = "standard",
        archive_strategy: str = "by_sprint",
        include_indexes: bool = True,
        include_open_issues: bool = True,
        include_protocol_yaml: bool = True,
        include_agents_index: bool = True,
        include_sprint_index: bool = True,
        include_task_index: bool = True,
        custom_policy_yaml: str | None = None,
        custom_readset_yaml: str | None = None,
        custom_sync_guard_yaml: str | None = None,
        agent_log_sections: list[str] | None = None,
        sprint_board_sections: list[str] | None = None,
        forbidden_keyword_in_log: str | None = None,
    ) -> Path:
        root = tmp_path / "acme_demo"
        root.mkdir()
        (root / ".ai_dev_os").mkdir()
        (root / "tasks").mkdir()
        (root / "logs").mkdir()
        (root / "logs" / "agents").mkdir()

        # ----- sprint board -----
        if sprint_board_sections is None:
            sprint_board_sections = [
                "# Sprint header (id / status)",
                "## Active task rows",
                "## Current evidence pointer",
                "## Index links: sprint_index, task_index",
            ]
        body = "\n".join(sprint_board_sections)
        # pad to requested line count
        pad_lines = sprint_board_lines - len(sprint_board_sections)
        if pad_lines > 0:
            body += "\n" + "\n".join(f"row {i}" for i in range(pad_lines))
        (root / "tasks" / "sprint_board.md").write_text(
            body + "\n", encoding="utf-8")

        # ----- agent log -----
        if agent_log_sections is None:
            agent_log_sections = [
                "## Current Hot State",
                "## Current Task",
                "## Current Truth",
                "## Active References",
                "## Next Step",
            ]
        body = "\n".join(agent_log_sections)
        pad_lines = agent_log_lines - len(agent_log_sections)
        if pad_lines > 0:
            body += "\n" + "\n".join(f"entry {i}" for i in range(pad_lines))
        if forbidden_keyword_in_log:
            body += f"\n{forbidden_keyword_in_log}\n"
        (root / "logs" / "agents" / "eng.md").write_text(
            body + "\n", encoding="utf-8")

        # ----- orchestrator log -----
        body = "\n".join(f"o{i}" for i in range(orchestrator_log_lines))
        (root / "logs" / "orchestrator_log.md").write_text(
            body + "\n", encoding="utf-8")

        # ----- open issues -----
        if include_open_issues:
            (root / "logs" / "open_issues.md").write_text(
                "no issues\n", encoding="utf-8")

        # ----- indexes -----
        if include_agents_index:
            (root / "logs" / "agents" / "index.md").write_text(
                "agents index\n", encoding="utf-8")
        if include_sprint_index:
            (root / "tasks" / "sprint_index.md").write_text(
                "sprint index\n", encoding="utf-8")
        if include_task_index:
            (root / "tasks" / "task_index.md").write_text(
                "task index\n", encoding="utf-8")

        # ----- protocol yaml -----
        if include_protocol_yaml:
            (root / ".ai_dev_os" / "project_runtime_protocol.yaml").write_text(
                "project_id: acme_demo\n", encoding="utf-8")

        # ----- state surface policy -----
        if custom_policy_yaml is not None:
            policy_yaml = custom_policy_yaml
        else:
            policy_yaml = textwrap.dedent(f"""\
                surfaces:
                  - surface_kind: {sprint_board_kind}
                    tier: 1
                    path: tasks/sprint_board.md
                    line_count_policy: {line_policy}
                  - surface_kind: {agent_log_kind}
                    tier: 1
                    path: logs/agents/eng.md
                    line_count_policy: {line_policy}
                  - surface_kind: {orchestrator_kind}
                    tier: 1
                    path: logs/orchestrator_log.md
                    line_count_policy: {line_policy}
                archive_strategy: {archive_strategy}
                """)
            if include_indexes:
                policy_yaml += textwrap.dedent("""\
                    indexes:
                      sprint_index: tasks/sprint_index.md
                      task_index: tasks/task_index.md
                      agents_index: logs/agents/index.md
                      orchestrator_decision_index: logs/orchestrator_decision_index.md
                    """)
        (root / ".ai_dev_os" / "state_surface_policy.yaml").write_text(
            policy_yaml, encoding="utf-8")

        # ----- cold start readset -----
        if custom_readset_yaml is not None:
            readset_yaml = custom_readset_yaml
        else:
            readset_yaml = textwrap.dedent("""\
                enabled: true
                os_minimum_paths:
                  - .ai_dev_os/project_runtime_protocol.yaml
                  - logs/agents/index.md
                  - tasks/sprint_board.md
                  - tasks/sprint_index.md
                  - tasks/task_index.md
                  - logs/orchestrator_log.md
                  - logs/open_issues.md
                project_extensions: []
                cold_start_max_file_size_bytes: 51200
                forbidden_path_patterns:
                  - exports/
                  - runtime/state/transient/
                  - tests/
                  - fixtures/
                  - _mock_baselines/
                archive_marker_string: "DO NOT LOAD BY DEFAULT"
                """)
        (root / ".ai_dev_os" / "cold_start_readset.yaml").write_text(
            readset_yaml, encoding="utf-8")

        # ----- registry sync guard -----
        if custom_sync_guard_yaml is not None:
            sync_yaml = custom_sync_guard_yaml
        else:
            sync_yaml = textwrap.dedent("""\
                preserve_historical_rows: true
                strip_markdown_markers: true
                refuse_silent_deletion: true
                dry_run_supported: true
                atomic_write: true
                source_kinds_supported:
                  - sprint_board_v1
                  - sprint_board_v2
                archive_stale_explicit_flag: --archive-stale
                """)
        (root / ".ai_dev_os" / "registry_sync_guard.yaml").write_text(
            sync_yaml, encoding="utf-8")

        return root
    return _make
