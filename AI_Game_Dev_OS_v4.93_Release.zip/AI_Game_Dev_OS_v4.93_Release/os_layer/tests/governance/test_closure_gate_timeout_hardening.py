"""test_closure_gate_timeout_hardening.py — v4.90.8 closure gate hardening.

v4.90.8 makes ``run_v490_rc3_closure_gate.py``'s ``_run()`` helper
process-group-safe: it spawns the child in its own session
(``start_new_session=True``) and uses ``os.killpg`` on timeout so
pytest's adoption-harness fan-out subprocesses cannot keep stdout/stderr
pipes open and deadlock the parent's ``communicate()`` call.

It also adds an opt-in ``--pytest-disable-plugin-autoload`` flag that
sets ``PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`` for the C1 full pytest run.

This test suite covers three contracts:

    1. ``_run()`` returns ``(124, "", ...)`` on timeout and the entire
       process tree (parent + grandchild sleeper) is reaped — no
       leaked PIDs after the call returns. This is the core hardening
       contract; before v4.90.8 the parent could deadlock on
       ``communicate()`` while a grandchild kept the pipe alive.

    2. ``_run()`` accepts and forwards ``extra_env`` so the C1 plugin
       autoload toggle is observable inside the child. We launch a
       tiny inline Python that prints ``os.environ.get(...)`` and
       verify the value round-trips.

    3. ``--help`` output advertises ``--pytest-disable-plugin-autoload``
       with its v4.90.8 marker and points at the v4.91 fast-vs-full
       split deferral.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import textwrap
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1].parent
GATE_PATH = REPO_ROOT / "scripts" / "governance" / "run_v490_rc3_closure_gate.py"


def _load_gate_module():
    spec = importlib.util.spec_from_file_location(
        "v490_closure_gate_under_test", GATE_PATH
    )
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def test_run_kills_grandchild_process_group_on_timeout(tmp_path):
    """A child that spawns a long-running grandchild must be fully reaped
    by ``_run()`` when the timeout fires. Before v4.90.8 the parent
    could deadlock on ``communicate()`` because the grandchild kept
    stdout open."""
    gate = _load_gate_module()

    # Child script: spawn a grandchild that sleeps 30s, then sleep 30s
    # itself. Both inherit stdout, so closing the pipe requires reaping
    # the whole tree.
    child_src = textwrap.dedent(
        """
        import os, sys, time, subprocess
        gc = subprocess.Popen(
            [sys.executable, "-c", "import time; time.sleep(30)"],
            stdout=sys.stdout, stderr=sys.stderr,
        )
        sys.stdout.write(f"GC_PID={gc.pid}\\n")
        sys.stdout.flush()
        time.sleep(30)
        """
    ).strip()
    script = tmp_path / "child.py"
    script.write_text(child_src, encoding="utf-8")

    t0 = time.monotonic()
    rc, out, err = gate._run(
        [sys.executable, str(script)],
        cwd=tmp_path,
        timeout=2,
    )
    elapsed = time.monotonic() - t0

    # Contract: timeout returns 124 and the call returns within a
    # reasonable window (must not deadlock waiting on the grandchild).
    assert rc == 124, f"expected 124 on timeout, got {rc} (err={err!r})"
    assert elapsed < 25, (
        f"_run() took {elapsed:.1f}s — grandchild likely deadlocked the "
        "pipe; v4.90.8 hardening missing or regressed"
    )

    # If the child did print before SIGTERM, parse the grandchild PID
    # and confirm it is no longer alive.
    gc_pid = None
    for line in (out or "").splitlines():
        if line.startswith("GC_PID="):
            try:
                gc_pid = int(line.split("=", 1)[1])
            except ValueError:
                pass
    if gc_pid is not None:
        # Give the OS a brief moment to actually reap.
        for _ in range(20):
            if not _pid_alive(gc_pid):
                break
            time.sleep(0.1)
        assert not _pid_alive(gc_pid), (
            f"grandchild PID {gc_pid} still alive after _run() timeout — "
            "killpg did not reach the process group"
        )


def test_run_forwards_extra_env_to_child(tmp_path):
    """``_run(..., extra_env=...)`` must merge into ``os.environ`` so
    the C1 autoload toggle is observable inside the child."""
    gate = _load_gate_module()

    child_src = (
        "import os, sys; "
        "sys.stdout.write(os.environ.get('PYTEST_DISABLE_PLUGIN_AUTOLOAD', '<unset>'))"
    )
    script = tmp_path / "envcheck.py"
    script.write_text(child_src, encoding="utf-8")

    rc, out, _ = gate._run(
        [sys.executable, str(script)],
        cwd=tmp_path,
        timeout=10,
        extra_env={"PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1"},
    )
    assert rc == 0
    assert out.strip() == "1", (
        f"extra_env not forwarded to child; got {out!r}"
    )


def test_help_advertises_plugin_autoload_flag():
    """--help must document --pytest-disable-plugin-autoload with its
    v4.90.8 marker and reference the deferred fast-vs-full split."""
    import tempfile as _tempfile

    if str(REPO_ROOT / "scripts" / "governance") not in sys.path:
        sys.path.insert(0, str(REPO_ROOT / "scripts" / "governance"))
    from _process_runner import run_pg_safe_to_file_v2

    cmd = [sys.executable, str(GATE_PATH), "--help"]
    with _tempfile.TemporaryDirectory(prefix="cg_hardening_") as td:
        tmp = Path(td)
        r = run_pg_safe_to_file_v2(
            cmd,
            cwd=str(REPO_ROOT),
            timeout=30,
            stdout_path=tmp / "stdout",
            stderr_path=tmp / "stderr",
            cleanup_process_group_on_exit=True,
        )
    assert r.rc == 0, r.stdout + r.stderr
    out = r.stdout
    assert "--pytest-disable-plugin-autoload" in out, (
        "v4.90.8 added this flag; --help must advertise it"
    )
    assert "v4.90.8" in out, (
        "help text should mark the flag's introduction patch"
    )
    assert "PYTEST_DISABLE_PLUGIN_AUTOLOAD=1" in out
    # And the older flags should still be advertised.
    assert "--pytest-timeout" in out
    assert "--aggregate-timeout" in out
