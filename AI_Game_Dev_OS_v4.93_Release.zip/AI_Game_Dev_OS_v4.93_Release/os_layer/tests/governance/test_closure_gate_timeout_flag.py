"""test_closure_gate_timeout_flag.py — v4.90 Batch 14.10 (v4.90.3 polish patch).

Closure gate gains an optional ``--pytest-timeout`` flag so external
CI / regression machines can accept the full pytest suite without
hitting the developer-laptop 240-second budget. The fast-vs-full
closure-gate split itself is deferred to v4.91 (B-CG backlog item).

1 test:

    1. ``run_v490_rc3_closure_gate.py --help`` exits 0 and the help
       text advertises the new --pytest-timeout flag with its default
       240. We don't kick off a full pytest run here — that would
       block this test with the very timeout it tries to verify.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1].parent
GATE = REPO_ROOT / "scripts" / "governance" / "run_v490_rc3_closure_gate.py"


def test_closure_gate_help_advertises_pytest_timeout_flag():
    res = subprocess.run(
        [sys.executable, str(GATE), "--help"],
        capture_output=True,
        text=True,
        cwd=str(REPO_ROOT),
        check=False,
    )
    assert res.returncode == 0, res.stdout + res.stderr
    out = res.stdout
    # Flag must appear in usage line and option block.
    assert "--pytest-timeout" in out, (
        "closure gate --help missing --pytest-timeout; v4.90.3 added it "
        "to support slow CI / external regression machines."
    )
    # Default 240 must be documented.
    assert "default 240" in out
    # The flag should mention the v4.91 fast-vs-full split is deferred.
    assert "fast vs full" in out
