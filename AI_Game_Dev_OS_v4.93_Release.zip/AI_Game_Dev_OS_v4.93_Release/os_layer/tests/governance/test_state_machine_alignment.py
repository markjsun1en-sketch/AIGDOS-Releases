"""test_state_machine_alignment.py — v4.90 Batch 14 Step 14.6.

Consistency audit C-07 guard. Asserts the alignment guard script
correctly cross-checks every model doc against its schema's
transition_history whitelist.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

V4_90_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(V4_90_ROOT))

from scripts.governance.check_state_machine_alignment import (  # noqa: E402
    STATE_MACHINES,
    check_all,
    parse_doc_transitions,
    parse_schema_transitions,
)


# ---------------------------------------------------------------------------
# 1. Module exposes the canonical STATE_MACHINES list with all required keys
# ---------------------------------------------------------------------------


def test_alignment_guard_module_exposes_state_machines_constant():
    """STATE_MACHINES must list 3 machines, each with required fields."""
    names = {sm["name"] for sm in STATE_MACHINES}
    assert names == {
        "proposal_state",
        "capability_adoption_state",
        "pack_lifecycle_state",
    }
    required_keys = {"name", "doc", "schema", "state_field"}
    for sm in STATE_MACHINES:
        assert required_keys <= set(sm.keys()), (
            f"State machine {sm['name']} missing keys: "
            f"{required_keys - set(sm.keys())}"
        )


# ---------------------------------------------------------------------------
# 2. proposal_state: doc transition table ≡ schema anyOf
# ---------------------------------------------------------------------------


def test_proposal_state_doc_schema_aligned():
    """The 12 transitions documented in PROPOSAL_STATE_MODEL.md must
    exactly match the 12 anyOf entries in proposal_state.schema.json."""
    sm = next(s for s in STATE_MACHINES if s["name"] == "proposal_state")
    schema_trans, enum = parse_schema_transitions(
        V4_90_ROOT / sm["schema"], sm["state_field"]
    )
    doc_trans = parse_doc_transitions(V4_90_ROOT / sm["doc"], enum)
    assert doc_trans == schema_trans, (
        f"proposal_state alignment broken: "
        f"doc_only={sorted(doc_trans - schema_trans)}, "
        f"schema_only={sorted(schema_trans - doc_trans)}"
    )
    assert len(schema_trans) == 12  # invariant from Batch 6 design


# ---------------------------------------------------------------------------
# 3. Wildcard expansion: `*→X (except from Y)` correctly produces
#    enum \ {Y, X} → X transitions (self-loop excluded)
# ---------------------------------------------------------------------------


def test_capability_adoption_wildcard_expanded_correctly(tmp_path):
    """Synthetic markdown with a `*→disabled (except from verified)`
    wildcard must expand to (every state except `verified` and
    `disabled`) → `disabled`.
    """
    enum = [
        "not_present", "detected_legacy", "compatible", "needs_adapter",
        "adopting", "adopted", "verified", "blocked", "disabled",
    ]
    md = (
        "# Synthetic\n\n"
        "## Transition Rules\n\n"
        "| From | To | Allowed | Trigger |\n"
        "| --- | --- | --- | --- |\n"
        "| `not_present` | `detected_legacy` | yes | scan |\n"
        "| `*` | `disabled` | yes (except from `verified`) | opt-out |\n"
        "| `verified` | `*` | no | terminal |\n"
    )
    fixture = tmp_path / "WILDCARD_FIXTURE.md"
    fixture.write_text(md)
    transitions = parse_doc_transitions(fixture, enum)
    expected = {("not_present", "detected_legacy")} | {
        (s, "disabled")
        for s in enum
        if s not in {"verified", "disabled"}
    }
    assert transitions == expected, (
        f"Wildcard expansion mismatch:\n"
        f"  unexpected: {sorted(transitions - expected)}\n"
        f"  missing: {sorted(expected - transitions)}"
    )


# ---------------------------------------------------------------------------
# 4. Alignment guard subprocess exits 0 on current state
# ---------------------------------------------------------------------------


def test_alignment_guard_exits_zero_on_clean_state():
    """check_state_machine_alignment.py exits 0 with all 3 aligned."""
    script = (
        V4_90_ROOT / "scripts" / "governance"
        / "check_state_machine_alignment.py"
    )
    result = subprocess.run(
        [sys.executable, str(script)],
        capture_output=True, text=True,
    )
    assert result.returncode == 0, (
        f"alignment guard exited {result.returncode}:\n"
        f"{result.stdout}\n{result.stderr}"
    )
    assert "All state machines aligned" in result.stdout
    # Cross-check: programmatic check_all() agrees
    results = check_all()
    assert all(r["ok"] for r in results)
