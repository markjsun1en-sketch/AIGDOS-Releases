"""test_docs_front_matter.py — v4.90 Batch 14 Step 14.9.

5 tests covering the docs front-matter spec + 6 instrumented docs:

    1. docs/DOCS_FRONT_MATTER_SPEC.md exists at the documented path
    2. all 6 instrumented core docs carry front-matter
    3. every front-matter has the protected_invariants field (and it
       is a non-empty list of inv_NNN_* IDs)
    4. every protected_invariants ID resolves to an active invariant
       in runtime/protected_contracts/protected_regression_matrix.yaml
    5. scripts/lint/check_docs_front_matter.py exits 0 on the current
       tree (no malformed front-matter under docs/** + root meta)

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))

from scripts.governance._yaml_subset import load_yaml_file, parse_yaml_text  # noqa: E402

SPEC_PATH = REPO_ROOT / "docs" / "DOCS_FRONT_MATTER_SPEC.md"
LINT_SCRIPT = REPO_ROOT / "scripts" / "lint" / "check_docs_front_matter.py"
MATRIX_PATH = REPO_ROOT / "runtime" / "protected_contracts" / "protected_regression_matrix.yaml"

INSTRUMENTED_DOCS = [
    REPO_ROOT / "docs" / "STATE_MACHINES_INDEX.md",
    REPO_ROOT / "docs" / "14_state_surface_governance" / "V4_89_REFERENCE_AUDIT.md",
    REPO_ROOT / "docs" / "16_agent_library" / "PACK_LIFECYCLE_STATE_MODEL.md",
    REPO_ROOT / "docs" / "17_self_evolution" / "PROPOSAL_STATE_MODEL.md",
    REPO_ROOT / "docs" / "13_migration" / "ADOPTION_STATE_MODEL.md",
    REPO_ROOT / "docs" / "MANIFEST_HISTORY.md",
]

INV_ID_PATTERN = re.compile(r"^inv_\d{3}_[a-z0-9_]+$")


def _read_front_matter(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    assert text.startswith("---\n"), f"{path} does not start with '---'"
    closing = text.find("\n---\n", 4)
    assert closing > 0, f"{path} has no closing '---' delimiter"
    return parse_yaml_text(text[4:closing])


def test_spec_doc_exists():
    assert SPEC_PATH.is_file(), f"{SPEC_PATH} missing"
    body = SPEC_PATH.read_text(encoding="utf-8")
    # Must declare all 6 fields somewhere in the body
    for field in ("title", "version", "status", "layer", "since_batch",
                  "protected_invariants"):
        assert field in body, f"spec doc missing reference to field {field!r}"


def test_all_instrumented_docs_have_front_matter():
    for d in INSTRUMENTED_DOCS:
        assert d.is_file(), f"instrumented doc missing: {d}"
        text = d.read_text(encoding="utf-8")
        assert text.startswith("---\n"), (
            f"{d.relative_to(REPO_ROOT)} does not start with YAML front-matter"
        )


def test_front_matter_carries_protected_invariants():
    for d in INSTRUMENTED_DOCS:
        fm = _read_front_matter(d)
        invs = fm.get("protected_invariants")
        assert isinstance(invs, list) and len(invs) >= 1, (
            f"{d.relative_to(REPO_ROOT)}: protected_invariants must be a non-empty list, got {invs!r}"
        )
        for inv_id in invs:
            assert INV_ID_PATTERN.fullmatch(inv_id), (
                f"{d.relative_to(REPO_ROOT)}: inv id {inv_id!r} doesn't match {INV_ID_PATTERN.pattern}"
            )


def test_protected_invariant_ids_resolve_to_registry():
    matrix = load_yaml_file(MATRIX_PATH)
    registry_ids = {inv["id"] for inv in matrix["invariants"]}
    for d in INSTRUMENTED_DOCS:
        fm = _read_front_matter(d)
        for inv_id in fm.get("protected_invariants", []):
            assert inv_id in registry_ids, (
                f"{d.relative_to(REPO_ROOT)}: protected_invariant {inv_id!r} "
                f"is not in the registry (known: {sorted(registry_ids)})"
            )


def test_lint_script_exits_zero_on_clean_tree():
    proc = subprocess.run(
        [sys.executable, str(LINT_SCRIPT)],
        cwd=str(REPO_ROOT),
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert proc.returncode == 0, (
        f"check_docs_front_matter.py exited {proc.returncode}; "
        f"stdout={proc.stdout[-500:]} stderr={proc.stderr[-500:]}"
    )
    assert "clean" in proc.stdout
