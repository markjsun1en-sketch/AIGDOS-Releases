"""test_release_closure_gate_dispatcher.py — v4.90.9 fast/full split.

v4.90.9 Batch 14.16 closes B-CG (closure gate fast vs full split).
v4.91 Batch 14.19 — Gate Runner Architecture Patch.

The dispatcher (``scripts/governance/run_release_closure_gate.py``) is
the recommended invocation surface for v4.90.9+ external reviewers.
This suite locks down behaviours so future patches cannot regress
the fast/full contract:

    1. ``--profile fast`` runs the 11-item architecture-patched gate
       (F1, F3, F4, F5, F6, F7=CLI smoke, F8a/F8b/F8c/F8d small
       pytest batches, F2 last; v4.91 Batch 14.19 split) and exits
       within bounded wall-time on a healthy package.

    2. ``--profile full`` (and the default) loads the RC3 gate module
       and forwards parsed flags. We test this via the help-text
       contract since invoking RC3 main() inside pytest would re-run
       the whole 13-check suite.

    3. ``--help`` simultaneously documents both profiles plus every
       passthrough flag plus the v4.91 Batch 14.19 supervisor flag
       (``--fast-total-timeout``).

    4. Every invocation prints the patch-chain banner so an external
       reviewer can see at a glance that the dispatcher is layered on
       the RC3 closure contract.

    5. ``_argv_for_full`` correctly serialises every passthrough flag.

v4.91 Batch 14.19 — migrated from plain ``subprocess.run`` to
``run_pg_safe_to_file_v2`` (file-capture + PG cleanup-on-exit).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import importlib.util
import sys
import tempfile
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1].parent
DISPATCHER = REPO_ROOT / "scripts" / "governance" / "run_release_closure_gate.py"

if str(REPO_ROOT / "scripts" / "governance") not in sys.path:
    sys.path.insert(0, str(REPO_ROOT / "scripts" / "governance"))

from _process_runner import run_pg_safe_to_file_v2  # noqa: E402


def _run_dispatcher(extra_args: list[str], *, timeout: int = 180,
                    extra_env: dict[str, str] | None = None):
    """PG-safe + file-captured dispatcher invocation."""
    cmd = [sys.executable, str(DISPATCHER), *extra_args]
    with tempfile.TemporaryDirectory(prefix="dispatcher_test_") as td:
        tmp = Path(td)
        return run_pg_safe_to_file_v2(
            cmd,
            cwd=str(REPO_ROOT),
            timeout=timeout,
            stdout_path=tmp / "stdout",
            stderr_path=tmp / "stderr",
            extra_env=extra_env,
            cleanup_process_group_on_exit=True,
        )


def _load_dispatcher():
    spec = importlib.util.spec_from_file_location(
        "_v490_dispatcher_under_test", DISPATCHER
    )
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    # Register in sys.modules BEFORE exec so dataclass introspection
    # (Python 3.13's _is_type lookup) can resolve the module's
    # globals — exec_module path was tripping on
    # `sys.modules.get(cls.__module__).__dict__`.
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def test_help_documents_both_profiles_and_passthrough_flags():
    """--help must advertise --profile {fast,full} and every passthrough
    flag the RC3 gate accepts, so an external reviewer can read a single
    --help and know what surface the dispatcher exposes."""
    r = _run_dispatcher(["--help"], timeout=30)
    assert r.rc == 0, r.stdout + r.stderr
    out = r.stdout
    assert "--profile" in out
    assert "fast" in out and "full" in out
    assert "--skip-deliverables" in out
    assert "--pytest-timeout" in out
    assert "--aggregate-timeout" in out
    assert "--pytest-disable-plugin-autoload" in out


def test_argv_for_full_serialises_every_passthrough_flag():
    """Direct unit test on _argv_for_full to lock down the
    serialisation contract (this is where dispatcher bugs hide)."""
    disp = _load_dispatcher()
    parser = disp._build_parser()
    args = parser.parse_args([
        "--profile", "full",
        "--skip-deliverables",
        "--pytest-timeout", "1800",
        "--aggregate-timeout", "1500",
        "--pytest-disable-plugin-autoload",
        "--format", "json",
    ])
    fwd = disp._argv_for_full(args)
    assert "--skip-deliverables" in fwd
    assert "--pytest-timeout" in fwd
    idx = fwd.index("--pytest-timeout")
    assert fwd[idx + 1] == "1800"
    assert "--aggregate-timeout" in fwd
    idx = fwd.index("--aggregate-timeout")
    assert fwd[idx + 1] == "1500"
    assert "--pytest-disable-plugin-autoload" in fwd
    assert "--format" in fwd
    idx = fwd.index("--format")
    assert fwd[idx + 1] == "json"


def test_default_profile_is_full():
    """Without --profile, the dispatcher must default to full (RC3
    contract) so existing CI invocations that just call the dispatcher
    keep their full-gate semantics."""
    disp = _load_dispatcher()
    parser = disp._build_parser()
    args = parser.parse_args([])
    assert args.profile == "full"


def test_banner_text_references_v4_92_and_rc3():
    """The patch-chain banner is the dispatcher's main UX promise to
    external reviewers. Locked down across v4.92 B13 — banner must
    call out v4.92 *and* the underlying RC3 contract."""
    disp = _load_dispatcher()
    import io
    buf = io.StringIO()
    disp._print_banner("fast", target=buf)
    text = buf.getvalue()
    assert "v4.92" in text
    assert "RC3" in text
    # Patch chain banner now spans v4.90.1..v4.92-b13-preclosure.
    assert "v4.90.1" in text
    assert "v4.92-b13-preclosure" in text
    assert "run_v490_rc3_closure_gate.py" in text


def test_fast_profile_runs_eleven_checks_in_under_three_minutes():
    """End-to-end: fast gate must finish quickly on a healthy package.
    v4.91 Batch 14.19 split: 11 items (F1, F3, F4, F5, F6, F7,
    F8a/b/c/d, F2). We do not assert pass/fail of each sub-check
    (the package may be mid-patch when this test runs), only that the
    dispatcher returns in bounded time and emits every sub-check ID.

    Time bound (180s) is a CI safeguard — *not* a documented benchmark.
    PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 keeps nested pytest invocations
    isolated from the outer test runner's plugins.
    """
    t0 = time.monotonic()
    r = _run_dispatcher(
        ["--profile", "fast"],
        timeout=180,
        extra_env={"PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1"},
    )
    elapsed = time.monotonic() - t0
    assert elapsed < 180, f"fast gate took {elapsed:.0f}s — too slow"
    out = r.stdout
    # All 11 sub-check IDs must appear in the output (v4.91 Batch 14.19).
    for cid in ("F1", "F2", "F3", "F4", "F5", "F6", "F7",
                "F8a", "F8b", "F8c", "F8d"):
        assert cid in out, f"fast gate output missing {cid}: {out[-500:]!r}"
    assert "release closure gate" in out
    assert "profile=fast" in out


# --------------------------------------------------------------------------
# v4.90.11 — fast-aggregate-wall-timeout flag (Batch 14.18)
# --------------------------------------------------------------------------


def test_fast_aggregate_wall_timeout_flag_default_and_override():
    """--fast-aggregate-wall-timeout (v4.90.11+) must default to 300
    and accept an integer override. The flag is fast-profile-only;
    full profile passes through without consulting it."""
    disp = _load_dispatcher()
    parser = disp._build_parser()

    args_default = parser.parse_args(["--profile", "fast"])
    assert args_default.fast_aggregate_wall_timeout == 300

    args_override = parser.parse_args([
        "--profile", "fast",
        "--fast-aggregate-wall-timeout", "900",
    ])
    assert args_override.fast_aggregate_wall_timeout == 900


def test_help_documents_fast_aggregate_wall_timeout():
    """--help must advertise --fast-aggregate-wall-timeout with its
    v4.90.11+ marker, default 300 hint, and 'fast profile only' note."""
    r = _run_dispatcher(["--help"], timeout=30)
    assert r.rc == 0, r.stdout + r.stderr
    out = r.stdout
    assert "--fast-aggregate-wall-timeout" in out
    assert "fast profile only" in out
    assert "default 300" in out
    assert "v4.90.11" in out


# --------------------------------------------------------------------------
# v4.91 Batch 14.19 — fast-total-timeout supervisor flag.
# --------------------------------------------------------------------------


def test_fast_total_timeout_flag_default_and_override():
    """--fast-total-timeout (v4.91 Batch 14.19+) caps the entire fast
    gate's wall-time. Default 600s; integer override accepted."""
    disp = _load_dispatcher()
    parser = disp._build_parser()

    args_default = parser.parse_args(["--profile", "fast"])
    assert args_default.fast_total_timeout == 600, (
        "default fast_total_timeout must be 600s"
    )

    args_override = parser.parse_args([
        "--profile", "fast",
        "--fast-total-timeout", "120",
    ])
    assert args_override.fast_total_timeout == 120


def test_help_documents_fast_total_timeout():
    """--help must advertise --fast-total-timeout with its v4.91
    marker, default 600 hint, and supervisor semantics."""
    r = _run_dispatcher(["--help"], timeout=30)
    assert r.rc == 0, r.stdout + r.stderr
    out = r.stdout
    assert "--fast-total-timeout" in out
    assert "fast profile only" in out
    assert "default 600" in out
    assert "v4.91" in out
