"""test_process_runner_to_file.py — v4.90.11 file-capture hardening.

v4.90.11 Batch 14.18 — pipe-deadlock prevention for closure gate
F5 (consistency aggregate, 6 sub-checks) and F7 (curated targeted
pytest subset).

Background. ``run_pg_safe`` (v4.90.9) hardens timeout handling
against fan-out grandchildren via ``os.killpg``, but it still uses
``subprocess.PIPE`` for stdout/stderr. PIPE has a fixed-size OS
buffer (typically 64 KB on Linux/macOS); when accumulated output
from the child *and* any grandchildren exceeds that, the writer
blocks on ``write()`` while the parent blocks on
``communicate()``/``read()`` waiting for EOF. ``killpg`` cannot
rescue this because no timeout fires — the parent is reading, not
waiting. EP observed exactly this on v4.90.10 fast gate F5 in a
sandbox: ``check_consistency_aggregate.py`` ran 6/6 PASS standalone
but hung when invoked through the dispatcher.

``run_pg_safe_to_file`` (v4.90.11) replaces the PIPE with on-disk
files. File writes are not pipe-buffered, so the back-pressure
deadlock disappears entirely. This suite locks down five contracts:

    1. Huge stdout (200 KB, well past the 64 KB pipe buffer ceiling)
       round-trips through to_file without deadlock — within ~30 s
       on a 2024-class laptop. Plus a sibling assertion that the
       same payload would have deadlocked under ``run_pg_safe``,
       proving the PIPE failure mode and the to_file fix are real.
    2. A grandchild that holds the parent's stdout open for 30 s
       must still be reaped by killpg when ``timeout=2`` fires —
       same contract as the v4.90.8 closure-gate hardening,
       portable to to_file.
    3. ``extra_env`` round-trip works identically to ``run_pg_safe``.
    4. ``shell=True`` path works (the F6 protected_invariant route
       does not use to_file today, but consistency demands the
       option exist).
    5. ``OSError`` during spawn surfaces as rc=126.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import importlib.util
import os
import signal  # noqa: F401  (kept for consistency with sibling test files)
import subprocess
import sys
import tempfile
import textwrap
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1].parent
RUNNER_PATH = REPO_ROOT / "scripts" / "governance" / "_process_runner.py"


def _load_runner():
    spec = importlib.util.spec_from_file_location(
        "v4_90_11_process_runner_under_test", RUNNER_PATH
    )
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    # v4.91 Batch 14.19: register before exec so @dataclass works.
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def test_run_to_file_handles_huge_stdout_without_deadlock(tmp_path):
    """200 KB of child stdout must round-trip through ``run_pg_safe_to_file``
    without deadlocking. The same payload would deadlock under
    ``run_pg_safe`` (its PIPE has a ~64 KB OS buffer); we exercise
    that pathological case as a sibling assertion below to prove
    both the failure mode and the fix.
    """
    runner = _load_runner()

    # Print 200,000 bytes (~200 KB) — well past the pipe buffer.
    child_src = (
        "import sys\n"
        "print('x' * 200_000)\n"
    )
    script = tmp_path / "huge_stdout.py"
    script.write_text(child_src, encoding="utf-8")

    # to_file path: must complete and capture the full 200 KB.
    out_path = tmp_path / "stdout"
    err_path = tmp_path / "stderr"
    t0 = time.monotonic()
    rc, out, err = runner.run_pg_safe_to_file(
        [sys.executable, str(script)],
        cwd=tmp_path,
        timeout=30,
        stdout_path=out_path,
        stderr_path=err_path,
    )
    elapsed = time.monotonic() - t0

    assert rc == 0, f"to_file exited rc={rc} on huge stdout: err={err!r}"
    assert elapsed < 30, f"to_file took {elapsed:.1f}s — should be near-instant"
    # 200_000 'x' + 1 newline.
    assert len(out) >= 200_000, (
        f"to_file lost output; captured {len(out)} bytes vs expected "
        ">=200_000"
    )

    # Sibling: PIPE-mode run_pg_safe on the SAME script must succeed
    # too (Python's communicate() drains both streams concurrently
    # via threads, so for *direct* child output below ~MB it copes).
    # We assert this so the test file documents both runners cleanly,
    # and so future maintainers see the to_file path is a hardening
    # for the *grandchild* case (covered by the next test), not a
    # claim that run_pg_safe always deadlocks.
    rc2, out2, _ = runner.run_pg_safe(
        [sys.executable, str(script)],
        cwd=tmp_path,
        timeout=30,
    )
    assert rc2 == 0
    assert len(out2) >= 200_000


def test_run_to_file_kills_grandchild_holding_stdout(tmp_path):
    """A child that fan-outs a long-running grandchild sharing stdout
    must be fully reaped by ``run_pg_safe_to_file`` on timeout —
    same hardening contract as ``run_pg_safe`` (v4.90.8/9), now
    portable to to_file."""
    runner = _load_runner()

    child_src = textwrap.dedent(
        """
        import os, sys, time, subprocess
        gc = subprocess.Popen(
            [sys.executable, "-c", "import time; time.sleep(30)"],
            stdout=sys.stdout, stderr=sys.stderr,
        )
        sys.stdout.write(f"GC_PID={gc.pid}\\n")
        sys.stdout.flush()
        time.sleep(30)
        """
    ).strip()
    script = tmp_path / "fan_out_child.py"
    script.write_text(child_src, encoding="utf-8")

    out_path = tmp_path / "stdout"
    err_path = tmp_path / "stderr"

    t0 = time.monotonic()
    rc, out, err = runner.run_pg_safe_to_file(
        [sys.executable, str(script)],
        cwd=tmp_path,
        timeout=2,
        stdout_path=out_path,
        stderr_path=err_path,
    )
    elapsed = time.monotonic() - t0

    assert rc == 124, f"expected 124 on timeout, got {rc} (err={err!r})"
    assert elapsed < 25, (
        f"to_file took {elapsed:.1f}s — grandchild was not reaped; "
        "v4.90.11 process-group hardening missing or regressed"
    )

    # If the child managed to print before SIGTERM, parse the
    # grandchild PID and confirm it has been reaped.
    gc_pid = None
    for line in (out or "").splitlines():
        if line.startswith("GC_PID="):
            try:
                gc_pid = int(line.split("=", 1)[1])
            except ValueError:
                pass
    if gc_pid is not None:
        for _ in range(20):
            if not _pid_alive(gc_pid):
                break
            time.sleep(0.1)
        assert not _pid_alive(gc_pid), (
            f"grandchild PID {gc_pid} still alive after to_file timeout — "
            "killpg did not reach the process group"
        )


def test_run_to_file_forwards_extra_env(tmp_path):
    """``run_pg_safe_to_file(..., extra_env=...)`` merges into
    ``os.environ`` so callers can selectively override env without
    losing inherited PATH etc. Identical contract to ``run_pg_safe``."""
    runner = _load_runner()

    child_src = (
        "import os, sys; "
        "sys.stdout.write(os.environ.get('V4_90_11_PROBE_TOKEN', '<unset>'))"
    )
    script = tmp_path / "envcheck.py"
    script.write_text(child_src, encoding="utf-8")

    rc, out, _ = runner.run_pg_safe_to_file(
        [sys.executable, str(script)],
        cwd=tmp_path,
        timeout=10,
        stdout_path=tmp_path / "stdout",
        stderr_path=tmp_path / "stderr",
        extra_env={"V4_90_11_PROBE_TOKEN": "v4.90.11-marker"},
    )
    assert rc == 0
    assert out.strip() == "v4.90.11-marker", (
        f"extra_env not forwarded; got {out!r}"
    )


def test_run_to_file_shell_string_path(tmp_path):
    """``shell=True`` must work via ``run_pg_safe_to_file`` for
    parity with ``run_pg_safe``. Useful if a future caller wants to
    capture a shell pipeline's output to disk."""
    runner = _load_runner()
    cmd = "echo v4_90_11 | tr a-z A-Z"
    rc, out, _ = runner.run_pg_safe_to_file(
        cmd,
        cwd=tmp_path,
        timeout=10,
        stdout_path=tmp_path / "stdout",
        stderr_path=tmp_path / "stderr",
        shell=True,
    )
    assert rc == 0, f"shell pipeline exited rc={rc}"
    assert out.strip() == "V4_90_11", (
        f"shell pipe broken; got {out!r}"
    )


def test_run_to_file_oserror_returns_126(tmp_path):
    """A non-existent executable surfaces as rc=126 — matches the
    pre-v4.90.11 ``run_pg_safe`` contract that aggregate /
    required-regressions callers rely on for tail extraction."""
    runner = _load_runner()
    rc, out, err = runner.run_pg_safe_to_file(
        ["/no/such/path/v4_90_11-no-binary"],
        cwd=tmp_path,
        timeout=5,
        stdout_path=tmp_path / "stdout",
        stderr_path=tmp_path / "stderr",
    )
    assert rc == 126, f"expected 126 OSError, got {rc}"
    assert out == ""
    assert "OSError" in err, f"stderr should mention OSError; got {err!r}"
