"""test_validate_registry_sync_guard.py — v4.90 Batch 3 Step 2.

Validates the sync-guard config checker + optional probe behaviour.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import textwrap


SCRIPT = "validate_registry_sync_guard.py"


def test_happy_all_rules_true(make_project, run_script):
    root = make_project()
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(0)
    assert "valid" in res.stdout


def test_one_rule_false_fails(make_project, run_script):
    bad = textwrap.dedent("""\
        preserve_historical_rows: true
        strip_markdown_markers: false
        refuse_silent_deletion: true
        dry_run_supported: true
        """)
    root = make_project(custom_sync_guard_yaml=bad)
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "strip_markdown_markers" in res.stderr
    assert "must be 'true'" in res.stderr


def test_rule_missing_fails(make_project, run_script):
    bad = textwrap.dedent("""\
        preserve_historical_rows: true
        strip_markdown_markers: true
        refuse_silent_deletion: true
        """)
    root = make_project(custom_sync_guard_yaml=bad)
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "dry_run_supported" in res.stderr
    assert "missing from config" in res.stderr


def test_probe_finds_dry_run_flag(make_project, run_script, tmp_path):
    fake_sync = tmp_path / "fake_sync.py"
    fake_sync.write_text(textwrap.dedent("""\
        #!/usr/bin/env python3
        import sys
        if "--help" in sys.argv:
            print("usage: fake_sync [--dry-run] [--strict]")
            sys.exit(0)
        sys.exit(0)
        """), encoding="utf-8")
    root = make_project()
    res = run_script(SCRIPT,
                     "--project-root", str(root),
                     "--sync-script", str(fake_sync))
    res.expect(0)
    assert "probe OK" in res.stdout


def test_probe_missing_flag_emits_warn_not_fail(make_project, run_script, tmp_path):
    fake_sync = tmp_path / "fake_sync.py"
    fake_sync.write_text(textwrap.dedent("""\
        #!/usr/bin/env python3
        import sys
        if "--help" in sys.argv:
            print("usage: fake_sync (no dry-run mode)")
            sys.exit(0)
        sys.exit(0)
        """), encoding="utf-8")
    root = make_project()
    res = run_script(SCRIPT,
                     "--project-root", str(root),
                     "--sync-script", str(fake_sync))
    # rules valid, probe warns but doesn't fail
    res.expect(0)
    assert "WARN" in res.stderr
    assert "no --dry-run" in res.stderr


def test_missing_config_returns_4(tmp_path, run_script):
    res = run_script(SCRIPT, "--project-root", str(tmp_path))
    res.expect(4)
    assert "config not found" in res.stderr
