"""test_gate_report_schema.py — v4.91 Batch 0 c1.

Validates the JSON report emitted by ``run_release_closure_gate.py``
at ``exports/closure/fast_gate_report.json`` against
``schemas/governance/gate_report.schema.json``.

v4.91 B0 c1 introduces an explicit 5-state ``status`` field
(pass / fail / timeout / killed / skipped) so downstream tooling can
distinguish failure modes without re-deriving them from the legacy
(ok, supervisor_timeout) pair semantics. This suite locks the contract:

    1. Schema file itself is well-formed JSON Schema draft-07.
    2. A live fast gate run produces a report that validates against
       the schema (round-trip).
    3. ``_derive_gate_status`` maps the four non-pass synthesised
       records correctly (fail / timeout / killed / skipped) so the
       payload is never written with an undeclared status value.

Layer 1. No project names.
"""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = (
    REPO_ROOT / "schemas" / "governance" / "gate_report.schema.json"
)
DISPATCHER_PATH = (
    REPO_ROOT / "scripts" / "governance" / "run_release_closure_gate.py"
)


def _load_dispatcher_module():
    """Load the dispatcher as a module so we can call _derive_gate_status
    directly without re-running the full fast gate.

    Note: register the module in sys.modules before exec so dataclass
    decorators inside the module can resolve their own ``__module__``
    qualifier on Python 3.13.
    """
    name = "_dispatcher_for_gate_report_schema_test"
    if name in sys.modules:
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, DISPATCHER_PATH)
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def _has_jsonschema() -> bool:
    try:
        import jsonschema  # noqa: F401
    except ImportError:
        return False
    return True


# ---------------------------------------------------------------------------
# Test 1 — schema file shape contract.
# ---------------------------------------------------------------------------

def test_gate_report_schema_well_formed():
    """The schema file is valid JSON, declares the expected top-level
    contract version, and lists exactly the 5 status enum values."""
    assert SCHEMA_PATH.exists(), (
        f"v4.91 B0 c1 contract: schema must exist at {SCHEMA_PATH}"
    )
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))

    # Top-level shape.
    assert schema["title"].startswith("Release Closure Gate Report")
    assert schema["properties"]["schema_version"]["const"] == "1.0.0"
    assert schema["properties"]["profile"]["enum"] == ["fast", "full"]

    # The 5-state status vocabulary is the v4.91 B0 contract. Lock it
    # down so future patches cannot silently widen or shrink it.
    record_props = (
        schema["definitions"]["result_record"]["properties"]
    )
    status_enum = record_props["status"]["enum"]
    assert sorted(status_enum) == sorted(
        ["pass", "fail", "timeout", "killed", "skipped"]
    ), (
        "v4.91 B0 c1 contract: status enum must be exactly "
        "{pass, fail, timeout, killed, skipped}"
    )

    # status MUST be required (authoritative, not optional).
    required = schema["definitions"]["result_record"]["required"]
    assert "status" in required, (
        "v4.91 B0 c1 contract: status field must be required"
    )


# ---------------------------------------------------------------------------
# Test 2 — synthesised payload round-trips through the schema.
# ---------------------------------------------------------------------------
#
# Rationale: we deliberately do NOT spawn the live fast gate here. Doing
# so would couple this schema test to RELEASE_MANIFEST hash drift (the
# clean-tree gate F2 fails the moment any new file — like this very
# schema or test — is added before the manifest is regenerated), which
# would create a chicken-and-egg dependency between B0 c1 and the
# regular per-batch manifest sync. Instead we synthesise a payload that
# mirrors the dispatcher's actual write path (built via _derive_gate_status
# from realistic record skeletons) and validate it against the schema.
# A separate test in test_release_closure_gate_dispatcher.py exercises
# the live spawn path.

@pytest.mark.skipif(
    not _has_jsonschema(),
    reason="jsonschema package not installed in this environment",
)
def test_synthesised_payload_matches_schema():
    """Build a payload identical in shape to what _persist_logs_and_reports
    writes, run every status state through it, and validate against the
    schema.
    """
    import jsonschema

    mod = _load_dispatcher_module()
    derive = mod._derive_gate_status
    schema_version = mod.GATE_REPORT_SCHEMA_VERSION

    base_records = [
        # pass
        {
            "id": "F1",
            "label": "pytest --collect-only floor",
            "ok": True,
            "summary": "997 tests collected (>= 928)",
            "command": ["python3", "-m", "pytest", "--collect-only", "-q"],
            "elapsed": 0.85,
            "supervisor_timeout": False,
            "stdout_text": "",
            "stderr_text": "",
        },
        # fail
        {
            "id": "F6",
            "label": "protected regressions 7/7",
            "ok": False,
            "summary": "5/7 invariants enforced (2 violations)",
            "command": ["python3", "scripts/governance/check_required_regressions.py"],
            "elapsed": 0.5,
            "supervisor_timeout": False,
            "stdout_text": "",
            "stderr_text": "",
        },
        # timeout
        {
            "id": "F8a",
            "label": "tests/cli",
            "ok": False,
            "summary": "SUPERVISOR_TIMEOUT after 600.0s",
            "command": ["python3", "-m", "pytest", "tests/cli"],
            "elapsed": 600.0,
            "supervisor_timeout": True,
            "stdout_text": "",
            "stderr_text": "[supervisor] watchdog tripped\n",
        },
        # killed
        {
            "id": "F5",
            "label": "consistency aggregate 6/6",
            "ok": False,
            "summary": "aggregate exit 124",
            "command": ["python3", "scripts/governance/check_consistency_aggregate.py"],
            "elapsed": 30.0,
            "supervisor_timeout": False,
            "stdout_text": "",
            "stderr_text": "TIMEOUT (process group unreaped)\n",
        },
        # skipped
        {
            "id": "F2",
            "label": "release clean-tree (post-clean)",
            "ok": False,
            "summary": "SKIPPED (--fast-total-timeout exhausted)",
            "command": [],
            "elapsed": 0.0,
            "supervisor_timeout": True,
            "stdout_text": "",
            "stderr_text": "[supervisor] skipped — fast-total-timeout exhausted\n",
        },
    ]

    # Mirror _persist_logs_and_reports cleanup (drop stdout_text/stderr_text,
    # add stdout_file/stderr_file + status).
    cleaned = []
    for r in base_records:
        c = {k: v for k, v in r.items() if k not in {"stdout_text", "stderr_text"}}
        c["stdout_file"] = f"exports/closure/fast_gate_logs/{r['id']}.stdout"
        c["stderr_file"] = f"exports/closure/fast_gate_logs/{r['id']}.stderr"
        c["status"] = derive(r)
        cleaned.append(c)

    payload = {
        "schema_version": schema_version,
        "profile": "fast",
        "patch_chain": "v4.90.1..v4.91-B0",
        "overall_exit": 1,
        "total_elapsed_seconds": 631.85,
        "fast_total_timeout_seconds": 600,
        "results": cleaned,
    }

    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    jsonschema.validate(payload, schema)

    # The 5 cleaned records must exhibit the 5 distinct status values.
    assert sorted({c["status"] for c in cleaned}) == sorted(
        ["pass", "fail", "timeout", "killed", "skipped"]
    )


# ---------------------------------------------------------------------------
# Test 3 — _derive_gate_status maps the 4 non-pass synthesised records.
# ---------------------------------------------------------------------------

def test_derive_status_maps_all_five_states():
    """The 5-state mapping is the authoritative contract. Synthesise
    one record per non-pass state and assert the derivation produces
    the expected label.
    """
    mod = _load_dispatcher_module()
    derive = mod._derive_gate_status

    # pass
    rec_pass = {"ok": True, "summary": "60 passed", "supervisor_timeout": False}
    assert derive(rec_pass) == "pass"

    # skipped — supervisor never dispatched (deadline exhausted).
    rec_skipped = {
        "ok": False,
        "summary": "SKIPPED (--fast-total-timeout exhausted)",
        "supervisor_timeout": True,
        "elapsed": 0.0,
        "command": [],
        "stderr_text": "[supervisor] skipped — fast-total-timeout exhausted\n",
    }
    assert derive(rec_skipped) == "skipped"

    # timeout — supervisor watchdog tripped on a dispatched item.
    rec_timeout = {
        "ok": False,
        "summary": "SUPERVISOR_TIMEOUT after 600.0s",
        "supervisor_timeout": True,
        "elapsed": 600.0,
        "command": ["python3", "-m", "pytest"],
        "stderr_text": "[supervisor] watchdog tripped after 600.0s\n",
    }
    assert derive(rec_timeout) == "timeout"

    # killed — process group reaped (legacy 3-tuple wrapper sentinel).
    rec_killed = {
        "ok": False,
        "summary": "pytest exit 124 (timed_out=True)",
        "supervisor_timeout": False,
        "elapsed": 30.0,
        "command": ["python3", "-m", "pytest"],
        "stderr_text": "TIMEOUT (process group unreaped)\n",
    }
    assert derive(rec_killed) == "killed"

    # fail — assertion failure with no timeout/kill signal.
    rec_fail = {
        "ok": False,
        "summary": "5/7 invariants enforced (2 violations)",
        "supervisor_timeout": False,
        "elapsed": 0.5,
        "command": ["python3", "scripts/governance/check_required_regressions.py"],
        "stderr_text": "",
    }
    assert derive(rec_fail) == "fail"
