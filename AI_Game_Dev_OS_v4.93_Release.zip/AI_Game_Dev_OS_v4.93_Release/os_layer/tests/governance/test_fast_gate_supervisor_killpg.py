"""test_fast_gate_supervisor_killpg.py — v4.91 B0 c4.

Dispatcher-level regression suite for the RC1-review P0 fix.

Context
-------
The RC1 review demonstrated that the *old* fast-gate supervisor
(``_run_fast_item_with_supervisor``: a daemon ``threading.Thread`` +
``Thread.join(timeout)``) could only *record* a timeout — it had no
handle on the subprocess tree the F-item helper had spawned, so on
budget exhaustion the dispatcher returned while a
``pytest --collect-only`` child (and its grandchildren) kept running.
The plan's Batch 0 requirement — "Timeout kills child/grandchild
process trees" — was therefore NOT met.

v4.91 B0 c1/c2/c3 replaced that model: each F-item now runs in its own
OS process group launched via ``--run-single-fast-item`` through
``run_pg_safe_to_file_v2(cleanup_process_group_on_exit=True)``. The
dispatcher owns the child's pgid and SIGKILLs the entire group when
its wall-clock budget trips.

The existing ``test_process_runner_grandchild_cleanup.py`` proves the
*runner* primitive kills process groups. This suite proves the
*dispatcher* (``_run_fast_item_via_subprocess``) actually uses it:
a synthetic hanging F-item must (a) be killed within budget+grace,
(b) leave NO live process-group members, and (c) be classified
``killed`` by ``_derive_gate_status`` via the structured
``killed_pg`` field — not merely time out on paper.

Marked ``gate_runner`` so the fast gate never recurses into itself.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import time
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
DISPATCHER = REPO_ROOT / "scripts" / "governance" / "run_release_closure_gate.py"

if str(REPO_ROOT / "scripts" / "governance") not in sys.path:
    sys.path.insert(0, str(REPO_ROOT / "scripts" / "governance"))

pytestmark = pytest.mark.gate_runner


def _load_dispatcher():
    spec = importlib.util.spec_from_file_location(
        "_dispatcher_killpg_under_test", DISPATCHER
    )
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def _pg_alive(pgid: int) -> bool:
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


# ---------------------------------------------------------------------------
# _derive_gate_status: structured killed_pg classification
# ---------------------------------------------------------------------------

def test_derive_status_killed_when_supervisor_timeout_and_killed_pg():
    """A timed-out item whose process group WAS reaped is classified
    ``killed`` — the strongest evidence the leak is fixed."""
    disp = _load_dispatcher()
    rec = {
        "ok": False,
        "supervisor_timeout": True,
        "killed_pg": True,
        "elapsed": 5.0,
        "command": ["x"],
        "summary": "SUPERVISOR_TIMEOUT after 5.0s — process group SIGKILLed",
        "stderr_text": "",
    }
    assert disp._derive_gate_status(rec) == disp.GATE_STATUS_KILLED


def test_derive_status_timeout_when_supervisor_timeout_without_kill():
    """A timed-out item whose PG was already empty (no kill needed)
    is classified ``timeout`` (budget tripped, nothing to reap)."""
    disp = _load_dispatcher()
    rec = {
        "ok": False,
        "supervisor_timeout": True,
        "killed_pg": False,
        "elapsed": 5.0,
        "command": ["x"],
        "summary": "SUPERVISOR_TIMEOUT after 5.0s",
        "stderr_text": "",
    }
    assert disp._derive_gate_status(rec) == disp.GATE_STATUS_TIMEOUT


def test_derive_status_skipped_when_never_dispatched():
    """Deadline already exhausted before dispatch → ``skipped``."""
    disp = _load_dispatcher()
    rec = {
        "ok": False,
        "supervisor_timeout": True,
        "killed_pg": False,
        "elapsed": 0.0,
        "command": [],
        "summary": "SKIPPED (--fast-total-timeout exhausted)",
        "stderr_text": "",
    }
    assert disp._derive_gate_status(rec) == disp.GATE_STATUS_SKIPPED


# ---------------------------------------------------------------------------
# Dispatcher-level end-to-end: hanging item is killpg'd, no stragglers
# ---------------------------------------------------------------------------

def test_dispatcher_kills_hanging_item_process_group(tmp_path, monkeypatch):
    """End-to-end proof of the RC2-FC P0 fix at the dispatcher layer.

    HISTORY — this test was a FALSE POSITIVE in the prior cycle. Its
    hang hook spawned the sleep tree with a plain ``subprocess.Popen``
    that did NOT start a new session, so the children always stayed in
    the wrapper's group and the dispatcher's killpg always reaped them.
    It therefore passed while the REAL helper path leaked: the actual
    F-item helpers launch pytest/validator via the ``_runner_imports()``
    runners, which used ``start_new_session=True`` — a NEW group (B)
    that the dispatcher's killpg (group A) could not reach. The RC2
    round-2 review reproduced that orphan.

    This rewrite makes the hook faithful: it launches its ``sleep`` via
    the SAME ``run_pg_safe_v2`` path the real helpers use, so it honours
    the ``GATE_IN_SINGLE_ITEM`` env the dispatcher sets. The fix
    (c1 ``new_session`` param + c2 wiring) makes that runner spawn the
    sleep in the wrapper's group, so the dispatcher's single outer
    killpg reaps it. Without the fix the sleep would escape into its
    own session and survive — exactly the leak under test.

    The dispatcher must:
      * return within budget + runner grace (not hang),
      * report supervisor_timeout=True and killed_pg=True,
      * leave the hook's ``sleep`` (spawned via the real runner path)
        DEAD — no orphan.

    We reuse a real fast-item id (F7) as the hang target — the hook
    short-circuits before F7's normal logic runs.
    """
    disp = _load_dispatcher()

    marker = tmp_path / "sleep_pid"
    monkeypatch.setenv("GATE_TEST_HANG_ITEM_ID", "F7")
    monkeypatch.setenv("GATE_TEST_HANG_MARKER", str(marker))

    fake = disp.FastItem("F7", "synthetic hanging item (hook)", lambda a: None)

    import argparse
    args = argparse.Namespace(
        fast_total_timeout=3,
        aggregate_timeout=600,
        fast_aggregate_wall_timeout=5,
        format="json",
    )

    started = time.monotonic()
    record = disp._run_fast_item_via_subprocess(fake, args, remaining_budget=3.0)
    elapsed = time.monotonic() - started

    # 1. The dispatcher returned in bounded time (budget + runner grace).
    #    run_pg_safe_to_file_v2 grace = SIGTERM_GRACE(10)+SIGKILL_DRAIN(5).
    assert elapsed < 25.0, f"dispatcher hung {elapsed:.1f}s — budget not enforced"

    # 2. Classified as a timeout that actually reaped the group.
    assert record["supervisor_timeout"] is True
    assert record["killed_pg"] is True, (
        "dispatcher budget tripped but PG was not reaped — the orphan leak"
    )
    assert disp._derive_gate_status(record) == disp.GATE_STATUS_KILLED

    # 3. The hook's sleep — launched through the REAL runner path
    #    (run_pg_safe_v2, honouring GATE_IN_SINGLE_ITEM) — must be dead.
    #    This is the assertion the prior false-positive test could not
    #    make, because its sleep never went through the escaping path.
    assert marker.exists(), "hang hook never wrote sleep marker — hook didn't fire"
    sleep_pid = int(marker.read_text(encoding="utf-8").strip())

    deadline = time.monotonic() + 5.0
    while time.monotonic() < deadline and _pid_alive(sleep_pid):
        time.sleep(0.1)

    if _pid_alive(sleep_pid):
        # Best-effort cleanup so a failure doesn't leak a real orphan.
        try:
            os.kill(sleep_pid, 9)
        except ProcessLookupError:
            pass
        pytest.fail(
            f"sleep {sleep_pid} (spawned via the real runner path) still "
            f"alive after dispatcher timeout — orphan escaped the outer "
            f"killpg (the exact RC2 round-2 P0 failure)"
        )


# ---------------------------------------------------------------------------
# v4.91 RC2-FC2 P0-2 — second-level-script (legacy wrapper) leak path
# ---------------------------------------------------------------------------

def test_dispatcher_kills_legacy_wrapper_inner_process_group(tmp_path, monkeypatch):
    """End-to-end proof of the RC2-FC2 P0-1 fix at the SECOND-LEVEL path.

    WHY A SEPARATE TEST — the sibling
    ``test_dispatcher_kills_hanging_item_process_group`` exercises the
    case where the F-item helper launches its child directly through the
    dispatcher's ``_runner_imports()`` runner (``run_pg_safe_v2``). But the
    real fast items F5 (consistency aggregate) and F6 (required
    regressions) do NOT do that. They shell out to a SECOND governance
    script — ``check_consistency_aggregate.py`` / ``check_required_
    regressions.py`` — and *those* scripts call the LEGACY
    ``run_pg_safe`` wrapper to spawn pytest.

    The 3rd review reproduced an orphan precisely here: before P0-1 the
    legacy wrapper hard-coded ``new_session=True`` (it didn't even expose
    the parameter), so even though the dispatcher set
    ``GATE_IN_SINGLE_ITEM=1`` and spawned the wrapper with
    ``new_session=False`` (group A), the inner pytest launched by the
    second-level script re-created its OWN session (group B). The
    dispatcher's single outer ``killpg`` on group A could not reach group
    B → orphan pytest survived a fast-gate timeout.

    P0-1 makes the legacy ``run_pg_safe`` honour ``GATE_IN_SINGLE_ITEM``
    too (``new_session = not nested``), so the inner process stays in the
    dispatcher's group and the one outer ``killpg`` reaps the whole tree.

    The hook models this faithfully via ``GATE_TEST_HANG_VIA_LEGACY=1``:
    it spawns the long ``sleep`` through the legacy ``run_pg_safe`` wrapper
    — the exact call shape the second-level scripts use — instead of
    ``run_pg_safe_v2``. Assertion: after the dispatcher's budget trips, the
    sleep must be DEAD. Without P0-1 it escapes into its own session and
    survives (the reproduced leak).
    """
    disp = _load_dispatcher()

    marker = tmp_path / "legacy_sleep_pid"
    monkeypatch.setenv("GATE_TEST_HANG_ITEM_ID", "F7")
    monkeypatch.setenv("GATE_TEST_HANG_MARKER", str(marker))
    monkeypatch.setenv("GATE_TEST_HANG_VIA_LEGACY", "1")

    fake = disp.FastItem("F7", "synthetic hanging item (legacy wrapper hook)", lambda a: None)

    import argparse
    args = argparse.Namespace(
        fast_total_timeout=3,
        aggregate_timeout=600,
        fast_aggregate_wall_timeout=5,
        format="json",
    )

    started = time.monotonic()
    record = disp._run_fast_item_via_subprocess(fake, args, remaining_budget=3.0)
    elapsed = time.monotonic() - started

    # 1. Dispatcher returned in bounded time (budget + runner grace).
    assert elapsed < 25.0, f"dispatcher hung {elapsed:.1f}s — budget not enforced"

    # 2. Classified as a timeout that actually reaped the group.
    assert record["supervisor_timeout"] is True
    assert record["killed_pg"] is True, (
        "dispatcher budget tripped but PG was not reaped — second-level "
        "legacy-wrapper orphan leak"
    )
    assert disp._derive_gate_status(record) == disp.GATE_STATUS_KILLED

    # 3. The sleep — launched through the LEGACY run_pg_safe wrapper, the
    #    exact path F5/F6 second-level scripts use — must be dead. This is
    #    the assertion the sibling v2-path test could not make.
    assert marker.exists(), "legacy-wrapper hang hook never wrote sleep marker"
    sleep_pid = int(marker.read_text(encoding="utf-8").strip())

    deadline = time.monotonic() + 5.0
    while time.monotonic() < deadline and _pid_alive(sleep_pid):
        time.sleep(0.1)

    if _pid_alive(sleep_pid):
        try:
            os.kill(sleep_pid, 9)
        except ProcessLookupError:
            pass
        pytest.fail(
            f"sleep {sleep_pid} (spawned via the LEGACY run_pg_safe wrapper) "
            f"still alive after dispatcher timeout — the second-level-script "
            f"orphan escaped the outer killpg (the exact 3rd-review F6 leak)"
        )
