"""test_validate_current_state_surface.py — v4.90 Batch 3 Step 2.

Validates the content-conformance script: required sections + forbidden
keywords + surface filter + missing inputs.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import textwrap


SCRIPT = "validate_current_state_surface.py"


def test_happy_all_sections_present(make_project, run_script):
    root = make_project()
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(0)
    assert "conformant" in res.stdout


def test_missing_agent_log_section(make_project, run_script):
    # remove "Current Truth" from agent log sections
    root = make_project(agent_log_sections=[
        "## Current Hot State",
        "## Current Task",
        "## Active References",
        "## Next Step",
    ])
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "Current Truth" in res.stderr


def test_missing_sprint_board_section(make_project, run_script):
    # missing Index links
    root = make_project(sprint_board_sections=[
        "# Sprint header (id / status)",
        "## Active task rows",
        "## Current evidence pointer",
    ])
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "Index links" in res.stderr


def test_forbidden_keyword_detected(make_project, run_script):
    # Add a forbidden keyword in the agent log; declare it in policy
    forbidden_token = "closed_sprint_summary_dump"
    custom_policy = textwrap.dedent(f"""\
        surfaces:
          - surface_kind: agent_log
            tier: 1
            path: logs/agents/eng.md
            line_count_policy: standard
            content_kinds_forbidden:
              - {forbidden_token}
        archive_strategy: by_sprint
        """)
    root = make_project(
        custom_policy_yaml=custom_policy,
        forbidden_keyword_in_log=f"DEBUG {forbidden_token} occurred",
    )
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert forbidden_token in res.stderr
    assert "L" in res.stderr  # line number annotation


def test_surface_filter_limits_scope(make_project, run_script):
    # break sprint_board (missing section) but ask only for agent_log
    root = make_project(sprint_board_sections=["# Bad header only"])
    res = run_script(SCRIPT, "--project-root", str(root),
                     "--surface", "agent_log")
    # agent_log is fine, sprint_board not checked → should pass
    res.expect(0)


def test_missing_policy_returns_4(tmp_path, run_script):
    res = run_script(SCRIPT, "--project-root", str(tmp_path))
    res.expect(4)
    assert "policy not found" in res.stderr
