"""test_process_runner_grandchild_cleanup.py — v4.91 Batch 14.19.

Anti-hang test suite for the v4.91 Gate Runner Architecture Patch:
verifies the four failure modes that motivated EP §3 (cleanup_process_
group_on_exit) and EP §6 (fast-gate total wall-time supervisor).

Marked ``gate_runner`` so the fast gate excludes them — these tests
launch their own subprocess trees with deliberate timeouts and are
meant to run in the **full** gate or a dedicated gate-runner sweep,
not in the fast smoke gate.

Test matrix (mirrors the EP plan §8 A/B/C/D):

    A. parent_exits_grandchild_alive
       Direct child exits 0; spawned ``(sleep 30 &)`` grandchild
       lingers. Runner with ``cleanup_process_group_on_exit=True``
       must SIGTERM the process group, set ``killed_pg=True``, and
       leave no live PG members.

    B. grandchild_holds_stdout
       Grandchild inherits stdout/stderr fds. With file capture +
       cleanup-on-exit, the runner must not block on fd-close
       (file writes don't pipe-buffer) and must reap the
       grandchild via PG cleanup.

    C. nested_pytest_child_hangs
       Outer process is pytest invoking a fixture that spawns an
       infinite-sleep grandchild. With file capture + reasonable
       timeout, the runner returns rc=124 within timeout+grace,
       not later.

    D. fast_gate_item_supervisor (smoke level)
       A single fake F-item that sleeps forever must not exceed
       the supervisor's wall-time budget. Implemented as a
       library-level call (full gate dispatcher integration is
       covered in test_release_closure_gate_dispatcher).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import os
import signal
import sys
import tempfile
import time
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT / "scripts" / "governance"))

from _process_runner import (  # noqa: E402  (path-injected import)
    RunResult,
    run_pg_safe_v2,
    run_pg_safe_to_file_v2,
)

pytestmark = pytest.mark.gate_runner


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _pg_alive(pgid: int) -> bool:
    """Best-effort liveness probe via signal 0 (no-op kill)."""
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        # Treat permission denied as 'something there' — conservative
        # because we want the assert-no-stragglers test to FAIL loudly
        # if anything is left, not silently pass.
        return True
    return True


# ---------------------------------------------------------------------------
# Test A — parent exits, grandchild alive (file capture path)
# ---------------------------------------------------------------------------

def test_a_parent_exits_grandchild_alive_file_capture(tmp_path: Path) -> None:
    """File-capture runner with cleanup-on-exit reaps the lingering
    ``(sleep 30 &)`` grandchild via SIGTERM to the process group.

    rc=0 (child exited cleanly), timed_out=False, killed_pg=True,
    cleanup_invoked=True.
    """
    r: RunResult = run_pg_safe_to_file_v2(
        ["/bin/sh", "-c", "(sleep 30 &) ; exit 0"],
        cwd=REPO_ROOT,
        timeout=10,
        stdout_path=tmp_path / "o",
        stderr_path=tmp_path / "e",
        cleanup_process_group_on_exit=True,
    )
    assert r.rc == 0
    assert not r.timed_out
    assert r.cleanup_invoked
    assert r.killed_pg, "expected runner to reap the lingering grandchild PG"
    assert r.elapsed < 5.0, f"cleanup took {r.elapsed:.2f}s — should be fast"


def test_a_parent_exits_grandchild_alive_pipe_documented_limitation(
    tmp_path: Path,
) -> None:
    """PIPE runner cannot reap grandchildren that inherit stdout
    because ``communicate()`` cannot return until every fd holder
    closes. This is the exact reason fast gate F5/F7 use file
    capture (v4.90.11). Documented behaviour: timeout path fires.

    This test exists to LOCK that behaviour so future refactors of
    ``run_pg_safe_v2`` cannot silently regress to deadlock.
    """
    r: RunResult = run_pg_safe_v2(
        ["/bin/sh", "-c", "(sleep 30 &) ; exit 0"],
        cwd=REPO_ROOT,
        timeout=2,
        cleanup_process_group_on_exit=True,
    )
    assert r.timed_out, "PIPE runner with grandchild MUST hit outer timeout"
    assert r.killed_pg
    assert r.rc == 124
    # cleanup_invoked is False because we hit the timeout branch first
    assert not r.cleanup_invoked


# ---------------------------------------------------------------------------
# Test B — grandchild holds stdout/stderr (file capture is the cure)
# ---------------------------------------------------------------------------

def test_b_grandchild_holds_stdout_file_capture_does_not_block(
    tmp_path: Path,
) -> None:
    """Grandchild inherits stdout/stderr (writes a small line, then
    sleeps holding the fd). With file capture, the parent's
    ``proc.wait`` is fd-independent — the runner must NOT block on
    fd-close. Cleanup-on-exit then reaps the grandchild.
    """
    script = (
        # Backgrounded grandchild prints, then sleeps holding inherited fds.
        "( echo grandchild-here ; sleep 30 ) & exit 0"
    )
    started = time.monotonic()
    r: RunResult = run_pg_safe_to_file_v2(
        ["/bin/sh", "-c", script],
        cwd=REPO_ROOT,
        timeout=10,
        stdout_path=tmp_path / "o",
        stderr_path=tmp_path / "e",
        cleanup_process_group_on_exit=True,
    )
    elapsed = time.monotonic() - started
    assert r.rc == 0
    assert not r.timed_out, f"file capture must not block on fd-close, elapsed={elapsed:.2f}"
    assert r.killed_pg, "grandchild should have been reaped"
    assert elapsed < 5.0, f"runner took {elapsed:.2f}s — should be fast"


# ---------------------------------------------------------------------------
# Test C — nested pytest with hanging child
# ---------------------------------------------------------------------------

def test_c_nested_pytest_child_hangs_returns_rc124(tmp_path: Path) -> None:
    """Outer process is a pytest run whose only test spawns an
    infinite-sleep grandchild and waits on it. Runner timeout=3s
    must trip and return rc=124 within timeout+SIGTERM+SIGKILL
    grace (~18s upper bound), not later.
    """
    fixture_dir = tmp_path / "nested"
    fixture_dir.mkdir()
    (fixture_dir / "test_hang.py").write_text(
        "import subprocess\n"
        "def test_hang():\n"
        "    subprocess.run(['sleep', '60'])\n",
        encoding="utf-8",
    )

    started = time.monotonic()
    r: RunResult = run_pg_safe_to_file_v2(
        [
            sys.executable, "-m", "pytest",
            str(fixture_dir),
            "-q", "--no-header",
        ],
        cwd=REPO_ROOT,
        timeout=3,
        stdout_path=tmp_path / "o",
        stderr_path=tmp_path / "e",
        extra_env={"PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1"},
        cleanup_process_group_on_exit=True,
    )
    elapsed = time.monotonic() - started
    assert r.timed_out
    assert r.rc == 124
    assert r.killed_pg
    # Upper bound: timeout (3) + SIGTERM_GRACE (10) + SIGKILL_DRAIN (5) + fudge.
    assert elapsed < 25.0, f"runner took {elapsed:.2f}s — should be ≤ ~18s"


# ---------------------------------------------------------------------------
# Test D — fast gate F-item supervisor smoke (library level)
# ---------------------------------------------------------------------------

def test_d_runner_timeout_returns_quickly_for_supervisor() -> None:
    """Lightweight smoke for the fast-gate supervisor invariant: a
    single F-item that sleeps forever returns rc=124 within the
    runner's own timeout grace. The supervisor (added in
    run_release_closure_gate.py:run_fast) layers an outer
    --fast-total-timeout on top of this; this test ensures the
    inner runner cooperates by not hanging past timeout+grace.
    """
    started = time.monotonic()
    r: RunResult = run_pg_safe_v2(
        ["/bin/sh", "-c", "sleep 60"],
        cwd=REPO_ROOT,
        timeout=2,
    )
    elapsed = time.monotonic() - started
    assert r.timed_out and r.rc == 124 and r.killed_pg
    assert elapsed < 20.0, (
        f"single-item timeout took {elapsed:.2f}s — "
        f"supervisor depends on this being ≤ timeout+grace"
    )
