"""test_generate_state_surface_index.py — v4.90 Batch 3 Step 3.

Validates the index shell scaffolder: create / skip / dry-run / force /
safety threshold / missing policy / missing indexes node.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import textwrap


SCRIPT = "generate_state_surface_index.py"


def _policy_with_indexes() -> str:
    return textwrap.dedent("""\
        surfaces:
          - surface_kind: sprint_board
            tier: 1
            path: tasks/sprint_board.md
            line_count_policy: standard
        archive_strategy: by_sprint
        indexes:
          sprint_index: tasks/sprint_index.md
          task_index: tasks/task_index.md
          agents_index: logs/agents/index.md
          orchestrator_decision_index: logs/orchestrator_decision_index.md
        """)


def test_dry_run_lists_actions_no_writes(make_project, run_script):
    root = make_project(custom_policy_yaml=_policy_with_indexes())
    # remove any pre-existing index files
    for rel in ["tasks/sprint_index.md", "tasks/task_index.md",
                "logs/agents/index.md",
                "logs/orchestrator_decision_index.md"]:
        p = root / rel
        if p.exists():
            p.unlink()
    res = run_script(SCRIPT, "--project-root", str(root), "--dry-run")
    res.expect(0)
    assert "would_create" in res.stdout
    assert "(dry-run)" in res.stdout
    # nothing should have been written
    assert not (root / "tasks" / "sprint_index.md").exists()


def test_create_when_missing(make_project, run_script):
    root = make_project(custom_policy_yaml=_policy_with_indexes())
    for rel in ["tasks/sprint_index.md", "tasks/task_index.md",
                "logs/agents/index.md",
                "logs/orchestrator_decision_index.md"]:
        p = root / rel
        if p.exists():
            p.unlink()
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(0)
    for rel in ["tasks/sprint_index.md", "tasks/task_index.md",
                "logs/agents/index.md",
                "logs/orchestrator_decision_index.md"]:
        target = root / rel
        assert target.exists(), f"expected {rel} to be created"
        text = target.read_text(encoding="utf-8")
        # routing-only Tier 2 surface — must include header + table marker
        assert "Index" in text
        assert "Auto-generated shell" in text


def test_skip_when_exists_above_threshold(make_project, run_script):
    root = make_project(custom_policy_yaml=_policy_with_indexes())
    target = root / "tasks" / "sprint_index.md"
    target.write_text("x" * 200, encoding="utf-8")
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(0)
    assert "skipped_exists" in res.stdout
    # file untouched
    assert target.read_text(encoding="utf-8") == "x" * 200


def test_force_overwrites_only_below_threshold(make_project, run_script):
    root = make_project(custom_policy_yaml=_policy_with_indexes())
    target_small = root / "tasks" / "sprint_index.md"
    target_big = root / "tasks" / "task_index.md"
    target_small.write_text("x", encoding="utf-8")          # 1 byte
    target_big.write_text("y" * 500, encoding="utf-8")      # 500 bytes
    res = run_script(SCRIPT, "--project-root", str(root), "--force")
    res.expect(0)
    # small one was rewritten with shell template
    new_small = target_small.read_text(encoding="utf-8")
    assert "Sprint Index" in new_small
    # big one preserved despite --force (safety threshold)
    assert target_big.read_text(encoding="utf-8") == "y" * 500


def test_missing_policy_returns_4(tmp_path, run_script):
    res = run_script(SCRIPT, "--project-root", str(tmp_path))
    res.expect(4)
    assert "policy not found" in res.stderr


def test_missing_indexes_node_returns_1(make_project, run_script):
    bad_policy = textwrap.dedent("""\
        surfaces:
          - surface_kind: sprint_board
            tier: 1
            path: tasks/sprint_board.md
            line_count_policy: standard
        archive_strategy: by_sprint
        """)
    root = make_project(custom_policy_yaml=bad_policy)
    res = run_script(SCRIPT, "--project-root", str(root))
    res.expect(1)
    assert "indexes" in res.stderr
