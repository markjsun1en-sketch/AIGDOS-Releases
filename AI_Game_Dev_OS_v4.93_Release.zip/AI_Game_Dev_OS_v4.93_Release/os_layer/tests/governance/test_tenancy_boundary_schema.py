"""test_tenancy_boundary_schema.py — v4.91 F-T-01.

Schema-shape and contract tests for the tenancy boundary system:

  1. schemas/tenancy/tenancy_boundary.schema.json structural sanity
     (required keys, schema_version const, definitions wired).
  2. RELEASE_MANIFEST.json::classification_rules.tenant_runtime exists
     and tenant_runtime_entries[] match the schema's
     tenant_runtime_manifest_entry definition.
  3. The path_template invariants:
     - must end with '/**'
     - must contain '<project_id>' exactly once
     - must NOT contain '..' or absolute paths
  4. project_runtime_protocol.schema.json gained the optional
     runtime_namespace block; schema_version stayed at '1.0.0'
     (inv_007 lock + extend-don't-replace charter).
  5. A generic acme_demo project yaml that DECLARES a runtime_namespace
     claim instantiating the manifest template validates against the
     extended schema; one that omits runtime_namespace also validates
     (the field is optional).
  6. Layer 1 invariant: schemas/tenancy/tenancy_boundary.schema.json
     contains zero specific project ids. The schema enforces the
     pattern via project_id_pattern definition; the test asserts the
     definition's pattern is present and the schema body has no
     hard-coded names.

Layer 1 (OS Spec). No project names — the only project token in this
file is the generic fixture id 'acme_demo'.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1].parent
TENANCY_SCHEMA = REPO_ROOT / "schemas" / "tenancy" / "tenancy_boundary.schema.json"
PROTOCOL_SCHEMA = REPO_ROOT / "schemas" / "protocol" / "project_runtime_protocol.schema.json"
MANIFEST = REPO_ROOT / "RELEASE_MANIFEST.json"

GENERIC_FIXTURE_PROJECT_ID = "acme_demo"


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# Schema shape
# ---------------------------------------------------------------------------


def test_tenancy_schema_loads_and_has_expected_definitions():
    s = _load(TENANCY_SCHEMA)
    assert s["$schema"].startswith("http://json-schema.org/draft-07/")
    assert s["properties"]["schema_version"]["const"] == "1.0.0"
    defs = s["definitions"]
    for required in (
        "project_id_pattern",
        "path_glob",
        "manifest_template_glob",
        "tenant_runtime_manifest_entry",
        "runtime_namespace_claim",
        "tenant_runtime_classification",
        "runtime_namespace_block",
    ):
        assert required in defs, f"missing definition: {required}"


def test_manifest_template_glob_pattern_demands_project_id_token():
    """The pattern allows the substring '<project_id>'; the per-template
    invariant 'must contain <project_id> exactly once' is enforced by
    the verifier (F-V-01), but the pattern at minimum must permit the
    token."""
    s = _load(TENANCY_SCHEMA)
    pat = s["definitions"]["manifest_template_glob"]["pattern"]
    # Quick sanity: '<' and '>' are in the allowed character class.
    assert "<" in pat and ">" in pat


def test_project_id_pattern_is_kebab_or_snake_case_only():
    s = _load(TENANCY_SCHEMA)
    pat = s["definitions"]["project_id_pattern"]["pattern"]
    rx = re.compile(pat)
    # Generic legitimate ids
    assert rx.match("acme_demo")
    assert rx.match("a1")
    # Forbidden shapes
    assert not rx.match("Acme")           # uppercase
    assert not rx.match("1acme")          # leading digit
    assert not rx.match("acme demo")      # space
    assert not rx.match("acme/demo")      # slash


# ---------------------------------------------------------------------------
# Manifest <-> schema wiring
# ---------------------------------------------------------------------------


def test_manifest_has_tenant_runtime_classification_rule():
    m = _load(MANIFEST)
    rules = m.get("classification_rules") or {}
    assert "tenant_runtime" in rules, (
        "RELEASE_MANIFEST.json::classification_rules must declare "
        "tenant_runtime (v4.91 F-T-01)"
    )
    # Description should mention the schema and the bidirectional
    # contract so reviewers can find the contract from the manifest.
    desc = rules["tenant_runtime"]
    assert "tenancy_boundary.schema.json" in desc or "tenancy" in desc.lower()


def test_manifest_tenant_runtime_entries_present_and_well_formed():
    m = _load(MANIFEST)
    entries = m.get("tenant_runtime_entries")
    assert isinstance(entries, list), "top-level tenant_runtime_entries[] must exist"
    # v4.91 F-T-01 ships at least one entry: ltm/project/<project_id>/**.
    assert len(entries) >= 1
    for e in entries:
        assert "path_template" in e and "owning_authority" in e
        # Generic invariant: '<project_id>' appears exactly once.
        assert e["path_template"].count("<project_id>") == 1, (
            f"path_template must contain '<project_id>' exactly once: {e['path_template']}"
        )
        # Tree concept: must end with /**.
        assert e["path_template"].endswith("/**"), (
            f"path_template must denote a subtree (end with '/**'): {e['path_template']}"
        )
        # Forbidden tokens.
        assert ".." not in e["path_template"]
        assert not e["path_template"].startswith("/")
        # Authority kind is the only one v4.91 supports.
        assert e["owning_authority"] == "adopting_project"


def test_manifest_schema_version_bumped_to_2_3():
    m = _load(MANIFEST)
    assert m["manifest_schema_version"] == "2.3", (
        "v4.91 F-T-01 bumps manifest_schema_version 2.2 → 2.3"
    )
    # Changelog entry exists.
    notes = m.get("manifest_schema_notes") or []
    assert any("F-T-01" in n for n in notes), (
        "manifest_schema_notes must record the F-T-01 change"
    )


# ---------------------------------------------------------------------------
# project_runtime_protocol.schema.json extension
# ---------------------------------------------------------------------------


def test_protocol_schema_version_unchanged_at_1_0_0():
    """inv_007 + extend-don't-replace: schema_version stays 1.0.0
    when adding optional fields."""
    s = _load(PROTOCOL_SCHEMA)
    assert s["properties"]["schema_version"]["const"] == "1.0.0"


def test_protocol_schema_has_optional_runtime_namespace():
    s = _load(PROTOCOL_SCHEMA)
    assert "runtime_namespace" in s["properties"], (
        "v4.91 F-T-01 adds runtime_namespace block to project_runtime_protocol"
    )
    rn = s["properties"]["runtime_namespace"]
    assert rn["additionalProperties"] is False
    assert "claims" in rn["required"]
    # The claim path_glob shape check.
    item = rn["properties"]["claims"]["items"]
    assert item["additionalProperties"] is False
    assert "path_glob" in item["required"]


def test_runtime_namespace_is_optional_not_in_root_required():
    """A v4.90-era project yaml that omits runtime_namespace must
    still validate. The schema's root required[] must NOT include
    runtime_namespace."""
    s = _load(PROTOCOL_SCHEMA)
    assert "runtime_namespace" not in s.get("required", []), (
        "runtime_namespace must be optional (extend, don't replace)"
    )


# ---------------------------------------------------------------------------
# Generic-fixture round-trip (validates against the extended schema)
# ---------------------------------------------------------------------------


def _generic_legacy_yaml() -> dict:
    """A v4.90-era project yaml without runtime_namespace."""
    return {
        "schema_version": "1.0.0",
        "project_id": GENERIC_FIXTURE_PROJECT_ID,
        "project_name": "Acme Demo Project",
        "project_runtime_protocol": {
            "legacy_project_version": "4.85",
            "mounted_core_version": "4.91",
            "target_protocol_version": "4.91",
            "compatibility_mode": "progressive_adoption",
        },
        "host": {"primary_host": "claude_code"},
    }


def _generic_v4_91_yaml() -> dict:
    """A v4.91-era project yaml with runtime_namespace claim."""
    base = _generic_legacy_yaml()
    base["runtime_namespace"] = {
        "claims": [
            {
                "path_glob": f"ltm/project/{GENERIC_FIXTURE_PROJECT_ID}/**",
                "matches_template": "ltm/project/<project_id>/**",
                "rationale": "sprint-close LTM capture target for this project",
            },
        ],
    }
    return base


def test_legacy_project_yaml_validates_against_extended_schema():
    """v4.90-era project that omits runtime_namespace MUST still pass
    the extended schema (extend-don't-replace contract)."""
    jsonschema = pytest.importorskip("jsonschema")
    schema = _load(PROTOCOL_SCHEMA)
    # additionalProperties=false at root level is strict; we verify
    # the legacy doc validates.
    jsonschema.validate(_generic_legacy_yaml(), schema)


def test_v4_91_project_yaml_with_runtime_namespace_validates():
    jsonschema = pytest.importorskip("jsonschema")
    schema = _load(PROTOCOL_SCHEMA)
    jsonschema.validate(_generic_v4_91_yaml(), schema)


def test_v4_91_project_yaml_rejects_path_glob_without_subtree_end():
    """path_glob max length / pattern is shape-level; the verifier
    enforces the '/**' invariant. The schema's pattern allows shorter
    globs but the F-V-01 verifier will reject them. Here we just
    document via a non-validating shape that the test suite treats
    the contract end-to-end (lint at schema, semantic at verifier)."""
    jsonschema = pytest.importorskip("jsonschema")
    schema = _load(PROTOCOL_SCHEMA)
    bad = _generic_v4_91_yaml()
    # Inject an invalid claim missing required path_glob.
    bad["runtime_namespace"]["claims"][0] = {"rationale": "no path"}
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_v4_91_project_yaml_rejects_unknown_claim_property():
    jsonschema = pytest.importorskip("jsonschema")
    schema = _load(PROTOCOL_SCHEMA)
    bad = _generic_v4_91_yaml()
    bad["runtime_namespace"]["claims"][0]["unexpected_field"] = "x"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


# ---------------------------------------------------------------------------
# Layer 1 invariant: no specific project ids in the schema body
# ---------------------------------------------------------------------------


_FORBIDDEN_PROJECT_NAMES = ["rh", "randomheroes", "random_heroes", "random-heroes"]


def test_tenancy_schema_body_contains_no_specific_project_ids():
    body = TENANCY_SCHEMA.read_text(encoding="utf-8").lower()
    for name in _FORBIDDEN_PROJECT_NAMES:
        # Allow generic 'acme_demo' / 'sample_project' tokens — but the
        # tenancy schema is even stricter: it should not contain those
        # either, because Layer 1 schema bodies should be 100% generic.
        assert name not in body, (
            f"Layer 1 tenancy schema must not contain specific project id "
            f"{name!r}"
        )
    # Confirm the schema relies on a pattern instead.
    schema = _load(TENANCY_SCHEMA)
    assert "pattern" in schema["definitions"]["project_id_pattern"]


def test_manifest_tenant_runtime_block_contains_no_specific_project_ids():
    """The manifest declares generic templates; specific project ids
    arrive at audit time via project yamls. Any concrete id leaking
    into the manifest is a Layer 1/2 violation."""
    m = _load(MANIFEST)
    block_text = json.dumps(
        {
            "classification_rules.tenant_runtime": m["classification_rules"]["tenant_runtime"],
            "tenant_runtime_entries": m["tenant_runtime_entries"],
        },
        indent=2,
    ).lower()
    for name in _FORBIDDEN_PROJECT_NAMES:
        assert name not in block_text, (
            f"manifest tenant_runtime block must not contain specific "
            f"project id {name!r}"
        )
