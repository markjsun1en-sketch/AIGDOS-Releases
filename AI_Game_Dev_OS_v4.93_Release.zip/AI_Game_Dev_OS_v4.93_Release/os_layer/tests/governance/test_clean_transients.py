"""test_clean_transients.py — v4.90 Batch 14.10 (v4.90.3 polish patch).

2 tests covering the new ``scripts/governance/clean_transients.py``
post-execution housekeeping helper:

    1. test_dry_run_does_not_remove_anything: simulating a dirty
       sandbox tree (with __pycache__/ and *.pyc), invoking the
       helper with --dry-run leaves all the targets in place and
       still reports the count.
    2. test_clean_actually_removes_targets_and_preserves_exports_gitignore:
       the helper removes __pycache__/ / .pytest_cache/ / *.pyc /
       .DS_Store / ._* AND wipes exports/ contents BUT preserves the
       required exports/.gitignore.

Both tests run against a synthetic tmp_path tree, not the actual
release pack, so they don't touch the developer's working dir.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import shutil
import subprocess
import sys
import textwrap
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1].parent
CLEAN_SCRIPT_REL = "scripts/governance/clean_transients.py"


def _build_dirty_fixture(root: Path) -> None:
    """Build a tmp tree shaped like a release pack with a few dirty
    items inside, plus exports/.gitignore which must survive.

    We import the module rather than running it via subprocess so we
    can target the tmp tree without monkey-patching __file__. The
    module derives _pkg_root() from its own location, so we copy the
    real script into tmp_path/scripts/governance/clean_transients.py.
    """
    (root / "scripts" / "governance").mkdir(parents=True)
    real_script = REPO_ROOT / CLEAN_SCRIPT_REL
    shutil.copy(real_script, root / CLEAN_SCRIPT_REL)

    # Dirty items at various depths.
    (root / "runtime" / "__pycache__").mkdir(parents=True)
    (root / "runtime" / "__pycache__" / "x.cpython-313.pyc").write_bytes(b"\x00")
    (root / "tests" / "ltm" / "__pycache__").mkdir(parents=True)
    (root / "tests" / "ltm" / "__pycache__" / "y.pyc").write_bytes(b"\x00")
    (root / ".pytest_cache").mkdir()
    (root / ".pytest_cache" / "v").mkdir()
    (root / ".pytest_cache" / "v" / "cache").write_text("nodeids: []")
    (root / "scripts" / "ltm").mkdir(parents=True)
    (root / "scripts" / "ltm" / "stale.pyc").write_bytes(b"\x00")
    (root / ".DS_Store").write_bytes(b"\x00")
    (root / "docs").mkdir()
    (root / "docs" / "._notes.md").write_bytes(b"\x00")  # apple resource fork

    # exports/ dirty content, but the .gitignore must survive.
    (root / "exports").mkdir()
    (root / "exports" / ".gitignore").write_text("*\n!.gitignore\n")
    (root / "exports" / "smoke_run.json").write_text("{}\n")
    (root / "exports" / "stale").mkdir()
    (root / "exports" / "stale" / "leftover.txt").write_text("x")


def _invoke_clean(root: Path, *args) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, str(root / CLEAN_SCRIPT_REL), *args],
        capture_output=True,
        text=True,
        cwd=str(root),
        check=False,
    )


def test_dry_run_does_not_remove_anything(tmp_path: Path):
    _build_dirty_fixture(tmp_path)
    res = _invoke_clean(tmp_path, "--dry-run", "--quiet")
    assert res.returncode == 0, res.stdout + res.stderr

    # Targets must still exist.
    assert (tmp_path / "runtime" / "__pycache__").is_dir()
    assert (tmp_path / "tests" / "ltm" / "__pycache__" / "y.pyc").is_file()
    assert (tmp_path / ".pytest_cache").is_dir()
    assert (tmp_path / "scripts" / "ltm" / "stale.pyc").is_file()
    assert (tmp_path / ".DS_Store").is_file()
    assert (tmp_path / "docs" / "._notes.md").is_file()
    assert (tmp_path / "exports" / "smoke_run.json").is_file()
    assert (tmp_path / "exports" / "stale" / "leftover.txt").is_file()
    assert (tmp_path / "exports" / ".gitignore").is_file()

    # Summary should report dry_run=True with non-zero counts.
    assert "dry_run=True" in res.stdout
    assert "pycache=2" in res.stdout
    assert "pytest_cache=1" in res.stdout
    assert "pyc=1" in res.stdout
    assert "dsstore=1" in res.stdout
    assert "apple_resource=1" in res.stdout
    # exports/ has 2 entries beyond .gitignore (smoke_run.json + stale/).
    assert "export=2" in res.stdout


def test_clean_actually_removes_targets_and_preserves_exports_gitignore(
    tmp_path: Path,
):
    _build_dirty_fixture(tmp_path)
    res = _invoke_clean(tmp_path, "--quiet")
    assert res.returncode == 0, res.stdout + res.stderr

    # All transient targets gone.
    assert not (tmp_path / "runtime" / "__pycache__").exists()
    assert not (tmp_path / "tests" / "ltm" / "__pycache__").exists()
    assert not (tmp_path / ".pytest_cache").exists()
    assert not (tmp_path / "scripts" / "ltm" / "stale.pyc").exists()
    assert not (tmp_path / ".DS_Store").exists()
    assert not (tmp_path / "docs" / "._notes.md").exists()
    # exports/.gitignore MUST remain — it is required-manifest content.
    assert (tmp_path / "exports" / ".gitignore").is_file()
    # All other exports/ entries gone.
    assert not (tmp_path / "exports" / "smoke_run.json").exists()
    assert not (tmp_path / "exports" / "stale").exists()

    # Summary line shape.
    assert "dry_run=False" in res.stdout
    assert "failures=0" in res.stdout

    # Idempotent: a second run on a clean tree still exits 0 with all
    # counts at 0.
    res2 = _invoke_clean(tmp_path, "--quiet")
    assert res2.returncode == 0, res2.stdout + res2.stderr
    assert "pycache=0" in res2.stdout
    assert "pytest_cache=0" in res2.stdout
    assert "pyc=0" in res2.stdout
    assert "export=0" in res2.stdout
