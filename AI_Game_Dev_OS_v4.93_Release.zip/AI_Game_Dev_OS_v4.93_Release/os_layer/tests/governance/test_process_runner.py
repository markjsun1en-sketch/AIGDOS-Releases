"""test_process_runner.py — v4.90.9 PG-safe runner contract.

v4.90.9 Batch 14.16 — extracted runner shared by closure gate,
required regressions router, and consistency aggregate.

The closure gate suite (test_closure_gate_timeout_hardening.py)
already exercises the v4.90.8 ``_run()`` body via the gate module.
This suite directly imports ``scripts.governance._process_runner``
and asserts the four contracts that matter for the broader
governance pipeline:

    1. Grandchild process-group reaping on timeout
       (a child that spawns a long-running grandchild does not
       deadlock the parent's communicate() — same regression
       v4.90.8 fixed for the gate, now portable).

    2. ``extra_env`` round-trips through to the child without
       clobbering inherited env vars.

    3. ``shell=True`` path works for the
       ``check_required_regressions.execute()`` call site whose
       commands are stored as shell strings in
       ``protected_regression_matrix.yaml``.

    4. ``OSError`` during spawn surfaces as rc=126 (matches the
       pre-v4.90.9 contract that ``check_required_regressions`` and
       ``check_consistency_aggregate`` relied on).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import textwrap
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1].parent
RUNNER_PATH = REPO_ROOT / "scripts" / "governance" / "_process_runner.py"


def _load_runner():
    spec = importlib.util.spec_from_file_location(
        "v490_process_runner_under_test", RUNNER_PATH
    )
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    # v4.91 Batch 14.19: register before exec so dataclass introspection
    # (Python 3.13 _is_type → sys.modules.get(...).__dict__) can resolve
    # the module's globals when @dataclass fires during exec.
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def test_run_pg_safe_kills_grandchild_process_group(tmp_path):
    """A child that spawns a long-running grandchild must be fully reaped
    by ``run_pg_safe`` when the timeout fires. Mirrors the v4.90.8
    closure gate hardening contract; this is the v4.90.9 portable
    coverage so check_required_regressions and check_consistency_aggregate
    inherit the same guarantee.
    """
    runner = _load_runner()

    child_src = textwrap.dedent(
        """
        import os, sys, time, subprocess
        gc = subprocess.Popen(
            [sys.executable, "-c", "import time; time.sleep(30)"],
            stdout=sys.stdout, stderr=sys.stderr,
        )
        sys.stdout.write(f"GC_PID={gc.pid}\\n")
        sys.stdout.flush()
        time.sleep(30)
        """
    ).strip()
    script = tmp_path / "child.py"
    script.write_text(child_src, encoding="utf-8")

    t0 = time.monotonic()
    rc, out, err = runner.run_pg_safe(
        [sys.executable, str(script)],
        cwd=tmp_path,
        timeout=2,
    )
    elapsed = time.monotonic() - t0

    assert rc == 124, f"expected 124 on timeout, got {rc} (err={err!r})"
    assert elapsed < 25, (
        f"run_pg_safe took {elapsed:.1f}s — grandchild deadlocked the "
        "pipe; v4.90.9 PG-safe extraction missing or regressed"
    )

    gc_pid = None
    for line in (out or "").splitlines():
        if line.startswith("GC_PID="):
            try:
                gc_pid = int(line.split("=", 1)[1])
            except ValueError:
                pass
    if gc_pid is not None:
        for _ in range(20):
            if not _pid_alive(gc_pid):
                break
            time.sleep(0.1)
        assert not _pid_alive(gc_pid), (
            f"grandchild PID {gc_pid} still alive — killpg did not "
            "reach the process group"
        )


def test_run_pg_safe_forwards_extra_env(tmp_path):
    """``run_pg_safe(..., extra_env=...)`` merges into ``os.environ`` so
    callers (closure gate C1, aggregate schema_self_validation) can
    selectively override env without losing inherited PATH etc."""
    runner = _load_runner()

    child_src = (
        "import os, sys; "
        "sys.stdout.write(os.environ.get('V490_PROBE_TOKEN', '<unset>'))"
    )
    script = tmp_path / "envcheck.py"
    script.write_text(child_src, encoding="utf-8")

    rc, out, _ = runner.run_pg_safe(
        [sys.executable, str(script)],
        cwd=tmp_path,
        timeout=10,
        extra_env={"V490_PROBE_TOKEN": "v4.90.9-marker"},
    )
    assert rc == 0
    assert out.strip() == "v4.90.9-marker", (
        f"extra_env not forwarded; got {out!r}"
    )


def test_run_pg_safe_shell_string_path(tmp_path):
    """check_required_regressions stores its protected_invariant
    commands as shell strings (``"python3 a.py | grep ..."`` style).
    The shell=True path must work via run_pg_safe just like it did
    via the pre-v4.90.9 ``subprocess.run(..., shell=True)`` call."""
    runner = _load_runner()

    # Compose a portable shell invocation: echo through a pipe so the
    # shell layer is genuinely exercised (not just argv-passthrough).
    cmd = "echo v490 | tr a-z A-Z"
    rc, out, _ = runner.run_pg_safe(
        cmd,
        cwd=tmp_path,
        timeout=10,
        shell=True,
    )
    assert rc == 0, f"shell pipeline exited {rc}"
    assert out.strip() == "V490", (
        f"shell pipe broken; got {out!r}"
    )


def test_run_pg_safe_oserror_returns_126(tmp_path):
    """A non-existent executable must surface as rc=126 with a
    diagnostic stderr — matches the pre-v4.90.9 contract that
    check_required_regressions / check_consistency_aggregate rely on
    for their error tail extraction."""
    runner = _load_runner()
    rc, out, err = runner.run_pg_safe(
        ["/no/such/path/v490-no-binary"],
        cwd=tmp_path,
        timeout=5,
    )
    assert rc == 126, f"expected 126 OSError, got {rc}"
    assert out == ""
    assert "OSError" in err, f"stderr should mention OSError; got {err!r}"
