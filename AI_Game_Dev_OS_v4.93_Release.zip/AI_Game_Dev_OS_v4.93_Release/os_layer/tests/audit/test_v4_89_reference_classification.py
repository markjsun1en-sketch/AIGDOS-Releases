"""test_v4_89_reference_classification.py — v4.90 Batch 14 Step 14.4.

Consistency audit C-05 guard. Asserts 8 invariants on the audit
classification result.

Per EP D-14.4 (X-1 + P-1 + A2 lessismore 332 absorption + B fix scope):
- 4-class scheme A/B/C/D (HISTORICAL_OK_BASELINE / _CHANGELOG /
  ACTIVE_STALE / INTENTIONAL_OPEN).
- Classifier priority: migration-arrow → C → A → B → D → fallback B.
- Self-reference exemption skips the audit/lint/test/report files.
- Class C must equal 0 after Step 14.4 fix.
- Class A + B floor 500 (legitimate-reference baseline).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

V4_90_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(V4_90_ROOT))

from scripts.audit.audit_v4_89_references import (  # noqa: E402
    SELF_REFERENCE_PATHS,
    audit,
    classify,
)


@pytest.fixture(scope="module")
def report() -> dict:
    return audit()


# ---------------------------------------------------------------------------
# Aggregate-level invariants
# ---------------------------------------------------------------------------


def test_audit_returns_4_class_buckets(report):
    """audit() must produce A/B/C/D buckets and class_labels metadata."""
    assert set(report["by_class"].keys()) == {"A", "B", "C", "D"}
    labels = report["summary"]["class_labels"]
    assert labels["A"] == "HISTORICAL_OK_BASELINE"
    assert labels["B"] == "HISTORICAL_OK_CHANGELOG"
    assert labels["C"] == "ACTIVE_STALE"
    assert labels["D"] == "INTENTIONAL_OPEN"


def test_class_c_active_stale_is_zero(report):
    """After Step 14.4 fix, no truly-stale lines remain."""
    c_entries = report["by_class"]["C"]
    assert len(c_entries) == 0, (
        f"Found {len(c_entries)} ACTIVE_STALE lines:\n  "
        + "\n  ".join(f"{e['path']}:{e['lineno']}" for e in c_entries[:10])
    )


def test_legitimate_baseline_above_floor(report):
    """A + B (legitimate references) must stay >= 500."""
    a = len(report["by_class"]["A"])
    b = len(report["by_class"]["B"])
    assert a + b >= 500, (
        f"Legitimate references (A+B={a + b}) below floor 500"
    )


# ---------------------------------------------------------------------------
# Classifier priority unit tests
# ---------------------------------------------------------------------------


def test_classify_path_reference_routed_to_a():
    """Pure path-form references stay in Class A."""
    line = "AI_Game_Dev_OS_v4.89_Release/runtime/state/some.json"
    assert classify(line) == "A"


def test_classify_stale_phrase_detected():
    """Stale self-claim phrases route to Class C, not A.

    Regression guard: this exact line was being absorbed by Class A
    before Step 14.4 priority fix (path pattern was too greedy).
    """
    line = "2. package name: `AI_Game_Dev_OS_v4.89_Release`."
    assert classify(line) == "C"


def test_classify_migration_arrow_routed_to_b():
    """Migration-arrow narrative wins regardless of stale-phrase match.

    Lines like commit messages and progress tables that contain
    `v4.89_Release → v4.90` are legitimate changelog narrative,
    even if they textually mention `package_name v4.89_Release`.
    """
    line = (
        "| 14.1 | RELEASE_MANIFEST: package_name v4.89_Release → v4.90 "
        "/ base_from v4.88_RC12 → v4.89_Release |"
    )
    assert classify(line) == "B"


# ---------------------------------------------------------------------------
# Self-reference exemption
# ---------------------------------------------------------------------------


def test_audit_self_reference_exemption(report):
    """The audit tooling files must not appear in any class bucket.

    The audit script, lint guard, this test file, and the audit report
    all contain literal example phrases (e.g. "package name: v4.89_Release"
    in docstrings) that would otherwise self-trigger Class C. They
    are exempt at scan time.
    """
    skipped = report["summary"]["skipped_self_references"]
    assert skipped > 0, "self-reference exemption should match >0 lines"
    all_paths = set()
    for cls in ("A", "B", "C", "D"):
        for e in report["by_class"][cls]:
            all_paths.add(e["path"])
    for self_ref in SELF_REFERENCE_PATHS:
        offending = [p for p in all_paths if self_ref in p]
        assert not offending, (
            f"Self-reference path {self_ref!r} leaked into classification: "
            f"{offending}"
        )


# ---------------------------------------------------------------------------
# Lint guard subprocess
# ---------------------------------------------------------------------------


def test_lint_guard_exits_zero_on_clean_state():
    """check_v4_89_baseline_integrity.py exits 0 on current state."""
    script = V4_90_ROOT / "scripts" / "lint" / "check_v4_89_baseline_integrity.py"
    result = subprocess.run(
        [sys.executable, str(script)],
        capture_output=True, text=True,
    )
    assert result.returncode == 0, (
        f"lint guard exited {result.returncode}:\n"
        f"{result.stdout}\n{result.stderr}"
    )
    assert "All invariants satisfied" in result.stdout
