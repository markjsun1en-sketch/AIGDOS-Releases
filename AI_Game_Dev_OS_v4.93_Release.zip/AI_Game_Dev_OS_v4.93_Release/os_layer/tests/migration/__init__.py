"""tests/migration/ — v4.90 P0-1 Progressive Adoption tests.

Batch 1 Step 3: fingerprint regex unit tests (R2.001 mitigation).
Batch 2 will add adoption flow integration tests.
"""
