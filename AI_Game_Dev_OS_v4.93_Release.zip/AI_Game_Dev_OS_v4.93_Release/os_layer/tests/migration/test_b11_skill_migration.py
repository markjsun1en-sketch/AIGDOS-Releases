"""B11 NHR/Split migration closure tests."""
from __future__ import annotations

import json
from pathlib import Path

import jsonschema

PKG_ROOT = Path(__file__).resolve().parents[2]
MAP = PKG_ROOT / "docs" / "13_migration" / "legacy_to_v492_migration_map.json"
SKILL_SCHEMA = PKG_ROOT / "capability_protocols" / "skill_contract.schema.json"


def _load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def test_b11_legacy_skill_targets_are_migrated():
    data = _load(MAP)
    by_id = {entry["legacy_skill_id"]: entry for entry in data["entries"]}
    expected = {
        "asset-variation-control": ("art_asset_pack", "asset_variation_control_skill"),
        "battle-hud-designer": ("design_data_pack", "battle_hud_designer_skill"),
        "game-design-system-builder": ("design_data_pack", "game_design_system_builder_skill"),
        "game-ui-wireframe-generator": ("design_data_pack", "game_ui_wireframe_spec_skill"),
        "ui-asset-prompt-engineer": ("art_asset_pack", "ui_asset_prompt_engineer_skill"),
    }
    for legacy_id, (pack_id, skill_id) in expected.items():
        entry = by_id[legacy_id]
        assert entry["migration_status"] == "migrated"
        assert entry["plane"] == "execution"
        assert entry["target"]["pack_id"] == pack_id
        assert entry["target"]["skill_contract_id"] == skill_id
        assert entry.get("notes")
    assert by_id["game-ui-wireframe-generator"]["target"]["os_lead_capability"] == (
        "game_design_lead"
    )
    assert data["by_status"] == {"migrated": 49}


def test_b11_skill_contracts_are_schema_valid_and_listed_in_packs():
    schema = _load(SKILL_SCHEMA)
    pairs = [
        ("art_asset", "asset_variation_control_skill"),
        ("art_asset", "ui_asset_prompt_engineer_skill"),
        ("design_data", "battle_hud_designer_skill"),
        ("design_data", "game_design_system_builder_skill"),
        ("design_data", "game_ui_wireframe_spec_skill"),
    ]
    for pack_dir, skill_id in pairs:
        pack_path = PKG_ROOT / "packs" / "game_system_packs" / pack_dir / "capability_pack.json"
        skill_path = (
            PKG_ROOT / "packs" / "game_system_packs" / pack_dir / "skills" /
            f"{skill_id}.json"
        )
        pack = _load(pack_path)
        skill = _load(skill_path)
        assert skill_id in pack["skills"]
        assert skill["execution_level"] == "spec_generation"
        assert skill["completion_evidence"] == ["spec_doc"]
        jsonschema.validate(skill, schema)


def test_b11_wireframe_split_has_control_review_capability():
    lead = _load(PKG_ROOT / "os_control_plane" / "leads" / "game_design_lead.capability.json")
    caps = {cap["capability_id"]: cap for cap in lead["capabilities"]}
    cap = caps["game_ui_wireframe_structure_review"]
    assert cap["migrated_from"] == (
        "skills/_generic_core/game_ui/game-ui-wireframe-generator/SKILL.md"
    )
    assert cap["emits_verdict"] == "os_verdict"
    assert "design_data_pack:game_ui_wireframe_spec_skill" in " ".join(
        cap["handoff_on_fix"]
    )
