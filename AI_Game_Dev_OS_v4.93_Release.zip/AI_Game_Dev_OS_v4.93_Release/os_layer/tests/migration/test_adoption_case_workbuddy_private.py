"""test_adoption_case_workbuddy_private.py — v4.90 Batch 5.5 Step 5.5.3.

Contract tests for the Layer 2 adoption case
``docs/14_state_surface_governance/STATE_SURFACE_MIGRATION_CASE_WORKBUDDY_PRIVATE.md``.

5 cases:
1. case file exists with the expected filename (matches Layer 2 regex
   exemption ``STATE_SURFACE_MIGRATION_CASE_*``).
2. case body references at least 3 distinct matrix rows by id
   (e.g. 09_agent_library, 10_pack_activation, 06_context_governance).
3. case body cites at least 1 Batch 5 cluster seed pack
   (ap_2026_00X_*_cluster.md).
4. Layer 1 lint stays clean (regex exemption is active and the case
   itself does not bleed into other Layer 1 roots).
5. case carries a Layer 2 Notice section (§0) and an outbound-references
   block referring forward to v4.90 OS Core (case points up at Layer 1,
   not the other way around).

Layer 1 (OS Spec). The case file itself is Layer 2; this test file is
Layer 1 and stays project-name-free except where literal regex text or
a deliberate runtime-assembled string is required.
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
CASE_FILE = (
    PKG_ROOT
    / "docs"
    / "14_state_surface_governance"
    / "STATE_SURFACE_MIGRATION_CASE_WORKBUDDY_PRIVATE.md"
)
LINT = PKG_ROOT / "scripts" / "governance" / "lint_layer_separation.py"

# Layer 2 filename regex (must match the lint exemption).
_CASE_FILENAME_RE = re.compile(r"^STATE_SURFACE_MIGRATION_CASE_[A-Z0-9_-]+\.md$")
_CAPABILITY_ID_RE = re.compile(r"\b\d{2}_[a-z][a-z0-9_]*")
_AP_SEED_RE = re.compile(r"\bap_\d{4}_\d{3}_[a-z][a-z0-9_]*\.md")


def test_1_case_file_exists_and_filename_matches_exemption():
    assert CASE_FILE.is_file(), f"missing case file: {CASE_FILE}"
    assert _CASE_FILENAME_RE.match(CASE_FILE.name), (
        f"filename {CASE_FILE.name!r} does not match "
        "Layer 2 exemption regex ^STATE_SURFACE_MIGRATION_CASE_*.md$"
    )


def test_2_references_at_least_three_matrix_rows():
    body = CASE_FILE.read_text(encoding="utf-8")
    found = set(_CAPABILITY_ID_RE.findall(body))
    # Filter to the 14 canonical IDs to avoid pollution.
    canonical = {
        "01_runtime_core", "02_project_profile", "03_host_profile",
        "04_handoff_registry", "05_validation_evidence",
        "06_context_governance", "07_ltm_capture_consult",
        "08_failure_fix_memory", "09_agent_library",
        "10_pack_activation", "11_profile_parity",
        "12_dashboard_exports", "13_adapter_bridge",
        "14_self_evolution_proposal",
    }
    referenced = found & canonical
    assert len(referenced) >= 3, (
        f"case must reference >= 3 matrix rows; found {sorted(referenced)}"
    )
    # Critically the Batch-5-promoted rows must be present.
    assert "09_agent_library" in referenced
    assert "10_pack_activation" in referenced


def test_3_cites_batch_5_cluster_seed_pack():
    body = CASE_FILE.read_text(encoding="utf-8")
    matches = set(_AP_SEED_RE.findall(body))
    assert matches, (
        "case must cite at least one Batch 5 cluster seed pack "
        "(ap_YYYY_NNN_<slug>_cluster.md)"
    )
    # Sanity: the canonical 5 v4.90 seeds.
    expected_subset = {
        "ap_2026_001_executive_cluster.md",
        "ap_2026_002_research_and_design_cluster.md",
        "ap_2026_003_implementation_cluster.md",
        "ap_2026_004_validation_cluster.md",
        "ap_2026_005_support_cluster.md",
    }
    assert matches & expected_subset, (
        f"expected at least one of the 5 v4.90 seeds, got {sorted(matches)}"
    )


def test_4_layer_1_lint_remains_clean():
    proc = subprocess.run(
        [sys.executable, str(LINT)],
        capture_output=True, text=True, timeout=30,
    )
    assert proc.returncode == 0, (
        f"lint failed:\nstdout: {proc.stdout}\nstderr: {proc.stderr}"
    )
    assert "0 violations" in proc.stdout


def test_5_layer_2_notice_and_outbound_refs_present():
    body = CASE_FILE.read_text(encoding="utf-8")
    # §0 Layer 2 Notice anchors the case as evidence-only.
    assert "## 0. Layer 2 Notice" in body, (
        "case must declare its Layer 2 status in §0"
    )
    # Outbound references show case → Layer 1 direction (not reverse).
    assert "Outbound references" in body or "cross-references" in body.lower()
    # Case must NOT introduce a Layer 1 rule directly.
    forbidden_patterns = [
        "MUST be added to Layer 1",
        "introduce as Layer 1 rule",
        "promote to Layer 1 without",
    ]
    for fp in forbidden_patterns:
        assert fp not in body, f"case attempts to mutate Layer 1: {fp!r}"
