"""test_adopt_capability.py — v4.90 Batch 5.5.

Tests scripts/migration/adopt_capability.py (GUIDED).

5 cases:
1. --help renders.
2. Legal transition (not_present -> adopted) on row 09 against v4.90
   self-fork -> exit 0, transition_status=applied + validation_evidence
   carries overall_status=pass.
3. Illegal transition (not_present -> verified) -> exit 1.
4. Validation failure (row 09 on empty project) blocks transition ->
   exit 1 with transition_status=rejected.
5. requires_human_approval=true row requires --approve (row 14 is such
   a row per Batch 6 matrix).

Note (Batch 12 Step 12.2 / GAP #1): the not_present->adopted /
not_present->verified direct paths skip the 'adopting' state and
are gated by the new direct_replacement_allowed=false default. These
tests pass --bypass-direct-replacement-gate to preserve their original
state-machine intent. Coverage of the gate itself lives in
tests/migration/test_direct_replacement_gate.py.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

PKG_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = PKG_ROOT / "scripts" / "migration" / "adopt_capability.py"


def _run(*args):
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True, text=True, timeout=20,
    )
    return proc.returncode, proc.stdout, proc.stderr


def test_1_help_renders():
    rc, out, err = _run("--help")
    assert rc == 0
    assert "--approve" in out


def test_2_legal_transition_applied():
    rc, out, err = _run(
        "09_agent_library",
        "--project", str(PKG_ROOT),
        "--from", "not_present",
        "--to", "adopted",
        "--bypass-direct-replacement-gate",
    )
    assert rc == 0, err
    doc = json.loads(out)
    assert doc["transition_status"] == "applied"
    assert doc["audit_event"] == "migration.adopt"
    evidence = doc.get("validation_evidence") or {}
    assert evidence.get("overall_status") == "pass"


def test_3_illegal_transition_rejected():
    rc, _, err = _run(
        "09_agent_library",
        "--project", str(PKG_ROOT),
        "--from", "not_present",
        "--to", "verified",
        "--bypass-direct-replacement-gate",
    )
    assert rc == 1, err
    assert "not allowed" in err


def test_4_validation_failure_blocks_transition(tmp_path):
    rc, out, err = _run(
        "09_agent_library",
        "--project", str(tmp_path),
        "--from", "not_present",
        "--to", "adopted",
        "--bypass-direct-replacement-gate",
    )
    assert rc == 1, err
    doc = json.loads(out)
    assert doc["transition_status"] == "rejected"


def test_5_requires_human_approval(tmp_path):
    # Row 14 self_evolution_proposal has requires_human_approval: true
    # (Batch 6 matrix). Without --approve we expect exit 5.
    rc, _, err = _run(
        "14_self_evolution_proposal",
        "--project", str(PKG_ROOT),
        "--from", "not_present",
        "--to", "adopted",
        "--bypass-direct-replacement-gate",
    )
    assert rc == 5, err
    assert "--approve" in err or "approval" in err.lower()
