"""Direct replacement gate enforcement — v4.90 Batch 12 Step 12.2 (GAP #1).

Covers the runtime gate added on top of the schema-declared
``direct_replacement_allowed`` boolean. Two layers:

  1. Helper unit tests on
     ``scripts.migration._matrix_parser.check_direct_replacement_gate``.
  2. End-to-end tests on the two scripts that consume the gate:
     ``scripts/migration/adopt_capability.py`` and
     ``scripts/adoption/init_project_runtime.py``.

Layer 1 (OS Spec). No project names. ``--project`` paths are opaque
fixtures under ``tmp_path``.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

PKG_ROOT = Path(__file__).resolve().parents[2]
ADOPT_SCRIPT = PKG_ROOT / "scripts" / "migration" / "adopt_capability.py"
INIT_SCRIPT = PKG_ROOT / "scripts" / "adoption" / "init_project_runtime.py"


sys.path.insert(0, str(PKG_ROOT))
from scripts.migration._matrix_parser import (  # noqa: E402
    check_direct_replacement_gate,
)


# --------------------------------------------------------------------------
# Helper unit tests (4)
# --------------------------------------------------------------------------


def test_helper_allows_when_flag_true_and_direct_path():
    """flag=true + direct path (not_present -> adopted) is allowed."""
    doc = {
        "project_runtime_protocol": {
            "direct_replacement_allowed": True,
        },
    }
    allowed, reason = check_direct_replacement_gate(
        doc, ("not_present", "adopted")
    )
    assert allowed is True
    assert reason is None


def test_helper_blocks_when_flag_false_and_direct_path():
    """flag=false + direct path (not_present -> adopted) is blocked
    with a reason mentioning the flag and the transition."""
    doc = {
        "project_runtime_protocol": {
            "direct_replacement_allowed": False,
        },
    }
    allowed, reason = check_direct_replacement_gate(
        doc, ("not_present", "adopted")
    )
    assert allowed is False
    assert reason is not None
    assert "direct_replacement_allowed=false" in reason
    assert "not_present->adopted" in reason


def test_helper_allows_gradual_path_regardless_of_flag():
    """flag=false + gradual path (adopting -> adopted) is allowed
    because the gate only fires on direct (skip-adopting) paths."""
    doc = {
        "project_runtime_protocol": {
            "direct_replacement_allowed": False,
        },
    }
    allowed, reason = check_direct_replacement_gate(
        doc, ("adopting", "adopted")
    )
    assert allowed is True
    assert reason is None


def test_helper_default_deny_on_missing_field():
    """Missing project_runtime_protocol / missing flag -> default deny.
    None input is also accepted and treated strictly."""
    # Empty doc -> strict
    allowed, reason = check_direct_replacement_gate(
        {}, ("not_present", "adopted")
    )
    assert allowed is False
    assert "direct_replacement_allowed=false" in (reason or "")

    # None doc -> strict (defensive)
    allowed, reason = check_direct_replacement_gate(
        None, ("not_present", "adopted")
    )
    assert allowed is False


# --------------------------------------------------------------------------
# adopt_capability e2e tests (2)
# --------------------------------------------------------------------------


def _write_project_protocol(project_dir: Path, *, flag: bool) -> None:
    """Write a minimal .ai_dev_os/project_runtime_protocol.yaml with
    direct_replacement_allowed set as requested."""
    aidev = project_dir / ".ai_dev_os"
    aidev.mkdir(parents=True, exist_ok=True)
    flag_lit = "true" if flag else "false"
    (aidev / "project_runtime_protocol.yaml").write_text(
        "project_id: gate_test\n"
        "project_name: Gate Test\n"
        "project_runtime_protocol:\n"
        "  legacy_project_version: \"4.82\"\n"
        "  mounted_core_version: \"4.90\"\n"
        "  target_protocol_version: \"4.90\"\n"
        "  compatibility_mode: progressive_adoption\n"
        f"  direct_replacement_allowed: {flag_lit}\n"
        "host:\n"
        "  primary_host: codex\n",
        encoding="utf-8",
    )


def test_adopt_capability_blocks_direct_path_with_strict_protocol(tmp_path):
    """Project declares direct_replacement_allowed=false; the direct
    transition (not_present -> adopted) must exit 1 with the gate's
    reason on stderr."""
    _write_project_protocol(tmp_path, flag=False)
    proc = subprocess.run(
        [
            sys.executable, str(ADOPT_SCRIPT),
            "09_agent_library",
            "--project", str(tmp_path),
            "--from", "not_present",
            "--to", "adopted",
        ],
        capture_output=True, text=True, timeout=20,
    )
    assert proc.returncode == 1, proc.stderr
    assert "direct_replacement_allowed=false" in proc.stderr
    assert "not_present->adopted" in proc.stderr


def test_adopt_capability_allows_with_bypass_flag(tmp_path):
    """Same setup but with --bypass-direct-replacement-gate the gate
    no longer blocks; the transition reaches the validator (which
    rejects on an empty project, exit 1 + transition_status=rejected,
    NOT a gate violation)."""
    _write_project_protocol(tmp_path, flag=False)
    proc = subprocess.run(
        [
            sys.executable, str(ADOPT_SCRIPT),
            "09_agent_library",
            "--project", str(tmp_path),
            "--from", "not_present",
            "--to", "adopted",
            "--bypass-direct-replacement-gate",
        ],
        capture_output=True, text=True, timeout=20,
    )
    # The gate is bypassed; downstream the empty project fails the
    # validator. The key invariant for THIS test is: the gate's reason
    # string is NOT what blocked us (validator did).
    assert "direct_replacement_allowed=false" not in proc.stderr
    # Either rc==1 (validator rejected) or rc==0 (passed) — both
    # demonstrate the gate did not fire.
    if proc.returncode == 1:
        doc = json.loads(proc.stdout)
        assert doc["transition_status"] == "rejected"


# --------------------------------------------------------------------------
# init_project_runtime e2e tests (2)
# --------------------------------------------------------------------------


def _scaffold_initial_tree(out_dir: Path, *, flag: bool) -> None:
    """Write a minimal pre-existing .ai_dev_os/ tree with the desired
    direct_replacement_allowed value."""
    out_dir.mkdir(parents=True, exist_ok=True)
    flag_lit = "true" if flag else "false"
    (out_dir / "01_project_runtime_protocol.yaml").write_text(
        "project_runtime_protocol:\n"
        "  legacy_project_version: \"4.82\"\n"
        "  mounted_core_version: \"4.90\"\n"
        "  target_protocol_version: \"4.90\"\n"
        "  compatibility_mode: progressive_adoption\n"
        f"  direct_replacement_allowed: {flag_lit}\n",
        encoding="utf-8",
    )


def _run_init(out_dir: Path, extra: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        [
            sys.executable, str(INIT_SCRIPT),
            "--out", str(out_dir),
            "--project-id", "gate_test",
            "--project-name", "Gate Test",
            "--stage", "alpha",
            "--primary-host", "codex",
            "--format", "json",
            *extra,
        ],
        capture_output=True, text=True, timeout=20,
    )


def test_init_project_runtime_refuses_overwrite_with_strict_protocol(tmp_path):
    """Pre-existing tree with direct_replacement_allowed=false +
    --force (no bypass) -> refused with the gate's reason."""
    out_dir = tmp_path / ".ai_dev_os"
    _scaffold_initial_tree(out_dir, flag=False)
    proc = _run_init(out_dir, ["--force"])
    assert proc.returncode == 1, proc.stderr + proc.stdout
    payload = json.loads(proc.stdout)
    assert payload["status"] == "refused"
    assert "direct_replacement_allowed=false" in payload["reason"]


def test_init_project_runtime_overwrites_with_bypass_flag(tmp_path):
    """Same setup but --bypass-direct-replacement-gate authorises the
    overwrite; status is 'scaffolded' and the new yaml replaces the
    old one."""
    out_dir = tmp_path / ".ai_dev_os"
    _scaffold_initial_tree(out_dir, flag=False)
    proc = _run_init(
        out_dir, ["--force", "--bypass-direct-replacement-gate"]
    )
    assert proc.returncode == 0, proc.stderr + proc.stdout
    payload = json.loads(proc.stdout)
    assert payload["status"] == "scaffolded"
    # The freshly-rendered protocol yaml should still set the flag to
    # false (default discipline of init_project_runtime).
    fresh = (out_dir / "01_project_runtime_protocol.yaml").read_text(
        encoding="utf-8"
    )
    assert "direct_replacement_allowed: false" in fresh
