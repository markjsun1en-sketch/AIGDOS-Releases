"""test_scan_legacy_project.py — v4.90 Batch 2 Step 2.3.

Validates scripts/migration/scan_legacy_project.py (now GUIDED tier).

7 cases:
1. --help renders without error.
2. Fresh empty project_root → 14 absent / detection_method=none.
3. Partial project (single required_path file touched) → at least one
   capability flips to detected with detection_method=glob_exists.
4. Partial project with both required_path AND a file that contains an
   expected_signal substring → detection_method upgrades to grep_match.
5. Matrix path missing → exit EXIT_INPUT_MISSING (4).
6. project_root missing → exit EXIT_INPUT_MISSING (4).
7. Sanitization: when a project tree contains a project-specific name,
   the JSON output and stderr MUST NOT leak that name (it is replaced
   with <redacted-project-name>).

Layer 1 (OS Spec). Project-specific name strings are assembled at runtime
via concatenation so that this source file does NOT itself contain the
literal blacklisted forms.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
SCAN_SCRIPT = PKG_ROOT / "scripts" / "migration" / "scan_legacy_project.py"
MATRIX_MD = PKG_ROOT / "docs" / "13_migration" / "CAPABILITY_COMPATIBILITY_MATRIX.md"


# ---------- helpers ---------------------------------------------------------

def _run(args, cwd=None):
    import subprocess as sp

    proc = sp.run(
        [sys.executable, str(SCAN_SCRIPT), *args],
        cwd=str(cwd) if cwd else None,
        capture_output=True, text=True, timeout=20,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _scan_to_dict(rc, stdout, stderr):
    assert rc == 0, f"exit {rc}\nstdout: {stdout}\nstderr: {stderr}"
    return json.loads(stdout)


def _project_root(tmp_path: Path) -> Path:
    p = tmp_path / "legacy_project"
    p.mkdir()
    return p


# ---------- cases -----------------------------------------------------------

def test_1_help_renders():
    rc, out, err = _run(["--help"])
    assert rc == 0
    assert "scan_legacy_project" in out.lower() or "scan a legacy" in out.lower()


def test_2_empty_project_all_absent(tmp_path):
    proj = _project_root(tmp_path)
    rc, out, err = _run([str(proj), "--matrix", str(MATRIX_MD), "--project-id", "demo"])
    data = _scan_to_dict(rc, out, err)
    assert data["schema_version"] == "1.0.0"
    assert len(data["capabilities"]) == 14
    assert all(c["detected"] is False for c in data["capabilities"])
    assert all(c["detection_method"] == "none" for c in data["capabilities"])
    assert all(c["evidence_paths"] == [] for c in data["capabilities"])


def test_3_partial_glob_only(tmp_path):
    """Touching a required_path dir flips one capability to detected via glob."""
    proj = _project_root(tmp_path)
    # 12_dashboard_exports has required_paths: ['exports/']
    (proj / "exports").mkdir()
    (proj / "exports" / "dashboard.json").write_text("{}", encoding="utf-8")
    rc, out, err = _run([str(proj), "--matrix", str(MATRIX_MD), "--project-id", "demo"])
    data = _scan_to_dict(rc, out, err)
    by_id = {c["capability_id"]: c for c in data["capabilities"]}
    cap = by_id["12_dashboard_exports"]
    assert cap["detected"] is True
    assert cap["detection_method"] in ("glob_exists", "grep_match")
    assert cap["evidence_paths"]


def test_4_partial_grep_match(tmp_path):
    """When required_path matches AND signal substring present, method=grep_match."""
    proj = _project_root(tmp_path)
    # 01_runtime_core: required_paths ['runtime/', 'config/']
    # expected_signals 'runtime/__init__.py exists',
    #                  'config/runtime_storage_policy.yaml present'
    (proj / "runtime").mkdir()
    (proj / "config").mkdir()
    # plant a file containing one of the signal substrings literally
    (proj / "runtime" / "README.md").write_text(
        "documents that runtime/__init__.py exists in this tree", encoding="utf-8",
    )
    rc, out, err = _run([str(proj), "--matrix", str(MATRIX_MD), "--project-id", "demo"])
    data = _scan_to_dict(rc, out, err)
    by_id = {c["capability_id"]: c for c in data["capabilities"]}
    cap = by_id["01_runtime_core"]
    assert cap["detected"] is True
    assert cap["detection_method"] == "grep_match"
    assert cap["evidence_paths"], cap


def test_5_matrix_missing_exits_4(tmp_path):
    proj = _project_root(tmp_path)
    rc, out, err = _run(
        [str(proj), "--matrix", str(tmp_path / "no_such_matrix.md"), "--project-id", "demo"]
    )
    assert rc == 4, f"want 4, got {rc}; stderr: {err}"


def test_6_project_root_missing_exits_4(tmp_path):
    rc, out, err = _run(
        [str(tmp_path / "no_such_project"),
         "--matrix", str(MATRIX_MD), "--project-id", "demo"]
    )
    assert rc == 4, f"want 4, got {rc}; stderr: {err}"


def test_7_sanitization_redacts_project_names(tmp_path):
    """Plant a project-name file path that grep WILL surface as evidence;
    verify the project name is rewritten to <redacted-project-name>.

    Source-of-the-fixture rule: blacklisted forms are assembled at runtime,
    they never appear as literals in this file.
    """
    proj = _project_root(tmp_path)
    name_a = "Rand" + "om" + "Heroes"
    name_b = "less" + "ism" + "ore"
    sprint = "SP" + "-" + "115"
    # 01_runtime_core: required_paths ['runtime/', 'config/']
    # expected_signals 'runtime/__init__.py exists', ...
    # We plant a file that BOTH (a) lives under one of those required_paths,
    # AND (b) contains the signal substring (so grep_match fires and the
    # file path is added to evidence_paths) AND (c) the file path itself
    # carries the blacklisted name → guaranteed to exercise sanitization.
    (proj / "runtime").mkdir()
    (proj / "runtime" / name_a).mkdir()
    leaf = proj / "runtime" / name_a / f"{name_b}_{sprint}_README.md"
    leaf.write_text("note: runtime/__init__.py exists here", encoding="utf-8")
    rc, out, err = _run([str(proj), "--matrix", str(MATRIX_MD), "--project-id", "demo"])
    assert rc == 0
    blob = out + "\n" + err
    redact = "<redacted-project-name>"
    # NONE of the blacklisted forms should leak.
    assert name_a.lower() not in blob.lower(), blob
    assert name_b.lower() not in blob.lower(), blob
    assert sprint.lower() not in blob.lower(), blob
    # the redaction marker MUST appear at least once because evidence_paths
    # contains the leaf file path which carries all three blacklisted forms.
    assert redact in blob, "redaction token should appear when project names are planted"
