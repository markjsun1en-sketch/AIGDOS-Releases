"""test_migration_map.py — v4.92 reopen B3 (Migration Mapping).

Validates scripts/migration/build_migration_map.py.

Cases:
 1. Runs over the real inventory, exits 0, summary prints 49 entries.
 2. Output validates against legacy_migration_map.schema.json (when
    jsonschema is importable) AND passes a zero-dep shape guard always.
 3. Per-skill coverage + count reconciliation: every inventory skill yields
    exactly one map entry; map total == inventory total == 49; the
    by_plane / by_status tallies sum to total.
 4. plane derivation on a synthetic inventory: os_control -> control;
    pack_execution -> execution; needs_human_review -> mixed.
 5. name/function mismatch -> plane=mixed, status=split_required, BOTH target
    slots filled (Lead + pack) and a split_note present.
 6. needs_human_review -> all target slots null, role_hint null.
 7. Sanitization: an inventory carrying a project-specific name MUST NOT leak
    it into the JSON output (replaced with <redacted-project-name>).
 8. Full run under the bare managed interpreter (jsonschema-absent) still
    exits 0 — proves zero external deps.
 9. missing inventory -> EXIT_INPUT_MISSING (4).

Layer 1 (OS Spec): project-name strings are assembled at runtime via
concatenation so this source never contains a literal blacklisted form.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = PKG_ROOT / "scripts" / "migration" / "build_migration_map.py"
MAP_SCHEMA = PKG_ROOT / "schemas" / "protocol" / "legacy_migration_map.schema.json"
REAL_INVENTORY = PKG_ROOT / "docs" / "13_migration" / "legacy_skill_inventory.json"

# Bare managed interpreter (jsonschema-absent) for the zero-dep proof.
_BARE = "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"


def _run(args, python=None):
    import subprocess as sp

    proc = sp.run(
        [python or sys.executable, str(SCRIPT), *args],
        capture_output=True, text=True, timeout=60,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _run_json(inventory: Path, repo_root: Path = PKG_ROOT):
    rc, out, err = _run(
        ["--repo-root", str(repo_root), "--inventory", str(inventory), "--json"])
    assert rc == 0, f"rc={rc} err={err}"
    return json.loads(out)


# ---------- synthetic inventory --------------------------------------------

def _inv_skill(skill_id, recommended_target, current_type, discipline_hint,
               name_function_mismatch=False):
    return {
        "skill_id": skill_id,
        "source_path": f"skills/_generic_core/x/{skill_id}/SKILL.md",
        "axis": "generic_core",
        "domain": "x",
        "engine": None,
        "status": "unknown",
        "frontmatter_format": "yaml",
        "owner_agent": None,
        "primary_consumer": None,
        "current_type": current_type,
        "name_function_mismatch": name_function_mismatch,
        "migration_candidate": current_type != "unknown",
        "recommended_target": recommended_target,
        "discipline_hint": discipline_hint,
    }


@pytest.fixture()
def synthetic_inventory(tmp_path: Path) -> Path:
    inv = {
        "schema_version": "1.0.0",
        "generated_at": "2026-06-01T00:00:00Z",
        "source_version": "4.91",
        "scan_root": "skills",
        "total": 5,
        "by_axis": {"generic_core": 5},
        "by_domain": {"x": 5},
        "skills": [
            _inv_skill("a-auditor", "os_control", "review_only", "qa"),
            _inv_skill("b-spec", "pack_execution", "spec_generation", "game_design"),
            _inv_skill("c-handoff", "os_control", "handoff_generation", None),
            _inv_skill("d-generator", "pack_execution", "spec_generation",
                       "game_design", name_function_mismatch=True),
            _inv_skill("e-mystery", "needs_human_review", "unknown", "art"),
        ],
    }
    p = tmp_path / "legacy_skill_inventory.json"
    p.write_text(json.dumps(inv, indent=2), encoding="utf-8")
    return p


# ---------- zero-dep shape guard -------------------------------------------

def _guard_map(m: dict) -> None:
    assert m["schema_version"] == "1.0.0"
    for k in ("generated_at", "source_version", "target_version",
              "inventory_ref", "total", "by_plane", "by_status", "entries"):
        assert k in m, f"missing {k}"
    assert isinstance(m["entries"], list)
    assert m["total"] == len(m["entries"])
    # tallies reconcile against the entry list.
    assert sum(m["by_plane"].values()) == m["total"]
    assert sum(m["by_status"].values()) == m["total"]
    allowed_plane = {"control", "execution", "mixed", "deprecated"}
    allowed_disc = {"game_design", "art", "program", "qa", "mixed", None}
    allowed_role = {"executive", "orchestrator", "research", "design",
                    "implementation", "validation", "support", "archivist", None}
    allowed_status = {"pending", "split_required", "needs_human_review",
                      "migrated", "deprecated"}
    for e in m["entries"]:
        for k in ("legacy_skill_id", "source_path", "current_type", "plane",
                  "discipline_hint", "role_hint", "target", "migration_status"):
            assert k in e, f"entry missing {k}: {e.get('legacy_skill_id')}"
        assert e["plane"] in allowed_plane
        assert e["discipline_hint"] in allowed_disc
        assert e["role_hint"] in allowed_role
        assert e["migration_status"] in allowed_status
        for k in ("os_lead_capability", "pack_id", "skill_contract_id"):
            assert k in e["target"], f"target missing {k}"


# ---------- tests -----------------------------------------------------------

def test_runs_over_real_inventory_and_counts():
    rc, out, err = _run(["--repo-root", str(PKG_ROOT)])
    assert rc == 0, err
    assert "migration map:" in out
    assert "49 entries" in out


def test_map_validates_and_reconciles():
    m = _run_json(REAL_INVENTORY)
    _guard_map(m)
    assert m["total"] == 49
    # the B2 census shape this map mirrors.
    assert m["by_plane"] == {"control": 16, "execution": 33}
    assert m["by_status"] == {"pending": 49}
    jsonschema = pytest.importorskip("jsonschema")
    jsonschema.validate(m, json.loads(MAP_SCHEMA.read_text()))


def test_every_inventory_skill_has_one_entry():
    inv = json.loads(REAL_INVENTORY.read_text())
    inv_ids = sorted(s["skill_id"] for s in inv["skills"])
    m = _run_json(REAL_INVENTORY)
    map_ids = sorted(e["legacy_skill_id"] for e in m["entries"])
    assert map_ids == inv_ids
    assert len(map_ids) == len(set(map_ids)), "duplicate entries"
    assert m["total"] == inv["total"] == 49


def test_plane_derivation(synthetic_inventory):
    m = _run_json(synthetic_inventory)
    by_id = {e["legacy_skill_id"]: e for e in m["entries"]}
    # os_control -> control, role from current_type, Lead from discipline.
    assert by_id["a-auditor"]["plane"] == "control"
    assert by_id["a-auditor"]["role_hint"] == "validation"
    assert by_id["a-auditor"]["target"]["os_lead_capability"] == "qa_lead"
    assert by_id["a-auditor"]["target"]["pack_id"] is None
    assert by_id["a-auditor"]["migration_status"] == "pending"
    # pack_execution -> execution, pack from discipline, contract null.
    assert by_id["b-spec"]["plane"] == "execution"
    assert by_id["b-spec"]["role_hint"] == "design"
    assert by_id["b-spec"]["target"]["pack_id"] == "design_data_pack"
    assert by_id["b-spec"]["target"]["os_lead_capability"] is None
    assert by_id["b-spec"]["target"]["skill_contract_id"] is None
    # cross-cutting control (discipline None) -> orchestrator Lead.
    assert by_id["c-handoff"]["plane"] == "control"
    assert by_id["c-handoff"]["role_hint"] == "orchestrator"
    assert by_id["c-handoff"]["target"]["os_lead_capability"] == "orchestrator"


def test_mismatch_becomes_split_required(synthetic_inventory):
    m = _run_json(synthetic_inventory)
    gen = {e["legacy_skill_id"]: e for e in m["entries"]}["d-generator"]
    assert gen["plane"] == "mixed"
    assert gen["migration_status"] == "split_required"
    # both planes get a slot: planning -> Lead, generation -> pack.
    assert gen["target"]["os_lead_capability"] == "game_design_lead"
    assert gen["target"]["pack_id"] == "design_data_pack"
    assert "split_note" in gen and gen["split_note"]


def test_needs_human_review_has_null_target(synthetic_inventory):
    m = _run_json(synthetic_inventory)
    mys = {e["legacy_skill_id"]: e for e in m["entries"]}["e-mystery"]
    assert mys["plane"] == "mixed"
    assert mys["migration_status"] == "needs_human_review"
    assert mys["role_hint"] is None
    assert mys["target"]["os_lead_capability"] is None
    assert mys["target"]["pack_id"] is None
    assert mys["target"]["skill_contract_id"] is None


def test_real_inventory_has_no_unresolved_b11_items():
    """B11 resolved the real NHR/Split set in the human-reviewed inventory."""
    m = _run_json(REAL_INVENTORY)
    by_status = {}
    for e in m["entries"]:
        by_status.setdefault(e["migration_status"], []).append(e["legacy_skill_id"])
    assert by_status == {"pending": [
        e["legacy_skill_id"] for e in m["entries"]
    ]}
    resolved = {
        "asset-variation-control",
        "battle-hud-designer",
        "game-design-system-builder",
        "game-ui-wireframe-generator",
        "ui-asset-prompt-engineer",
    }
    by_id = {e["legacy_skill_id"]: e for e in m["entries"]}
    for skill_id in resolved:
        assert by_id[skill_id]["plane"] == "execution"
        assert by_id[skill_id]["migration_status"] == "pending"
        assert by_id[skill_id]["target"]["pack_id"] is not None


def test_sanitizes_project_name(tmp_path):
    project = "rand" + "om" + "heroes"  # assembled, never literal in source
    inv = {
        "schema_version": "1.0.0",
        "generated_at": "2026-06-01T00:00:00Z",
        "source_version": "4.91",
        "scan_root": "skills",
        "total": 1,
        "by_axis": {"generic_core": 1},
        "by_domain": {"x": 1},
        "skills": [{
            "skill_id": "leaky",
            "source_path": f"skills/_generic_core/x/{project}-skill/SKILL.md",
            "axis": "generic_core", "domain": "x", "engine": None,
            "status": "unknown", "frontmatter_format": "yaml",
            "owner_agent": None, "primary_consumer": None,
            "current_type": "spec_generation", "name_function_mismatch": False,
            "migration_candidate": True, "recommended_target": "pack_execution",
            "discipline_hint": "game_design",
        }],
    }
    p = tmp_path / "inv.json"
    p.write_text(json.dumps(inv), encoding="utf-8")
    rc, out, err = _run(["--repo-root", str(tmp_path), "--inventory", str(p), "--json"])
    assert rc == 0, err
    assert project.lower() not in out.lower()
    assert "<redacted-project-name>" in out


def test_runs_under_bare_interpreter():
    if not Path(_BARE).exists():
        pytest.skip("bare managed interpreter not present")
    rc, out, err = _run(["--repo-root", str(PKG_ROOT)], python=_BARE)
    assert rc == 0, f"bare run failed: {err}"
    assert "49 entries" in out


def test_missing_inventory(tmp_path):
    rc, out, err = _run(
        ["--repo-root", str(tmp_path), "--inventory", str(tmp_path / "nope.json")])
    assert rc == 4


# ---------- living-ledger merge-on-rebuild (B5-c4) -------------------------

def _write_out(inventory: Path, out: Path, extra=None):
    args = ["--repo-root", str(PKG_ROOT), "--inventory", str(inventory),
            "--out", str(out)]
    if extra:
        args += extra
    return _run(args)


def test_rebuild_preserves_migrated_progress(synthetic_inventory, tmp_path):
    out = tmp_path / "map.json"
    # 1. first build: everything derivable (no migrated yet).
    rc, _, err = _write_out(synthetic_inventory, out)
    assert rc == 0, err
    m = json.loads(out.read_text())
    assert m["by_status"].get("migrated", 0) == 0

    # 2. advance one entry to migrated with a realized landing + notes.
    for e in m["entries"]:
        if e["legacy_skill_id"] == "b-spec":
            e["migration_status"] = "migrated"
            e["target"]["os_lead_capability"] = "game_design_lead"
            e["target"]["skill_contract_id"] = "b_spec_skill"
            e["notes"] = "migrated in a slice"
    out.write_text(json.dumps(m))

    # 3. rebuild over the advanced map: progress MUST survive, decision fields
    #    MUST stay fresh.
    rc, _, err = _write_out(synthetic_inventory, out)
    assert rc == 0, err
    m2 = json.loads(out.read_text())
    b = {e["legacy_skill_id"]: e for e in m2["entries"]}["b-spec"]
    assert b["migration_status"] == "migrated", "merge lost the migrated status"
    assert b["target"]["os_lead_capability"] == "game_design_lead"
    assert b["target"]["skill_contract_id"] == "b_spec_skill"
    assert b["notes"] == "migrated in a slice"
    # decision fields still derived fresh:
    assert b["plane"] == "execution" and b["role_hint"] == "design"
    assert m2["by_status"].get("migrated") == 1


def test_no_merge_resets_progress(synthetic_inventory, tmp_path):
    out = tmp_path / "map.json"
    _write_out(synthetic_inventory, out)
    m = json.loads(out.read_text())
    for e in m["entries"]:
        if e["legacy_skill_id"] == "b-spec":
            e["migration_status"] = "migrated"
    out.write_text(json.dumps(m))
    # --no-merge forces a pure rebuild: migrated is reset to the derived default.
    rc, _, err = _write_out(synthetic_inventory, out, extra=["--no-merge"])
    assert rc == 0, err
    m2 = json.loads(out.read_text())
    b = {e["legacy_skill_id"]: e for e in m2["entries"]}["b-spec"]
    assert b["migration_status"] == "pending", "--no-merge should reset progress"


def test_rebuild_conflict_blocks(synthetic_inventory, tmp_path):
    out = tmp_path / "map.json"
    _write_out(synthetic_inventory, out)
    m = json.loads(out.read_text())
    # advance b-spec to migrated but record it on a WRONG plane, so the fresh
    # derivation (execution) disagrees -> conflict must block the rebuild.
    for e in m["entries"]:
        if e["legacy_skill_id"] == "b-spec":
            e["migration_status"] = "migrated"
            e["plane"] = "control"  # fresh derivation says execution
    out.write_text(json.dumps(m))
    rc, out_s, err = _write_out(synthetic_inventory, out)
    assert rc == 1, "policy/progress conflict must block (exit 1)"
    assert "CONFLICT" in err


def test_real_map_has_current_migrations(tmp_path):
    """The real committed map records B5 + B8 execution + B9 control + B11."""
    m = json.loads(REAL_INVENTORY.with_name(
        "legacy_to_v492_migration_map.json").read_text())
    by_status = {}
    for e in m["entries"]:
        by_status.setdefault(e["migration_status"], []).append(e["legacy_skill_id"])
    expected = {
        "rawdata-pipeline-check",
        "content-scope-breakdown",
        "feature-acceptance-definition",
        "feature-brief-structuring",
        "gameplay-loop-and-flow-definition",
        "rules-and-constraints-specification",
        "combat-feature-rollout",
        "gdd-to-spec",
        "card-ui-prefab-spec",
        "figma-handoff-spec",
        "data-config-layering",
        "numeric-id-planning",
        "ui-component-specification",
        "ui-flow-definition",
        "ui-information-architecture",
        "ui-screen-structure",
        "2d-character-motion-designer",
        "character-layer-splitter",
        "combat-animation-spec",
        "sprite-sheet-planner",
        "art-concept-from-design-brief",
        "asset-batch-planning",
        "asset-breakdown-for-engine",
        "engine-export-packaging",
        "image-cleanup-pipeline",
        "animation-qa-auditor",
        "qa-regression",
        "godot-2d-animation-implementer",
        "godot-ui-implementation-planner",
        "godot-2d-responsive-layout",
        "godot-2d-responsive-layout-general",
        "asset-prompt-animation-helper",
        "rigging-prep-handoff",
        "art-consistency-review",
        "gamestring-localization-contract",
        "cross-function-handoff-prep",
        "contract-check",
        "doc-sync",
        "multi-agent-preflight-review",
        "subagent-routing-gate",
        "task-breakdown",
        "game-ui-ux-auditor",
        "ui-review-and-iteration",
        "ui-visual-guideline-binding",
        "asset-variation-control",
        "battle-hud-designer",
        "game-design-system-builder",
        "game-ui-wireframe-generator",
        "ui-asset-prompt-engineer",
    }
    assert set(by_status.get("migrated", [])) == expected
    assert by_status.get("pending", []) == []
    assert by_status.get("needs_human_review", []) == []
    assert by_status.get("split_required", []) == []
    assert len(by_status.get("migrated", [])) == 49
    e = {x["legacy_skill_id"]: x for x in m["entries"]}["rawdata-pipeline-check"]
    assert e["target"]["skill_contract_id"] == "rawdata_pipeline_check_skill"
    assert e.get("notes")
    godot = {x["legacy_skill_id"]: x for x in m["entries"]}[
        "godot-2d-animation-implementer"]
    assert godot["target"]["pack_id"] == "godot_2d_adapter"
    control = {x["legacy_skill_id"]: x for x in m["entries"]}[
        "contract-check"]
    assert control["target"]["os_lead_capability"] == "orchestrator"
    assert control["target"]["pack_id"] is None
    assert control["target"]["skill_contract_id"] is None
    assert "orchestrator:contract_check_review" in control.get("notes", "")
    wireframe = {x["legacy_skill_id"]: x for x in m["entries"]}[
        "game-ui-wireframe-generator"]
    assert wireframe["target"]["pack_id"] == "design_data_pack"
    assert wireframe["target"]["skill_contract_id"] == "game_ui_wireframe_spec_skill"
    assert wireframe["target"]["os_lead_capability"] == "game_design_lead"
