"""test_generate_migration_report.py — v4.90 Batch 5.5.

Tests scripts/migration/generate_migration_report.py (GUIDED).

4 cases:
1. --help renders.
2. No inputs -> exit 4.
3. Markdown output contains all expected H2 sections when all four
   inputs are supplied.
4. JSON output is shape-stable: schema_version + project_id + the four
   summary blocks.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

PKG_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = PKG_ROOT / "scripts" / "migration" / "generate_migration_report.py"


def _run(*args):
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True, text=True, timeout=15,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _seed_inputs(tmp_path: Path) -> dict[str, Path]:
    protocol = {
        "project_id": "acme_demo",
        "project_runtime_protocol": {
            "legacy_project_version": "4.82",
            "mounted_core_version": "4.90",
            "target_protocol_version": "4.90",
            "compatibility_mode": "progressive_adoption",
        },
        "host": {"primary_host": "codex"},
    }
    queue = {
        "schema_version": "1.0.0",
        "queue": [
            {"capability_id": "01_runtime_core", "priority": 0,
             "dependencies": [], "compatibility_status": "breaking",
             "risk_level": "high"},
        ],
        "cycles": [],
    }
    adoption = {
        "score": 50.0,
        "adoption_phase": "discovery",
        "summary": {
            "detected_count": 7, "absent_count": 7,
            "total_scored": 14, "deprecated_count": 0,
        },
    }
    transitions = [
        {
            "capability_id": "01_runtime_core",
            "from_state": "not_present",
            "to_state": "adopted",
            "transition_status": "applied",
            "audit_event": "migration.adopt",
        },
        {
            "capability_id": "02_project_profile",
            "from_state": "not_present",
            "to_state": "adopted",
            "transition_status": "rejected",
        },
    ]
    paths = {
        "protocol": tmp_path / "protocol.json",
        "queue": tmp_path / "queue.json",
        "adoption": tmp_path / "adoption.json",
        "transitions": tmp_path / "transitions.json",
    }
    paths["protocol"].write_text(json.dumps(protocol), encoding="utf-8")
    paths["queue"].write_text(json.dumps(queue), encoding="utf-8")
    paths["adoption"].write_text(json.dumps(adoption), encoding="utf-8")
    paths["transitions"].write_text(json.dumps(transitions), encoding="utf-8")
    return paths


def test_1_help_renders():
    rc, out, err = _run("--help")
    assert rc == 0
    assert "--protocol" in out
    assert "--queue" in out


def test_2_no_inputs_exits_4():
    rc, _, err = _run()
    assert rc == 4, err


def test_3_markdown_contains_all_sections(tmp_path):
    paths = _seed_inputs(tmp_path)
    rc, out, err = _run(
        "--protocol", str(paths["protocol"]),
        "--queue", str(paths["queue"]),
        "--adoption", str(paths["adoption"]),
        "--transitions", str(paths["transitions"]),
        "--format", "markdown",
    )
    assert rc == 0, err
    assert "# Migration Report" in out
    assert "## Protocol" in out
    assert "## Capability Queue" in out
    assert "## Adoption Score" in out
    assert "## Transitions" in out


def test_4_json_shape_stable(tmp_path):
    paths = _seed_inputs(tmp_path)
    rc, out, err = _run(
        "--protocol", str(paths["protocol"]),
        "--queue", str(paths["queue"]),
        "--adoption", str(paths["adoption"]),
        "--transitions", str(paths["transitions"]),
        "--format", "json",
    )
    assert rc == 0, err
    doc = json.loads(out)
    assert doc["schema_version"] == "1.0.0"
    assert doc["project_id"] == "acme_demo"
    assert {"protocol", "queue_summary", "adoption_summary",
            "transitions_summary"} <= doc.keys()
    assert doc["queue_summary"]["total"] == 1
    assert doc["adoption_summary"]["score"] == 50.0
    assert doc["transitions_summary"]["applied"] == ["01_runtime_core"]
    assert doc["transitions_summary"]["rejected"] == ["02_project_profile"]
