"""test_validate_protocol_compatibility.py — v4.90 Batch 5.5.

Tests scripts/migration/validate_protocol_compatibility.py (GUIDED).

5 cases:
1. --help renders.
2. Project yaml with valid capabilities matching matrix -> exit 0.
3. Project declares capability NOT in matrix -> exit 1 (ERROR).
4. Project declares adopted capability but omits its dependency -> WARN
   by default (exit 0), ERROR under --strict (exit 1).
5. Matrix path missing -> exit 4.

Layer 1 (OS Spec). Generic placeholders only.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = PKG_ROOT / "scripts" / "migration" / "validate_protocol_compatibility.py"
MATRIX = PKG_ROOT / "docs" / "13_migration" / "CAPABILITY_COMPATIBILITY_MATRIX.md"


def _run(*args):
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True, text=True, timeout=15,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _write(project_root: Path, yaml_body: str) -> Path:
    d = project_root / ".ai_dev_os"
    d.mkdir(parents=True, exist_ok=True)
    p = d / "project_runtime_protocol.yaml"
    p.write_text(yaml_body, encoding="utf-8")
    return p


_BASE = '''\
project_id: "acme_demo"
project_name: "Acme demo"
project_runtime_protocol:
  legacy_project_version: "4.82"
  mounted_core_version: "4.90"
  target_protocol_version: "4.90"
  compatibility_mode: "progressive_adoption"
host:
  primary_host: "codex"
capabilities:
'''


def test_1_help_renders():
    rc, out, err = _run("--help")
    assert rc == 0
    assert "--strict" in out


def test_2_valid_capabilities_pass(tmp_path):
    yaml_body = _BASE + (
        "  01_runtime_core:\n"
        "    adoption_status: \"needs_adapter\"\n"
        "  07_ltm_capture_consult:\n"
        "    adoption_status: \"needs_adapter\"\n"
    )
    _write(tmp_path, yaml_body)
    rc, out, err = _run(str(tmp_path))
    # Non-strict: missing 12 others are WARN only, exit 0.
    assert rc == 0, err
    assert "Summary" in out


def test_3_capability_outside_matrix_rejected(tmp_path):
    yaml_body = _BASE + (
        "  99_fictional_feature:\n"
        "    adoption_status: \"adopted\"\n"
    )
    _write(tmp_path, yaml_body)
    rc, out, err = _run(str(tmp_path))
    assert rc == 1, err
    assert "99_fictional_feature" in out or "99_fictional_feature" in err


def test_4_dependency_missing_warn_vs_strict(tmp_path):
    # 14_self_evolution_proposal depends on 07_ltm_capture_consult.
    # Declaring it adopted without enumerating the dep -> WARN.
    yaml_body = _BASE + (
        "  14_self_evolution_proposal:\n"
        "    adoption_status: \"adopted\"\n"
    )
    _write(tmp_path, yaml_body)
    rc, out, err = _run(str(tmp_path))
    assert rc == 0, err  # WARN only
    rc2, _, _ = _run(str(tmp_path), "--strict")
    # --strict: WARN escalates to ERROR.
    assert rc2 == 1


def test_5_matrix_missing_exits_4(tmp_path):
    _write(tmp_path, _BASE + "  01_runtime_core:\n    adoption_status: \"not_present\"\n")
    rc, _, err = _run(str(tmp_path), "--matrix", str(tmp_path / "no_such_matrix.md"))
    assert rc == 4, err
