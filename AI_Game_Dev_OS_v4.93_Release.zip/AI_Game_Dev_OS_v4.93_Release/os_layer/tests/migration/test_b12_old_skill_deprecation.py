"""B12 old skills deprecation strategy tests."""
from __future__ import annotations

import json
from pathlib import Path

PKG_ROOT = Path(__file__).resolve().parents[2]
MAP = PKG_ROOT / "docs" / "13_migration" / "legacy_to_v492_migration_map.json"
SKILLS_README = PKG_ROOT / "skills" / "README.md"


def _load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def test_old_skills_tree_is_marked_deprecated_read_only():
    text = SKILLS_README.read_text(encoding="utf-8")
    assert "v4.92 B12 deprecation status" in text
    assert "`deprecated-read-only` legacy skill surface" in text
    assert "Do not add new skills or route new work through this legacy tree" in text
    assert "legacy_to_v492_migration_map.json" in text


def test_all_legacy_skills_migrated_without_using_legacy_tree_as_target():
    data = _load(MAP)
    assert data["total"] == 49
    assert data["by_status"] == {"migrated": 49}

    for entry in data["entries"]:
        assert entry["source_path"].startswith("skills/")
        assert entry["migration_status"] == "migrated"
        target = entry["target"]
        target_values = [
            target.get("os_lead_capability"),
            target.get("pack_id"),
            target.get("skill_contract_id"),
        ]
        assert any(target_values), entry["legacy_skill_id"]
        assert all(
            not (isinstance(value, str) and value.startswith("skills/"))
            for value in target_values
        )
