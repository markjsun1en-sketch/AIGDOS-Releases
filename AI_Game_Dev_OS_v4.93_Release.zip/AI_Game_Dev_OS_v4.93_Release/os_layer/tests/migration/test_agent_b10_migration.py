"""test_agent_b10_migration.py — v4.92 reopen B10.

Validates the first B10 agent migration rule:

- agent_contract has a single primary discipline.
- cross-discipline collaboration is represented by consults_disciplines.
- the four legacy v4.91 agent names are folded into existing v4.92
  production agent contracts without creating duplicate owners.
"""
from __future__ import annotations

import json
from pathlib import Path

import jsonschema

PKG_ROOT = Path(__file__).resolve().parents[2]
AGENT_SCHEMA = PKG_ROOT / "capability_protocols" / "agent_contract.schema.json"
PACKS = PKG_ROOT / "packs"


def _load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _agent(rel: str) -> dict:
    return _load(PKG_ROOT / rel)


def test_all_shipped_agent_contracts_have_single_discipline():
    schema = _load(AGENT_SCHEMA)
    for path in sorted(PACKS.glob("**/agents/*.json")):
        data = _load(path)
        jsonschema.validate(data, schema)
        discipline = data["discipline"]
        assert discipline in {"game_design", "art", "program", "qa", None}
        assert not isinstance(discipline, list)


def test_b10_legacy_agent_provenance_landed():
    design = _agent("packs/game_system_packs/design_data/agents/design_spec_author.json")
    art = _agent("packs/game_system_packs/art_asset/agents/art_asset_preparer.json")

    assert design["discipline"] == "game_design"
    assert set(design["consults_disciplines"]) == {"art", "program", "qa"}
    assert set(design["migrated_from_agents"]) == {
        "Design_Planning_Agent",
        "UI_UX_Agent",
    }

    assert art["discipline"] == "art"
    assert set(art["consults_disciplines"]) == {"game_design", "program", "qa"}
    assert set(art["migrated_from_agents"]) == {
        "Art_Direction_Agent",
        "Art_Production_Agent",
    }


def test_ui_ux_agent_is_game_design_primary_with_art_program_qa_consults():
    design = _agent("packs/game_system_packs/design_data/agents/design_spec_author.json")

    assert "UI_UX_Agent" in design["migrated_from_agents"]
    assert design["discipline"] == "game_design"
    assert set(design["consults_disciplines"]) == {"art", "program", "qa"}
    assert any("visual style lock" in t and "art_lead" in t
               for t in design["handoff_triggers"])
    assert any("Godot scene/theme implementation" in t and "godot_2d_adapter" in t
               for t in design["handoff_triggers"])
    assert any("readability/usability acceptance" in t and "qa_lead" in t
               for t in design["handoff_triggers"])
