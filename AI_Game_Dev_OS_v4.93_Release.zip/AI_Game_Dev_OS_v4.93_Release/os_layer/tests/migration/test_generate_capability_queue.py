"""test_generate_capability_queue.py — v4.90 Batch 5.5.

Tests scripts/migration/generate_capability_queue.py (GUIDED).

5 cases:
1. --help renders.
2. Default matrix produces 14-entry queue with priorities increasing
   monotonically and 01_runtime_core (no deps) at priority 0.
3. Each entry's dependencies set is a subset of capabilities preceding
   it in the queue (dependency-first ordering invariant).
4. --scan-result with detected capabilities flags them as already_detected.
5. --break-cycle 'A:B' drops the A->B edge (no behavioural change on the
   real matrix since it has no cycle, but the kwarg is accepted; absent
   cycle means queue is still produced).
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

PKG_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = PKG_ROOT / "scripts" / "migration" / "generate_capability_queue.py"


def _run(*args):
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True, text=True, timeout=15,
    )
    return proc.returncode, proc.stdout, proc.stderr


def test_1_help_renders():
    rc, out, err = _run("--help")
    assert rc == 0
    assert "--break-cycle" in out


def test_2_queue_shape_and_first_priority():
    rc, out, err = _run()
    assert rc == 0, err
    doc = json.loads(out)
    assert doc["schema_version"] == "1.0.0"
    assert len(doc["queue"]) == 14
    priorities = [entry["priority"] for entry in doc["queue"]]
    assert priorities == sorted(priorities) == list(range(14))
    assert doc["queue"][0]["capability_id"] == "01_runtime_core"
    assert doc["queue"][0]["dependencies"] == []
    assert doc["cycles"] == []


def test_3_dependency_first_ordering():
    rc, out, _ = _run()
    assert rc == 0
    doc = json.loads(out)
    seen: set[str] = set()
    for entry in doc["queue"]:
        for dep in entry["dependencies"]:
            assert dep in seen, (
                f"{entry['capability_id']!r} listed before its dep {dep!r}"
            )
        seen.add(entry["capability_id"])


def test_4_scan_result_flags_already_detected(tmp_path):
    scan = {
        "schema_version": "1.0.0",
        "capabilities": [
            {
                "capability_id": "01_runtime_core",
                "detected": True,
                "detection_method": "glob_exists",
                "evidence_paths": ["docs/runtime/Anchor.md"],
            },
            {
                "capability_id": "02_project_profile",
                "detected": False,
                "detection_method": "none",
                "evidence_paths": [],
            },
        ],
    }
    scan_path = tmp_path / "scan.json"
    scan_path.write_text(json.dumps(scan), encoding="utf-8")
    rc, out, err = _run("--scan-result", str(scan_path))
    assert rc == 0, err
    doc = json.loads(out)
    by_id = {e["capability_id"]: e for e in doc["queue"]}
    assert by_id["01_runtime_core"]["already_detected"] is True
    assert by_id["02_project_profile"]["already_detected"] is False


def test_5_break_cycle_argument_accepted():
    rc, out, err = _run(
        "--break-cycle", "10_pack_activation",
    )
    assert rc == 0, err
    doc = json.loads(out)
    # When 10's outgoing edges are broken, 10 may bubble forward in the
    # queue; we just assert the queue still has 14 entries and no cycles.
    assert len(doc["queue"]) == 14
    assert doc["cycles"] == []
