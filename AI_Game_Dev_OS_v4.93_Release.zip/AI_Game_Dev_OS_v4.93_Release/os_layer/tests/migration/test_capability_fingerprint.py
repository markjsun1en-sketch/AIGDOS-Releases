"""test_capability_fingerprint.py — fingerprint integrity for the 14 capabilities.

v4.90 Batch 1 Step 3 (R2.001 mitigation):
Prevents fingerprint drift / typo / missing-field regressions in
``docs/13_migration/CAPABILITY_COMPATIBILITY_MATRIX.md``.

Test categories:
1. Parser sanity                  — 14 blocks, IDs match canonical list
2. Required field presence        — every capability has the schema-mandated keys
3. Fingerprint structural rules   — required_paths non-empty, detect_command shell-safe
4. Cross-reference consistency    — dependencies refer to existing capability IDs
5. v4.89 self-detect              — every fingerprint that should hit on v4.90 itself does;
                                    deprecated/missing capabilities correctly do NOT hit.
6. Schema validation              — each block validates against compatibility_matrix.schema.json
"""
from __future__ import annotations

import json
import shlex
import subprocess
from pathlib import Path

import pytest

from scripts.migration._matrix_parser import (
    get_capability,
    iter_capability_ids,
    parse_capability_blocks,
)

# v4.90 root (one level up from tests/migration/)
PKG_ROOT = Path(__file__).resolve().parents[2]
MATRIX_MD = PKG_ROOT / "docs" / "13_migration" / "CAPABILITY_COMPATIBILITY_MATRIX.md"
MATRIX_SCHEMA = PKG_ROOT / "schemas" / "protocol" / "compatibility_matrix.schema.json"

# The canonical 14 capability IDs as declared in PROJECT_RUNTIME_PROTOCOL.md.
CANONICAL_IDS = [
    "01_runtime_core",
    "02_project_profile",
    "03_host_profile",
    "04_handoff_registry",
    "05_validation_evidence",
    "06_context_governance",
    "07_ltm_capture_consult",
    "08_failure_fix_memory",
    "09_agent_library",
    "10_pack_activation",
    "11_profile_parity",
    "12_dashboard_exports",
    "13_adapter_bridge",
    "14_self_evolution_proposal",
]

# Capabilities that should be present on a v4.89 RC3 / v4.90 fork tree.
# Used by the self-detect test below. Batch 5 promoted rows 09 and 10
# to requires_adapter with fingerprints rooted at v4.90 paths:
#   09_agent_library: docs/16_agent_library/ + agent_packs/ + schemas
#   10_pack_activation: config/pack_selection_policy.yaml +
#                       game_type_packs/ + context_packs/
# Both rows are now present on a v4.90 self-fork because Batch 5
# authored docs/16_agent_library/ + agent_packs/, and the v4.89_Release
# baseline already shipped config/pack_selection_policy.yaml +
# context_packs/. The Layer-2 EXPECTED_ABSENT_ON_V490_SELF set is now
# empty for Batch 5; adopting projects exercise the requires_adapter
# path via scan_legacy_project, not via this self-detect harness.
# 14 was promoted in Batch 6 — proposals/ now exists on self-fork.
EXPECTED_PRESENT_ON_V490_SELF = {
    "01_runtime_core",
    "02_project_profile",
    "03_host_profile",
    "04_handoff_registry",
    "05_validation_evidence",
    "06_context_governance",
    "07_ltm_capture_consult",
    "08_failure_fix_memory",
    "09_agent_library",      # Batch 5: docs/16_agent_library/ + agent_packs/
    "10_pack_activation",    # config/pack_selection_policy.yaml exists
    "11_profile_parity",
    "12_dashboard_exports",
    "13_adapter_bridge",
    "14_self_evolution_proposal",  # Batch 6: proposals/ present
}
EXPECTED_ABSENT_ON_V490_SELF: set[str] = set()  # empty after Batch 5


@pytest.fixture(scope="module")
def blocks() -> list[dict]:
    return parse_capability_blocks(MATRIX_MD)


# ---------------------------------------------------------------------------
# 1. Parser sanity
# ---------------------------------------------------------------------------


def test_parser_returns_14_blocks(blocks):
    assert len(blocks) == 14, (
        f"expected 14 capability blocks, got {len(blocks)}: "
        f"{list(iter_capability_ids(blocks))}"
    )


def test_parser_finds_all_canonical_ids(blocks):
    parsed_ids = list(iter_capability_ids(blocks))
    assert parsed_ids == CANONICAL_IDS, (
        "capability IDs must appear in canonical order; "
        f"got {parsed_ids}"
    )


# ---------------------------------------------------------------------------
# 2. Required-field presence
# ---------------------------------------------------------------------------


REQUIRED_TOP_LEVEL = [
    "capability_id",
    "source_version",
    "target_version",
    "compatibility_status",
    "risk_level",
    "fingerprint",
]


@pytest.mark.parametrize("capability_id", CANONICAL_IDS)
def test_capability_has_required_fields(capability_id, blocks):
    cap = get_capability(blocks, capability_id)
    assert cap is not None, f"capability {capability_id} missing from matrix"
    for field in REQUIRED_TOP_LEVEL:
        assert field in cap, f"{capability_id}: missing required field '{field}'"


# ---------------------------------------------------------------------------
# 3. Fingerprint structural rules
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("capability_id", CANONICAL_IDS)
def test_fingerprint_required_paths_non_empty(capability_id, blocks):
    cap = get_capability(blocks, capability_id)
    fp = cap.get("fingerprint", {})
    paths = fp.get("required_paths") or []
    assert isinstance(paths, list), (
        f"{capability_id}: fingerprint.required_paths must be a list"
    )
    assert len(paths) >= 1, (
        f"{capability_id}: fingerprint.required_paths must have at least 1 entry"
    )
    for p in paths:
        assert isinstance(p, str) and p, (
            f"{capability_id}: fingerprint.required_paths entries must be non-empty strings"
        )


@pytest.mark.parametrize("capability_id", CANONICAL_IDS)
def test_detect_command_is_shell_safe(capability_id, blocks):
    """detect_command must be parseable by shlex (catches unbalanced quotes)."""
    cap = get_capability(blocks, capability_id)
    cmd = cap.get("fingerprint", {}).get("detect_command")
    if not cmd:
        pytest.skip(f"{capability_id} has no detect_command")
    # shlex.split raises ValueError on unbalanced quotes — that's what we test for.
    tokens = shlex.split(cmd)
    assert tokens, f"{capability_id}: detect_command tokenized to empty"


# ---------------------------------------------------------------------------
# 4. Cross-reference consistency
# ---------------------------------------------------------------------------


def test_dependencies_refer_to_existing_capabilities(blocks):
    """Every capability_id appearing in any 'dependencies' list must
    itself be one of the 14 declared capabilities."""
    valid_ids = set(iter_capability_ids(blocks))
    for cap in blocks:
        deps = cap.get("dependencies") or []
        for dep in deps:
            assert dep in valid_ids, (
                f"{cap['capability_id']}: declares dependency on undefined "
                f"capability '{dep}' (valid: {sorted(valid_ids)})"
            )


def test_compatibility_status_uses_valid_enum(blocks):
    valid = {"direct_compatible", "requires_adapter", "breaking", "deprecated"}
    for cap in blocks:
        s = cap.get("compatibility_status")
        assert s in valid, (
            f"{cap['capability_id']}: compatibility_status='{s}' not in {valid}"
        )


def test_risk_level_uses_valid_enum(blocks):
    valid = {"low", "medium", "high"}
    for cap in blocks:
        r = cap.get("risk_level")
        assert r in valid, (
            f"{cap['capability_id']}: risk_level='{r}' not in {valid}"
        )


# ---------------------------------------------------------------------------
# 5. v4.90 self-detect — fingerprints execute correctly on v4.90 itself
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("capability_id", sorted(EXPECTED_PRESENT_ON_V490_SELF))
def test_fingerprint_detects_capability_on_v490_self(capability_id, blocks):
    """Run detect_command in v4.90 root; expect exit 0 (capability present)."""
    cap = get_capability(blocks, capability_id)
    cmd = cap.get("fingerprint", {}).get("detect_command")
    if not cmd:
        pytest.skip(f"{capability_id} has no detect_command")
    result = subprocess.run(
        cmd, shell=True, cwd=PKG_ROOT, capture_output=True, timeout=10
    )
    assert result.returncode == 0, (
        f"{capability_id}: detect_command should exit 0 on v4.90 self-scan, "
        f"got {result.returncode}; cmd={cmd!r}"
    )


@pytest.mark.parametrize("capability_id", sorted(EXPECTED_ABSENT_ON_V490_SELF))
def test_fingerprint_does_not_detect_absent_capability(capability_id, blocks):
    """Run detect_command in v4.90 root; expect non-zero (capability absent)."""
    cap = get_capability(blocks, capability_id)
    cmd = cap.get("fingerprint", {}).get("detect_command")
    if not cmd:
        pytest.skip(f"{capability_id} has no detect_command")
    result = subprocess.run(
        cmd, shell=True, cwd=PKG_ROOT, capture_output=True, timeout=10
    )
    assert result.returncode != 0, (
        f"{capability_id}: detect_command should exit non-zero (capability "
        f"absent in v4.90), got {result.returncode}; cmd={cmd!r}"
    )


# ---------------------------------------------------------------------------
# 6. Schema validation
# ---------------------------------------------------------------------------


def test_schema_file_loads():
    """compatibility_matrix.schema.json must be valid JSON."""
    schema = json.loads(MATRIX_SCHEMA.read_text())
    assert schema.get("$schema"), "schema missing $schema"
    assert schema.get("type") == "object", "schema not object type"


def test_each_block_has_schema_required_fields(blocks):
    """Cross-check blocks against the schema's 'required' array."""
    schema = json.loads(MATRIX_SCHEMA.read_text())
    required = schema.get("required", [])
    for cap in blocks:
        for field in required:
            assert field in cap, (
                f"{cap.get('capability_id')}: missing schema-required field '{field}'"
            )
