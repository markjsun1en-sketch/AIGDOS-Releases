"""test_validate_capability_adoption.py — v4.90 Batch 5.5.

Tests scripts/migration/validate_capability_adoption.py (GUIDED).

7 cases:
1. --help renders.
2. row 09_agent_library against v4.90 self-fork -> overall_status=pass
   (all 3 checks green: agent_library_spec_present, agent_packs_ledger_present,
   agent_role_schema_valid).
3. row 10_pack_activation against v4.90 self-fork -> overall_status=pass
   (2 checks: pack_selection_policy_valid, pack_selection_manifest_integrity).
4. row 09 against an empty project root -> overall_status=fail (all 3 fail).
5. row with no required_checks (e.g. 12_dashboard_exports currently has
   none) -> overall_status handled (pass when checks list is empty).
6. Unknown capability_id -> exit 1 + error JSON.
7. --evidence-out writes evidence JSON to file.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

PKG_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = PKG_ROOT / "scripts" / "migration" / "validate_capability_adoption.py"


def _run(*args):
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True, text=True, timeout=15,
    )
    return proc.returncode, proc.stdout, proc.stderr


def test_1_help_renders():
    rc, out, err = _run("--help")
    assert rc == 0
    assert "required_checks" in out or "evidence" in out


def test_2_row_09_on_self_fork_passes():
    rc, out, err = _run(
        "09_agent_library", "--project", str(PKG_ROOT), "--format", "json",
    )
    assert rc == 0, err
    doc = json.loads(out)
    assert doc["overall_status"] == "pass"
    assert doc["failed_count"] == 0
    checks = {c["check"] for c in doc["required_checks"]}
    assert "agent_library_spec_present" in checks
    assert "agent_packs_ledger_present" in checks
    assert "agent_role_schema_valid" in checks


def test_3_row_10_on_self_fork_passes():
    rc, out, err = _run(
        "10_pack_activation", "--project", str(PKG_ROOT), "--format", "json",
    )
    assert rc == 0, err
    doc = json.loads(out)
    assert doc["overall_status"] == "pass"
    checks = {c["check"] for c in doc["required_checks"]}
    assert "pack_selection_policy_valid" in checks
    assert "pack_selection_manifest_integrity" in checks


def test_4_row_09_on_empty_project_fails(tmp_path):
    rc, out, err = _run(
        "09_agent_library", "--project", str(tmp_path), "--format", "json",
    )
    assert rc == 1, err
    doc = json.loads(out)
    assert doc["overall_status"] == "fail"
    assert doc["failed_count"] == 3


def test_5_row_with_empty_checks_returns_pass():
    # 12_dashboard_exports currently declares no required_checks.
    rc, out, err = _run(
        "12_dashboard_exports", "--project", str(PKG_ROOT), "--format", "json",
    )
    assert rc == 0, err
    doc = json.loads(out)
    assert doc["failed_count"] == 0
    # checks list may be empty; overall_status should still resolve.


def test_6_unknown_capability_id_exits_1():
    rc, out, err = _run(
        "99_missing_row", "--project", str(PKG_ROOT), "--format", "json",
    )
    assert rc == 1, err
    doc = json.loads(out)
    assert "error" in doc
    assert "99_missing_row" in doc["error"]


def test_7_evidence_out_writes_file(tmp_path):
    evidence = tmp_path / "row09_evidence.json"
    rc, _, err = _run(
        "09_agent_library",
        "--project", str(PKG_ROOT),
        "--evidence-out", str(evidence),
        "--format", "json",
    )
    assert rc == 0, err
    assert evidence.is_file()
    doc = json.loads(evidence.read_text(encoding="utf-8"))
    assert doc["overall_status"] == "pass"
