"""test_detect_project_protocol.py — v4.90 Batch 5.5.

Tests scripts/migration/detect_project_protocol.py (GUIDED tier).

6 cases:
1. --help renders.
2. yaml absent + --fallback-default -> exit 0 with v4.82 default JSON.
3. yaml absent, no --fallback-default -> exit 4.
4. well-formed minimal yaml -> exit 0 + normalised JSON.
5. yaml with invalid project_id (uppercase) -> exit 1.
6. yaml with unknown compatibility_mode -> exit 1.

Layer 1 (OS Spec). Generic placeholders only.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = PKG_ROOT / "scripts" / "migration" / "detect_project_protocol.py"


def _run(*args, cwd=None):
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True, text=True, timeout=15, cwd=cwd,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _write_protocol(project_root: Path, payload: str) -> Path:
    d = project_root / ".ai_dev_os"
    d.mkdir(parents=True, exist_ok=True)
    p = d / "project_runtime_protocol.yaml"
    p.write_text(payload, encoding="utf-8")
    return p


_MINIMAL_YAML = '''\
project_id: "acme_demo"
project_name: "Acme demo project"
project_runtime_protocol:
  legacy_project_version: "4.82"
  mounted_core_version: "4.90"
  target_protocol_version: "4.90"
  compatibility_mode: "progressive_adoption"
host:
  primary_host: "codex"
'''


def test_1_help_renders():
    rc, out, err = _run("--help")
    assert rc == 0
    assert "--fallback-default" in out


def test_2_fallback_default_emits_v482(tmp_path):
    rc, out, err = _run(str(tmp_path), "--fallback-default")
    assert rc == 0, err
    doc = json.loads(out)
    prp = doc["project_runtime_protocol"]
    assert prp["legacy_project_version"] == "4.82"
    assert prp["compatibility_mode"] == "progressive_adoption"
    assert doc["host"]["primary_host"] == "codex"


def test_3_yaml_absent_no_fallback_exits_4(tmp_path):
    rc, _, err = _run(str(tmp_path))
    assert rc == 4, err
    assert "not found" in err.lower()


def test_4_well_formed_yaml_round_trips(tmp_path):
    _write_protocol(tmp_path, _MINIMAL_YAML)
    rc, out, err = _run(str(tmp_path))
    assert rc == 0, err
    doc = json.loads(out)
    assert doc["project_id"] == "acme_demo"
    assert doc["host"]["primary_host"] == "codex"


def test_5_invalid_project_id_rejected(tmp_path):
    bad = _MINIMAL_YAML.replace('"acme_demo"', '"Acme_Demo"')
    _write_protocol(tmp_path, bad)
    rc, _, err = _run(str(tmp_path))
    assert rc == 1, err
    assert "project_id" in err


def test_6_unknown_compatibility_mode_rejected(tmp_path):
    bad = _MINIMAL_YAML.replace(
        '"progressive_adoption"', '"magic_mode"'
    )
    _write_protocol(tmp_path, bad)
    rc, _, err = _run(str(tmp_path))
    assert rc == 1, err
    assert "compatibility_mode" in err
