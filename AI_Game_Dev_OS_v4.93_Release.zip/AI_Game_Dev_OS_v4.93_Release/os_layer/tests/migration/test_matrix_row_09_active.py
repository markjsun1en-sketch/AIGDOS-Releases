"""test_matrix_row_09_active.py — v4.90 Batch 5 Step 5.6.

Verifies that the Batch 5 matrix-row-09 promotion is durable:
- row 09 `09_agent_library` is now `requires_adapter` (not `deprecated`).
- The adapter.name field points to the v4.90 agent library directory
  adapter (`agent_library_v490_directory`).
- fingerprint.required_paths covers the three-path triple (D7=D):
  docs/16_agent_library/, agent_packs/, schemas/agent_library/
  agent_role.schema.json.
- validation.required_checks is non-empty (3 checks).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import sys
from pathlib import Path

PKG_ROOT = Path(__file__).resolve().parents[2]
MATRIX_MD = PKG_ROOT / "docs" / "13_migration" / "CAPABILITY_COMPATIBILITY_MATRIX.md"

sys.path.insert(0, str(PKG_ROOT / "scripts" / "migration"))
from _matrix_parser import parse_capability_blocks, get_capability  # noqa: E402


def test_row_09_is_requires_adapter():
    blocks = parse_capability_blocks(MATRIX_MD)
    row = get_capability(blocks, "09_agent_library")
    assert row is not None, "row 09 must exist in the matrix"
    assert row.get("compatibility_status") == "requires_adapter", (
        f"expected 'requires_adapter', got {row.get('compatibility_status')!r}"
    )


def test_row_09_has_v490_adapter_name():
    blocks = parse_capability_blocks(MATRIX_MD)
    row = get_capability(blocks, "09_agent_library")
    adapter = (row or {}).get("adapter") or {}
    assert adapter.get("name") == "agent_library_v490_directory", (
        f"expected 'agent_library_v490_directory', got {adapter.get('name')!r}"
    )


def test_row_09_fingerprint_three_path_triple():
    """D7=D fingerprint: three-path verification triple covering docs,
    ledger and schema."""
    blocks = parse_capability_blocks(MATRIX_MD)
    row = get_capability(blocks, "09_agent_library")
    fp = (row or {}).get("fingerprint") or {}
    required = fp.get("required_paths") or []
    expected = {
        "docs/16_agent_library/",
        "agent_packs/",
        "schemas/agent_library/agent_role.schema.json",
    }
    missing = expected - set(required)
    assert not missing, (
        f"row 09 fingerprint missing required_paths: {sorted(missing)}; "
        f"got {required!r}"
    )


def test_row_09_validation_required_checks_non_empty():
    blocks = parse_capability_blocks(MATRIX_MD)
    row = get_capability(blocks, "09_agent_library")
    validation = (row or {}).get("validation") or {}
    checks = validation.get("required_checks") or []
    assert checks, (
        "row 09 must declare at least one required_check after Batch 5"
    )
    # Expect the three Batch 5 promotion checks.
    expected = {
        "agent_library_spec_present",
        "agent_packs_ledger_present",
        "agent_role_schema_valid",
    }
    missing = expected - set(checks)
    assert not missing, (
        f"row 09 missing required_checks: {sorted(missing)}; got {checks!r}"
    )
