"""test_matrix_row_10_active.py — v4.90 Batch 5 Step 5.6.

Verifies that the Batch 5 matrix-row-10 promotion is durable:
- row 10 `10_pack_activation` is now `requires_adapter` (not `deprecated`).
- The adapter.name field points to the v4.90 pack activation directory
  adapter (`pack_activation_v490_directory`).
- fingerprint.required_paths preserves the three-path triple covering
  pack_selection_policy.yaml, game_type_packs/, context_packs/.
- validation.required_checks is non-empty (2 checks).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import sys
from pathlib import Path

PKG_ROOT = Path(__file__).resolve().parents[2]
MATRIX_MD = PKG_ROOT / "docs" / "13_migration" / "CAPABILITY_COMPATIBILITY_MATRIX.md"

sys.path.insert(0, str(PKG_ROOT / "scripts" / "migration"))
from _matrix_parser import parse_capability_blocks, get_capability  # noqa: E402


def test_row_10_is_requires_adapter():
    blocks = parse_capability_blocks(MATRIX_MD)
    row = get_capability(blocks, "10_pack_activation")
    assert row is not None, "row 10 must exist in the matrix"
    assert row.get("compatibility_status") == "requires_adapter", (
        f"expected 'requires_adapter', got {row.get('compatibility_status')!r}"
    )


def test_row_10_has_v490_adapter_name():
    blocks = parse_capability_blocks(MATRIX_MD)
    row = get_capability(blocks, "10_pack_activation")
    adapter = (row or {}).get("adapter") or {}
    assert adapter.get("name") == "pack_activation_v490_directory", (
        f"expected 'pack_activation_v490_directory', got {adapter.get('name')!r}"
    )


def test_row_10_fingerprint_three_path_triple():
    """Three-path fingerprint covering policy file + two pack roots."""
    blocks = parse_capability_blocks(MATRIX_MD)
    row = get_capability(blocks, "10_pack_activation")
    fp = (row or {}).get("fingerprint") or {}
    required = fp.get("required_paths") or []
    expected = {
        "config/pack_selection_policy.yaml",
        "game_type_packs/",
        "context_packs/",
    }
    missing = expected - set(required)
    assert not missing, (
        f"row 10 fingerprint missing required_paths: {sorted(missing)}; "
        f"got {required!r}"
    )


def test_row_10_validation_required_checks_non_empty():
    blocks = parse_capability_blocks(MATRIX_MD)
    row = get_capability(blocks, "10_pack_activation")
    validation = (row or {}).get("validation") or {}
    checks = validation.get("required_checks") or []
    assert checks, (
        "row 10 must declare at least one required_check after Batch 5"
    )
    expected = {
        "pack_selection_policy_valid",
        "pack_selection_manifest_integrity",
    }
    missing = expected - set(checks)
    assert not missing, (
        f"row 10 missing required_checks: {sorted(missing)}; got {checks!r}"
    )
