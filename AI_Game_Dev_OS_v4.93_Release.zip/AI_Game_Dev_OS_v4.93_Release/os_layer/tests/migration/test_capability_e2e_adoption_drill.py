"""Capability adoption e2e drill — v4.90 Batch 12 Step 12.5 (GAP #5).

Covers the new `--adoption-flow` mode of
``scripts/adoption/run_mock_harness.py``: drives one or more
capability_ids through the full pipeline:

    scan_legacy_project
      └→ validate_protocol_compatibility
            └→ generate_capability_queue
                  └→ adopt_capability (not_present → adopting → adopted)
                        └→ validate_capability_adoption

The drill writes ``<work>/adoption_drill_summary.json`` with per-
capability results and an aggregate ``all_adopted`` flag.

8 tests:
  1. Single cap happy path — 01_runtime_core
  2. Single cap happy path — 05_validation_evidence
  3. Single cap happy path — 07_ltm_capture_consult
  4. 3-cap combined drill (matches plan §10.2 + handoff §4 GAP #5)
  5. Unknown capability_id rejected (status=unknown_capability_id)
  6. Summary JSON shape sentinel (keys / nesting)
  7. Summary file actually lands at <work>/adoption_drill_summary.json
  8. Empty --adoption-flow (whitespace / commas only) rejected as
     EXIT_USAGE.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
HARNESS = PKG_ROOT / "scripts" / "adoption" / "run_mock_harness.py"


def _run_drill(
    cap_csv: str, work_dir: Path,
    fixture: str = "full",
    extra: list[str] | None = None,
) -> tuple[int, str, str]:
    cmd = [
        sys.executable, str(HARNESS),
        "--fixture", fixture,
        "--work-dir", str(work_dir),
        "--adoption-flow", cap_csv,
        "--out", str(work_dir / "report.json"),
    ]
    if extra:
        cmd.extend(extra)
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    return proc.returncode, proc.stdout, proc.stderr


def _load_summary(work_dir: Path) -> dict:
    summary_path = work_dir / "adoption_drill_summary.json"
    return json.loads(summary_path.read_text(encoding="utf-8"))


# --------------------------------------------------------------------------
# 1-3. Single-cap happy paths
# --------------------------------------------------------------------------

@pytest.mark.parametrize("cap_id", [
    "01_runtime_core",
    "05_validation_evidence",
    "07_ltm_capture_consult",
])
def test_adoption_flow_single_cap_happy(cap_id: str, tmp_path: Path):
    rc, out, err = _run_drill(cap_id, tmp_path)
    assert rc == 0, err
    summary = _load_summary(tmp_path)
    assert summary["all_adopted"] is True
    caps = summary["capabilities"]
    assert len(caps) == 1
    assert caps[0]["cap_id"] == cap_id
    assert caps[0]["final_state"] == "adopted"
    assert caps[0]["status"] == "ok"
    # evidence_ref must point at a real file
    assert caps[0]["evidence_ref"] is not None
    assert Path(caps[0]["evidence_ref"]).is_file()


# --------------------------------------------------------------------------
# 4. 3-cap combined drill (the plan §10.2 / handoff §4 GAP #5 trio)
# --------------------------------------------------------------------------

def test_adoption_flow_three_caps_combined_happy(tmp_path: Path):
    rc, out, err = _run_drill(
        "01_runtime_core,05_validation_evidence,07_ltm_capture_consult",
        tmp_path,
    )
    assert rc == 0, err
    summary = _load_summary(tmp_path)
    assert summary["all_adopted"] is True
    cap_ids = [c["cap_id"] for c in summary["capabilities"]]
    assert cap_ids == [
        "01_runtime_core",
        "05_validation_evidence",
        "07_ltm_capture_consult",
    ]
    for c in summary["capabilities"]:
        assert c["final_state"] == "adopted"
        assert c["status"] == "ok"


# --------------------------------------------------------------------------
# 5. Unknown capability_id rejected (status=unknown_capability_id)
# --------------------------------------------------------------------------

def test_adoption_flow_unknown_cap_id_rejected(tmp_path: Path):
    rc, out, err = _run_drill("99_phantom_capability", tmp_path)
    # Drill exits VIOLATION because all_adopted=False.
    assert rc == 1, err
    summary = _load_summary(tmp_path)
    assert summary["all_adopted"] is False
    cap = summary["capabilities"][0]
    assert cap["cap_id"] == "99_phantom_capability"
    assert cap["status"] == "unknown_capability_id"
    assert cap["final_state"] == "unknown"
    assert "not in the 14 capability matrix" in (cap["notes"] or "")


# --------------------------------------------------------------------------
# 6. Summary shape sentinel
# --------------------------------------------------------------------------

def test_adoption_flow_summary_shape(tmp_path: Path):
    rc, _, err = _run_drill("01_runtime_core", tmp_path)
    assert rc == 0, err
    summary = _load_summary(tmp_path)
    # Top-level keys
    assert set(summary.keys()) >= {
        "capabilities", "all_adopted",
        "protocol_compatibility", "summary_path",
    }
    # Per-cap shape
    assert isinstance(summary["capabilities"], list)
    cap = summary["capabilities"][0]
    for key in ("cap_id", "final_state", "evidence_ref", "status", "notes"):
        assert key in cap, f"missing per-cap key: {key}"
    assert summary["protocol_compatibility"] in ("ok", "warn_or_violation")


# --------------------------------------------------------------------------
# 7. Summary file lands at <work>/adoption_drill_summary.json
# --------------------------------------------------------------------------

def test_adoption_flow_summary_file_location(tmp_path: Path):
    rc, _, err = _run_drill("05_validation_evidence", tmp_path)
    assert rc == 0, err
    summary_path = tmp_path / "adoption_drill_summary.json"
    assert summary_path.is_file()
    # The summary's self-recorded path matches the actual location.
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    assert summary["summary_path"] == str(summary_path)


# --------------------------------------------------------------------------
# 8. Empty --adoption-flow (commas / whitespace only) rejected
# --------------------------------------------------------------------------

def test_adoption_flow_empty_csv_rejected(tmp_path: Path):
    rc, out, err = _run_drill(" , ,  ,", tmp_path)
    # EXIT_USAGE == 2 (from harness exit map)
    assert rc == 2, err
    assert "at least one" in err
