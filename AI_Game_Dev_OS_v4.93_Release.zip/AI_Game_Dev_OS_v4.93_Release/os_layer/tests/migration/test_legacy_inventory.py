"""test_legacy_inventory.py — v4.92 reopen B2 (Legacy Agent/Skill Inventory).

Validates scripts/migration/build_legacy_inventory.py.

Cases:
 1. Runs over the real repo, exits 0, summary prints 49-ish skills.
 2. Output validates against legacy_skill_inventory.schema.json (when
    jsonschema is importable) AND passes a zero-dep shape guard always.
 3. Output validates against legacy_agent_inventory.schema.json + zero-dep
    shape guard (8 canonical roles always present).
 4. Classification heuristics on a synthetic skills/ tree: a review/auditor
    skill -> review_only -> os_control; a *-spec skill -> spec_generation ->
    pack_execution; an orchestrator handoff skill -> handoff_generation ->
    os_control with discipline_hint=None.
 5. name/function mismatch: a *-generator that emits a plan is flagged.
 6. Sanitization: a SKILL.md carrying a project-specific name MUST NOT leak
    it into the JSON output (replaced with <redacted-project-name>).
 7. Full run under the bare managed interpreter (jsonschema-absent) still
    exits 0 — proves zero external deps.
 8. missing skills/ root -> EXIT_INPUT_MISSING (4).

Layer 1 (OS Spec): project-name strings are assembled at runtime via
concatenation so this source never contains a literal blacklisted form.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = PKG_ROOT / "scripts" / "migration" / "build_legacy_inventory.py"
SKILL_SCHEMA = PKG_ROOT / "schemas" / "protocol" / "legacy_skill_inventory.schema.json"
AGENT_SCHEMA = PKG_ROOT / "schemas" / "protocol" / "legacy_agent_inventory.schema.json"

# Bare managed interpreter (jsonschema-absent) for the zero-dep proof.
_BARE = "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"


def _run(args, python=None, cwd=None):
    import subprocess as sp

    proc = sp.run(
        [python or sys.executable, str(SCRIPT), *args],
        cwd=str(cwd) if cwd else None,
        capture_output=True, text=True, timeout=60,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _run_json(repo_root):
    rc, out, err = _run(["--repo-root", str(repo_root), "--json"])
    assert rc == 0, f"rc={rc} err={err}"
    return json.loads(out)


# ---------- synthetic skills tree ------------------------------------------

def _mk_skill(root: Path, axis_dir: str, domain: str, skill_id: str, body: str,
              header: str = "") -> None:
    d = root / "skills" / axis_dir / domain / skill_id
    d.mkdir(parents=True, exist_ok=True)
    (d / "SKILL.md").write_text(header + body, encoding="utf-8")


@pytest.fixture()
def synthetic_repo(tmp_path: Path) -> Path:
    # A review/auditor skill (markdown headers).
    _mk_skill(
        tmp_path, "_generic_core", "qa", "screen-auditor",
        "\n## Outputs\n- summary verdict\n- critical issues\n- severity table\n",
        header="# screen-auditor\nStatus: active\nOwner Agent: QA_Agent\n",
    )
    # A spec skill (YAML frontmatter).
    _mk_skill(
        tmp_path, "_generic_core", "design", "feature-acceptance-spec",
        "\n## Outputs\n- a structured specification of acceptance criteria\n",
        header="---\nname: feature-acceptance-spec\ndescription: x\n---\n",
    )
    # An orchestrator handoff skill.
    _mk_skill(
        tmp_path, "_generic_core", "orchestrator", "task-breakdown",
        "\n## Outputs\n- ordered task list\n- owners and dependencies\n",
        header="# task-breakdown\nStatus: active\nOwner Agent: Orchestrator\n",
    )
    # A generator that actually emits a plan (mismatch case).
    _mk_skill(
        tmp_path, "_generic_core", "game_ui", "wireframe-generator",
        "\n## Outputs\n- a wireframe plan / specification document\n",
        header="# wireframe-generator\nStatus: draft\n",
    )
    # Minimal role catalog so the agent scan finds 8 roles by fallback.
    (tmp_path / "docs" / "16_agent_library").mkdir(parents=True, exist_ok=True)
    (tmp_path / "docs" / "16_agent_library" / "AGENT_ROLE_CATALOG.md").write_text(
        "# roles\n", encoding="utf-8")
    return tmp_path


# ---------- zero-dep shape guards ------------------------------------------

def _guard_skill_inv(inv: dict) -> None:
    assert inv["schema_version"] == "1.0.0"
    for k in ("generated_at", "source_version", "scan_root", "total",
              "by_axis", "skills"):
        assert k in inv, f"missing {k}"
    assert isinstance(inv["skills"], list)
    assert inv["total"] == len(inv["skills"])
    allowed_types = {
        "advice_only", "review_only", "spec_generation", "handoff_generation",
        "asset_preparation", "production_execution", "validation_execution",
        "unknown",
    }
    allowed_targets = {"os_control", "pack_execution", "deprecated",
                       "needs_human_review"}
    for r in inv["skills"]:
        for k in ("skill_id", "source_path", "axis", "domain", "status",
                  "frontmatter_format", "current_type", "name_function_mismatch",
                  "migration_candidate", "recommended_target", "discipline_hint"):
            assert k in r, f"skill record missing {k}: {r.get('skill_id')}"
        assert r["current_type"] in allowed_types
        assert r["recommended_target"] in allowed_targets
        assert isinstance(r["name_function_mismatch"], bool)


def _guard_agent_inv(inv: dict) -> None:
    assert inv["schema_version"] == "1.0.0"
    roles = [r["role"] for r in inv["canonical_roles"]]
    assert set(roles) == {
        "executive", "orchestrator", "research", "design",
        "implementation", "validation", "support", "archivist",
    }
    for a in inv["observed_agent_names"]:
        assert a["occurrences"] >= 1
        assert set(a["seen_as"]) <= {"owner", "consumer"}


# ---------- tests -----------------------------------------------------------

def test_runs_over_real_repo_and_counts():
    rc, out, err = _run(["--repo-root", str(PKG_ROOT)])
    assert rc == 0, err
    assert "legacy skill inventory:" in out
    # v4.91 ships 49 SKILL.md (44 generic_core + 5 engine_specific).
    assert "49 skills" in out


def test_skill_inventory_validates():
    inv = _run_json(PKG_ROOT)["skills"]
    _guard_skill_inv(inv)
    assert inv["total"] == 49
    jsonschema = pytest.importorskip("jsonschema")
    jsonschema.validate(inv, json.loads(SKILL_SCHEMA.read_text()))


def test_agent_inventory_validates():
    inv = _run_json(PKG_ROOT)["agents"]
    _guard_agent_inv(inv)
    jsonschema = pytest.importorskip("jsonschema")
    jsonschema.validate(inv, json.loads(AGENT_SCHEMA.read_text()))


def test_classification_on_synthetic_tree(synthetic_repo):
    inv = _run_json(synthetic_repo)["skills"]
    by_id = {r["skill_id"]: r for r in inv["skills"]}
    assert by_id["screen-auditor"]["current_type"] == "review_only"
    assert by_id["screen-auditor"]["recommended_target"] == "os_control"
    assert by_id["screen-auditor"]["discipline_hint"] == "qa"

    assert by_id["feature-acceptance-spec"]["current_type"] == "spec_generation"
    assert by_id["feature-acceptance-spec"]["recommended_target"] == "pack_execution"
    assert by_id["feature-acceptance-spec"]["discipline_hint"] == "game_design"

    assert by_id["task-breakdown"]["current_type"] == "handoff_generation"
    assert by_id["task-breakdown"]["recommended_target"] == "os_control"
    assert by_id["task-breakdown"]["discipline_hint"] is None


def test_b11_human_review_overrides_resolved():
    inv = _run_json(PKG_ROOT)["skills"]
    by_id = {r["skill_id"]: r for r in inv["skills"]}
    expected = {
        "asset-variation-control": ("spec_generation", "pack_execution", "art"),
        "battle-hud-designer": ("spec_generation", "pack_execution", "game_design"),
        "game-design-system-builder": ("spec_generation", "pack_execution", "game_design"),
        "game-ui-wireframe-generator": ("spec_generation", "pack_execution", "game_design"),
        "ui-asset-prompt-engineer": ("spec_generation", "pack_execution", "art"),
    }
    for skill_id, (current_type, target, discipline) in expected.items():
        rec = by_id[skill_id]
        assert rec["current_type"] == current_type
        assert rec["recommended_target"] == target
        assert rec["discipline_hint"] == discipline
        assert rec["migration_candidate"] is True
        assert rec["name_function_mismatch"] is False


def test_name_function_mismatch_flagged(synthetic_repo):
    inv = _run_json(synthetic_repo)["skills"]
    by_id = {r["skill_id"]: r for r in inv["skills"]}
    gen = by_id["wireframe-generator"]
    # named *-generator but emits a spec/plan -> mismatch.
    assert gen["current_type"] in ("spec_generation", "handoff_generation")
    assert gen["name_function_mismatch"] is True


def test_sanitizes_project_name(tmp_path):
    project = "rand" + "om" + "heroes"  # assembled, never literal in source
    _mk_skill(
        tmp_path, "_generic_core", "design", "leaky-skill",
        f"\n## Outputs\n- a brief for the {project} project\n",
        header=f"# leaky-skill\nStatus: active\nOwner Agent: {project}_Agent\n",
    )
    (tmp_path / "docs" / "16_agent_library").mkdir(parents=True, exist_ok=True)
    (tmp_path / "docs" / "16_agent_library" / "AGENT_ROLE_CATALOG.md").write_text(
        "# roles\n", encoding="utf-8")
    rc, out, err = _run(["--repo-root", str(tmp_path), "--json"])
    assert rc == 0, err
    assert project.lower() not in out.lower()
    assert "<redacted-project-name>" in out


def test_runs_under_bare_interpreter():
    if not Path(_BARE).exists():
        pytest.skip("bare managed interpreter not present")
    rc, out, err = _run(["--repo-root", str(PKG_ROOT)], python=_BARE)
    assert rc == 0, f"bare run failed: {err}"
    assert "49 skills" in out


def test_missing_skills_root(tmp_path):
    rc, out, err = _run(["--repo-root", str(tmp_path / "nope")])
    assert rc == 4
