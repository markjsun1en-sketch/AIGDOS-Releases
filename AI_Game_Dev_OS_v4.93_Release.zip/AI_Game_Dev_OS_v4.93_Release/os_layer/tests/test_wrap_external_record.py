"""Tests for workbuddy_collector.wrap_external_record (v4.89 P0-A A1)."""
from __future__ import annotations

import pytest

from runtime.observability.runtime_event_collectors.workbuddy_collector import (
    AUDIT_STATUS_PENDING,
    AUDIT_STATUS_FAILED,
    _ALLOWED_SOURCE_LAYERS,
    wrap_external_record,
)


def test_happy_path_tapd(tapd_normalize_record):
    env = wrap_external_record(
        tapd_normalize_record,
        source_layer="tapd",
        runtime_profile="workbuddy_private",
    )
    required = {
        "event_id", "event_type", "timestamp", "actor", "runtime_profile",
        "result", "source_layer", "audit_status", "details",
    }
    assert required.issubset(env), sorted(required - env.keys())
    assert len(env["event_id"]) == 36  # uuid4 str length
    assert env["source_layer"] == "tapd"
    assert env["audit_status"] == AUDIT_STATUS_PENDING
    assert env["actor"] == "main_session"  # default
    assert env["timestamp"].endswith("Z")
    assert env["details"] == tapd_normalize_record


def test_event_type_falls_back_through_record_keys():
    # event -> event_type -> "unknown"
    assert wrap_external_record(
        {"event": "story_updated"}, source_layer="tapd",
        runtime_profile="workbuddy_private",
    )["event_type"] == "story_updated"
    assert wrap_external_record(
        {"event_type": "merge_applied"}, source_layer="git",
        runtime_profile="workbuddy_private",
    )["event_type"] == "merge_applied"
    assert wrap_external_record(
        {}, source_layer="workbuddy", runtime_profile="workbuddy_private",
    )["event_type"] == "unknown"


def test_explicit_event_type_and_result_override():
    env = wrap_external_record(
        {"event": "story_updated", "result": "ok"},
        source_layer="tapd",
        runtime_profile="workbuddy_private",
        event_type="external.tapd.verify",
        result="warn",
    )
    assert env["event_type"] == "external.tapd.verify"
    assert env["result"] == "warn"


def test_raises_type_error_on_non_dict_record():
    with pytest.raises(TypeError):
        wrap_external_record(
            "not-a-dict", source_layer="tapd",
            runtime_profile="workbuddy_private",
        )


def test_raises_value_error_on_illegal_source_layer():
    with pytest.raises(ValueError):
        wrap_external_record(
            {}, source_layer="s3", runtime_profile="workbuddy_private",
        )
    # all allowed values accepted
    for layer in _ALLOWED_SOURCE_LAYERS:
        wrap_external_record(
            {}, source_layer=layer, runtime_profile="workbuddy_private",
        )  # does not raise


def test_raises_value_error_on_empty_runtime_profile():
    with pytest.raises(ValueError):
        wrap_external_record({}, source_layer="tapd", runtime_profile="")


def test_audit_status_and_actor_overridable():
    env = wrap_external_record(
        {"event": "x"},
        source_layer="tapd",
        runtime_profile="workbuddy_private",
        actor="trial_driver",
        audit_status=AUDIT_STATUS_FAILED,
    )
    assert env["actor"] == "trial_driver"
    assert env["audit_status"] == AUDIT_STATUS_FAILED
