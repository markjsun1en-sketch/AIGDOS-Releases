"""test_state_machines_index.py — v4.90 Batch 14 Step 14.6.4.

Asserts STATE_MACHINES_INDEX.md is in sync with the alignment guard's
STATE_MACHINES list.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import sys
from pathlib import Path

V4_90_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(V4_90_ROOT))

from scripts.governance.check_state_machine_alignment import (  # noqa: E402
    STATE_MACHINES,
)

INDEX_PATH = V4_90_ROOT / "docs" / "STATE_MACHINES_INDEX.md"


def test_state_machines_index_lists_all_3_machines():
    """STATE_MACHINES_INDEX.md must reference every machine, doc, and
    schema declared in STATE_MACHINES (alignment guard's config), so
    the catalog cannot drift from the script."""
    assert INDEX_PATH.exists(), f"missing index: {INDEX_PATH}"
    text = INDEX_PATH.read_text(encoding="utf-8")
    for sm in STATE_MACHINES:
        assert sm["name"] in text, (
            f"State machine {sm['name']!r} not listed in "
            f"STATE_MACHINES_INDEX.md"
        )
        # Doc path is recorded relative to v4.90 root in STATE_MACHINES;
        # the index uses doc-relative links, so check the basename plus
        # one level of parent dir to be robust against link style.
        doc_tail = "/".join(Path(sm["doc"]).parts[-2:])
        assert doc_tail in text, (
            f"Doc reference {doc_tail!r} for {sm['name']} missing "
            f"from STATE_MACHINES_INDEX.md"
        )
        schema_tail = "/".join(Path(sm["schema"]).parts[-2:])
        assert schema_tail in text, (
            f"Schema reference {schema_tail!r} for {sm['name']} "
            f"missing from STATE_MACHINES_INDEX.md"
        )
