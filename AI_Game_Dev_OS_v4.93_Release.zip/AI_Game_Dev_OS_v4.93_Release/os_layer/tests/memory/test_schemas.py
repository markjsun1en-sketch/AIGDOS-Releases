"""test_schemas.py — v4.91 M-E B8 c2.

Pin the three memory sync schemas (project_summary + preflight_summary
+ uplink_record) at their v1.0.0 contract shape: closed enums,
const-locked schema_version, ID patterns, source_layer 'L2' lock,
human-confirmation gate (allOf) for uplink_level 2/3.

Layer 1 (OS Spec). No project names; fixtures use opaque
``ps_aaaaaaaa`` / ``pfs_bbbbbbbb`` / ``upl_cccccccc`` placeholders.
"""
from __future__ import annotations

import json
from pathlib import Path

import jsonschema
import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = REPO_ROOT / "schemas" / "memory"


def _load(name: str) -> dict:
    return json.loads((SCHEMA_DIR / name).read_text(encoding="utf-8"))


@pytest.fixture(scope="module")
def project_summary_schema() -> dict:
    return _load("project_summary.schema.json")


@pytest.fixture(scope="module")
def preflight_summary_schema() -> dict:
    return _load("preflight_summary.schema.json")


@pytest.fixture(scope="module")
def uplink_record_schema() -> dict:
    return _load("uplink_record.schema.json")


# ---------------------------------------------------------------------------
# 1. All three schemas pass jsonschema Draft7 self-validation.
# ---------------------------------------------------------------------------


def test_project_summary_schema_self_valid(project_summary_schema):
    jsonschema.Draft7Validator.check_schema(project_summary_schema)


def test_preflight_summary_schema_self_valid(preflight_summary_schema):
    jsonschema.Draft7Validator.check_schema(preflight_summary_schema)


def test_uplink_record_schema_self_valid(uplink_record_schema):
    jsonschema.Draft7Validator.check_schema(uplink_record_schema)


# ---------------------------------------------------------------------------
# 2. schema_version is const-locked literal "1.0.0" on every schema.
# ---------------------------------------------------------------------------


def test_schema_version_const_locked(
    project_summary_schema,
    preflight_summary_schema,
    uplink_record_schema,
):
    for s in (project_summary_schema, preflight_summary_schema, uplink_record_schema):
        sv = s["properties"]["schema_version"]
        assert sv.get("const") == "1.0.0", f"schema_version must be const '1.0.0', got {sv!r}"


# ---------------------------------------------------------------------------
# 3. source_layer is const-locked literal "L2" on every schema.
# Charter #5: Core does not bind to project narrative — projection
# direction is locked at the schema layer.
# ---------------------------------------------------------------------------


def test_source_layer_const_locked_L2(
    project_summary_schema,
    preflight_summary_schema,
    uplink_record_schema,
):
    for s in (project_summary_schema, preflight_summary_schema, uplink_record_schema):
        sl = s["properties"]["source_layer"]
        assert sl.get("const") == "L2", f"source_layer must be const 'L2', got {sl!r}"


# ---------------------------------------------------------------------------
# 4. project_summary minimal valid envelope round-trips.
# ---------------------------------------------------------------------------


def _minimal_project_summary() -> dict:
    return {
        "schema_version": "1.0.0",
        "summary_id": "ps_aaaaaaaa",
        "project_id": "host-a",
        "sprint_id": "sprint-1",
        "outcome": "PASS",
        "captured_at": "2026-05-26T10:00:00Z",
        "source_layer": "L2",
        "uplink_level": 1,
        "audit_status": "draft",
        "amends": None,
    }


def test_project_summary_minimal_valid(project_summary_schema):
    jsonschema.validate(_minimal_project_summary(), project_summary_schema, cls=jsonschema.Draft7Validator)


def test_project_summary_outcome_5_enum(project_summary_schema):
    enum = project_summary_schema["properties"]["outcome"]["enum"]
    assert sorted(enum) == sorted(
        ["PASS", "PASS_WITH_NOTE", "FAIL", "DEFERRED", "CANCELLED"]
    )


def test_project_summary_uplink_level_closed_3_tier(project_summary_schema):
    p = project_summary_schema["properties"]["uplink_level"]
    assert p["minimum"] == 1 and p["maximum"] == 3


def test_project_summary_audit_status_3_enum(project_summary_schema):
    enum = project_summary_schema["properties"]["audit_status"]["enum"]
    assert sorted(enum) == sorted(["draft", "recorded", "withdrawn"])


def test_project_summary_amends_required_iff_withdrawn(project_summary_schema):
    """Charter anti-pattern #7 / amend lifecycle structural enforcement."""
    env = _minimal_project_summary()
    env["audit_status"] = "withdrawn"
    env["amends"] = None  # invalid: must be ps_XXXXXXXX
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(env, project_summary_schema, cls=jsonschema.Draft7Validator)
    env["amends"] = "ps_bbbbbbbb"
    jsonschema.validate(env, project_summary_schema, cls=jsonschema.Draft7Validator)


# ---------------------------------------------------------------------------
# 5. preflight_summary minimal valid envelope round-trips; outcome
# is the case-mirror 3-enum (no withdrawn — that lives on
# audit_status).
# ---------------------------------------------------------------------------


def _minimal_preflight_summary() -> dict:
    return {
        "schema_version": "1.0.0",
        "summary_id": "pfs_aaaaaaaa",
        "case_id": "pf_case_demo",
        "project_id": "host-a",
        "outcome": "approved",
        "captured_at": "2026-05-26T10:00:00Z",
        "source_layer": "L2",
        "uplink_level": 1,
        "audit_status": "draft",
        "preflight_case_ref": "ltm/preflight/cases/pf_case_demo.json",
        "amends": None,
    }


def test_preflight_summary_minimal_valid(preflight_summary_schema):
    jsonschema.validate(_minimal_preflight_summary(), preflight_summary_schema, cls=jsonschema.Draft7Validator)


def test_preflight_summary_outcome_3_enum_no_withdrawn(preflight_summary_schema):
    enum = preflight_summary_schema["properties"]["outcome"]["enum"]
    assert sorted(enum) == sorted(["approved", "rejected", "deferred"])
    assert "withdrawn" not in enum, "withdrawn lives on audit_status, not outcome"


def test_preflight_summary_preflight_case_ref_required(preflight_summary_schema):
    required = preflight_summary_schema["required"]
    assert "preflight_case_ref" in required


# ---------------------------------------------------------------------------
# 6. uplink_record human-confirmation gate (allOf) — Charter #7.
# Level 1: confirmed_by + confirmed_at optional.
# Level 2: confirmed_by + confirmed_at required.
# Level 3: confirmed_by + confirmed_at + rationale required.
# ---------------------------------------------------------------------------


def _minimal_uplink_record(level: int) -> dict:
    rec = {
        "schema_version": "1.0.0",
        "uplink_id": "upl_aaaaaaaa",
        "uplink_level": level,
        "captured_at": "2026-05-26T10:00:00Z",
        "source_layer": "L2",
        "audit_status": "recorded",
        "summary_refs": [
            {"kind": "project_summary", "ref": "summaries/ps_bbbbbbbb.json"}
        ],
        "amends": None,
    }
    if level >= 2:
        rec["confirmed_by"] = "human-reviewer"
        rec["confirmed_at"] = "2026-05-26T10:05:00Z"
    if level == 3:
        rec["rationale"] = "Cross-project memory uplink; impact reviewed."
    return rec


def test_uplink_level_1_minimal_valid(uplink_record_schema):
    jsonschema.validate(_minimal_uplink_record(1), uplink_record_schema, cls=jsonschema.Draft7Validator)


def test_uplink_level_2_requires_human_confirmation(uplink_record_schema):
    rec = _minimal_uplink_record(2)
    jsonschema.validate(rec, uplink_record_schema, cls=jsonschema.Draft7Validator)
    # remove human confirmation -> must fail
    rec_no_conf = dict(rec)
    rec_no_conf["confirmed_by"] = None
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(rec_no_conf, uplink_record_schema, cls=jsonschema.Draft7Validator)


def test_uplink_level_3_requires_rationale(uplink_record_schema):
    rec = _minimal_uplink_record(3)
    jsonschema.validate(rec, uplink_record_schema, cls=jsonschema.Draft7Validator)
    # remove rationale -> must fail
    rec_no_rat = dict(rec)
    rec_no_rat["rationale"] = None
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(rec_no_rat, uplink_record_schema, cls=jsonschema.Draft7Validator)
    # also: empty rationale fails minLength=1
    rec_empty = dict(rec)
    rec_empty["rationale"] = ""
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(rec_empty, uplink_record_schema, cls=jsonschema.Draft7Validator)


def test_uplink_level_closed_3_tier(uplink_record_schema):
    p = uplink_record_schema["properties"]["uplink_level"]
    assert p["minimum"] == 1 and p["maximum"] == 3


def test_uplink_audit_status_3_enum(uplink_record_schema):
    enum = uplink_record_schema["properties"]["audit_status"]["enum"]
    assert sorted(enum) == sorted(["recorded", "withdrawn", "superseded"])


def test_uplink_summary_refs_kind_2_enum(uplink_record_schema):
    refs = uplink_record_schema["properties"]["summary_refs"]
    item = refs["items"]
    enum = item["properties"]["kind"]["enum"]
    assert sorted(enum) == sorted(["project_summary", "preflight_summary"])


# ---------------------------------------------------------------------------
# 7. additionalProperties refusal — every top-level schema rejects
# unknown fields. Charter #4 (extend, don't replace) + governance
# precedent on every existing v4.91 schema.
# ---------------------------------------------------------------------------


def test_additional_properties_false(
    project_summary_schema,
    preflight_summary_schema,
    uplink_record_schema,
):
    for s in (project_summary_schema, preflight_summary_schema, uplink_record_schema):
        assert s.get("additionalProperties") is False
