"""test_generate_preflight_summary.py — v4.91 M-E B8 c2.

Lifecycle tests for scripts/memory/generate_preflight_summary.py.
The script reads a finalized preflight_case (and optional metric)
and emits a preflight_summary JSON. Read-only mirroring; no
case mutation.

Layer 1. Opaque case_id / project_id placeholders.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

import jsonschema
import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = REPO_ROOT / "scripts" / "memory" / "generate_preflight_summary.py"
SCHEMA = REPO_ROOT / "schemas" / "memory" / "preflight_summary.schema.json"


def _run(args: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True,
        text=True,
        cwd=str(REPO_ROOT),
        check=False,
    )


def _write_case(path: Path, *, outcome: str = "approved", decided_by: str = "epx") -> Path:
    case = {
        "schema_version": "1.0.0",
        "case_id": "pf_case_demo_b8_t1",
        "trigger": "major_version_bump",
        "subject": {
            "kind": "core_update_plan",
            "ref": "hub/update_plans/plan_demo.yaml",
        },
        "consulted_roles": [decided_by, "matrix_owner"],
        "consensus": {
            "outcome": outcome,
            "decided_by": decided_by,
            "rationale": "All matrix invariants verified.",
        },
        "generated_at": "2026-05-26T10:00:00Z",
    }
    path.write_text(json.dumps(case), encoding="utf-8")
    return path


def _write_metric(path: Path, *, case_path: str = "ltm/preflight/cases/pf_case_demo_b8_t1.json") -> Path:
    metric = {
        "schema_version": "1.0.0",
        "metric_id": "pf_metric_demo_b8_t1",
        "case_ref": case_path,
        "captured_at": "2026-05-26T10:01:00Z",
        "elapsed_seconds": 42.5,
        "consulted_role_count": 2,
    }
    path.write_text(json.dumps(metric), encoding="utf-8")
    return path


def test_lifecycle_case_only_writes_draft_summary(tmp_path):
    case = _write_case(tmp_path / "case.json")
    out_dir = tmp_path / "out"
    res = _run([
        "--case", str(case),
        "--project-id", "host-a",
        "--out-dir", str(out_dir),
        "--captured-at", "2026-05-26T10:05:00Z",
    ])
    assert res.returncode == 0, res.stderr
    summary_id = res.stdout.strip()
    assert re.fullmatch(r"pfs_[0-9a-f]{8}", summary_id), summary_id
    summary = json.loads((out_dir / f"{summary_id}.json").read_text(encoding="utf-8"))
    assert summary["audit_status"] == "draft"
    assert summary["outcome"] == "approved"
    assert summary["decided_by"] == "epx"
    assert summary["consulted_role_count"] is None
    assert summary["elapsed_seconds"] is None
    schema = json.loads(SCHEMA.read_text(encoding="utf-8"))
    jsonschema.validate(summary, schema, cls=jsonschema.Draft7Validator)


def test_lifecycle_with_metric_mirrors_count_and_elapsed(tmp_path):
    case = _write_case(tmp_path / "case.json")
    metric = _write_metric(tmp_path / "metric.json")
    out_dir = tmp_path / "out"
    res = _run([
        "--case", str(case),
        "--metric", str(metric),
        "--project-id", "host-a",
        "--out-dir", str(out_dir),
        "--captured-at", "2026-05-26T10:05:00Z",
    ])
    assert res.returncode == 0, res.stderr
    summary_id = res.stdout.strip()
    summary = json.loads((out_dir / f"{summary_id}.json").read_text(encoding="utf-8"))
    assert summary["consulted_role_count"] == 2
    assert summary["elapsed_seconds"] == 42.5


def test_lifecycle_recorded_flag_promotes_audit_status(tmp_path):
    case = _write_case(tmp_path / "case.json")
    out_dir = tmp_path / "out"
    res = _run([
        "--case", str(case),
        "--project-id", "host-a",
        "--out-dir", str(out_dir),
        "--recorded",
        "--captured-at", "2026-05-26T10:05:00Z",
    ])
    assert res.returncode == 0, res.stderr
    summary_id = res.stdout.strip()
    summary = json.loads((out_dir / f"{summary_id}.json").read_text(encoding="utf-8"))
    assert summary["audit_status"] == "recorded"


def test_invalid_project_id_rejected(tmp_path):
    case = _write_case(tmp_path / "case.json")
    res = _run([
        "--case", str(case),
        "--project-id", "Bad Project",
        "--out-dir", str(tmp_path),
        "--captured-at", "2026-05-26T10:05:00Z",
    ])
    assert res.returncode == 3


def test_missing_case_file_returns_4(tmp_path):
    res = _run([
        "--case", str(tmp_path / "no.json"),
        "--project-id", "host-a",
        "--out-dir", str(tmp_path),
        "--captured-at", "2026-05-26T10:05:00Z",
    ])
    assert res.returncode == 4


def test_outcome_is_read_only_mirror(tmp_path):
    """Charter #12 — script does NOT synthesise outcome; it mirrors."""
    case = _write_case(tmp_path / "case.json", outcome="rejected")
    out_dir = tmp_path / "out"
    res = _run([
        "--case", str(case),
        "--project-id", "host-a",
        "--out-dir", str(out_dir),
        "--captured-at", "2026-05-26T10:05:00Z",
    ])
    assert res.returncode == 0, res.stderr
    summary_id = res.stdout.strip()
    summary = json.loads((out_dir / f"{summary_id}.json").read_text(encoding="utf-8"))
    assert summary["outcome"] == "rejected"
