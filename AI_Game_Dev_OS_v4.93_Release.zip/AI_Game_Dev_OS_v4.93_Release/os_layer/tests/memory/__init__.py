"""tests.memory — v4.91 M-E B8 c2.

Layer 1 test fixtures for the memory sync / periodic uplink contract
surface. No project literals; opaque project_id / sprint_id /
case_id placeholders only.
"""
