"""test_sprint_close_hook.py — v4.91 M-E B8 c2.

End-to-end lifecycle tests for scripts/memory/sprint_close_hook.py.
The hook is a Layer 1 projection layer: input → schema-validated
output. These tests exercise the lifecycle (success / draft vs
recorded / schema-fail surfaces) without booting any LTM engine.

Layer 1. Opaque project / sprint placeholders.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

import jsonschema
import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
HOOK = REPO_ROOT / "scripts" / "memory" / "sprint_close_hook.py"
SCHEMA = REPO_ROOT / "schemas" / "memory" / "project_summary.schema.json"


def _run(args: list[str], *, env_input: str | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, str(HOOK), *args],
        input=env_input,
        capture_output=True,
        text=True,
        cwd=str(REPO_ROOT),
        check=False,
    )


def _write(path: Path, payload: dict) -> Path:
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def _minimal_input() -> dict:
    return {
        "sprint_id": "sprint-7",
        "project_id": "host-a",
        "outcome": "PASS",
        "captured_at": "2026-05-26T10:00:00Z",
    }


def test_lifecycle_minimal_input_writes_draft_summary(tmp_path):
    inp = _write(tmp_path / "close.json", _minimal_input())
    out_dir = tmp_path / "summaries"
    res = _run(["--input", str(inp), "--out-dir", str(out_dir)])
    assert res.returncode == 0, res.stderr
    summary_id = res.stdout.strip()
    assert re.fullmatch(r"ps_[0-9a-f]{8}", summary_id), summary_id
    out_file = out_dir / f"{summary_id}.json"
    assert out_file.exists()
    summary = json.loads(out_file.read_text(encoding="utf-8"))
    assert summary["audit_status"] == "draft"
    assert summary["uplink_level"] == 1
    assert summary["source_layer"] == "L2"
    schema = json.loads(SCHEMA.read_text(encoding="utf-8"))
    jsonschema.validate(summary, schema, cls=jsonschema.Draft7Validator)


def test_lifecycle_recorded_flag_promotes_audit_status(tmp_path):
    inp = _write(tmp_path / "close.json", _minimal_input())
    out_dir = tmp_path / "summaries"
    res = _run(["--input", str(inp), "--out-dir", str(out_dir), "--recorded"])
    assert res.returncode == 0, res.stderr
    summary_id = res.stdout.strip()
    summary = json.loads((out_dir / f"{summary_id}.json").read_text(encoding="utf-8"))
    assert summary["audit_status"] == "recorded"


def test_lifecycle_full_input_round_trips(tmp_path):
    payload = _minimal_input()
    payload.update({
        "uplink_level": 2,
        "headline": "Sprint 7 closed cleanly.",
        "lessons": ["respect the manifest sync canonical path"],
        "evidence_index": ["abc1234", "docs/sprint7.md"],
        "closure_report_ref": "docs/sprint7.md",
        "preflight_summary_ref": "summaries/pfs_aaaaaaaa.json",
    })
    inp = _write(tmp_path / "close.json", payload)
    out_dir = tmp_path / "summaries"
    res = _run(["--input", str(inp), "--out-dir", str(out_dir)])
    assert res.returncode == 0, res.stderr
    summary_id = res.stdout.strip()
    summary = json.loads((out_dir / f"{summary_id}.json").read_text(encoding="utf-8"))
    assert summary["uplink_level"] == 2
    assert summary["headline"] == "Sprint 7 closed cleanly."
    assert summary["lessons"] == ["respect the manifest sync canonical path"]
    assert summary["evidence_index"] == ["abc1234", "docs/sprint7.md"]
    assert summary["closure_report_ref"] == "docs/sprint7.md"
    assert summary["preflight_summary_ref"] == "summaries/pfs_aaaaaaaa.json"


def test_input_invalid_outcome_rejected(tmp_path):
    payload = _minimal_input()
    payload["outcome"] = "MAYBE"
    inp = _write(tmp_path / "close.json", payload)
    res = _run(["--input", str(inp), "--out-dir", str(tmp_path)])
    assert res.returncode == 3
    assert "outcome" in res.stderr.lower()


def test_input_invalid_project_id_rejected(tmp_path):
    payload = _minimal_input()
    payload["project_id"] = "Bad Project Id"  # uppercase + spaces
    inp = _write(tmp_path / "close.json", payload)
    res = _run(["--input", str(inp), "--out-dir", str(tmp_path)])
    assert res.returncode == 3


def test_input_missing_file_returns_4(tmp_path):
    res = _run(["--input", str(tmp_path / "no.json"), "--out-dir", str(tmp_path)])
    assert res.returncode == 4


def test_no_apply_or_force_flag_in_argparse():
    """Charter #7 — the hook must not grow an --apply / --force /
    --auto-confirm flag. Compile-time guard at the help text level.
    """
    res = _run(["--help"])
    assert res.returncode == 0
    help_text = res.stdout.lower()
    for forbidden in ("--apply", "--force", "--auto-confirm", "--execute"):
        assert forbidden not in help_text, f"forbidden flag {forbidden} appeared in --help"
