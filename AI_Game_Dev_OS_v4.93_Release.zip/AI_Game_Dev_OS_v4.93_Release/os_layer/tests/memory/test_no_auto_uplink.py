"""test_no_auto_uplink.py — v4.91 M-E B8 c2.

Compile-time guards for inv_010_no_auto_level_2_3_promotion. These
tests catch any future drift toward an auto-confirm / auto-promote
posture in the memory sync toolchain (Charter anti-pattern #6 +
#7 + #11).

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
MEMORY_DIR = REPO_ROOT / "scripts" / "memory"
UPLINK_SCHEMA = REPO_ROOT / "schemas" / "memory" / "uplink_record.schema.json"


# ---------------------------------------------------------------------------
# 1. No script under scripts/memory/ defines an --apply / --execute /
# --auto-confirm / --force / --auto-apply / --skip-confirm /
# --bypass / --allow-extra argparse flag. Charter anti-pattern #7.
# ---------------------------------------------------------------------------


_FORBIDDEN_FLAG_RE = re.compile(
    r'add_argument\(\s*"\s*-{1,2}(apply|execute|auto[\-_]apply|auto[\-_]confirm|force|skip[\-_]confirm|bypass|allow[\-_]extra)\b',
    re.IGNORECASE,
)


def test_no_forbidden_flag_in_memory_scripts():
    found_violations: list[str] = []
    for py in MEMORY_DIR.glob("*.py"):
        if py.name == "__init__.py":
            continue
        text = py.read_text(encoding="utf-8")
        for match in _FORBIDDEN_FLAG_RE.finditer(text):
            found_violations.append(f"{py.name}: {match.group(0)}")
    assert not found_violations, (
        "scripts/memory/ may NOT introduce escape-hatch flags. "
        f"Violations: {found_violations}"
    )


# ---------------------------------------------------------------------------
# 2. uplink_record.schema.json keeps confirmed_by + confirmed_at
# REQUIRED iff uplink_level >= 2 (allOf gate). Catches anyone
# softening the human-confirmation contract.
# ---------------------------------------------------------------------------


def test_uplink_level_2_requires_human_confirmation_in_schema():
    schema = json.loads(UPLINK_SCHEMA.read_text(encoding="utf-8"))
    branches = schema.get("allOf", [])
    found_level_2 = False
    for branch in branches:
        cond = branch.get("if", {}).get("properties", {}).get("uplink_level", {})
        if cond.get("const") == 2:
            req = branch.get("then", {}).get("required", [])
            assert "confirmed_by" in req
            assert "confirmed_at" in req
            found_level_2 = True
    assert found_level_2, "allOf branch for uplink_level==2 missing"


def test_uplink_level_3_requires_rationale_in_schema():
    schema = json.loads(UPLINK_SCHEMA.read_text(encoding="utf-8"))
    branches = schema.get("allOf", [])
    found_level_3 = False
    for branch in branches:
        cond = branch.get("if", {}).get("properties", {}).get("uplink_level", {})
        if cond.get("const") == 3:
            req = branch.get("then", {}).get("required", [])
            assert "confirmed_by" in req
            assert "confirmed_at" in req
            assert "rationale" in req
            found_level_3 = True
    assert found_level_3, "allOf branch for uplink_level==3 missing"


# ---------------------------------------------------------------------------
# 3. uplink_level closed at 1..3. Catches any drift to a 0 / 4 tier.
# ---------------------------------------------------------------------------


def test_uplink_level_closed_3_tier():
    schema = json.loads(UPLINK_SCHEMA.read_text(encoding="utf-8"))
    p = schema["properties"]["uplink_level"]
    assert p["minimum"] == 1
    assert p["maximum"] == 3


# ---------------------------------------------------------------------------
# 4. summary_refs[].kind closed 2-enum. Catches accidental
# expansion to 'failure_fix_memory' or other LTM domains.
# ---------------------------------------------------------------------------


def test_uplink_summary_refs_kind_closed_2_enum():
    schema = json.loads(UPLINK_SCHEMA.read_text(encoding="utf-8"))
    enum = schema["properties"]["summary_refs"]["items"]["properties"]["kind"]["enum"]
    assert sorted(enum) == sorted(["project_summary", "preflight_summary"])


# ---------------------------------------------------------------------------
# 5. No script under scripts/memory/ imports retrieval_policy /
# promotion_policy modules — Charter anti-pattern #6 (no auto-promote
# from memory sync into retrieval-policy boost / threshold tunables).
# ---------------------------------------------------------------------------


_FORBIDDEN_IMPORT_RE = re.compile(
    r"^\s*(from|import)\s+.*?(retrieval_policy|promotion_policy|promote_memory_candidate|reject_memory_candidate)\b",
    re.MULTILINE,
)


def test_memory_scripts_do_not_import_policy_engines():
    found_violations: list[str] = []
    for py in MEMORY_DIR.glob("*.py"):
        text = py.read_text(encoding="utf-8")
        for match in _FORBIDDEN_IMPORT_RE.finditer(text):
            found_violations.append(f"{py.name}: {match.group(0).strip()}")
    assert not found_violations, (
        "scripts/memory/ scripts must NOT import retrieval / promotion "
        f"policy engines (Charter #6 — no auto-promote). Violations: {found_violations}"
    )
