"""Tests for verify_beta_sprint_exit.check_init_integrity cursor
schema cross-check (v4.89 Phase 2 Stage 2 / M6.5 · updated Phase 4 / M7.3.3).

Contract surface
----------------
The cross-check fires when ``runtime_state.profile == "cursor"``:

    coordination_model must equal "parallel_agents"
    writeback_owner    must equal "reviewed_apply_owner"

Two severities, different semantics:

- **ERROR** (M7.3.3 lift) — field absent from runtime_state.  Post-M7.3.2
  ``_stub_init`` is contractually required to write these fields from the
  authoritative profile JSON, so an absent field is a contract violation.
- **WARN** (M6.5 semantics, preserved) — field present but value
  contradicts the cursor ground truth.  Schema drift, non-fatal.

Symmetric structure with the M6.4 codex cross-check; both per-profile
blocks live in the same schema_driven_init_check and are mutually
exclusive because a runtime_state declares only one profile at a time.

See ltm/failures/2026-05-05_cursor_silent_pass_blindness.md and
docs/06_runtime_profiles/PHASE_4_LIFT_GATE_AUDIT.md §1 §4.
"""
from __future__ import annotations

import json
from pathlib import Path

from verify_beta_sprint_exit import VerifyContext, check_init_integrity


def _make_state(workspace: Path, **fields) -> Path:
    """Materialise a runtime_state.json under the canonical location."""
    rs_dir = workspace / "runtime" / "state"
    rs_dir.mkdir(parents=True, exist_ok=True)
    rs = rs_dir / "runtime_state.json"
    base = {
        "project_id": "rh_sprint_sim_01",
        "runtime_profile": "workbuddy_private",
        "profile": "workbuddy_private",
        "initialized_at": "2026-05-02T12:00:00Z",
    }
    base.update(fields)
    rs.write_text(json.dumps(base, indent=2) + "\n", encoding="utf-8")
    return rs


def _ctx(workspace: Path, runtime_state: Path) -> VerifyContext:
    return VerifyContext(
        workspace=workspace,
        audit_log=workspace / "runtime" / "logs" / "mcp_audit.jsonl",
        runtime_state=runtime_state,
        sprint_close_checklist=(
            workspace / "runtime" / "state" / "sprint_close_checklist.md"
        ),
    )


def _cursor_drift_findings(findings: list[dict]) -> list[dict]:
    """Filter to M6.5 cursor schema drift findings (WARN — wrong value)."""
    return [
        f for f in findings
        if f.get("category") == "init"
        and f.get("severity") == "WARN"
        and f.get("contract_field") in {"coordination_model", "writeback_owner"}
        and "profile=cursor" in f.get("message", "")
    ]


def _cursor_missing_findings(findings: list[dict]) -> list[dict]:
    """Filter to M7.3.3 cursor missing-contract-field ERRORs."""
    return [
        f for f in findings
        if f.get("category") == "init"
        and f.get("severity") == "ERROR"
        and f.get("contract_field") in {"coordination_model", "writeback_owner"}
        and "profile=cursor" in f.get("message", "")
        and "missing contract field" in f.get("message", "")
    ]


# C1 — P1 baseline unaffected --------------------------------------------------


def test_p1_baseline_unaffected_by_cursor_check(workspace: Path):
    """workbuddy_private state → 0 cursor findings (both filters)."""
    rs = _make_state(workspace)
    findings = check_init_integrity(_ctx(workspace, rs))
    assert _cursor_drift_findings(findings) == []
    assert _cursor_missing_findings(findings) == []


# C2 — cursor positive (clean) mirror — M7.3.3 flips this from 0 to 2 ERROR --


def test_cursor_positive_mirror_clean(workspace: Path):
    """profile=cursor + NO contract fields → M7.3.3: 2 ERROR, 0 WARN."""
    rs = _make_state(workspace, profile="cursor", runtime_profile="cursor")
    findings = check_init_integrity(_ctx(workspace, rs))
    assert _cursor_drift_findings(findings) == []
    missing = _cursor_missing_findings(findings)
    assert len(missing) == 2
    assert {f["contract_field"] for f in missing} == {
        "coordination_model",
        "writeback_owner",
    }


# C3 — coordination_model drift ------------------------------------------------


def test_cursor_negative_coordination_drift(workspace: Path):
    """profile=cursor + coordination_model=private_coordinated +
    writeback_owner=reviewed_apply_owner (correct) → 1 WARN / 0 ERROR."""
    rs = _make_state(
        workspace,
        profile="cursor",
        runtime_profile="cursor",
        coordination_model="private_coordinated",
        writeback_owner="reviewed_apply_owner",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    drift = _cursor_drift_findings(findings)
    assert len(drift) == 1
    assert drift[0]["contract_field"] == "coordination_model"
    assert "parallel_agents" in drift[0]["message"]
    assert "private_coordinated" in drift[0]["message"]
    assert _cursor_missing_findings(findings) == []


# C4 — writeback_owner drift ---------------------------------------------------


def test_cursor_negative_writeback_drift(workspace: Path):
    """profile=cursor + coordination_model=parallel_agents (correct) +
    writeback_owner=main_session → 1 WARN / 0 ERROR."""
    rs = _make_state(
        workspace,
        profile="cursor",
        runtime_profile="cursor",
        coordination_model="parallel_agents",
        writeback_owner="main_session",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    drift = _cursor_drift_findings(findings)
    assert len(drift) == 1
    assert drift[0]["contract_field"] == "writeback_owner"
    assert "reviewed_apply_owner" in drift[0]["message"]
    assert "main_session" in drift[0]["message"]
    assert _cursor_missing_findings(findings) == []


# C5 — combined drift (both fields) --------------------------------------------


def test_cursor_negative_combined_drift(workspace: Path):
    """Both contract fields present but drifted → exactly 2 WARN,
    mirroring the rh_sprint_sim_01__cursor_negative trial workspace."""
    rs = _make_state(
        workspace,
        profile="cursor",
        runtime_profile="cursor",
        coordination_model="private_coordinated",
        writeback_owner="main_session",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    drift = _cursor_drift_findings(findings)
    fields_seen = {f["contract_field"] for f in drift}
    assert fields_seen == {"coordination_model", "writeback_owner"}
    assert all(f["severity"] == "WARN" for f in drift)
    assert all(f["category"] == "init" for f in drift)
    assert _cursor_missing_findings(findings) == []


# C6 — cross-profile gate guard (codex profile must NOT trigger cursor block) --


def test_codex_profile_with_drift_fields_does_not_trigger_cursor_block(
    workspace: Path,
):
    """Defensive: a codex profile that declares the same drift values
    must trigger the M6.4 codex block (codex's expected values are
    parent_subagents / parent), but must NOT trigger the M6.5 cursor
    block.  This is the symmetric guard to test_verify_codex_cross_check
    C6 — each per-profile gate stays profile-gated.
    """
    rs = _make_state(
        workspace,
        profile="codex",
        runtime_profile="codex",
        coordination_model="private_coordinated",
        writeback_owner="main_session",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    assert _cursor_drift_findings(findings) == []
    assert _cursor_missing_findings(findings) == []
    codex_findings = [
        f for f in findings
        if f.get("category") == "init"
        and f.get("severity") == "WARN"
        and "profile=codex" in f.get("message", "")
    ]
    assert len(codex_findings) == 2
