"""test_release_manifest_consistency.py — v4.92 release identity guard.

RELEASE_MANIFEST.json must truthfully identify the v4.92 release artifact.

3 tests:
1. package_name == "AI_Game_Dev_OS_v4.92" (abstract identity)
2. package_root_dir == "AI_Game_Dev_OS_v4.92_Release" (physical dir)
3. base_from == "AI_Game_Dev_OS_v4.91_Release" (true fork point)

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
MANIFEST_PATH = REPO_ROOT / "RELEASE_MANIFEST.json"


@pytest.fixture(scope="module")
def manifest() -> dict:
    assert MANIFEST_PATH.exists(), (
        f"RELEASE_MANIFEST.json missing at {MANIFEST_PATH}"
    )
    return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))


def test_package_name_matches_working_tree(manifest: dict) -> None:
    """package_name carries the abstract identity (no _Release suffix)."""
    assert manifest["package_name"] == "AI_Game_Dev_OS_v4.92", (
        "package_name must be 'AI_Game_Dev_OS_v4.92' (abstract identity, "
        f"no _Release suffix); got {manifest.get('package_name')!r}"
    )


def test_package_root_dir_matches_release_dir(manifest: dict) -> None:
    """package_root_dir must match the physical release directory name.

    v4.92 release: aligned with the physical byte-locked release
    directory ``AI_Game_Dev_OS_v4.92_Release/``.
    """
    assert manifest["package_root_dir"] == "AI_Game_Dev_OS_v4.92_Release", (
        "package_root_dir must be 'AI_Game_Dev_OS_v4.92_Release' (physical "
        f"release directory); got {manifest.get('package_root_dir')!r}"
    )


def test_base_from_is_v4_91_release(manifest: dict) -> None:
    """base_from must be v4.92's true fork point."""
    assert (
        manifest["base_from"] == "AI_Game_Dev_OS_v4.91_Release"
    ), (
        "base_from must be 'AI_Game_Dev_OS_v4.91_Release' (true v4.92 "
        f"fork point); got {manifest.get('base_from')!r}"
    )
