"""Tests for verify_beta_sprint_exit._ev_get envelope-aware reader
(v4.89 P0-A A5)."""
from __future__ import annotations

from verify_beta_sprint_exit import _ev_get


def test_flat_shape_reads_from_root():
    event = {"event_type": "runtime.create", "task_id": "RH-1"}
    assert _ev_get(event, "task_id") == "RH-1"
    assert _ev_get(event, "missing", "default") == "default"


def test_envelope_falls_back_to_details():
    event = {
        "event_type": "external.tapd.verify",
        "details": {"task_id": "RH-2", "verification_ok": True},
    }
    assert _ev_get(event, "task_id") == "RH-2"
    assert _ev_get(event, "verification_ok") is True
    assert _ev_get(event, "missing") is None


def test_root_wins_over_details_when_both_present():
    event = {"task_id": "ROOT", "details": {"task_id": "DETAIL"}}
    assert _ev_get(event, "task_id") == "ROOT"


def test_falsy_root_value_is_not_masked_by_details():
    """Semantic: False/0/'' at root are REAL values; they must not fall
    back to details (otherwise verification_ok=False would be read as
    details.verification_ok=True and break bad_verifies detection)."""
    event = {"verification_ok": False, "details": {"verification_ok": True}}
    assert _ev_get(event, "verification_ok") is False

    empty_str = {"note": "", "details": {"note": "non-empty"}}
    assert _ev_get(empty_str, "note") == ""


def test_non_dict_details_is_safe():
    """When details isn't a dict (malformed / migrated envelope shape),
    helper returns the default without crashing."""
    event = {"details": "not-a-dict"}
    assert _ev_get(event, "task_id", "default") == "default"
