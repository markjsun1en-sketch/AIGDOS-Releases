"""M6.2 driver CLI contract tests — v4.89 Phase 2 Stage 2.

Covers STAGE_2_MATRIX_INVENTORY.md §4.2 back-compat rules (B1–B4) plus
driver-level enum validation for profile / maturity / shape.

Strategy:
- In-process ``main()`` call (fast; captures stdout via ``capsys``).
- Baseline workspace is the live ``trial_workspaces/rh_sprint_sim_01/``
  tree that Phase 1 already green-lit — same fixture Phase 1 exited on.
- Tests assert on the JSON report fields (``categories_checked``,
  ``verdict``) and driver exit codes (0/1/2).

What these tests do NOT cover (out of M6.2 scope, deferred):
- Multi-combo orchestration → M6.4–M6.8
- Per-profile workspace mirroring → M6.3
- Parallel execution → Phase 3+
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest


# conftest.py has already prepended scripts/ to sys.path.
import beta_sprint_driver  # noqa: E402
from beta_sprint_driver import main, resolve_categories, discover_profiles  # noqa: E402


_PKG_ROOT = Path(__file__).resolve().parents[1]
_TRIAL = _PKG_ROOT / "trial_workspaces" / "rh_sprint_sim_01"

_FULL_CATEGORIES = ["init", "execution", "external", "evidence", "close"]
_SCAFFOLD_CATEGORIES = ["execution", "external"]

_ALL_PROFILES = (
    "workbuddy_private",
    "codex",
    "cursor",
    "claude_code_agent_teams",
    "claude_code_subagents",
    "default_beta_codex_tapd_git",
)


def _extract_report(captured_stdout: str) -> dict:
    """Extract the verify-layer JSON payload from driver stdout.

    Driver prints nothing of its own on the happy path; all stdout
    comes from verify_beta_sprint_exit.main() which emits a single
    ``json.dumps(..., indent=2)`` block.
    """
    lines = captured_stdout.splitlines()
    for i, line in enumerate(lines):
        if line.strip() == "{":
            tail = "\n".join(lines[i:])
            return json.loads(tail)
    raise AssertionError(f"no JSON report in stdout: {captured_stdout[:200]!r}")


# ---------------------------------------------------------------------------
# T1–T3: maturity semantics (inventory §4.2 B1, B2 + maturity filter)
# ---------------------------------------------------------------------------


def test_b1_default_runs_all_five_categories(capsys):
    """B1: --profile alone (no --maturity) → all 5 categories (Phase 1
    baseline identity)."""
    rc = main([
        "--profile", "workbuddy_private",
        "--workspace", str(_TRIAL),
    ])
    report = _extract_report(capsys.readouterr().out)
    assert rc in (0, 1), f"unexpected exit {rc}; report={report.get('verdict')}"
    assert report["categories_checked"] == _FULL_CATEGORIES


def test_b2_explicit_guided_runs_all_five_categories(capsys):
    """B2: --maturity GUIDED → all 5 categories (GUIDED is floor)."""
    rc = main([
        "--profile", "workbuddy_private",
        "--maturity", "GUIDED",
        "--workspace", str(_TRIAL),
    ])
    report = _extract_report(capsys.readouterr().out)
    assert rc in (0, 1)
    assert report["categories_checked"] == _FULL_CATEGORIES


def test_scaffold_narrows_to_scaffold_tier_only(capsys):
    """--maturity SCAFFOLD → only the two SCAFFOLD-tier categories."""
    rc = main([
        "--profile", "workbuddy_private",
        "--maturity", "SCAFFOLD",
        "--workspace", str(_TRIAL),
    ])
    report = _extract_report(capsys.readouterr().out)
    assert rc in (0, 1)
    assert report["categories_checked"] == _SCAFFOLD_CATEGORIES


# ---------------------------------------------------------------------------
# T4–T5: shape default + invalid (inventory §4.2 B3)
# ---------------------------------------------------------------------------


def test_b3_shape_default_accepted(capsys):
    """B3 upper half: omitted --shape defaults to rh_sprint_sim_01."""
    rc = main([
        "--profile", "workbuddy_private",
        "--workspace", str(_TRIAL),
    ])
    capsys.readouterr()  # drain
    assert rc in (0, 1)


def test_b3_unknown_shape_exits_2(capsys):
    """B3 lower half: unknown shape → exit 2 with explicit stderr msg."""
    rc = main([
        "--profile", "workbuddy_private",
        "--shape", "bogus_shape_v99",
        "--workspace", str(_TRIAL),
    ])
    err = capsys.readouterr().err
    assert rc == 2
    assert "unknown shape" in err


# ---------------------------------------------------------------------------
# T6: unknown profile (inventory §4.2 B4)
# ---------------------------------------------------------------------------


def test_b4_unknown_profile_exits_2(capsys):
    """B4: unrecognised profile stem → exit 2."""
    rc = main([
        "--profile", "not_a_real_profile_abc",
        "--workspace", str(_TRIAL),
    ])
    err = capsys.readouterr().err
    assert rc == 2
    assert "unknown profile" in err


# ---------------------------------------------------------------------------
# T7: maturity enum guard (argparse choices)
# ---------------------------------------------------------------------------


def test_maturity_invalid_enum_exits_2():
    """argparse choices guard: bad --maturity → SystemExit(2)."""
    with pytest.raises(SystemExit) as exc:
        main([
            "--profile", "workbuddy_private",
            "--maturity", "BOGUS_TIER",
        ])
    assert exc.value.code == 2


# ---------------------------------------------------------------------------
# T8: all 6 profiles are accepted by the driver (smoke)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("profile", _ALL_PROFILES)
def test_all_six_profiles_parseable(profile, capsys):
    """Every profile in the inventory §1.1 enumeration must be accepted
    by the driver-level validation.  Verdict is not asserted — non-P1
    profiles may legitimately FAIL against the P1 baseline workspace;
    M6.3 owns the per-profile mirror decision.

    Only contract here: driver must not reject these profile stems
    and must not return INTERNAL_ERROR (3).
    """
    rc = main([
        "--profile", profile,
        "--workspace", str(_TRIAL),
    ])
    capsys.readouterr()
    assert rc in (0, 1, 2), f"profile {profile}: unexpected exit {rc}"


# ---------------------------------------------------------------------------
# Helper-level contract tests (pure functions, no I/O)
# ---------------------------------------------------------------------------


def test_resolve_categories_contract():
    assert resolve_categories(None) == "init,execution,external,evidence,close"
    assert resolve_categories("GUIDED") == "init,execution,external,evidence,close"
    assert resolve_categories("SCAFFOLD") == "execution,external"


def test_discover_profiles_finds_six_on_disk():
    """Sanity: the live config/profiles/ dir carries exactly the 6
    profiles that M6.1 inventory froze.  Any drift here is a signal
    that someone added/removed a profile without updating the
    inventory — that is an M6.1 amendment, not an M6.2 test fix."""
    profiles = discover_profiles()
    assert set(profiles) == set(_ALL_PROFILES), (
        f"profile drift detected: on-disk={sorted(profiles)} "
        f"vs inventory={sorted(_ALL_PROFILES)}"
    )
