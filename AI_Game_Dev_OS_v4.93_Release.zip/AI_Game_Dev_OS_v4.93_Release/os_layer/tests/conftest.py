"""Shared pytest fixtures for v4.89 Phase 1 suite.

v4.89 P0-B B1: all fixtures are ``tmp_path``-backed so no test leaks
state into the developer's home directory. The Python-path prepend in
this file is the only way test modules reach the v4.89 source tree
(package isn't installable — it's a reference bundle, not a pip pkg).
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

# Root of the AI_Game_Dev_OS_v4.89 reference bundle. Must come before
# site-packages so tests pick up the local source over any installed
# copy (safety against contamination from parallel v4.88 / v4.87
# workspaces on the same machine).
_PKG_ROOT = Path(__file__).resolve().parents[1]
if str(_PKG_ROOT) not in sys.path:
    sys.path.insert(0, str(_PKG_ROOT))

# Scripts are not a package (no __init__); expose them as a directory
# on sys.path so `import verify_beta_sprint_exit` / `init_runtime_env`
# works in test modules.
_SCRIPTS = _PKG_ROOT / "scripts"
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

# M9.0.7 — runtime cold-start tooling under tools/runtime/ is not a
# package either.  Expose it on sys.path so the M9.0.7 test suite can
# import `_runtime_common`, `generate_sprint_context_rollup`,
# `generate_cold_start_pack`, and `boot_agent_thread` directly without
# spawning a subprocess for every test.  Subprocess-based tests remain
# the canonical form for boot_agent_thread (real CLI contract), but
# parser-level tests use direct imports for speed.
_TOOLS_RUNTIME = _PKG_ROOT / "tools" / "runtime"
if str(_TOOLS_RUNTIME) not in sys.path:
    sys.path.insert(0, str(_TOOLS_RUNTIME))


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    """A clean workspace directory that's neither in the user tree nor
    in the package. All file-system-touching tests must use this fixture
    (or tmp_path directly).
    """
    return tmp_path


@pytest.fixture
def valid_envelope() -> dict:
    """A minimal envelope with all `_REQUIRED_ENVELOPE_FIELDS` populated."""
    return {
        "event_type": "runtime.test",
        "timestamp": "2026-05-02T12:00:00Z",
        "actor": "pytest",
        "runtime_profile": "workbuddy_private",
        "result": "ok",
    }


@pytest.fixture
def tapd_normalize_record() -> dict:
    """A tapd adapter normalize shape suitable for wrap_external_record()."""
    return {
        "id": "story-9001",
        "status": "resolved",
        "event": "story_updated",
        "object_type": "story",
    }


@pytest.fixture
def git_merge_record() -> dict:
    """A git adapter merge_apply shape (carries source_layer='git'
    from A3)."""
    return {
        "id": "pr-42",
        "status": "merged",
        "event": "merge.apply",
        "refs": ["branch/wb/feature-x"],
        "branch": "integration",
        "updated_at": "2026-05-02T12:00:00Z",
        "source_layer": "git",
    }


# ---------------------------------------------------------------------------
# v4.91 Batch 14.19 — Gate Runner Architecture Patch.
# Auto-tag tests by file path so the fast gate's marker-based selection
# (`pytest -m fast_gate_safe`) and the gate-runner exclusion
# (`pytest -m "not gate_runner"`) work without per-file boilerplate.
#
# Membership rules below are the SOURCE OF TRUTH; if you add a new test
# file that should run in the fast gate, add its path here (and to the
# fast-gate F8 batch in scripts/governance/run_release_closure_gate.py).
#
# Anything tagged ``gate_runner`` MUST NOT be invoked from inside the
# fast gate — these are tests that themselves drive the closure gate /
# dispatcher / process runner timeouts as subprocesses, so running them
# inside the fast gate would form a recursive validation loop.
# ---------------------------------------------------------------------------

_FAST_GATE_SAFE_PATTERNS = (
    "tests/cli/",
    "tests/contracts/test_v4_89_byte_lock_modes.py",
    "tests/test_release_clean_tree.py",
    "tests/governance/test_schema_self_validation.py",
    "tests/governance/test_state_machine_alignment.py",
    "tests/governance/test_validate_cold_start_readset.py",
    "tests/governance/test_validate_registry_sync_guard.py",
)

_GATE_RUNNER_PATTERNS = (
    "tests/governance/test_process_runner.py",
    "tests/governance/test_process_runner_to_file.py",
    "tests/governance/test_process_runner_grandchild_cleanup.py",
    "tests/governance/test_release_closure_gate_dispatcher.py",
    "tests/governance/test_consistency_aggregate_stability.py",
    "tests/governance/test_closure_gate_timeout_hardening.py",
    "tests/governance/test_closure_gate_timeout_flag.py",
)


def pytest_collection_modifyitems(config, items):  # noqa: D401, ARG001
    """Auto-apply ``fast_gate_safe`` and ``gate_runner`` markers based
    on file path. Tests can also opt-in manually via ``pytestmark`` or
    ``@pytest.mark.fast_gate_safe`` — both are additive.
    """
    pkg_root = Path(__file__).resolve().parents[1]
    for item in items:
        try:
            rel = Path(item.fspath).resolve().relative_to(pkg_root).as_posix()
        except (ValueError, AttributeError):
            continue
        if any(rel.startswith(p) for p in _FAST_GATE_SAFE_PATTERNS):
            item.add_marker(pytest.mark.fast_gate_safe)
        if any(rel == p or rel.startswith(p) for p in _GATE_RUNNER_PATTERNS):
            item.add_marker(pytest.mark.gate_runner)
