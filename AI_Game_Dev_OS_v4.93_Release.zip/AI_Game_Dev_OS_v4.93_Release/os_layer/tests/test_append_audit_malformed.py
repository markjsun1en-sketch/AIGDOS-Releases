"""Tests for workbuddy_collector.append_audit malformed sink
(v4.89 P0-C C1)."""
from __future__ import annotations

import json

import pytest

from runtime.observability.runtime_event_collectors.workbuddy_collector import (
    AuditAppendError,
    MALFORMED_AUDIT_RELATIVE,
    append_audit,
)


def test_missing_envelope_fields_routes_to_malformed(workspace):
    ok = append_audit(workspace, {"not": "valid"})
    assert ok is False

    m = workspace / MALFORMED_AUDIT_RELATIVE
    assert m.exists()
    rec = json.loads(m.read_text().strip())
    assert "missing required fields" in rec["reason"]
    assert rec["raw_record"] == {"not": "valid"}
    assert rec["recorded_at"].endswith("Z")


def test_non_serialisable_event_falls_back_to_repr(workspace):
    ok = append_audit(workspace, {
        "event_type": "test",
        "timestamp": "2026-05-02T00:00:00Z",
        "actor": "x", "runtime_profile": "x", "result": "x",
        "bad_obj": object(),
    })
    assert ok is False

    m = workspace / MALFORMED_AUDIT_RELATIVE
    rec = json.loads(m.read_text().strip())
    assert "not JSON-serialisable" in rec["reason"]
    assert isinstance(rec["raw_record"], str)  # repr() fallback


def test_happy_path_does_not_touch_malformed(workspace, valid_envelope):
    ok = append_audit(workspace, valid_envelope)
    assert ok is True

    assert (workspace / "runtime/logs/mcp_audit.jsonl").exists()
    assert not (workspace / MALFORMED_AUDIT_RELATIVE).exists()


def test_strict_mode_still_raises(workspace):
    with pytest.raises(AuditAppendError):
        append_audit(workspace, {"bad": "event"}, strict=True)
