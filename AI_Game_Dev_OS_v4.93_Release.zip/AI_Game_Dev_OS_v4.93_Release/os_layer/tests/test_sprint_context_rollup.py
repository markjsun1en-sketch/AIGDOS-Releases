"""Tests for M9.0.4 — generate_sprint_context_rollup.py.

Phase 4 Step 3 / M9.0 Sprint+Agent cold-start / commit 7 (M9.0.7) of
8-commit chain.

Covers:
- build_rollup() determinism on an empty registry skeleton.
- build_rollup() idempotency on the M9.0.5 fixture
  (tests/fixtures/sprint_window/) — two runs produce identical payload
  except for generated_at.
- parse_sprint_sections() recognises ## Current / ## Previous Sprint
  headings and extracts Sprint Name / Goal / Status plus the Sprint
  Boundary body.
- TaskIdPatterns override via runtime/config/task_id_pattern.json —
  fixture uses TASK-/ISSUE-/SPRINT- patterns, not the default.
- --dry-run does not touch the disk.

Working language: English (permanent contract §11).
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

from _runtime_common import RuntimeContext, TaskIdPatterns
from generate_sprint_context_rollup import (
    build_rollup,
    extract_field,
    parse_sprint_sections,
)


_PKG_ROOT = Path(__file__).resolve().parents[1]
_FIXTURE = _PKG_ROOT / "tests" / "fixtures" / "sprint_window"
_ROLLUP_SCRIPT = _PKG_ROOT / "tools" / "runtime" / "generate_sprint_context_rollup.py"


# ---------------------------------------------------------------------------
# Empty skeleton path
# ---------------------------------------------------------------------------


def test_build_rollup_on_empty_package_skeleton():
    ctx = RuntimeContext(repo_root=_PKG_ROOT)
    rollup, archive_index = build_rollup(ctx, handoff_limit=12, archive_limit=120)
    assert rollup["schema_version"] == "sprint_context_rollup.v1"
    assert rollup["project"] == "v4.89_os"
    assert rollup["summary"]["runtime_task_count"] == 0
    assert rollup["summary"]["open_blocker_count"] == 0
    assert rollup["runtime_tasks_for_window"] == []
    assert rollup["open_blockers"] == []
    # Empty sprint board template leaves current/previous empty.
    assert rollup["context_window"]["sprint_ids"] == []
    assert archive_index["schema_version"] == "sprint_archive_index.v1"
    assert archive_index["handoff_archive_count"] == 0


# ---------------------------------------------------------------------------
# Fixture path — real sprint window
# ---------------------------------------------------------------------------


def test_build_rollup_on_fixture_resolves_sprint_window():
    ctx = RuntimeContext(repo_root=_FIXTURE)
    rollup, archive_index = build_rollup(ctx, handoff_limit=12, archive_limit=120)
    assert rollup["project"] == "v4.89_os"
    assert rollup["summary"]["runtime_task_count"] == 3
    assert rollup["summary"]["open_blocker_count"] == 1
    # Fixture has 3 tasks total; 1 in_progress (TASK-1) + 1
    # validation_pending (TASK-2) match _ACTIVE_TASK_STATUSES.
    assert rollup["summary"]["sprint_runtime_task_count"] >= 2
    assert any(
        blocker["blocker_id"] == "BLOCK-1"
        for blocker in rollup["open_blockers"]
    )
    # Archive index includes the archived handoff.
    assert archive_index["handoff_archive_count"] == 1
    assert archive_index["handoff_archive_index"][0]["path"].endswith(
        "2026-05-05_writer_to_engineer_TASK-1_brief.md"
    )


def test_build_rollup_idempotent_except_generated_at():
    ctx = RuntimeContext(repo_root=_FIXTURE)
    first, _ = build_rollup(ctx, handoff_limit=12, archive_limit=120)
    second, _ = build_rollup(ctx, handoff_limit=12, archive_limit=120)
    first.pop("generated_at", None)
    second.pop("generated_at", None)
    assert first == second


# ---------------------------------------------------------------------------
# Parser unit tests
# ---------------------------------------------------------------------------


_SAMPLE_BOARD = """\
# Sprint Board

## Previous Sprint

- Sprint Name: SPRINT-0 — scaffold
- Goal: Stand up the scaffold.
- Status: DONE

## Current Sprint

- Sprint Name: SPRINT-1 — feature
- Goal: Ship the feature.
- Status: IN_PROGRESS
- Sprint Boundary:
  1. Only the feature scope; no refactors.
  2. QA gate required before close.
"""


def test_parse_sprint_sections_resolves_current_and_previous():
    ctx = RuntimeContext(repo_root=_FIXTURE)
    patterns = TaskIdPatterns.from_context(ctx)
    current, previous, all_previous = parse_sprint_sections(_SAMPLE_BOARD, patterns)
    assert current["sprint_name"] == "SPRINT-1 — feature"
    assert current["status"] == "IN_PROGRESS"
    assert previous["sprint_name"] == "SPRINT-0 — scaffold"
    assert len(all_previous) == 1
    assert "sprint_boundary_excerpt" in current
    assert "Only the feature scope" in current["sprint_boundary_excerpt"]


def test_parse_sprint_sections_empty_board_returns_empty_dicts():
    ctx = RuntimeContext(repo_root=_FIXTURE)
    patterns = TaskIdPatterns.from_context(ctx)
    current, previous, all_previous = parse_sprint_sections("", patterns)
    assert current == {}
    assert previous == {}
    assert all_previous == []


def test_extract_field_returns_none_for_placeholder():
    section = "- Sprint Name: _none_\n- Goal: _none_\n- Status: DONE\n"
    assert extract_field(section, "Sprint Name") is None
    assert extract_field(section, "Goal") is None
    assert extract_field(section, "Status") == "DONE"


# ---------------------------------------------------------------------------
# TaskIdPatterns override
# ---------------------------------------------------------------------------


def test_task_id_patterns_use_fixture_override_not_default():
    ctx = RuntimeContext(repo_root=_FIXTURE)
    patterns = TaskIdPatterns.from_context(ctx)
    # Fixture config narrows task_id to TASK-<digits>; default permissive
    # regex [A-Z]{2,6}-\d+... would also match 'SPRINT-1'.  Assert the
    # fixture pattern is in effect.
    assert patterns.find_task_ids("See TASK-42 and BUG-7 plus SPRINT-1.") == ["TASK-42"]
    assert patterns.find_issue_ids("See TASK-42 and ISSUE-7 plus BUG-3.") == ["ISSUE-7"]
    assert patterns.find_sprint_ids("Current SPRINT-1 follows SPRINT-0.") == [
        "SPRINT-0",
        "SPRINT-1",
    ]


# ---------------------------------------------------------------------------
# --dry-run CLI
# ---------------------------------------------------------------------------


def test_dry_run_does_not_write_rollup_files(tmp_path):
    # Mirror the fixture into tmp_path so we can observe disk writes.
    import shutil
    target = tmp_path / "sprint_window"
    shutil.copytree(_FIXTURE, target)
    rollup_path = target / "runtime" / "registries" / "sprint_context_rollup.json"
    # rollup_path is a generator output; the fixture skeleton does NOT
    # pre-place it.  --dry-run must preserve this absence.
    assert not rollup_path.exists()
    cmd = [
        sys.executable,
        str(_ROLLUP_SCRIPT),
        "--repo-root",
        str(target),
        "--dry-run",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["dry_run"] is True
    assert payload["ok"] is True
    # Still absent after --dry-run (no write happened).
    assert not rollup_path.exists()
