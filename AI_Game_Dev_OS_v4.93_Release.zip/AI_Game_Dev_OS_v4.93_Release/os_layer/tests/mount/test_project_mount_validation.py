"""test_project_mount_validation.py — v4.91 Batch 2 c2.

Drives scripts/hub/validate_project_mount.py through realistic
project-side scenarios. Mirrors the fixture mechanic from
test_hub_cli_lifecycle.py: every test materialises a throwaway Core
under tmp_path so the real working tree is never mutated.

Layer 1 (OS Spec). No project names — fixtures use 'sample_alpha'.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]


def _run(argv, cwd: Path):
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return subprocess.run(
        argv,
        cwd=str(cwd),
        capture_output=True,
        text=True,
        env=env,
        timeout=60,
    )


@pytest.fixture
def fake_core_with_link(tmp_path: Path):
    """Materialise a fake Core, init the Hub, link sample_alpha. Returns
    (core_path, project_path)."""
    core = tmp_path / "fake_core"
    (core / "hub").mkdir(parents=True)
    for sub in ("logs", "reports", "preflight"):
        (core / "hub" / sub).mkdir()
        (core / "hub" / sub / ".gitkeep").write_text("", encoding="utf-8")
    (core / "scripts" / "hub").mkdir(parents=True)
    (core / "scripts" / "governance").mkdir()
    (core / "schemas" / "hub").mkdir(parents=True)
    (core / "schemas" / "tenancy").mkdir(parents=True)
    (core / "schemas" / "mount").mkdir(parents=True)

    # Copy hub state files.
    for name in ["global_os_config.yaml", "projects.index.json",
                 "mounts.yaml", "hub_state.json", "README.md"]:
        shutil.copy(REPO_ROOT / "hub" / name, core / "hub" / name)
    # CLIs.
    for f in (REPO_ROOT / "scripts" / "hub").glob("*.py"):
        shutil.copy(f, core / "scripts" / "hub" / f.name)
    # Helpers.
    for fname in ["_yaml_subset.py", "_tenancy_reader.py"]:
        shutil.copy(REPO_ROOT / "scripts" / "governance" / fname,
                    core / "scripts" / "governance" / fname)
    # Schemas.
    for f in (REPO_ROOT / "schemas" / "hub").glob("*.json"):
        shutil.copy(f, core / "schemas" / "hub" / f.name)
    for f in (REPO_ROOT / "schemas" / "tenancy").glob("*.json"):
        shutil.copy(f, core / "schemas" / "tenancy" / f.name)
    for f in (REPO_ROOT / "schemas" / "mount").glob("*.json"):
        shutil.copy(f, core / "schemas" / "mount" / f.name)
    (core / "VERSION").write_text("4.91-WIP\n", encoding="utf-8")

    # Build the project tree.
    proj = tmp_path / "projects" / "sample_alpha"
    (proj / ".ai_dev_os").mkdir(parents=True)
    (proj / ".ai_dev_os" / "project_runtime_protocol.yaml").write_text(
        'schema_version: "1.0.0"\n'
        'project_id: "sample_alpha"\n'
        "project_profile:\n"
        '  stage: "incubation"\n'
        '  game_dev_phase: "prototype"\n',
        encoding="utf-8",
    )

    # init + link.
    r = _run([sys.executable, "scripts/hub/init_hub.py",
              "--hub-id", "test_hub_b2"], core)
    assert r.returncode == 0, r.stderr
    r = _run([sys.executable, "scripts/hub/link_project.py",
              "--project-id", "sample_alpha",
              "--project-root", str(proj)], core)
    assert r.returncode == 0, r.stderr

    return core, proj


def _write_mount_yaml(proj: Path, *, project_id="sample_alpha",
                     stage="incubation", phase="prototype",
                     write_scope=None, cannot_write=None,
                     extra_blocks=None) -> Path:
    write_scope = write_scope or [
        ".ai_dev_os/preflight/**",
        ".ai_dev_os/audit/**",
    ]
    cannot_write = cannot_write or ["src/**", "assets/**"]
    lines = [
        'schema_version: "1.1.0"',
        f'project_id: "{project_id}"',
        'mount_mode: "external_core"',
        f'stage: "{stage}"',
        f'game_dev_phase: "{phase}"',
        "write_scope:",
        *[f'  - "{p}"' for p in write_scope],
        "cannot_write:",
        *[f'  - "{p}"' for p in cannot_write],
    ]
    if extra_blocks:
        lines.extend(extra_blocks)
    p = proj / ".ai_dev_os" / "project_mount.yaml"
    p.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# Tests.
# ---------------------------------------------------------------------------

def test_validate_falls_back_to_runtime_protocol(fake_core_with_link):
    """When no project_mount.yaml exists, F-T-01 protocol yaml accepted."""
    core, proj = fake_core_with_link
    r = _run([sys.executable, "scripts/hub/validate_project_mount.py",
              "--project-id", "sample_alpha"], core)
    assert r.returncode == 0, r.stderr
    assert "project_runtime_protocol.yaml" in r.stdout
    assert "deprecation hint" in r.stdout


def test_validate_accepts_well_formed_mount_yaml(fake_core_with_link):
    core, proj = fake_core_with_link
    _write_mount_yaml(proj)
    r = _run([sys.executable, "scripts/hub/validate_project_mount.py",
              "--project-id", "sample_alpha"], core)
    assert r.returncode == 0, r.stderr
    assert "OK" in r.stdout
    assert "stage='incubation'" in r.stdout
    assert "game_dev_phase='prototype'" in r.stdout


def test_validate_rejects_project_id_mismatch(fake_core_with_link):
    core, proj = fake_core_with_link
    _write_mount_yaml(proj, project_id="sample_other")
    r = _run([sys.executable, "scripts/hub/validate_project_mount.py",
              "--project-id", "sample_alpha"], core)
    assert r.returncode == 1
    assert "does not match linked project_id" in r.stderr


def test_validate_rejects_write_scope_outside_ai_dev_os(fake_core_with_link):
    """Schema-level: write_scope MUST be rooted at .ai_dev_os/."""
    core, proj = fake_core_with_link
    _write_mount_yaml(proj, write_scope=["src/**"])
    r = _run([sys.executable, "scripts/hub/validate_project_mount.py",
              "--project-id", "sample_alpha"], core)
    assert r.returncode == 1
    assert "schema violation" in r.stderr or "write_scope" in r.stderr


def test_validate_rejects_write_scope_cannot_write_overlap(fake_core_with_link):
    """Cross-field: cannot_write entry contained inside a write_scope glob."""
    core, proj = fake_core_with_link
    _write_mount_yaml(
        proj,
        write_scope=[".ai_dev_os/**"],
        cannot_write=[".ai_dev_os/preflight/secrets.yaml"],
    )
    r = _run([sys.executable, "scripts/hub/validate_project_mount.py",
              "--project-id", "sample_alpha"], core)
    assert r.returncode == 1
    assert "contained within write_scope" in r.stderr or "overlap" in r.stderr.lower()


def test_validate_rejects_invalid_stage(fake_core_with_link):
    core, proj = fake_core_with_link
    _write_mount_yaml(proj, stage="weird_stage")
    r = _run([sys.executable, "scripts/hub/validate_project_mount.py",
              "--project-id", "sample_alpha"], core)
    assert r.returncode == 1


def test_validate_rejects_invalid_game_dev_phase(fake_core_with_link):
    core, proj = fake_core_with_link
    _write_mount_yaml(proj, phase="weird_phase")
    r = _run([sys.executable, "scripts/hub/validate_project_mount.py",
              "--project-id", "sample_alpha"], core)
    assert r.returncode == 1


def test_validate_rejects_unlinked_project(fake_core_with_link):
    core, _proj = fake_core_with_link
    r = _run([sys.executable, "scripts/hub/validate_project_mount.py",
              "--project-id", "not_linked_proj"], core)
    assert r.returncode == 2
    assert "not linked" in r.stderr
