"""test_addendum_b_link_removal.py — v4.91 Addendum-B c5.

Tests that 'link' mount_mode is rejected at every layer post-Addendum-B
(Charter anti-pattern #15: No mount_mode aliases).

Coverage matrix:

  1. Schema layer (3 schemas reject 'link'):
     - schemas/mount/project_mount.schema.json (top-level + mounted_core)
     - schemas/mount/host_profile.schema.json (default_mount_mode)
     - schemas/version/version_lock.schema.json

  2. Runtime layer (CLI rejects 'link'):
     - scripts/hub/validate_project_mount.py (VPM-002 FAIL)
     - scripts/hub/detect_embedded_release_bundle.py (argparse choices reject)
     - scripts/hub/init_hub.py (default mount_default = external_core, not link)

  3. State surface:
     - hub/global_os_config.yaml mount_default = external_core (not link)

  4. Charter doc:
     - policies/charter_anti_patterns.md table contains row #15
     - 'No mount_mode aliases' phrase present

Layer 1. Fixtures use sample_alpha (a Charter-compliant project_id).
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
PROJECT_MOUNT = REPO_ROOT / "schemas" / "mount" / "project_mount.schema.json"
HOST_PROFILE = REPO_ROOT / "schemas" / "mount" / "host_profile.schema.json"
VERSION_LOCK = REPO_ROOT / "schemas" / "version" / "version_lock.schema.json"
HUB_GLOBAL_CONFIG = REPO_ROOT / "hub" / "global_os_config.yaml"
CHARTER_DOC = REPO_ROOT / "policies" / "charter_anti_patterns.md"
DETECT_BUNDLE = REPO_ROOT / "scripts" / "hub" / "detect_embedded_release_bundle.py"
INIT_HUB = REPO_ROOT / "scripts" / "hub" / "init_hub.py"


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# 1. Schema layer — 3 schemas reject 'link'
# ---------------------------------------------------------------------------


def test_project_mount_schema_rejects_link_top_level():
    """project_mount top-level mount_mode enum no longer contains 'link'."""
    inst = {
        "schema_version": "1.1.0",
        "project_id": "sample_alpha",
        "mount_mode": "link",
        "stage": "incubation",
        "game_dev_phase": "prototype",
        "write_scope": [".ai_dev_os/audit/**"],
        "cannot_write": ["src/**"],
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_project_mount_schema_rejects_link_in_mounted_core():
    """project_mount.mounted_core.mount_mode enum no longer contains 'link'."""
    inst = {
        "schema_version": "1.1.0",
        "project_id": "sample_alpha",
        "mount_mode": "external_core",  # top-level OK
        "stage": "incubation",
        "game_dev_phase": "prototype",
        "write_scope": [".ai_dev_os/audit/**"],
        "cannot_write": ["src/**"],
        "mounted_core": {
            "mount_mode": "link",  # but inner block invalid
            "core_path": "/abs/external/core",
            "core_version": "4.91-Release",
            "writable": False,
        },
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_version_lock_schema_rejects_link():
    """version_lock.mount_mode enum no longer contains 'link'."""
    inst = {
        "schema_version": "1.1.0",
        "core_version": "4.91-Release",
        "package_name": "AI_Game_Dev_OS_v4.91",
        "package_root_dir": "/abs/path/to/core",
        "locked_at": "2026-05-22T10:00:00Z",
        "linked_project_count": 0,
        "linked_project_locks": {},
        "mount_mode": "link",
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(VERSION_LOCK))


def test_host_profile_schema_rejects_link():
    """host_profile.project_adoption.default_mount_mode enum has never accepted
    'link' (was forward-only since Addendum-A); Addendum-B description-only
    update reaffirms the rejection. This test pins the contract."""
    inst = {
        "schema_version": "1.1.0",
        "host_tool": "workbuddy",
        "capabilities": {
            "supports_project_instructions": True,
            "supports_skills": True,
            "supports_subagents": "conditional",
            "supports_team_mode": "conditional",
            "auto_subagent_without_explicit_request": False,
        },
        "recommended_mode": "project_rules_plus_explicit_task_prompt",
        "project_adoption": {
            "default_mount_mode": "link",
            "scaffold_target": ".ai_dev_os",
            "copy_full_release_bundle_by_default": False,
        },
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(HOST_PROFILE))


# ---------------------------------------------------------------------------
# 2. Runtime layer — CLI rejects 'link' / defaults to external_core
# ---------------------------------------------------------------------------


def test_detect_embedded_release_bundle_argparse_rejects_link():
    """detect_embedded_release_bundle --mount-mode link is rejected by argparse
    choices (auto-derived from VALID_MODES set, post-Addendum-B 3-element)."""
    proc = subprocess.run(
        [sys.executable, str(DETECT_BUNDLE),
         "--project-root", "/tmp", "--mount-mode", "link"],
        capture_output=True, text=True, timeout=10,
    )
    # argparse exits with code 2 on choice failure, prints "invalid choice" to stderr
    assert proc.returncode == 2, (
        f"Expected argparse rejection (rc=2), got rc={proc.returncode}; "
        f"stdout={proc.stdout!r}; stderr={proc.stderr!r}"
    )
    assert "invalid choice" in proc.stderr.lower(), proc.stderr


def test_detect_embedded_release_bundle_help_lists_three_modes():
    """The --help output shows exactly the 3 forward-only mount modes,
    confirming VALID_MODES has been narrowed in module scope."""
    proc = subprocess.run(
        [sys.executable, str(DETECT_BUNDLE), "--help"],
        capture_output=True, text=True, timeout=10,
    )
    assert proc.returncode == 0
    out = proc.stdout
    assert "external_core" in out
    assert "thin_scaffold" in out
    assert "vendor_snapshot" in out
    # The 3-value choice list MUST NOT contain 'link' as a CLI choice;
    # the argparse choices line shows {external_core,thin_scaffold,vendor_snapshot}
    assert "{external_core,thin_scaffold,vendor_snapshot}" in out or \
        "{external_core, thin_scaffold, vendor_snapshot}" in out, (
            f"Expected 3-value choice list in --help; got:\n{out}"
        )


def test_init_hub_default_mount_default_is_external_core():
    """init_hub.py source carries 'mount_default': 'external_core' default
    in the global_os_config write block (not 'link')."""
    src = INIT_HUB.read_text(encoding="utf-8")
    assert '"mount_default": "external_core"' in src, (
        "init_hub.py must default mount_default to 'external_core' post-Addendum-B"
    )
    assert '"mount_default": "link"' not in src, (
        "init_hub.py must not retain any 'mount_default': 'link' default"
    )


# ---------------------------------------------------------------------------
# 3. State surface — hub/global_os_config.yaml
# ---------------------------------------------------------------------------


def test_hub_global_os_config_mount_default_is_external_core():
    """The shipped Hub default skeleton at hub/global_os_config.yaml MUST
    carry mount_default: external_core (not link). This is the file every
    fresh init reads / writes; a 'link' default would silently re-introduce
    the deprecated alias on every Hub initialisation."""
    text = HUB_GLOBAL_CONFIG.read_text(encoding="utf-8")
    assert 'mount_default: "external_core"' in text, (
        f"hub/global_os_config.yaml must declare mount_default: 'external_core' "
        f"post-Addendum-B; got:\n{text}"
    )
    assert 'mount_default: "link"' not in text, (
        "hub/global_os_config.yaml must not retain mount_default: 'link'"
    )


# ---------------------------------------------------------------------------
# 4. Charter layer — anti-pattern #15 entry
# ---------------------------------------------------------------------------


def test_charter_anti_pattern_15_entry_present():
    """policies/charter_anti_patterns.md MUST list anti-pattern #15
    (No mount_mode aliases) and reference its Addendum-B source."""
    text = CHARTER_DOC.read_text(encoding="utf-8")
    assert "15 anti-patterns" in text, (
        "Charter doc header / tail must declare 15 enforced anti-patterns"
    )
    assert "No mount_mode aliases" in text, (
        "Charter doc must contain the #15 statement 'No mount_mode aliases'"
    )
    assert "Addendum-B" in text, (
        "Charter doc must reference Addendum-B as the source of #15"
    )
