"""test_schema_addendum_a.py — v4.91 Addendum-A c5 (post-Addendum-B narrowed).

Schema-level tests for the 1.1.0 widening landed in Addendum-A c1.
Note: Addendum-B (2026-05-22) subsequently narrowed the mount_mode enum
from 4 values to 3 by removing the 'link' deprecated alias (Charter
anti-pattern #15: No mount_mode aliases). The widening tests in this
module now parametrise over the 3 forward-only modes; the 'link rejected'
test lives in tests/mount/test_addendum_b_link_removal.py.

  * mount_mode enum: 3 values (external_core / thin_scaffold / vendor_snapshot)
  * NEW optional blocks: mounted_core / release_bundle_policy /
                          forbidden_generated_paths / ownership
  * host_profile NEW optional blocks: project_adoption /
                          forbidden_default_actions / allowed_actions
  * Charter anti-pattern #14 schema-level const guards:
    - host_profile.project_adoption.copy_full_release_bundle_by_default: const false
    - mount.release_bundle_policy.allow_full_release_copy: const false
    - mount.mounted_core.writable: const false
    - mount.ownership.project_truth_owner: const ".ai_dev_os"
    - mount.ownership.release_bundle_truth_owner: const "non_authoritative_reference"

Layer 1. Fixtures use sample_alpha / local_dev_hub.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
PROJECT_MOUNT = REPO_ROOT / "schemas" / "mount" / "project_mount.schema.json"
HOST_PROFILE = REPO_ROOT / "schemas" / "mount" / "host_profile.schema.json"


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


def _project_mount_minimal() -> dict:
    return {
        "schema_version": "1.1.0",
        "project_id": "sample_alpha",
        "mount_mode": "external_core",
        "stage": "incubation",
        "game_dev_phase": "prototype",
        "write_scope": [".ai_dev_os/audit/**"],
        "cannot_write": ["src/**"],
    }


# ---------------------------------------------------------------------------
# mount_mode enum (3 values post-Addendum-B; 'link' removed per Charter #15)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "mode",
    ["external_core", "thin_scaffold", "vendor_snapshot"],
)
def test_mount_mode_all_three_values_accepted(mode):
    inst = _project_mount_minimal()
    inst["mount_mode"] = mode
    jsonschema.validate(inst, _load(PROJECT_MOUNT))


@pytest.mark.parametrize(
    "bad_mode",
    ["link", "copy", "auto", "embedded", "snapshot", "vendor", "External_core"],
)
def test_mount_mode_unknown_value_rejected(bad_mode):
    inst = _project_mount_minimal()
    inst["mount_mode"] = bad_mode
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


# ---------------------------------------------------------------------------
# mounted_core block (NEW optional in 1.1.0)
# ---------------------------------------------------------------------------

def test_mounted_core_block_writable_must_be_false():
    inst = _project_mount_minimal()
    inst["mounted_core"] = {
        "mount_mode": "external_core",
        "core_path": "../AI_Game_Dev_OS_v4.91",
        "core_version": "4.91-WIP",
        "writable": True,  # Charter §6.5 violation
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_mounted_core_block_writable_false_accepted():
    inst = _project_mount_minimal()
    inst["mounted_core"] = {
        "mount_mode": "external_core",
        "core_path": "../AI_Game_Dev_OS_v4.91",
        "core_version": "4.91-WIP",
        "writable": False,
    }
    jsonschema.validate(inst, _load(PROJECT_MOUNT))


# ---------------------------------------------------------------------------
# release_bundle_policy.allow_full_release_copy: const false
# (Charter anti-pattern #14 schema-level guard)
# ---------------------------------------------------------------------------

def test_release_bundle_policy_allow_full_release_copy_must_be_false():
    inst = _project_mount_minimal()
    inst["release_bundle_policy"] = {
        "allow_full_release_copy": True,  # anti-pattern #14
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_release_bundle_policy_allow_full_release_copy_false_accepted():
    inst = _project_mount_minimal()
    inst["release_bundle_policy"] = {
        "allow_full_release_copy": False,
        "allow_vendor_snapshot": True,
        "vendor_snapshot_must_be_readonly": True,
        "exclude_vendor_snapshot_from_runtime_scan": True,
        "exclude_vendor_snapshot_from_ltm_retrieval": True,
        "exclude_vendor_snapshot_from_gate_scope": True,
        "exclude_vendor_snapshot_from_project_mutation": True,
    }
    jsonschema.validate(inst, _load(PROJECT_MOUNT))


# ---------------------------------------------------------------------------
# ownership block const locks
# ---------------------------------------------------------------------------

def test_ownership_project_truth_owner_const_ai_dev_os():
    inst = _project_mount_minimal()
    inst["ownership"] = {
        "core_truth_owner": "external_core",
        "project_truth_owner": "src/",  # NOT .ai_dev_os
        "release_bundle_truth_owner": "non_authoritative_reference",
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_ownership_release_bundle_truth_owner_const_locked():
    inst = _project_mount_minimal()
    inst["ownership"] = {
        "core_truth_owner": "external_core",
        "project_truth_owner": ".ai_dev_os",
        "release_bundle_truth_owner": "authoritative",  # not allowed
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


# ---------------------------------------------------------------------------
# host_profile.project_adoption.copy_full_release_bundle_by_default: const false
# (Charter anti-pattern #14 — the headline schema guard)
# ---------------------------------------------------------------------------

def _host_profile_minimal() -> dict:
    return {
        "schema_version": "1.1.0",
        "host_tool": "workbuddy",
        "capabilities": {
            "supports_project_instructions": True,
            "supports_skills": True,
            "supports_subagents": "conditional",
            "auto_subagent_without_explicit_request": False,
        },
        "recommended_mode": "project_rules_plus_explicit_task_prompt",
    }


def test_host_profile_copy_full_release_default_must_be_false():
    inst = _host_profile_minimal()
    inst["project_adoption"] = {
        "default_mount_mode": "external_core",
        "scaffold_target": ".ai_dev_os",
        "copy_full_release_bundle_by_default": True,  # anti-pattern #14
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(HOST_PROFILE))


def test_host_profile_default_mount_mode_link_rejected():
    """Host profiles never accepted 'link' (it was Addendum-A's project_mount-only
    deprecated alias). Post-Addendum-B, 'link' is removed entirely per Charter #15
    — this test now serves as a regression that the host_profile schema continues
    to reject the historical deprecated value."""
    inst = _host_profile_minimal()
    inst["project_adoption"] = {
        "default_mount_mode": "link",  # 3-value enum (post-Addendum-B) excludes link
        "scaffold_target": ".ai_dev_os",
        "copy_full_release_bundle_by_default": False,
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(HOST_PROFILE))


def test_host_profile_scaffold_target_const_ai_dev_os():
    inst = _host_profile_minimal()
    inst["project_adoption"] = {
        "default_mount_mode": "external_core",
        "scaffold_target": ".some_other_dir",  # not const
        "copy_full_release_bundle_by_default": False,
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(HOST_PROFILE))


def test_host_profile_full_addendum_a_block_accepted():
    inst = _host_profile_minimal()
    inst["project_adoption"] = {
        "default_mount_mode": "external_core",
        "generate_project_scaffold": True,
        "scaffold_target": ".ai_dev_os",
        "copy_full_release_bundle_by_default": False,
    }
    inst["forbidden_default_actions"] = [
        "copy_full_release_to_project_root",
        "treat_release_bundle_as_project_truth",
        "patch_embedded_release_bundle",
        "include_release_bundle_in_runtime_scan",
        "include_release_bundle_in_ltm_retrieval",
        "include_release_bundle_in_gate_scope",
        "generate_project_state_inside_release_bundle",
    ]
    inst["allowed_actions"] = [
        "generate_ai_dev_os_scaffold",
        "write_project_mount_yaml",
        "write_project_runtime_protocol",
        "write_version_lock",
    ]
    jsonschema.validate(inst, _load(HOST_PROFILE))


def test_host_profile_forbidden_action_unknown_value_rejected():
    inst = _host_profile_minimal()
    inst["forbidden_default_actions"] = [
        "copy_full_release_to_project_root",
        "made_up_action_not_in_enum",  # rejected
    ]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(HOST_PROFILE))
