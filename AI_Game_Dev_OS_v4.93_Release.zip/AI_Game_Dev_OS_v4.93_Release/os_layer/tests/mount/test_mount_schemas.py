"""test_mount_schemas.py — v4.91 Batch 2 c1.

Validates the mount-level schemas:

  schemas/mount/project_mount.schema.json
  schemas/mount/host_profile.schema.json

Layer 1 (OS Spec). No project names — fixtures use 'sample_alpha'.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = REPO_ROOT / "schemas" / "mount"
PROJECT_MOUNT = SCHEMA_DIR / "project_mount.schema.json"
HOST_PROFILE = SCHEMA_DIR / "host_profile.schema.json"


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# Meta-validation.
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("path", [PROJECT_MOUNT, HOST_PROFILE])
def test_mount_schema_meta_valid(path):
    jsonschema.Draft7Validator.check_schema(_load(path))


# ---------------------------------------------------------------------------
# project_mount.schema.json
# ---------------------------------------------------------------------------

def _project_mount_happy() -> dict:
    return {
        "schema_version": "1.1.0",
        "project_id": "sample_alpha",
        "mount_mode": "external_core",
        "stage": "incubation",
        "game_dev_phase": "prototype",
        "write_scope": [
            ".ai_dev_os/preflight/**",
            ".ai_dev_os/audit/**",
        ],
        "cannot_write": [
            "src/**",
            "assets/**",
            "project.godot",
        ],
    }


def test_project_mount_happy_accepts():
    jsonschema.validate(_project_mount_happy(), _load(PROJECT_MOUNT))


def test_project_mount_with_optional_blocks_accepts():
    inst = _project_mount_happy()
    inst["core_os_package"] = {
        "package_name": "AI_Game_Dev_OS_v4.91",
        "version": "4.91-Release",
    }
    inst["preflight"] = {
        "enabled": True,
        "policy_path": ".ai_dev_os/preflight/preflight_policy.yaml",
    }
    inst["host_profile"] = {
        "host_tool": "workbuddy",
        "supports_subagents": "environment_dependent",
    }
    jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_project_mount_schema_version_const_locked():
    """v4.91 Addendum-A: schema_version is now const 1.1.0; the previous
    1.0.0 (B2 c1 baseline) is rejected."""
    inst = _project_mount_happy()
    inst["schema_version"] = "1.0.0"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_project_mount_mount_mode_widened_enum_accepts_external_core():
    """v4.91 Addendum-A: mount_mode enum widened to 4 values; external_core
    is the new default for fresh adoptions."""
    inst = _project_mount_happy()
    inst["mount_mode"] = "external_core"
    jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_project_mount_mount_mode_link_rejected_after_addendum_b():
    """v4.91 Addendum-B (2026-05-22): 'link' deprecated alias removed entirely
    from the mount_mode enum (Charter anti-pattern #15: No mount_mode aliases).
    Replaces the prior Addendum-A 'link kept 1 minor' compat test. Migration
    recipe: 'link' -> 'external_core' (mechanical rename)."""
    inst = _project_mount_happy()
    inst["mount_mode"] = "link"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_project_mount_mount_mode_rejects_unknown_value():
    """v4.91 Addendum-B (post-narrowing): enum is now [external_core, thin_scaffold,
    vendor_snapshot]; 'copy' (and any other value) MUST still reject.
    Charter anti-pattern #9 (Hub never copies Core) intact via enum lock."""
    inst = _project_mount_happy()
    inst["mount_mode"] = "copy"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_project_mount_stage_enum_locked():
    inst = _project_mount_happy()
    inst["stage"] = "weird_stage"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_project_mount_game_dev_phase_enum_locked():
    inst = _project_mount_happy()
    inst["game_dev_phase"] = "weird_phase"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_project_mount_write_scope_must_be_under_ai_dev_os():
    inst = _project_mount_happy()
    inst["write_scope"] = ["src/**"]  # NOT rooted at .ai_dev_os/
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_project_mount_write_scope_min_one_entry():
    inst = _project_mount_happy()
    inst["write_scope"] = []
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_project_mount_cannot_write_min_one_entry():
    inst = _project_mount_happy()
    inst["cannot_write"] = []
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_project_mount_preflight_policy_path_pattern():
    inst = _project_mount_happy()
    inst["preflight"] = {
        "enabled": True,
        "policy_path": "src/something.yaml",  # not under .ai_dev_os/preflight/
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


def test_project_mount_additional_properties_rejected():
    inst = _project_mount_happy()
    inst["unexpected"] = "nope"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(PROJECT_MOUNT))


# ---------------------------------------------------------------------------
# host_profile.schema.json
# ---------------------------------------------------------------------------

def _host_profile_happy() -> dict:
    return {
        "schema_version": "1.1.0",
        "host_tool": "codex",
        "capabilities": {
            "supports_project_instructions": True,
            "supports_skills": True,
            "supports_subagents": "conditional",
            "auto_subagent_without_explicit_request": False,
        },
        "recommended_mode": "explicit_preflight_request_or_skill",
    }


def test_host_profile_happy_accepts():
    jsonschema.validate(_host_profile_happy(), _load(HOST_PROFILE))


def test_host_profile_auto_subagent_must_be_false():
    """Charter anti-pattern #13 enforced at the schema level."""
    inst = _host_profile_happy()
    inst["capabilities"]["auto_subagent_without_explicit_request"] = True
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(HOST_PROFILE))


def test_host_profile_recommended_mode_enum_locked():
    inst = _host_profile_happy()
    inst["recommended_mode"] = "auto_dispatch_no_consent"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(HOST_PROFILE))


def test_host_profile_supports_subagents_string_form_accepted():
    for s in ["conditional", "environment_dependent", "profile_dependent"]:
        inst = _host_profile_happy()
        inst["capabilities"]["supports_subagents"] = s
        jsonschema.validate(inst, _load(HOST_PROFILE))


def test_host_profile_unknown_host_tool_rejected():
    inst = _host_profile_happy()
    inst["host_tool"] = "vim"  # not in enum
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(inst, _load(HOST_PROFILE))
