"""test_pack_definition_schema_v11.py — v4.90 Batch 13 Step 13.2.

Plan §7.4 字面 — Pack Definition schema 1.0.0 -> 1.1.0 minor bump
adds the full field set (roles_detailed / skills / activation /
dependencies). Per EP decision 2026-05-14 17:50 (D-13.2.1=B no
grandfather): const is locked at 1.1.0 and any 1.0.0 entry is
rejected by the validator.

8 tests:
1. schema const is 1.1.0 (B path: no enum, no grandfather)
2. all 5 seed packs promoted to 1.1.0 with all 4 new fields populated
3. validator passes 5 seed packs with new fields (--dir mode)
4. validator rejects legacy 1.0.0 entry (no grandfather)
5. dependencies.requires referencing unknown pack_id -> violation
6. dependencies.conflicts_with referencing unknown pack_id -> violation
7. activation.default_stages with unknown stage -> violation
8. activation.host_profiles with unknown host -> violation

Layer 1 (OS Spec). No project names; placeholder pack_id ap_2099_*.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = (
    REPO_ROOT / "schemas" / "agent_library" / "agent_pack_entry.schema.json"
)
SEED_PACK_DIR = REPO_ROOT / "agent_packs"
VALIDATOR = REPO_ROOT / "scripts" / "agent_library" / "validate_agent_pack.py"

SEED_PACK_NAMES = [
    "ap_2026_001_executive_cluster",
    "ap_2026_002_research_and_design_cluster",
    "ap_2026_003_implementation_cluster",
    "ap_2026_004_validation_cluster",
    "ap_2026_005_support_cluster",
]


def _run_validator(*args: str) -> tuple[int, str, str]:
    cmd = [sys.executable, str(VALIDATOR), *args]
    env = dict(os.environ)
    env["PYTHONPATH"] = str(REPO_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.run(
        cmd, env=env, capture_output=True, text=True, timeout=30,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _minimal_v11_pack(
    pack_id: str = "ap_2099_999_sample_cluster",
    cluster: str = "executive",
    roles: list[str] | None = None,
    extra_lines: list[str] | None = None,
) -> str:
    """Emit a 1.1.0 pack front-matter + body. Caller may append
    extra YAML lines (e.g. dependencies / activation overrides) via
    `extra_lines`. Roles default to a cluster-appropriate value.
    """
    if roles is None:
        roles = ["executive", "orchestrator"] if cluster == "executive" else [cluster]
    lines = [
        "---",
        'schema_version: "1.1.0"',
        f'pack_id: "{pack_id}"',
        'pack_version: "1.0.0"',
        f'cluster: "{cluster}"',
        "roles:",
        *[f'  - "{r}"' for r in roles],
        'lifecycle_state: "draft"',
        'created_at: "2099-01-01"',
        "references:",
        '  - "docs/16_agent_library/README.md"',
    ]
    if extra_lines:
        lines.extend(extra_lines)
    lines.extend(["---", "", "# Body", ""])
    return "\n".join(lines) + "\n"


# --- Test 1: schema const is 1.1.0 (B path, no enum) -----------------------

def test_schema_version_const_is_1_1_0():
    """B path: schema const is 1.1.0 (not enum, no grandfather)."""
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    sv = schema["properties"]["schema_version"]
    assert "const" in sv, (
        "schema_version property must use `const` (B path; no enum/grandfather)"
    )
    assert sv["const"] == "1.1.0", (
        f"schema_version.const should be '1.1.0', got {sv['const']!r}"
    )
    assert "enum" not in sv, (
        "B path forbids enum on schema_version (no 1.0.0 grandfather)"
    )


# --- Test 2: 5 seed packs promoted to 1.1.0 + 4 new fields populated -------

def test_all_seed_packs_promoted_to_1_1_0_with_new_fields():
    """Every seed pack carries schema_version 1.1.0 + roles_detailed +
    skills + activation + dependencies blocks.

    Aggregated (not parametrized) so the §8 trajectory matches +8 net
    test additions exactly.
    """
    failures: list[str] = []
    for pack_stem in SEED_PACK_NAMES:
        text = (SEED_PACK_DIR / f"{pack_stem}.md").read_text(encoding="utf-8")
        if not text.startswith("---\n"):
            failures.append(f"{pack_stem}: missing front-matter open")
            continue
        fm_end = text.find("\n---\n", 4)
        if fm_end == -1:
            failures.append(f"{pack_stem}: missing front-matter close")
            continue
        fm = text[4:fm_end]
        if 'schema_version: "1.1.0"' not in fm:
            failures.append(f"{pack_stem}: schema_version not promoted to 1.1.0")
        for required_block in ("roles_detailed:", "skills:", "activation:",
                               "dependencies:"):
            if required_block not in fm:
                failures.append(
                    f"{pack_stem}: required 1.1.0 block "
                    f"{required_block!r} missing"
                )
    assert not failures, "seed promotion failures:\n  " + "\n  ".join(failures)


# --- Test 3: validator passes all 5 seed packs in --dir mode ---------------

def test_validator_passes_all_seed_packs_dir_mode():
    """Sanity: 5 seed packs validate cleanly under the new 1.1.0 schema."""
    rc, out, err = _run_validator("--dir", str(SEED_PACK_DIR))
    assert rc == 0, (
        f"validator returned {rc}; stdout={out!r}\nstderr={err!r}"
    )
    assert "0 violation" in out, f"expected 0 violations; out={out!r}"


# --- Test 4: validator rejects legacy 1.0.0 entry (no grandfather) ---------

def test_validator_rejects_legacy_1_0_0_entry(tmp_path):
    """B path: no grandfather. A pack with schema_version 1.0.0 must
    fail validation against the 1.1.0 schema.
    """
    fm = (
        "---\n"
        'schema_version: "1.0.0"\n'
        'pack_id: "ap_2099_111_legacy"\n'
        'pack_version: "1.0.0"\n'
        'cluster: "executive"\n'
        'lifecycle_state: "draft"\n'
        'created_at: "2099-01-01"\n'
        'roles:\n'
        '  - "executive"\n'
        'references:\n'
        '  - "docs/16_agent_library/README.md"\n'
        "---\n"
        "# Body\n"
    )
    path = tmp_path / "ap_2099_111_legacy.md"
    path.write_text(fm, encoding="utf-8")
    rc, out, err = _run_validator("--file", str(path))
    assert rc == 1, (
        f"expected exit 1 (legacy 1.0.0 should fail under B path); "
        f"rc={rc}, out={out!r}, err={err!r}"
    )
    assert "schema_version" in out, (
        f"violation should mention schema_version; out={out!r}"
    )


# --- Test 5: dependencies.requires unknown pack_id -> violation ------------

def test_dependencies_requires_unknown_pack_id_violation(tmp_path):
    """Cross-file referent existence check: requires must resolve."""
    body = _minimal_v11_pack(
        pack_id="ap_2099_222_with_bad_dep",
        extra_lines=[
            "dependencies:",
            "  requires:",
            '    - "ap_9999_999_does_not_exist"',
            "  conflicts_with: []",
        ],
    )
    path = tmp_path / "ap_2099_222_with_bad_dep.md"
    path.write_text(body, encoding="utf-8")
    rc, out, err = _run_validator("--dir", str(tmp_path))
    assert rc == 1, (
        f"unknown requires must trip the validator; rc={rc}, out={out!r}"
    )
    assert "requires" in out and "unknown pack_id" in out, (
        f"violation message must mention requires + unknown pack_id; "
        f"out={out!r}"
    )


# --- Test 6: dependencies.conflicts_with unknown pack_id -> violation ------

def test_dependencies_conflicts_with_unknown_pack_id_violation(tmp_path):
    """Symmetric to test 5: conflicts_with also must resolve."""
    body = _minimal_v11_pack(
        pack_id="ap_2099_223_with_bad_conflict",
        extra_lines=[
            "dependencies:",
            "  requires: []",
            "  conflicts_with:",
            '    - "ap_9999_888_phantom"',
        ],
    )
    path = tmp_path / "ap_2099_223_with_bad_conflict.md"
    path.write_text(body, encoding="utf-8")
    rc, out, err = _run_validator("--dir", str(tmp_path))
    assert rc == 1, f"unknown conflicts_with must trip; rc={rc}, out={out!r}"
    assert "conflicts_with" in out and "unknown pack_id" in out, (
        f"violation must mention conflicts_with + unknown pack_id; "
        f"out={out!r}"
    )


# --- Test 7: activation.default_stages unknown stage -> violation ----------

def test_activation_unknown_stage_rejected(tmp_path):
    """7-stage enum: alphaa is not a valid stage."""
    body = _minimal_v11_pack(
        pack_id="ap_2099_224_bad_stage",
        extra_lines=[
            "activation:",
            "  default_stages:",
            '    - "alphaa"',
            "  host_profiles: []",
        ],
    )
    path = tmp_path / "ap_2099_224_bad_stage.md"
    path.write_text(body, encoding="utf-8")
    rc, out, err = _run_validator("--file", str(path))
    assert rc == 1, f"unknown stage must trip; rc={rc}, out={out!r}"
    assert "default_stages" in out and "alphaa" in out, (
        f"violation must mention default_stages + bad value; out={out!r}"
    )


# --- Test 8: activation.host_profiles unknown host -> violation ------------

def test_activation_unknown_host_profile_rejected(tmp_path):
    """5-host enum: bogus_host is not a valid host_profile."""
    body = _minimal_v11_pack(
        pack_id="ap_2099_225_bad_host",
        extra_lines=[
            "activation:",
            "  default_stages: []",
            "  host_profiles:",
            '    - "bogus_host"',
        ],
    )
    path = tmp_path / "ap_2099_225_bad_host.md"
    path.write_text(body, encoding="utf-8")
    rc, out, err = _run_validator("--file", str(path))
    assert rc == 1, f"unknown host must trip; rc={rc}, out={out!r}"
    assert "host_profiles" in out and "bogus_host" in out, (
        f"violation must mention host_profiles + bad value; out={out!r}"
    )


# Net additions: 8 distinct test functions (no parametrize).
# Pre-13.2 baseline 805 (after 13.1). §8 trajectory entry: 805 -> 813 (+8). ✓
