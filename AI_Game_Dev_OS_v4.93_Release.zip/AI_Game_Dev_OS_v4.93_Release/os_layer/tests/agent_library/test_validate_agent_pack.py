"""test_validate_agent_pack.py — v4.90 Batch 5 Module C.

Validates scripts/agent_library/validate_agent_pack.py subprocess behavior.

11 cases (all use tmp_path; seed packs are authored in Step 5.5):
1. --help renders.
2. --file with minimal valid pack -> exit 0.
3. --dir with one valid pack -> exit 0; summary 1 file checked.
4. --file with malformed front-matter -> exit 1.
5. --file with active state but no activated_at -> exit 1.
6. --file with active state + _skeleton_notes -> exit 1.
7. --file with cluster <-> role taxonomy violation
   (cluster=executive but roles=[design]) -> exit 1.
8. --file with deferred cluster (creative_cluster) -> exit 1.
9. --file with pack_id mismatching filename stem -> exit 1.
10. --file nonexistent path -> exit 4.
11. --format json carries an agent_pack_ledger-shaped block with
    pack_id / cluster / roles / lifecycle_state / file_path on each
    pack entry.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
VALIDATOR = PKG_ROOT / "scripts" / "agent_library" / "validate_agent_pack.py"


def _run(*args, timeout: int = 20) -> tuple[int, str, str]:
    proc = subprocess.run(
        [sys.executable, str(VALIDATOR), *args],
        capture_output=True, text=True, timeout=timeout,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _minimal_frontmatter(overrides: dict | None = None,
                         pack_id: str = "ap_2099_999_sample_cluster") -> str:
    """Emit a valid minimal pack front-matter + stub body."""
    base = {
        "schema_version": '"1.1.0"',
        "pack_id": f'"{pack_id}"',
        "pack_version": '"1.0.0"',
        "cluster": '"executive"',
        "lifecycle_state": '"draft"',
        "created_at": '"2099-01-01"',
    }
    if overrides:
        for k, v in overrides.items():
            base[k] = v
    lines = ["---"]
    for k, v in base.items():
        lines.append(f"{k}: {v}")
    # roles and references as block lists (override via overrides if needed)
    if "roles" not in (overrides or {}):
        lines.append("roles:")
        lines.append('  - "executive"')
        lines.append('  - "orchestrator"')
    lines.append("references:")
    lines.append('  - "docs/16_agent_library/README.md"')
    lines.append("---")
    lines.append("")
    lines.append("# Body")
    lines.append("")
    return "\n".join(lines) + "\n"


def _write_pack(tmp_path: Path, filename: str,
                overrides: dict | None = None,
                pack_id: str | None = None) -> Path:
    """Helper: write a pack file at tmp_path/filename. pack_id defaults
    to the filename stem (without .md)."""
    stem = filename[:-3] if filename.endswith(".md") else filename
    pid = pack_id if pack_id is not None else stem
    p = tmp_path / filename
    p.write_text(
        _minimal_frontmatter(overrides=overrides, pack_id=pid),
        encoding="utf-8",
    )
    return p


# --- Case 1: --help -------------------------------------------------------

def test_1_help_renders():
    rc, out, err = _run("--help")
    assert rc == 0
    assert "validate" in out.lower() and "pack" in out.lower()


# --- Case 2: minimal valid pack -> exit 0 ---------------------------------

def test_2_minimal_valid_pack_exits_0(tmp_path):
    p = _write_pack(tmp_path, "ap_2099_999_sample_cluster.md")
    rc, out, err = _run("--file", str(p))
    assert rc == 0, f"stdout={out}\nstderr={err}"
    assert "0 violation" in out


# --- Case 3: --dir with one valid pack ------------------------------------

def test_3_dir_with_one_valid_pack_exits_0(tmp_path):
    _write_pack(tmp_path, "ap_2099_998_sample_cluster.md")
    rc, out, err = _run("--dir", str(tmp_path))
    assert rc == 0, err
    assert "1 file" in out


# --- Case 4: malformed front-matter ---------------------------------------

def test_4_malformed_front_matter_exits_1(tmp_path):
    p = tmp_path / "ap_2099_001_bad.md"
    p.write_text("(no front matter)\n# body\n", encoding="utf-8")
    rc, out, err = _run("--file", str(p))
    assert rc == 1, err
    assert "front-matter" in out.lower() or "front-matter" in err.lower()


# --- Case 5: active state without activated_at ----------------------------

def test_5_active_without_activated_at_exits_1(tmp_path):
    p = _write_pack(tmp_path, "ap_2099_002_active_no_at.md",
                    overrides={"lifecycle_state": '"active"'})
    rc, out, err = _run("--file", str(p))
    assert rc == 1, err
    assert "activated_at" in out


# --- Case 6: active state with _skeleton_notes ----------------------------

def test_6_active_with_skeleton_notes_exits_1(tmp_path):
    # Embed _skeleton_notes literal in the front-matter body. The zero-dep
    # YAML subset accepts a string scalar with that key, which is enough
    # to trip the validator's "active forbids _skeleton_notes" guard.
    fm = (
        "---\n"
        'schema_version: "1.1.0"\n'
        'pack_id: "ap_2099_003_active_with_skel"\n'
        'pack_version: "1.0.0"\n'
        'cluster: "executive"\n'
        'lifecycle_state: "active"\n'
        'activated_at: "2099-01-02T00:00:00Z"\n'
        'created_at: "2099-01-01"\n'
        'roles:\n'
        '  - "executive"\n'
        'references:\n'
        '  - "docs/16_agent_library/README.md"\n'
        '_skeleton_notes: "still drafting"\n'
        "---\n"
        "# Body\n"
    )
    p = tmp_path / "ap_2099_003_active_with_skel.md"
    p.write_text(fm, encoding="utf-8")
    rc, out, err = _run("--file", str(p))
    assert rc == 1, err
    assert "_skeleton_notes" in out


# --- Case 7: cluster <-> role taxonomy violation --------------------------

def test_7_cluster_role_taxonomy_violation_exits_1(tmp_path):
    # cluster=executive permits {executive, orchestrator}; declaring
    # design + research must trip the taxonomy guard.
    fm = (
        "---\n"
        'schema_version: "1.1.0"\n'
        'pack_id: "ap_2099_004_taxonomy_violation"\n'
        'pack_version: "1.0.0"\n'
        'cluster: "executive"\n'
        'lifecycle_state: "draft"\n'
        'created_at: "2099-01-01"\n'
        'roles:\n'
        '  - "design"\n'
        '  - "research"\n'
        'references:\n'
        '  - "docs/16_agent_library/README.md"\n'
        "---\n"
        "# Body\n"
    )
    p = tmp_path / "ap_2099_004_taxonomy_violation.md"
    p.write_text(fm, encoding="utf-8")
    rc, out, err = _run("--file", str(p))
    assert rc == 1, err
    assert "not permitted in cluster" in out


# --- Case 8: deferred cluster -------------------------------------------

def test_8_deferred_cluster_without_exemption_exits_1(tmp_path):
    """v4.91 M-G c1 — creative_cluster has a capability_promotion exemption
    (evo_2026_002). A pack declaring creative_cluster WITHOUT the
    authorising proposal id in references[] is still rejected."""
    fm = (
        "---\n"
        'schema_version: "1.1.0"\n'
        'pack_id: "ap_2099_005_creative_seed"\n'
        'pack_version: "1.0.0"\n'
        'cluster: "creative_cluster"\n'
        'lifecycle_state: "draft"\n'
        'created_at: "2099-01-01"\n'
        'roles:\n'
        '  - "design"\n'
        'references:\n'
        '  - "docs/16_agent_library/README.md"\n'
        "---\n"
        "# Body\n"
    )
    p = tmp_path / "ap_2099_005_creative_seed.md"
    p.write_text(fm, encoding="utf-8")
    rc, out, err = _run("--file", str(p))
    assert rc == 1, err
    # Validator now reports the exemption requirement explicitly.
    assert "capability_promotion" in out or "evo_2026_002" in out, (
        f"expected exemption guidance in output, got: {out!r}"
    )


def test_8b_deferred_cluster_with_exemption_exits_0(tmp_path):
    """v4.91 M-G c1 — creative_cluster pack listing
    proposals/evo_2026_002_creative_cluster_role_aliasing.md in references[]
    AND declaring roles within {design, implementation, validation}
    passes validation."""
    fm = (
        "---\n"
        'schema_version: "1.1.0"\n'
        'pack_id: "ap_2099_006_creative_with_exemption"\n'
        'pack_version: "1.0.0"\n'
        'cluster: "creative_cluster"\n'
        'lifecycle_state: "draft"\n'
        'created_at: "2099-01-01"\n'
        'roles:\n'
        '  - "design"\n'
        '  - "implementation"\n'
        '  - "validation"\n'
        'references:\n'
        '  - "proposals/evo_2026_002_creative_cluster_role_aliasing.md"\n'
        '  - "docs/16_agent_library/README.md"\n'
        "---\n"
        "# Body\n"
    )
    p = tmp_path / "ap_2099_006_creative_with_exemption.md"
    p.write_text(fm, encoding="utf-8")
    rc, out, err = _run("--file", str(p))
    assert rc == 0, f"validator should accept exemption pack; out={out!r} err={err!r}"
    assert "0 violation" in out


def test_8c_deferred_cluster_with_exemption_but_outside_role_exits_1(tmp_path):
    """v4.91 M-G c1 — even with the exemption ref, roles outside
    {design, implementation, validation} are rejected."""
    fm = (
        "---\n"
        'schema_version: "1.1.0"\n'
        'pack_id: "ap_2099_007_creative_outside_role"\n'
        'pack_version: "1.0.0"\n'
        'cluster: "creative_cluster"\n'
        'lifecycle_state: "draft"\n'
        'created_at: "2099-01-01"\n'
        'roles:\n'
        '  - "design"\n'
        '  - "executive"\n'
        'references:\n'
        '  - "proposals/evo_2026_002_creative_cluster_role_aliasing.md"\n'
        "---\n"
        "# Body\n"
    )
    p = tmp_path / "ap_2099_007_creative_outside_role.md"
    p.write_text(fm, encoding="utf-8")
    rc, out, err = _run("--file", str(p))
    assert rc == 1, err
    assert "not permitted in cluster" in out


# --- Case 9: pack_id mismatching filename stem ----------------------------

def test_9_pack_id_filename_mismatch_exits_1(tmp_path):
    # File on disk: ap_2099_006_aaa.md  but front-matter says ap_2099_006_bbb
    p = _write_pack(tmp_path, "ap_2099_006_aaa.md",
                    pack_id="ap_2099_006_bbb")
    rc, out, err = _run("--file", str(p))
    assert rc == 1, err
    assert "filename stem" in out


# --- Case 10: nonexistent input ------------------------------------------

def test_10_nonexistent_file_exits_4(tmp_path):
    p = tmp_path / "no_such_pack.md"
    rc, out, err = _run("--file", str(p))
    assert rc == 4, err


# --- Case 11: --format json ledger shape ---------------------------------

def test_11_json_format_carries_ledger_shape(tmp_path):
    _write_pack(tmp_path, "ap_2099_010_sample_a.md")
    _write_pack(tmp_path, "ap_2099_011_sample_b.md")
    rc, out, err = _run("--dir", str(tmp_path), "--format", "json")
    assert rc == 0, err
    parsed = json.loads(out)
    assert "ledger" in parsed
    ledger = parsed["ledger"]
    assert ledger["schema_version"] == "1.1.0"
    assert ledger["pack_count"] == 2
    assert isinstance(ledger["packs"], list)
    for entry in ledger["packs"]:
        assert {"pack_id", "cluster", "roles", "lifecycle_state",
                "file_path"} <= entry.keys()
