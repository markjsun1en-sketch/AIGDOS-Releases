"""test_baseline_versions_dual_track.py — v4.90 Batch 14.9 (v4.90.2 patch).

Issue 4 closure: every game_type_packs manifest carries the new
``baseline_versions`` array (v4.89_Release + v4.90_Release alias) and a
human-readable ``baseline_alias_note``, while preserving the legacy
``required_runtime_baseline`` / ``depends_on_run_baseline`` strings for
inv_004 reference-baseline integrity (v4.89 audit Class C: 0).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1].parent
PACKS_ROOT = REPO_ROOT / "game_type_packs"

EXPECTED_BASELINE_VERSIONS = ["v4.89_Release", "v4.90_Release"]


def _manifest_paths():
    pd = sorted(PACKS_ROOT.glob("*/manifests/pack_definition.json"))
    pm = sorted(PACKS_ROOT.glob("*/manifests/PACK_MANIFEST.json"))
    return pd + pm


def test_at_least_six_manifests_exist():
    paths = _manifest_paths()
    # 4 pack_definition.json (one per pack) + 2 PACK_MANIFEST.json
    # (the two project_pack-typed packs ship the manifest extra).
    assert len(paths) >= 6, [str(p.relative_to(REPO_ROOT)) for p in paths]


def test_every_manifest_carries_baseline_versions_dual_track():
    for path in _manifest_paths():
        data = json.loads(path.read_text(encoding="utf-8"))
        rel = path.relative_to(REPO_ROOT)
        assert "baseline_versions" in data, f"{rel} missing baseline_versions"
        assert (
            data["baseline_versions"] == EXPECTED_BASELINE_VERSIONS
        ), f"{rel} baseline_versions != {EXPECTED_BASELINE_VERSIONS}"
        assert (
            "baseline_alias_note" in data
        ), f"{rel} missing baseline_alias_note"
        assert isinstance(data["baseline_alias_note"], str)
        assert "v4.90_Release" in data["baseline_alias_note"]


def test_legacy_baseline_string_preserved_for_inv_004_compat():
    """Confirm we did NOT rewrite the legacy v4.89_Release string fields.

    inv_004 (v4.89 reference baseline integrity) classifies every v4.89
    mention as HISTORICAL_OK_BASELINE / CHANGELOG / INTENTIONAL_OPEN. If
    we silently swapped the legacy fields to v4.90, downstream tools
    that match the alias label would break and Class C would not change
    even though the semantic meaning shifted. The dual-track design
    keeps both labels reachable.
    """
    legacy_keys = ("required_runtime_baseline", "depends_on_run_baseline")
    found_any = False
    for path in _manifest_paths():
        data = json.loads(path.read_text(encoding="utf-8"))
        for key in legacy_keys:
            if key in data:
                found_any = True
                assert (
                    data[key] == "v4.89_Release Run Baseline layer"
                ), f"{path.relative_to(REPO_ROOT)} {key} unexpectedly rewritten"
    assert found_any, "no legacy baseline string keys found across manifests"
