"""test_seed_packs.py — v4.90 Batch 5 Module D.

Contract tests for the 5 seed packs in agent_packs/.

7 cases:
1. All 5 seed files exist with the expected filenames.
2. Each seed front-matter parses cleanly + every cluster -> roles
   pairing matches PACK_CLUSTER_TAXONOMY.md.
3. Each seed validates against
   schemas/agent_library/agent_pack_entry.schema.json.
4. Subprocess call validate_agent_pack.py --dir agent_packs/ exits 0
   and reports 5 file(s) checked / 0 violation(s).
5. The 5 seed packs collectively cover all 8 generic role_id values
   in AGENT_ROLE_CATALOG.md.
6. None of the 5 seeds declare a deferred cluster (creative_cluster,
   tools_cluster) — those are reserved for v4.91.
7. agent_packs/README.md is project-name-free (delegates to the
   Layer 1 lint script and asserts it returns 0 violations).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
PACKS_DIR = REPO_ROOT / "agent_packs"
ENTRY_SCHEMA_PATH = (
    REPO_ROOT / "schemas" / "agent_library" / "agent_pack_entry.schema.json"
)
VALIDATOR = REPO_ROOT / "scripts" / "agent_library" / "validate_agent_pack.py"
LINT = REPO_ROOT / "scripts" / "governance" / "lint_layer_separation.py"

# Reuse the zero-dep YAML parser that lives in scripts/governance/.
sys.path.insert(0, str(REPO_ROOT / "scripts" / "governance"))
from _yaml_subset import parse_yaml_text  # noqa: E402

_FRONT_MATTER_RE = re.compile(r"^---\n(.*?)\n---\n", re.DOTALL)

EXPECTED_SEEDS = [
    ("ap_2026_001_executive_cluster.md", "executive",
     {"executive", "orchestrator"}),
    ("ap_2026_002_research_and_design_cluster.md", "research_design",
     {"research", "design"}),
    ("ap_2026_003_implementation_cluster.md", "implementation",
     {"implementation"}),
    ("ap_2026_004_validation_cluster.md", "validation",
     {"validation"}),
    ("ap_2026_005_support_cluster.md", "support",
     {"support", "archivist"}),
]

ALL_GENERIC_ROLES = {
    "executive", "orchestrator", "research", "design",
    "implementation", "validation", "support", "archivist",
}

DEFERRED_CLUSTERS = {"creative_cluster", "tools_cluster"}


def _parse_pack(path: Path) -> tuple[dict, str]:
    text = path.read_text(encoding="utf-8")
    m = _FRONT_MATTER_RE.match(text)
    assert m, f"front-matter block not found at top of {path}"
    fm = parse_yaml_text(m.group(1))
    body = text[m.end():]
    return fm, body


# --- Case 1: 5 seed files exist -------------------------------------------

def test_1_all_five_seed_files_exist():
    for filename, _, _ in EXPECTED_SEEDS:
        p = PACKS_DIR / filename
        assert p.is_file(), f"missing seed pack: {p}"


# --- Case 2: each seed parses + cluster -> roles correct ------------------

def test_2_each_seed_parses_with_correct_cluster_role_pairing():
    for filename, expected_cluster, expected_roles in EXPECTED_SEEDS:
        p = PACKS_DIR / filename
        fm, body = _parse_pack(p)
        assert fm["pack_id"] == filename[:-3], (
            f"pack_id {fm['pack_id']!r} != filename stem in {filename}"
        )
        assert fm["cluster"] == expected_cluster, (
            f"{filename}: cluster mismatch"
        )
        assert set(fm["roles"]) == expected_roles, (
            f"{filename}: roles {set(fm['roles'])} != expected "
            f"{expected_roles}"
        )
        # Body has a non-trivial length — not just front-matter.
        assert len(body.strip()) > 300


# --- Case 3: each seed validates against schema ---------------------------

def test_3_each_seed_validates_against_entry_schema():
    schema = json.loads(ENTRY_SCHEMA_PATH.read_text(encoding="utf-8"))
    for filename, _, _ in EXPECTED_SEEDS:
        p = PACKS_DIR / filename
        fm, _ = _parse_pack(p)
        jsonschema.validate(instance=fm, schema=schema)


# --- Case 4: validator subprocess passes 0 violations ---------------------

def test_4_validate_agent_pack_dir_exits_0():
    proc = subprocess.run(
        [sys.executable, str(VALIDATOR), "--dir", str(PACKS_DIR)],
        capture_output=True, text=True, timeout=30,
    )
    assert proc.returncode == 0, (
        f"validator failed:\nstdout={proc.stdout}\nstderr={proc.stderr}"
    )
    # v4.91 M-G c1 added ap_2026_006 (6th pack); accept ≥5.
    import re as _re
    m = _re.search(r"Summary:\s+(\d+)\s+file\(s\)", proc.stdout)
    assert m is not None, f"missing Summary line: {proc.stdout!r}"
    n = int(m.group(1))
    assert n >= 5, f"expected ≥5 packs validated, got {n}"
    assert "0 violation" in proc.stdout


# --- Case 5: 5 seeds collectively cover all 8 roles -----------------------

def test_5_collective_role_coverage_is_complete():
    covered: set[str] = set()
    for filename, _, _ in EXPECTED_SEEDS:
        p = PACKS_DIR / filename
        fm, _ = _parse_pack(p)
        covered.update(fm["roles"])
    missing = ALL_GENERIC_ROLES - covered
    assert not missing, (
        f"v4.90 baseline does not cover all 8 roles. Missing: "
        f"{sorted(missing)}"
    )


# --- Case 6: no seed declares a deferred cluster --------------------------

def test_6_no_seed_in_deferred_cluster():
    for filename, _, _ in EXPECTED_SEEDS:
        p = PACKS_DIR / filename
        fm, _ = _parse_pack(p)
        assert fm["cluster"] not in DEFERRED_CLUSTERS, (
            f"{filename} declares deferred cluster {fm['cluster']!r}; "
            "those are reserved for v4.91"
        )


# --- Case 7: Layer 1 lint clean over agent_packs/ -------------------------

def test_7_agent_packs_layer_1_lint_clean():
    proc = subprocess.run(
        [sys.executable, str(LINT)],
        capture_output=True, text=True, timeout=30,
    )
    assert proc.returncode == 0, (
        f"lint failed:\nstdout={proc.stdout}\nstderr={proc.stderr}"
    )
    assert "0 violations" in proc.stdout
