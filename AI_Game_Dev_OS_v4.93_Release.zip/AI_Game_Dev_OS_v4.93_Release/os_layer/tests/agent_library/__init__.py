"""tests/agent_library/__init__.py — v4.90 Batch 5 Module B.

Marker-only package init. Layer 1 (OS Spec). No project names.
"""
