"""test_pack_lifecycle_state_model.py — v4.90 Batch 14 Step 14.6.3.

Asserts that the new PACK_LIFECYCLE_STATE_MODEL.md is structurally
sound and aligned with agent_pack_state.schema.json.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

V4_90_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(V4_90_ROOT))

from scripts.governance.check_state_machine_alignment import (  # noqa: E402
    parse_doc_transitions,
    parse_schema_transitions,
)

DOC_PATH = (
    V4_90_ROOT / "docs" / "16_agent_library" / "PACK_LIFECYCLE_STATE_MODEL.md"
)
SCHEMA_PATH = (
    V4_90_ROOT / "schemas" / "agent_library" / "agent_pack_state.schema.json"
)


def test_pack_lifecycle_model_doc_exists():
    """The model doc must exist at the canonical path."""
    assert DOC_PATH.exists(), f"missing model doc: {DOC_PATH}"
    assert DOC_PATH.stat().st_size > 0


def test_pack_lifecycle_doc_lists_5_states():
    """All 5 enum values must appear in the doc body."""
    text = DOC_PATH.read_text(encoding="utf-8")
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    enum = schema["properties"]["lifecycle_state"]["enum"]
    assert len(enum) == 5  # invariant from Batch 5 design
    for state in enum:
        assert state in text, (
            f"State {state!r} not mentioned in PACK_LIFECYCLE_STATE_MODEL.md"
        )


def test_pack_lifecycle_doc_transition_table_matches_schema():
    """Doc transition table must equal schema anyOf whitelist."""
    schema_trans, enum = parse_schema_transitions(SCHEMA_PATH, "lifecycle_state")
    doc_trans = parse_doc_transitions(DOC_PATH, enum)
    assert doc_trans == schema_trans, (
        f"Pack lifecycle alignment broken:\n"
        f"  doc_only: {sorted(doc_trans - schema_trans)}\n"
        f"  schema_only: {sorted(schema_trans - doc_trans)}"
    )
    assert len(schema_trans) == 6  # invariant from Batch 5 design
