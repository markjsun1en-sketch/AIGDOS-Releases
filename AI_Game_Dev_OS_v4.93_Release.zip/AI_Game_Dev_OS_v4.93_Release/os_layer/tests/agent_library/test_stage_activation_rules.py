"""stage_activation_rules schema + validator — v4.90 Batch 12 Step 12.4
(GAP #4).

Covers:
  1. Schema declares `const: "1.0.0"` + 7-stage stage_id enum aligned
     with project_profile.stage.
  2. The shipped canonical yaml (config/stage_activation_rules.yaml)
     parses + validates clean.
  3. The validator (scripts/agent_library/validate_stage_activation.py)
     accepts a hand-written valid rules file.
  4. Validator rejects yaml whose stage_id is not in the enum.
  5. Validator rejects yaml referencing a pack id absent under
     agent_packs/ (cross-reference integrity).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

PKG_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = (
    PKG_ROOT
    / "schemas"
    / "agent_library"
    / "stage_activation_rules.schema.json"
)
SCRIPT = PKG_ROOT / "scripts" / "agent_library" / "validate_stage_activation.py"
CANONICAL_YAML = PKG_ROOT / "config" / "stage_activation_rules.yaml"


def _run(*args):
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True, text=True, timeout=20,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _make_packs_dir(tmp_path: Path, ids: list[str]) -> Path:
    """Create a fake agent_packs/ dir with empty .md placeholders."""
    d = tmp_path / "agent_packs"
    d.mkdir()
    for pid in ids:
        (d / f"{pid}.md").write_text(f"# {pid}\n", encoding="utf-8")
    return d


# --------------------------------------------------------------------------
# 1. Schema shape sentinel
# --------------------------------------------------------------------------

def test_schema_const_and_stage_enum():
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    assert schema["properties"]["schema_version"]["const"] == "1.0.0"
    stage_enum = schema["properties"]["stages"]["items"]["properties"][
        "stage_id"
    ]["enum"]
    assert stage_enum == [
        "incubation",
        "alpha",
        "beta",
        "release_candidate",
        "production",
        "maintenance",
        "sunset",
    ]


# --------------------------------------------------------------------------
# 2. Canonical yaml passes the validator out of the box
# --------------------------------------------------------------------------

def test_canonical_yaml_validates_clean():
    rc, out, err = _run("--format", "json")
    assert rc == 0, err
    payload = json.loads(out)
    assert payload["violation_count"] == 0
    # Sanity: 7 stages × non-empty packs == realistic shipped data
    assert "Summary" not in payload  # JSON path; no text summary leaked


# --------------------------------------------------------------------------
# 3. Hand-written valid yaml passes
# --------------------------------------------------------------------------

def test_validator_accepts_valid_handwritten_yaml(tmp_path: Path):
    pack_id = "ap_2026_001_executive_cluster"
    packs = _make_packs_dir(tmp_path, [pack_id])
    rules = tmp_path / "rules.yaml"
    rules.write_text(
        "schema_version: \"1.0.0\"\n"
        "stages:\n"
        "  - stage_id: alpha\n"
        "    activated_packs:\n"
        f"      - \"{pack_id}\"\n",
        encoding="utf-8",
    )
    rc, out, err = _run(
        "--file", str(rules),
        "--packs-dir", str(packs),
        "--format", "json",
    )
    assert rc == 0, err
    payload = json.loads(out)
    assert payload["violation_count"] == 0


# --------------------------------------------------------------------------
# 4. Unknown stage_id rejected
# --------------------------------------------------------------------------

def test_validator_rejects_unknown_stage_id(tmp_path: Path):
    pack_id = "ap_2026_001_executive_cluster"
    packs = _make_packs_dir(tmp_path, [pack_id])
    rules = tmp_path / "rules.yaml"
    rules.write_text(
        "schema_version: \"1.0.0\"\n"
        "stages:\n"
        "  - stage_id: vertical_slice\n"  # not in enum
        "    activated_packs:\n"
        f"      - \"{pack_id}\"\n",
        encoding="utf-8",
    )
    rc, out, err = _run(
        "--file", str(rules),
        "--packs-dir", str(packs),
        "--format", "json",
    )
    assert rc == 1, err
    payload = json.loads(out)
    assert payload["violation_count"] >= 1
    assert any(
        "vertical_slice" in v for v in payload["violations"]
    ), payload


# --------------------------------------------------------------------------
# 5. Missing pack reference rejected
# --------------------------------------------------------------------------

def test_validator_rejects_missing_pack_reference(tmp_path: Path):
    # agent_packs/ has only ap_2026_001
    have = "ap_2026_001_executive_cluster"
    miss = "ap_2099_999_phantom_cluster"
    packs = _make_packs_dir(tmp_path, [have])
    rules = tmp_path / "rules.yaml"
    rules.write_text(
        "schema_version: \"1.0.0\"\n"
        "stages:\n"
        "  - stage_id: alpha\n"
        "    activated_packs:\n"
        f"      - \"{have}\"\n"
        f"      - \"{miss}\"\n",
        encoding="utf-8",
    )
    rc, out, err = _run(
        "--file", str(rules),
        "--packs-dir", str(packs),
        "--format", "json",
    )
    assert rc == 1, err
    payload = json.loads(out)
    assert payload["violation_count"] == 1
    assert miss in payload["violations"][0]
