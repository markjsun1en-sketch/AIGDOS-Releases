"""test_agent_pack_schema.py — v4.90 Batch 5 Module B.

Self-validation for the 3 agent library schemas:
- schemas/agent_library/agent_role.schema.json
- schemas/agent_library/agent_pack_entry.schema.json
- schemas/agent_library/agent_pack_state.schema.json

6 cases:
1. All 3 schemas are themselves valid draft-07 documents.
2. agent_role: minimal happy-path instance validates AND the
   role_id <-> scope canonical pairing allOf is satisfied.
3. agent_role: mismatched pairing (role_id=executive + scope=code)
   rejected by allOf.anyOf.
4. agent_pack_entry: minimal happy-path (lifecycle_state=draft)
   validates.
5. agent_pack_entry: lifecycle_state=active WITHOUT activated_at
   rejected; with activated_at AND _skeleton_notes also rejected.
6. agent_pack_state: transition_history item with an invalid
   transition (deprecated -> active) rejected by the allOf.anyOf
   whitelist.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = REPO_ROOT / "schemas" / "agent_library"
ROLE_PATH = SCHEMA_DIR / "agent_role.schema.json"
ENTRY_PATH = SCHEMA_DIR / "agent_pack_entry.schema.json"
STATE_PATH = SCHEMA_DIR / "agent_pack_state.schema.json"


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


def _minimal_role(role_id: str = "executive", scope: str = "decision-only") -> dict:
    return {
        "schema_version": "1.0.0",
        "role_id": role_id,
        "scope": scope,
        "writeback": "decision-only / no writeback to canonical",
    }


def _minimal_entry(lifecycle_state: str = "draft", **overrides) -> dict:
    base = {
        "schema_version": "1.1.0",
        "pack_id": "ap_2099_999_sample_cluster",
        "pack_version": "1.0.0",
        "cluster": "executive",
        "roles": ["executive", "orchestrator"],
        "lifecycle_state": lifecycle_state,
        "created_at": "2099-01-01",
        "references": ["docs/16_agent_library/README.md"],
    }
    base.update(overrides)
    return base


# --- Test 1: draft-07 meta-validation -------------------------------------

def test_all_three_schemas_are_valid_draft_07():
    for p in (ROLE_PATH, ENTRY_PATH, STATE_PATH):
        schema = _load(p)
        jsonschema.Draft7Validator.check_schema(schema)
        assert schema["$schema"] == "http://json-schema.org/draft-07/schema#"


# --- Test 2: agent_role minimal valid -------------------------------------

def test_agent_role_minimal_valid_and_canonical_pairing_satisfied():
    schema = _load(ROLE_PATH)
    # All 8 canonical pairings must validate.
    pairings = [
        ("executive", "decision-only"),
        ("orchestrator", "coordination"),
        ("research", "read-only"),
        ("design", "spec"),
        ("implementation", "code"),
        ("validation", "verify-only"),
        ("support", "infra"),
        ("archivist", "record-only"),
    ]
    for role_id, scope in pairings:
        jsonschema.validate(instance=_minimal_role(role_id, scope), schema=schema)


# --- Test 3: agent_role mismatched pairing rejected -----------------------

def test_agent_role_mismatched_pairing_rejected():
    schema = _load(ROLE_PATH)
    # executive should pair with decision-only, not code
    inst = _minimal_role(role_id="executive", scope="code")
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=inst, schema=schema)


# --- Test 4: agent_pack_entry minimal valid -------------------------------

def test_agent_pack_entry_minimal_valid():
    schema = _load(ENTRY_PATH)
    jsonschema.validate(instance=_minimal_entry(), schema=schema)


# --- Test 5: agent_pack_entry active state guards -------------------------

def test_agent_pack_entry_active_requires_activated_at_and_no_skeleton_notes():
    schema = _load(ENTRY_PATH)

    # 5a. lifecycle_state=active WITHOUT activated_at -> rejected
    inst = _minimal_entry(lifecycle_state="active")
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=inst, schema=schema)

    # 5b. lifecycle_state=active WITH activated_at + _skeleton_notes -> rejected
    inst = _minimal_entry(
        lifecycle_state="active",
        activated_at="2099-01-02T00:00:00Z",
        _skeleton_notes={"author_todo": "still drafting"},
    )
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=inst, schema=schema)

    # 5c. lifecycle_state=active WITH activated_at and NO _skeleton_notes -> valid
    inst = _minimal_entry(
        lifecycle_state="active",
        activated_at="2099-01-02T00:00:00Z",
    )
    jsonschema.validate(instance=inst, schema=schema)


# --- Test 6: agent_pack_state invalid transition rejected -----------------

def test_agent_pack_state_invalid_transition_rejected():
    schema = _load(STATE_PATH)
    inst = {
        "pack_id": "ap_2099_999_sample_cluster",
        "lifecycle_state": "active",
        "captured_at": "2099-01-01T00:00:00Z",
        "transition_history": [
            {
                "from": "deprecated",
                "to": "active",  # NOT in the 6-entry whitelist
                "at": "2099-01-01T00:00:00Z",
            }
        ],
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=inst, schema=schema)
