"""test_verdict_chain.py — v4.92 reopen B6 (OS Verdict Chain).

Validates scripts/capability/validate_verdict_chain.py + the two B6 schemas
(os_verdict, lead_capability) + the committed Lead sheets.

Cases:
 1. The two schemas are valid draft-07.
 2. The 6 real control sheets validate (schema + structural) and the validator
    reports them clean.
 3. The verdict-authority firewall (the heart of B6):
    a. verdict_owner != os_control_plane -> schema-invalid.
    b. reviewed_by == subject_pack_id -> validator violation (a pack cannot
       review its own work).
    c. reviewed_by must resolve to a known Lead, Lead capability, or approved
       OS validator id.
 4. A Lead capability emitting anything but os_verdict -> schema-invalid.
 5. evidence_refs resolution: a verdict citing a non-existent ev_ id is a
    violation when --evidence-dir is given.
 6. The real committed os_verdict (osv_fd047184) is valid and resolves
    against the slice evidence dir.
 7. The validator runs clean under the bare managed interpreter (zero deps).

jsonschema is a soft dependency (importorskip) for the schema-validate cases;
the validator's own structural checks run without it.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
VALIDATOR = PKG_ROOT / "scripts" / "capability" / "validate_verdict_chain.py"
OSV_SCHEMA = PKG_ROOT / "capability_protocols" / "os_verdict.schema.json"
LC_SCHEMA = PKG_ROOT / "capability_protocols" / "lead_capability.schema.json"
LEADS_DIR = PKG_ROOT / "os_control_plane" / "leads"
MIGRATION_MAP = PKG_ROOT / "docs" / "13_migration" / "legacy_to_v492_migration_map.json"
SLICE_EVIDENCE = PKG_ROOT / "docs" / "13_migration" / "b5_slice_evidence"
REAL_VERDICT = SLICE_EVIDENCE / "osv_fd047184.os_verdict.json"

_BARE = "/Users/macsun/.workbuddy/binaries/python/versions/3.13.12/bin/python3"

LEADS = ("game_design_lead", "art_lead", "program_lead", "qa_lead",
         "orchestrator", "executive_producer")


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


def _run_validator(args, python=None):
    proc = subprocess.run(
        [python or sys.executable, str(VALIDATOR), *args],
        capture_output=True, text=True, timeout=60)
    return proc.returncode, proc.stdout, proc.stderr


# ---------- schemas --------------------------------------------------------

def test_schemas_valid_draft7():
    jsonschema = pytest.importorskip("jsonschema")
    jsonschema.Draft7Validator.check_schema(_load(OSV_SCHEMA))
    jsonschema.Draft7Validator.check_schema(_load(LC_SCHEMA))


def test_all_control_sheets_present_and_clean():
    for lead in LEADS:
        assert (LEADS_DIR / f"{lead}.capability.json").is_file(), \
            f"missing {lead}"
    rc, out, err = _run_validator(["--repo-root", str(PKG_ROOT)])
    assert rc == 0, f"rc={rc} err={err}\n{out}"
    assert "6 Lead sheets" in out
    assert "clean" in out


def test_b9_control_capabilities_landed_on_leads():
    """B9 migrated the 15 control-plane skills into Lead capabilities.

    B5/B6 already put rawdata_pipeline_check on program_lead, B11 adds
    the wireframe split review on game_design_lead, and the native
    executive_producer sheet adds two product/governance gates.
    """
    expected = {
        "game_design_lead": {
            "gamestring_localization_contract_review",
            "cross_function_handoff_review",
            "ui_review_iteration_verdict",
            "ui_visual_guideline_binding_review",
            "game_ui_wireframe_structure_review",
        },
        "art_lead": {
            "animation_asset_prompt_review",
            "rigging_prep_handoff_review",
            "art_consistency_review",
        },
        "program_lead": {
            "rawdata_pipeline_check",
            "godot_2d_responsive_layout_review",
            "godot_2d_responsive_layout_general_review",
        },
        "qa_lead": {
            "game_ui_ux_audit_verdict",
        },
        "orchestrator": {
            "contract_check_review",
            "doc_sync_review",
            "multi_agent_preflight_review",
            "os_pack_invocation_plan_review",
            "os_pack_resource_routing_review",
            "subagent_routing_gate_review",
            "task_breakdown_review",
        },
        "executive_producer": {
            "product_scope_priority_gate",
            "milestone_go_no_go_gate",
        },
    }
    for lead, expected_ids in expected.items():
        data = _load(LEADS_DIR / f"{lead}.capability.json")
        actual_ids = {c["capability_id"] for c in data["capabilities"]}
        assert actual_ids == expected_ids
        for cap in data["capabilities"]:
            assert cap["emits_verdict"] == "os_verdict"


def test_orchestrator_can_route_os_and_pack_resources():
    data = _load(LEADS_DIR / "orchestrator.capability.json")
    caps = {c["capability_id"]: c for c in data["capabilities"]}

    routing = caps["os_pack_resource_routing_review"]
    routing_text = " ".join(
        [routing["judges"], routing["notes"], *routing["handoff_on_fix"]]
    )
    for expected in (
        "OS-layer",
        "pack-layer",
        "control-plane Leads",
        "pack agents",
        "pack skills",
        "workflow",
        "validation scripts",
        "runtime adapter",
        ".dev_os_meta FixOps",
    ):
        assert expected in routing_text

    invocation = caps["os_pack_invocation_plan_review"]
    invocation_text = " ".join(
        [invocation["judges"], invocation["notes"], *invocation["handoff_on_fix"]]
    )
    for expected in (
        "gdd_orchestrator_skill",
        "end_to_end_delivery_workflow.json",
        "generate_agent_run_plan.py",
        "RUNTIME_ADAPTER_SPEC.md",
        "write-boundary",
    ):
        assert expected in invocation_text


def test_executive_producer_is_native_control_sheet():
    data = _load(LEADS_DIR / "executive_producer.capability.json")
    assert data["discipline"] is None
    caps = {c["capability_id"]: c for c in data["capabilities"]}
    assert set(caps) == {"product_scope_priority_gate", "milestone_go_no_go_gate"}
    for cap in caps.values():
        assert "migrated_from" not in cap
        assert cap["emits_verdict"] == "os_verdict"
    assert "orchestrator" in " ".join(caps["product_scope_priority_gate"]["handoff_on_fix"])


def test_lead_capability_provenance_resolves_to_migrated_map_entries():
    rc, out, err = _run_validator([
        "--repo-root", str(PKG_ROOT),
        "--map", str(MIGRATION_MAP),
    ])
    assert rc == 0, f"rc={rc} err={err}\n{out}"
    assert "provenance: 17 migrated_from claim(s) checked" in out


# ---------- the verdict-authority firewall ---------------------------------

def _valid_verdict():
    return {
        "schema_version": "1.0.0",
        "verdict_id": "osv_12345678",
        "created_at": "2026-06-02T00:00:00Z",
        "verdict_owner": "os_control_plane",
        "reviewed_by": "program_lead",
        "subject_pack_id": "data_pipeline_pack",
        "evidence_refs": ["ev_ec84bd1b"],
        "os_verdict": "pass",
    }


def test_pack_self_verdict_owner_rejected_by_schema():
    jsonschema = pytest.importorskip("jsonschema")
    bad = _valid_verdict()
    bad["verdict_owner"] = "data_pipeline_pack"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(OSV_SCHEMA))


def test_pack_reviewing_itself_rejected_by_validator(tmp_path):
    bad = _valid_verdict()
    bad["reviewed_by"] = "data_pipeline_pack"  # reviewer == subject
    f = tmp_path / "bad.os_verdict.json"
    f.write_text(json.dumps(bad))
    rc, out, err = _run_validator(
        ["--repo-root", str(PKG_ROOT), "--verdict", str(f)])
    assert rc == 1, f"a pack reviewing itself must be a violation; rc={rc}"
    assert "review its own work" in out


def test_unknown_reviewer_rejected_by_validator(tmp_path):
    bad = _valid_verdict()
    bad["reviewed_by"] = "external_reviewer"
    f = tmp_path / "unknown_reviewer.os_verdict.json"
    f.write_text(json.dumps(bad))
    rc, out, err = _run_validator(
        ["--repo-root", str(PKG_ROOT), "--verdict", str(f)])
    assert rc == 1
    assert "not a known control-plane reviewer" in out


def test_lead_capability_id_can_review(tmp_path):
    v = _valid_verdict()
    v["reviewed_by"] = "rawdata_pipeline_check"
    f = tmp_path / "capability_reviewer.os_verdict.json"
    f.write_text(json.dumps(v))
    rc, out, err = _run_validator(
        ["--repo-root", str(PKG_ROOT), "--verdict", str(f)])
    assert rc == 0, f"Lead capability reviewer should resolve; rc={rc}\n{out}\n{err}"
    assert "clean" in out


def test_lead_capability_must_emit_os_verdict():
    jsonschema = pytest.importorskip("jsonschema")
    bad = {
        "schema_version": "1.0.0", "lead_id": "program_lead",
        "discipline": "program", "plane": "control",
        "capabilities": [{
            "capability_id": "x", "title": "x", "judges": "y",
            "consumes_evidence": ["markdown_report"],
            "emits_verdict": "pack_self_attestation",
        }],
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(LC_SCHEMA))


def test_dangling_evidence_ref_is_violation(tmp_path):
    v = _valid_verdict()
    v["evidence_refs"] = ["ev_00000000"]  # no such evidence
    f = tmp_path / "v.os_verdict.json"
    f.write_text(json.dumps(v))
    # empty evidence dir -> the ref resolves to nothing.
    edir = tmp_path / "ev"
    edir.mkdir()
    rc, out, err = _run_validator(
        ["--repo-root", str(PKG_ROOT), "--verdict", str(f),
         "--evidence-dir", str(edir)])
    assert rc == 1
    assert "resolves to no pack evidence" in out


# ---------- the real committed verdict -------------------------------------

def test_real_verdict_valid_and_resolves():
    assert REAL_VERDICT.is_file(), "the B6 demo os_verdict must be committed"
    rc, out, err = _run_validator(
        ["--repo-root", str(PKG_ROOT), "--verdict", str(REAL_VERDICT),
         "--evidence-dir", str(SLICE_EVIDENCE)])
    assert rc == 0, f"rc={rc} out={out} err={err}"
    v = _load(REAL_VERDICT)
    assert v["verdict_owner"] == "os_control_plane"
    assert v["reviewed_by"] == "program_lead"
    assert v["reviewed_by"] != v["subject_pack_id"]
    assert v["os_verdict"] == "pass"


# ---------- zero-dep proof -------------------------------------------------

def test_runs_under_bare_interpreter():
    if not Path(_BARE).exists():
        pytest.skip("bare managed interpreter not present")
    rc, out, err = _run_validator(["--repo-root", str(PKG_ROOT)], python=_BARE)
    assert rc == 0, f"bare run failed: {err}"
    assert "clean" in out
