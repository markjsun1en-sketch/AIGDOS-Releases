"""test_capability_contracts_schema.py — v4.92 Batch 1 (P0-1/2/3).

Self-tests for the Capability Protocol Layer contracts under
``capability_protocols/``:

    - capability_pack.schema.json   (P0-1)
    - agent_contract.schema.json    (P0-2)
    - skill_contract.schema.json    (P0-3)

For each schema:
    1. the schema is itself draft-07 valid
    2. a representative VALID instance is accepted
    3. a representative INVALID instance is rejected
       (proves required[] / conditional allOf rules actually bite)

Plus structural cross-checks:
    4. every schema declares additionalProperties:false and the
       v4.92 contract conventions ($id under capability_protocols/,
       schema_version const 1.0.0)
    5. the anti-virtual firewall fields are mandatory where the
       roadmap requires them (agent non_completion_conditions /
       completion_evidence; skill validation_commands /
       non_completion_conditions / example_task).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
from pathlib import Path

import jsonschema
import pytest

REPO_ROOT = Path(__file__).resolve().parents[1].parent
PROTO_DIR = REPO_ROOT / "capability_protocols"

PACK_SCHEMA = PROTO_DIR / "capability_pack.schema.json"
AGENT_SCHEMA = PROTO_DIR / "agent_contract.schema.json"
SKILL_SCHEMA = PROTO_DIR / "skill_contract.schema.json"

ALL_SCHEMAS = {
    "capability_pack": PACK_SCHEMA,
    "agent_contract": AGENT_SCHEMA,
    "skill_contract": SKILL_SCHEMA,
}


def _load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


# --------------------------------------------------------------------------
# 1. schemas are draft-07 valid
# --------------------------------------------------------------------------
@pytest.mark.parametrize("name", sorted(ALL_SCHEMAS))
def test_schema_is_draft07_valid(name):
    jsonschema.Draft7Validator.check_schema(_load(ALL_SCHEMAS[name]))


# --------------------------------------------------------------------------
# 4. structural conventions
# --------------------------------------------------------------------------
@pytest.mark.parametrize("name", sorted(ALL_SCHEMAS))
def test_schema_conventions(name):
    schema = _load(ALL_SCHEMAS[name])
    assert schema["$schema"] == "http://json-schema.org/draft-07/schema#"
    assert schema["$id"].startswith(
        "https://ai-dev-os.local/v4.92/capability_protocols/"
    ), f"{name} $id not under v4.92 capability_protocols namespace"
    assert schema["additionalProperties"] is False
    assert schema["properties"]["schema_version"]["const"] == "1.0.0"


# --------------------------------------------------------------------------
# Valid example instances
# --------------------------------------------------------------------------
VALID_PACK = {
    "schema_version": "1.0.0",
    "pack_id": "data_pipeline_pack",
    "version": "0.1.0",
    "layer": "game_system_pack",
    "lifecycle_status": "beta",
    "engine_support": ["godot_2d"],
    "allowed_writes": ["game/data/json/**", "game/data/tres/**"],
    "forbidden_writes": ["AI_Game_Dev_OS_Core/**", "project.godot"],
    "validation": {"smoke": ["python scripts/validate_data_pipeline_pack.py"]},
}

VALID_AGENT = {
    "schema_version": "1.0.0",
    "agent_id": "godot_gameplay_engineer",
    "layer": "production_agent",
    "discipline": "program",
    "consults_disciplines": ["game_design", "qa"],
    "primary_pack": "data_pipeline_pack",
    "status": "beta",
    "owns": ["xlsx->json import pipeline"],
    "can_modify": ["game/data/json/**"],
    "must_not_modify": ["AI_Game_Dev_OS_Core/**", "project.godot"],
    "required_inputs": ["feature_brief.md", "xlsx source tables"],
    "required_outputs": ["regenerated json", "validation result"],
    "completion_evidence": ["validation command result attached"],
    "non_completion_conditions": ["only a markdown plan is produced"],
}

VALID_SKILL = {
    "schema_version": "1.0.0",
    "skill_id": "xlsx_to_json_import",
    "pack_id": "data_pipeline_pack",
    "status": "beta",
    "execution_level": "production_execution",
    "use_when": ["a designer changed an xlsx source table"],
    "required_inputs": ["game/data/xlsx/*.xlsx", "schema files"],
    "allowed_writes": ["game/data/json/**"],
    "forbidden_writes": ["AI_Game_Dev_OS_Core/**"],
    "required_outputs": ["regenerated json", "import report"],
    "execution_steps": ["read xlsx", "map types", "write json", "validate"],
    "validation_commands": ["python scripts/validate_data_pipeline_pack.py"],
    "failure_handling": ["on schema mismatch, emit conflict report and halt"],
    "non_completion_conditions": ["no validation result is provided"],
    "example_task": {
        "input": "heroes.xlsx edited",
        "expected_output": "heroes.json regenerated + passing validation",
    },
    "completion_evidence": ["generated_config", "rollback_note"],
    "rollback_policy": {"required": True, "output": ".ai_dev_os/rollback_notes/"},
}

VALID_INSTANCES = {
    "capability_pack": (PACK_SCHEMA, VALID_PACK),
    "agent_contract": (AGENT_SCHEMA, VALID_AGENT),
    "skill_contract": (SKILL_SCHEMA, VALID_SKILL),
}


# --------------------------------------------------------------------------
# 2. valid instances accepted
# --------------------------------------------------------------------------
@pytest.mark.parametrize("name", sorted(VALID_INSTANCES))
def test_valid_instance_accepted(name):
    schema_path, instance = VALID_INSTANCES[name]
    jsonschema.validate(instance, _load(schema_path))


# --------------------------------------------------------------------------
# 3. invalid instances rejected (required[] / conditional bite)
# --------------------------------------------------------------------------
def test_pack_missing_validation_rejected():
    bad = dict(VALID_PACK)
    del bad["validation"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(PACK_SCHEMA))


def test_pack_adapter_without_engine_support_rejected():
    bad = dict(VALID_PACK)
    bad["layer"] = "engine_adapter"
    bad.pop("engine_support")
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(PACK_SCHEMA))


def test_pack_deprecated_without_reason_rejected():
    bad = dict(VALID_PACK)
    bad["lifecycle_status"] = "deprecated"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(PACK_SCHEMA))


def test_agent_missing_non_completion_rejected():
    bad = dict(VALID_AGENT)
    del bad["non_completion_conditions"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(AGENT_SCHEMA))


def test_agent_production_without_primary_pack_rejected():
    bad = dict(VALID_AGENT)
    bad.pop("primary_pack")
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(AGENT_SCHEMA))


def test_agent_missing_discipline_rejected():
    bad = dict(VALID_AGENT)
    del bad["discipline"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(AGENT_SCHEMA))


def test_agent_discipline_must_be_single_value():
    bad = dict(VALID_AGENT)
    bad["discipline"] = ["program", "qa"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(AGENT_SCHEMA))


def test_agent_consults_disciplines_enum_rejected():
    bad = dict(VALID_AGENT)
    bad["consults_disciplines"] = ["program", "marketing"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(AGENT_SCHEMA))


def test_skill_missing_validation_commands_rejected():
    bad = dict(VALID_SKILL)
    del bad["validation_commands"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(SKILL_SCHEMA))


def test_skill_production_execution_without_rollback_required_rejected():
    bad = dict(VALID_SKILL)
    bad["rollback_policy"] = {"required": False}
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(SKILL_SCHEMA))


def test_skill_evidence_mismatch_rejected():
    # a production_execution skill may not claim a doc-only evidence kind.
    bad = dict(VALID_SKILL)
    bad["completion_evidence"] = ["spec_doc"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, _load(SKILL_SCHEMA))


def test_skill_old_ladder_value_rejected():
    # the retired writes-capability ladder values must not be accepted.
    for bad_level in ("implement", "scaffold", "refactor_optimize"):
        bad = dict(VALID_SKILL)
        bad["execution_level"] = bad_level
        with pytest.raises(jsonschema.ValidationError):
            jsonschema.validate(bad, _load(SKILL_SCHEMA))


# --------------------------------------------------------------------------
# 5. anti-virtual firewall fields are mandatory
# --------------------------------------------------------------------------
def test_agent_anti_virtual_fields_required():
    schema = _load(AGENT_SCHEMA)
    req = set(schema["required"])
    assert {"completion_evidence", "non_completion_conditions"} <= req
    assert "discipline" in req


def test_skill_practicality_minimum_required():
    schema = _load(SKILL_SCHEMA)
    req = set(schema["required"])
    assert {
        "required_inputs",
        "allowed_writes",
        "forbidden_writes",
        "required_outputs",
        "validation_commands",
        "failure_handling",
        "non_completion_conditions",
        "example_task",
        "completion_evidence",
    } <= req
