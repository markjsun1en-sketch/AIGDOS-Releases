"""test_consistency_aggregate.py — v4.90 Batch 14 Step 14.8.

4 tests covering scripts/governance/check_consistency_aggregate.py:
    1. The aggregate script exists and is executable
    2. End-to-end run on the clean tree exits 0
    3. --check NAME runs only the named check
    4. --format json returns a top-level object with 6 results

v4.91 Batch 14.19 — migrated from plain ``subprocess.run`` to
``run_pg_safe_to_file_v2`` (file-capture + PG cleanup-on-exit) so
the test-side helper is immune to the same fan-out / pipe-deadlock /
grandchild-leak hazards the gate runner itself defends against.

v4.91 Hygiene-1 c2 (2026-05-29) —
* deduplicated the 4 test bodies (the 2026-05-25 edit accidentally
  appended a verbatim copy of every test; pytest was only ever
  executing the second copy);
* added ``jsonschema`` availability guards to
  ``test_aggregate_clean_state_exits_zero`` and
  ``test_json_format_returns_six_results``. Step 5 of the aggregate
  (schema_self_validation) shells out to ``python3 -m pytest …`` —
  the literal ``python3`` is resolved against ``$PATH`` inside
  ``check_consistency_aggregate.py``, NOT against
  ``sys.executable`` of the calling pytest. So the skip decision
  must probe the **PATH-resolved** ``python3`` for ``jsonschema``,
  not whatever interpreter launched this test. When ``jsonschema``
  is importable in the PATH ``python3`` the sub-process collects 16
  cases and exits 0; when it is NOT importable (e.g. macOS managed-
  Python builds whose ``rpds`` C-extension fails the codesign Team-
  ID check) the sub-process exits 5 ("no tests collected") and the
  aggregate surfaces overall=1. That outcome does not represent a
  tree regression, so the two whole-tree tests are skipped in that
  environment rather than being expected-to-fail.

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1].parent
SCRIPT = REPO_ROOT / "scripts" / "governance" / "check_consistency_aggregate.py"

if str(REPO_ROOT / "scripts" / "governance") not in sys.path:
    sys.path.insert(0, str(REPO_ROOT / "scripts" / "governance"))

from _process_runner import run_pg_safe_to_file_v2  # noqa: E402


def _path_python_has_jsonschema() -> bool:
    """Probe the PATH-resolved ``python3`` for jsonschema importability.

    The aggregate sub-runner spawns ``python3 -m pytest …`` literally;
    the resolved interpreter is whatever ``$PATH`` returns first, NOT
    ``sys.executable``. So we shell out to that same interpreter and
    attempt a real import. A subprocess return code of 0 means the
    sub-pytest will collect the 16 jsonschema tests; non-zero means it
    will exit 5 (no tests collected) and the aggregate will surface
    overall=1.
    """
    py = shutil.which("python3")
    if py is None:
        return False
    try:
        proc = subprocess.run(
            [py, "-c", "import jsonschema"],
            capture_output=True,
            timeout=10,
        )
    except (subprocess.TimeoutExpired, OSError):
        return False
    return proc.returncode == 0


_JSONSCHEMA_AVAILABLE = _path_python_has_jsonschema()

_SKIP_REASON = (
    "jsonschema not importable in PATH-resolved python3; aggregate "
    "step 5 (schema_self_validation) sub-pytest will exit 5 (no "
    "tests collected) and the aggregate will surface overall=1. "
    "That is an environment artefact, not a tree regression."
)


@dataclass
class _Proc:
    returncode: int
    stdout: str
    stderr: str


def _run(args: list[str], timeout: int = 240) -> _Proc:
    cmd = [sys.executable, str(SCRIPT), *args]
    with tempfile.TemporaryDirectory(prefix="agg_test_") as td:
        tmp = Path(td)
        r = run_pg_safe_to_file_v2(
            cmd,
            cwd=str(REPO_ROOT),
            timeout=timeout,
            stdout_path=tmp / "stdout",
            stderr_path=tmp / "stderr",
            cleanup_process_group_on_exit=True,
        )
    return _Proc(returncode=r.rc, stdout=r.stdout, stderr=r.stderr)


def test_aggregate_script_exists():
    assert SCRIPT.is_file(), f"{SCRIPT} missing"
    # Quick sanity: the file declares the 6 checks
    text = SCRIPT.read_text(encoding="utf-8")
    for name in [
        "layer_1",
        "v4_89",
        "alignment",
        "alias",
        "required_regressions",
        "schema_self_validation",
    ]:
        assert f'"{name}"' in text, f"check {name!r} not declared in CHECKS"


@pytest.mark.skipif(not _JSONSCHEMA_AVAILABLE, reason=_SKIP_REASON)
def test_aggregate_clean_state_exits_zero():
    proc = _run([])
    assert proc.returncode == 0, (
        f"aggregate should exit 0 on clean tree; stderr={proc.stderr[-500:]}"
    )
    assert "All consistency checks passed" in proc.stdout


def test_check_filter_runs_only_named_check():
    proc = _run(["--check", "alias"])
    assert proc.returncode == 0
    # Only 1 check entry should appear (the script numbers from "1.")
    body = proc.stdout
    assert "Naming alias catalog" in body
    # Other check labels must NOT appear
    assert "Layer 1 separation" not in body
    assert "State machine doc-schema alignment" not in body


@pytest.mark.skipif(not _JSONSCHEMA_AVAILABLE, reason=_SKIP_REASON)
def test_json_format_returns_six_results():
    proc = _run(["--format", "json"])
    assert proc.returncode == 0
    payload = json.loads(proc.stdout)
    assert "overall" in payload
    assert isinstance(payload["results"], list)
    assert len(payload["results"]) == 6
    names = [r["name"] for r in payload["results"]]
    # v4.90.7: schema_self_validation is now position 5 (before
    # required_regressions) so the pure-pytest sub-suite runs ahead
    # of the regressions router. See module docstring of
    # scripts/governance/check_consistency_aggregate.py for the
    # external-sandbox subprocess-stability rationale.
    assert names == [
        "layer_1",
        "v4_89",
        "alignment",
        "alias",
        "schema_self_validation",
        "required_regressions",
    ]
