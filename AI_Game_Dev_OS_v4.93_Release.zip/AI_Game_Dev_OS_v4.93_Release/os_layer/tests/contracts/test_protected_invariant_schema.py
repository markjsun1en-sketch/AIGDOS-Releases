"""test_protected_invariant_schema.py — v4.90 Batch 14 Step 14.8.

Validate the Protected Behavior Contract registry under
``runtime/protected_contracts/protected_regression_matrix.yaml``
against ``schemas/contracts/protected_invariant.schema.json`` and
``schemas/contracts/protected_regression_matrix.schema.json``.

5 tests:
    1. protected_invariant.schema.json is itself draft-07 valid
    2. matrix yaml conforms to protected_regression_matrix schema
       (with the inv_schema inlined to bypass cross-file $ref
       resolution)
    3. all 8 active invariants carry the required fields
       (schema_version / id / status / owner / behavior /
        trigger_files / required_validation)
       — 7 from v4.90 RC3 Phase 1 + inv_008 added in v4.91 Addendum-C
       (subagent-routing-gate delegation_decision_ledger).
    4. each invariant id matches the inv_NNN_<snake>$ pattern
    5. each invariant has at least one trigger_files glob

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import jsonschema
import pytest  # noqa: F401  (imported for future parametrization slots)

REPO_ROOT = Path(__file__).resolve().parents[1].parent
sys.path.insert(0, str(REPO_ROOT))

from scripts.governance._yaml_subset import load_yaml_file  # noqa: E402

INV_SCHEMA_PATH = REPO_ROOT / "schemas" / "contracts" / "protected_invariant.schema.json"
MATRIX_SCHEMA_PATH = REPO_ROOT / "schemas" / "contracts" / "protected_regression_matrix.schema.json"
MATRIX_YAML_PATH = REPO_ROOT / "runtime" / "protected_contracts" / "protected_regression_matrix.yaml"

INV_ID_PATTERN = re.compile(r"^inv_\d{3}_[a-z0-9_]+$")
REQUIRED_INV_KEYS = {
    "schema_version",
    "id",
    "status",
    "owner",
    "behavior",
    "trigger_files",
    "required_validation",
}


def _inv_schema():
    return json.loads(INV_SCHEMA_PATH.read_text(encoding="utf-8"))


def _matrix_schema_inlined():
    """Inline the protected_invariant ref so jsonschema.validate doesn't need
    a network resolver for $id-based lookup."""
    mat = json.loads(MATRIX_SCHEMA_PATH.read_text(encoding="utf-8"))
    mat["properties"]["invariants"]["items"] = _inv_schema()
    return mat


def _load_matrix():
    return load_yaml_file(MATRIX_YAML_PATH)


def test_protected_invariant_schema_is_draft07_valid():
    schema = _inv_schema()
    jsonschema.Draft7Validator.check_schema(schema)


def test_matrix_yaml_passes_schema():
    matrix = _load_matrix()
    schema = _matrix_schema_inlined()
    jsonschema.validate(matrix, schema)


def test_all_invariants_have_required_keys():
    matrix = _load_matrix()
    invariants = matrix["invariants"]
    assert len(invariants) == 15, f"expected 15 active invariants, got {len(invariants)}"
    for inv in invariants:
        missing = REQUIRED_INV_KEYS - set(inv.keys())
        assert not missing, f"{inv.get('id', '?')} missing required keys: {missing}"


def test_all_invariant_ids_match_pattern():
    matrix = _load_matrix()
    for inv in matrix["invariants"]:
        assert INV_ID_PATTERN.fullmatch(inv["id"]), (
            f"invariant id {inv['id']!r} does not match {INV_ID_PATTERN.pattern}"
        )


def test_each_invariant_has_non_empty_trigger_files():
    matrix = _load_matrix()
    for inv in matrix["invariants"]:
        triggers = inv.get("trigger_files", [])
        assert isinstance(triggers, list) and len(triggers) >= 1, (
            f"{inv['id']} must declare at least one trigger_files glob"
        )
        for pat in triggers:
            assert isinstance(pat, str) and pat.strip(), (
                f"{inv['id']} has an empty/non-string trigger pattern: {pat!r}"
            )
