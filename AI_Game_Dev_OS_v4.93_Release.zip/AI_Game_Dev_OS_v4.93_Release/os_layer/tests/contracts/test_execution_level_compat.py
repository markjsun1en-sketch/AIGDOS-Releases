"""test_execution_level_compat.py — v4.92 reopen B4 (Contract Compatibility).

Validates the B4 redefinition of skill_contract.execution_level from a
writes-capability ladder (advice_only/scaffold/implement/refactor_optimize)
to an output-nature axis (production_execution/spec_generation/review_only/
validation_execution/advice_only), plus the new completion_evidence field
and its per-execution_level allOf constraints.

This is the §4 backward-compatibility matrix from the B4 design note:

 1. The shipped pack contracts validate after the implement->
    production_execution remap and B8 design_data migration.
 2. Each new output-nature kind has a legal fixture that validates AND a
    non-production kind needs no rollback_policy (the whole point: document-
    type skills migrate without being mis-judged 'not productive').
 3. The retired ladder values (implement/scaffold/refactor_optimize) are
    REJECTED (anti-regression — no quiet return of the old axis).
 4. completion_evidence is required, and its allowed kinds are constrained
    per execution_level: a review_only claiming modified_source is REJECTED;
    a production_execution claiming spec_doc is REJECTED.
 5. production_execution still forces rollback_policy.required=true; a
    production_execution without it is REJECTED.
 6. completion_evidence enum is exactly the blueprint §204 set.

jsonschema is a soft dependency (importorskip): the schema files and fixtures
are plain JSON, so the structural facts (enums, required[]) are also checked
without jsonschema to keep a zero-dep floor.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

PKG_ROOT = Path(__file__).resolve().parents[2]
SCHEMA = PKG_ROOT / "capability_protocols" / "skill_contract.schema.json"
PACK_SKILLS = sorted((PKG_ROOT / "packs").glob("**/skills/*.json"))
FIXTURES = PKG_ROOT / "tests" / "capability" / "fixtures"

NEW_LEVELS = {
    "production_execution",
    "spec_generation",
    "review_only",
    "validation_execution",
    "advice_only",
}
OLD_LADDER = {"implement", "scaffold", "refactor_optimize"}
EVIDENCE_SET = {
    "modified_source", "generated_config", "spec_doc",
    "markdown_report", "validation_report", "rollback_note",
}


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


# ---------- zero-dep structural facts --------------------------------------

def test_schema_enum_is_output_nature_axis():
    schema = _load(SCHEMA)
    enum = set(schema["properties"]["execution_level"]["enum"])
    assert enum == NEW_LEVELS, f"execution_level enum drifted: {enum}"
    # the old ladder must be gone.
    assert not (enum & OLD_LADDER), "old ladder value leaked into enum"


def test_completion_evidence_required_and_enum():
    schema = _load(SCHEMA)
    assert "completion_evidence" in schema["required"]
    ev = schema["properties"]["completion_evidence"]
    assert set(ev["items"]["enum"]) == EVIDENCE_SET
    assert ev["minItems"] == 1


# ---------- jsonschema behavioural matrix ----------------------------------

def _schema():
    return _load(SCHEMA)


def test_shipped_pack_contracts_still_valid():
    jsonschema = pytest.importorskip("jsonschema")
    # 5 original production_execution skills + 1 migrated review_only (B5)
    # + 28 migrated B8 execution skills + 5 B11 resolved execution skills:
    #   design_data: 18 spec_generation
    #   art_asset: 9 spec_generation + 2 production_execution
    #   qa_validation: 2 validation_execution
    #   godot_2d_adapter: 2 spec_generation planner skills
    assert len(PACK_SKILLS) == 39, f"expected 39 pack skills, found {len(PACK_SKILLS)}"
    for f in PACK_SKILLS:
        d = _load(f)
        jsonschema.validate(d, _schema())
    # B8+B11 now cover all execution-plane migrated skills.
    levels = sorted(_load(f)["execution_level"] for f in PACK_SKILLS)
    assert levels.count("production_execution") == 7
    assert levels.count("review_only") == 1
    assert levels.count("spec_generation") == 29
    assert levels.count("validation_execution") == 2


@pytest.mark.parametrize("fixture,level,needs_rollback", [
    ("skill_spec_generation.json", "spec_generation", False),
    ("skill_review_only.json", "review_only", False),
    ("skill_validation_execution.json", "validation_execution", False),
    ("skill_good.json", "production_execution", True),
])
def test_legal_fixtures_validate(fixture, level, needs_rollback):
    jsonschema = pytest.importorskip("jsonschema")
    d = _load(FIXTURES / fixture)
    assert d["execution_level"] == level
    # non-production kinds carry no forced rollback (the migration enabler).
    if not needs_rollback:
        assert "rollback_policy" not in d, \
            f"{fixture} should not need rollback_policy"
    jsonschema.validate(d, _schema())


def test_old_ladder_values_rejected():
    jsonschema = pytest.importorskip("jsonschema")
    base = _load(FIXTURES / "skill_good.json")
    for bad in OLD_LADDER:
        t = dict(base)
        t["execution_level"] = bad
        with pytest.raises(jsonschema.ValidationError):
            jsonschema.validate(t, _schema())


def test_evidence_mismatch_review_claims_source_rejected():
    jsonschema = pytest.importorskip("jsonschema")
    d = _load(FIXTURES / "skill_bad_evidence_mismatch.json")
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(d, _schema())


def test_evidence_mismatch_production_claims_spec_rejected():
    jsonschema = pytest.importorskip("jsonschema")
    base = _load(FIXTURES / "skill_good.json")
    t = dict(base)
    t["completion_evidence"] = ["spec_doc"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(t, _schema())


def test_production_without_rollback_rejected():
    jsonschema = pytest.importorskip("jsonschema")
    d = _load(FIXTURES / "skill_bad_production_no_rollback.json")
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(d, _schema())


def test_non_production_kinds_need_no_rollback():
    """The core compatibility guarantee: spec/review/validation/advice skills
    validate with NO rollback_policy at all."""
    jsonschema = pytest.importorskip("jsonschema")
    for fixture in ("skill_spec_generation.json", "skill_review_only.json",
                    "skill_validation_execution.json"):
        d = _load(FIXTURES / fixture)
        assert "rollback_policy" not in d
        jsonschema.validate(d, _schema())


def test_completion_evidence_required_bites():
    jsonschema = pytest.importorskip("jsonschema")
    base = _load(FIXTURES / "skill_good.json")
    t = dict(base)
    del t["completion_evidence"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(t, _schema())
