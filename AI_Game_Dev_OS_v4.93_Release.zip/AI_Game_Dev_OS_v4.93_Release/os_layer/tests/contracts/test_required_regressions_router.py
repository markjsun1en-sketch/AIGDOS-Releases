"""test_required_regressions_router.py — v4.90 Batch 14 Step 14.8.

5 tests covering the router (scripts/governance/check_required_regressions.py):
    1. matrix yaml loads via _yaml_subset
    2. a single changed file routes to the right invariant set
    3. '**' recursive globs match nested paths
    4. multi-file change set unions hits across invariants
    5. --advisory mode exits 0 even when there are hits

v4.91 Batch 14.19 — migrated from plain ``subprocess.run`` to
``run_pg_safe_to_file_v2`` (file-capture + PG cleanup-on-exit).

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1].parent
sys.path.insert(0, str(REPO_ROOT))
if str(REPO_ROOT / "scripts" / "governance") not in sys.path:
    sys.path.insert(0, str(REPO_ROOT / "scripts" / "governance"))

from scripts.governance import check_required_regressions as router  # noqa: E402
from scripts.governance._yaml_subset import load_yaml_file  # noqa: E402
from _process_runner import run_pg_safe_to_file_v2  # noqa: E402

MATRIX_PATH = REPO_ROOT / "runtime" / "protected_contracts" / "protected_regression_matrix.yaml"
ROUTER_PATH = REPO_ROOT / "scripts" / "governance" / "check_required_regressions.py"


def test_matrix_loads_via_yaml_subset():
    matrix = load_yaml_file(MATRIX_PATH)
    assert matrix["schema_version"] == "1.0.0"
    assert isinstance(matrix["invariants"], list)
    assert len(matrix["invariants"]) == 15  # v4.91 P1-c: inv_015_preflight_advisory_not_gate
    ids = {inv["id"] for inv in matrix["invariants"]}
    assert "inv_002_layer_1_no_project_names" in ids


def test_single_file_routes_to_correct_invariant_set():
    matrix = load_yaml_file(MATRIX_PATH)
    report = router.route(matrix, ["scripts/governance/lint_layer_separation.py"])
    hit_ids = {h["id"] for h in report["hit_invariants"]}
    assert "inv_002_layer_1_no_project_names" in hit_ids
    # The lint script is NOT under any of the v4.89-baseline trigger paths
    assert "inv_001_v4_89_byte_lock_immutable" not in hit_ids


def test_recursive_glob_matches_nested_paths():
    # Patterns like 'docs/**' must catch deep paths under docs/
    matrix = load_yaml_file(MATRIX_PATH)
    report = router.route(matrix, ["docs/16_agent_library/PACK_LIFECYCLE_STATE_MODEL.md"])
    hit_ids = {h["id"] for h in report["hit_invariants"]}
    # inv_002 (Layer 1 lint) AND inv_003 (state machine alignment) both fire
    assert "inv_002_layer_1_no_project_names" in hit_ids
    assert "inv_003_state_machine_doc_schema_aligned" in hit_ids


def test_multi_file_change_set_unions_hits():
    matrix = load_yaml_file(MATRIX_PATH)
    files = [
        "config/naming_aliases.yaml",                   # → inv_005
        "schemas/protocol/capability_adoption_state.schema.json",  # → inv_002 + inv_003 + inv_006 + inv_007
    ]
    report = router.route(matrix, files)
    hit_ids = {h["id"] for h in report["hit_invariants"]}
    assert {"inv_002_layer_1_no_project_names",
            "inv_003_state_machine_doc_schema_aligned",
            "inv_005_naming_alias_catalog_valid",
            "inv_006_capability_id_pattern_intact",
            "inv_007_schema_version_const_locked"}.issubset(hit_ids)


def test_advisory_mode_exits_zero_even_with_hits():
    cmd = [
        sys.executable, str(ROUTER_PATH),
        "--advisory",
        "--files", "scripts/governance/lint_layer_separation.py",
    ]
    with tempfile.TemporaryDirectory(prefix="rrr_") as td:
        tmp = Path(td)
        r = run_pg_safe_to_file_v2(
            cmd,
            cwd=str(REPO_ROOT),
            timeout=60,
            stdout_path=tmp / "stdout",
            stderr_path=tmp / "stderr",
            cleanup_process_group_on_exit=True,
        )
    assert r.rc == 0, f"advisory mode should exit 0; stderr={r.stderr}"
    assert "advisory" in r.stdout
