"""test_checkpoint_lifecycle.py — v4.91 M-D B7 c4.

End-to-end exercise of the recovery v0 toolchain on a synthetic
host project rooted under tmp_path:

    create_checkpoint -> append envelope to index.jsonl
    list_checkpoints  -> filter / count
    generate_rollback_plan -> synthesise plan from envelope
    verify_rollback   -> diff plan vs current filesystem

Layer 1 (OS Spec). No project literals; fixtures are generic.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
RECOVERY_DIR = REPO_ROOT / "scripts" / "recovery"

CHECKPOINT_TYPES = (
    "before_core_update",
    "before_project_mount_change",
    "before_capability_adoption",
    "before_reusable_asset_standard_change",
)


def _run(*args: str, cwd: Path | None = None, expected_rc: int = 0) -> subprocess.CompletedProcess:
    cmd = [sys.executable, *args]
    res = subprocess.run(
        cmd, capture_output=True, text=True, timeout=30,
        cwd=str(cwd) if cwd else None,
    )
    if expected_rc is not None:
        assert res.returncode == expected_rc, (
            f"unexpected exit {res.returncode} (expected {expected_rc})\n"
            f"stdout={res.stdout!r}\nstderr={res.stderr!r}"
        )
    return res


def _create(tmp_root: Path, *, ctype: str, target: Path, actor: str = "smoke") -> str:
    """Run create_checkpoint and return checkpoint_id."""
    res = _run(
        str(RECOVERY_DIR / "create_checkpoint.py"),
        "--type", ctype,
        "--target-paths", str(target),
        "--actor", actor,
        "--out-index", str(tmp_root / ".ai_dev_os" / "checkpoints" / "checkpoint_index.jsonl"),
        "--repo-root", str(tmp_root),
    )
    return res.stdout.strip()


# ---------------------------------------------------------------------------
# 6. create_checkpoint happy path + index file is append-only
# ---------------------------------------------------------------------------


def test_create_checkpoint_happy_path_and_append_only(tmp_path):
    f = tmp_path / "VERSION"
    f.write_text("v0\n", encoding="utf-8")
    cp1 = _create(tmp_path, ctype="before_core_update", target=f)
    assert cp1.startswith("cp_") and len(cp1) == 11

    # second checkpoint on same file with different content
    f.write_text("v1\n", encoding="utf-8")
    cp2 = _create(tmp_path, ctype="before_core_update", target=f)
    assert cp2 != cp1

    # index file must contain both entries (append-only)
    index = tmp_path / ".ai_dev_os" / "checkpoints" / "checkpoint_index.jsonl"
    lines = [ln for ln in index.read_text(encoding="utf-8").splitlines() if ln.strip()]
    assert len(lines) == 2
    ids = [json.loads(ln)["checkpoint_id"] for ln in lines]
    assert ids == [cp1, cp2]


# ---------------------------------------------------------------------------
# 7. All four checkpoint types succeed and round-trip
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("ctype", CHECKPOINT_TYPES)
def test_all_four_checkpoint_types_succeed(tmp_path, ctype):
    f = tmp_path / "target.yaml"
    f.write_text(f"# fixture for {ctype}\n", encoding="utf-8")
    cp = _create(tmp_path, ctype=ctype, target=f)
    assert cp.startswith("cp_")

    # list_checkpoints --type ctype yields exactly 1 entry
    res = _run(
        str(RECOVERY_DIR / "list_checkpoints.py"),
        "--index", str(tmp_path / ".ai_dev_os" / "checkpoints" / "checkpoint_index.jsonl"),
        "--type", ctype,
    )
    parsed = json.loads(res.stdout)
    assert len(parsed) == 1
    assert parsed[0]["checkpoint_type"] == ctype
    assert parsed[0]["checkpoint_id"] == cp


# ---------------------------------------------------------------------------
# 8. list_checkpoints empty index returns 0 entries (rc=0)
# ---------------------------------------------------------------------------


def test_list_checkpoints_empty_index(tmp_path):
    index = tmp_path / "empty.jsonl"
    index.write_text("", encoding="utf-8")
    res = _run(str(RECOVERY_DIR / "list_checkpoints.py"), "--index", str(index))
    assert json.loads(res.stdout) == []


# ---------------------------------------------------------------------------
# 9. before_capability_adoption F-I-01 lifecycle subset roundtrip
# ---------------------------------------------------------------------------


def test_before_capability_adoption_roundtrip(tmp_path):
    """Original F-I-01 (Adoption Lifecycle Transaction) is now a single
    checkpoint_type enum value; this test verifies the roundtrip works
    end-to-end for that case.
    """
    f1 = tmp_path / "capability_state.yaml"
    f1.write_text("capability: pending\n", encoding="utf-8")
    cp = _create(tmp_path, ctype="before_capability_adoption", target=f1)

    # generate_rollback_plan
    plan_path = tmp_path / "plan.json"
    _run(
        str(RECOVERY_DIR / "generate_rollback_plan.py"),
        "--checkpoint-id", cp,
        "--index", str(tmp_path / ".ai_dev_os" / "checkpoints" / "checkpoint_index.jsonl"),
        "--out", str(plan_path),
    )
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    assert plan["readiness"] == "pending"
    assert plan["plan_only_flag"] is True
    assert plan["references_checkpoint_id"] == cp
    assert plan["steps"][0]["op_kind"] == "revert_file"

    # verify_rollback against unchanged file -> overall ready (rc=0)
    res = _run(
        str(RECOVERY_DIR / "verify_rollback.py"),
        "--plan", str(plan_path),
        "--repo-root", str(tmp_path),
        expected_rc=0,
    )
    verification = json.loads(res.stdout)
    assert verification["overall"] == "ready"
    assert verification["step_results"][0]["match"] is True


# ---------------------------------------------------------------------------
# 10. verify_rollback overall transitions: ready / partial / blocked
# ---------------------------------------------------------------------------


def test_verify_rollback_partial_and_blocked_transitions(tmp_path):
    f = tmp_path / "drifty.txt"
    f.write_text("v0\n", encoding="utf-8")
    cp = _create(tmp_path, ctype="before_project_mount_change", target=f)

    # Generate plan
    plan_path = tmp_path / "plan.json"
    _run(
        str(RECOVERY_DIR / "generate_rollback_plan.py"),
        "--checkpoint-id", cp,
        "--index", str(tmp_path / ".ai_dev_os" / "checkpoints" / "checkpoint_index.jsonl"),
        "--out", str(plan_path),
    )

    # Drift the file -> overall partial (rc=1)
    f.write_text("v1\n", encoding="utf-8")
    res = _run(
        str(RECOVERY_DIR / "verify_rollback.py"),
        "--plan", str(plan_path),
        "--repo-root", str(tmp_path),
        expected_rc=1,
    )
    assert json.loads(res.stdout)["overall"] == "partial"

    # Delete the file -> overall blocked (rc=2)
    f.unlink()
    res = _run(
        str(RECOVERY_DIR / "verify_rollback.py"),
        "--plan", str(plan_path),
        "--repo-root", str(tmp_path),
        expected_rc=2,
    )
    assert json.loads(res.stdout)["overall"] == "blocked"
