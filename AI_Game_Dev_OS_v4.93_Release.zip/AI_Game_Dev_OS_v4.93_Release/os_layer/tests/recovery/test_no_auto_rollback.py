"""test_no_auto_rollback.py — v4.91 M-D B7 c4.

Compile-time guards for inv_009_no_auto_rollback_execution. These
tests catch any future drift toward an enforcement / auto-apply
posture in the recovery v0 toolchain (Charter anti-pattern #7
+ #11).

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
RECOVERY_DIR = REPO_ROOT / "scripts" / "recovery"
PLAN_SCHEMA = REPO_ROOT / "schemas" / "recovery" / "rollback_plan.schema.json"


# ---------------------------------------------------------------------------
# 11. No script under scripts/recovery/ defines an --apply / --execute
# / --auto-apply argparse flag.
# ---------------------------------------------------------------------------


_FORBIDDEN_FLAG_RE = re.compile(
    r'add_argument\(\s*"\s*-{1,2}(apply|execute|auto[\-_]apply|run|do[\-_]apply)\b',
    re.IGNORECASE,
)


def test_no_apply_flag_in_recovery_scripts():
    offenders: list[tuple[Path, int, str]] = []
    for py in RECOVERY_DIR.rglob("*.py"):
        text = py.read_text(encoding="utf-8")
        for m in _FORBIDDEN_FLAG_RE.finditer(text):
            line = text.count("\n", 0, m.start()) + 1
            offenders.append((py.relative_to(REPO_ROOT), line, m.group(0)))
    assert not offenders, (
        f"Charter anti-pattern #7 violation — scripts/recovery/* defines "
        f"a forbidden execution flag: {offenders}"
    )


# ---------------------------------------------------------------------------
# 12. rollback_plan.schema.json keeps plan_only_flag const true.
# ---------------------------------------------------------------------------


def test_plan_only_flag_const_true_at_source():
    schema = json.loads(PLAN_SCHEMA.read_text(encoding="utf-8"))
    flag = schema["properties"]["plan_only_flag"]
    assert flag.get("const") is True, (
        f"plan_only_flag const must remain literal True; got {flag.get('const')!r}"
    )


# ---------------------------------------------------------------------------
# 13. No source under scripts/recovery/ contains the words
# "auto_apply" / "auto-execute" / "auto rollback execution".
# ---------------------------------------------------------------------------


_FORBIDDEN_TOKENS = (
    "auto_apply",
    "auto-apply",
    "auto_execute",
    "auto-execute",
    "automatic_rollback",
    "auto rollback execution",
    "automatic rollback execution",
)


def test_no_auto_execute_keyword_in_source():
    offenders: list[tuple[Path, int, str]] = []
    for py in RECOVERY_DIR.rglob("*.py"):
        text = py.read_text(encoding="utf-8")
        # Only look for the token in code/string-literal context, but to
        # keep the guard ruthless, just scan the text. The skill text
        # explicitly disclaims auto-rollback in negative phrases ("never
        # auto-applies"), and the test's own pattern ("auto_apply") is
        # therefore allowed only inside comment / docstring lines that
        # explicitly negate it. The test below filters for that.
        for ln_no, line in enumerate(text.splitlines(), start=1):
            stripped = line.strip()
            for tok in _FORBIDDEN_TOKENS:
                if tok in stripped.lower():
                    # Allow lines that explicitly negate the token
                    # (e.g. "never auto_apply", "no auto-apply",
                    # "no auto rollback execution").
                    lowered = stripped.lower()
                    if any(
                        neg in lowered
                        for neg in ("never ", "no ", "without ", "not ", "forbid", "anti-pattern", "no auto", "no escape")
                    ):
                        continue
                    offenders.append((py.relative_to(REPO_ROOT), ln_no, tok))
    assert not offenders, (
        f"Charter anti-pattern #7 violation — scripts/recovery/* mentions "
        f"a forbidden auto-rollback token without negation: {offenders}"
    )


# ---------------------------------------------------------------------------
# 14. verify_rollback never imports any module that mutates the
# filesystem under repo root (smoke check on the import surface).
# ---------------------------------------------------------------------------


def test_verify_rollback_never_imports_shutil_rmtree():
    """Belt-and-braces import-surface guard: verify_rollback must not
    pull in mutation primitives (shutil.rmtree, os.remove, os.unlink,
    pathlib.Path.unlink, pathlib.Path.write_text, etc.) at the module
    top level.

    The test is a textual scan: the source must not contain
    ``shutil`` / ``os.remove`` / ``os.unlink`` / ``.unlink(`` /
    ``.write_text(`` / ``.write_bytes(`` references in a way that
    suggests mutation. Pure-read primitives (open(..., 'r'), pathlib
    .read_text, etc.) are fine.
    """
    src = (RECOVERY_DIR / "verify_rollback.py").read_text(encoding="utf-8")
    forbidden = (
        "shutil.rmtree",
        "os.remove(",
        "os.unlink(",
        "rmtree(",
    )
    hits: list[str] = []
    # The verifier IS allowed to write its OWN output document via
    # --out PATH (Path.write_text). That single allowed write surface
    # is the verification doc itself, not any path under the
    # repo-root. The compile guard below rules out filesystem mutation
    # primitives that would be needed for actual rollback execution.
    for tok in forbidden:
        if tok in src:
            hits.append(tok)
    assert not hits, (
        f"verify_rollback.py imports / calls a mutation primitive: "
        f"{hits}. The verifier must remain read-only on the host "
        f"tree (Charter anti-pattern #7 + #11)."
    )
