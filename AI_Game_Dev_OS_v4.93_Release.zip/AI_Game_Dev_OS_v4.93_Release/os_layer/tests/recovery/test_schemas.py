"""test_schemas.py — v4.91 M-D B7 c4.

Pin the three recovery schemas (checkpoint_manifest +
rollback_plan + rollback_verification) at their v1.0.0 contract
shape: closed enums, const-locked schema_version + plan_only_flag,
ID patterns, additionalProperties refusal.

Layer 1 (OS Spec). No project names; fixtures use opaque
``cp_aaaaaaaa`` / ``rp_bbbbbbbb`` / ``rv_cccccccc`` placeholders.
"""
from __future__ import annotations

import json
from pathlib import Path

import jsonschema
import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = REPO_ROOT / "schemas" / "recovery"


def _load(name: str) -> dict:
    return json.loads((SCHEMA_DIR / name).read_text(encoding="utf-8"))


@pytest.fixture(scope="module")
def checkpoint_schema() -> dict:
    return _load("checkpoint_manifest.schema.json")


@pytest.fixture(scope="module")
def plan_schema() -> dict:
    return _load("rollback_plan.schema.json")


@pytest.fixture(scope="module")
def verification_schema() -> dict:
    return _load("rollback_verification.schema.json")


# ---------------------------------------------------------------------------
# 1. All three schemas pass Draft7 self-validation
# ---------------------------------------------------------------------------


def test_three_schemas_self_validate(checkpoint_schema, plan_schema, verification_schema):
    for s in (checkpoint_schema, plan_schema, verification_schema):
        jsonschema.Draft7Validator.check_schema(s)
    assert checkpoint_schema["properties"]["schema_version"]["const"] == "1.0.0"
    assert plan_schema["properties"]["schema_version"]["const"] == "1.0.0"
    assert verification_schema["properties"]["schema_version"]["const"] == "1.0.0"


# ---------------------------------------------------------------------------
# 2. checkpoint_type 4-enum closed
# ---------------------------------------------------------------------------


def test_checkpoint_type_enum_closed(checkpoint_schema):
    enum = checkpoint_schema["properties"]["checkpoint_type"]["enum"]
    assert enum == [
        "before_core_update",
        "before_project_mount_change",
        "before_capability_adoption",
        "before_reusable_asset_standard_change",
    ]


# ---------------------------------------------------------------------------
# 3. op_kind 4-enum closed
# ---------------------------------------------------------------------------


def test_op_kind_enum_closed(plan_schema):
    step_props = plan_schema["properties"]["steps"]["items"]["properties"]
    enum = step_props["op_kind"]["enum"]
    assert enum == ["revert_file", "restore_file", "remove_file", "restore_state_field"]


# ---------------------------------------------------------------------------
# 4. ID pattern locks (cp_ / rp_ / rv_)
# ---------------------------------------------------------------------------


def test_id_pattern_locks(checkpoint_schema, plan_schema, verification_schema):
    assert checkpoint_schema["properties"]["checkpoint_id"]["pattern"] == r"^cp_[0-9a-f]{8}$"
    assert plan_schema["properties"]["plan_id"]["pattern"] == r"^rp_[0-9a-f]{8}$"
    assert plan_schema["properties"]["references_checkpoint_id"]["pattern"] == r"^cp_[0-9a-f]{8}$"
    assert verification_schema["properties"]["verification_id"]["pattern"] == r"^rv_[0-9a-f]{8}$"
    assert verification_schema["properties"]["references_plan_id"]["pattern"] == r"^rp_[0-9a-f]{8}$"


# ---------------------------------------------------------------------------
# 5. plan_only_flag is const-locked literal true
# ---------------------------------------------------------------------------


def test_plan_only_flag_const_true(plan_schema):
    flag = plan_schema["properties"]["plan_only_flag"]
    assert flag["type"] == "boolean"
    assert flag["const"] is True

    # A plan claiming plan_only_flag = false MUST be rejected by the schema.
    bad_plan = {
        "schema_version": "1.0.0",
        "plan_id": "rp_aaaaaaaa",
        "references_checkpoint_id": "cp_bbbbbbbb",
        "generated_at": "2026-05-25T00:00:00Z",
        "source_layer": "L2",
        "readiness": "pending",
        "plan_only_flag": False,
        "steps": [{
            "order": 0,
            "op_kind": "revert_file",
            "path": "VERSION",
            "expected_sha256_after": "0" * 64,
        }],
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad_plan, plan_schema, cls=jsonschema.Draft7Validator)
