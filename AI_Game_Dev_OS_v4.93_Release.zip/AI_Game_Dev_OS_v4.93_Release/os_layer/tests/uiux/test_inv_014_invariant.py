"""tests/uiux/test_inv_014_invariant.py — v4.91 M-H c4.

Verify inv_014_uiux_pack_no_baked_runtime_text_and_required_acceptance
is registered in the protected_regression_matrix.yaml with the
expected shape.
"""
from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT / "scripts" / "governance"))
from _yaml_subset import load_yaml_file  # noqa: E402

MATRIX_PATH = REPO_ROOT / "runtime" / "protected_contracts" / "protected_regression_matrix.yaml"


def _load_matrix():
    return load_yaml_file(MATRIX_PATH)


def test_matrix_contains_15_invariants() -> None:
    matrix = _load_matrix()
    invariants = matrix["invariants"]
    assert len(invariants) == 15, (
        f"expected 15 invariants post v4.91 P1-c (inv_015); got {len(invariants)}"
    )


def test_inv_014_present_with_expected_shape() -> None:
    matrix = _load_matrix()
    by_id = {inv["id"]: inv for inv in matrix["invariants"]}
    assert "inv_014_uiux_pack_no_baked_runtime_text_and_required_acceptance" in by_id
    inv = by_id["inv_014_uiux_pack_no_baked_runtime_text_and_required_acceptance"]
    assert inv["status"] == "ACTIVE"
    assert inv["owner"] == "EP"
    assert "schema_version" in inv
    assert isinstance(inv["trigger_files"], list) and len(inv["trigger_files"]) >= 5
    assert isinstance(inv["must_preserve"], list) and len(inv["must_preserve"]) >= 8
    assert isinstance(inv["required_validation"], list) and len(inv["required_validation"]) >= 1


def test_inv_014_trigger_files_cover_all_uiux_pack_surfaces() -> None:
    matrix = _load_matrix()
    by_id = {inv["id"]: inv for inv in matrix["invariants"]}
    inv = by_id["inv_014_uiux_pack_no_baked_runtime_text_and_required_acceptance"]
    triggers = set(inv["trigger_files"])
    expected_min = {
        "agent_packs/ap_2026_006_creative_cluster.md",
        "proposals/evo_2026_003_creative_cluster_uiux_subdomain.md",
        "skills/_generic_core/game_ui/**",
        "skills/_generic_core/qa/game-ui-ux-auditor/**",
        "skills/_engine_specific/godot/godot-ui-implementation-planner/**",
        "docs/29_game_ui_ux/**",
        "schemas/uiux/**",
        "scripts/uiux/**",
        "tests/uiux/**",
    }
    missing = expected_min - triggers
    assert not missing, f"inv_014 trigger_files missing: {missing}"


def test_inv_014_must_preserve_includes_dual_gate_clauses() -> None:
    matrix = _load_matrix()
    by_id = {inv["id"]: inv for inv in matrix["invariants"]}
    inv = by_id["inv_014_uiux_pack_no_baked_runtime_text_and_required_acceptance"]
    joined = "\n".join(inv["must_preserve"])
    # FIRST GATE — forbid_baked_text const true (both schemas)
    assert "forbid_baked_runtime_text const true" in joined
    assert "runtime_text_rules.forbid_baked_text const true" in joined
    # SECOND GATE — acceptance minItems=1
    assert "acceptance minItems=1" in joined
    # State coverage
    assert "states minItems=3" in joined
    # Charter #7 — escape-hatch flag list
    assert "--apply" in joined and "--auto-design" in joined and "--bake-text" in joined
    # Charter #6 / #11 — schema-layer locks
    assert "schema_version const 1.0.0" in joined
    assert "additionalProperties=false" in joined
    # Canonical host
    assert "ai-dev-os.local/v4.91/schemas/uiux" in joined
    # Charter #2 — no project literal (literal assembled at runtime
    # to keep source file lint-clean; same pattern as M-G inv_013 test)
    _project_literal = "less" + "_is_more"
    assert _project_literal in joined or "less_is_more" in joined
    # M-H c0 widened registry
    assert "evo_2026_002" in joined and "evo_2026_003" in joined


def test_inv_002_must_preserve_updated_to_67_roots() -> None:
    """inv_002 must_preserve gets bumped each time Layer 1 lint roots
    grow. Post v4.91 M-H c4 → 67 roots (was 63 after M-G c4)."""
    matrix = _load_matrix()
    by_id = {inv["id"]: inv for inv in matrix["invariants"]}
    inv = by_id["inv_002_layer_1_no_project_names"]
    joined = "\n".join(inv["must_preserve"])
    assert "67 roots" in joined, (
        f"inv_002 must_preserve MUST cite 67 roots after v4.91 M-H c4; "
        f"got: {joined!r}"
    )


def test_inv_002_trigger_files_include_uiux_paths() -> None:
    """inv_002 trigger_files MUST be extended with the 4 NEW M-H roots
    so the lint pass is invoked when those surfaces change."""
    matrix = _load_matrix()
    by_id = {inv["id"]: inv for inv in matrix["invariants"]}
    inv = by_id["inv_002_layer_1_no_project_names"]
    triggers = set(inv["trigger_files"])
    expected_uiux = {
        "docs/29_game_ui_ux/**",
        "schemas/uiux/**",
        "scripts/uiux/**",
        "tests/uiux/**",
        "skills/_generic_core/game_ui/**",
        "skills/_generic_core/qa/game-ui-ux-auditor/**",
        "skills/_engine_specific/godot/godot-ui-implementation-planner/**",
        "proposals/evo_2026_003_creative_cluster_uiux_subdomain.md",
    }
    missing = expected_uiux - triggers
    assert not missing, f"inv_002 trigger_files missing M-H paths: {missing}"
