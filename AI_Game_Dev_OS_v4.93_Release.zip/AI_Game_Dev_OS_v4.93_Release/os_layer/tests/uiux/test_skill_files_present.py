"""tests/uiux/test_skill_files_present.py — v4.91 M-H c4.

Verify the 8 SKILL.md files referenced by ap_2026_006_creative_cluster.md
(game UI/UX sub-domain, M-H) exist at OS-grade locations and meet
structural requirements:
- front-matter `name:` matches directory name
- front-matter contains `description:`
- file contains an Acceptance / QA / Test / Implementation /
  Governance checklist section (multi-form to match the M-H source
  pack's varied gate-section conventions)
- file contains at least one gate-style section (inv_014 must_preserve)

Mirrors tests/animation/test_skill_files_present.py (M-G c4) but
accepts the multi-form gate markers used by the UI/UX source pack.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]

EXPECTED_SKILLS = [
    ("game-ui-wireframe-generator",
     "skills/_generic_core/game_ui/game-ui-wireframe-generator/SKILL.md"),
    ("battle-hud-designer",
     "skills/_generic_core/game_ui/battle-hud-designer/SKILL.md"),
    ("card-ui-prefab-spec",
     "skills/_generic_core/game_ui/card-ui-prefab-spec/SKILL.md"),
    ("game-design-system-builder",
     "skills/_generic_core/game_ui/game-design-system-builder/SKILL.md"),
    ("figma-handoff-spec",
     "skills/_generic_core/game_ui/figma-handoff-spec/SKILL.md"),
    ("ui-asset-prompt-engineer",
     "skills/_generic_core/game_ui/ui-asset-prompt-engineer/SKILL.md"),
    ("game-ui-ux-auditor",
     "skills/_generic_core/qa/game-ui-ux-auditor/SKILL.md"),
    ("godot-ui-implementation-planner",
     "skills/_engine_specific/godot/godot-ui-implementation-planner/SKILL.md"),
]

GATE_MARKERS = (
    "## Hard rules",
    "## Hard boundary",
    "## Do not use when",
    "## Required output",
    "## Use when",
    "Always produce:",
    "Required states:",
    "Priority order:",
)

ACCEPTANCE_MARKERS = (
    "Acceptance criteria",
    "Acceptance Criteria",
    "Acceptance checklist",
    "QA checklist",
    "Test checklist",
    "Implementation handoff notes",
    "Governance rules",
)

FRONT_MATTER_RE = re.compile(r"^---\n(.*?)\n---\n", re.DOTALL)


@pytest.mark.parametrize("name,rel", EXPECTED_SKILLS)
def test_skill_file_exists(name: str, rel: str) -> None:
    p = REPO_ROOT / rel
    assert p.is_file(), f"missing skill file: {rel}"


@pytest.mark.parametrize("name,rel", EXPECTED_SKILLS)
def test_skill_front_matter_name_matches_dir(name: str, rel: str) -> None:
    text = (REPO_ROOT / rel).read_text(encoding="utf-8")
    m = FRONT_MATTER_RE.match(text)
    assert m is not None, f"{rel}: missing YAML front matter"
    body = m.group(1)
    assert f"name: {name}" in body, (
        f"{rel}: front matter `name` MUST equal {name!r}"
    )


@pytest.mark.parametrize("name,rel", EXPECTED_SKILLS)
def test_skill_has_description(name: str, rel: str) -> None:
    text = (REPO_ROOT / rel).read_text(encoding="utf-8")
    m = FRONT_MATTER_RE.match(text)
    assert m is not None
    assert "description:" in m.group(1), f"{rel}: missing front-matter description"


@pytest.mark.parametrize("name,rel", EXPECTED_SKILLS)
def test_skill_has_acceptance_or_checklist_section(name: str, rel: str) -> None:
    text = (REPO_ROOT / rel).read_text(encoding="utf-8")
    matches = [m for m in ACCEPTANCE_MARKERS if m in text]
    assert matches, (
        f"{rel}: MUST contain at least one acceptance / checklist marker "
        f"({ACCEPTANCE_MARKERS!r})"
    )


@pytest.mark.parametrize("name,rel", EXPECTED_SKILLS)
def test_skill_has_gate_style_section(name: str, rel: str) -> None:
    """inv_014 must_preserve: every SKILL.md MUST declare at least
    one gate-style section so the manual-gate discipline is visible
    to the AI consumer."""
    text = (REPO_ROOT / rel).read_text(encoding="utf-8")
    matches = [g for g in GATE_MARKERS if g in text]
    assert matches, (
        f"{rel}: MUST contain at least one gate-style section "
        f"({GATE_MARKERS!r}) — Charter #6 / #11 alignment requirement"
    )
