"""tests/uiux/test_pack_schemas.py — v4.91 M-H c4.

JSON schema validation for the 4 schemas under schemas/uiux/.
inv_014 must_preserve guards the closed enums, schema-const lock,
canonical $id host, and the dual gate (forbid_baked_text const true
+ acceptance minItems=1).
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = REPO_ROOT / "schemas" / "uiux"

SCHEMAS = [
    "ui_screen_spec.schema.json",
    "card_prefab_spec.schema.json",
    "ui_design_tokens.schema.json",
    "ui_asset_prompt.schema.json",
]


@pytest.mark.parametrize("name", SCHEMAS)
def test_schema_loads_and_has_schema_version_const(name: str) -> None:
    schema = json.loads((SCHEMA_DIR / name).read_text(encoding="utf-8"))
    sv = schema["properties"]["schema_version"]
    assert sv.get("const") == "1.0.0", (
        f"{name}: schema_version MUST be const '1.0.0' (Charter #6 schema-layer lock); got {sv!r}"
    )


@pytest.mark.parametrize("name", SCHEMAS)
def test_schema_additional_properties_false_at_root(name: str) -> None:
    schema = json.loads((SCHEMA_DIR / name).read_text(encoding="utf-8"))
    assert schema.get("additionalProperties") is False, (
        f"{name}: additionalProperties MUST be false at root"
    )


@pytest.mark.parametrize("name", SCHEMAS)
def test_schema_uses_draft_07(name: str) -> None:
    schema = json.loads((SCHEMA_DIR / name).read_text(encoding="utf-8"))
    assert schema.get("$schema") == "http://json-schema.org/draft-07/schema#", (
        f"{name}: $schema MUST be draft-07 (consistent with v4.91 OS convention)"
    )


@pytest.mark.parametrize("name", SCHEMAS)
def test_schema_id_uses_canonical_v491_host(name: str) -> None:
    schema = json.loads((SCHEMA_DIR / name).read_text(encoding="utf-8"))
    sid = schema.get("$id", "")
    assert sid.startswith("https://ai-dev-os.local/v4.91/schemas/uiux/"), (
        f"{name}: $id MUST use canonical v4.91 host; got {sid!r}"
    )


# inv_014 FIRST GATE — forbid_baked_text const true.

def test_card_prefab_runtime_text_rules_forbid_baked_text_const_true() -> None:
    schema = json.loads((SCHEMA_DIR / "card_prefab_spec.schema.json").read_text(encoding="utf-8"))
    forbid = schema["properties"]["runtime_text_rules"]["properties"]["forbid_baked_text"]
    assert forbid.get("const") is True, (
        f"card_prefab_spec.runtime_text_rules.forbid_baked_text MUST be const true (inv_014 FIRST GATE); got {forbid!r}"
    )


def test_ui_asset_prompt_forbid_baked_runtime_text_const_true() -> None:
    schema = json.loads((SCHEMA_DIR / "ui_asset_prompt.schema.json").read_text(encoding="utf-8"))
    forbid = schema["properties"]["forbid_baked_runtime_text"]
    assert forbid.get("const") is True, (
        f"ui_asset_prompt.forbid_baked_runtime_text MUST be const true (inv_014 FIRST GATE); got {forbid!r}"
    )


# inv_014 SECOND GATE — acceptance minItems=1.

def test_ui_screen_spec_acceptance_min_items_1() -> None:
    schema = json.loads((SCHEMA_DIR / "ui_screen_spec.schema.json").read_text(encoding="utf-8"))
    acc = schema["properties"]["acceptance"]
    assert acc.get("minItems") == 1, (
        f"ui_screen_spec.acceptance MUST require minItems=1 (inv_014 SECOND GATE); got {acc!r}"
    )


def test_card_prefab_spec_acceptance_min_items_1() -> None:
    schema = json.loads((SCHEMA_DIR / "card_prefab_spec.schema.json").read_text(encoding="utf-8"))
    acc = schema["properties"]["acceptance"]
    assert acc.get("minItems") == 1, (
        f"card_prefab_spec.acceptance MUST require minItems=1 (inv_014 SECOND GATE); got {acc!r}"
    )


def test_ui_screen_spec_states_min_items_3() -> None:
    schema = json.loads((SCHEMA_DIR / "ui_screen_spec.schema.json").read_text(encoding="utf-8"))
    states = schema["properties"]["states"]
    assert states.get("minItems") == 3, (
        f"ui_screen_spec.states MUST require minItems=3 (state coverage gate); got {states!r}"
    )


def test_card_prefab_spec_states_min_items_3() -> None:
    schema = json.loads((SCHEMA_DIR / "card_prefab_spec.schema.json").read_text(encoding="utf-8"))
    states = schema["properties"]["states"]
    assert states.get("minItems") == 3, (
        f"card_prefab_spec.states MUST require minItems=3; got {states!r}"
    )


# Closed-enum tightness checks.

def test_ui_screen_spec_screen_role_enum_closed_12_vocabulary() -> None:
    schema = json.loads((SCHEMA_DIR / "ui_screen_spec.schema.json").read_text(encoding="utf-8"))
    enum = schema["properties"]["screen_role"]["enum"]
    expected = {
        "battle_hud", "card_collection", "deck_builder", "shop",
        "map", "settings", "victory", "defeat", "prologue",
        "tutorial", "main_menu", "other",
    }
    assert set(enum) == expected, f"ui_screen_spec screen_role enum drift: {enum!r}"


def test_ui_screen_spec_target_platforms_enum_closed_6_vocabulary() -> None:
    schema = json.loads((SCHEMA_DIR / "ui_screen_spec.schema.json").read_text(encoding="utf-8"))
    enum = schema["properties"]["target_platforms"]["items"]["enum"]
    expected = {"mobile_portrait", "mobile_landscape", "tablet", "desktop", "console", "tv"}
    assert set(enum) == expected, f"ui_screen_spec target_platforms enum drift: {enum!r}"


def test_ui_asset_prompt_asset_type_enum_closed_12_vocabulary() -> None:
    schema = json.loads((SCHEMA_DIR / "ui_asset_prompt.schema.json").read_text(encoding="utf-8"))
    enum = schema["properties"]["asset_type"]["enum"]
    assert len(enum) == 12, f"ui_asset_prompt asset_type enum MUST have 12 entries; got {len(enum)}"
    assert "icon" in enum and "card_frame" in enum and "other" in enum


def test_ui_asset_prompt_background_enum_closed_6_vocabulary() -> None:
    schema = json.loads((SCHEMA_DIR / "ui_asset_prompt.schema.json").read_text(encoding="utf-8"))
    enum = schema["properties"]["background"]["enum"]
    expected = {"transparent", "solid_dark", "solid_light", "gradient", "noise", "scene"}
    assert set(enum) == expected, f"ui_asset_prompt background enum drift: {enum!r}"


def test_card_prefab_aspect_ratio_enum_closed() -> None:
    schema = json.loads((SCHEMA_DIR / "card_prefab_spec.schema.json").read_text(encoding="utf-8"))
    enum = schema["properties"]["aspect_ratio"]["enum"]
    expected = {"2:3", "3:4", "1:1", "4:5", "5:7", "other"}
    assert set(enum) == expected, f"card_prefab aspect_ratio enum drift: {enum!r}"


def test_card_prefab_states_enum_closed_11_vocabulary() -> None:
    schema = json.loads((SCHEMA_DIR / "card_prefab_spec.schema.json").read_text(encoding="utf-8"))
    enum = schema["properties"]["states"]["items"]["enum"]
    assert len(enum) == 11, f"card_prefab states enum MUST have 11 entries; got {len(enum)}"
    assert "default" in enum and "insufficient_resource" in enum


def test_card_prefab_rarity_variants_enum_6_tier() -> None:
    schema = json.loads((SCHEMA_DIR / "card_prefab_spec.schema.json").read_text(encoding="utf-8"))
    enum = schema["properties"]["rarity_variants"]["items"]["enum"]
    expected = {"common", "uncommon", "rare", "epic", "legendary", "mythic"}
    assert set(enum) == expected, f"card_prefab rarity_variants enum drift: {enum!r}"


def test_design_tokens_meta_brand_token_pattern() -> None:
    schema = json.loads((SCHEMA_DIR / "ui_design_tokens.schema.json").read_text(encoding="utf-8"))
    pat = schema["properties"]["meta"]["properties"]["brand_token"]["pattern"]
    assert pat == "^[a-z][a-z0-9_]*$", (
        f"ui_design_tokens.meta.brand_token MUST require token-shape pattern (Charter #2 — no real brand names); got {pat!r}"
    )
