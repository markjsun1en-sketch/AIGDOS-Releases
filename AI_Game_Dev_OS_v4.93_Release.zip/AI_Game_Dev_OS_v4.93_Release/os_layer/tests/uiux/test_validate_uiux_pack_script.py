"""tests/uiux/test_validate_uiux_pack_script.py — v4.91 M-H c4.

Smoke-test the read-only validator + manifest scripts under
scripts/uiux/.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
VALIDATE_SCRIPT = REPO_ROOT / "scripts" / "uiux" / "validate_uiux_pack.py"
MANIFEST_SCRIPT = REPO_ROOT / "scripts" / "uiux" / "make_uiux_manifest.py"


def test_validate_uiux_pack_script_exists() -> None:
    assert VALIDATE_SCRIPT.is_file()


def test_validate_uiux_pack_runs_clean() -> None:
    proc = subprocess.run(
        [sys.executable, str(VALIDATE_SCRIPT)],
        capture_output=True, text=True, timeout=30,
    )
    assert proc.returncode == 0, (
        f"validator failed:\nstdout={proc.stdout}\nstderr={proc.stderr}"
    )
    assert "[OK]" in proc.stdout
    assert "8 skills" in proc.stdout
    assert "ledger" in proc.stdout
    assert "provenance" in proc.stdout


def test_make_uiux_manifest_runs_and_writes_index() -> None:
    proc = subprocess.run(
        [sys.executable, str(MANIFEST_SCRIPT)],
        capture_output=True, text=True, timeout=30,
    )
    assert proc.returncode == 0, (
        f"manifest generator failed:\nstdout={proc.stdout}\nstderr={proc.stderr}"
    )
    assert "[OK]" in proc.stdout
    out = REPO_ROOT / "docs" / "29_game_ui_ux" / "GENERATED_INDEX.md"
    assert out.is_file()
    text = out.read_text(encoding="utf-8")
    assert "agent_packs/ap_2026_006_creative_cluster.md" in text
    assert "proposals/evo_2026_003_creative_cluster_uiux_subdomain.md" in text
    # All 8 game UI/UX SKILL.md should appear in the index.
    for skill in [
        "game-ui-wireframe-generator", "battle-hud-designer",
        "card-ui-prefab-spec", "game-design-system-builder",
        "figma-handoff-spec", "ui-asset-prompt-engineer",
        "game-ui-ux-auditor", "godot-ui-implementation-planner",
    ]:
        assert skill in text, f"GENERATED_INDEX.md missing skill: {skill}"
