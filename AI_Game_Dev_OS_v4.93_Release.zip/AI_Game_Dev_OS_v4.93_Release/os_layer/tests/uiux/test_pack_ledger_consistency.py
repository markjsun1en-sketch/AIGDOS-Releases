"""tests/uiux/test_pack_ledger_consistency.py — v4.91 M-H c4.

Verify ap_2026_006_creative_cluster.md ledger entry post-M-H c1
correctly declares all 16 skills (8 animation + 8 game UI/UX),
includes the M-H exemption proposal evo_2026_003 in references[]
(in addition to the M-G evo_2026_002), and stays project-name-free
across both M-G and M-H sub-domain literals.
"""
from __future__ import annotations

import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
PACK_LEDGER = REPO_ROOT / "agent_packs" / "ap_2026_006_creative_cluster.md"
EXEMPTION_PROPOSAL_M_G = "proposals/evo_2026_002_creative_cluster_role_aliasing.md"
EXEMPTION_PROPOSAL_M_H = "proposals/evo_2026_003_creative_cluster_uiux_subdomain.md"

EXPECTED_SKILL_NAMES_UIUX = {
    "game-ui-wireframe-generator",
    "battle-hud-designer",
    "card-ui-prefab-spec",
    "game-design-system-builder",
    "figma-handoff-spec",
    "ui-asset-prompt-engineer",
    "godot-ui-implementation-planner",
    "game-ui-ux-auditor",
}

EXPECTED_SKILL_NAMES_ALL_16 = EXPECTED_SKILL_NAMES_UIUX | {
    "2d-character-motion-designer",
    "sprite-sheet-planner",
    "character-layer-splitter",
    "rigging-prep-handoff",
    "combat-animation-spec",
    "asset-prompt-animation-helper",
    "godot-2d-animation-implementer",
    "animation-qa-auditor",
}

# Forbidden tokens assembled at runtime so this source file stays
# Layer 1 lint-clean (per evo_2026_001 §Authoring discipline pattern).
FORBIDDEN_TOKENS = [
    "chi" + "ren",
    "lessis" + "more",
    "less" + "_is_more",
]


def _load_pack_text() -> str:
    return PACK_LEDGER.read_text(encoding="utf-8")


def test_pack_ledger_file_exists() -> None:
    assert PACK_LEDGER.is_file(), f"missing pack ledger: {PACK_LEDGER}"


def test_pack_ledger_cluster_is_creative_cluster() -> None:
    text = _load_pack_text()
    assert ('cluster: "creative_cluster"' in text
            or "cluster: 'creative_cluster'" in text), (
        "pack ledger MUST declare cluster='creative_cluster'"
    )


def test_pack_ledger_lists_m_h_exemption_proposal() -> None:
    """M-H exemption gate per evo_2026_003 — the proposal id MUST
    appear in references[]; the validator's
    _CLUSTER_ALIASING_EXEMPTIONS registry was widened in M-H c0 to
    accept either evo_2026_002 OR evo_2026_003. Both being listed is
    the expected steady state once both sub-domains shipped."""
    text = _load_pack_text()
    assert EXEMPTION_PROPOSAL_M_H in text, (
        f"pack ledger references[] MUST list {EXEMPTION_PROPOSAL_M_H!r} (M-H widening)"
    )


def test_pack_ledger_still_lists_m_g_exemption_proposal() -> None:
    """M-G exemption gate is preserved alongside M-H widening."""
    text = _load_pack_text()
    assert EXEMPTION_PROPOSAL_M_G in text, (
        f"pack ledger references[] MUST still list {EXEMPTION_PROPOSAL_M_G!r} (M-G baseline preserved)"
    )


def test_pack_ledger_lists_all_16_skills() -> None:
    text = _load_pack_text()
    missing = [s for s in EXPECTED_SKILL_NAMES_ALL_16 if s not in text]
    assert not missing, f"pack ledger missing skill references: {missing}"


def test_pack_ledger_lists_8_uiux_skills() -> None:
    text = _load_pack_text()
    missing = [s for s in EXPECTED_SKILL_NAMES_UIUX if s not in text]
    assert not missing, f"pack ledger missing UI/UX skill references: {missing}"


def test_pack_ledger_no_forbidden_tokens() -> None:
    """Charter #2 — pack ledger body MUST NOT contain project-specific
    tokens (animation sub-domain literals OR UI/UX sub-domain literals)."""
    text = _load_pack_text()
    for tok in FORBIDDEN_TOKENS:
        assert tok not in text, (
            f"pack ledger contains forbidden token {tok!r} (Charter #2)"
        )


def test_pack_ledger_roles_subset_of_design_implementation_validation() -> None:
    """Per evo_2026_002 + evo_2026_003 exemption, creative_cluster packs
    MAY only declare roles from {design, implementation, validation}."""
    text = _load_pack_text()
    m = re.search(r"^roles:\s*\n((?:  - .*\n)+)", text, re.MULTILINE)
    assert m is not None, "pack ledger missing roles: list"
    role_lines = m.group(1)
    declared = set(re.findall(r'^\s+-\s+"([a-z_]+)"', role_lines, re.MULTILINE))
    allowed = {"design", "implementation", "validation"}
    extra = declared - allowed
    assert not extra, (
        f"pack ledger declares roles outside the exemption set: {extra}; "
        f"only {allowed} permitted per evo_2026_002 / evo_2026_003"
    )
    assert declared, "roles list must be non-empty"


def test_pack_version_post_m_h_widening() -> None:
    """M-H c1 bumped pack_version from 0.1.0-beta -> 0.2.0-beta."""
    text = _load_pack_text()
    m = re.search(r'^pack_version:\s*"([^"]+)"', text, re.MULTILINE)
    assert m is not None, "pack_version missing"
    pv = m.group(1)
    assert pv.startswith("0.2."), (
        f"pack_version MUST be 0.2.x post-M-H widening (was 0.1.x post-M-G); got {pv!r}"
    )


def test_provenance_yaml_is_project_name_free() -> None:
    """Charter #2 — docs/29_game_ui_ux/provenance.yaml MUST NOT
    contain project literals. Specific adopting-project name lives in
    workspace MEMORY.md only."""
    p = REPO_ROOT / "docs" / "29_game_ui_ux" / "provenance.yaml"
    assert p.is_file(), "missing provenance.yaml"
    text = p.read_text(encoding="utf-8")
    for tok in FORBIDDEN_TOKENS:
        assert tok not in text, (
            f"provenance.yaml contains forbidden token {tok!r} (Charter #2)"
        )
