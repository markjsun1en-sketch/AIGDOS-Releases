"""tests/uiux/test_no_project_literals.py — v4.91 M-H c4.

Charter #2 enforcement at the test layer for the M-H game UI/UX
sub-domain. Verify no project-specific UI/UX literals leaked into
canonical pack surfaces during c2/c3 migration.

Allowed grep hits (intentional, documented):
- docs/29_game_ui_ux/CROSS_PROJECT_PROMOTION_LESSONS.md
  (methodology cross-ref; legitimate per Q5=B EP decision)
- scripts/uiux/validate_uiux_pack.py (forbidden_tokens guardrail
  list — the validator looks for literals to reject them)

Per evo_2026_001 §Authoring discipline: forbidden token strings are
assembled at runtime so this source file itself stays Layer 1 lint
clean (same pattern as scripts/migration/scan_legacy_project.py).
"""
from __future__ import annotations

import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]

# Surfaces that MUST stay literal-free.
SCAN_PATHS = [
    "skills/_generic_core/game_ui",
    "skills/_generic_core/qa/game-ui-ux-auditor",
    "skills/_engine_specific/godot/godot-ui-implementation-planner",
    "schemas/uiux",
    "agent_packs/ap_2026_006_creative_cluster.md",
    "proposals/evo_2026_003_creative_cluster_uiux_subdomain.md",
    "docs/29_game_ui_ux/references",
    "docs/29_game_ui_ux/templates",
    "docs/29_game_ui_ux/examples",
    "docs/29_game_ui_ux/contracts",
    "docs/29_game_ui_ux/README.md",
    "docs/29_game_ui_ux/AGENT_PACK_OVERVIEW.md",
    "docs/29_game_ui_ux/AI_LIMITATIONS_AND_HUMAN_GATE.md",
    "docs/29_game_ui_ux/provenance.yaml",
]

# Documented exceptions — meta-references / guardrails.
ALLOWED_EXCEPTIONS = {
    "docs/29_game_ui_ux/CROSS_PROJECT_PROMOTION_LESSONS.md",
    "scripts/uiux/validate_uiux_pack.py",
    "tests/uiux/test_no_project_literals.py",
    "tests/uiux/test_pack_ledger_consistency.py",
    "tests/uiux/test_no_baked_runtime_text.py",
    # The proposal itself contains a single methodology meta-reference
    # explaining the c3 rename ('less_is_more_battle_hud_spec_example.md'
    # -> 'screen_alpha_battle_hud_spec_example.md'). This is a Q5=B
    # legitimate cross-reference, not project usage.
    "proposals/evo_2026_003_creative_cluster_uiux_subdomain.md",
}

# Forbidden tokens assembled at runtime so this source file stays
# Layer 1 lint-clean (per evo_2026_001 §Authoring discipline; mirrors
# tests/animation/test_no_project_literals.py M-G c4 pattern).
_TOK_LIM_LOWER = "less" + "_is_more"
_TOK_LIM_HUMAN = "less " + "is more"
_TOK_LIM_TITLE = "Less " + "Is More"
_TOK_PROJECT = "lessis" + "more"
FORBIDDEN_TOKENS = [
    _TOK_LIM_LOWER,
    _TOK_LIM_HUMAN,
    _TOK_LIM_TITLE,
    _TOK_PROJECT,
]


def _iter_files_under(rel: str):
    p = REPO_ROOT / rel
    if p.is_file():
        yield p
    elif p.is_dir():
        for f in sorted(p.rglob("*")):
            if f.is_file():
                yield f


def test_no_uiux_project_literal_in_canonical_pack_surfaces() -> None:
    """Search the snake-case + spaced + title-case + camelCase variants
    of the M-H source pack project literal across the M-H surfaces."""
    offenders: list[tuple[str, int, str]] = []
    for surface in SCAN_PATHS:
        for f in _iter_files_under(surface):
            rel = str(f.relative_to(REPO_ROOT))
            if rel in ALLOWED_EXCEPTIONS:
                continue
            try:
                text = f.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            for tok in FORBIDDEN_TOKENS:
                pattern = re.compile(re.escape(tok), re.IGNORECASE)
                for ln_no, line in enumerate(text.splitlines(), start=1):
                    if pattern.search(line):
                        offenders.append((rel, ln_no, line.strip()[:80]))
    assert not offenders, (
        f"Charter #2 violation — UI/UX project literal in canonical "
        f"pack surface(s): {offenders}"
    )


def test_documented_exceptions_actually_contain_meta_references() -> None:
    """Sanity check: the allowed-exceptions list isn't stale. If we
    later remove the meta-reference from the methodology doc or the
    validator, this list should shrink correspondingly."""
    methodology = REPO_ROOT / "docs/29_game_ui_ux/CROSS_PROJECT_PROMOTION_LESSONS.md"
    if methodology.exists():
        text = methodology.read_text(encoding="utf-8")
        # Methodology doc may legitimately reference the M-G sibling
        # by mentioning the methodology cross-ref pattern. Q5=B
        # preserves this. We assert the methodology doc itself exists,
        # not the literal — the literal is M-G's; M-H methodology only
        # mentions its own pattern naming via abstract tokens.
        assert "Cross-Project Promotion Lessons" in text, (
            "CROSS_PROJECT_PROMOTION_LESSONS.md should retain the "
            "methodology document title"
        )
    validator = REPO_ROOT / "scripts/uiux/validate_uiux_pack.py"
    if validator.exists():
        text = validator.read_text(encoding="utf-8")
        assert "forbidden_tokens" in text, (
            "validator should retain the forbidden_tokens guardrail; "
            "if removed, drop from ALLOWED_EXCEPTIONS"
        )
