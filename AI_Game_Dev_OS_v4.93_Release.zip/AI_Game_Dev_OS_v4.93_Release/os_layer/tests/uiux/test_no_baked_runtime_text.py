"""tests/uiux/test_no_baked_runtime_text.py — v4.91 M-H c4.

inv_014 FIRST GATE compile-time guards. Verify scripts/uiux/ remains
read-only with respect to canonical pack assets and that the
schema-layer Charter #6 / #11 locks for the no-baked-runtime-text
contract stay in place.

Mirrors tests/animation/test_no_auto_rig_promise.py (M-G c4) but
adapts the forbidden-flag list to UI/UX-specific escape hatches.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS_DIR = REPO_ROOT / "scripts" / "uiux"
SCHEMA_DIR = REPO_ROOT / "schemas" / "uiux"
DOCS_DIR = REPO_ROOT / "docs" / "29_game_ui_ux"

# Charter #7 — escape-hatch flags forbidden in scripts/uiux/.
FORBIDDEN_FLAGS = [
    "--apply",
    "--auto-design",
    "--bake-text",
    "--auto-prompt",
    "--auto-confirm",
    "--override",
    "--override-freeze",
    "--skip-review",
    "--skip-acceptance",
    "--bypass",
    "--allow-extra",
    "--force",
    "--auto-apply",
]

FORBIDDEN_RUNTIME_CALLS = [
    "shutil.rmtree",
    "shutil.move",
    "shutil.copytree",
    "os.system",
    "os.unlink",
    "os.remove",
    "subprocess.run",
    "subprocess.Popen",
    "subprocess.check_call",
    "subprocess.check_output",
]


def _iter_uiux_py_files():
    for p in sorted(SCRIPTS_DIR.glob("*.py")):
        yield p


@pytest.mark.parametrize("flag", FORBIDDEN_FLAGS)
def test_scripts_uiux_no_forbidden_argparse_flag(flag: str) -> None:
    offenders = []
    for py in _iter_uiux_py_files():
        text = py.read_text(encoding="utf-8")
        non_comment_lines = []
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            non_comment_lines.append(line)
        joined = "\n".join(non_comment_lines)
        pattern = re.compile(rf'[\'"]({re.escape(flag)})[\'"]')
        if pattern.search(joined):
            offenders.append(str(py.relative_to(REPO_ROOT)))
    assert not offenders, (
        f"Charter #7 violation — scripts/uiux/ MUST NOT define "
        f"argparse flag {flag!r}. Offenders: {offenders}"
    )


@pytest.mark.parametrize("call", FORBIDDEN_RUNTIME_CALLS)
def test_scripts_uiux_no_destructive_runtime_call(call: str) -> None:
    """scripts/uiux/ MUST stay read-only with respect to canonical
    pack assets. Destructive operations (shutil.rmtree, os.system,
    subprocess.*) are forbidden — the only writes permitted are to
    docs/29_game_ui_ux/GENERATED_INDEX.md (regenerable output) via
    Path.write_text."""
    offenders = []
    for py in _iter_uiux_py_files():
        text = py.read_text(encoding="utf-8")
        for ln_no, line in enumerate(text.splitlines(), start=1):
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            if call in stripped:
                offenders.append(f"{py.relative_to(REPO_ROOT)}:{ln_no}")
    assert not offenders, (
        f"inv_014 violation — scripts/uiux/ uses forbidden runtime "
        f"call {call!r}. Offenders: {offenders}"
    )


# --- inv_014 FIRST GATE: forbid_baked_text const true (compile-time) ---

def test_card_prefab_forbid_baked_text_const_true_at_schema_layer() -> None:
    """Compile-time guard: const true is the schema-layer Charter #6
    enforcement that no spec can declare runtime text baked into card
    art."""
    schema = json.loads((SCHEMA_DIR / "card_prefab_spec.schema.json").read_text(encoding="utf-8"))
    forbid = schema["properties"]["runtime_text_rules"]["properties"]["forbid_baked_text"]
    assert forbid.get("const") is True


def test_ui_asset_prompt_forbid_baked_runtime_text_const_true_at_schema_layer() -> None:
    """Compile-time guard: const true is the schema-layer Charter #6
    enforcement that no UI asset prompt can permit baking runtime text
    into the generated image."""
    schema = json.loads((SCHEMA_DIR / "ui_asset_prompt.schema.json").read_text(encoding="utf-8"))
    forbid = schema["properties"]["forbid_baked_runtime_text"]
    assert forbid.get("const") is True


# --- inv_014 SECOND GATE: spec-required acceptance (compile-time) ---

def test_ui_screen_spec_acceptance_is_required_field() -> None:
    schema = json.loads((SCHEMA_DIR / "ui_screen_spec.schema.json").read_text(encoding="utf-8"))
    assert "acceptance" in schema.get("required", []), (
        "ui_screen_spec.acceptance MUST be a required field (inv_014 SECOND GATE — "
        "Charter #11 spec-as-contract)"
    )


def test_card_prefab_spec_acceptance_is_required_field() -> None:
    schema = json.loads((SCHEMA_DIR / "card_prefab_spec.schema.json").read_text(encoding="utf-8"))
    assert "acceptance" in schema.get("required", []), (
        "card_prefab_spec.acceptance MUST be a required field"
    )


# --- AI_LIMITATIONS_AND_HUMAN_GATE.md presence + ≥9 gates ---

def test_ai_limitations_doc_lists_at_least_nine_human_gates() -> None:
    """inv_014 must_preserve: AI_LIMITATIONS_AND_HUMAN_GATE.md MUST
    enumerate ≥9 numbered human gates."""
    p = DOCS_DIR / "AI_LIMITATIONS_AND_HUMAN_GATE.md"
    assert p.is_file()
    text = p.read_text(encoding="utf-8")
    # Count "## Gate N — ..." headers.
    gate_headers = re.findall(r"^## Gate \d+", text, re.MULTILINE)
    assert len(gate_headers) >= 9, (
        f"AI_LIMITATIONS_AND_HUMAN_GATE.md MUST list ≥9 numbered human "
        f"gates (Charter #11 alignment); found {len(gate_headers)}"
    )


# --- Validator widened registry: M-H c0 design ---

def test_validate_agent_pack_registry_widened_to_evo_2026_003() -> None:
    """inv_014 must_preserve: the validator's _CLUSTER_ALIASING_EXEMPTIONS
    registry MUST be the M-H c0 widened tuple form, accepting
    evo_2026_003 alongside evo_2026_002 as authorising proposal ids
    for creative_cluster."""
    p = REPO_ROOT / "scripts" / "agent_library" / "validate_agent_pack.py"
    text = p.read_text(encoding="utf-8")
    assert "_CLUSTER_ALIASING_EXEMPTIONS" in text
    assert '"creative_cluster"' in text
    assert "evo_2026_002" in text
    assert "evo_2026_003" in text, (
        "validator MUST cite proposals/evo_2026_003 in the widened exemption registry"
    )
    forbidden_flags = ("--allow-deferred", "--skip-exemption", "--override-cluster")
    for flag in forbidden_flags:
        assert flag not in text, (
            f"Charter #7 violation — validator has escape flag {flag!r}"
        )
