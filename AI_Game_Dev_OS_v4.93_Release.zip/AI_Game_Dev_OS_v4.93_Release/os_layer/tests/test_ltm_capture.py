"""Tests for runtime.ltm.capture + Gate (v4.89 P2 M3.2)."""
from __future__ import annotations

import importlib
from pathlib import Path

import pytest

from runtime.ltm import (
    GATE_STATUS_BLOCKED,
    GATE_STATUS_PASSED,
    KNOWN_DOMAINS,
    capture,
)

# Module object for monkeypatching _LTM_ROOT (same trick as
# test_ltm_consult — package-level re-export shadows the submodule
# attribute path).
_capture_mod = importlib.import_module("runtime.ltm.capture")
_consult_mod = importlib.import_module("runtime.ltm.consult")


def _redirect_ltm_root(monkeypatch, tmp_path: Path) -> None:
    """Point BOTH capture.py and consult.py at tmp_path.

    capture writes relative to consult's _LTM_ROOT (shared source of
    truth); but capture also caches its own alias, so we patch both
    to be safe.
    """
    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)
    monkeypatch.setattr(_capture_mod, "_LTM_ROOT", tmp_path)


def test_unknown_domain_raises_value_error(tmp_path: Path, monkeypatch):
    _redirect_ltm_root(monkeypatch, tmp_path)
    with pytest.raises(ValueError) as exc:
        capture("bogus", "Title", "body")
    msg = str(exc.value)
    assert "bogus" in msg
    for d in KNOWN_DOMAINS:
        assert d in msg


def test_os_domain_passes_without_evidence(tmp_path: Path, monkeypatch):
    """OS domain is the only one that doesn't require evidence_ref."""
    _redirect_ltm_root(monkeypatch, tmp_path)
    result = capture("os", "Envelope Contract", "body text here\n")
    assert result["gate"] == GATE_STATUS_PASSED
    assert result["reason"] is None
    # File lives at ltm/os/envelope-contract.md (slugified title).
    target = tmp_path / "os" / "envelope-contract.md"
    assert target.exists()
    body = target.read_text(encoding="utf-8")
    assert "# Envelope Contract" in body
    assert "captured_at:" in body
    assert "gate: passed" in body


def test_non_os_domain_without_evidence_quarantined(tmp_path, monkeypatch):
    """project/pattern/failures MUST have evidence_ref; missing →
    quarantine."""
    _redirect_ltm_root(monkeypatch, tmp_path)
    result = capture(
        "failures", "Silent Drop Bug", "details",
        evidence_ref=None,
    )
    assert result["gate"] == GATE_STATUS_BLOCKED
    assert "evidence_ref" in result["reason"]
    assert "_quarantine" in result["path"]
    # Nothing written to the real domain directory.
    assert not (tmp_path / "failures").exists() or not list(
        (tmp_path / "failures").glob("*.md")
    )
    # Payload IS in quarantine.
    qfiles = list((tmp_path / "_quarantine").glob("*.quarantined.md"))
    assert len(qfiles) == 1
    body = qfiles[0].read_text(encoding="utf-8")
    assert "intended_domain: failures" in body
    assert "block_reason:" in body


def test_non_os_domain_with_evidence_passes(tmp_path, monkeypatch):
    _redirect_ltm_root(monkeypatch, tmp_path)
    result = capture(
        "failures", "A4 dry run fail",
        "Symptom / RCA / Fix",
        evidence_ref="commit 7a72ea6",
    )
    assert result["gate"] == GATE_STATUS_PASSED
    target = tmp_path / "failures" / "a4-dry-run-fail.md"
    assert target.exists()
    body = target.read_text(encoding="utf-8")
    assert "evidence_ref: commit 7a72ea6" in body


def test_requires_approval_forces_quarantine(tmp_path, monkeypatch):
    """Even with a valid domain + evidence_ref, requires_approval=True
    forces quarantine. Needed for orchestrator-driven captures that
    want human sign-off before publishing."""
    _redirect_ltm_root(monkeypatch, tmp_path)
    result = capture(
        "os", "Manually Queued Rule",
        "proposed new OS rule that needs review",
        requires_approval=True,
    )
    assert result["gate"] == GATE_STATUS_BLOCKED
    assert "requires_approval" in result["reason"]
    # Nothing under os/ (domain directory doesn't even get created).
    assert not (tmp_path / "os").exists()
    qfiles = list((tmp_path / "_quarantine").glob("*.quarantined.md"))
    assert len(qfiles) == 1


def test_canonical_override_soft_warning(tmp_path, monkeypatch):
    """OS-domain content mentioning 'canonical' / 'override' triggers
    a soft warning but still passes the gate (MVP behavior; Phase 3
    Self-Evolution tightens this)."""
    _redirect_ltm_root(monkeypatch, tmp_path)
    result = capture(
        "os", "Override Investigation",
        "This rule discusses when canonical path may be overridden.",
    )
    assert result["gate"] == GATE_STATUS_PASSED  # soft warn, not reject
    warnings = result["warnings"]
    assert warnings, "expected at least one soft-warn entry"
    joined = " ".join(warnings)
    assert "soft-warn" in joined
    assert "canonical_override_block" in joined
