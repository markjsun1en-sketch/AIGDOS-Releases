"""test_naming_aliases_yaml.py — v4.90 Batch 14 Step 14.5.

Self-consistency tests for `config/naming_aliases.yaml` and the
`scripts/lint/check_naming_aliases.py` lint guard.

Three tests:
1. yaml file exists, parses cleanly, has expected top-level keys
2. every entry across all domains has the required minimum keys
3. lint guard subprocess exits 0 on current state

Layer 1 (OS Spec). No project names.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))

from scripts.governance._yaml_subset import load_yaml_file  # noqa: E402

CONFIG_PATH = REPO_ROOT / "config" / "naming_aliases.yaml"
LINT_SCRIPT = (
    REPO_ROOT / "scripts" / "lint" / "check_naming_aliases.py"
)


def test_naming_aliases_yaml_top_level_shape():
    """yaml must have schema_version + domains + not_aliases keys."""
    assert CONFIG_PATH.is_file(), (
        f"missing naming aliases catalog: {CONFIG_PATH}"
    )
    data = load_yaml_file(CONFIG_PATH)
    assert data.get("schema_version") == "1.0.0"
    assert "domains" in data
    assert set(data["domains"].keys()) == {
        "directory_aliases",
        "cli_aliases",
    }
    assert "not_aliases" in data


def test_every_alias_entry_has_required_minimum_keys():
    """Each alias entry must carry an `alias` key plus a domain-
    specific canonical pointer.

    - directory_aliases entries: alias + canonical (+ optional
      readme/markers/canonical_schemas/since_batch/ep_decision/notes)
    - cli_aliases entries: alias + kind + (canonical OR canonical_chain)
    """
    data = load_yaml_file(CONFIG_PATH)
    for e in data["domains"]["directory_aliases"]["entries"]:
        assert "alias" in e, f"directory_aliases entry missing alias: {e}"
        assert "canonical" in e, (
            f"directory_aliases[{e['alias']}] missing canonical"
        )
    for e in data["domains"]["cli_aliases"]["entries"]:
        assert "alias" in e, f"cli_aliases entry missing alias: {e}"
        assert "kind" in e, f"cli_aliases[{e['alias']}] missing kind"
        if e["kind"] == "chain":
            assert "canonical_chain" in e, (
                f"cli_aliases[{e['alias']}] kind=chain needs canonical_chain"
            )
        else:
            assert "canonical" in e, (
                f"cli_aliases[{e['alias']}] kind={e['kind']!r} needs canonical"
            )


def test_lint_guard_exits_zero_on_clean_state():
    """check_naming_aliases.py must exit 0 with current yaml + tree."""
    result = subprocess.run(
        [sys.executable, str(LINT_SCRIPT)],
        capture_output=True, text=True,
    )
    assert result.returncode == 0, (
        f"lint guard exited {result.returncode}:\n"
        f"{result.stdout}\n{result.stderr}"
    )
    assert "All naming aliases valid" in result.stdout
