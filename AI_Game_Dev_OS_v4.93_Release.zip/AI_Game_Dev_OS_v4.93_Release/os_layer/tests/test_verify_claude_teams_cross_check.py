"""Tests for verify_beta_sprint_exit.check_init_integrity
claude_code_agent_teams schema cross-check
(v4.89 Phase 2 Stage 2 / M6.6 · updated Phase 4 / M7.3.3).

Contract surface
----------------
The cross-check fires when ``runtime_state.profile ==
"claude_code_agent_teams"``:

    coordination_model must equal "lead_teammates"
    writeback_owner    must equal "lead"

Two severities, different semantics:

- **ERROR** (M7.3.3 lift) — field absent from runtime_state.  Contract
  violation: post-M7.3.2 ``_stub_init`` must canonically write these
  fields from the profile JSON.
- **WARN** (M6.6 semantics, preserved) — field present but value
  contradicts ground truth.  Schema drift, non-fatal.

Symmetric with M6.4 codex / M6.5 cursor; all four per-profile blocks
live in the same schema_driven_init_check loop.

See ltm/failures/2026-05-05_claude_teams_silent_pass_blindness.md and
docs/06_runtime_profiles/PHASE_4_LIFT_GATE_AUDIT.md §1 §4.
"""
from __future__ import annotations

import json
from pathlib import Path

from verify_beta_sprint_exit import VerifyContext, check_init_integrity


def _make_state(workspace: Path, **fields) -> Path:
    rs_dir = workspace / "runtime" / "state"
    rs_dir.mkdir(parents=True, exist_ok=True)
    rs = rs_dir / "runtime_state.json"
    base = {
        "project_id": "rh_sprint_sim_01",
        "runtime_profile": "workbuddy_private",
        "profile": "workbuddy_private",
        "initialized_at": "2026-05-02T12:00:00Z",
    }
    base.update(fields)
    rs.write_text(json.dumps(base, indent=2) + "\n", encoding="utf-8")
    return rs


def _ctx(workspace: Path, runtime_state: Path) -> VerifyContext:
    return VerifyContext(
        workspace=workspace,
        audit_log=workspace / "runtime" / "logs" / "mcp_audit.jsonl",
        runtime_state=runtime_state,
        sprint_close_checklist=(
            workspace / "runtime" / "state" / "sprint_close_checklist.md"
        ),
    )


def _claude_teams_drift_findings(findings: list[dict]) -> list[dict]:
    """Filter to M6.6 claude_teams schema drift findings (WARN)."""
    return [
        f for f in findings
        if f.get("category") == "init"
        and f.get("severity") == "WARN"
        and f.get("contract_field") in {"coordination_model", "writeback_owner"}
        and "profile=claude_code_agent_teams" in f.get("message", "")
    ]


def _claude_teams_missing_findings(findings: list[dict]) -> list[dict]:
    """Filter to M7.3.3 claude_teams missing-contract-field ERRORs."""
    return [
        f for f in findings
        if f.get("category") == "init"
        and f.get("severity") == "ERROR"
        and f.get("contract_field") in {"coordination_model", "writeback_owner"}
        and "profile=claude_code_agent_teams" in f.get("message", "")
        and "missing contract field" in f.get("message", "")
    ]


# C1 — P1 baseline unaffected --------------------------------------------------


def test_p1_baseline_unaffected_by_claude_teams_check(workspace: Path):
    """workbuddy_private state → 0 claude_teams findings (both filters)."""
    rs = _make_state(workspace)
    findings = check_init_integrity(_ctx(workspace, rs))
    assert _claude_teams_drift_findings(findings) == []
    assert _claude_teams_missing_findings(findings) == []


# C2 — claude_teams positive (clean) mirror — M7.3.3 flips to 2 ERROR --------


def test_claude_teams_positive_mirror_clean(workspace: Path):
    """profile=claude_code_agent_teams + NO contract fields → M7.3.3:
    2 ERROR, 0 WARN."""
    rs = _make_state(
        workspace,
        profile="claude_code_agent_teams",
        runtime_profile="claude_code_agent_teams",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    assert _claude_teams_drift_findings(findings) == []
    missing = _claude_teams_missing_findings(findings)
    assert len(missing) == 2
    assert {f["contract_field"] for f in missing} == {
        "coordination_model",
        "writeback_owner",
    }


# C3 — coordination_model drift ------------------------------------------------


def test_claude_teams_negative_coordination_drift(workspace: Path):
    """profile=claude_code_agent_teams + coordination_model=private_coordinated +
    writeback_owner=lead (correct) → 1 WARN / 0 ERROR."""
    rs = _make_state(
        workspace,
        profile="claude_code_agent_teams",
        runtime_profile="claude_code_agent_teams",
        coordination_model="private_coordinated",
        writeback_owner="lead",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    drift = _claude_teams_drift_findings(findings)
    assert len(drift) == 1
    assert drift[0]["contract_field"] == "coordination_model"
    assert "lead_teammates" in drift[0]["message"]
    assert "private_coordinated" in drift[0]["message"]
    assert _claude_teams_missing_findings(findings) == []


# C4 — writeback_owner drift ---------------------------------------------------


def test_claude_teams_negative_writeback_drift(workspace: Path):
    """profile=claude_code_agent_teams + coordination_model=lead_teammates (correct) +
    writeback_owner=main_session → 1 WARN / 0 ERROR."""
    rs = _make_state(
        workspace,
        profile="claude_code_agent_teams",
        runtime_profile="claude_code_agent_teams",
        coordination_model="lead_teammates",
        writeback_owner="main_session",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    drift = _claude_teams_drift_findings(findings)
    assert len(drift) == 1
    assert drift[0]["contract_field"] == "writeback_owner"
    assert "'lead'" in drift[0]["message"]
    assert "main_session" in drift[0]["message"]
    assert _claude_teams_missing_findings(findings) == []


# C5 — combined drift (both fields) --------------------------------------------


def test_claude_teams_negative_combined_drift(workspace: Path):
    """Both contract fields present but drifted → exactly 2 WARN,
    mirroring rh_sprint_sim_01__claude_code_agent_teams_negative."""
    rs = _make_state(
        workspace,
        profile="claude_code_agent_teams",
        runtime_profile="claude_code_agent_teams",
        coordination_model="private_coordinated",
        writeback_owner="main_session",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    drift = _claude_teams_drift_findings(findings)
    fields_seen = {f["contract_field"] for f in drift}
    assert fields_seen == {"coordination_model", "writeback_owner"}
    assert all(f["severity"] == "WARN" for f in drift)
    assert all(f["category"] == "init" for f in drift)
    assert _claude_teams_missing_findings(findings) == []


# C6 — cross-profile gate guard (codex profile must NOT trigger claude_teams) --


def test_codex_profile_with_drift_fields_does_not_trigger_claude_teams_block(
    workspace: Path,
):
    """Defensive: a codex profile must not trip the claude_teams block."""
    rs = _make_state(
        workspace,
        profile="codex",
        runtime_profile="codex",
        coordination_model="private_coordinated",
        writeback_owner="main_session",
    )
    findings = check_init_integrity(_ctx(workspace, rs))
    assert _claude_teams_drift_findings(findings) == []
    assert _claude_teams_missing_findings(findings) == []
    codex_findings = [
        f for f in findings
        if f.get("category") == "init"
        and f.get("severity") == "WARN"
        and "profile=codex" in f.get("message", "")
    ]
    assert len(codex_findings) == 2
