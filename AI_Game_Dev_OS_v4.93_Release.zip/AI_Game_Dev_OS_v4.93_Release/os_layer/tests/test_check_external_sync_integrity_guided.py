"""Tests for verify_beta_sprint_exit.check_external_sync_integrity GUIDED tier
(v4.90 Batch 0.5 Step 0.5.2).

Covers five GUIDED additions on top of the SCAFFOLD-era checks
(write↔verify pairing + verification_ok=false ERROR):
  1. tapd.write timestamp monotonicity (WARN on inversion)
  2. write -> verify temporal ordering (ERROR when verify precedes write)
  3. write -> verify latency upper bound 60s (WARN when exceeded)
  4. write count lower bound 1 (WARN when zero writes on non-dry-run profile)
  5. cross-workspace consistency (WARN when write.workspace disagrees)
"""
from __future__ import annotations

import json
from pathlib import Path

from verify_beta_sprint_exit import VerifyContext, check_external_sync_integrity


def _ctx(workspace: Path, audit_log: Path, *, profile: str | None = "codex") -> VerifyContext:
    return VerifyContext(
        workspace=workspace,
        audit_log=audit_log,
        runtime_state=workspace / "runtime_state.json",
        sprint_close_checklist=workspace / "sprint_close_checklist.md",
        audit_log_explicit=True,
        profile=profile,
    )


def _write_audit(audit_log: Path, events: list[dict]) -> None:
    audit_log.parent.mkdir(parents=True, exist_ok=True)
    with audit_log.open("w", encoding="utf-8") as fh:
        for e in events:
            fh.write(json.dumps(e) + "\n")


def _write_event(**kwargs) -> dict:
    base = {
        "event_type": "external.tapd.write",
        "timestamp": "2026-05-04T13:10:00Z",
        "actor": "engineering",
        "source_layer": "tapd",
        "status": "ok",
        "task_id": "FT-100",
        "object_id": "1001",
    }
    base.update(kwargs)
    return base


def _verify_event(**kwargs) -> dict:
    base = {
        "event_type": "external.tapd.verify",
        "timestamp": "2026-05-04T13:10:10Z",
        "actor": "engineering",
        "source_layer": "tapd",
        "status": "ok",
        "task_id": "FT-100",
        "object_id": "1001",
        "verification_ok": True,
    }
    base.update(kwargs)
    return base


# -----------------------------------------------------------------------
# 1. tapd.write timestamp monotonicity
# -----------------------------------------------------------------------

def test_write_timestamp_monotonic_happy(tmp_path: Path):
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _write_event(timestamp="2026-05-04T13:10:00Z", task_id="FT-100", object_id="1001"),
        _verify_event(timestamp="2026-05-04T13:10:10Z", task_id="FT-100", object_id="1001"),
        _write_event(timestamp="2026-05-04T13:20:00Z", task_id="FT-101", object_id="1002"),
        _verify_event(timestamp="2026-05-04T13:20:10Z", task_id="FT-101", object_id="1002"),
    ])
    findings = check_external_sync_integrity(_ctx(tmp_path, audit))
    inversions = [f for f in findings
                  if "tapd.write timestamp inversion" in f.get("message", "")]
    assert inversions == [], inversions


def test_write_timestamp_inversion_warns(tmp_path: Path):
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _write_event(timestamp="2026-05-04T13:30:00Z", task_id="FT-100", object_id="1001"),
        _verify_event(timestamp="2026-05-04T13:30:10Z", task_id="FT-100", object_id="1001"),
        _write_event(timestamp="2026-05-04T13:10:00Z", task_id="FT-101", object_id="1002"),
        _verify_event(timestamp="2026-05-04T13:10:10Z", task_id="FT-101", object_id="1002"),
    ])
    findings = check_external_sync_integrity(_ctx(tmp_path, audit))
    relevant = [f for f in findings
                if "tapd.write timestamp inversion" in f.get("message", "")]
    assert len(relevant) == 1
    assert relevant[0].get("severity") == "WARN"


# -----------------------------------------------------------------------
# 2. write -> verify temporal ordering
# -----------------------------------------------------------------------

def test_write_to_verify_temporal_happy(tmp_path: Path):
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _write_event(timestamp="2026-05-04T13:10:00Z"),
        _verify_event(timestamp="2026-05-04T13:10:10Z"),
    ])
    findings = check_external_sync_integrity(_ctx(tmp_path, audit))
    inversions = [f for f in findings
                  if "precede" in f.get("message", "")]
    assert inversions == [], inversions


def test_verify_precedes_write_errors(tmp_path: Path):
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _write_event(timestamp="2026-05-04T13:10:30Z"),
        _verify_event(timestamp="2026-05-04T13:10:00Z"),  # earlier than write
    ])
    findings = check_external_sync_integrity(_ctx(tmp_path, audit))
    relevant = [f for f in findings
                if "precede their matching tapd.write" in f.get("message", "")]
    assert len(relevant) == 1
    assert relevant[0].get("severity") == "ERROR"


# -----------------------------------------------------------------------
# 3. latency upper bound
# -----------------------------------------------------------------------

def test_latency_within_limit_silent(tmp_path: Path):
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _write_event(timestamp="2026-05-04T13:10:00Z"),
        _verify_event(timestamp="2026-05-04T13:10:30Z"),  # 30s within 60s
    ])
    findings = check_external_sync_integrity(_ctx(tmp_path, audit))
    stale = [f for f in findings if "latency limit" in f.get("message", "")]
    assert stale == [], stale


def test_latency_exceeded_warns(tmp_path: Path):
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _write_event(timestamp="2026-05-04T13:10:00Z"),
        _verify_event(timestamp="2026-05-04T13:12:00Z"),  # 120s > 60s
    ])
    findings = check_external_sync_integrity(_ctx(tmp_path, audit))
    relevant = [f for f in findings if "latency limit" in f.get("message", "")]
    assert len(relevant) == 1
    assert relevant[0].get("severity") == "WARN"
    assert relevant[0].get("stale_pairs")[0]["latency_seconds"] == 120


# -----------------------------------------------------------------------
# 4. write count lower bound
# -----------------------------------------------------------------------

def test_zero_writes_codex_warns(tmp_path: Path):
    audit = tmp_path / "audit.jsonl"
    # Place a non-tapd event so _require_audit returns events; zero
    # writes specifically.
    _write_audit(audit, [
        {"event_type": "runtime.create", "timestamp": "2026-05-04T09:00:00Z",
         "actor": "orchestrator", "source_layer": "runtime_registry",
         "status": "ok", "task_id": "FT-100"},
    ])
    findings = check_external_sync_integrity(_ctx(tmp_path, audit, profile="codex"))
    relevant = [f for f in findings if "zero tapd.write events" in f.get("message", "")]
    assert len(relevant) == 1
    assert relevant[0].get("severity") == "WARN"


def test_zero_writes_workbuddy_private_silent(tmp_path: Path):
    """workbuddy_private profile is the dry-run baseline; zero writes is fine."""
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        {"event_type": "runtime.create", "timestamp": "2026-05-04T09:00:00Z",
         "actor": "orchestrator", "source_layer": "runtime_registry",
         "status": "ok", "task_id": "FT-100"},
    ])
    findings = check_external_sync_integrity(_ctx(tmp_path, audit, profile="workbuddy_private"))
    relevant = [f for f in findings if "zero tapd.write events" in f.get("message", "")]
    assert relevant == [], relevant


# -----------------------------------------------------------------------
# 5. cross-workspace consistency
# -----------------------------------------------------------------------

def test_workspace_field_absent_silent(tmp_path: Path):
    """S1-style fixtures lack workspace field; check skips."""
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _write_event(timestamp="2026-05-04T13:10:00Z"),
        _verify_event(timestamp="2026-05-04T13:10:10Z"),
    ])
    findings = check_external_sync_integrity(_ctx(tmp_path, audit))
    relevant = [f for f in findings if "disagreeing" in f.get("message", "")]
    assert relevant == [], relevant


def test_workspace_field_mismatch_warns(tmp_path: Path):
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _write_event(timestamp="2026-05-04T13:10:00Z", workspace="/some/other/path"),
        _verify_event(timestamp="2026-05-04T13:10:10Z"),
    ])
    findings = check_external_sync_integrity(_ctx(tmp_path, audit))
    relevant = [f for f in findings if "disagreeing" in f.get("message", "")]
    assert len(relevant) == 1
    assert relevant[0].get("severity") == "WARN"
    assert "/some/other/path" in relevant[0].get("mismatch_workspaces", [])
