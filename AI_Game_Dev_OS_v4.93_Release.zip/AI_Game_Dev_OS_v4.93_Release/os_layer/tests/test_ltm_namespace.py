"""Tests for Phase 4 M9.5 cross-project LTM namespace (Layer A).

Covers the project_id filter wired into consult() and the Gate rule 5
hardening applied to capture(). Plus a real-corpus spot check that
the four synthesized RH seed entries are consultable, and a lexicon
scrub guardrail that prevents stray project vocabulary from slipping
into the project/rh/ corpus in future edits.
"""
from __future__ import annotations

import importlib
import re
import subprocess
import sys
from pathlib import Path

import pytest

from runtime.ltm import capture, consult

# Module handle so monkeypatch can replace consult._LTM_ROOT for
# fixture-backed tests (same pattern used by test_ltm_consult.py).
_consult_mod = importlib.import_module("runtime.ltm.consult")
_capture_mod = importlib.import_module("runtime.ltm.capture")

# Absolute path to the real repo root (AI_Game_Dev_OS_v4.89/) — used
# by the lexicon scrub and the real-corpus tests.
_PKG_ROOT: Path = Path(__file__).resolve().parents[1]
_REAL_RH_DIR: Path = _PKG_ROOT / "ltm" / "project" / "rh"


def _seed_corpus(root: Path, files: dict[str, str]) -> None:
    """Write the {relative_path: body} dict under ``root``."""
    for rel, body in files.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(body, encoding="utf-8")


# ---------------------------------------------------------------------
# 1-3  consult() filter semantics
# ---------------------------------------------------------------------


def test_project_id_filter_includes_unscoped(monkeypatch, tmp_path: Path):
    """project_id='rh' must include both rh-tagged AND untagged entries.

    This is the 'missing ≡ global' contract — the existing 19 legacy
    entries (no project_id) remain visible to every project-scoped
    query. Breaking this would silently hide cross-project OS wisdom
    from every project-filtered consult call.
    """
    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)
    _seed_corpus(tmp_path, {
        # No front-matter → unscoped → always visible.
        "os/rule.md": "# Rule\nenvelope canonical contract\n",
        # Tagged rh → visible under --project rh.
        "project/rh/tag.md": (
            "---\nproject_id: rh\n---\n"
            "# Tag\nenvelope drift lesson\n"
        ),
    })
    hits = consult("envelope", project_id="rh")
    paths = {Path(h["path"]).name for h in hits}
    assert paths == {"rule.md", "tag.md"}, hits


def test_project_id_filter_excludes_other_projects(
    monkeypatch, tmp_path: Path,
):
    """An explicit tag on a different project must be excluded.

    This is the complementary half of the namespace contract: the
    filter actually filters. Without this test the previous one can
    pass trivially (by returning everything).
    """
    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)
    _seed_corpus(tmp_path, {
        "project/rh/mine.md": (
            "---\nproject_id: rh\n---\n# Mine\nenvelope rh lesson\n"
        ),
        "project/foo/theirs.md": (
            "---\nproject_id: foo\n---\n# Theirs\nenvelope foo lesson\n"
        ),
    })
    hits = consult("envelope", project_id="rh")
    paths = {Path(h["path"]).name for h in hits}
    assert paths == {"mine.md"}, hits
    assert "theirs.md" not in paths, hits


def test_missing_project_id_is_global(monkeypatch, tmp_path: Path):
    """Entries without a project_id remain visible across all filters.

    Regression guard for the 19 legacy entries captured before M9.5.
    A naive filter ('entry.project_id == query.project_id') would drop
    them entirely; 'missing ≡ global' is the explicit fix.
    """
    monkeypatch.setattr(_consult_mod, "_LTM_ROOT", tmp_path)
    _seed_corpus(tmp_path, {
        "os/legacy.md": "# Legacy\nenvelope canonical entry\n",
    })
    for filter_id in (None, "rh", "foo", "anything"):
        hits = consult("envelope", project_id=filter_id)
        names = {Path(h["path"]).name for h in hits}
        assert "legacy.md" in names, (filter_id, hits)


# ---------------------------------------------------------------------
# 4  CLI end-to-end
# ---------------------------------------------------------------------


def test_cli_project_flag_exits_zero():
    """`python -m runtime.ltm "..." --project rh` must exit 0.

    Uses the real corpus. We don't assert specific hits (that's the
    job of the real-corpus test further down) — here we only prove
    the CLI parses --project and does not reject it.
    """
    result = subprocess.run(
        [
            sys.executable, "-m", "runtime.ltm",
            "sprint close handoff", "--project", "rh",
        ],
        cwd=str(_PKG_ROOT),
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, (
        f"stdout={result.stdout!r} stderr={result.stderr!r}"
    )


# ---------------------------------------------------------------------
# 5-6  capture() Gate rule 5 + front-matter emission
# ---------------------------------------------------------------------


def test_capture_project_domain_requires_project_id(
    monkeypatch, tmp_path: Path,
):
    """Gate rule 5 — project domain without project_id → quarantine."""
    monkeypatch.setattr(_capture_mod, "_LTM_ROOT", tmp_path)
    result = capture(
        "project",
        "handoff drift",
        "body text",
        evidence_ref="synthesized — test fixture",
    )
    assert result["gate"] == "blocked", result
    assert "project_id" in (result["reason"] or ""), result
    # Payload must be in quarantine, not in project/.
    assert "/_quarantine/" in result["path"], result


def test_capture_writes_project_id_frontmatter(
    monkeypatch, tmp_path: Path,
):
    """Explicit project_id → emitted in YAML front-matter + routed
    under project/<id>/."""
    monkeypatch.setattr(_capture_mod, "_LTM_ROOT", tmp_path)
    result = capture(
        "project",
        "seeded handoff",
        "body text",
        evidence_ref="synthesized — test fixture",
        project_id="rh",
    )
    assert result["gate"] == "passed", result
    assert result["path"].endswith("project/rh/seeded-handoff.md"), result
    written = (tmp_path / "project" / "rh" / "seeded-handoff.md").read_text(
        encoding="utf-8",
    )
    assert "project_id: rh" in written, written


# ---------------------------------------------------------------------
# 7  Real-corpus spot check
# ---------------------------------------------------------------------


def test_rh_seed_corpus_consultable():
    """The 4 synthesized RH entries seeded in M9.5.3 must be reachable
    via consult() with the rh project filter."""
    hits = consult("writeback owner drift", project_id="rh")
    paths = {h["path"] for h in hits}
    target = "ltm/project/rh/2026-05-07_writeback_owner_drift.md"
    assert target in paths, hits


# ---------------------------------------------------------------------
# 8  Lexicon scrub guardrail
# ---------------------------------------------------------------------


# Terms that MUST NOT appear inside any ltm/project/rh/*.md file.
# Mix of lessismore-specific vocabulary and other project dialects
# that would indicate a leak during future edits. The list mirrors
# the EP-locked word scrub policy (2026-04 / 2026-05).
_LEXICON_FORBIDDEN: tuple[str, ...] = (
    "lessismore",
    "Card Roguelike",
    "卡牌",
    "爆衣",
    "限界共鸣",
    "七宗罪",
    "SP-",
    "relic",
    "gourd",
)


def test_lexicon_scrub_rh_corpus():
    """Future edits to ltm/project/rh/ must stay project-agnostic.

    The RH corpus here is synthesized from EP decisions; any of the
    forbidden terms would indicate that a real-project vocabulary
    has leaked in. This test is the automated analogue of the
    grep-based scrub run at commit time.
    """
    assert _REAL_RH_DIR.is_dir(), f"expected {_REAL_RH_DIR} to exist"
    pattern = re.compile(
        "|".join(re.escape(t) for t in _LEXICON_FORBIDDEN),
        re.IGNORECASE,
    )
    offenders: list[tuple[str, str, int]] = []
    for md in sorted(_REAL_RH_DIR.rglob("*.md")):
        try:
            for lineno, line in enumerate(
                md.read_text(encoding="utf-8").splitlines(), start=1,
            ):
                match = pattern.search(line)
                if match:
                    offenders.append((
                        str(md.relative_to(_PKG_ROOT)),
                        match.group(0),
                        lineno,
                    ))
        except (OSError, UnicodeDecodeError):  # pragma: no cover
            pytest.fail(f"unreadable corpus entry: {md}")
    assert offenders == [], offenders
