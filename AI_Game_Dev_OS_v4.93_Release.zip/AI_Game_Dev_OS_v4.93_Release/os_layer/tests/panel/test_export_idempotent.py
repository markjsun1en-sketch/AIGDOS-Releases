"""test_export_idempotent.py — v4.91 M-E B9 c2.

Lifecycle / idempotence tests for scripts/panel/export_static_panel.py.

These tests boot a synthetic --repo-root in tmp_path, populate the
expected SoT inputs (hub_state.json + projects.index.json + a few
ltm subdirs + RELEASE_MANIFEST + VERSION + matrix yaml), invoke the
exporter twice, and assert:
  - exit code 0,
  - all expected output files exist,
  - the second run produces byte-identical content modulo the
    GENERATED_AT timestamp (the generator stamps an ISO instant
    that drifts between runs; everything else must be stable).
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = REPO_ROOT / "scripts" / "panel" / "export_static_panel.py"
TEMPLATE_DIR = REPO_ROOT / "templates" / "panel"


def _run(out_dir: Path, repo_root: Path) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, str(SCRIPT), "--out-dir", str(out_dir), "--repo-root", str(repo_root)],
        capture_output=True,
        text=True,
        check=False,
    )


@pytest.fixture
def synthetic_repo(tmp_path) -> Path:
    """Build a minimal synthetic repo root with the SoT files the panel reads."""
    repo = tmp_path / "synrepo"
    repo.mkdir()

    # Mirror the templates dir structure (panel resolves templates relative to
    # its own location, not --repo-root, so we don't actually need to copy
    # them — but we DO need scripts/panel/ to exist if anyone imports it).
    # The script is invoked directly via --repo-root, and TEMPLATE_DIR is
    # resolved from __file__ in the script itself, so the real templates dir
    # at REPO_ROOT/templates/panel/ is used. Nothing to mirror here.

    # Minimal hub state.
    (repo / "hub").mkdir()
    (repo / "hub" / "hub_state.json").write_text(json.dumps({
        "schema_version": "1.0.0",
        "hub_id": "synthetic_hub",
        "hub_status": "active",
        "linked_project_count": 1,
        "updated_at": "2026-05-26T10:00:00Z",
    }), encoding="utf-8")
    (repo / "hub" / "projects.index.json").write_text(json.dumps({
        "schema_version": "1.0.0",
        "hub_id": "synthetic_hub",
        "updated_at": "2026-05-26T10:00:00Z",
        "projects": [
            {
                "project_id": "host-alpha",
                "mount_mode": "external_core",
                "core_version": "v4.91-test",
                "linked_at": "2026-05-26T09:00:00Z",
                "last_health_check": "2026-05-26T10:00:00Z",
            }
        ],
    }), encoding="utf-8")

    # Minimal RELEASE_MANIFEST + VERSION.
    (repo / "RELEASE_MANIFEST.json").write_text(json.dumps({
        "manifest_schema_version": "2.3",
        "required_manifest_files": [{"path": "VERSION", "sha256": "0" * 64}],
        "optional_seed_files": [],
        "test_fixtures": [],
    }), encoding="utf-8")
    (repo / "VERSION").write_text("v4.91-test\n", encoding="utf-8")

    # Minimal matrix yaml.
    (repo / "runtime").mkdir()
    (repo / "runtime" / "protected_contracts").mkdir()
    (repo / "runtime" / "protected_contracts" / "protected_regression_matrix.yaml").write_text(
        "schema_version: \"1.0.0\"\n"
        "invariants:\n"
        "  - id: inv_001_test\n"
        "  - id: inv_002_test\n"
        "  - id: inv_011_test_latest\n",
        encoding="utf-8",
    )

    # Minimal ltm tree.
    for sub in ("os", "pattern", "failures", "_quarantine",
                "cross_project/candidates", "cross_project/approved_patterns",
                "cross_project/rejected", "cross_project/superseded",
                "preflight/cases"):
        (repo / "ltm" / sub).mkdir(parents=True, exist_ok=True)
    return repo


def test_lifecycle_emits_six_pages(synthetic_repo, tmp_path):
    out_dir = tmp_path / "panel-out"
    res = _run(out_dir, synthetic_repo)
    assert res.returncode == 0, f"stderr={res.stderr}"
    expected = {
        "hub_overview.html",
        "cross_project_candidates.html",
        "memory_health.html",
        "version_lock_status.html",
        "preflight_governance.html",
        "project_status_host-alpha.html",
    }
    actual = {p.name for p in out_dir.iterdir()}
    assert expected.issubset(actual), f"missing: {expected - actual}"


def test_lifecycle_omits_project_status_when_no_projects(synthetic_repo, tmp_path):
    # rewrite projects index with empty list
    (synthetic_repo / "hub" / "projects.index.json").write_text(json.dumps({
        "schema_version": "1.0.0",
        "hub_id": "synthetic_hub",
        "updated_at": "2026-05-26T10:00:00Z",
        "projects": [],
    }), encoding="utf-8")
    out_dir = tmp_path / "panel-out"
    res = _run(out_dir, synthetic_repo)
    assert res.returncode == 0, f"stderr={res.stderr}"
    names = {p.name for p in out_dir.iterdir()}
    assert all(not n.startswith("project_status_") for n in names), (
        f"unexpected project_status pages: {names}"
    )


def test_idempotent_modulo_timestamp(synthetic_repo, tmp_path):
    out_a = tmp_path / "out-a"
    out_b = tmp_path / "out-b"
    res_a = _run(out_a, synthetic_repo)
    assert res_a.returncode == 0
    res_b = _run(out_b, synthetic_repo)
    assert res_b.returncode == 0

    # strip the GENERATED_AT iso timestamps and compare.
    iso_re = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z")
    for fname in ("hub_overview.html", "memory_health.html"):
        a = (out_a / fname).read_text(encoding="utf-8")
        b = (out_b / fname).read_text(encoding="utf-8")
        a_norm = iso_re.sub("<TS>", a)
        b_norm = iso_re.sub("<TS>", b)
        assert a_norm == b_norm, f"non-timestamp drift in {fname}"


def test_repeated_run_into_same_dir_overwrites(synthetic_repo, tmp_path):
    out_dir = tmp_path / "out"
    res1 = _run(out_dir, synthetic_repo)
    assert res1.returncode == 0
    files1 = {p.name for p in out_dir.iterdir()}
    res2 = _run(out_dir, synthetic_repo)
    assert res2.returncode == 0
    files2 = {p.name for p in out_dir.iterdir()}
    # Same file set; second run reused dir without leaving stale files.
    assert files1 == files2


def test_uninitialised_hub_handled(tmp_path):
    """When hub_state is missing entirely, panel still emits 5 pages
    (no project_status), with — placeholders."""
    repo = tmp_path / "empty"
    repo.mkdir()
    (repo / "hub").mkdir()
    out_dir = tmp_path / "out"
    res = _run(out_dir, repo)
    assert res.returncode == 0, f"stderr={res.stderr}"
    assert (out_dir / "hub_overview.html").exists()
    txt = (out_dir / "hub_overview.html").read_text(encoding="utf-8")
    # uninitialised state surfaces with — placeholder for hub_id
    assert "—" in txt or "uninitialised" in txt.lower()


def test_help_returns_zero_no_forbidden_flags():
    res = subprocess.run(
        [sys.executable, str(SCRIPT), "--help"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert res.returncode == 0
    help_text = res.stdout.lower()
    for forbidden in ("--apply", "--execute", "--auto-confirm", "--force"):
        assert forbidden not in help_text, f"forbidden flag {forbidden} appeared in --help"


def test_invalid_repo_root_returns_3(tmp_path):
    out_dir = tmp_path / "out"
    res = _run(out_dir, Path("/nonexistent/path/xyz123"))
    assert res.returncode == 3
