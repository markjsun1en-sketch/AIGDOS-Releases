"""tests.panel — v4.91 M-E B9 c2.

Layer 1 (OS Spec) tests for the static runtime panel export.
No project literals; opaque project_id placeholders only.
"""
