"""test_no_runtime_mutation.py — v4.91 M-E B9 c2.

Compile-time guards for inv_011_panel_no_runtime_mutation. These
tests catch any future drift toward runtime-state-mutating posture
in the static panel exporter (Charter anti-pattern #6 + #11 + #14).

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
PANEL_DIR = REPO_ROOT / "scripts" / "panel"
EXPORT_SCRIPT = PANEL_DIR / "export_static_panel.py"


# ---------------------------------------------------------------------------
# 1. No script under scripts/panel/ defines an --apply / --execute /
# --auto-confirm / --force / --skip-confirm / --bypass /
# --allow-extra argparse flag.
# ---------------------------------------------------------------------------


_FORBIDDEN_FLAG_RE = re.compile(
    r'add_argument\(\s*"\s*-{1,2}(apply|execute|auto[\-_]apply|auto[\-_]confirm|force|skip[\-_]confirm|bypass|allow[\-_]extra|run|do[\-_]apply)\b',
    re.IGNORECASE,
)


def test_no_forbidden_flag_in_panel_scripts():
    found_violations: list[str] = []
    for py in PANEL_DIR.glob("*.py"):
        if py.name == "__init__.py":
            continue
        text = py.read_text(encoding="utf-8")
        for match in _FORBIDDEN_FLAG_RE.finditer(text):
            found_violations.append(f"{py.name}: {match.group(0)}")
    assert not found_violations, (
        f"scripts/panel/ may NOT introduce escape-hatch flags. {found_violations}"
    )


# ---------------------------------------------------------------------------
# 2. No script under scripts/panel/ imports any state-mutating
# governance / ltm / hub / recovery / memory engine. The panel is
# strictly read-only with respect to runtime state.
# ---------------------------------------------------------------------------


_FORBIDDEN_IMPORT_RE = re.compile(
    r"^\s*(from|import)\s+.*?("
    r"retrieval_policy|promotion_policy|"
    r"promote_memory_candidate|reject_memory_candidate|supersede_memory_candidate|"
    r"capture_sprint_close|capture_evolution_proposal|"
    r"create_checkpoint|generate_rollback_plan|verify_rollback|"
    r"sprint_close_hook|generate_preflight_summary|"
    r"run_preflight_consensus|lock_core_version|"
    r"link_project|init_hub|"
    r"rebuild_release_manifest"
    r")\b",
    re.MULTILINE,
)


def test_panel_scripts_do_not_import_mutating_engines():
    found_violations: list[str] = []
    for py in PANEL_DIR.glob("*.py"):
        text = py.read_text(encoding="utf-8")
        for match in _FORBIDDEN_IMPORT_RE.finditer(text):
            found_violations.append(f"{py.name}: {match.group(0).strip()}")
    assert not found_violations, (
        f"scripts/panel/ must NOT import state-mutating engines. {found_violations}"
    )


# ---------------------------------------------------------------------------
# 3. The exporter does NOT call subprocess / os.system / shutil.move /
# shutil.rmtree on runtime tree paths. We allow standard file writes
# (the script writes to --out-dir), but not destructive operations on
# hub/, ltm/, runtime/ paths.
# ---------------------------------------------------------------------------


_FORBIDDEN_RUNTIME_WRITE_RE = re.compile(
    r"(shutil\.(rmtree|move|copy)|os\.system|subprocess\.(run|call|Popen)|os\.unlink|os\.remove)",
)


def test_panel_does_not_invoke_destructive_ops():
    text = EXPORT_SCRIPT.read_text(encoding="utf-8")
    matches = _FORBIDDEN_RUNTIME_WRITE_RE.findall(text)
    assert not matches, (
        "export_static_panel.py must NOT use destructive / subprocess "
        f"primitives on runtime tree paths. Matches: {matches}"
    )


# ---------------------------------------------------------------------------
# 4. The exporter writes ONLY to paths beneath the resolved --out-dir.
# We assert this by source inspection: the only write_text() calls in
# the script must target a path constructed via the out_dir variable.
# (Soft heuristic but catches accidental writes to repo paths.)
# ---------------------------------------------------------------------------


def test_panel_only_writes_under_out_dir():
    text = EXPORT_SCRIPT.read_text(encoding="utf-8")
    write_calls = re.findall(r"\.write_text\s*\(", text)
    # We expect at minimum one write site (the page emission loop). All
    # write sites in the implementation should be within the for-name-html
    # in pages loop where target = out_dir / name.
    assert write_calls, "expected at least one write_text() call"
    # The implementation guarantees the target = out_dir / name pattern;
    # this test asserts the source contains that idiom.
    assert "out_dir / name" in text, (
        "export_static_panel.py must write only to paths constructed "
        "as `out_dir / name`. Drift indicates a write outside the "
        "declared output directory."
    )
