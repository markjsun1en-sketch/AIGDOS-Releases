"""Tests for verify_beta_sprint_exit.check_execution_integrity GUIDED tier
(v4.90 Batch 0.5 Step 0.5.1).

Covers four GUIDED additions on top of the SCAFFOLD-era checks:
  1. Per-task transition timestamp monotonicity (ERROR)
  2. merge.apply / merge.cleanup count balance (ERROR — upgraded from WARN)
  3. handoff orphan detection (WARN)
  4. isolation_unit cross-check (WARN — silently skipped when fixture lacks field)

The SCAFFOLD-era happy/sad paths (no transitions / merge.apply without
cleanup WARN) remain covered by run_mock_smoke harness scenarios S1/S4/S5.
"""
from __future__ import annotations

import json
from pathlib import Path

from verify_beta_sprint_exit import VerifyContext, check_execution_integrity


def _ctx(workspace: Path, audit_log: Path, runtime_state: Path | None = None) -> VerifyContext:
    return VerifyContext(
        workspace=workspace,
        audit_log=audit_log,
        runtime_state=runtime_state or (workspace / "runtime_state.json"),
        sprint_close_checklist=workspace / "sprint_close_checklist.md",
        audit_log_explicit=True,
    )


def _write_audit(audit_log: Path, events: list[dict]) -> None:
    audit_log.parent.mkdir(parents=True, exist_ok=True)
    with audit_log.open("w", encoding="utf-8") as fh:
        for e in events:
            fh.write(json.dumps(e) + "\n")


def _base_event(**kwargs) -> dict:
    """Minimal valid event with required fields populated."""
    base = {
        "event_type": "runtime.transition",
        "timestamp": "2026-05-04T10:00:00Z",
        "actor": "engineering",
        "source_layer": "runtime_registry",
        "status": "ok",
        "task_id": "FT-100",
    }
    base.update(kwargs)
    return base


# -----------------------------------------------------------------------
# 1. Per-task transition timestamp monotonicity
# -----------------------------------------------------------------------

def test_transition_timestamp_monotonic_happy(tmp_path: Path):
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _base_event(timestamp="2026-05-04T09:00:00Z", task_id="FT-100",
                    from_state="open", to_state="in_progress"),
        _base_event(timestamp="2026-05-04T11:00:00Z", task_id="FT-100",
                    from_state="in_progress", to_state="done"),
    ])
    findings = check_execution_integrity(_ctx(tmp_path, audit))
    inversions = [f for f in findings if "inversion" in f.get("message", "")]
    assert inversions == [], inversions


def test_transition_timestamp_monotonic_inversion_error(tmp_path: Path):
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _base_event(timestamp="2026-05-04T11:00:00Z", task_id="FT-100",
                    from_state="open", to_state="in_progress"),
        _base_event(timestamp="2026-05-04T09:00:00Z", task_id="FT-100",
                    from_state="in_progress", to_state="done"),
    ])
    findings = check_execution_integrity(_ctx(tmp_path, audit))
    inversions = [f for f in findings
                  if f.get("severity") == "ERROR" and "inversion" in f.get("message", "")]
    assert len(inversions) == 1
    assert inversions[0].get("task_id") == "FT-100"


def test_transition_timestamp_monotonic_independent_per_task(tmp_path: Path):
    """Different task_ids have independent timestamp lanes — interleaved order is fine."""
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _base_event(timestamp="2026-05-04T09:00:00Z", task_id="FT-100"),
        _base_event(timestamp="2026-05-04T08:00:00Z", task_id="FT-200"),  # earlier than FT-100, but different task
        _base_event(timestamp="2026-05-04T10:00:00Z", task_id="FT-100"),
        _base_event(timestamp="2026-05-04T09:30:00Z", task_id="FT-200"),
    ])
    findings = check_execution_integrity(_ctx(tmp_path, audit))
    inversions = [f for f in findings if "inversion" in f.get("message", "")]
    assert inversions == [], inversions


# -----------------------------------------------------------------------
# 2. merge.apply / merge.cleanup balance
# -----------------------------------------------------------------------

def test_merge_balance_happy(tmp_path: Path):
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _base_event(),
        _base_event(event_type="merge.apply", timestamp="2026-05-04T12:00:00Z"),
        _base_event(event_type="merge.cleanup", timestamp="2026-05-04T12:01:00Z"),
    ])
    findings = check_execution_integrity(_ctx(tmp_path, audit))
    merge_findings = [f for f in findings if "merge" in f.get("message", "").lower()]
    assert merge_findings == [], merge_findings


def test_merge_apply_without_cleanup_remains_warn(tmp_path: Path):
    """Preserved SCAFFOLD-era WARN: apply present, cleanup absent (not a
    structural bug — sometimes intentional in trial runs)."""
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _base_event(),
        _base_event(event_type="merge.apply", timestamp="2026-05-04T12:00:00Z"),
    ])
    findings = check_execution_integrity(_ctx(tmp_path, audit))
    relevant = [f for f in findings if "merge.apply" in f.get("message", "") and "no merge.cleanup" in f.get("message", "")]
    assert len(relevant) == 1
    assert relevant[0].get("severity") == "WARN"


def test_merge_imbalance_error_when_both_present(tmp_path: Path):
    """3 apply vs 2 cleanup is a structural bug → ERROR."""
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _base_event(),
        _base_event(event_type="merge.apply", timestamp="2026-05-04T12:00:00Z"),
        _base_event(event_type="merge.apply", timestamp="2026-05-04T12:01:00Z"),
        _base_event(event_type="merge.apply", timestamp="2026-05-04T12:02:00Z"),
        _base_event(event_type="merge.cleanup", timestamp="2026-05-04T12:03:00Z"),
        _base_event(event_type="merge.cleanup", timestamp="2026-05-04T12:04:00Z"),
    ])
    findings = check_execution_integrity(_ctx(tmp_path, audit))
    relevant = [f for f in findings if "merge.apply" in f.get("message", "") and "merge.cleanup" in f.get("message", "")]
    assert len(relevant) == 1
    assert relevant[0].get("severity") == "ERROR"
    assert relevant[0].get("merge_apply_count") == 3
    assert relevant[0].get("merge_cleanup_count") == 2


# -----------------------------------------------------------------------
# 3. handoff orphan detection
# -----------------------------------------------------------------------

def test_handoff_with_known_task_id_no_warn(tmp_path: Path):
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _base_event(event_type="runtime.create", task_id="FT-100"),
        _base_event(task_id="FT-100"),
        _base_event(event_type="runtime.handoff", task_id="FT-100",
                    timestamp="2026-05-04T12:00:00Z"),
    ])
    findings = check_execution_integrity(_ctx(tmp_path, audit))
    orphans = [f for f in findings if "orphan" in f.get("message", "").lower()
               or "never seen" in f.get("message", "")]
    assert orphans == [], orphans


def test_handoff_with_unknown_task_id_warns(tmp_path: Path):
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _base_event(event_type="runtime.create", task_id="FT-100"),
        _base_event(task_id="FT-100"),
        _base_event(event_type="runtime.handoff", task_id="FT-999",
                    timestamp="2026-05-04T12:00:00Z"),
    ])
    findings = check_execution_integrity(_ctx(tmp_path, audit))
    relevant = [f for f in findings if "never seen" in f.get("message", "")]
    assert len(relevant) == 1
    assert relevant[0].get("severity") == "WARN"
    assert "FT-999" in relevant[0].get("orphan_task_ids", [])


# -----------------------------------------------------------------------
# 4. isolation_unit cross-check
# -----------------------------------------------------------------------

def test_isolation_unit_cross_check_silent_when_field_absent(tmp_path: Path):
    """Default S1-style fixtures lack isolation_unit on transitions; check skips."""
    rs = tmp_path / "runtime_state.json"
    rs.write_text(json.dumps({
        "project_id": "p", "profile": "codex",
        "initialized_at": "2026-05-02T12:00:00Z",
        "isolation_unit": "system_managed",
    }) + "\n", encoding="utf-8")
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [_base_event(task_id="FT-100")])
    findings = check_execution_integrity(_ctx(tmp_path, audit, rs))
    iu_findings = [f for f in findings if "isolation_unit" in f.get("message", "")]
    assert iu_findings == [], iu_findings


def test_isolation_unit_cross_check_mismatch_warns(tmp_path: Path):
    rs = tmp_path / "runtime_state.json"
    rs.write_text(json.dumps({
        "project_id": "p", "profile": "codex",
        "initialized_at": "2026-05-02T12:00:00Z",
        "isolation_unit": "system_managed",
    }) + "\n", encoding="utf-8")
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _base_event(task_id="FT-100", isolation_unit="project_defined"),
    ])
    findings = check_execution_integrity(_ctx(tmp_path, audit, rs))
    relevant = [f for f in findings if "isolation_unit" in f.get("message", "")]
    assert len(relevant) == 1
    assert relevant[0].get("severity") == "WARN"


def test_isolation_unit_cross_check_match_silent(tmp_path: Path):
    rs = tmp_path / "runtime_state.json"
    rs.write_text(json.dumps({
        "project_id": "p", "profile": "codex",
        "initialized_at": "2026-05-02T12:00:00Z",
        "isolation_unit": "project_defined",
    }) + "\n", encoding="utf-8")
    audit = tmp_path / "audit.jsonl"
    _write_audit(audit, [
        _base_event(task_id="FT-100", isolation_unit="project_defined"),
    ])
    findings = check_execution_integrity(_ctx(tmp_path, audit, rs))
    iu_findings = [f for f in findings if "isolation_unit" in f.get("message", "")]
    assert iu_findings == [], iu_findings
