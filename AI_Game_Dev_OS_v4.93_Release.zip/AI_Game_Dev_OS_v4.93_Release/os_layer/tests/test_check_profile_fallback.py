"""Tests for C3 run_beta_sprint_check.check_profile_validity fallback."""
from __future__ import annotations

import os
from pathlib import Path

from run_beta_sprint_check import ROOT, check_profile_validity


def test_workspace_profile_takes_precedence(workspace: Path):
    # Fake workspace with its own profile file.
    ws_profile = workspace / "config" / "profiles" / "workbuddy_private.json"
    ws_profile.parent.mkdir(parents=True)
    # Copy pkg profile so required_fields check doesn't fail.
    pkg_profile = ROOT / "config" / "profiles" / "workbuddy_private.json"
    ws_profile.write_text(pkg_profile.read_text())

    findings = check_profile_validity("workbuddy_private", workspace)
    parse = next(f for f in findings if f["check"] == "profile.parse")
    assert parse["status"] == "ok"
    assert parse["source"] == "workspace"


def test_package_root_fallback_for_empty_workspace(workspace: Path):
    findings = check_profile_validity("workbuddy_private", workspace)
    parse = next(f for f in findings if f["check"] == "profile.parse")
    assert parse["status"] == "ok"
    assert parse["source"] == "package_root"


def test_error_when_both_locations_missing(workspace: Path, monkeypatch):
    # Temporarily rename the pkg profile so neither location has it.
    p = ROOT / "config" / "profiles" / "workbuddy_private.json"
    backup = p.with_suffix(".json.test_backup")
    os.rename(str(p), str(backup))
    try:
        findings = check_profile_validity("workbuddy_private", workspace)
        assert findings[0]["check"] == "profile.file"
        assert findings[0]["status"] == "error"
        assert "missing" in findings[0]["message"]
        assert "fallback_path" in findings[0]
    finally:
        os.rename(str(backup), str(p))
