"""test_rebuild_release_manifest.py — v4.91 P2 c2.

Covers scripts/rebuild_release_manifest.py preservation behaviour:
metadata fields read from the source manifest travel through
unchanged; only the file-inventory tier (required_manifest_files /
optional_seed_files / test_fixtures + counts) is recomputed. Also
covers the new --check / --out / --root flags and refusal to emit
when transients are present.

Layer 1 (OS Spec). No project names; fixture project IDs use
generic placeholders.
"""
from __future__ import annotations

import json
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = REPO_ROOT / "scripts" / "rebuild_release_manifest.py"
LIVE_MANIFEST = REPO_ROOT / "RELEASE_MANIFEST.json"

sys.path.insert(0, str(REPO_ROOT / "scripts"))

# Import the module by file path so tests can call build_manifest()
# directly. The script is not packaged; this mirrors the pattern other
# governance tests use (e.g. test_state_machine_alignment.py).
import importlib.util  # noqa: E402

_spec = importlib.util.spec_from_file_location("rebuild_release_manifest", SCRIPT)
_mod = importlib.util.module_from_spec(_spec)  # type: ignore[arg-type]
_spec.loader.exec_module(_mod)  # type: ignore[union-attr]
build_manifest = _mod.build_manifest


# ---------------------------------------------------------------------------
# Fixture builder — minimal synthetic tree with the metadata shape the
# rebuilder must preserve.
# ---------------------------------------------------------------------------


def _make_seed_manifest(*, with_tenant_runtime: bool = True) -> dict:
    base: dict = {
        "package_name": "AI_Game_Dev_OS_v4.fixture",
        "base_from": "AI_Game_Dev_OS_v4.fixture_prev",
        "package_root_dir": "AI_Game_Dev_OS_v4.fixture_release",
        "superset_policy": "fixture",
        "required_files": ["README.md"],
        "required_dirs": [],
        "manifest_schema_version": "2.3",
        "manifest_schema_notes": [
            "fixture seed note 1 — Batch 12.1a",
            "fixture seed note 2 — Batch 14.8 — em-dash + arrow → token",
        ],
        "byte_lock": {
            "ref_pack": "fixture_ref",
            "tree_sha": "0" * 40,
            "verification_modes": ["source_tree", "skipped"],
        },
        "exclusions": {
            "self_referential": ["RELEASE_MANIFEST.json", "CHECKSUMS.sha"],
            "transient_patterns": [
                "__pycache__/",
                ".pytest_cache/",
                "*.pyc",
                ".DS_Store",
                "._*",
                # 5 extended patterns (B1+ era) that the legacy
                # rebuilder used to strip:
                "fixture/.lock",
                "fixture/cache/",
                "fixture/logs/",
                "fixture/reports/",
                "fixture/scratch.lock",
            ],
            "generated_runtime_outputs": ["exports/**  (except exports/.gitignore)"],
        },
        "classification_rules": {
            "required_manifest_files": "ordinary content",
            "optional_seed_files": "*.gitkeep / *.keep",
            "test_fixtures": "trial_workspaces/**",
            "generated_runtime_outputs": "exports/**",
            # tenant_runtime key — the legacy rebuilder used to strip
            # this. Preservation must keep it.
            "tenant_runtime": "tenant subtrees governed by adopting projects",
        },
        "required_manifest_count": 0,
        "optional_seed_count": 0,
        "test_fixtures_count": 0,
        "required_manifest_files": [],
        "optional_seed_files": [],
        "test_fixtures": [],
    }
    if with_tenant_runtime:
        base["tenant_runtime_entries"] = [
            {
                "path_template": "ltm/project/<project_id>/**",
                "owning_authority": "adopting_project",
                "purpose": "fixture sovereign subtree",
                "promotion_target": True,
            }
        ]
    return base


def _make_tree(tmp_path: Path, *, include_gitkeep: bool = True,
               include_test_fixture: bool = True,
               include_transient: bool = False) -> Path:
    """Materialise a synthetic repo root under ``tmp_path``."""
    root = tmp_path / "fixture_root"
    root.mkdir()

    # ordinary content
    (root / "README.md").write_text("readme\n", encoding="utf-8")
    (root / "VERSION").write_text("v4.fixture\n", encoding="utf-8")

    # required marker
    (root / "config").mkdir()
    (root / "config" / ".core_os_root").write_text("v4-fixture-marker\n", encoding="utf-8")

    # optional seed
    if include_gitkeep:
        seed_dir = root / "ltm" / "cross_project" / "candidates"
        seed_dir.mkdir(parents=True)
        (seed_dir / ".gitkeep").write_text("", encoding="utf-8")

    # test fixture
    if include_test_fixture:
        tw = root / "trial_workspaces"
        tw.mkdir()
        (tw / "README.md").write_text("trial readme\n", encoding="utf-8")
        (tw / "fixture_a.txt").write_text("fixture content\n", encoding="utf-8")

    # exports/.gitignore (required) + ephemeral content (excluded)
    (root / "exports").mkdir()
    (root / "exports" / ".gitignore").write_text("*\n", encoding="utf-8")
    (root / "exports" / "smoke_run.json").write_text("{}\n", encoding="utf-8")

    # transient (only if requested — exercises the refusal path)
    if include_transient:
        cache_dir = root / "scripts" / "__pycache__"
        cache_dir.mkdir(parents=True)
        (cache_dir / "stale.cpython-313.pyc").write_text("", encoding="utf-8")

    return root


def _seed_manifest_at(root: Path, **kwargs) -> dict:
    seed = _make_seed_manifest(**kwargs)
    (root / "RELEASE_MANIFEST.json").write_text(
        json.dumps(seed, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return seed


# ---------------------------------------------------------------------------
# 1. Top-level metadata preservation (round-trip)
# ---------------------------------------------------------------------------


def test_preservation_top_level_fields(tmp_path):
    root = _make_tree(tmp_path)
    seed = _seed_manifest_at(root)
    new, stats = build_manifest(root)

    # All metadata fields the rebuilder is supposed to preserve.
    for key in (
        "package_name",
        "base_from",
        "package_root_dir",
        "superset_policy",
        "required_files",
        "required_dirs",
        "manifest_schema_version",
        "manifest_schema_notes",
        "byte_lock",
        "tenant_runtime_entries",
    ):
        assert new[key] == seed[key], f"preservation broke for key {key!r}"


# ---------------------------------------------------------------------------
# 2. classification_rules.tenant_runtime survives
# ---------------------------------------------------------------------------


def test_preservation_classification_rules_tenant_runtime_key(tmp_path):
    root = _make_tree(tmp_path)
    _seed_manifest_at(root)
    new, _ = build_manifest(root)
    assert "tenant_runtime" in new["classification_rules"], (
        "classification_rules.tenant_runtime was stripped — that is the "
        "legacy rebuilder bug v4.91 P2 fixes"
    )


# ---------------------------------------------------------------------------
# 3. exclusions.transient_patterns extended list survives
# ---------------------------------------------------------------------------


def test_preservation_exclusions_transient_patterns_extended(tmp_path):
    root = _make_tree(tmp_path)
    seed = _seed_manifest_at(root)
    new, _ = build_manifest(root)
    assert (
        new["exclusions"]["transient_patterns"]
        == seed["exclusions"]["transient_patterns"]
    )
    # The 5 B1+ era patterns must still be present after rebuild.
    for required_pat in (
        "fixture/.lock",
        "fixture/cache/",
        "fixture/logs/",
        "fixture/reports/",
        "fixture/scratch.lock",
    ):
        assert required_pat in new["exclusions"]["transient_patterns"]


# ---------------------------------------------------------------------------
# 4. counts match list lengths
# ---------------------------------------------------------------------------


def test_required_manifest_count_matches_list_length(tmp_path):
    root = _make_tree(tmp_path)
    _seed_manifest_at(root)
    new, _ = build_manifest(root)
    assert new["required_manifest_count"] == len(new["required_manifest_files"])
    assert new["optional_seed_count"] == len(new["optional_seed_files"])
    assert new["test_fixtures_count"] == len(new["test_fixtures"])


# ---------------------------------------------------------------------------
# 5. --check on a clean tree returns 0
# ---------------------------------------------------------------------------


def test_check_mode_clean_returns_zero(tmp_path):
    root = _make_tree(tmp_path)
    _seed_manifest_at(root)
    # First write the manifest so on-disk == rebuild output.
    res_write = subprocess.run(
        [sys.executable, str(SCRIPT), "--root", str(root)],
        capture_output=True, text=True, timeout=30,
    )
    assert res_write.returncode == 0, res_write.stderr
    # Now --check should succeed.
    res_check = subprocess.run(
        [sys.executable, str(SCRIPT), "--root", str(root), "--check"],
        capture_output=True, text=True, timeout=30,
    )
    assert res_check.returncode == 0, (
        f"--check returned {res_check.returncode}; "
        f"stdout={res_check.stdout!r}; stderr={res_check.stderr!r}"
    )
    assert "clean" in res_check.stdout


# ---------------------------------------------------------------------------
# 6. --check on a drifted tree returns 1 + diff
# ---------------------------------------------------------------------------


def test_check_mode_drift_returns_one(tmp_path):
    root = _make_tree(tmp_path)
    _seed_manifest_at(root)
    # Bootstrap: write the manifest with current contents.
    subprocess.run(
        [sys.executable, str(SCRIPT), "--root", str(root)],
        capture_output=True, text=True, timeout=30,
    )
    # Add a new file to drift the tree.
    (root / "drift.md").write_text("new content\n", encoding="utf-8")
    res = subprocess.run(
        [sys.executable, str(SCRIPT), "--root", str(root), "--check"],
        capture_output=True, text=True, timeout=30,
    )
    assert res.returncode == 1, (
        f"expected exit 1 on drift; got {res.returncode}\n"
        f"stdout={res.stdout!r}\nstderr={res.stderr!r}"
    )
    assert "DRIFT" in res.stderr
    assert "drift.md" in res.stderr


# ---------------------------------------------------------------------------
# 7. Transient files refuse to rebuild (exit 2)
# ---------------------------------------------------------------------------


def test_transient_files_refused(tmp_path):
    root = _make_tree(tmp_path, include_transient=True)
    _seed_manifest_at(root)
    res = subprocess.run(
        [sys.executable, str(SCRIPT), "--root", str(root)],
        capture_output=True, text=True, timeout=30,
    )
    # The rebuilder prunes __pycache__ in walk; .pyc files outside
    # such a dir would surface, but inside they're already pruned.
    # Place a stray .pyc at root level to trigger the refusal path.
    (root / "stray.pyc").write_text("", encoding="utf-8")
    res = subprocess.run(
        [sys.executable, str(SCRIPT), "--root", str(root)],
        capture_output=True, text=True, timeout=30,
    )
    assert res.returncode == 2, (
        f"expected exit 2 on transient; got {res.returncode}\n"
        f"stdout={res.stdout!r}\nstderr={res.stderr!r}"
    )
    assert "transient" in res.stderr


# ---------------------------------------------------------------------------
# 8. Idempotency — two consecutive rebuilds produce byte-identical output
# ---------------------------------------------------------------------------


def test_idempotency(tmp_path):
    root = _make_tree(tmp_path)
    _seed_manifest_at(root)
    res1 = subprocess.run(
        [sys.executable, str(SCRIPT), "--root", str(root)],
        capture_output=True, text=True, timeout=30,
    )
    assert res1.returncode == 0
    body1 = (root / "RELEASE_MANIFEST.json").read_bytes()
    res2 = subprocess.run(
        [sys.executable, str(SCRIPT), "--root", str(root)],
        capture_output=True, text=True, timeout=30,
    )
    assert res2.returncode == 0
    body2 = (root / "RELEASE_MANIFEST.json").read_bytes()
    assert body1 == body2, "rebuilder is not idempotent — second run drifted"


# ---------------------------------------------------------------------------
# 9 (bonus). Live repo --check is clean — guards against future drift
# ---------------------------------------------------------------------------


def test_live_repo_check_is_clean():
    """Sanity: the live repo manifest is in sync with what the rebuilder
    would emit. Closure-gate adoption point for P9."""
    if not LIVE_MANIFEST.exists():
        pytest.skip("RELEASE_MANIFEST.json not present (out-of-tree test run)")
    res = subprocess.run(
        [sys.executable, str(SCRIPT), "--check"],
        capture_output=True, text=True, timeout=60,
        cwd=str(REPO_ROOT),
    )
    assert res.returncode == 0, (
        f"live repo manifest drift — rerun rebuilder.\n"
        f"stdout={res.stdout!r}\nstderr={res.stderr[:2000]!r}"
    )
