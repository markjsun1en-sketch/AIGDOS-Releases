"""Tests for M9.0.4 — boot_agent_thread.py.

Phase 4 Step 3 / M9.0 Sprint+Agent cold-start / commit 7 (M9.0.7) of
8-commit chain.

Covers:
- boot_mode resolution: explicit_task / explicit_issue /
  default_cold_start per the CLI flag combination.
- profile resolution: --profile > COLD_START_PROFILE env >
  SPRINT_GOVERNED default.
- CLI requires at least one selector (matches generate_cold_start_pack.py).
- --dry-run exits before subprocess spawn and returns the resolved
  boot context.
- Full subprocess chain: boot_agent_thread → generate_cold_start_pack
  succeeds on the M9.0.5 fixture and injects the 4 boot decorator keys
  (boot_mode / boot_source / cold_start_performed / profile) into the
  final JSON.

Working language: English (permanent contract §11).
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from boot_agent_thread import _resolve_boot_mode, _resolve_profile


_PKG_ROOT = Path(__file__).resolve().parents[1]
_FIXTURE = _PKG_ROOT / "tests" / "fixtures" / "sprint_window"
_BOOT_SCRIPT = _PKG_ROOT / "tools" / "runtime" / "boot_agent_thread.py"


def _make_args(**overrides) -> argparse.Namespace:
    base = dict(
        agent=None, thread=None, task_id=None, issue_id=None, profile=None,
        repo_root=None, dry_run=False,
    )
    base.update(overrides)
    return argparse.Namespace(**base)


# ---------------------------------------------------------------------------
# _resolve_boot_mode
# ---------------------------------------------------------------------------


def test_boot_mode_explicit_task():
    assert _resolve_boot_mode(_make_args(task_id="T-1")) == "explicit_task"


def test_boot_mode_explicit_issue():
    assert _resolve_boot_mode(_make_args(issue_id="I-1")) == "explicit_issue"


def test_boot_mode_task_id_overrides_issue_id():
    # Both flags set; task wins by the code's if/elif order.
    assert _resolve_boot_mode(_make_args(task_id="T-1", issue_id="I-1")) == "explicit_task"


def test_boot_mode_default_cold_start():
    assert _resolve_boot_mode(_make_args(agent="x")) == "default_cold_start"


# ---------------------------------------------------------------------------
# _resolve_profile
# ---------------------------------------------------------------------------


def test_profile_flag_wins_over_env(monkeypatch):
    monkeypatch.setenv("COLD_START_PROFILE", "SPRINT_DEEP")
    assert _resolve_profile(_make_args(profile="SPRINT_GOVERNED")) == "SPRINT_GOVERNED"


def test_profile_env_wins_when_flag_absent(monkeypatch):
    monkeypatch.setenv("COLD_START_PROFILE", "ARCHIVE_LOOKUP")
    assert _resolve_profile(_make_args()) == "ARCHIVE_LOOKUP"


def test_profile_defaults_to_sprint_governed(monkeypatch):
    monkeypatch.delenv("COLD_START_PROFILE", raising=False)
    assert _resolve_profile(_make_args()) == "SPRINT_GOVERNED"


def test_profile_ignores_empty_env(monkeypatch):
    monkeypatch.setenv("COLD_START_PROFILE", "   ")
    assert _resolve_profile(_make_args()) == "SPRINT_GOVERNED"


# ---------------------------------------------------------------------------
# CLI contract
# ---------------------------------------------------------------------------


def test_cli_requires_at_least_one_selector():
    cmd = [sys.executable, str(_BOOT_SCRIPT)]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert result.returncode != 0
    assert "required" in (result.stderr + result.stdout).lower()


def test_cli_rejects_unknown_profile():
    cmd = [sys.executable, str(_BOOT_SCRIPT), "--agent", "x", "--profile", "NONSENSE"]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert result.returncode != 0
    assert "nonsense" in (result.stderr + result.stdout).lower() or "invalid choice" in (result.stderr + result.stdout).lower()


# ---------------------------------------------------------------------------
# --dry-run
# ---------------------------------------------------------------------------


def test_dry_run_short_circuits_before_subprocess(tmp_path):
    env = os.environ.copy()
    env.pop("COLD_START_PROFILE", None)
    cmd = [
        sys.executable, str(_BOOT_SCRIPT),
        "--agent", "engineer",
        "--profile", "SPRINT_DEEP",
        "--dry-run",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False, env=env)
    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["dry_run"] is True
    assert payload["boot_mode"] == "default_cold_start"
    assert payload["boot_source"] == "boot_agent_thread.py"
    assert payload["profile"] == "SPRINT_DEEP"
    assert payload["agent"] == "engineer"


def test_dry_run_explicit_task_reports_explicit_task_mode():
    cmd = [
        sys.executable, str(_BOOT_SCRIPT),
        "--task-id", "TASK-7",
        "--dry-run",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["boot_mode"] == "explicit_task"
    assert payload["task_id"] == "TASK-7"


# ---------------------------------------------------------------------------
# Full subprocess chain: boot → cold-start pack
# ---------------------------------------------------------------------------


def test_full_boot_chain_on_fixture_decorates_pack():
    cmd = [
        sys.executable, str(_BOOT_SCRIPT),
        "--repo-root", str(_FIXTURE),
        "--agent", "engineer",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    # Pack contract fields (from M9.0.5) survive.
    assert payload["schema_version"] == "cold_start_pack.v1"
    assert payload["primary_task"]["task_id"] == "TASK-1"
    # Boot decorator fields (from M9.0.4).
    assert payload["boot_mode"] == "default_cold_start"
    assert payload["boot_source"] == "boot_agent_thread.py"
    assert payload["cold_start_performed"] is True
    assert payload["profile"] == "SPRINT_GOVERNED"


def test_full_boot_chain_with_issue_id_sets_explicit_issue_mode():
    cmd = [
        sys.executable, str(_BOOT_SCRIPT),
        "--repo-root", str(_FIXTURE),
        "--issue-id", "BLOCK-1",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["boot_mode"] == "explicit_issue"
    # BLOCK-1 links to TASK-2 via blocker_ids.
    assert payload["primary_task"]["task_id"] == "TASK-2"
