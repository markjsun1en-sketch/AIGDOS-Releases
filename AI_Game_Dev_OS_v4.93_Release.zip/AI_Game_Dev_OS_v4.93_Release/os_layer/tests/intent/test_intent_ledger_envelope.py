"""test_intent_ledger_envelope.py — v4.91 Batch 6 c3.

Verifies that ledger entries appended by the 3 intent CLIs strictly satisfy
the v4.89 9-field audit envelope contract + the intent-specific details
payload defined by ``schemas/intent/intent_baseline_ledger.schema.json``.

End-to-end: drive each CLI with synthetic inputs and validate the resulting
JSONL line against the schema using ``jsonschema``.

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")


REPO_ROOT = Path(__file__).resolve().parents[2]
INTENT_DIR = REPO_ROOT / "scripts" / "intent"
SCHEMA = REPO_ROOT / "schemas" / "intent" / "intent_baseline_ledger.schema.json"
PYTHON = sys.executable


def _baseline(intent_id: str = "intent_alpha", status: str = "draft") -> dict:
    b = {
        "schema_version": "1.0.0",
        "intent_id": intent_id,
        "project_id": "project_alpha",
        "scope": "feature",
        "owner": {"role": "producer", "approval_required_for_change": True},
        "intent_summary": "Build a 3-turn combat loop for MVP validation.",
        "goals": ["Validate combat pacing"],
        "non_goals": ["No meta progression"],
        "acceptance_criteria": ["Combat loop completes start-to-finish"],
        "freeze": {"status": status},
    }
    if status == "frozen":
        b["freeze"]["frozen_at"] = "2026-05-28T00:00:00Z"
        b["freeze"]["frozen_by"] = "producer:alice"
    return b


def _write(p: Path, obj: dict) -> Path:
    p.write_text(json.dumps(obj, indent=2), encoding="utf-8")
    return p


def _read_ledger(ledger: Path) -> list[dict]:
    return [
        json.loads(line)
        for line in ledger.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def _validate_against_schema(entry: dict) -> None:
    schema_obj = json.loads(SCHEMA.read_text(encoding="utf-8"))
    jsonschema.validate(entry, schema_obj)


# ---------------------------------------------------------------------------
# generate_intent_baseline ledger envelope.
# ---------------------------------------------------------------------------


def test_generate_baseline_emits_valid_envelope(tmp_path):
    inp = _write(tmp_path / "draft.json", _baseline(status="draft"))
    ledger = tmp_path / "ledger.jsonl"
    res = subprocess.run(
        [
            PYTHON, str(INTENT_DIR / "generate_intent_baseline.py"),
            "--input", str(inp),
            "--actor", "producer:alice",
            "--ledger", str(ledger),
        ],
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    assert res.returncode == 0
    entries = _read_ledger(ledger)
    assert len(entries) == 1
    _validate_against_schema(entries[0])
    assert entries[0]["event_type"] == "intent_baseline_event"
    assert entries[0]["source_layer"] == "L1"
    assert entries[0]["audit_status"] == "recorded"
    assert re.fullmatch(r"^ib_[0-9a-f]{8}$", entries[0]["event_id"])
    assert re.fullmatch(
        r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$",
        entries[0]["timestamp"],
    )


# ---------------------------------------------------------------------------
# validate_intent_freeze ledger envelope on FREEZE_VIOLATION.
# ---------------------------------------------------------------------------


def test_freeze_violation_emits_valid_envelope(tmp_path):
    bl = _write(tmp_path / "baseline.json", _baseline(status="frozen"))
    mutated = _baseline(status="frozen")
    mutated["goals"].append("Smuggled goal")
    pr = _write(tmp_path / "proposed.json", mutated)
    ledger = tmp_path / "ledger.jsonl"
    res = subprocess.run(
        [
            PYTHON, str(INTENT_DIR / "validate_intent_freeze.py"),
            "--baseline", str(bl), "--proposed", str(pr),
            "--actor", "producer:alice", "--ledger", str(ledger),
        ],
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    assert res.returncode == 5
    entries = _read_ledger(ledger)
    assert len(entries) == 1
    _validate_against_schema(entries[0])
    assert entries[0]["result"] == "FREEZE_VIOLATION"


# ---------------------------------------------------------------------------
# generate_intent_diff_report ledger envelope.
# ---------------------------------------------------------------------------


def test_diff_generated_emits_valid_envelope(tmp_path):
    bl = _write(tmp_path / "baseline.json", _baseline(status="frozen"))
    pr = _write(tmp_path / "proposed.json", _baseline(status="frozen"))
    ledger = tmp_path / "ledger.jsonl"
    res = subprocess.run(
        [
            PYTHON, str(INTENT_DIR / "generate_intent_diff_report.py"),
            "--baseline", str(bl), "--proposed", str(pr),
            "--actor", "producer:alice",
            "--changed-references", "x.md",
            "--ledger", str(ledger),
            "--output", "-",
        ],
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    assert res.returncode == 0
    entries = _read_ledger(ledger)
    assert len(entries) == 1
    _validate_against_schema(entries[0])
    assert entries[0]["result"] == "DIFF_GENERATED"
    assert entries[0]["details"]["diff_report_id"].startswith("idr_")


# ---------------------------------------------------------------------------
# Multi-CLI ledger appends preserve order + uniqueness.
# ---------------------------------------------------------------------------


def test_multi_cli_appends_preserve_uniqueness_and_order(tmp_path):
    inp = _write(tmp_path / "draft.json", _baseline(status="draft"))
    ledger = tmp_path / "ledger.jsonl"
    # Append three times via generate_intent_baseline
    for _ in range(3):
        res = subprocess.run(
            [
                PYTHON, str(INTENT_DIR / "generate_intent_baseline.py"),
                "--input", str(inp), "--actor", "producer:alice",
                "--ledger", str(ledger),
            ],
            capture_output=True, text=True, cwd=str(REPO_ROOT),
        )
        assert res.returncode == 0
    entries = _read_ledger(ledger)
    assert len(entries) == 3
    ids = [e["event_id"] for e in entries]
    assert len(set(ids)) == 3, f"event_id collision detected in {ids}"
    # All envelope fields valid
    for e in entries:
        _validate_against_schema(e)
        assert e["event_type"] == "intent_baseline_event"
