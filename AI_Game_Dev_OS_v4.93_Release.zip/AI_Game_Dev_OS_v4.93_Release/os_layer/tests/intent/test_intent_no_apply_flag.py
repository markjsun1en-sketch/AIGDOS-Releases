"""test_intent_no_apply_flag.py — v4.91 Batch 6 c3.

Compile-time guard for inv_012_intent_baseline_freeze_respected. These tests
catch any future drift toward an enforcement / auto-apply / override-freeze
posture in the intent governance v0 toolchain (Charter anti-pattern #6 + #11
+ #13).

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
INTENT_DIR = REPO_ROOT / "scripts" / "intent"
SCHEMA_DIR = REPO_ROOT / "schemas" / "intent"
DIFF_REPORT_SCHEMA = SCHEMA_DIR / "intent_diff_report.schema.json"
BASELINE_SCHEMA = SCHEMA_DIR / "intent_baseline.schema.json"


# ---------------------------------------------------------------------------
# Forbidden execution / override flags must NOT appear in scripts/intent/.
# ---------------------------------------------------------------------------


_FORBIDDEN_FLAG_RE = re.compile(
    r'add_argument\(\s*"\s*-{1,2}'
    r'(apply|execute|auto[\-_]apply|auto[\-_]confirm|force|skip[\-_]confirm'
    r'|bypass|allow[\-_]extra|override[\-_]freeze|run|do[\-_]apply)\b',
    re.IGNORECASE,
)


def test_no_apply_flag_in_intent_scripts():
    offenders: list[tuple[Path, int, str]] = []
    for py in INTENT_DIR.rglob("*.py"):
        text = py.read_text(encoding="utf-8")
        for m in _FORBIDDEN_FLAG_RE.finditer(text):
            line = text.count("\n", 0, m.start()) + 1
            offenders.append((py.relative_to(REPO_ROOT), line, m.group(0)))
    assert not offenders, (
        f"Charter anti-pattern #6/#7 violation — scripts/intent/* defines "
        f"a forbidden execution / override flag: {offenders}"
    )


# ---------------------------------------------------------------------------
# auto_semantic_judgement schema-const enforcement.
# ---------------------------------------------------------------------------


def test_auto_semantic_judgement_const_not_performed_at_source():
    schema = json.loads(DIFF_REPORT_SCHEMA.read_text(encoding="utf-8"))
    field = schema["properties"]["auto_semantic_judgement"]
    assert field.get("const") == "not_performed", (
        f"auto_semantic_judgement const must remain literal 'not_performed'; "
        f"got {field.get('const')!r}"
    )


# ---------------------------------------------------------------------------
# approval_required_for_change schema-const enforcement.
# ---------------------------------------------------------------------------


def test_approval_required_for_change_const_true_at_source():
    schema = json.loads(BASELINE_SCHEMA.read_text(encoding="utf-8"))
    field = schema["properties"]["owner"]["properties"]["approval_required_for_change"]
    assert field.get("const") is True, (
        f"approval_required_for_change const must remain literal True; "
        f"got {field.get('const')!r}"
    )


# ---------------------------------------------------------------------------
# freeze.status closed 4-enum.
# ---------------------------------------------------------------------------


def test_freeze_status_enum_locked_at_4_values():
    schema = json.loads(BASELINE_SCHEMA.read_text(encoding="utf-8"))
    enum = schema["properties"]["freeze"]["properties"]["status"]["enum"]
    assert sorted(enum) == sorted(["draft", "frozen", "reopened", "superseded"]), (
        f"freeze.status enum must remain the closed 4-vocabulary; got {enum!r}"
    )


# ---------------------------------------------------------------------------
# ledger result closed 6-enum.
# ---------------------------------------------------------------------------


def test_ledger_result_enum_locked_at_6_values():
    schema_obj = json.loads(
        (SCHEMA_DIR / "intent_baseline_ledger.schema.json").read_text(encoding="utf-8")
    )
    enum = schema_obj["properties"]["result"]["enum"]
    expected = {
        "FROZEN", "REOPENED", "SUPERSEDED",
        "DRAFT_VALIDATED", "DIFF_GENERATED", "FREEZE_VIOLATION",
    }
    assert set(enum) == expected, (
        f"intent ledger result enum must remain the closed 6-vocabulary; got {enum!r}"
    )


# ---------------------------------------------------------------------------
# scope closed 6-enum.
# ---------------------------------------------------------------------------


def test_scope_enum_locked_at_6_values():
    schema = json.loads(BASELINE_SCHEMA.read_text(encoding="utf-8"))
    enum = schema["properties"]["scope"]["enum"]
    expected = {
        "feature", "sprint", "milestone",
        "runtime_contract", "visual_standard", "asset_standard",
    }
    assert set(enum) == expected, (
        f"scope enum must remain the closed 6-vocabulary; got {enum!r}"
    )


# ---------------------------------------------------------------------------
# owner.role closed 6-enum.
# ---------------------------------------------------------------------------


def test_owner_role_enum_locked_at_6_values():
    schema = json.loads(BASELINE_SCHEMA.read_text(encoding="utf-8"))
    enum = schema["properties"]["owner"]["properties"]["role"]["enum"]
    expected = {
        "producer", "tech_lead", "design_lead",
        "art_lead", "qa_lead", "executive_producer",
    }
    assert set(enum) == expected, (
        f"owner.role enum must remain the closed 6-vocabulary; got {enum!r}"
    )


# ---------------------------------------------------------------------------
# reason_codes closed 7-enum on diff_report schema.
# ---------------------------------------------------------------------------


def test_reason_codes_enum_locked_at_7_values():
    schema = json.loads(DIFF_REPORT_SCHEMA.read_text(encoding="utf-8"))
    enum = schema["properties"]["reason_codes"]["items"]["enum"]
    expected = {
        "player_facing_visual_semantics",
        "runtime_contract_sensitive",
        "reusable_asset_standard",
        "non_goal_relaxation",
        "acceptance_criteria_removal",
        "cross_project_inheritance",
        "owner_initiated_reopen",
    }
    assert set(enum) == expected, (
        f"reason_codes enum must remain the closed 7-vocabulary; got {enum!r}"
    )
