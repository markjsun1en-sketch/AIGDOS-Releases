"""test_intent_forbidden_actors.py — v4.91 Batch 6 c3.

Verifies the 10-token forbidden_actors vocabulary (Charter anti-pattern #13)
is refused at runtime by all 3 intent CLIs:

    auto / system / agent / automation / robot / ci
    majority / consensus / vote / tally

The check rejects:

- bare token (e.g. ``--actor auto``)
- prefix-smuggled (e.g. ``--actor auto-orchestrator`` / ``--actor system_admin``)

It does NOT reject legitimate owner-role identifiers (e.g.
``producer:alice`` / ``tech_lead`` / ``art_lead``).

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
INTENT_DIR = REPO_ROOT / "scripts" / "intent"
GENERATE = INTENT_DIR / "generate_intent_baseline.py"
VALIDATE = INTENT_DIR / "validate_intent_freeze.py"
DIFF = INTENT_DIR / "generate_intent_diff_report.py"

PYTHON = sys.executable


FORBIDDEN_TOKENS = (
    "auto", "system", "agent", "automation", "robot", "ci",
    "majority", "consensus", "vote", "tally",
)


PERMITTED_ACTORS = (
    "producer:alice",
    "tech_lead",
    "art_lead:bob",
    "qa_lead:carol",
    "executive_producer",
    "design_lead:dave",
)


def _baseline_text() -> dict:
    return {
        "schema_version": "1.0.0",
        "intent_id": "intent_alpha",
        "project_id": "project_alpha",
        "scope": "feature",
        "owner": {"role": "producer", "approval_required_for_change": True},
        "intent_summary": "Build a 3-turn combat loop for MVP validation.",
        "goals": ["Validate combat pacing"],
        "non_goals": ["No meta progression"],
        "acceptance_criteria": ["Combat loop completes start-to-finish"],
        "freeze": {"status": "draft"},
    }


def _write(p: Path, obj: dict) -> Path:
    p.write_text(json.dumps(obj, indent=2), encoding="utf-8")
    return p


@pytest.mark.parametrize("token", FORBIDDEN_TOKENS)
def test_generate_baseline_rejects_bare_forbidden_actor(tmp_path, token):
    inp = _write(tmp_path / "draft.json", _baseline_text())
    ledger = tmp_path / "ledger.jsonl"
    res = subprocess.run(
        [PYTHON, str(GENERATE), "--input", str(inp), "--actor", token, "--ledger", str(ledger)],
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    assert res.returncode == 2, f"expected EXIT_FORBIDDEN_ACTOR=2 for token={token!r}, got {res.returncode}\n{res.stderr}"
    assert "forbidden_actors" in res.stderr or "forbidden" in res.stderr.lower()


@pytest.mark.parametrize("token", FORBIDDEN_TOKENS)
def test_generate_baseline_rejects_prefix_smuggled_actor(tmp_path, token):
    """`auto-orchestrator` / `system_admin` etc. — the prefix gate fires."""
    inp = _write(tmp_path / "draft.json", _baseline_text())
    ledger = tmp_path / "ledger.jsonl"
    smuggled = f"{token}-impostor"
    res = subprocess.run(
        [PYTHON, str(GENERATE), "--input", str(inp), "--actor", smuggled, "--ledger", str(ledger)],
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    assert res.returncode == 2, f"expected exit 2 for {smuggled!r}, got {res.returncode}"


@pytest.mark.parametrize("token", FORBIDDEN_TOKENS)
def test_validate_freeze_rejects_bare_forbidden_actor(tmp_path, token):
    bl = _write(tmp_path / "baseline.json", _baseline_text())
    pr = _write(tmp_path / "proposed.json", _baseline_text())
    ledger = tmp_path / "ledger.jsonl"
    res = subprocess.run(
        [
            PYTHON, str(VALIDATE),
            "--baseline", str(bl), "--proposed", str(pr),
            "--actor", token, "--ledger", str(ledger),
        ],
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    assert res.returncode == 2


@pytest.mark.parametrize("token", FORBIDDEN_TOKENS)
def test_diff_report_rejects_bare_forbidden_actor(tmp_path, token):
    bl = _write(tmp_path / "baseline.json", _baseline_text())
    pr = _write(tmp_path / "proposed.json", _baseline_text())
    ledger = tmp_path / "ledger.jsonl"
    res = subprocess.run(
        [
            PYTHON, str(DIFF),
            "--baseline", str(bl), "--proposed", str(pr),
            "--actor", token, "--changed-references", "x.md",
            "--ledger", str(ledger),
        ],
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    assert res.returncode == 2


@pytest.mark.parametrize("actor", PERMITTED_ACTORS)
def test_permitted_actors_pass_actor_gate(tmp_path, actor):
    """Sanity check — owner-role identifiers must NOT be rejected."""
    inp = _write(tmp_path / "draft.json", _baseline_text())
    ledger = tmp_path / "ledger.jsonl"
    res = subprocess.run(
        [PYTHON, str(GENERATE), "--input", str(inp), "--actor", actor, "--ledger", str(ledger)],
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    assert res.returncode == 0, f"permitted actor {actor!r} unexpectedly rejected: {res.stderr}"


def test_frozen_by_in_forbidden_token_rejected(tmp_path):
    """The frozen_by gate (in addition to the actor gate) catches forbidden tokens."""
    bad = _baseline_text()
    bad["freeze"] = {
        "status": "frozen",
        "frozen_at": "2026-05-28T00:00:00Z",
        "frozen_by": "auto",  # forbidden in baseline body
    }
    inp = _write(tmp_path / "draft.json", bad)
    ledger = tmp_path / "ledger.jsonl"
    res = subprocess.run(
        [PYTHON, str(GENERATE), "--input", str(inp), "--actor", "producer:alice", "--ledger", str(ledger)],
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    # Exit 1 = EXIT_VIOLATION (schema-shape level), not 2 (actor gate).
    assert res.returncode == 1, f"frozen_by='auto' should yield EXIT_VIOLATION=1, got {res.returncode}"
    assert "forbidden_actors" in res.stderr or "forbidden" in res.stderr.lower()
