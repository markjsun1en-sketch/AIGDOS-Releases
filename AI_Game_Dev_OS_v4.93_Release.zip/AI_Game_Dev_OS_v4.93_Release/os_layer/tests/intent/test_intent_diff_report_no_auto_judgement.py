"""test_intent_diff_report_no_auto_judgement.py — v4.91 Batch 6 c3.

Verifies the schema-const ``auto_semantic_judgement`` enforcement (Charter
anti-pattern #6 at the schema layer) and the auto-derivation logic for
``requires_preflight_review`` and ``reason_codes``.

End-to-end: runs scripts/intent/generate_intent_diff_report.py against
synthetic baseline / proposed pairs and asserts:

- auto_semantic_judgement is ALWAYS literal "not_performed"
- non_goal_relaxation auto-derived when non_goals removed
- acceptance_criteria_removal auto-derived when AC removed
- requires_preflight_review TRUE iff any reason_codes set
- requires_human_review FALSE only on purely-additive goals diffs
- caller-supplied --reason-code accepted only from 7-token enum

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = REPO_ROOT / "scripts" / "intent" / "generate_intent_diff_report.py"
PYTHON = sys.executable


def _baseline(intent_id: str = "intent_alpha") -> dict:
    return {
        "schema_version": "1.0.0",
        "intent_id": intent_id,
        "project_id": "project_alpha",
        "scope": "feature",
        "owner": {"role": "producer", "approval_required_for_change": True},
        "intent_summary": "Build a 3-turn combat loop for MVP validation.",
        "goals": ["Validate combat pacing", "Validate perk replayability"],
        "non_goals": ["No meta progression", "No live economy"],
        "acceptance_criteria": [
            "Combat loop completes start-to-finish",
            "At least 3 perk choices",
        ],
        "freeze": {"status": "frozen", "frozen_at": "2026-05-28T00:00:00Z", "frozen_by": "producer:alice"},
    }


def _write(p: Path, obj: dict) -> Path:
    p.write_text(json.dumps(obj, indent=2), encoding="utf-8")
    return p


def _run_diff(*, baseline: Path, proposed: Path, ledger: Path, reason_codes: list[str] | None = None) -> dict:
    args = [
        PYTHON, str(SCRIPT),
        "--baseline", str(baseline),
        "--proposed", str(proposed),
        "--actor", "producer:alice",
        "--changed-references", "docs/world.md",
        "--ledger", str(ledger),
        "--output", "-",
    ]
    for rc in (reason_codes or []):
        args.extend(["--reason-code", rc])
    res = subprocess.run(args, capture_output=True, text=True, cwd=str(REPO_ROOT))
    assert res.returncode == 0, f"diff generator failed: {res.stderr}"
    return json.loads(res.stdout)


def test_auto_semantic_judgement_is_always_not_performed(tmp_path):
    """Even when many things change, the const is preserved."""
    bl = _write(tmp_path / "baseline.json", _baseline())
    proposed = _baseline()
    # Massive change: drop a goal, drop a non_goal, drop an AC, add new ones.
    proposed["goals"] = ["Brand new goal"]
    proposed["non_goals"] = ["No live economy", "No new feature scope"]
    proposed["acceptance_criteria"] = ["At least 5 perk choices"]
    pr = _write(tmp_path / "proposed.json", proposed)
    report = _run_diff(baseline=bl, proposed=pr, ledger=tmp_path / "ledger.jsonl")
    assert report["auto_semantic_judgement"] == "not_performed"


def test_non_goal_relaxation_auto_derived(tmp_path):
    bl = _write(tmp_path / "baseline.json", _baseline())
    proposed = _baseline()
    proposed["non_goals"].remove("No live economy")  # loosen scope
    pr = _write(tmp_path / "proposed.json", proposed)
    report = _run_diff(baseline=bl, proposed=pr, ledger=tmp_path / "ledger.jsonl")
    assert "non_goal_relaxation" in report["reason_codes"]
    assert report["requires_preflight_review"] is True


def test_acceptance_criteria_removal_auto_derived(tmp_path):
    bl = _write(tmp_path / "baseline.json", _baseline())
    proposed = _baseline()
    proposed["acceptance_criteria"].remove("At least 3 perk choices")
    pr = _write(tmp_path / "proposed.json", proposed)
    report = _run_diff(baseline=bl, proposed=pr, ledger=tmp_path / "ledger.jsonl")
    assert "acceptance_criteria_removal" in report["reason_codes"]
    assert report["requires_preflight_review"] is True


def test_purely_additive_goals_diff_lowers_human_review_flag(tmp_path):
    bl = _write(tmp_path / "baseline.json", _baseline())
    proposed = _baseline()
    proposed["goals"].append("New supplemental goal")
    pr = _write(tmp_path / "proposed.json", proposed)
    report = _run_diff(baseline=bl, proposed=pr, ledger=tmp_path / "ledger.jsonl")
    assert report["requires_human_review"] is False
    assert report["requires_preflight_review"] is False
    assert report["reason_codes"] == []


def test_caller_reason_code_added(tmp_path):
    bl = _write(tmp_path / "baseline.json", _baseline())
    proposed = _baseline()
    proposed["goals"].append("New supplemental goal")
    pr = _write(tmp_path / "proposed.json", proposed)
    report = _run_diff(
        baseline=bl, proposed=pr, ledger=tmp_path / "ledger.jsonl",
        reason_codes=["player_facing_visual_semantics"],
    )
    assert "player_facing_visual_semantics" in report["reason_codes"]
    assert report["requires_preflight_review"] is True


def test_caller_invalid_reason_code_rejected_at_argparse(tmp_path):
    """argparse --reason-code choices enforce the 7-token enum."""
    bl = _write(tmp_path / "baseline.json", _baseline())
    pr = _write(tmp_path / "proposed.json", _baseline())
    ledger = tmp_path / "ledger.jsonl"
    res = subprocess.run(
        [
            PYTHON, str(SCRIPT),
            "--baseline", str(bl), "--proposed", str(pr),
            "--actor", "producer:alice",
            "--changed-references", "x.md",
            "--reason-code", "garbage_reason",  # not in 7-enum
            "--ledger", str(ledger),
        ],
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    assert res.returncode != 0
    assert "invalid choice" in res.stderr or "choices" in res.stderr


def test_report_id_pattern_matches_idr_prefix(tmp_path):
    bl = _write(tmp_path / "baseline.json", _baseline())
    pr = _write(tmp_path / "proposed.json", _baseline())
    report = _run_diff(baseline=bl, proposed=pr, ledger=tmp_path / "ledger.jsonl")
    assert report["report_id"].startswith("idr_")
    assert len(report["report_id"]) >= 8  # idr_ + at least 4 chars


def test_diff_emits_diff_generated_ledger_entry(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    bl = _write(tmp_path / "baseline.json", _baseline())
    pr = _write(tmp_path / "proposed.json", _baseline())
    _run_diff(baseline=bl, proposed=pr, ledger=ledger)
    lines = [json.loads(line) for line in ledger.read_text(encoding="utf-8").splitlines() if line.strip()]
    assert len(lines) == 1
    assert lines[0]["result"] == "DIFF_GENERATED"
    assert lines[0]["details"]["diff_report_id"].startswith("idr_")
