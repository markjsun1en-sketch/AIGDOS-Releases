"""test_intent_freeze_workflow.py — v4.91 Batch 6 c3.

End-to-end workflow tests covering the 8-cell transition matrix enforced by
``scripts/intent/validate_intent_freeze.py``:

    Source     × Target           Outcome
    -----------------------------------------
    draft      → frozen           PERMITTED  -> result=FROZEN, exit 0
    draft      → draft            PERMITTED  -> result=DRAFT_VALIDATED, exit 0
    frozen     → frozen (no delta) PERMITTED  -> result=DRAFT_VALIDATED, exit 0
    frozen     → frozen (+delta)  REJECTED   -> result=FREEZE_VIOLATION, exit 5
    frozen     → reopened (+rationale) PERMITTED -> result=REOPENED, exit 0
    frozen     → reopened (no rat)     REJECTED  -> result=FREEZE_VIOLATION, exit 5
    frozen     → draft            REJECTED   -> result=FREEZE_VIOLATION, exit 5
    frozen     → superseded (+new id +supersedes link +rationale) PERMITTED -> SUPERSEDED, exit 0
    frozen     → superseded (missing rationale) REJECTED -> FREEZE_VIOLATION, exit 5
    superseded → *                REJECTED   -> result=FREEZE_VIOLATION, exit 5

Each case uses tmp_path for isolation; ledger entries are appended to a
per-test ledger file.

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import copy
import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = REPO_ROOT / "scripts" / "intent" / "validate_intent_freeze.py"
GENERATE_SCRIPT = REPO_ROOT / "scripts" / "intent" / "generate_intent_baseline.py"

PYTHON = sys.executable


def _baseline(intent_id: str = "intent_alpha", status: str = "draft") -> dict:
    b = {
        "schema_version": "1.0.0",
        "intent_id": intent_id,
        "project_id": "project_alpha",
        "scope": "feature",
        "owner": {"role": "producer", "approval_required_for_change": True},
        "intent_summary": "Build a 3-turn combat loop for MVP validation.",
        "goals": ["Validate combat pacing", "Validate perk replayability"],
        "non_goals": ["No meta progression", "No live economy"],
        "acceptance_criteria": [
            "Combat loop completes start-to-finish",
            "At least 3 perk choices",
        ],
        "freeze": {"status": status},
    }
    if status == "frozen":
        b["freeze"]["frozen_at"] = "2026-05-28T00:00:00Z"
        b["freeze"]["frozen_by"] = "producer:alice"
    elif status == "reopened":
        b["freeze"]["reopened_at"] = "2026-05-28T03:00:00Z"
    return b


def _write(p: Path, obj: dict) -> Path:
    p.write_text(json.dumps(obj, indent=2), encoding="utf-8")
    return p


def _run_validate(
    *, baseline: Path, proposed: Path, ledger: Path, actor: str = "producer:alice", rationale: str | None = None
) -> subprocess.CompletedProcess:
    args = [
        PYTHON,
        str(SCRIPT),
        "--baseline", str(baseline),
        "--proposed", str(proposed),
        "--actor", actor,
        "--ledger", str(ledger),
        "--json",
    ]
    if rationale:
        args.extend(["--rationale", rationale])
    return subprocess.run(args, capture_output=True, text=True, cwd=str(REPO_ROOT))


def _read_ledger_lines(ledger: Path) -> list[dict]:
    if not ledger.exists():
        return []
    return [json.loads(line) for line in ledger.read_text(encoding="utf-8").splitlines() if line.strip()]


# ---------------------------------------------------------------------------
# Cell 1: draft -> frozen (permitted)
# ---------------------------------------------------------------------------


def test_draft_to_frozen_permitted(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    bl = _write(tmp_path / "baseline.json", _baseline(status="draft"))
    pr = _write(tmp_path / "proposed.json", _baseline(status="frozen"))
    res = _run_validate(baseline=bl, proposed=pr, ledger=ledger)
    assert res.returncode == 0, f"unexpected: {res.stdout}\n{res.stderr}"
    body = json.loads(res.stdout)
    assert body["ok"] is True
    assert body["result"] == "FROZEN"
    entries = _read_ledger_lines(ledger)
    assert len(entries) == 1
    assert entries[0]["result"] == "FROZEN"
    assert entries[0]["details"]["freeze_status"] == "frozen"


# ---------------------------------------------------------------------------
# Cell 2: draft -> draft (permitted, no-op revalidation)
# ---------------------------------------------------------------------------


def test_draft_to_draft_permitted(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    bl = _write(tmp_path / "baseline.json", _baseline(status="draft"))
    pr = _write(tmp_path / "proposed.json", _baseline(status="draft"))
    res = _run_validate(baseline=bl, proposed=pr, ledger=ledger)
    assert res.returncode == 0
    body = json.loads(res.stdout)
    assert body["result"] == "DRAFT_VALIDATED"


# ---------------------------------------------------------------------------
# Cell 3: frozen -> frozen with NO delta (permitted, no-op revalidation)
# ---------------------------------------------------------------------------


def test_frozen_to_frozen_no_delta_permitted(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    bl = _write(tmp_path / "baseline.json", _baseline(status="frozen"))
    pr = _write(tmp_path / "proposed.json", _baseline(status="frozen"))
    res = _run_validate(baseline=bl, proposed=pr, ledger=ledger)
    assert res.returncode == 0, f"unexpected: {res.stdout}\n{res.stderr}"
    body = json.loads(res.stdout)
    assert body["result"] == "DRAFT_VALIDATED"


# ---------------------------------------------------------------------------
# Cell 4: frozen -> frozen WITH delta (REJECTED -> FREEZE_VIOLATION exit 5)
# ---------------------------------------------------------------------------


def test_frozen_to_frozen_with_delta_rejected(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    bl = _write(tmp_path / "baseline.json", _baseline(status="frozen"))
    mutated = _baseline(status="frozen")
    mutated["goals"].append("Smuggled extra goal")
    pr = _write(tmp_path / "proposed.json", mutated)
    res = _run_validate(baseline=bl, proposed=pr, ledger=ledger)
    assert res.returncode == 5, f"expected EXIT_FROZEN_MUTATION=5, got {res.returncode}"
    body = json.loads(res.stdout)
    assert body["ok"] is False
    assert body["result"] == "FREEZE_VIOLATION"
    entries = _read_ledger_lines(ledger)
    # Rejection itself is logged for audit (Charter #11 audit trail).
    assert len(entries) == 1
    assert entries[0]["result"] == "FREEZE_VIOLATION"


# ---------------------------------------------------------------------------
# Cell 5: frozen -> reopened WITH rationale (permitted)
# ---------------------------------------------------------------------------


def test_frozen_to_reopened_with_rationale_permitted(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    bl = _write(tmp_path / "baseline.json", _baseline(status="frozen"))
    pr = _write(tmp_path / "proposed.json", _baseline(status="reopened"))
    res = _run_validate(
        baseline=bl, proposed=pr, ledger=ledger, rationale="Owner reopens to expand non-goals"
    )
    assert res.returncode == 0, f"{res.stdout}\n{res.stderr}"
    body = json.loads(res.stdout)
    assert body["result"] == "REOPENED"
    entries = _read_ledger_lines(ledger)
    assert entries[0]["details"].get("rationale") == "Owner reopens to expand non-goals"


# ---------------------------------------------------------------------------
# Cell 6: frozen -> reopened MISSING rationale (REJECTED)
# ---------------------------------------------------------------------------


def test_frozen_to_reopened_without_rationale_rejected(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    bl = _write(tmp_path / "baseline.json", _baseline(status="frozen"))
    pr = _write(tmp_path / "proposed.json", _baseline(status="reopened"))
    res = _run_validate(baseline=bl, proposed=pr, ledger=ledger)
    assert res.returncode == 5
    body = json.loads(res.stdout)
    assert body["result"] == "FREEZE_VIOLATION"


# ---------------------------------------------------------------------------
# Cell 7: frozen -> draft (silent rollback to draft) — REJECTED
# ---------------------------------------------------------------------------


def test_frozen_to_draft_rejected(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    bl = _write(tmp_path / "baseline.json", _baseline(status="frozen"))
    pr = _write(tmp_path / "proposed.json", _baseline(status="draft"))
    res = _run_validate(baseline=bl, proposed=pr, ledger=ledger)
    assert res.returncode == 5
    body = json.loads(res.stdout)
    assert body["result"] == "FREEZE_VIOLATION"


# ---------------------------------------------------------------------------
# Cell 8: frozen -> superseded with new intent_id + supersedes link + rationale (permitted)
# ---------------------------------------------------------------------------


def test_frozen_to_superseded_full_witness_permitted(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    bl = _write(tmp_path / "baseline.json", _baseline(intent_id="intent_alpha", status="frozen"))
    successor = _baseline(intent_id="intent_beta", status="frozen")
    successor["freeze"]["supersedes"] = "intent_alpha"
    pr = _write(tmp_path / "proposed.json", successor)
    res = _run_validate(
        baseline=bl, proposed=pr, ledger=ledger, rationale="Superseded by next-gen baseline"
    )
    assert res.returncode == 0, f"{res.stdout}\n{res.stderr}"
    body = json.loads(res.stdout)
    assert body["result"] == "SUPERSEDED"
    entries = _read_ledger_lines(ledger)
    assert entries[0]["details"]["intent_id"] == "intent_beta"
    assert entries[0]["details"].get("supersedes") == "intent_alpha"


# ---------------------------------------------------------------------------
# Cell 9: frozen -> superseded MISSING rationale (REJECTED)
# ---------------------------------------------------------------------------


def test_frozen_to_superseded_missing_rationale_rejected(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    bl = _write(tmp_path / "baseline.json", _baseline(intent_id="intent_alpha", status="frozen"))
    successor = _baseline(intent_id="intent_beta", status="frozen")
    successor["freeze"]["supersedes"] = "intent_alpha"
    pr = _write(tmp_path / "proposed.json", successor)
    res = _run_validate(baseline=bl, proposed=pr, ledger=ledger)
    assert res.returncode == 5
    body = json.loads(res.stdout)
    assert body["result"] == "FREEZE_VIOLATION"


# ---------------------------------------------------------------------------
# Cell 10: frozen -> superseded with WRONG supersedes link (REJECTED)
# ---------------------------------------------------------------------------


def test_frozen_to_superseded_wrong_link_rejected(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    bl = _write(tmp_path / "baseline.json", _baseline(intent_id="intent_alpha", status="frozen"))
    successor = _baseline(intent_id="intent_beta", status="frozen")
    successor["freeze"]["supersedes"] = "intent_unrelated"  # wrong link
    pr = _write(tmp_path / "proposed.json", successor)
    res = _run_validate(
        baseline=bl, proposed=pr, ledger=ledger, rationale="Some rationale"
    )
    assert res.returncode == 5


# ---------------------------------------------------------------------------
# Cell 11: superseded -> * is terminal (REJECTED)
# ---------------------------------------------------------------------------


def test_superseded_is_terminal(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    sup = _baseline(status="frozen")
    sup["freeze"]["status"] = "superseded"
    bl = _write(tmp_path / "baseline.json", sup)
    pr = _write(tmp_path / "proposed.json", _baseline(status="draft"))
    res = _run_validate(baseline=bl, proposed=pr, ledger=ledger)
    assert res.returncode == 5
    body = json.loads(res.stdout)
    assert body["result"] == "FREEZE_VIOLATION"
