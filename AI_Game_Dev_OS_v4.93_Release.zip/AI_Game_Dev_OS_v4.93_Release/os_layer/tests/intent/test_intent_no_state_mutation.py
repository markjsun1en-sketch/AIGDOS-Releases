"""test_intent_no_state_mutation.py — v4.91 Batch 6 c3.

Compile-time guard for inv_012_intent_baseline_freeze_respected. Verifies
``scripts/intent/`` does NOT import any state-mutating governance / ltm /
hub / recovery / memory engine module, and never uses subprocess / shutil
calls that could mutate runtime state outside the append-only ledger.

Charter alignment: anti-pattern #6 (no auto-promote feedback into
retrieval-policy / promotion-policy tunables) and #11 (validation is
recording-only, not closure-gate enforcement).

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
INTENT_DIR = REPO_ROOT / "scripts" / "intent"


# Modules that are STATE-MUTATING and therefore forbidden imports for
# scripts/intent/. The list mirrors inv_010 / inv_011 patterns plus the
# v4.91 B5/B5B/B6 lifecycle / preflight / capture engines.
FORBIDDEN_IMPORTS = (
    # Retrieval / promotion engines
    "retrieval_policy",
    "promotion_policy",
    "promote_memory_candidate",
    "reject_memory_candidate",
    "supersede_memory_candidate",
    # Capture engines
    "capture_sprint_close",
    "capture_evolution_proposal",
    # Recovery engines
    "create_checkpoint",
    "generate_rollback_plan",
    "verify_rollback",
    # Memory uplink
    "sprint_close_hook",
    "generate_preflight_summary",
    # Preflight runtime
    "run_preflight_consensus",
    # Hub / lock / init
    "lock_core_version",
    "link_project",
    "init_hub",
    # Manifest rebuild
    "rebuild_release_manifest",
)


# Subprocess / shutil patterns that could mutate runtime state outside
# the append-only ledger.
FORBIDDEN_RUNTIME_CALLS = (
    "shutil.rmtree",
    "shutil.move",
    "shutil.copytree",
    "os.system",
    "subprocess.run",
    "subprocess.call",
    "subprocess.Popen",
    "os.unlink",
    "os.remove",
)


def _iter_intent_py_files() -> list[Path]:
    return sorted(INTENT_DIR.rglob("*.py"))


def test_no_state_mutating_imports():
    offenders: list[tuple[Path, int, str, str]] = []
    import_re = re.compile(
        r"^\s*(?:from\s+([\w.]+)\s+import\s+|import\s+([\w.]+))",
        re.MULTILINE,
    )
    for py in _iter_intent_py_files():
        text = py.read_text(encoding="utf-8")
        for m in import_re.finditer(text):
            mod = m.group(1) or m.group(2) or ""
            for forbidden in FORBIDDEN_IMPORTS:
                if forbidden in mod.split("."):
                    line = text.count("\n", 0, m.start()) + 1
                    offenders.append((py.relative_to(REPO_ROOT), line, forbidden, m.group(0).strip()))
    assert not offenders, (
        f"Charter anti-pattern #6 violation — scripts/intent/* imports a "
        f"state-mutating engine module: {offenders}"
    )


def test_no_runtime_mutation_calls():
    offenders: list[tuple[Path, int, str, str]] = []
    for py in _iter_intent_py_files():
        text = py.read_text(encoding="utf-8")
        for ln_no, line in enumerate(text.splitlines(), start=1):
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            for token in FORBIDDEN_RUNTIME_CALLS:
                if token in stripped:
                    offenders.append((py.relative_to(REPO_ROOT), ln_no, token, stripped))
    assert not offenders, (
        f"Charter anti-pattern #6 violation — scripts/intent/* uses a "
        f"runtime-mutating call: {offenders}"
    )


def test_intent_scripts_only_write_to_ledger_and_specified_output():
    """Sanity check: the only path-writing operations in scripts/intent/
    must be:

    - ``target.open("a", ...)`` inside ``_intent_common.append_ledger`` —
      append-only ledger writer (audit-trail rule).
    - ``Path.write_text(...)`` for --output and validated baseline files
      (CLI-controlled output path).

    No bare ``open(..., "w")`` / ``open(..., "x")`` / ``open(..., "r+")``
    calls are permitted (they would imply file truncation or in-place
    mutation).
    """
    # Only flag bare open() with truncating modes.
    bare_truncate_re = re.compile(
        r'\bopen\(\s*[^)]*[\'\"][wx][\'\"]'  # open(..., "w") or open(..., "x")
    )
    truncate_replace_re = re.compile(
        r'\.open\(\s*[^)]*[\'\"][wx][\'\"]'  # path.open("w") / path.open("x")
    )
    offenders: list[tuple[Path, int, str]] = []
    for py in _iter_intent_py_files():
        text = py.read_text(encoding="utf-8")
        for ln_no, line in enumerate(text.splitlines(), start=1):
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            if bare_truncate_re.search(stripped) or truncate_replace_re.search(stripped):
                offenders.append((py.relative_to(REPO_ROOT), ln_no, stripped))
    # `target.open("a", ...)` is the legitimate ledger writer — append mode,
    # not truncate. Path.write_text() is also legitimate (CLI --output path).
    assert not offenders, (
        f"Charter audit-trail violation — scripts/intent/ uses a truncating "
        f"file open: {offenders}"
    )


def test_append_ledger_uses_append_mode_only():
    """Reading the source of _intent_common.py: append_ledger MUST open
    the ledger with mode 'a' (append-only). Charter audit-trail rule."""
    common = INTENT_DIR / "_intent_common.py"
    text = common.read_text(encoding="utf-8")
    # Find the append_ledger function body up to the next `def`.
    m = re.search(r"def append_ledger\([^)]*\)[^:]*:\s*\n(.*?)(?=\ndef |\Z)", text, re.DOTALL)
    assert m, "append_ledger function not found in _intent_common.py"
    body = m.group(1)
    # The body must contain `target.open("a"` (append mode), and must NOT
    # contain "w" or "x" mode opens.
    assert '"a"' in body or "'a'" in body, (
        "append_ledger must open the ledger in append mode; got body:\n" + body
    )
    forbidden_modes = ('"w"', "'w'", '"x"', "'x'", '"r+"', "'r+'")
    for mode in forbidden_modes:
        assert mode not in body, (
            f"append_ledger must not use mode {mode}; ledger is append-only"
        )


def test_validate_freeze_does_not_mutate_input_files():
    """Static-analysis sanity: validate_intent_freeze.py never writes back
    to its --baseline / --proposed inputs."""
    script = INTENT_DIR / "validate_intent_freeze.py"
    text = script.read_text(encoding="utf-8")
    # Forbid write_text / open(..., 'w') anywhere in the validator (the
    # only legitimate write is via append_ledger which calls into
    # _intent_common, not directly).
    assert "write_text" not in text, (
        "validate_intent_freeze.py must not call write_text on any input — "
        "Charter anti-pattern #6 (no silent mutation)."
    )
