"""test_intent_baseline_schema.py — v4.91 Batch 6 c3.

Validates the 3 intent governance schemas (Layer 1 / OS Spec):

1. ``schemas/intent/intent_baseline.schema.json``
2. ``schemas/intent/intent_diff_report.schema.json``
3. ``schemas/intent/intent_baseline_ledger.schema.json``

Each schema is verified to:

- Be a valid JSON Schema draft-07 document (meta-validation).
- Accept a happy-path fixture instance.
- Reject specific invalid variants:
    * additionalProperties=false enforced
    * required fields enforced
    * schema_version const 1.0.0 enforced
    * enum violations rejected (scope / owner.role / freeze.status / result)
    * auto_semantic_judgement const ``not_performed`` enforced (Charter #6)

Uses ``jsonschema`` as a soft dependency via ``pytest.importorskip`` —
projects without the lib auto-skip rather than failing CI.

Layer 1 (OS Spec). No project literals.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

jsonschema = pytest.importorskip("jsonschema")


REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = REPO_ROOT / "schemas" / "intent"

INTENT_BASELINE_SCHEMA = SCHEMA_DIR / "intent_baseline.schema.json"
INTENT_DIFF_REPORT_SCHEMA = SCHEMA_DIR / "intent_diff_report.schema.json"
INTENT_LEDGER_SCHEMA = SCHEMA_DIR / "intent_baseline_ledger.schema.json"


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# 1. Schema files are valid draft-07 documents.
# ---------------------------------------------------------------------------


def test_intent_baseline_schema_is_draft07_valid():
    schema = _load(INTENT_BASELINE_SCHEMA)
    jsonschema.Draft7Validator.check_schema(schema)
    assert schema["properties"]["schema_version"]["const"] == "1.0.0"


def test_intent_diff_report_schema_is_draft07_valid():
    schema = _load(INTENT_DIFF_REPORT_SCHEMA)
    jsonschema.Draft7Validator.check_schema(schema)
    assert schema["properties"]["schema_version"]["const"] == "1.0.0"


def test_intent_ledger_schema_is_draft07_valid():
    schema = _load(INTENT_LEDGER_SCHEMA)
    jsonschema.Draft7Validator.check_schema(schema)
    assert schema["properties"]["schema_version"]["const"] == "1.0.0"


# ---------------------------------------------------------------------------
# Fixtures.
# ---------------------------------------------------------------------------


HAPPY_BASELINE: dict = {
    "schema_version": "1.0.0",
    "intent_id": "intent_alpha_combat_loop",
    "project_id": "project_alpha",
    "scope": "feature",
    "owner": {"role": "producer", "approval_required_for_change": True},
    "intent_summary": "Build a 3-turn combat loop for MVP validation.",
    "goals": ["Validate combat pacing", "Validate perk replayability"],
    "non_goals": ["No meta progression", "No live economy"],
    "acceptance_criteria": [
        "Combat loop completes start-to-finish",
        "At least 3 perk choices",
    ],
    "freeze": {
        "status": "frozen",
        "frozen_at": "2026-05-28T00:00:00Z",
        "frozen_by": "producer:alice",
    },
}

HAPPY_DIFF_REPORT: dict = {
    "schema_version": "1.0.0",
    "report_id": "idr_abcdef01",
    "intent_id": "intent_alpha_combat_loop",
    "project_id": "project_alpha",
    "generated_at": "2026-05-28T00:00:00Z",
    "generated_by": "scripts/intent/generate_intent_diff_report.py",
    "changed_references": ["docs/world.md"],
    "delta": {
        "goals_added": ["Add new combat goal"],
        "goals_removed": [],
        "non_goals_added": [],
        "non_goals_removed": [],
        "acceptance_criteria_added": [],
        "acceptance_criteria_removed": [],
    },
    "auto_semantic_judgement": "not_performed",
}

HAPPY_LEDGER_ENTRY: dict = {
    "schema_version": "1.0.0",
    "event_id": "ib_a1b2c3d4",
    "event_type": "intent_baseline_event",
    "timestamp": "2026-05-28T00:00:00Z",
    "actor": "producer:alice",
    "runtime_profile": "default",
    "result": "FROZEN",
    "source_layer": "L1",
    "audit_status": "recorded",
    "details": {
        "intent_id": "intent_alpha_combat_loop",
        "project_id": "project_alpha",
        "scope": "feature",
        "freeze_status": "frozen",
        "owner_role": "producer",
    },
}


# ---------------------------------------------------------------------------
# 2. Happy path acceptance.
# ---------------------------------------------------------------------------


def test_intent_baseline_accepts_happy_fixture():
    schema = _load(INTENT_BASELINE_SCHEMA)
    jsonschema.validate(HAPPY_BASELINE, schema)


def test_intent_diff_report_accepts_happy_fixture():
    schema = _load(INTENT_DIFF_REPORT_SCHEMA)
    jsonschema.validate(HAPPY_DIFF_REPORT, schema)


def test_intent_ledger_accepts_happy_fixture():
    schema = _load(INTENT_LEDGER_SCHEMA)
    jsonschema.validate(HAPPY_LEDGER_ENTRY, schema)


# ---------------------------------------------------------------------------
# 3. Invalid variants — baseline.
# ---------------------------------------------------------------------------


def test_baseline_rejects_extra_property():
    schema = _load(INTENT_BASELINE_SCHEMA)
    bad = copy.deepcopy(HAPPY_BASELINE)
    bad["unexpected_field"] = "x"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_baseline_rejects_wrong_schema_version_const():
    schema = _load(INTENT_BASELINE_SCHEMA)
    bad = copy.deepcopy(HAPPY_BASELINE)
    bad["schema_version"] = "1.1.0"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_baseline_rejects_missing_required_freeze():
    schema = _load(INTENT_BASELINE_SCHEMA)
    bad = copy.deepcopy(HAPPY_BASELINE)
    del bad["freeze"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_baseline_rejects_invalid_scope_enum():
    schema = _load(INTENT_BASELINE_SCHEMA)
    bad = copy.deepcopy(HAPPY_BASELINE)
    bad["scope"] = "module"  # not in 6-enum
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_baseline_rejects_invalid_owner_role_enum():
    schema = _load(INTENT_BASELINE_SCHEMA)
    bad = copy.deepcopy(HAPPY_BASELINE)
    bad["owner"]["role"] = "intern"  # not in 6-enum
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_baseline_rejects_approval_required_false():
    schema = _load(INTENT_BASELINE_SCHEMA)
    bad = copy.deepcopy(HAPPY_BASELINE)
    bad["owner"]["approval_required_for_change"] = False
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_baseline_rejects_invalid_freeze_status_enum():
    schema = _load(INTENT_BASELINE_SCHEMA)
    bad = copy.deepcopy(HAPPY_BASELINE)
    bad["freeze"]["status"] = "archived"  # not in 4-enum
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_baseline_rejects_intent_id_pattern_violation():
    schema = _load(INTENT_BASELINE_SCHEMA)
    bad = copy.deepcopy(HAPPY_BASELINE)
    bad["intent_id"] = "MyProjectIntent"  # uppercase + no intent_ prefix
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_baseline_rejects_empty_goals_array():
    schema = _load(INTENT_BASELINE_SCHEMA)
    bad = copy.deepcopy(HAPPY_BASELINE)
    bad["goals"] = []
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_baseline_rejects_empty_non_goals_array():
    schema = _load(INTENT_BASELINE_SCHEMA)
    bad = copy.deepcopy(HAPPY_BASELINE)
    bad["non_goals"] = []
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_baseline_rejects_short_intent_summary():
    schema = _load(INTENT_BASELINE_SCHEMA)
    bad = copy.deepcopy(HAPPY_BASELINE)
    bad["intent_summary"] = "short"  # < 16 chars
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


# ---------------------------------------------------------------------------
# 4. Invalid variants — diff report.
# ---------------------------------------------------------------------------


def test_diff_report_rejects_auto_semantic_judgement_other_value():
    schema = _load(INTENT_DIFF_REPORT_SCHEMA)
    bad = copy.deepcopy(HAPPY_DIFF_REPORT)
    bad["auto_semantic_judgement"] = "auto_decided"  # forbidden by const
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_diff_report_rejects_missing_delta():
    schema = _load(INTENT_DIFF_REPORT_SCHEMA)
    bad = copy.deepcopy(HAPPY_DIFF_REPORT)
    del bad["delta"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_diff_report_rejects_partial_delta():
    schema = _load(INTENT_DIFF_REPORT_SCHEMA)
    bad = copy.deepcopy(HAPPY_DIFF_REPORT)
    del bad["delta"]["goals_added"]  # required by delta
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_diff_report_rejects_invalid_reason_code_enum():
    schema = _load(INTENT_DIFF_REPORT_SCHEMA)
    bad = copy.deepcopy(HAPPY_DIFF_REPORT)
    bad["reason_codes"] = ["unknown_reason"]  # not in 7-enum
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_diff_report_rejects_empty_changed_references():
    schema = _load(INTENT_DIFF_REPORT_SCHEMA)
    bad = copy.deepcopy(HAPPY_DIFF_REPORT)
    bad["changed_references"] = []  # minItems 1
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_diff_report_rejects_invalid_report_id_pattern():
    schema = _load(INTENT_DIFF_REPORT_SCHEMA)
    bad = copy.deepcopy(HAPPY_DIFF_REPORT)
    bad["report_id"] = "report_001"  # missing idr_ prefix
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


# ---------------------------------------------------------------------------
# 5. Invalid variants — ledger entry.
# ---------------------------------------------------------------------------


def test_ledger_rejects_invalid_event_id_pattern():
    schema = _load(INTENT_LEDGER_SCHEMA)
    bad = copy.deepcopy(HAPPY_LEDGER_ENTRY)
    bad["event_id"] = "id_a1b2c3d4"  # missing ib_ prefix
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_ledger_rejects_invalid_result_enum():
    schema = _load(INTENT_LEDGER_SCHEMA)
    bad = copy.deepcopy(HAPPY_LEDGER_ENTRY)
    bad["result"] = "AUTO_APPROVED"  # not in 6-enum
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_ledger_rejects_wrong_event_type_const():
    schema = _load(INTENT_LEDGER_SCHEMA)
    bad = copy.deepcopy(HAPPY_LEDGER_ENTRY)
    bad["event_type"] = "delegation_decision"  # const mismatch
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_ledger_rejects_wrong_source_layer_const():
    schema = _load(INTENT_LEDGER_SCHEMA)
    bad = copy.deepcopy(HAPPY_LEDGER_ENTRY)
    bad["source_layer"] = "L2"  # must be L1
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)


def test_ledger_rejects_invalid_audit_status_enum():
    schema = _load(INTENT_LEDGER_SCHEMA)
    bad = copy.deepcopy(HAPPY_LEDGER_ENTRY)
    bad["audit_status"] = "approved"  # not in 3-enum
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, schema)
