"""v4.89 OS — runtime tooling shared helpers.

This module is loaded by ``generate_sprint_context_rollup.py``,
``boot_agent_thread.py``, and ``generate_cold_start_pack.py``.  It
provides:

* a tiny ``RuntimeContext`` dataclass that resolves canonical paths
  inside an adopting project's working tree;
* JSON / markdown read+write helpers tuned for the cold-start use
  case (small, deterministic, UTF-8 only);
* task / issue / sprint id regex compilation that is **read at
  runtime from** ``runtime/config/task_id_pattern.json`` rather than
  hardcoded — projects override the pattern on adoption (see M9.0.2).

Working language is English by permanent contract §11.

This file is M9.0.4 of v4.89 OS Phase 4 Step 3.  It is a v4.89-native
rewrite, not a port of the upstream cold-start ``_runtime_common.py``.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Pattern


__all__ = (
    "utc_now",
    "load_json",
    "save_json",
    "read_text",
    "RuntimeContext",
    "TaskIdPatterns",
)


# ---------------------------------------------------------------------------
# Time helpers
# ---------------------------------------------------------------------------


def utc_now() -> str:
    """Return the current UTC time as an ISO 8601 string with ``Z`` suffix.

    Microseconds are dropped so cold-start outputs stay diff-friendly when
    regenerated multiple times within the same second.
    """

    return (
        datetime.now(timezone.utc)
        .replace(microsecond=0)
        .isoformat()
        .replace("+00:00", "Z")
    )


# ---------------------------------------------------------------------------
# JSON / markdown I/O
# ---------------------------------------------------------------------------


def load_json(path: Path, default: Any = None) -> Any:
    """Load JSON from ``path``.  If the file is missing and ``default`` is
    not ``None``, return ``default``.  Raise ``FileNotFoundError`` only when
    no default is supplied — the cold-start pipeline often runs against
    a partially populated workspace.
    """

    if not path.exists():
        if default is None:
            raise FileNotFoundError(f"Missing JSON file: {path}")
        return default
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def save_json(path: Path, payload: Any) -> None:
    """Write ``payload`` to ``path`` as pretty-printed UTF-8 JSON with a
    trailing newline.  Parent directories are created on demand.
    """

    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)
        handle.write("\n")


def read_text(path: Path, max_chars: Optional[int] = None) -> str:
    """Return the UTF-8 contents of ``path``.  If the file is missing,
    return an empty string (cold-start tolerates absent assets).  If
    ``max_chars`` is given, truncate the result.
    """

    if not path.exists():
        return ""
    text = path.read_text(encoding="utf-8")
    return text if max_chars is None else text[:max_chars]


# ---------------------------------------------------------------------------
# Runtime context — canonical path resolution
# ---------------------------------------------------------------------------


@dataclass
class RuntimeContext:
    """Canonical path resolver for the v4.89 OS runtime tree.

    ``repo_root`` points at the directory that contains ``runtime/`` and
    ``tasks/`` and ``logs/``.  Tools never resolve paths manually; they
    go through ``RuntimeContext`` so the same source code works inside
    the OS package, inside an adopting project, and inside test
    fixtures.
    """

    repo_root: Path

    @classmethod
    def from_script(cls, script_path: Path) -> "RuntimeContext":
        """Construct a context whose ``repo_root`` is the package root
        relative to the script.  ``tools/runtime/<script>.py`` lives two
        directories below the package root.
        """

        return cls(repo_root=script_path.resolve().parents[2])

    def resolve(self, rel_path: str) -> Path:
        return self.repo_root / rel_path

    @property
    def task_registry_path(self) -> Path:
        return self.resolve("runtime/registries/task_registry.json")

    @property
    def blocker_registry_path(self) -> Path:
        return self.resolve("runtime/registries/blocker_registry.json")

    @property
    def handoff_queue_path(self) -> Path:
        return self.resolve("runtime/registries/handoff_queue.json")

    @property
    def project_snapshot_path(self) -> Path:
        return self.resolve("runtime/registries/project_status_snapshot.json")

    @property
    def archive_index_path(self) -> Path:
        return self.resolve("runtime/registries/archive_index.json")

    @property
    def sprint_context_rollup_path(self) -> Path:
        return self.resolve("runtime/registries/sprint_context_rollup.json")

    @property
    def sprint_board_path(self) -> Path:
        return self.resolve("tasks/sprint_board.md")

    @property
    def orchestrator_log_path(self) -> Path:
        return self.resolve("logs/orchestrator_log.md")

    @property
    def handoff_dir(self) -> Path:
        return self.resolve("logs/handoffs")

    @property
    def handoff_archive_dir(self) -> Path:
        return self.resolve("logs/handoffs/archive")

    @property
    def context_profiles_manifest_path(self) -> Path:
        return self.resolve("runtime/config/context_profiles_manifest.json")

    @property
    def task_id_pattern_path(self) -> Path:
        return self.resolve("runtime/config/task_id_pattern.json")


# ---------------------------------------------------------------------------
# Task / issue / sprint id pattern resolution
# ---------------------------------------------------------------------------


@dataclass
class TaskIdPatterns:
    """Compiled regex bundle loaded from
    ``runtime/config/task_id_pattern.json`` (see M9.0.2).

    Projects override the JSON file to narrow the patterns; this class
    never hardcodes a particular project's convention.
    """

    task_id: Pattern[str]
    issue_id: Pattern[str]
    sprint_id: Pattern[str]

    @classmethod
    def from_context(cls, ctx: RuntimeContext) -> "TaskIdPatterns":
        data = load_json(ctx.task_id_pattern_path, default={})
        patterns = data.get("patterns", {}) if isinstance(data, dict) else {}
        return cls(
            task_id=cls._compile(patterns.get("task_id", {}).get("regex"),
                                 fallback=r"[A-Z]{2,6}-\d+(?:-[A-Z0-9]+)*"),
            issue_id=cls._compile(patterns.get("issue_id", {}).get("regex"),
                                  fallback=r"(?:ISSUE|BUG|QA)-\d+"),
            sprint_id=cls._compile(patterns.get("sprint_id", {}).get("regex"),
                                   fallback=r"SPRINT-\d+(?:-[A-Z0-9]+)*"),
        )

    @staticmethod
    def _compile(regex: Optional[str], fallback: str) -> Pattern[str]:
        return re.compile(regex if regex else fallback)

    def find_task_ids(self, text: str) -> List[str]:
        return sorted(set(self.task_id.findall(text)))

    def find_issue_ids(self, text: str) -> List[str]:
        return sorted(set(self.issue_id.findall(text)))

    def find_sprint_ids(self, text: str) -> List[str]:
        return sorted(set(self.sprint_id.findall(text)))


# ---------------------------------------------------------------------------
# Misc
# ---------------------------------------------------------------------------


def status_count(items: List[Dict[str, Any]], key: str = "status") -> Dict[str, int]:
    """Group-count ``items`` by their ``key`` value."""

    counts: Dict[str, int] = {}
    for item in items:
        status = str(item.get(key) or "unknown")
        counts[status] = counts.get(status, 0) + 1
    return dict(sorted(counts.items()))


def compact_item(item: Dict[str, Any], keys: List[str]) -> Dict[str, Any]:
    """Return a shallow copy of ``item`` containing only ``keys`` that are
    present in the source.
    """

    return {key: item.get(key) for key in keys if key in item}
