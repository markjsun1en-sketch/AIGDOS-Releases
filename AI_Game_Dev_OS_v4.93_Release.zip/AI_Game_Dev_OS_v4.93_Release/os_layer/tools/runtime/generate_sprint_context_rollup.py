#!/usr/bin/env python3
"""v4.89 OS — Sprint context rollup generator.

Reads the canonical sprint sources::

    tasks/sprint_board.md                    # current + previous sprint metadata
    runtime/registries/task_registry.json     # full task list
    runtime/registries/blocker_registry.json  # full blocker list
    runtime/registries/handoff_queue.json     # all handoff entries
    runtime/registries/project_status_snapshot.json   # one-page rollup
    logs/handoffs/                           # active handoff markdown files
    logs/handoffs/archive/                   # archived handoff markdown files
    logs/orchestrator_log.md                 # narrative trace

Emits two JSON outputs::

    runtime/registries/sprint_context_rollup.json   # current/previous sprint
    runtime/registries/archive_index.json           # historical lookup index

Both outputs feed ``generate_cold_start_pack.py`` (M9.0.5) and the
context profiles in ``runtime/config/context_profiles_manifest.json``
(M9.0.3).

Task / issue / sprint id regex are resolved from
``runtime/config/task_id_pattern.json`` (M9.0.2) — no project-specific
patterns are hardcoded here.

This script is M9.0.4 of v4.89 OS Phase 4 Step 3.  v4.89-native rewrite.
Working language: English (permanent contract §11).
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

# Allow running as a script: ``python3 tools/runtime/generate_sprint_context_rollup.py``
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _runtime_common import (  # noqa: E402
    RuntimeContext,
    TaskIdPatterns,
    compact_item,
    load_json,
    read_text,
    save_json,
    status_count,
    utc_now,
)


# ---------------------------------------------------------------------------
# Sprint board parsing
# ---------------------------------------------------------------------------


def extract_field(section: str, name: str) -> Optional[str]:
    """Return the value of a ``- <name>: <value>`` line within a sprint
    section, or ``None`` if the field is absent or blank.
    """

    match = re.search(rf"^- {re.escape(name)}:\s*(.+)$", section, re.MULTILINE)
    if not match:
        return None
    value = match.group(1).strip()
    if value in {"_none_", "-", ""}:
        return None
    return value


def parse_sprint_sections(
    board_text: str,
    patterns: TaskIdPatterns,
) -> Tuple[Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]:
    """Parse ``tasks/sprint_board.md``.  Recognise the two canonical
    second-level headings ``## Current Sprint`` and ``## Previous Sprint``;
    extract Sprint Name / Goal / Status and the optional Sprint Boundary
    body.  Returns ``(current, previous_most_recent, all_previous)``.
    """

    sections: List[Tuple[str, str]] = []
    headings = list(re.finditer(r"^## (.+?)\s*$", board_text, re.MULTILINE))
    for index, match in enumerate(headings):
        kind = match.group(1).strip()
        if kind not in {"Previous Sprint", "Current Sprint"}:
            continue
        start = match.end()
        end = headings[index + 1].start() if index + 1 < len(headings) else len(board_text)
        sections.append((kind, board_text[start:end]))

    previous: List[Dict[str, Any]] = []
    current: Dict[str, Any] = {}
    for kind, section in sections:
        info: Dict[str, Any] = {
            "sprint_name": extract_field(section, "Sprint Name"),
            "goal": extract_field(section, "Goal"),
            "status": extract_field(section, "Status"),
            "task_ids": patterns.find_task_ids(section),
            "issue_ids": patterns.find_issue_ids(section),
            "sprint_ids": patterns.find_sprint_ids(section),
        }
        boundary_match = re.search(
            r"^- Sprint Boundary:\s*\n(?P<body>.*?)(?=\n## |\n---\n|\Z)",
            section,
            re.MULTILINE | re.DOTALL,
        )
        if boundary_match:
            body = " ".join(boundary_match.group("body").split())
            if body and body not in {"_none_", "-"}:
                info["sprint_boundary_excerpt"] = body[:1600]
        if kind == "Current Sprint":
            current = info
        else:
            previous.append(info)
    previous_current = previous[0] if previous else {}
    return current, previous_current, previous


def summarize_markdown(path: Path, patterns: TaskIdPatterns, max_chars: int = 900) -> Dict[str, Any]:
    """Return a small summary record for a markdown file used by the
    cold-start handoff index.
    """

    text = read_text(path, max_chars=3500)
    title: Optional[str] = None
    for line in text.splitlines():
        if line.startswith("#"):
            title = line.lstrip("#").strip()
            break
    return {
        "path": str(path),
        "size_bytes": path.stat().st_size if path.exists() else 0,
        "title": title,
        "task_ids": patterns.find_task_ids(text),
        "issue_ids": patterns.find_issue_ids(text),
        "excerpt": " ".join(text.split())[:max_chars],
    }


# ---------------------------------------------------------------------------
# Active handoff window discovery
# ---------------------------------------------------------------------------


def find_current_handoffs(
    ctx: RuntimeContext,
    patterns: TaskIdPatterns,
    sprint_ids: Iterable[str],
    limit: int,
) -> List[Dict[str, Any]]:
    handoff_dir = ctx.handoff_dir
    if not handoff_dir.exists():
        return []
    candidates = [
        path
        for path in handoff_dir.glob("*.md")
        if not path.name.startswith("_") and path.name not in {"README.md", ".gitkeep"}
    ]
    sprint_ids = list(sprint_ids)
    scored: List[Tuple[int, str, Path]] = []
    for path in candidates:
        text = read_text(path, max_chars=2500)
        haystack = f"{path.name}\n{text}"
        score = sum(1 for sid in sprint_ids if sid and sid in haystack)
        scored.append((score, path.name, path))
    scored.sort(key=lambda item: (item[0], item[1]), reverse=True)
    if not sprint_ids:
        # No sprint context available — return latest few by name.
        return [summarize_markdown(path, patterns) for _, _, path in scored[:limit]]
    return [summarize_markdown(path, patterns) for score, _, path in scored[:limit] if score > 0]


# ---------------------------------------------------------------------------
# Archive index builder
# ---------------------------------------------------------------------------


def build_archive_index(
    ctx: RuntimeContext,
    patterns: TaskIdPatterns,
    sprint_ids: List[str],
    archive_limit: int,
) -> Dict[str, Any]:
    handoff_archive = ctx.handoff_archive_dir
    handoff_entries: List[Dict[str, Any]] = []
    if handoff_archive.exists():
        for path in sorted(handoff_archive.glob("*.md")):
            if path.name.startswith("_") or path.name in {".gitkeep", "README.md"}:
                continue
            text = read_text(path, max_chars=1800)
            haystack = path.name + "\n" + text
            task_ids = patterns.find_task_ids(haystack)
            issue_ids = patterns.find_issue_ids(haystack)
            in_window = any(sid in task_ids or sid in path.name for sid in sprint_ids)
            handoff_entries.append({
                "path": str(path.relative_to(ctx.repo_root)),
                "size_bytes": path.stat().st_size,
                "task_ids": task_ids,
                "issue_ids": issue_ids,
                "in_current_or_previous_sprint_window": in_window,
                "title": next(
                    (line.lstrip("#").strip() for line in text.splitlines() if line.startswith("#")),
                    None,
                ),
            })
    handoff_entries.sort(
        key=lambda item: (not item["in_current_or_previous_sprint_window"], item["path"])
    )

    key_log_entries: List[Dict[str, Any]] = []
    for path in [ctx.sprint_board_path, ctx.orchestrator_log_path]:
        if not path.exists():
            continue
        text = read_text(path, max_chars=6000)
        key_log_entries.append({
            "path": str(path.relative_to(ctx.repo_root)),
            "size_bytes": path.stat().st_size,
            "task_ids": patterns.find_task_ids(text),
            "issue_ids": patterns.find_issue_ids(text),
        })

    return {
        "schema_version": "sprint_archive_index.v1",
        "generated_at": utc_now(),
        "project": "v4.89_os",
        "sprint_window_ids": sprint_ids,
        "handoff_archive_count": len(handoff_entries),
        "handoff_archive_index": handoff_entries[:archive_limit],
        "key_log_index": key_log_entries,
        "lookup_rule": (
            "Search this index first, then open exact paths only when "
            "historical evidence is needed for cold-start re-entry."
        ),
    }


# ---------------------------------------------------------------------------
# Rollup builder
# ---------------------------------------------------------------------------


_ACTIVE_TASK_STATUSES = frozenset(
    {"in_progress", "validation_pending", "blocked", "review", "active"}
)


def build_rollup(
    ctx: RuntimeContext,
    handoff_limit: int,
    archive_limit: int,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    patterns = TaskIdPatterns.from_context(ctx)
    board_text = read_text(ctx.sprint_board_path)
    current_sprint, previous_sprint, all_previous = parse_sprint_sections(board_text, patterns)
    sprint_ids = sorted(set(
        current_sprint.get("task_ids", []) + previous_sprint.get("task_ids", [])
    ))

    task_registry = load_json(ctx.task_registry_path, default={"tasks": []})
    blocker_registry = load_json(ctx.blocker_registry_path, default={"blockers": []})
    handoff_queue = load_json(ctx.handoff_queue_path, default={"handoffs": []})
    project_snapshot = load_json(ctx.project_snapshot_path, default={})

    tasks = [item for item in task_registry.get("tasks", []) if isinstance(item, dict)]
    blockers = [item for item in blocker_registry.get("blockers", []) if isinstance(item, dict)]
    handoffs = [item for item in handoff_queue.get("handoffs", []) if isinstance(item, dict)]

    sprint_runtime_tasks = [
        task
        for task in tasks
        if str(task.get("task_id", "")) in sprint_ids
        or str(task.get("status", "")) in _ACTIVE_TASK_STATUSES
    ]
    open_blockers = [
        blocker
        for blocker in blockers
        if str(blocker.get("status", "")) not in {"closed", "resolved", "done"}
    ]
    current_handoffs = find_current_handoffs(ctx, patterns, sprint_ids, handoff_limit)

    warnings: List[str] = []
    if board_text.strip() == "":
        warnings.append("tasks/sprint_board.md is empty; no sprint window resolved.")
    if not current_sprint:
        warnings.append("No '## Current Sprint' section found in sprint_board.md.")

    rollup = {
        "schema_version": "sprint_context_rollup.v1",
        "generated_at": utc_now(),
        "project": "v4.89_os",
        "context_window": {
            "current_sprint": current_sprint,
            "previous_sprint": previous_sprint,
            "sprint_ids": sprint_ids,
            "all_previous_sprint_count": len(all_previous),
        },
        "summary": {
            "runtime_task_count": len(tasks),
            "sprint_runtime_task_count": len(sprint_runtime_tasks),
            "open_blocker_count": len(open_blockers),
            "active_handoff_window_count": len(current_handoffs),
            "total_runtime_handoff_count": len(handoffs),
            "archived_runtime_handoff_count": len(
                [item for item in handoffs if str(item.get("status")) == "archived"]
            ),
        },
        "status_counts": {
            "tasks": status_count(tasks),
            "blockers": status_count(blockers),
            "runtime_handoffs": status_count(handoffs),
        },
        "warnings": warnings,
        "runtime_tasks_for_window": [
            compact_item(task, ["task_id", "title", "status", "owner_agent",
                                "sprint_id", "blocker_ids", "handoff_ids",
                                "evidence_refs"])
            for task in sprint_runtime_tasks
        ],
        "open_blockers": [
            compact_item(blocker, ["blocker_id", "title", "status",
                                   "owner_agent", "linked_task_ids", "priority"])
            for blocker in open_blockers
        ],
        "handoff_window": current_handoffs,
        "project_snapshot_summary": (
            project_snapshot.get("summary") if isinstance(project_snapshot, dict) else None
        ),
        "source_refs": [
            "tasks/sprint_board.md",
            "logs/orchestrator_log.md",
            "runtime/registries/task_registry.json",
            "runtime/registries/blocker_registry.json",
            "runtime/registries/handoff_queue.json",
            "runtime/registries/project_status_snapshot.json",
        ],
        "archive_lookup_ref": "runtime/registries/archive_index.json",
    }
    archive_index = build_archive_index(ctx, patterns, sprint_ids, archive_limit)
    return rollup, archive_index


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate sprint-window rollup and archive index for v4.89 cold-start.",
    )
    parser.add_argument("--repo-root", default=None,
                        help="Override the package root (defaults to script's parents[2]).")
    parser.add_argument("--rollup-output", default=None,
                        help="Override the rollup output path.")
    parser.add_argument("--archive-index-output", default=None,
                        help="Override the archive index output path.")
    parser.add_argument("--handoff-limit", type=int, default=12)
    parser.add_argument("--archive-limit", type=int, default=120)
    parser.add_argument("--dry-run", action="store_true",
                        help="Build the rollup and archive index but do not write to disk.")
    args = parser.parse_args()

    script_path = Path(__file__).resolve()
    repo_root = (
        Path(args.repo_root).resolve() if args.repo_root else script_path.parents[2]
    )
    ctx = RuntimeContext(repo_root=repo_root)

    rollup_output = (
        Path(args.rollup_output).resolve()
        if args.rollup_output
        else ctx.sprint_context_rollup_path
    )
    archive_output = (
        Path(args.archive_index_output).resolve()
        if args.archive_index_output
        else ctx.archive_index_path
    )

    rollup, archive_index = build_rollup(ctx, args.handoff_limit, args.archive_limit)

    if not args.dry_run:
        save_json(rollup_output, rollup)
        save_json(archive_output, archive_index)

    summary = {
        "ok": True,
        "dry_run": args.dry_run,
        "rollup_output": str(rollup_output),
        "archive_index_output": str(archive_output),
        "summary": rollup["summary"],
        "current_sprint": rollup["context_window"]["current_sprint"].get("sprint_name"),
        "previous_sprint": rollup["context_window"]["previous_sprint"].get("sprint_name"),
        "warnings": rollup["warnings"],
    }
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
