#!/usr/bin/env python3
"""v4.89 OS — Cold-start pack generator.

Builds a minimal cold-start pack for an agent or thread re-entering
work after a context cold start.  The pack is deterministic JSON
written to stdout; ``boot_agent_thread.py`` (M9.0.4) is the canonical
caller.

The pack honours the active runtime profile's
``sprint_cold_start.mode`` declaration (M9.0.3) and the manifest's
context_files / on_demand_files / dynamic_context plan
(``runtime/config/context_profiles_manifest.json``).

This script is M9.0.5 of v4.89 OS Phase 4 Step 3.  It is a
v4.89-native rewrite of the upstream live cold-start pack; project-
specific business hardcodes from the upstream source (game-genre hint
sets, project workflow document numbers, project-specific task id
patterns, project-domain keys) are deliberately not transcribed.  The
v4.89 rewrite reads its task / issue / sprint id regex from
``runtime/config/task_id_pattern.json`` (M9.0.2) so adopting projects
plug in their own conventions without modifying this script.

Working language: English (permanent contract §11).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

# Allow running as a script: ``python3 tools/runtime/generate_cold_start_pack.py``
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _runtime_common import (  # noqa: E402
    RuntimeContext,
    TaskIdPatterns,
    compact_item,
    load_json,
    read_text,
    utc_now,
)


_ACTIVE_TASK_STATUSES = frozenset(
    {"in_progress", "validation_pending", "blocked", "review", "active"}
)
_TERMINAL_STATUSES = frozenset({"done", "closed", "resolved", "archived", "cancelled"})


# ---------------------------------------------------------------------------
# Profile manifest helpers
# ---------------------------------------------------------------------------


def load_manifest(ctx: RuntimeContext) -> Dict[str, Any]:
    return load_json(ctx.context_profiles_manifest_path, default={})


def manifest_profile(manifest: Dict[str, Any], profile_name: str) -> Dict[str, Any]:
    profiles = manifest.get("profiles", {})
    if not isinstance(profiles, dict):
        return {}
    profile = profiles.get(profile_name)
    if not isinstance(profile, dict):
        return {}
    return profile


def manifest_default_profile(manifest: Dict[str, Any]) -> str:
    value = manifest.get("default_profile")
    return str(value) if value else "SPRINT_GOVERNED"


# ---------------------------------------------------------------------------
# Registry / rollup loaders
# ---------------------------------------------------------------------------


def load_runtime_objects(ctx: RuntimeContext) -> Dict[str, Any]:
    return {
        "task_registry": load_json(ctx.task_registry_path, default={"tasks": []}),
        "blocker_registry": load_json(ctx.blocker_registry_path, default={"blockers": []}),
        "handoff_queue": load_json(ctx.handoff_queue_path, default={"handoffs": []}),
        "project_snapshot": load_json(ctx.project_snapshot_path, default={}),
        "sprint_context_rollup": load_json(ctx.sprint_context_rollup_path, default={}),
        "archive_index": load_json(ctx.archive_index_path, default={}),
    }


# ---------------------------------------------------------------------------
# Task / blocker / handoff selection
# ---------------------------------------------------------------------------


def find_task(tasks: Sequence[Dict[str, Any]], task_id: str) -> Optional[Dict[str, Any]]:
    for task in tasks:
        if str(task.get("task_id", "")) == task_id:
            return task
    return None


def candidate_tasks_from_agent(
    tasks: Sequence[Dict[str, Any]], agent_name: Optional[str]
) -> List[Dict[str, Any]]:
    if not agent_name:
        return []
    canonical = agent_name.strip().lower()
    return [
        task
        for task in tasks
        if str(task.get("owner_agent", "")).strip().lower() == canonical
        and str(task.get("status", "")).strip().lower() in _ACTIVE_TASK_STATUSES
    ]


def candidate_tasks_from_issue(
    tasks: Sequence[Dict[str, Any]], issue_id: Optional[str]
) -> List[Dict[str, Any]]:
    if not issue_id:
        return []
    matches: List[Dict[str, Any]] = []
    for task in tasks:
        blocker_ids = task.get("blocker_ids") or []
        if isinstance(blocker_ids, list) and issue_id in blocker_ids:
            matches.append(task)
    return matches


def sort_candidates(
    candidates: List[Dict[str, Any]], hinted_ids: Sequence[str]
) -> List[Dict[str, Any]]:
    hinted = set(hinted_ids)

    def score(task: Dict[str, Any]) -> Tuple[int, str]:
        task_id = str(task.get("task_id", ""))
        return (1 if task_id in hinted else 0, task_id)

    return sorted(candidates, key=score, reverse=True)


def find_open_blockers(
    blockers: Sequence[Dict[str, Any]], task_blocker_ids: Sequence[str]
) -> List[Dict[str, Any]]:
    if not task_blocker_ids:
        return []
    wanted = set(task_blocker_ids)
    return [
        blocker
        for blocker in blockers
        if str(blocker.get("blocker_id", "")) in wanted
        and str(blocker.get("status", "")).strip().lower() not in _TERMINAL_STATUSES
    ]


def latest_handoff_for_task(
    handoffs: Sequence[Dict[str, Any]], task_id: Optional[str]
) -> Optional[Dict[str, Any]]:
    if not task_id:
        return None
    candidates = [
        handoff
        for handoff in handoffs
        if task_id in (handoff.get("linked_issue_ids") or [])
        or task_id in str(handoff.get("file_path", ""))
    ]
    if not candidates:
        return None
    candidates.sort(key=lambda item: str(item.get("created_at") or ""), reverse=True)
    return candidates[0]


# ---------------------------------------------------------------------------
# Confidence scoring
# ---------------------------------------------------------------------------


def confidence_level(
    primary: Optional[Dict[str, Any]],
    secondary: Sequence[Dict[str, Any]],
    explicit_task_id: Optional[str],
) -> str:
    if primary and explicit_task_id:
        return "high"
    if primary and not secondary:
        return "high"
    if primary and len(secondary) <= 2:
        return "medium"
    if not primary and not secondary:
        return "empty"
    return "low"


def task_reset_warning(
    primary: Optional[Dict[str, Any]],
    secondary: Sequence[Dict[str, Any]],
) -> Optional[str]:
    if primary is None and secondary:
        return (
            "No primary task resolved; multiple candidate tasks exist. "
            "Pick one explicitly via --task-id before proceeding."
        )
    if primary and len(secondary) >= 3:
        return (
            f"Primary task {primary.get('task_id')} chosen but {len(secondary)} "
            "additional candidates remain; verify the choice before deep work."
        )
    return None


# ---------------------------------------------------------------------------
# Context file resolution from manifest
# ---------------------------------------------------------------------------


def resolve_context_files(
    ctx: RuntimeContext, manifest: Dict[str, Any], profile_name: str
) -> Dict[str, List[str]]:
    profile = manifest_profile(manifest, profile_name)
    return {
        "context_files": [str(p) for p in profile.get("context_files", []) if isinstance(p, str)],
        "dynamic_context": [str(p) for p in profile.get("dynamic_context", []) if isinstance(p, str)],
        "on_demand_files": [str(p) for p in profile.get("on_demand_files", []) if isinstance(p, str)],
        "load_width_policy": str(profile.get("load_width_policy", "")),
        "auto_escalate_to_on_demand": [
            str(item) for item in profile.get("auto_escalate_to_on_demand", []) if isinstance(item, str)
        ],
    }


def make_must_read_files(
    ctx: RuntimeContext,
    profile_files: Dict[str, List[str]],
    primary_task: Optional[Dict[str, Any]],
) -> List[str]:
    seen: List[str] = []
    seen_set: set[str] = set()

    def push(path: str) -> None:
        if path and path not in seen_set:
            seen_set.add(path)
            seen.append(path)

    for path in profile_files.get("context_files", []):
        push(path)
    if primary_task:
        for evidence in primary_task.get("evidence_refs") or []:
            if isinstance(evidence, str):
                push(evidence)
    return seen


# ---------------------------------------------------------------------------
# Suggested next-step heuristic
# ---------------------------------------------------------------------------


def suggest_next_step(
    primary_task: Optional[Dict[str, Any]],
    open_blockers: Sequence[Dict[str, Any]],
    latest_handoff: Optional[Dict[str, Any]],
) -> str:
    if not primary_task:
        return (
            "Cold start landed without a resolved primary task; review the "
            "sprint board to pick the next task or issue an explicit --task-id."
        )
    status = str(primary_task.get("status", "")).strip().lower()
    if open_blockers:
        return (
            f"Resolve open blocker(s) {[b.get('blocker_id') for b in open_blockers]} "
            f"before continuing on task {primary_task.get('task_id')}."
        )
    if status == "validation_pending":
        return f"Run the validation gate for task {primary_task.get('task_id')}."
    if latest_handoff:
        return (
            f"Pick up the latest handoff {latest_handoff.get('handoff_id')} "
            f"for task {primary_task.get('task_id')}."
        )
    if status in {"in_progress", "active"}:
        return f"Continue task {primary_task.get('task_id')} where the agent log left off."
    return f"Start task {primary_task.get('task_id')} per its acceptance criteria."


def infer_not_in_scope(
    primary_task: Optional[Dict[str, Any]], open_blockers: Sequence[Dict[str, Any]]
) -> List[str]:
    notes: List[str] = []
    if primary_task and primary_task.get("sprint_id"):
        notes.append(
            f"Out-of-sprint work (sprint scope = {primary_task.get('sprint_id')})"
        )
    if open_blockers:
        notes.append("Bypassing or deferring the listed open blockers")
    notes.append("Touching v4.88_Release/ assets (byte-locked)")
    return notes


# ---------------------------------------------------------------------------
# Orchestrator log glance
# ---------------------------------------------------------------------------


def recent_log_entries(ctx: RuntimeContext, max_entries: int) -> List[str]:
    text = read_text(ctx.orchestrator_log_path, max_chars=8000)
    if not text:
        return []
    headings = [
        line.strip() for line in text.splitlines() if line.startswith("### ")
    ]
    return headings[-max_entries:] if max_entries > 0 else headings


# ---------------------------------------------------------------------------
# Pack assembly
# ---------------------------------------------------------------------------


def build_pack(
    ctx: RuntimeContext,
    args: argparse.Namespace,
) -> Dict[str, Any]:
    manifest = load_manifest(ctx)
    profile_name = args.profile or manifest_default_profile(manifest)
    profile_files = resolve_context_files(ctx, manifest, profile_name)
    runtime = load_runtime_objects(ctx)
    patterns = TaskIdPatterns.from_context(ctx)

    tasks = [item for item in runtime["task_registry"].get("tasks", []) if isinstance(item, dict)]
    blockers = [item for item in runtime["blocker_registry"].get("blockers", []) if isinstance(item, dict)]
    handoffs = [item for item in runtime["handoff_queue"].get("handoffs", []) if isinstance(item, dict)]

    rollup = runtime["sprint_context_rollup"] if isinstance(runtime["sprint_context_rollup"], dict) else {}
    sprint_window = rollup.get("context_window", {}) if isinstance(rollup, dict) else {}
    sprint_ids = sprint_window.get("sprint_ids", []) if isinstance(sprint_window, dict) else []

    explicit_task = find_task(tasks, args.task_id) if args.task_id else None

    candidates: List[Dict[str, Any]] = []
    if explicit_task:
        candidates.append(explicit_task)
    candidates.extend(candidate_tasks_from_agent(tasks, args.agent))
    candidates.extend(candidate_tasks_from_issue(tasks, args.issue_id))
    deduped: List[Dict[str, Any]] = []
    seen_ids: set[str] = set()
    for task in candidates:
        tid = str(task.get("task_id", ""))
        if tid and tid not in seen_ids:
            seen_ids.add(tid)
            deduped.append(task)
    sorted_candidates = sort_candidates(deduped, sprint_ids)

    primary_task = sorted_candidates[0] if sorted_candidates else None
    secondary_tasks = sorted_candidates[1:6]

    primary_blockers = (
        find_open_blockers(blockers, primary_task.get("blocker_ids") or [])
        if primary_task
        else []
    )
    latest_handoff = latest_handoff_for_task(
        handoffs, primary_task.get("task_id") if primary_task else None
    )

    must_read_files = make_must_read_files(ctx, profile_files, primary_task)

    pack = {
        "schema_version": "cold_start_pack.v1",
        "generated_at": utc_now(),
        "project": "v4.89_os",
        "profile": profile_name,
        "load_width_policy": profile_files["load_width_policy"],
        "primary_task": (
            compact_item(primary_task, ["task_id", "title", "status",
                                        "owner_agent", "sprint_id",
                                        "blocker_ids", "handoff_ids",
                                        "evidence_refs"])
            if primary_task
            else None
        ),
        "secondary_candidate_tasks": [
            compact_item(task, ["task_id", "title", "status", "owner_agent"])
            for task in secondary_tasks
        ],
        "open_blockers": [
            compact_item(blocker, ["blocker_id", "title", "status",
                                   "owner_agent", "priority"])
            for blocker in primary_blockers
        ],
        "latest_handoff": (
            compact_item(latest_handoff,
                         ["handoff_id", "status", "file_path", "created_at"])
            if latest_handoff
            else None
        ),
        "context_files": profile_files["context_files"],
        "dynamic_context": profile_files["dynamic_context"],
        "on_demand_files": profile_files["on_demand_files"],
        "must_read_files": must_read_files,
        "sprint_window_ids": sprint_ids,
        "recent_orchestrator_log_entries": recent_log_entries(ctx, max_entries=5),
        "suggested_next_step": suggest_next_step(
            primary_task, primary_blockers, latest_handoff
        ),
        "not_in_scope": infer_not_in_scope(primary_task, primary_blockers),
        "confidence": confidence_level(primary_task, secondary_tasks, args.task_id),
        "task_reset_warning": task_reset_warning(primary_task, secondary_tasks),
        "auto_escalate_to_on_demand": profile_files["auto_escalate_to_on_demand"],
    }
    # patterns is loaded so adopting projects can plug in their own task id
    # regex via runtime/config/task_id_pattern.json without code change.  It
    # is not currently surfaced in the pack JSON; consumers who need it
    # should look at the rollup / archive index outputs of M9.0.4.
    _ = patterns
    return pack


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate a cold-start pack for v4.89 OS agent/thread re-entry.",
    )
    parser.add_argument("--agent")
    parser.add_argument("--thread")
    parser.add_argument("--task-id", dest="task_id")
    parser.add_argument("--issue-id", dest="issue_id")
    parser.add_argument(
        "--profile",
        choices=("SPRINT_GOVERNED", "SPRINT_DEEP", "ARCHIVE_LOOKUP"),
        default=None,
        help="Cold-start profile name; defaults to manifest.default_profile.",
    )
    parser.add_argument("--repo-root", default=None,
                        help="Override the package root.")
    args = parser.parse_args()

    if not (args.agent or args.thread or args.task_id or args.issue_id):
        raise SystemExit(
            "At least one of --agent, --thread, --task-id, or --issue-id is required."
        )

    script_path = Path(__file__).resolve()
    repo_root = (
        Path(args.repo_root).resolve() if args.repo_root else script_path.parents[2]
    )
    ctx = RuntimeContext(repo_root=repo_root)

    pack = build_pack(ctx, args)
    print(json.dumps(pack, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
