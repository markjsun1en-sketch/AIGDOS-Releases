#!/usr/bin/env python3
"""v4.89 OS — agent / thread cold-start boot wrapper.

Default boot entry for cold-start re-entry.  Exposes one CLI surface
that the runtime profile templates reference; subprocess-launches
``generate_cold_start_pack.py`` (M9.0.5) and decorates the resulting
JSON with a few boot-mode keys.

Honours the sprint cold-start mode declared in the active runtime
profile (``config/profiles/<profile>.json::sprint_cold_start.mode``,
written in M9.0.3).  The active profile may be supplied via the
``--profile`` flag; if omitted, the wrapper falls back to the
``COLD_START_PROFILE`` environment variable, then to ``SPRINT_GOVERNED``.

This script is M9.0.4 of v4.89 OS Phase 4 Step 3.  v4.89-native rewrite.
Working language: English (permanent contract §11).
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List


_DEFAULT_PROFILE = "SPRINT_GOVERNED"
_VALID_PROFILES = ("SPRINT_GOVERNED", "SPRINT_DEEP", "ARCHIVE_LOOKUP")


def _resolve_profile(args: argparse.Namespace) -> str:
    if args.profile:
        return args.profile
    env_profile = os.environ.get("COLD_START_PROFILE", "").strip()
    if env_profile:
        return env_profile
    return _DEFAULT_PROFILE


def _resolve_boot_mode(args: argparse.Namespace) -> str:
    if args.task_id:
        return "explicit_task"
    if args.issue_id:
        return "explicit_issue"
    return "default_cold_start"


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Default boot entry for v4.89 OS agent/thread cold-start re-entry.",
    )
    parser.add_argument("--agent")
    parser.add_argument("--thread")
    parser.add_argument("--task-id")
    parser.add_argument("--issue-id")
    parser.add_argument(
        "--profile",
        choices=list(_VALID_PROFILES),
        default=None,
        help=(
            "Cold-start profile name as declared in "
            "runtime/config/context_profiles_manifest.json. Defaults to "
            "$COLD_START_PROFILE, then to SPRINT_GOVERNED."
        ),
    )
    parser.add_argument("--repo-root", default=None,
                        help="Override the package root for cold-start pack invocation.")
    parser.add_argument("--dry-run", action="store_true",
                        help="Resolve boot context but do not call the cold-start pack.")
    args = parser.parse_args()

    if not (args.agent or args.thread or args.task_id or args.issue_id):
        raise SystemExit(
            "At least one of --agent, --thread, --task-id, or --issue-id is required."
        )

    profile = _resolve_profile(args)
    boot_mode = _resolve_boot_mode(args)

    if args.dry_run:
        payload: Dict[str, Any] = {
            "ok": True,
            "dry_run": True,
            "boot_mode": boot_mode,
            "boot_source": "boot_agent_thread.py",
            "profile": profile,
            "agent": args.agent,
            "thread": args.thread,
            "task_id": args.task_id,
            "issue_id": args.issue_id,
        }
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return

    script_path = Path(__file__).with_name("generate_cold_start_pack.py")
    if not script_path.exists():
        raise SystemExit(
            f"Cold-start pack generator missing: {script_path}. "
            "M9.0.5 must land before this wrapper can boot a real thread."
        )

    cmd: List[str] = [sys.executable, str(script_path)]
    if args.agent:
        cmd.extend(["--agent", args.agent])
    if args.thread:
        cmd.extend(["--thread", args.thread])
    if args.task_id:
        cmd.extend(["--task-id", args.task_id])
    if args.issue_id:
        cmd.extend(["--issue-id", args.issue_id])
    if args.profile:
        cmd.extend(["--profile", args.profile])
    if args.repo_root:
        cmd.extend(["--repo-root", args.repo_root])

    completed = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if completed.returncode != 0:
        raise SystemExit(
            (completed.stderr or completed.stdout or "cold-start pack failed").strip()
        )

    try:
        pack_payload = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"cold-start pack returned non-JSON output: {exc}") from exc

    pack_payload["boot_mode"] = boot_mode
    pack_payload["boot_source"] = "boot_agent_thread.py"
    pack_payload["cold_start_performed"] = True
    pack_payload["profile"] = profile
    print(json.dumps(pack_payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
