# Cursor Project Rules Template

This project uses **AI_Game_Dev_OS v4.89** with the **Cursor runtime profile**.

## Core Cursor execution stance

- agents may explore or implement in parallel
- isolated worktree/branch execution is preferred
- apply/merge to the main integration line is serial
- TAPD writeback follows reviewed accepted state

## Rule themes to keep active

- plan before broad edits
- keep each agent scoped
- avoid concurrent mutation of state-heavy files
- centralize writeback and audit closure during beta sprint operation

## Agent completion expectation

Each agent should hand back:

- changed files
- summary of result
- validation status
- whether result is candidate or accepted
