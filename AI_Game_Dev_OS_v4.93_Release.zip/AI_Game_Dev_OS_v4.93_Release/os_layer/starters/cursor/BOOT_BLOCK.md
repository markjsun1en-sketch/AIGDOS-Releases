# Cursor Boot Block

Use this block for a bounded Cursor agent task.

## Include in the task

- task id and goal
- scope files
- acceptance criteria
- whether worktree isolation is required
- who owns final apply/merge
- who owns TAPD writeback

## Cursor-specific note

Do not confuse parallel generation with parallel integration. Results may be produced in parallel, but accepted integration is serialized.
