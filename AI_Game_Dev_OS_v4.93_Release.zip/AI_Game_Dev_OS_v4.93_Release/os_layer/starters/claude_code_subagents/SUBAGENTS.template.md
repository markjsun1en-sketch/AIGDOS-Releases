# Subagents Template

## Example bounded subagent roles

### implementation_worker

Use for one bounded code change with a clear file scope.

### analysis_worker

Use for codebase or document analysis that returns a structured summary.

### docs_worker

Use for producing or revising docs from an explicit source set.

## Required fields per subagent

- name
- allowed task type
- expected handback format
- whether worktree isolation is required
- whether hooks apply before completion
