# Subsystem Roles — Shared Starter Layer

> Added 2026-04-22 to close REV-5-009 (Subsystems Capability Packs —
> design / art / uiux / engineering / game-design / qa / sound etc —
> had zero mapping to starters; projects couldn't tell how to use the
> subsystem Skills migrated in Phase 3 Step 1 under any particular
> runtime profile).

## Purpose

`skills/_generic_core/` (populated by Phase 3 Step 1) provides 34 subsystem-organized Skills across 12 subsystems. This doc explains **how to bind subsystem Skills to Agent definitions** when instantiating a starter for a particular runtime profile.

Related: `docs/06_runtime_profiles/Runtime_Profile_Comparison.md` §Subsystem support table (REV-4-007) explains **which profile** supports subsystem decomposition best. This doc goes one level down: **how Agents inside any chosen profile carry subsystem role information**.

## Subsystems inventory

From `skills/_generic_core/`:

| Subsystem | Skill count | Typical deliverables |
| --- | --- | --- |
| `art` | 7 | concept / consistency review / asset breakdown / batch planning / variation control / engine export / image cleanup |
| `design` | 6 | content scope / handoff prep / feature acceptance / feature brief / gameplay loop / rules & constraints |
| `uiux` | 6 | component spec / flow / information architecture / review / screen structure / visual binding |
| `engineering` | 2 | delivery contract / workflow ops |
| `ep` | 1 | delivery contract (Executive Producer / EP) |
| `game-design` | 2 | delivery contract / workflow ops |
| `research` | 2 | delivery contract / workflow ops |
| `orchestrator` | 2 | delivery contract / workflow ops (4 parallel-agent hard rules) |
| `content-design` | 1 | delivery contract (pairs with data pipeline hook) |
| `numeric` | 1 | delivery contract (pairs with data pipeline hook) |
| `qa` | 2 | delivery contract / workflow ops (scoring + gate hooks) |
| `sound-designer` | 2 | delivery contract / workflow ops (audio naming + audiogen hooks) |

## Subsystem field in Agent definitions

When authoring `starters/<profile>/AGENTS.md.template` (or equivalent) for a specific project, each Agent declaration should carry an explicit `subsystem` field that names **one** subsystem from the inventory above. This lets automated tooling know which Skills to load for that Agent's context.

### YAML declaration pattern

```yaml
agents:
  - id: engineering-main
    subsystem: engineering
    skills:
      - skills/_generic_core/engineering/ENGINEERING_DELIVERY_CONTRACT.md
      - skills/_generic_core/engineering/engineering_workflow_ops.md
    hooks:
      - skills/_adaptation_hooks/common/hook_engine_validation.md
      - skills/_adaptation_hooks/common/hook_branch_strategy.md

  - id: qa-main
    subsystem: qa
    skills:
      - skills/_generic_core/qa/QA_DELIVERY_CONTRACT.md
      - skills/_generic_core/qa/qa_workflow_ops.md
    hooks:
      - skills/_adaptation_hooks/common/hook_5d_scoring.md
      - skills/_adaptation_hooks/common/hook_gate_standards.md
```

### Markdown declaration pattern

Projects that prefer markdown-only AGENTS.md can use:

```markdown
### engineering-main
- **Subsystem**: engineering
- **Skills**: skills/_generic_core/engineering/{ENGINEERING_DELIVERY_CONTRACT, engineering_workflow_ops}.md
- **Adaptation hooks**: skills/_adaptation_hooks/common/{hook_engine_validation, hook_branch_strategy}.md
```

## Profile-specific notes

### Codex + Cursor + Claude Subagents (ephemeral role model)

Each subagent/parallel-agent spawn's brief should name the subsystem at prompt level:

> "Act as the `engineering` subsystem per `skills/_generic_core/engineering/`. Follow the delivery contract + workflow ops; apply adaptation hooks as listed in the project's AGENTS.md for this role."

Subsystem binding is ephemeral per task; do not expect subsystem state to persist across spawns.

### Claude Agent Teams (persistent role model, strongest match)

Each teammate can be bound to a subsystem long-lived. When calling the Task tool with `name`:

- Use a teammate name that reflects the subsystem: `engineering`, `qa-lead`, `sound-designer`, etc.
- Pre-load the teammate with the subsystem's Skills via starter boot sequence
- Lead routing logic maps task types to teammate roles via subsystem match

### Workbuddy Private (project-defined)

Workbuddy's `AGENTS.md.template` (40 KB, REV-4-010 exception) carries subsystem role declarations internally in project-specific format. Projects migrating to public profiles should extract the subsystem field per Agent and re-author the declaration in the YAML/markdown patterns above.

## Cross-references

- `skills/README.md` — Skills layer navigation (Phase 3 Step 1)
- `skills/_generic_core/` — 34 subsystem Skills
- `skills/_adaptation_hooks/` — 12 project-adaptation hooks
- `docs/06_runtime_profiles/Runtime_Profile_Comparison.md` §Subsystem support — profile-level support matrix (REV-4-007)
- `docs/07_starters/shared/Agent_Definition_Template.md` — Agent declaration template (Phase 4 extension may add subsystem field here)
- `starters/shared/TASK_TEMPLATE.yaml` / `HANDOFF_TEMPLATE.yaml` / `QA_GATE_TEMPLATE.yaml` — downstream templates that may consume subsystem field
