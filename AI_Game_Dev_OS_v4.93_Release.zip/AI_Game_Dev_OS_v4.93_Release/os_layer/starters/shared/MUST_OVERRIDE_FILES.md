# Must Override Files

These files are package templates and should be overridden or concretized in a real project setup.

## Always override

- runtime config for the selected project
- TAPD workspace / iteration / project identifiers
- selected execution profile config if the defaults do not match the project
- project adaptation summary
- project-specific boot blocks

## Usually override

- AGENTS / CLAUDE / rules files used by the chosen runtime
- task / handoff / QA templates if the project has stronger schema requirements
- default loadset if the project is unusually small or unusually complex

## Do not treat as final project truth

The following package files are package baselines, not project-owned deliverables:

- package digest
- package overview
- runtime profile docs
- release notes

## Override rule

If a file contains placeholder identifiers, example workspace IDs, example task IDs, or generic repo assumptions, treat it as a required override before real sprint execution.
