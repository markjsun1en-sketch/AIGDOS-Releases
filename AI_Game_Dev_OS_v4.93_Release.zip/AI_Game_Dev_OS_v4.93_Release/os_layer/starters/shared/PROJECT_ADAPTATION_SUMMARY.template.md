# PROJECT_ADAPTATION_SUMMARY

## Project Identity
- project_name:
- project_id:
- engine:
- target_platforms:
- runtime_profile:

## Scope
- current_phase:
- sprint_mode:
- active_ep_owner:

## Core Decisions
- external_pm: TAPD
- vcs: Git
- isolation_unit:
- writeback_owner:
- cleanup_owner:

## Project Overrides
- must_override_files:
- project_specific_agents:
- project_specific_rules:
- project_specific_validation:

## Current Risks
- risk_1:
- risk_2:
- risk_3:
