# Codex Boot Block

Use this boot block when starting a bounded Codex task.

## Required context

- selected execution profile = codex
- current task id and title
- touched files
- acceptance criteria
- writeback owner
- whether a worktree is required

## Required operating rules

- stay inside the declared file/task scope
- do not write back to TAPD directly unless explicitly instructed
- if working in parallel, use isolated worktree/branch target
- return a compact summary suitable for parent review and serial integration

## Required return payload

- what changed
- validation status
- remaining risk
- suggested next state
