# Team Boot Guide

## Before starting a team

Confirm all of the following:

- several tasks can genuinely proceed independently
- one lead is clearly designated
- teammate scope is bounded
- cleanup ownership is clear
- TAPD writeback remains lead-owned for the beta sprint

## Team startup packet

The lead should prepare:

- shared sprint objective
- teammate assignments
- conflict boundaries
- integration order expectations
- quality gate checkpoints

## See also
- `docs/USAGE_GUIDE.md §6` — authoritative three-step sprint close flow (`init_runtime_env.py` → `run_beta_sprint_check.py` → `verify_beta_sprint_exit.py`) + v4.89 maturity tier table (inherited from v4.88-stable B+ Bridge Hardening line).
