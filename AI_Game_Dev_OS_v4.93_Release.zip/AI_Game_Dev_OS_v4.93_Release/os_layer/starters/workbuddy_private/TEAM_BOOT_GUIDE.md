# Workbuddy Private Team Boot Guide

This guide is intentionally private-profile specific.

## Before starting team mode

- define a unique team name tied to sprint/task scope
- define main-session proxy sync ownership
- define registry-sensitive files and task state ownership
- define recovery owner if dirty state appears
- confirm project-facing rule files are present: `AGENTS.md`, `SKILLS.md`, execution/workflow rules

## During execution

- keep worker scope bounded
- do not let team members improvise external writeback ownership
- capture enough information for main-session reconciliation
- use re-entry guidance instead of improvised continuation after interruption

## See also
- `docs/USAGE_GUIDE.md §6` — authoritative three-step sprint close flow (`init_runtime_env.py` → `run_beta_sprint_check.py` → `verify_beta_sprint_exit.py`) + v4.89 maturity tier table (inherited from v4.88-stable B+ Bridge Hardening line).
