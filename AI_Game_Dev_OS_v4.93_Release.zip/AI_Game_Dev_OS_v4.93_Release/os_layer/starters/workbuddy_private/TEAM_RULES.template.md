# Workbuddy Private Team Rules Template

## Core rules

- team name must be unique and traceable
- main session owns proxy sync by default
- registry/task state mutations require review when execution fails or stalls
- cleanup is centralized
- `AGENTS.md` is a live project execution file, not a decorative reference
- `SKILLS.md` should define recurring execution patterns
- this runtime profile should not be generalized to other tools by default
