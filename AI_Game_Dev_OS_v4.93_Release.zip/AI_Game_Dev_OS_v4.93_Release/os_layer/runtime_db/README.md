# runtime_db/ — Runtime State Store Skeleton

> **Created in Phase 2 Step 1.0**: 2026-04-21. Copied as an empty-directory skeleton from v4.87's `runtime_db/`; actual data is filled in after Steps 1.1~1.8 re-mount the runtime scripts, which populate this tree according to `config/runtime_storage_policy.yaml`'s `runtime_root` setting.

## Directory structure

```
runtime_db/
├── external/    # external-system snapshots (written back by TAPD / Git / adapters)
├── objects/     # Runtime Object storage (task / blocker / handoff / snapshot / etc.)
│   └── (populated per-object-type by runtime_object_cli.py from Step 1.1 onwards)
└── registry/    # central registry
    └── (registry.json maintained by registry_manager.py from Step 1.1 onwards)
```

## Configuration source

`config/runtime_storage_policy.yaml` defines the relative path for each subdirectory (defaults as above). At script startup, `runtime_common.resolve_storage_paths()` resolves these to absolute paths.

## Life cycle

- **Step 1.0 (this round)**: create the empty skeleton; no data is placed.
- **Steps 1.1~1.8**: re-mount the runtime scripts.
- **Phase 3 trial**: `scripts/load_demo_seed.py` (shipped with v4.87, ported in Phase 3) seeds demo data for validation.
- **After project onboarding**: the project's adapters write real `task` / `blocker` entries.

## Content that should not enter git (a `.gitignore` candidate)

After the Phase 3 trial, this directory fills with real `jsonl` / `json` runtime data; these **should not enter git** (they are runtime state, not source). When Phase 3 closes, consider adding:

```gitignore
# .gitignore candidate
AI_Game_Dev_OS_v4.89_Release/runtime_db/**
!AI_Game_Dev_OS_v4.89_Release/runtime_db/**/README.md
!AI_Game_Dev_OS_v4.89_Release/runtime_db/**/.gitkeep
```

**In Phase 2 (current)**: the skeleton is committed (empty directories need a `.gitkeep` or a README placeholder; this README serves that role).

## References

- Source: `AI_Game_Dev_OS_v4.87_Stabilization_AdapterObs_Concrete/AI_Game_Dev_OS_v4.87_Optimized_Run_Baseline/runtime_db/`.
- Config: `config/runtime_storage_policy.yaml`.
- Plan: `086af2bd06074626ae5a1c88358eb6d2` Phase 2 Step 1.0.
