# AI Game Dev OS v4.93 Real Project Adoption Contract

This contract defines the evidence required before v4.93 can be claimed as
adopted by a real project or considered for lifecycle promotion.

The current lifecycle remains `draft`. Fixture success, synthetic traces, and
dry-run reports are regression evidence only. They do not authorize promotion.

## Required Inputs

| Input | Required Path Or Source | Purpose |
| --- | --- | --- |
| Target project root | `<target_project>/` | Project being evaluated. |
| Runtime state root | `<target_project>/.ai_dev_os/` | Project-owned bindings, run plans, traces, and reports. |
| Readiness binding registry | `<target_project>/.ai_dev_os/readiness_binding_registry.json` | Preferred project-declared adapter input. It can include capability bindings, split gate statuses, evidence lifecycle, and safe/unsafe interpretation guidance. |
| Capability bindings | `<target_project>/.ai_dev_os/capability_bindings.json` or accepted compatibility path | Compatibility input when the readiness binding registry is absent. |
| Artifact root | `<target_project_artifacts>/v493/` | Shareable evidence generated for review. |
| Delivery artifacts | artifact root JSON and referenced files | GDD, production specs, QA, rollback, visual, RawData, and handoff evidence. |
| Agent run plan | `<target_project>/.ai_dev_os/agent_run_plan.json` | Expected external agent lanes. |
| Agent execution trace | `<target_project>/.ai_dev_os/agent_execution_trace.json` | Runtime-produced evidence that agents executed the plan. |
| Beta readiness report | `<target_project_artifacts>/v493/beta_readiness_report.json` | Promotion decision input. |

Runtime output placement is defined by `RUNTIME_INSTANCE_CONTRACT.md`.

## Split-Gate Readiness Registry

When `.ai_dev_os/readiness_binding_registry.json` exists,
`inspect_project_readiness.py` treats it as the primary adapter input before
falling back to legacy capability binding files. The registry keeps these
states separate:

- `sprint_closure_gate`: whether a project sprint or D2 slice is closed;
- `focused_qa_gate`: whether focused QA evidence passes for its declared scope;
- `human_review_gate`: whether human review is final or still blocked;
- `supported_adoption_gate`: whether the OS can claim supported project
  adoption;
- `os_demo_gate`: whether OS demo evidence is complete;
- `production_release_gate`: whether production approval exists.

Non-final statuses such as `review_needed`,
`human_visual_rejected_rework_required`, and
`provisional_slice_human_accepted_not_production_approval` are valid evidence
states. They may support project review, but they must not be rewritten as
production approval. A blocked `os_demo_gate` or rejected follow-up art review
must not be collapsed into "the earlier sprint closure failed" unless the
registry explicitly marks that sprint gate as failed.

## Required Run Sequence

Start with a read-only or explicit-output dry run:

```bash
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/evaluate_pack_beta_readiness.py \
  --project-root <target_project> \
  --artifact-root <target_project_artifacts>/v493 \
  --dry-run \
  --write-report <target_project_artifacts>/v493/beta_readiness_dry_run.json
```

Generate a run plan for runtime-mediated work:

```bash
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/generate_agent_run_plan.py \
  --artifact-root <target_project_artifacts>/v493 \
  --write-plan <target_project>/.ai_dev_os/agent_run_plan.json
```

Validate the runtime-produced trace:

```bash
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/validate_agent_execution_trace.py \
  --run-plan <target_project>/.ai_dev_os/agent_run_plan.json \
  --trace <target_project>/.ai_dev_os/agent_execution_trace.json
```

Run the promotion evidence evaluator only after blockers are repaired:

```bash
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/evaluate_pack_beta_readiness.py \
  --project-root <target_project> \
  --artifact-root <target_project_artifacts>/v493 \
  --agent-trace <target_project>/.ai_dev_os/agent_execution_trace.json \
  --spec-authority-review <target_project_artifacts>/v493/closure_evidence/spec_authority_review.json \
  --write-report <target_project_artifacts>/v493/beta_readiness_report.json
```

Render the reviewer-facing report:

```bash
python3 AI_Game_Dev_OS_v4.93/scripts/delivery/render_beta_readiness_report.py \
  --report <target_project_artifacts>/v493/beta_readiness_report.json \
  --write-markdown <target_project_artifacts>/v493/beta_readiness_report.md
```

## Spec Authority Evidence

The qualifying real-project run must exercise and record how the runtime chose
the design/spec authority used for execution. LessIsMore is the designated
v4.93 closure project unless a later human-approved project supersedes it.

The reviewed evidence must contain:

- the candidate GDD, design decision, production spec, and change/merge records
  that were available to the executing Agent;
- the exact source refs that the Agent treated as current;
- the applicable Human review or approval refs;
- any stale, superseded, proposed, conflicted, or unmerged candidate that was
  rejected, including the rejection reason;
- the downstream task, implementation, QA, or handoff affected by the
  resolution;
- a reviewer verdict of `resolved_current_authority`, `blocked_ambiguity`, or
  `authority_defect_found`.

At least one real mid-production requirement/design change must be evaluated
when the project contains such a change. If no qualifying change exists, the
review must state that negative result rather than fabricate one.

v4.93 does not need to implement the full temporal truth resolver planned for
v4.94. It must, however, fail closed when the current Human-approved source
cannot be proven. A stale or superseded spec influencing execution while the
readiness report still passes is a v4.93 closure blocker, not merely v4.94
backlog.

The beta readiness evaluator must consume the reviewed Spec Authority record
for real-project runtime evidence. Missing evidence, `blocked_ambiguity`,
`authority_defect_found`, missing Human approval refs, or a selected
non-current candidate must fail the execution and promotion gates. Fixture
regression is non-promotional and cannot satisfy this check. The Spec Authority
`qualifying_task_id` must equal the supplied trace `task_id`; an historical
trace from another Sprint/task cannot qualify the reviewed run.
`resolved_current_authority` also fails closed when a selected candidate is not
marked `selected`, unresolved ambiguity is recorded, memory/retrieval overrode
approved authority, or resolution occurred after qualifying execution.

## Promotion Gate

Lifecycle promotion can be considered only when all are true:

- `beta_readiness_report.json` has `verdict: "PASS"`;
- `beta_promotion_allowed` is `true`;
- `trace_evidence_mode` is `supplied`;
- `promotion_blockers` is empty;
- the supplied `agent_execution_trace.json` was produced by an external runtime
  or AI IDE, not synthesized by repository scripts for fixture regression;
- reviewed Spec Authority Evidence exists for the qualifying real-project run;
- no stale, superseded, unapproved, or ambiguous source was accepted as current;
- any unresolved authority ambiguity produced a blocking result rather than a
  successful execution or promotion verdict;
- reviewers approve the evidence and manually update lifecycle fields.

Repository scripts do not update `lifecycle_status`. A manifest lifecycle
change without reviewed real-project evidence is a contract violation.

## Blocked State

If the first real-project run is `BLOCKED`, preserve the report and route the
blockers instead of weakening the gate. Use:

- `blocking_checks` for failed checks;
- `warning_checks` for advisory issues;
- `remediation_items` for owner, severity, summary, and command;
- `promotion_blockers` for promotion-specific blockers;
- `REAL_PROJECT_ADOPTION_CHECKLIST.md` for pack-layer implementation details.

For a Spec Authority defect, also preserve the candidate source set, selected
source, Human approval evidence, affected output, and reviewer verdict. Apply
only the minimum v4.93 safety repair needed to prevent a false PASS. Carry the
full revision, freshness, dependency invalidation, and resolver implementation
into the accepted v4.94 plan.

The root manifest retains the package-level fail-closed state
`real_project_adoption.status: "blocked_pending_real_project_inputs"` while
supported adoption remains unapproved. An external project can satisfy the
qualifying-input requirement, as LessIsMore R2 does, without automatically
changing the released package manifest or lifecycle. That transition requires
separate supported-adoption evidence and manual promotion authority.

Codex, Cursor, or WorkBuddy users may start from the shared input checklist at
`adapters/codex/examples/real_project_adoption_inputs.example.json` and validate
their filled input shape against
`adapters/codex/examples/real_project_adoption_inputs.schema.json`.

## Non-Goals

- Do not treat fixture outputs as adoption evidence.
- Do not treat dry-run reports as promotion evidence.
- Do not write generated project state into canonical v4.93 definitions.
- Do not make `.dev_os_meta/` a runtime package dependency.
- Do not promote lifecycle status automatically from a script.
- Do not add the full v4.94 Temporal Shared Truth implementation to v4.93
  unless a narrowly scoped fail-closed repair is required to prevent false
  acceptance of stale or superseded authority.
