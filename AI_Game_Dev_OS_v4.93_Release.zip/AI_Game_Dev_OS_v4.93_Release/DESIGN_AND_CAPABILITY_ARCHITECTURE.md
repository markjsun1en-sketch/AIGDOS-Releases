# AI Game Dev OS v4.93 Design And Capability Architecture

This document is the explanatory architecture map for `AI_Game_Dev_OS_v4.93/`.
It explains why the system is split into layers, how current capabilities are
organized, how agents and skills are selected, and how evidence flows back into
validation. Use it after `README.md` and before operational routing documents
such as `MODULES_AND_INVOCATION.md`.

v4.93 should be read as a governed AI production operating system, not as a
single prompt pack. Its central design rule is:

```text
code and schemas are executable truth
documents are intent and rationale
evidence is the memory of what happened
manifest and registry files are structured operational state
human approval remains the authority for promotion
```

## Whole-System Layered Architecture

The v4.78 architecture diagram made the whole system legible by showing control,
planning, execution, runtime truth, evidence, and export as one connected
system. v4.93 still needs that view, but the implementation now has additional
OS/Pack separation, AI IDE adapters, target-project runtime state, release
snapshot governance, and `.dev_os_meta` workspace memory.

```mermaid
flowchart TB
  subgraph L1["L1 Control And Authority Layer"]
    H["Human / Owner / Approver"]
    EP["Executive Producer / Product Owner"]
    OSL["OS Leads / Governance Owners"]
    ORCH["Orchestrator Control Capability"]
    H --> EP --> ORCH
    OSL --> ORCH
  end

  subgraph L2["L2 Planning And Governance Layer"]
    INTENT["Intent Baseline"]
    ROADMAP["Roadmap / Phase Status"]
    CHANGE["Governance / Change Control"]
    ADOPT["Lifecycle / Adoption Governance"]
    MIRROR["Root Mirror + Release Policy"]
    ORCH --> INTENT
    ORCH --> ROADMAP
    ORCH --> CHANGE
    ORCH --> ADOPT
    ORCH --> MIRROR
  end

  subgraph L3["L3 Execution And Capability Layer"]
    PACK["Production Pack"]
    WF["Workflow Contracts"]
    AGENTS["Specialized Agents"]
    SKILLS["Skills Library"]
    SCRIPTS["Delivery Scripts / Tools"]
    ADAPTERS["Runtime Adapter Lanes"]
    ROADMAP --> PACK
    CHANGE --> WF
    PACK --> AGENTS
    PACK --> SKILLS
    WF --> AGENTS
    AGENTS --> ADAPTERS
    SCRIPTS --> WF
  end

  subgraph L4["L4 Runtime Core And Source-Of-Truth Layer"]
    CODE["Code + Schemas"]
    MANIFEST["Manifest + Pack Manifest"]
    RUNTIME["Target Project Runtime Instance"]
    TRUTH["Shared Truth Index"]
    PLAN["Agent Run Plan + Handoff Lanes"]
    TRACE["Agent Execution Trace + Provenance"]
    ARTIFACTS["Project Artifacts"]
    CODE --> MANIFEST
    MANIFEST --> PLAN
    ADAPTERS --> PLAN
    PLAN --> TRACE
    RUNTIME --> TRUTH
    ARTIFACTS --> TRUTH
    AGENTS --> ARTIFACTS
    SCRIPTS --> CODE
  end

  subgraph L5["L5 Validation And Evidence Layer"]
    VALIDATE["Validation Engine"]
    EVIDENCE["Evidence Model"]
    RECON["Reconciliation"]
    BETA["Beta Readiness Report"]
    LOGS["Test / Run Logs"]
    CODE --> VALIDATE
    MANIFEST --> VALIDATE
    TRUTH --> VALIDATE
    TRACE --> VALIDATE
    ARTIFACTS --> VALIDATE
    VALIDATE --> EVIDENCE
    VALIDATE --> RECON
    VALIDATE --> LOGS
    EVIDENCE --> BETA
    RECON --> BETA
  end

  subgraph L6["L6 Observation And Delivery Layer"]
    REPORTS["Rendered Reports"]
    SNAPSHOT["Release Snapshot"]
    ARCHIVE["Archive / Compaction"]
    BETA --> REPORTS
    LOGS --> REPORTS
    MIRROR --> SNAPSHOT
    REPORTS --> ARCHIVE
  end

  subgraph EXT["External / Specialized Truth Layers"]
    GIT["Git / Repo / CI"]
    ISSUE["Jira / TAPD / Issue Trackers"]
    DOCS["Docs / Storage / Knowledge Base"]
    PROJECT["Target Game Project Repo"]
    META[".dev_os_meta Workspace Governance"]
  end

  PROJECT -. project files and local runtime state .-> RUNTIME
  PROJECT -. code and artifact signals .-> TRUTH
  GIT -. source and CI evidence .-> VALIDATE
  ISSUE -. issue state and approvals .-> RECON
  DOCS -. design and storage references .-> TRUTH
  META -. problem, fix, pattern, and evolution candidates .-> CHANGE
  META -. promoted decisions only .-> OSL
  REPORTS -. review feedback .-> H
  BETA -. promotion decision .-> ADOPT
  ADOPT -. lifecycle remains draft until reviewed evidence passes .-> H
```

Key reading rules:

- L1 owns authority. It can approve, reject, escalate, or promote; lower layers
  can recommend but cannot silently promote lifecycle.
- L2 owns governance intent. It converts owner intent into roadmap, lifecycle,
  change-control, mirror, and release policies.
- L3 owns capability execution. Agents, skills, workflow contracts, scripts,
  and adapter lanes perform scoped work but must declare owners and evidence.
- L4 owns runtime truth surfaces. Code, schemas, manifests, Shared Truth,
  run plans, execution traces, and project artifacts are the sources validators
  inspect.
- L5 owns evidence and verdict preparation. Validation can produce reports and
  blockers, but promotion remains a human/governance decision.
- L6 owns observation, delivery, and compaction. Release snapshots and reports
  are outputs, not separate authority sources.
- External systems are specialized truth layers. They can supply evidence or
  receive reports, but they do not redefine canonical v4.93 agents, skills,
  schemas, or workflows.

## v4.78 To v4.93 Architecture Continuity

v4.93 does not discard the v4.78 layered architecture. It re-expresses it with
clearer package boundaries, stronger adapter contracts, and an explicit
real-project adoption gate.

| v4.78 concept | v4.93 location | Current status |
| --- | --- | --- |
| Human / Owner / Approver | L1 control authority, `REAL_PROJECT_ADOPTION_CONTRACT.md` | Present; still final authority for lifecycle promotion. |
| Producer / Project Lead | L1/L2 product ownership and roadmap stewardship | Present as governance role, not a separate runtime object. |
| Orchestrator | `os_layer/os_control_plane/leads/orchestrator.capability.json` | Present; owns cross-layer routing review. |
| Escalation Ladder | Orchestrator stop conditions, adoption contract, adapter base policy | Present as policy behavior; not a dedicated root diagram node until this document. |
| Runtime Budget / Capacity Governance | L2 governance constraints, phase status, roadmap and change-control planning | Partially explicit; capacity remains mostly governance/document-level. |
| Governance / Change Control | `RESTRUCTURING_PLAN.md`, `.dev_os_meta`, root manifest, release policy | Present; `.dev_os_meta` stores candidates, package surfaces store promoted behavior. |
| Sprint Planning | Pack workflow, roadmap status, delivery command matrix | Present in pack-layer workflow/status docs. |
| Project Modes / Stage Rules | `lifecycle_status`, real-project adoption mode, supported project phases | Present; implemented through manifest and adoption contract rather than one mode file. |
| Specialized Agents | Production pack `agents/` and capability manifest | Present. |
| Skills Library | Production pack `skills/` plus OS-layer skill foundations | Present. |
| Subagents / Temporary Workers | Runtime adapter lanes and generated agent run plans | Present as external runtime behavior, not repository-script execution. |
| Runtime Scripts / Tools | `scripts/delivery/` and `pack_layer/scripts/delivery/` | Present; scripts generate or validate artifacts, not LLM routing. |
| Contracts / Ownership Binding | Agent contracts, skill contracts, runtime instance contract, adapter base | Present. |
| Feature State Machine | Delivery workflow states, run plan status, phase/adoption gates | Present as distributed workflow/gate state rather than one monolithic object. |
| Handoff Objects | Agent run plan, handoff lanes, runtime-produced execution trace | Present. |
| Registry | Root manifest, pack manifest, Shared Truth index, target-project `.ai_dev_os` state | Present as multiple structured truth surfaces. |
| Issue Objects | FixOps cards, `.dev_os_meta/fixops/`, external issue trackers | Present outside runtime package by default. |
| Validation Engine | Delivery validators, schema checks, pytest suites | Present. |
| Evidence Model | Evidence bundles, beta readiness report, execution trace, logs | Present. |
| Reconciliation | Shared Truth, Architecture Baseline, write-back validation, beta readiness | Present. |
| Test / Compile / Run Logs | Test logs, run logs, report inputs from target artifacts | Present when supplied by runtime/project. |
| Dashboard Export | Rendered beta/readiness reports and release snapshot surfaces | Partially present; no dedicated interactive dashboard in v4.93 root. |
| Reports / Snapshots | Beta readiness report, release snapshot, phase status, changelog | Present. |
| Archive / Compaction | OS-layer archive/compaction policy and workspace governance memory | Present in inherited OS surfaces; package runtime must not depend on `.dev_os_meta`. |
| Docs / Storage / Knowledge Base | External specialized truth layer and package docs | Present. |
| Git / Repo / CI | External specialized truth layer and validation evidence source | Present as integration/evidence boundary. |
| Jira / TAPD | External specialized truth layer | Supported by inherited OS contracts; not required by v4.93 package runtime. |

The main architectural change is that v4.93 no longer treats every v4.78 object
as a single local runtime file. Some concepts became OS control contracts, some
became pack-layer workflow artifacts, some became target-project runtime state,
and some remain external truth layers.

## Governance Nodes Expanded

The compact L2 box in the whole-system diagram hides several important
governance controls. They remain separate decisions even when implemented
through shared documents or adapter policies.

```mermaid
flowchart TB
  OWNER["Human / Owner / Approver"]
  ORCH["Orchestrator"]
  ESC["Escalation Ladder"]
  BUDGET["Runtime Budget / Capacity Governance"]
  CHANGE["Governance / Change Control"]
  SPRINT["Sprint / Phase Planning"]
  MODES["Project Modes / Stage Rules"]
  ADOPT["Lifecycle / Adoption Gate"]
  MIRROR["Root Mirror / Release Snapshot Policy"]

  OWNER --> ORCH
  ORCH --> ESC
  ORCH --> BUDGET
  ORCH --> CHANGE
  ORCH --> SPRINT
  ORCH --> MODES
  ORCH --> ADOPT
  ORCH --> MIRROR
  ESC -. unclear authority or missing evidence .-> OWNER
  BUDGET -. over-capacity plan .-> CHANGE
  SPRINT -. phase status .-> ADOPT
  MODES -. allowed adoption mode .-> ADOPT
  MIRROR -. stale snapshot or mirror drift .-> CHANGE
```

Governance interpretation:

- Escalation is triggered by unclear authority, blocked evidence, write-boundary
  ambiguity, lifecycle promotion, or unresolved cross-source conflict.
- Runtime budget and capacity governance limit how many agents, artifacts, and
  reviews can be active before the plan must be split or re-scoped.
- Project mode and stage rules are expressed through lifecycle fields,
  supported project phases, adoption mode, and required evidence, not through
  an AI IDE's local preference.
- Root mirror and release snapshot policy prevent root commands, pack-layer
  commands, and release artifacts from drifting apart.

## Founding Constraints And Doctrine

The early AI Game Dev OS doctrine is still present in v4.93, but it had become
buried across historical OS documents and proposals. v4.93 operationalizes those
constraints as first-class package rules.

### Founding Declaration 1: Portable Core And Runtime Profiles

The OS core must stay portable. Project, engine, AI IDE, and external-tool
differences belong in profiles, adapters, packs, or target-project runtime
state. They must not rewrite the canonical OS contract.

```mermaid
flowchart LR
  CORE["Portable OS Core"] --> PROFILES["Runtime Profiles"]
  CORE --> PACKS["Production Packs"]
  CORE --> ADAPTERS["AI IDE Adapters"]
  PROFILES --> PROJECT["Target Project Runtime State"]
  PACKS --> PROJECT
  ADAPTERS --> PROJECT
```

### Founding Declaration 2: Truth Hierarchy

Truth is layered. A document can explain intent, but executable state and
validated evidence decide whether the system is actually coherent.

```mermaid
flowchart TB
  APPROVAL["Human Approval / Promotion Authority"]
  CODE["Code + Schemas"]
  MANIFEST["Manifest / Registry State"]
  EVIDENCE["Evidence / Logs / Reports"]
  DOCS["Documents / Intent / Rationale"]
  MEMORY["Workspace Memory / .dev_os_meta"]

  APPROVAL --> CODE
  CODE --> MANIFEST
  MANIFEST --> EVIDENCE
  DOCS --> CODE
  DOCS --> MANIFEST
  MEMORY -. candidates only .-> DOCS
  MEMORY -. promoted only after review .-> CODE
```

In practice:

- Code and schemas are the executable truth for correctness.
- Documents are intent, rationale, onboarding, and governance memory.
- Evidence records what actually happened.
- Manifest and registry files are structured operational state.
- `.dev_os_meta` can store governance memory, but runtime packages must not
  require it.

### Founding Declaration 3: Layer 1 / Layer 2 Separation

Authority and coordination are separate. Owner approval, promotion, and scope
decisions stay at the control layer. Execution planning and capability routing
can prepare recommendations, but they do not own final authority.

```mermaid
flowchart LR
  L1["L1 Authority: owner, approver, governance lead"]
  L2["L2 Coordination: roadmap, routing, change control"]
  L3["L3 Execution: agents, skills, scripts, adapters"]
  L5["L5 Evidence: validation, reports, blockers"]
  L1 --> L2 --> L3 --> L5
  L5 -. recommendation .-> L1
```

### Founding Declaration 4: Control Plane / Execution Plane Separation

The OS layer defines control-plane contracts: routing, authority, capability
boundaries, memory policy, governance, and validation rules. The pack layer
defines execution-plane production capability for game development workflows.

```mermaid
flowchart TB
  subgraph OS["os_layer Control Plane"]
    ORCH2["Orchestrator"]
    GOV["Governance Contracts"]
    MEM["Memory / FixOps Policy"]
    VALID["Validation Principles"]
  end
  subgraph PACKL["pack_layer Execution Plane"]
    PACK2["Production Pack"]
    AG2["Agents"]
    SK2["Skills"]
    WF2["Workflow + Artifacts"]
  end
  ORCH2 --> PACK2
  GOV --> WF2
  MEM -. promoted learnings .-> PACK2
  WF2 --> VALID
```

### Founding Declaration 5: Agents Are Contracts, Not Just Code

An agent is a contract containing owner, purpose, allowed inputs, allowed
outputs, write boundaries, evidence, stop conditions, and validation route. The
runtime adapter may execute an agent, but it cannot redefine the canonical
agent.

```mermaid
flowchart LR
  GOAL["User Goal"] --> ROUTE["Invocation Plan"]
  ROUTE --> AGENT["Canonical Agent Contract"]
  AGENT --> SKILL["Owner Skill / Workflow State"]
  SKILL --> OUTPUT["Artifact or Handoff"]
  OUTPUT --> TRACE2["Execution Trace"]
  TRACE2 --> CHECK["Validation"]
```

### Founding Declaration 6: Charter Anti-Patterns Are Hard Constraints

The system rejects silent authority transfer, uncontrolled writes, document-only
promotion, fixture-only promotion, and adapter-defined canonical behavior. These
are not style preferences; they are architecture constraints.

### Founding Declaration 7: Evidence Over Trust

A workflow is not considered complete because an agent says it is complete. It
is complete only when the required artifact exists, matches schema and semantic
rules, and leaves reviewable evidence.

```mermaid
flowchart LR
  CLAIM["Agent Claim"] --> ART["Artifact"]
  ART --> SCHEMA["Schema Check"]
  SCHEMA --> SEM["Semantic Check"]
  SEM --> EVID["Evidence Bundle"]
  EVID --> VERDICT["Reviewable Verdict"]
```

### Founding Declaration 8: Managed Autonomy, Not Silent Authority

AI agents can plan, draft, inspect, and propose. They stop when evidence is
missing, when authority is unclear, when a write boundary would be crossed, or
when lifecycle promotion is requested.

```mermaid
flowchart TB
  TASK["Task"] --> PLAN2["Plan / Owner / Boundary"]
  PLAN2 --> WORK["Scoped Agent Work"]
  WORK --> CHECK2{"Evidence and Authority OK?"}
  CHECK2 -- yes --> REPORT["Report + Validation"]
  CHECK2 -- no --> STOP["Stop / Escalate"]
  STOP --> OWNER["Human / Governance Review"]
```

### Founding Declaration 9: Project Mount And Runtime State Isolation

The v4.93 source tree contains canonical definitions. Generated bindings,
run plans, traces, reports, and project-local state belong in the target
project runtime instance or an explicit artifact root.

```mermaid
flowchart LR
  V493["AI_Game_Dev_OS_v4.93 Source Tree"]
  TARGET["Target Project"]
  RSTATE["Target Project .ai_dev_os Runtime State"]
  OUT["Delivery Artifact Root"]
  V493 --> TARGET
  TARGET --> RSTATE
  TARGET --> OUT
  RSTATE -. evidence path .-> V493
  OUT -. validation input .-> V493
```

### Founding Declaration 10: Preflight Is Advisory, Not Approval

Readiness and preflight tools can diagnose blockers and produce reports. They
do not approve production adoption or lifecycle promotion by themselves.

### Founding Declaration 11: Memory Learns, It Does Not Promote Itself

`.dev_os_meta` can collect problem cards, fix cards, pattern cards, and
self-evolution candidates. Those items affect runtime behavior only after a
reviewed promotion into `os_layer/`, `pack_layer/`, or root compatibility
surfaces.

### Founding Declaration 12: Starters And Project Packs Cannot Redefine The OS

Starter templates and production packs can specialize game-domain work. They
cannot replace the OS authority model, truth hierarchy, canonical agent
contract, evidence rules, or adapter boundaries.

## Current v4.93 Capability Organization

v4.93 is physically split so the system can keep inherited OS contracts while
allowing the game-production pack to evolve independently.

```mermaid
flowchart TB
  ROOT["AI_Game_Dev_OS_v4.93 Root Entrypoints"]
  OS["os_layer: inherited OS baseline + promoted OS additions"]
  PACK["pack_layer: end_to_end_production_pack"]
  ADAPT["adapters: Codex, Cursor, WorkBuddy, runtime adapter contracts"]
  SCHEMA["schemas: root manifest and adapter schemas"]
  MIRROR["packs / scripts / tests: root compatibility mirrors"]
  RELEASE["AI_Game_Dev_OS_v4.93_Release snapshot"]

  ROOT --> OS
  ROOT --> PACK
  ROOT --> ADAPT
  ROOT --> SCHEMA
  ROOT --> MIRROR
  MIRROR <--> PACK
  ROOT --> RELEASE
```

The split has four practical consequences:

- Root files own whole-version onboarding, module selection, invocation order,
  and validation command maps.
- `os_layer/` owns control-plane capabilities, inherited OS surfaces, promoted
  OS additions, and governance foundations.
- `pack_layer/` owns the production pack, game-development agents, skills,
  workflows, schemas, reports, and fixture-backed delivery tests.
- Root mirrors exist for compatibility and must stay synchronized with
  `pack_layer/`.

## v4.93 Runtime Object Model

v4.93 uses a distributed object model instead of a single runtime registry file.
The following diagram shows the objects an AI IDE or runtime adapter should keep
separate.

```mermaid
flowchart TB
  subgraph CANON["Canonical Package Objects"]
    ROOTDOC["Root Entrypoint Docs"]
    VMAN["Version Manifest"]
    PMAN["Production Pack Manifest"]
    AGC["Agent Contracts"]
    SKC["Skill Contracts"]
    WFC["Workflow Contracts"]
    SCHEMA["Schemas"]
  end

  subgraph RUNTIMEOBJ["Runtime / Project Objects"]
    BIND["Project Capability Bindings"]
    RUNPLAN["Agent Run Plan"]
    HANDOFF["Handoff Lanes"]
    TRACE["Agent Execution Trace"]
    TRUTH["Shared Truth Index"]
    ARCH["Architecture Baseline Report"]
    ART["Delivery Artifacts"]
    ISSUE["Issue / Problem Objects"]
  end

  subgraph VERDICTOBJ["Evidence And Verdict Objects"]
    VALID["Validation Results"]
    READINESS["Beta Readiness Report"]
    LOG["Test / Run Logs"]
    DECISION["Manual Review Decision"]
  end

  ROOTDOC --> VMAN
  VMAN --> PMAN
  PMAN --> AGC
  PMAN --> SKC
  PMAN --> WFC
  SCHEMA --> ART
  BIND --> RUNPLAN
  RUNPLAN --> HANDOFF
  HANDOFF --> TRACE
  ART --> TRUTH
  ART --> ARCH
  ISSUE --> TRUTH
  TRACE --> VALID
  TRUTH --> VALID
  ARCH --> VALID
  LOG --> VALID
  VALID --> READINESS
  READINESS --> DECISION
```

Object ownership rules:

| Object type | Typical location | Owner |
| --- | --- | --- |
| Root entrypoint docs | `AI_Game_Dev_OS_v4.93/*.md` | Version governance. |
| Version manifest | `MANIFEST.json` | Version governance and validators. |
| Pack manifest | `pack_layer/packs/game_system_packs/end_to_end_production/capability_pack.json` | Pack governance. |
| Agent and skill contracts | Pack-layer `agents/` and `skills/` | Pack owner; adapters only consume them. |
| Workflow contracts | Pack-layer `references/` | Pack owner. |
| Project bindings | Target project `.ai_dev_os/` or accepted compatibility path | Runtime adapter / target project. |
| Run plan and handoff lanes | Target project `.ai_dev_os/` or explicit artifact root | Runtime adapter. |
| Execution trace | Target project `.ai_dev_os/agent_execution_trace.json` or artifact root | Runtime adapter; validator consumes it. |
| Shared Truth and architecture reports | Explicit delivery artifact root | Pack validators and project runtime. |
| Problem/fix/pattern cards | Repository-root `.dev_os_meta/` by default | Workspace governance, not runtime package. |
| Beta readiness report | Explicit delivery artifact root | Validator output; human review consumes it. |

## Agent And Skill Invocation Model

The AI IDE or runtime adapter must convert a natural-language user request into
an explicit invocation plan before work begins.

```mermaid
flowchart LR
  USER["Natural-Language Goal"] --> CLASS["Goal Class"]
  CLASS --> LAYER["Selected Layer"]
  LAYER --> OWNER["Owner Agent or Control Capability"]
  OWNER --> SKILL["Owner Skill / Workflow State"]
  SKILL --> WRITE["Allowed Write Surfaces"]
  WRITE --> NEED["Required Evidence"]
  NEED --> CMD["Validation Command"]
  CMD --> STOP["Stop Condition / Verdict"]
```

Examples:

| Goal | Primary route |
| --- | --- |
| Create or improve a GDD | Pack-layer GDD orchestration and specialist GDD skills |
| Attach a real project | Runtime instance contract, Shared Truth, Architecture Baseline, beta readiness |
| Ask agents to divide work | Orchestrator routing, agent run plan, runtime adapter trace |
| Reconcile design and implementation | Shared Truth and Architecture Baseline validation |
| Fix recurring process failure | `.dev_os_meta` FixOps intake, then reviewed promotion if needed |
| Change OS behavior | Workspace governance first, then promoted OS-layer change |

Repository scripts may generate plans, contracts, reports, and validators. They
do not become an automatic LLM router. External AI runtimes perform the agent
work and return evidence such as an execution trace for validation.

## Capability Organization Matrix

| Capability area | Layer | Owner surface | Primary inputs | Primary outputs | Required evidence / stop condition |
| --- | --- | --- | --- | --- | --- |
| Cross-layer routing | OS control plane | Orchestrator capability sheet | User goal, root manifest, pack manifest | Invocation plan recommendation | Stop if owner, layer, write boundary, or evidence route is unclear. |
| GDD orchestration | Pack layer | GDD orchestrator skill and workflow | Intent, project id, scope, depth/quality profile | GDD run package and artifact contracts | Stop if required GDD artifacts or review gates are missing. |
| Specialist design review | Pack layer | GDD specialist agents and skills | Draft GDD sections, rubric, design constraints | Review notes and revised design artifacts | Stop if semantic checks fail or design ownership is unclear. |
| Production specification | Pack layer | Production spec skills | Approved design artifacts | Runtime/data/art/QA handoff specs | Stop if handoff lacks owner, target surface, rollback, or QA evidence. |
| Shared Truth | Pack layer | Shared Truth generator and validator | Project artifacts, code/data/design references | Shared Truth index | Stop if references are missing, stale, or inconsistent. |
| Architecture Baseline | Pack layer | Architecture baseline inspectors and validators | Target project files, design declarations | Architecture baseline report | Stop if declared architecture cannot be reconciled with project files. |
| Controlled refactor | Pack layer | Controlled refactor contracts and validators | Approved refactor proposal and before/after evidence | Refactor evidence bundle | Stop if rollback, QA, or approval evidence is absent. |
| Agent harness | Pack layer + adapter lane | Agent run plan generator and trace validator | Capability bindings, workflow lanes, runtime trace | Validated execution trace | Stop if trace is synthetic when real-project evidence is required. |
| Beta readiness | Pack layer | Readiness evaluator and report renderer | Real project root, artifacts, trace, pack evidence | Beta readiness report | Stop if blockers remain or manual review is incomplete. |
| AI IDE integration | Adapters | Shared adapter base plus Codex/Cursor/WorkBuddy profiles | Root read order, invocation profile, project binding | Runtime-specific execution behavior | Stop if adapter tries to redefine canonical agents, skills, schemas, or workflows. |
| FixOps / memory intake | Workspace governance + promoted OS docs | `.dev_os_meta/fixops/` and `os_layer/docs/31_fixops/` | Recurring issue, fix, pattern, evolution candidate | Governance evidence and promotion candidate | Stop if behavior has not been promoted into package surfaces. |
| Release snapshot | Root delivery policy | Source tree and `AI_Game_Dev_OS_v4.93_Release/` | Source package tree | Fresh release snapshot | Stop if snapshot stale, mirror drift exists, or transients are present. |

This matrix is intentionally contract-oriented. It tells a runtime which
surface owns a capability and what evidence must exist before work can be
considered complete.

## Real-Project Adoption Swimlane

The real-project path crosses human authority, AI IDE routing, OS control,
pack execution, target-project runtime state, validation, and release
governance. No single layer owns the whole path.

```mermaid
sequenceDiagram
  actor Owner as Human / Owner
  participant IDE as AI IDE / Runtime Adapter
  participant Orch as Orchestrator
  participant Pack as Production Pack
  participant Project as Target Project
  participant Artifacts as Artifact Root
  participant Validators as Validators
  participant Review as Manual Review

  Owner->>IDE: request project adoption or production workflow
  IDE->>IDE: read root entrypoints and architecture contract
  IDE->>Orch: request OS/Pack routing review
  Orch-->>IDE: selected layer, owner, evidence, stop condition
  IDE->>Project: inspect project root and .ai_dev_os state
  IDE->>Pack: select workflow, agents, skills, and validators
  Pack-->>IDE: artifact contracts and handoff lanes
  IDE->>Project: execute scoped agent/runtime work
  Project-->>Artifacts: write delivery artifacts and reports
  Project-->>IDE: return agent execution trace
  IDE->>Validators: run schema, semantic, trace, and readiness checks
  Validators-->>Artifacts: beta readiness report and logs
  Validators-->>Review: blockers, verdict inputs, evidence summary
  Review-->>Owner: recommend PASS/BLOCKED and promotion decision
  Owner-->>IDE: approve, reject, or request follow-up
```

The adoption path is blocked unless the target project supplies real evidence:
project runtime state, delivery artifacts, runtime-produced execution trace,
validation logs, readiness report, and manual review.

## Evidence And Promotion Flow

v4.93 deliberately separates fixture confidence from real-project adoption.
Fixture success proves regression stability. It does not prove production
fitness.

```mermaid
flowchart TB
  FIXTURE["Fixture / Synthetic Evidence"] --> REGRESS["Regression Confidence"]
  REAL["Real Project Inputs"] --> TRACE3["Runtime-Produced Trace"]
  TRACE3 --> READINESS["Beta Readiness Evaluation"]
  REAL --> READINESS
  READINESS --> REPORT2["Readiness Report"]
  REPORT2 --> REVIEW["Manual Review"]
  REVIEW --> PROMOTE{"Promotion Allowed?"}
  PROMOTE -- no --> DRAFT["Lifecycle remains draft"]
  PROMOTE -- yes --> UPDATE["Reviewed manifest / changelog / release update"]
  REGRESS -. cannot promote alone .-> DRAFT
```

The current v4.93 posture remains a Production Pack Beta Candidate scaffold.
`lifecycle_status` remains `draft` until reviewed real-project evidence passes.

## Why The v4.78-Style Diagram Was Missing

It was missing because the earlier documentation work optimized for contract
precision: root entrypoints, OS/Pack separation, adapter boundaries, runtime
instance isolation, and validation gates. That made the system mechanically
more consistent, but it did not restore the older architecture affordance that
lets a human see the whole OS in one picture.

That was a documentation design gap. The fix is not to copy v4.78 literally;
the fix is to provide the equivalent v4.93 whole-system view with the newer
surfaces included: OS/Pack split, adapters, release snapshot, target-project
runtime instance, and `.dev_os_meta` governance memory.
